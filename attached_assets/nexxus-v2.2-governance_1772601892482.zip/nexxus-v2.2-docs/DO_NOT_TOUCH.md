# DO_NOT_TOUCH.md — Nexxus v2.2
# These files and directories are off-limits to all agents at all autonomy levels.
# Enforcer blocks any write attempt to these paths.
# Owner must explicitly remove an item from this list before any agent may touch it.

---

## FILES — NO AGENT WRITES PERMITTED

| File | Reason |
|------|--------|
| CLAUDE.md | Master governance — agent modification is a critical breach |
| DO_NOT_TOUCH.md | This file — self-protecting |
| .agent_docs/acceptance_criteria.md | Contract source of truth — owner only |
| .env.production | Production credentials — never in agent scope |
| .env | Default env — staging only during development |
| MEMORY.md | Scribe only — no other agent writes |
| MEMORY.md.bak | Backup — Scribe only |

---

## DIRECTORIES — NO AGENT CREATES OR MODIFIES

| Directory | Reason |
|-----------|--------|
| .project/ | Legacy init-project governance layer — causes three-layer conflict |
| docs/archive/ | Archived files — append only, no modification |
| /root/.claude/ | Claude system-level configuration — never modified |

---

## ACTIONS — PERMANENTLY PROHIBITED

| Action | Reason |
|--------|--------|
| Run /init-project or /init-template | Generates .project/ governance conflict |
| Connect to production Supabase URL | All dev uses staging only |
| Use --dangerously-skip-permissions without L4 approval | March 3 incident root cause |
| Write real phone numbers to any database | Customer privacy, SMS compliance |
| Modify any file outside declared session scope | Governance boundary |
| Delete from docs/archive/ | Archive is permanent |
| Alter master system prompt directly | Hunch Filter is additive only |
| Queue outbound triggers | Blocked triggers become escalations, never queue |

---

## ENFORCER RULE

If any agent attempts to write to a file or directory on this list:
1. Block the write immediately
2. Log the attempt with: agent, file path, timestamp, session ID
3. Create a Critical escalation in TeamBox
4. Halt the agent session
5. Notify owner before any further work proceeds
