# SPEC.md — Nexxus v2.2 Architecture Specification
# PURPOSE: Build-ready architecture reference. Facts only. No feature specs (see SRS.md).
# Audience: Engineers and AI agents.
# Last updated: 2026-03-04

---

## 1. TECHNOLOGY STACK

| Layer | Technology | Version | Notes |
|-------|-----------|---------|-------|
| Frontend | Vite + React | 18 | Wouter for routing |
| Backend | Node.js + Express | 20 / 5 | |
| Database | Supabase PostgreSQL | Latest | Drizzle ORM |
| AI | Anthropic Claude | API | Via MCP proxy |
| Voice | VAPI | API | Via MCP proxy |
| Video | Tavus | API | Via MCP proxy |
| SMS | TextMagic | API | Via MCP proxy |
| Email | Resend | API | Via MCP proxy |
| Process manager | PM2 | Latest | |
| Version control | Git | Latest | Branch: v2.2 |

---

## 2. PORTS AND PROCESSES

| Environment | Port | PM2 process name |
|------------|------|-----------------|
| Production | 5020 | nexxus-v2 |
| Staging | 5021 | nexxus-v2-staging |
| central-mcp | Internal | central-mcp (PM2 id 14) |

---

## 3. MCP PROXY ARCHITECTURE

All external service calls route through central-mcp. No direct API calls from application code.
Location: ../central-mcp (relative to nexxus-v2 root)

### VIN Solutions Tools
| Tool | Purpose | Auth |
|------|---------|------|
| vin_query_leads | Search leads by date range, dealer, status | Per-org OAuth token from Supabase |
| vin_create_contact | Step 1 of lead creation | Per-org OAuth token |
| vin_create_lead | Step 2 — requires contact href from step 1 | Per-org OAuth token |
| vin_get_lead_sources | List valid lead sources per dealer | Per-org OAuth token |
| vin_token_status | Check OAuth token health per org | Service key |

VIN API critical facts:
- Header casing: v3 (lowercase) — NOT V3
- Response key: items — NOT results
- Lead creation is 2-step: contact first, then lead with contact href
- Content types vary per endpoint: application/json vs application/vnd.coxauto.v3+json
- OAuth tokens: per-org, stored encrypted in Supabase tokens table
- MCP token access: read-only Supabase service key scoped to tokens table only

### VAPI Tools
| Tool | Purpose | Kill switch |
|------|---------|------------|
| vapi_create_call | Initiate outbound voice call | Checks phone_enabled before firing |
| vapi_get_transcript | Retrieve call transcript | None needed |
| vapi_get_call_status | Check call status | None needed |

VAPI org ID: c303d993-bf42-4784-a8cb-247477b1cbdd

### Tavus Tools
| Tool | Purpose |
|------|---------|
| tavus_create_session | Initialize video session (on customer click only — never on page load) |
| tavus_get_status | Check session status |
| tavus_end_session | Terminate session |

### TextMagic Tools
| Tool | Purpose | Kill switch |
|------|---------|------------|
| sms_send | Send SMS | Checks sms_enabled before firing |
| sms_get_status | Check message status | None needed |

TextMagic: credentials per-org from DB | 11-char sender name limit | API key from org settings

### Resend Tools
| Tool | Purpose | Kill switch |
|------|---------|------------|
| email_send | Send email | Checks email_enabled before firing |
| email_get_status | Check delivery status | None needed |

### Billing Tools
| Tool | Purpose |
|------|---------|
| billing_get_usage | Return usage data per org by period |
| billing_create_invoice | Generate invoice record |

### Calendar Tools
| Tool | Purpose |
|------|---------|
| calendar_create_event | Create event (Google or Outlook) |
| calendar_get_events | Retrieve events |

### Third-Party Appointment Tools
| Tool | Purpose |
|------|---------|
| dealerdotcom_get_appointments | Pull appointments from Dealer.com |
| tekion_get_appointments | Pull appointments from Tekion |

### Google Ads Tools
| Tool | Purpose |
|------|---------|
| ads_query_campaigns | Query campaign performance data |
| ads_get_performance | Get lead and spend metrics |

### Database Tools
| Tool | Purpose | Autonomy required |
|------|---------|------------------|
| db_query | Read operations | L1+ |
| db_mutate | Write operations | L2+ |

---

## 4. KILL SWITCH SCHEMA

```sql
-- Add to organization_settings table
outbound_enabled  BOOLEAN NOT NULL DEFAULT FALSE,
sms_enabled       BOOLEAN NOT NULL DEFAULT FALSE,
phone_enabled     BOOLEAN NOT NULL DEFAULT FALSE,
email_enabled     BOOLEAN NOT NULL DEFAULT FALSE
```

Logic: master outbound_enabled = FALSE blocks all channels regardless of channel settings.
Channel checks only evaluated when outbound_enabled = TRUE.
All checks enforced at MCP tool layer — not UI layer.
Blocked triggers → Unsent Message escalation in TeamBox (never queued).

---

## 5. RBAC ROLES

| Role | Scope | Default section access |
|------|-------|----------------------|
| Super Admin | Platform-wide | All |
| Partner Admin | Their orgs only | All |
| Org Admin | Their org | All |
| Sales | Org — sales data | AI Chat, My Work, Sales (if granted) |
| Sales Manager | Org — sales + team | AI Chat, My Work, Sales (if granted) |
| Service | Org — service data | AI Chat, My Work, Service (if granted) |
| Marketing | Org — marketing data | AI Chat, My Work, Marketing (if granted) |
| Executive | Org — read only all | AI Chat, My Work + any granted |

Default for all users: AI Chat + My Work always on.
All other sections require explicit Org Admin grant per user.
Visibility requires: module enabled at platform level AND section access granted by Org Admin.

---

## 6. METERING — BILLABLE EVENTS

All events counted regardless of package. Package allowances set by Super Admin per org.

| Event | Unit | Alert threshold |
|-------|------|----------------|
| Outbound SMS | Per message | 80% of allowance |
| Outbound phone call | Per minute | 80% of allowance |
| Outbound email | Per message | 80% of allowance |
| VAPI inbound call | Per minute | 80% of allowance |
| Tavus video session | Per minute | 80% of allowance |
| VIN Solutions API call | Per call | 80% of allowance |
| CSV upload processing | Per row | 80% of allowance |
| AI chat message | Per message | 80% of allowance |
| Campaign message | Per message | 80% of allowance |

At 80%: notification to Org Admin.
At 100%: escalation to Org Admin, usage continues, flagged for manual billing review.
No hard cutoff in v2.2.

---

## 7. LOG RETENTION

| Tier | Content | Storage | Retention |
|------|---------|---------|----------|
| Hot | All operational logs | Supabase | 90 days |
| Cold | Security, user history, billing events | S3-compatible | Indefinite, append-only |

Cold archive triggers: logins, permission changes, outbound messages sent, kill switch changes, escalation resolutions, all billable events.
Archive writes: async — never block user actions.
Archive: append-only — no modification or deletion permitted.
Summary logs: 1 year in hot storage.

---

## 8. CODEBASE CONVENTIONS

- Every function: JSDoc/TSDoc block — purpose, params, return, side effects, @mvp-item tag
- Every new file: entry added to .agent_docs/codebase-index.md in same commit
- Agent Name field: single master field in org settings — propagates to all surfaces
- SMS sender name: truncated to 11 chars from master field
- VAPI caller ID: truncated to 15 chars from master field
- Landing page URL format: nexxus.ai/p/[org-slug] — auto-generated, editable, unique enforced
- Customer outbound rate limit: max 3 messages per customer per 24-hour rolling window across ALL outbound (campaigns + triggers combined)

---

## 9. APPOINTMENT SYNC — SUPPORTED SOURCES (v2.2)

| Source | Method |
|--------|--------|
| Manual entry | Staff creates in Nexxus UI |
| Agent entry | AI agent creates from conversation |
| Google Calendar | OAuth connector — enabled per org |
| Dealer.com | Backend connector — enabled per org |
| Tekion | Backend connector — enabled per org |
| VIN Solutions | NOT SUPPORTED — no calendar sync capability |

All appointments land in internal Nexxus calendar first.
Optional per-user sync out to Google Calendar or Outlook (OAuth — separate sprints).

---

## 10. AGENT SYSTEM PROMPT HIERARCHY

```
Master System Prompt (locked — set by Super Admin, stored in org settings)
  + Hunch Filter (accepted, unresolved hunches only — additive, cannot override master)
  + Session Context (current user, org, role)
  = Effective prompt for inference
```

Hunch Filter performance gate: if context exceeds token limit, oldest resolved hunches dropped first.
Hunch Filter evaluated at inference time only.
