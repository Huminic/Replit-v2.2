# PLAN.md — Nexxus v2.2 Execution Plan
# PURPOSE: Marching orders. Current phase, next steps, status.
# This document does NOT define behavior (see SRS.md) or architecture (see SPEC.md).
# Last updated: 2026-03-04

---

## 1. PROJECT SNAPSHOT

**Current phase:** Pre-flight — governance documents being written
**Overall objective:** Deliver contracted MVP to Serra Auto Group using a wave-based, governed delivery approach
**Customer:** Serra Auto Group (3 dealerships) | Contract: $17,700 upfront + $7,200/month
**Deadline:** 30 days from contract signing
**Outbound status:** DISABLED — kill switch not yet deployed to staging

---

## 2. WAVE STRUCTURE

| Wave | Label | What Ships | Gate to enter |
|------|-------|------------|---------------|
| 0 | Governance | All governance docs locked, pre-flight complete, staging DB live, kill switch deployed | Owner sign-off on pre-flight checklist |
| 1 | Stabilize | Fix pipeline count, fix hosted-pages route, delete dropped nav items (Drive, Custom Agent, Sharing, standalone Artifacts, Skills), **build new navigation shell** (Wouter routing for all 8 sections, modularity toggle, AI Chat sub-items, My Work sub-items, TeamBox sub-items), clean test suite, smoke tests pass | Wave 0 complete |
| 2 | MVP Core | **Sales section built as reference model** (Dashboard, Agents, Insights, Calendar), VAPI lead capture → VIN push, third-party appointment sync, Communications Agent (Sales + Service personas), outbound trigger engine with kill switch, TeamBox Conversations + Workflows | Wave 1 demo approved |
| 3 | MVP Complete | Universal widget + embed codes, CRM Guru agent, advanced chat with history + thinking cards, hosted landing page | Wave 2 demo approved |
| 4 | Service Module | Service dashboard, 5 campaign types, CSV import, two-way conversations → TeamBox, appointment reminders | Wave 3 paid |
| 5 | Billing + RBAC | Metering UI, billing MCP/API, RBAC navigation per expanded roles, Google Ads integration | Wave 4 signed |
| 6 | French Pastry | Studio (Podcasts/Images/Landing Pages/Videos), SEO/AIO under Marketing Insights, competitor intel, sales-coach agents, Personal Assistant (NanoClaw) | Wave 5 stable |

---

## 3. PRE-FLIGHT CHECKLIST — WAVE 0 GATE

All items must be complete and verified before Wave 1 code is written.

### Human Relay Tasks (owner only)
- [ ] H1: Call Durran — confirm pipeline filter definition (provisional: last 14 days, excl. Lost/Sold/Duplicate)
- [ ] H2: Communicate timeline update to Serra honestly
- [ ] H3: Approve governance document package (all 13 files)
- [ ] H4: Create Supabase staging project (requires account access)
- [ ] H5: Deliver DESIGNER_BRIEF.md to designer
- [ ] H6: Obtain designer-approved mockups for all new navigation sections
- [ ] H7: Store approved mockup reference URL in .agent_docs/rules/operational-context.md
- [ ] H8: Audit Claude system-level context for conflicts (active system prompts, loaded memory, tool configs)
- [ ] H9: Verify no .project/ directory conflicts in repo
- [ ] H10: Owner signs off on pre-flight completion — Wave 1 unlocks here

### Agent Tasks (require H3 complete first)
- [ ] A1: Create git branch v2.2 off main
- [ ] A2: Populate .env.staging — verify no production credentials
- [ ] A3: Deploy kill switch migration to staging DB (4 columns, all DEFAULT FALSE)
- [ ] A4: Verify all 4 kill switch channel tests pass on staging
- [ ] A5: Archive competing governance files to docs/archive/ with datestamp
- [ ] A6: Audit and archive .project/ directory if found
- [ ] A7: Lock CLAUDE.md (chmod 444)
- [ ] A8: Lock .agent_docs/acceptance_criteria.md (chmod 444)
- [ ] A9: Install ESLint + Prettier, run clean pass on codebase
- [ ] A10: Initialize .agent_docs/codebase-index.md
- [ ] A11: Initialize .agent_docs/undefined-items.md
- [ ] A12: Verify MEMORY.md integrity
- [ ] A13: Enforcer runs full pre-flight compliance check — all gates must pass

---

## 4. QUALITY GATES — ALL SPRINTS

Every sprint must pass all gates before merge. Enforcer validates.

| Gate | Command | Requirement |
|------|---------|-------------|
| 0 | npm run lint | Zero warnings, zero errors |
| 1 | npm run check | TypeScript zero errors |
| 2 | npm run build | Production build succeeds, dist/ generated |
| 3 | npm run test:env | All env variables and credentials valid |
| 4 | npm run test:smoke | Kill switch tests pass (all 4 channels), critical path tests pass |
| 5 | Enforcer compliance | No dropped-feature references, no prod credentials, CLAUDE.md unchanged |

---

## 5. P0 GAP TRACKER

Items that must be resolved in Wave 1. Each must cite file:path:line when fixed.

| ID | Issue | File | Status |
|----|-------|------|--------|
| P0-01 | Pipeline count inflated — provisional filter active | server/services/vinSolutionsService.ts | OPEN |
| P0-02 | Hosted-pages route mismatch | server/routes/ | OPEN |
| P0-03 | Kill switch missing from all outbound paths | server/services/ | OPEN |
| P0-04 | No staging database | Infrastructure | OPEN — H4 required |
| P0-05 | Competing governance files in root | / | OPEN — A5 required |
| P0-06 | Tests referencing dropped features | tests/ | OPEN |
| P0-07 | .project/ governance conflict if present | / | OPEN — A6 required |
| P0-08 | Navigation shell not yet rebuilt — old nav (Drive, Hub, standalone Artifacts) still in place | client/src/components/nav/ | OPEN — Wave 1 Sprint 1 |
| P0-09 | Wrong sub-items wired for Sales (Campaigns/Conversations) and Management (Reports/Org Settings) | client/src/pages/ | OPEN — Wave 1 Sprint 1 |

---

## 6. FALSE COMPLETION LOG

Items previously marked COMPLETED without evidence. Starting state for Wave 1.

| Item | Claimed by | Why flagged |
|------|-----------|-------------|
| Pipeline count fix | Prior agent session | Count still showing 247 — no file:path:line cited |
| Hosted-pages route fix | Prior agent session | Route still broken — no evidence provided |
| Kill switch implementation | Prior agent session | No DB columns exist — no migration file cited |

---

## 7. INCIDENT LOG

**March 3, 2026 — Unauthorized SMS Blast**
- 82 SMS messages sent to 31 real Serra Auto Group customers
- Cause: AI agent used --dangerously-skip-permissions with no kill switch in place
- Action taken: All outbound disabled immediately
- Rules generated: See CLAUDE.md Section 6 — Prohibited Actions
- Status: Outbound remains disabled until kill switch deployed, tested, and owner explicitly re-enables

---

## 8. DEFERRED ITEMS

Items confirmed out of scope for v2.2 — do not implement without owner written approval.

| Item | Deferred to |
|------|-------------|
| NanoClaw Personal Assistant container | Wave 6 |
| A2P / 10DLC registration | Next version |
| Custom domain for landing page | Wave 6 |
| Credit system and billing markup | Wave 6 |
| Service CRM live integration | Wave 6 |
| Competitor intel | Wave 6 |
| SEO/AIO analysis | Wave 6 |
| Sales Coach / Priority Coach agents | Wave 6 |
| Facebook marketing connector | Post Wave 5 |
| Google Analytics connector | Post Wave 5 |
| Make.com connector | Post Wave 5 |
| Sub-item level RBAC granularity | Post Wave 5 |
| Task auto-escalation logic | Post Wave 3 |
| Hunch auto-generation engine | Wave 4+ |

---

## 9. DEFINITION OF WAVE COMPLETION

A wave is complete when:
1. All sprint acceptance criteria pass with evidence (file:path:line)
2. All quality gates pass (Gates 0–5)
3. Enforcer compliance check passes
4. No open P0 items for this wave
5. Owner reviews wave summary and provides explicit written approval
6. v2.2 branch merged to main
7. PLAN.md updated with completed items and next wave activated
