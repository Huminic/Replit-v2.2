# SRS.md — Nexxus v2.2 System Requirements Specification
# PURPOSE: Formal system behavior document. Defines HOW the system behaves, not what it looks like.
# Audience: Engineers, QA, AI agents.
# This document does NOT define architecture (see SPEC.md) or business strategy (see PRD.md).
# Every requirement is traceable to an AC item in .agent_docs/acceptance_criteria.md.
# Last updated: 2026-03-04

---

## 1. CONVENTIONS

- REQ-##-### = requirement (section-number)
- Each REQ traces to one or more AC items
- Undefined behavior: log to .agent_docs/undefined-items.md and HALT — do not invent
- Evidence format: COMPLETED [timestamp] [file:path:line] [REQ reference]

---

## 2. KILL SWITCH SYSTEM

**REQ-02-001:** The system shall maintain four boolean columns in the organization_settings table:
`outbound_enabled`, `sms_enabled`, `phone_enabled`, `email_enabled`. All default FALSE.

**REQ-02-002:** When `outbound_enabled = FALSE`, no outbound action shall be executed regardless
of channel switch state.

**REQ-02-003:** Channel switches (`sms_enabled`, `phone_enabled`, `email_enabled`) are only evaluated
when `outbound_enabled = TRUE`.

**REQ-02-004:** All kill switch enforcement occurs at the MCP tool layer, not the UI layer.

**REQ-02-005:** When an outbound trigger fires and any applicable kill switch is FALSE, the system
shall create an Unsent Message escalation in TeamBox. The trigger shall NOT be queued.

**REQ-02-006:** Unsent Message escalation fields: org_id, recipient, message_content, trigger_source,
blocked_reason ("kill_switch_off"), timestamp. Multiple same-type blocked triggers within 1 hour
shall be batched into a single escalation with count and individual review option.

**REQ-02-007:** Staff viewing an Unsent Message escalation may choose "Send Now" (blocked again if
kill switch remains OFF) or "Dismiss". Both actions are forensically logged.

---

## 3. OUTBOUND TRIGGER ENGINE

**REQ-03-001:** The trigger engine shall check kill switch state before executing any outbound action.
No outbound shall fire without a kill switch check.

**REQ-03-002:** The trigger engine shall enforce a rate limit: maximum 3 outbound messages per customer
in any rolling 24-hour window, across all campaigns and triggers combined.

**REQ-03-003:** When the rate limit is exceeded, the blocked message shall create an Unsent Message
escalation in TeamBox (not silently dropped, not queued).

**REQ-03-004:** The rate limit default is 3 messages / 24 hours. Configurable by Super Admin.
Org Admin may set a lower limit for their org, but not higher than platform default.

**REQ-03-005:** Each outbound trigger shall log: trigger_id, org_id, customer_id, channel,
message_content, status (sent/blocked), blocked_reason (null if sent), timestamp, campaign_id (if any).

---

## 4. VAPI LEAD CAPTURE

**REQ-04-001:** When an inbound VAPI call completes, the system shall create a lead record using the
VIN Solutions 2-step flow: (a) create contact, (b) create lead with contact href.

**REQ-04-002:** Call transcript shall be attached to the lead record.

**REQ-04-003:** If step 1 (create contact) fails, the system shall: (a) log the failure with full
error response, (b) retain the original VAPI call data, (c) create a VIN Push Failure escalation
in TeamBox with org, failed step, error response, timestamp, and original call data.

**REQ-04-004:** If step 1 succeeds and step 2 (create lead) fails, the system shall: (a) log the failure
with contact href and error response, (b) create a VIN Push Failure escalation with all step 1 and
step 2 data so staff can manually complete the lead.

**REQ-04-005:** Both steps must succeed for the system to consider the lead capture complete.
Silent partial failures are prohibited.

**REQ-04-006:** VIN API header casing must be `v3` (lowercase). Response key is `items`. OAuth token
retrieved per-org from Supabase tokens table via read-only service key.

---

## 5. APPOINTMENT SYNC

**REQ-05-001:** The system shall support these appointment sources for v2.2: manual entry, agent entry,
Google Calendar, Dealer.com, Tekion.

**REQ-05-002:** VIN Solutions is NOT a supported appointment source in v2.2.

**REQ-05-003:** All appointments from any source land in the internal Nexxus calendar first.

**REQ-05-004:** Per-user sync out to Google Calendar or Outlook is optional, requires OAuth per user,
and is implemented as a separate sprint per external calendar provider.

**REQ-05-005:** Appointment creation via agent is subject to confirmation: the agent shall present the
appointment details before creating. Org Admin may configure auto-confirm for trusted agent flows.

---

## 6. UNIVERSAL WIDGET

**REQ-06-001:** The widget shall support four channels: web chat, web call, form, two-way video.

**REQ-06-002:** Each channel is independently toggleable in the widget configuration UI.

**REQ-06-003:** When the two-way video channel is enabled and a customer selects it, a Tavus session
shall be initialized immediately. No pre-load on widget open or page load.

**REQ-06-004:** The widget configuration UI shall produce an embed code for inclusion on external pages.

**REQ-06-005:** Widget behavior (channels enabled, persona name, colors) is configurable per org.

---

## 7. ADVANCED CHAT AND AGENTS

**REQ-07-001:** AI Chat shall display a thinking card when the AI is processing a complex query.

**REQ-07-002:** AI Chat shall maintain persistent chat history per user per session and across sessions.

**REQ-07-003:** The persona name displayed in all AI Chat surfaces shall come from the master Agent Name
field in org settings. If empty, fall back to VAPI configuration.

**REQ-07-004:** Agent Name changes shall propagate to all surfaces within one request cycle.

**REQ-07-005:** Agent Name entry UI shall warn the Org Admin when the name would be truncated on any
surface (SMS: 11 chars, VAPI caller ID: 15 chars).

**REQ-07-006:** CRM Guru shall query VIN Solutions data first. It shall supplement with internal
data warehouse data when relevant. When warehouse data is used, the response must explicitly state this
(e.g., "I found additional data in your internal data warehouse").

**REQ-07-007:** When a general chat query requires CRM data and the user is not in CRM Guru, the system
shall attempt to answer using internal data warehouse first. If insufficient, return the warehouse
answer plus a non-intrusive navigation suggestion to CRM Guru.

**REQ-07-008:** The master system prompt shall not be directly modified by any agent or trigger.
The Hunch Filter is additive only: accepted, unresolved hunches are appended to the effective prompt.
Resolved hunches are removed. If token limit is hit, oldest resolved hunches are dropped first.

---

## 8. HOSTED LANDING PAGE

**REQ-08-001:** Each org shall have a public hosted landing page at `nexxus.ai/p/[org-slug]`.

**REQ-08-002:** Org slug is auto-generated from org name at setup (lowercase, hyphenated).
Slug collisions append a numeric suffix (e.g., `serra-chevrolet-2`).

**REQ-08-003:** Org Admin may edit the slug. Slug changes are forensically logged.

**REQ-08-004:** The landing page embeds the org's video persona (Tavus) and the universal widget.

**REQ-08-005:** The landing page is publicly accessible — no authentication required to view.

---

## 9. METRICS AND DASHBOARD

**REQ-09-001:** Active pipeline definition: leads created in the last 14 days, excluding leads with
status Lost, Sold, or Duplicate. This is the provisional definition — confirm with Durran before Wave 1.

**REQ-09-002:** All metrics shown in the system shall be computed from a single shared query.
The same metric shall display identically across all sections (Sales, Marketing, Insights, etc.).
Section-specific metric overrides are prohibited.

**REQ-09-003:** The AI Chat landing page shall display four summary metrics on load.
These metrics shall be hidden once the user begins chatting.

**REQ-09-004:** Each navigation section that has a dashboard shall show only metrics relevant to
that section's role scope.

---

## 10. TEAMBOX AND ESCALATIONS

**REQ-10-001:** TeamBox shall support three item types: Task, Escalation, and Unsent Message.

**REQ-10-002:** Task assignment is manual only. Tasks may be self-claimed by any TeamBox user.

**REQ-10-003:** Escalations are system-generated items requiring human action. Priority levels:
Critical, High, Medium, Low. Escalation types include: VIN Push Failure, Kill Switch Block,
System Error, Enforcer Violation, MEMORY.md Failure.

**REQ-10-004:** Unsent Message is a specialized escalation type for outbound triggers blocked by
the kill switch or rate limit. Fields defined in REQ-02-006.

**REQ-10-005:** When a new Task is created, all users with TeamBox access in the org are notified.

**REQ-10-006 [SERVICE MODULE]:** When an active campaign conversation receives a message, staff may click to take over.
Clicking "Take over" navigates to the appropriate thread in TeamBox.

**REQ-10-007 [SERVICE MODULE]:** A "Stop outbound" button per campaign prevents further outbound for that campaign
without affecting the org-level kill switch.

---

## 11. RBAC AND NAVIGATION

**REQ-11-001:** All users have AI Chat and My Work access by default.

AI Chat sub-items: Favorites, Chat History, Artifacts (data reports only — no sharing).
My Work sub-items: Assistant (placeholder — Wave 6), Dashboard, Tasks, Chat.

**REQ-11-002:** TeamBox, Sales, Service, Marketing, and Management sections require explicit
Org Admin grant per user in v2.2. Granularity is at the section level (not sub-item).

**REQ-11-003:** Navigation visibility requires two conditions both true: (a) module is enabled at
platform level by Super Admin, (b) section access is granted by Org Admin to the user.

**REQ-11-004:** A module that is enabled but not yet built shall display a "Coming Soon" label in navigation.
A module that is disabled shall be completely absent from navigation — no stub.

**REQ-11-006:** Navigation section sub-item structure (locked):

| Section | Sub-items |
|---------|----------|
| AI Chat | Favorites, Chat History, Artifacts |
| My Work | Assistant, Dashboard, Tasks, Chat |
| TeamBox | Tasks, Conversations, Workflows |
| Sales | Dashboard, Agents, Insights, Calendar |
| Service | Dashboard, Agents, Campaigns, Insights, Calendar |
| Marketing | Dashboard, Agents, Campaigns, Studio, Insights |
| Management | Dashboard, Insights, Hunches, Activities, ROI |
| System | Users, Billing, Integrations, Kill Switch |

**REQ-11-007:** Sales is the reference model section. All existing dashboard and insights
components are built under Sales first. Service, Marketing, and Management extract their relevant
subset from the Sales pattern. No duplicate dashboard architectures — extract and scope from source.

**REQ-11-008:** TeamBox → Conversations holds all agent-to-customer conversations regardless
of which agent or channel initiated them. Conversations are segmented in the sub-popup by:
agent, channel (SMS/voice/chat/video), and status (active/claimed/closed). When staff take over
a conversation from a campaign or agent, they are routed to TeamBox → Conversations.

**REQ-11-009:** Artifacts under AI Chat are scoped to downloadable data reports only.
No file upload analysis, no sharing, no Drive storage. The v2.1 standalone Artifacts section
(with sharing capability) is removed and not replaced — this scoped version is its replacement.

**REQ-11-005:** Usage data (event counts and volumes only — no dollar amounts) is visible to
Org Admin, Partner Admin, and Super Admin. Org Admin sees their org only. Partner Admin sees their
orgs. Super Admin sees all orgs.

---

## 12. METERING AND BILLING API

**REQ-12-001:** All billable events (see SPEC.md Section 6) shall be logged regardless of package tier.

**REQ-12-002:** Each org has a package definition in the database specifying allowances per event type.

**REQ-12-003:** At 80% of any allowance, an automated notification is sent to Org Admin.

**REQ-12-004:** At 100% of any allowance, an escalation is created in TeamBox. Usage continues.
No hard cutoff in v2.2.

**REQ-12-005:** The billing API shall expose usage data and invoice generation via MCP tools
(`billing_get_usage`, `billing_create_invoice`) for consumption by external systems (e.g., QuickBooks).

**REQ-12-006:** The billing API uses a pull architecture: Nexxus exposes usage data;
external systems pull via the MCP connector.

---

## 13. FORENSIC LOGGING — FULL AUDIT TRAIL

**REQ-13-001:** The system shall log all user actions at C (full audit trail level):
all outbound sent/blocked, all agent actions, all user logins, all configuration changes,
all permission changes, all file uploads, all campaign events, all escalation resolutions.

**REQ-13-002:** Every log entry shall include: actor (user_id or agent_id), action, resource,
timestamp, org_id, outcome, and IP address (for user actions).

**REQ-13-003:** Security events (logins, permission changes, outbound messages, kill switch changes,
escalation resolutions) shall be archived to cold storage (S3-compatible) in append-only format.

**REQ-13-004:** Log writes to cold storage shall be asynchronous — they shall never block user actions.

---

## 14. ENFORCER AGENT BEHAVIOR

**REQ-14-001:** The Enforcer agent shall run a compliance check on every git merge attempt before
the merge is allowed.

**REQ-14-002:** Enforcer compliance check must verify: (a) TypeScript zero errors, (b) production
build succeeds, (c) all kill switch tests pass, (d) no references to dropped features, (e) no
production credentials in any file, (f) CLAUDE.md is unchanged from its locked state, (g) all
new functions have JSDoc/TSDoc blocks, (h) all new files have codebase-index.md entries.

**REQ-14-003:** Any compliance check failure shall: (a) block the merge, (b) log the violation
with agent, file path, timestamp, and session ID, (c) create an Enforcer Violation escalation
in TeamBox, (d) halt the agent session.

**REQ-14-004:** The Enforcer is read-only except for its compliance log file.
Path: `.agent_docs/rules/agent-roles.md` (log section only).

---

## 15. DEFINITION BOUNDARY — DO NOT INVENT RULE

**REQ-15-001:** If any agent encounters a behavior, value, field, or flow that is not defined in
CLAUDE.md, SPEC.md, SRS.md, acceptance_criteria.md, or the current sprint definition,
the agent shall: (a) STOP work on that item, (b) log the undefined item to
`.agent_docs/undefined-items.md` with: file, line, undefined item description, assumed behavior,
(c) surface the item to the owner before proceeding.

**REQ-15-002:** Undefined items shall not be invented, guessed, or defaulted silently.
Each undefined item requires an explicit owner decision before implementation proceeds.

---

## 16. MEMORY.MD INTEGRITY

**REQ-16-001:** Scribe agent shall verify MEMORY.md integrity at session start:
file exists, is not empty, contains a parseable timestamp, and conforms to schema.

**REQ-16-002:** On integrity failure, Scribe shall halt and create a Critical escalation in TeamBox.
No session proceeds until the owner resolves the MEMORY.md failure.

**REQ-16-003:** After each session, Scribe archives the current MEMORY.md to MEMORY.md.bak.
Only one backup is retained (overwritten each session).

---

## 17. CODE INTELLIGENCE SYSTEM

**REQ-17-001:** Every new function or component shall include a JSDoc/TSDoc block containing:
purpose, parameters, return value, side effects, and `@mvp-item` tag referencing the AC item.

**REQ-17-002:** Every new file shall have an entry added to `.agent_docs/codebase-index.md`
in the same commit as the file. Entry fields: file path, purpose, key dependencies, wave/sprint origin.

**REQ-17-003:** Linting (ESLint strict TypeScript) and formatting (Prettier) shall pass with zero
warnings before any commit. Linting is Gate 0 in the quality gate sequence.
