# CLAUDE.md — Nexxus v2.2 Agent Governance
# VERSION: 2.2.0 | LOCKED: chmod 444 after deployment
# READ THIS ENTIRE FILE BEFORE TOUCHING ANYTHING.

---

## 1. TRUTH HIERARCHY

When any two sources conflict, the higher tier wins. No exceptions.

| Tier | Source | Authority |
|------|--------|-----------|
| T1 | Approved UI mockups | Highest — designer approved, stored in operational-context.md |
| T2 | CLAUDE.md (this file) | Agent governance — cannot be modified by any agent |
| T3 | SPEC.md | Architecture facts |
| T4 | SRS.md | Formal system behavior |
| T5 | .agent_docs/acceptance_criteria.md | Testable contract |
| T6 | PLAN.md | Execution sequence |
| T7 | All other files | Subordinate |

---

## 2. SESSION CHECKLIST — RUN BEFORE TOUCHING ANYTHING

- [ ] Read CLAUDE.md in full
- [ ] Read current wave spec in PLAN.md
- [ ] Check .agent_docs/undefined-items.md — resolve owner-answered items, halt on open items
- [ ] Check MEMORY.md integrity (Scribe: file exists, not empty, timestamp parseable)
- [ ] Confirm autonomy level for this session (L1–L4)
- [ ] Confirm declared file scope for this session
- [ ] Verify .env.staging is active — never .env.production
- [ ] Verify kill switch: outbound_enabled = FALSE in staging DB before any outbound test
- [ ] Confirm no .project/ directory exists — if found, halt and alert owner

---

## 3. GOVERNANCE FILE MAP

| File | Purpose | Modifiable by |
|------|---------|---------------|
| CLAUDE.md | Agent rules | Owner only, chmod 444 |
| PRD.md | Strategy and business framing | Owner only |
| SRS.md | Formal system behavior | Owner + Architect |
| SPEC.md | Architecture facts | Owner + Architect |
| PLAN.md | Wave execution, P0 tracker | Owner + Scribe |
| DESIGNER_BRIEF.md | UI handoff | Owner + Designer |
| DO_NOT_TOUCH.md | Off-limits list | Owner only |
| MEMORY.md | Session memory | Scribe only |
| .agent_docs/acceptance_criteria.md | Testable contract | Owner only, chmod 444 |
| .agent_docs/undefined-items.md | Undefined behavior log | All agents (append only) |
| .agent_docs/codebase-index.md | Live codebase map | Scribe only |
| .agent_docs/rules/*.md | Conditional context | Owner + Architect |

---

## 4. DEVELOPMENT WORKFLOW

### Work Loop
1. Read session checklist (Section 2) — complete every item
2. Read current sprint definition in PLAN.md
3. Implement only what is defined in current sprint
4. Run all quality gates before marking anything complete
5. Update codebase-index.md via Scribe before committing
6. No task is COMPLETED without evidence: `COMPLETED [timestamp] [file:path:line] [description]`
7. Submit for Enforcer review before merge

### Stop Conditions — HALT IMMEDIATELY AND NOTIFY OWNER
- Any file outside declared scope would be modified
- CLAUDE.md has been modified by any agent
- Kill switch check is absent from any outbound code path
- Production credentials detected in any file
- Undefined behavior encountered (log to undefined-items.md first)
- MEMORY.md integrity check fails
- .project/ directory found or recreated
- --dangerously-skip-permissions used without L4 written approval
- Enforcer compliance check fails
- Previously passing test now fails (regression — do not fix without owner instruction)

---

## 5. ARCHITECTURE FACTS

- Stack: Vite + React 18 + Wouter | Node 20 + Express 5 | Supabase PostgreSQL | Drizzle ORM
- Port: 5020 (production) | 5021 (staging)
- PM2: nexxus-v2 (prod) | nexxus-v2-staging (staging)
- Branch: v2.2 off main — merge to main per approved wave only
- All external calls via central-mcp proxy — no direct API calls from application code
- Kill switch DB columns: outbound_enabled, sms_enabled, phone_enabled, email_enabled (all BOOLEAN DEFAULT FALSE)
- Kill switch enforced at MCP layer — master overrides all channels
- VIN Solutions: header casing v3 not V3 | items not results | 2-step lead creation | OAuth per-org in Supabase
- TextMagic: SMS only | credentials from DB per org | 11-char sender name limit
- VAPI: voice calls | 15-char caller ID limit | persona name from master Agent Name field
- Tavus: video sessions | session init on customer click | no pre-load
- Staging DB: synthetic data only — never production data, never real phone numbers

---

## 6. PROHIBITED ACTIONS

- Do NOT use --dangerously-skip-permissions without written L4 approval from owner this session
- Do NOT access production database — staging only
- Do NOT send any outbound (SMS, call, email) without kill switch = TRUE in DB
- Do NOT modify CLAUDE.md, DO_NOT_TOUCH.md, or acceptance_criteria.md
- Do NOT invent undefined behavior — log to undefined-items.md and halt that task
- Do NOT mark COMPLETED without file:path:line evidence
- Do NOT run /init-project, /init-template, or any script generating .project/
- Do NOT queue outbound triggers — blocked triggers become Unsent Message escalations
- Do NOT merge without Enforcer sign-off
- Do NOT modify files outside declared session scope
- Do NOT add features not in current sprint definition
- Do NOT alter the master system prompt — Hunch Filter is additive only
- Triggers blocked by kill switch → Unsent Message escalation in TeamBox, never queued

### Autonomy Levels
- L1 Read Only: no writes — default for research sessions
- L2 Scoped Write: writes only to declared scope list — declare at session start
- L3 Wave Scoped: writes within owner-approved wave boundaries only
- L4 Full Autonomy: owner types approval phrase fresh at session start — logged with timestamp

---

## 7. VOCABULARY — NAMING RULES

- Agent name: use master Agent Name field from org settings — never "Automa"
- Persona: store-named AI identity (e.g., Alex — Serra Chevrolet)
- Wave: high-level delivery chapter (Wave 0 through Wave 6)
- Phase: subdivision of a wave
- Sprint: subdivision of a phase — the unit of work
- Escalation: a system-generated TeamBox item requiring human action
- Kill switch: master outbound_enabled flag — governs all outbound
- MCP: Model Context Protocol proxy — all external calls route through central-mcp
- Above the line: feature and function decisions (what users experience)
- Below the line: architecture and engineering decisions (how it is built)
- COMPLETED: only valid with timestamp + file:path:line + description
