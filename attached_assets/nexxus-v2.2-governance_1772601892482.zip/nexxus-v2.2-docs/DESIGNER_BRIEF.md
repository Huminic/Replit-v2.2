# DESIGNER_BRIEF.md — Nexxus v2.2 UI & Design Handoff
# PURPOSE: Complete design specification for the UI designer.
# Audience: UI/UX designer. Covers navigation, layout patterns, new components, branding rules.
# Mockup URL: [stored in .agent_docs/rules/operational-context.md after delivery]
# Last updated: 2026-03-04

---

## 1. BRAND RULES

- The platform is called **Nexxus**
- Customer-facing agent persona name is set per org (e.g., "Alex — Serra Chevrolet")
- Use the master Agent Name everywhere — never use "Automa" as a fallback
- Color system, typography, and logo: reference existing v2.1 brand guide (stored separately)
- All new components should extend — not break — the existing visual system

---

## 2. NAVIGATION — CURRENT vs PROPOSED

### v2.1 Navigation (to be removed)
- Main
- Insights
- Agents
- Hub
- Drive ← **REMOVE entirely**
- System

### v2.2 Navigation (to replace it)

| Section | Sub-items | Default | Notes |
|---------|-----------|---------|-------|
| AI Chat | Favorites, Chat History, Artifacts | Always visible | Pattern A on home; sub-items in left drawer |
| My Work | Assistant, Dashboard, Tasks, Chat | Always visible | Pattern C; Assistant = PA placeholder (Wave 6) |
| TeamBox | Tasks, Conversations, Workflows | Requires grant | Pattern C; all three are sub-popup segments |
| Sales | Dashboard, Agents, Insights, Calendar | Requires grant | Pattern C; **reference model** — all existing dashboard/insights live here first |
| Service | Dashboard, Agents, Campaigns, Insights, Calendar | Requires grant + Service Module | Pattern C; extracted from Sales model |
| Marketing | Dashboard, Agents, Campaigns, Studio, Insights | Requires grant | Pattern C; extracted from Sales model |
| → Studio | Podcasts, Images, Landing Pages, Videos | Sub-section of Marketing | "Coming Soon" in v2.2 |
| Management | Dashboard, Insights, Hunches, Activities, ROI | Requires grant | Pattern C; Hunches = "Coming Soon" in v2.2; extracted from Sales model |
| System | Users, Billing, Integrations, Kill Switch | Admin roles only | Pattern C |

**Modularity rule:**
- Module enabled + built → fully functional, appears in nav
- Module enabled + not built → "Coming Soon" label in nav (light badge or label, not a blocking overlay)
- Module disabled → completely absent from nav, no stub

**Always-visible:** AI Chat and My Work for all users.
**Globe icon in header:** links to the org's public hosted landing page (nexxus.ai/p/[org-slug]).

**Sales is the reference model section.** All existing dashboard and insights features are built
under Sales first. Service, Marketing, and Management extract the relevant subset of that pattern
for their own sections. Do not build separate dashboard architectures — extract from Sales.

**Artifacts under AI Chat (not a standalone section):** Artifacts exist only as a sub-item under
AI Chat. Scope is limited to downloadable data reports — no sharing, no Drive storage, no upload
analysis. The v2.1 Artifacts standalone section is removed; this scoped version is its replacement.

**TeamBox conversation layout:** Conversations are segmented by source/type in the left-column
sub-popup (e.g., by agent, by channel, by status). Use commBox as a layout reference — three-column
with the third column as a modal or side panel, not a permanent fourth column.

---

## 3. LAYOUT PATTERNS

Three layout patterns govern all pages in the system.

### Pattern A — Full-screen chat
- Used by: AI Chat home page ONLY
- Layout: chat interface fills the entire viewport
- The four summary metrics are shown on load above or around the input; they collapse/hide once the
  user begins typing or sends a message
- No sidebar, no persistent header content beyond logo + avatar

### Pattern B — Agent-centered
- Used by: Agent configuration pages (Communications Agent, CRM Guru, etc.)
- Layout: chat interface centered (60% width), right pane (40%) shows agent config and data
- The right pane shows: agent description, active settings, and the globe icon linking to landing page
- "Coming Soon" agents use the same layout with a status indicator instead of a live config panel

### Pattern C — Content-centered with chat
- Used by: ALL other pages (dashboards, insights, campaigns, settings, TeamBox, My Work, etc.)
- Layout: main content area (70%) on left, persistent chat drawer (30%) on right
- Chat is available but not the primary focus
- Chat drawer can collapse to an icon if the user needs full width

---

## 4. NEW COMPONENTS REQUIRED

### 4.1 Escalation Card (TeamBox)
- Three types: Task, Escalation, Unsent Message — each needs a distinct visual treatment
- Priority badges: Critical (red), High (orange), Medium (yellow), Low (grey)
- Escalation-specific fields: blocked_reason, trigger_source
- Unsent Message specific: "Send Now" button (disabled if kill switch is still OFF), "Dismiss" button
- Escalation types displayed as pills or badges: VIN Push Failure, Kill Switch Block, System Error, etc.

### 4.2 Kill Switch Controls (System → Kill Switch page)
- Master toggle: large, prominent, labeled "All Outbound" — clearly shows ON/OFF state
- Channel toggles below master: SMS, Phone Calls, Emails — greyed out when master is OFF
- Visual hierarchy must make it immediately obvious when master is OFF (e.g., warning bar, red tint)
- Change confirmation modal: "You are enabling outbound. This will allow the system to send real
  messages to real customers. Confirm?" — cannot be bypassed

### 4.3 Widget Configuration UI (Org Settings → Widget)
- Four channel toggles: Web Chat, Web Call, Form, Two-Way Video
- Per-channel customization: label text, button color, icon
- Persona name field (links to master Agent Name field — shows a sync indicator)
- Embed code panel: generated code with copy button, preview link
- Live preview of widget bubble as channels are toggled

### 4.4 Hosted Landing Page Template
- Public page at nexxus.ai/p/[org-slug]
- Full-screen or hero-section Tavus video embed on load
- Widget bubble in bottom-right corner
- Org name and Agent Name visible
- No Nexxus branding on the customer-facing page (white-label)
- Slug editor in Org Settings: current slug shown, edit field, uniqueness validation, save button

### 4.5 Unsent Messages Escalation (campaign "Stop Outbound" button)
- Per-campaign toggle in campaign detail view: "Outbound active / Stopped" — distinct from kill switch
- Visual indicator on campaign card when outbound is stopped for that campaign

### 4.6 Metering / Usage Display
- Available to Org Admin, Partner Admin, Super Admin
- Simple table or tile view: event type, allowance, used, remaining, % bar
- No dollar amounts displayed
- Period selector: current billing period, last 30 days, custom range
- "Export usage" button

### 4.7 My Work → Dashboard Tiles
- Four tiles matching the AI Chat landing metrics
- Task summary with count and priority breakdown
- Upcoming appointments summary

### 4.8 Hunch Card (AI Chat)
- Appears in the chat response stream when the AI generates a hunch
- Two actions: "Accept" (promotes to TeamBox task) and "Dismiss"
- Hunch payload shown: headline, supporting data reference, proposed task description
- Accepted hunches appear as a small banner in subsequent chats: "[N] accepted hunches are influencing
  this conversation"

---

## 5. AI CHAT LANDING PAGE (Pattern A detail)

- Four metrics shown on load:
  1. Active pipeline count (leads in last 14 days, excl. Lost/Sold/Duplicate)
  2. Appointments today
  3. Open escalations
  4. Outbound sent (last 24 hours)
- Metrics animate in then fade/collapse on first keypress or send
- Prominent chat input centered, with persona greeting ("Hi, I'm Alex — how can I help today?")
- No navigation clutter — clean single-focus view

---

## 6. NAVIGATION DELTA TABLE

| Item | v2.1 state | v2.2 action | Notes |
|------|-----------|------------|-------|
| Drive | Exists | REMOVE | No replacement |
| Custom Agent | Exists | REMOVE | No replacement |
| Sharing | Exists | REMOVE | No replacement |
| Artifacts (standalone) | Exists | SCOPE + RELOCATE | Moved to AI Chat sub-nav; data reports only; no sharing |
| Skills (global) | Exists | REMOVE | Skills exist only inside PA/NanoClaw — Wave 6 |
| AI Chat | Exists | KEEP + redesign | Pattern A home; sub-items: Favorites, Chat History, Artifacts |
| Insights | Exists | MERGE into sections | Each section has its own Insights sub-item; Sales is the source |
| Agents | Exists | MODIFY | Becomes sub-item of each section (Sales, Service, Marketing, Management) |
| Hub | Exists | RENAME + SPLIT | Becomes TeamBox with sub-items: Tasks, Conversations, Workflows |
| TeamBox | New | BUILD | Sub-items: Tasks, Conversations (all agent conversations), Workflows |
| My Work | New | BUILD | Sub-items: Assistant, Dashboard, Tasks, Chat |
| Sales | New | BUILD | Sub-items: Dashboard, Agents, Insights, Calendar — **reference model** |
| Service | New | BUILD | Sub-items: Dashboard, Agents, Campaigns, Insights, Calendar |
| Marketing | New | BUILD | Sub-items: Dashboard, Agents, Campaigns, Studio, Insights |
| Management | New | BUILD | Sub-items: Dashboard, Insights, Hunches (Coming Soon), Activities, ROI |
| System | Exists | MODIFY | Sub-items: Users, Billing, Integrations, Kill Switch |

---

## 7. RESPONSIVE AND ACCESSIBILITY

- All layouts must be responsive to 1024px minimum width (desktop SaaS application)
- Mobile view: Pattern C chat drawer collapses to floating button
- Accessibility: WCAG AA minimum — all interactive elements keyboard-navigable

---

## 8. DELIVERABLES REQUESTED FROM DESIGNER

1. **Navigation shell mockup** — all sections visible (maximum enabled state) + collapsed state
2. **Pattern A** — AI Chat landing page with 4 metric tiles and persona greeting
3. **Pattern B** — Agent configuration page (Communications Agent as example)
4. **Pattern C** — Sales Dashboard as primary example (reference model); Service → Campaigns as second example
5. **Kill Switch page** — master + channel toggles + confirmation modal
6. **Widget configuration UI** — with live preview panel
7. **Hosted landing page template** — nexxus.ai/p/[org-slug] public view
8. **Escalation card variants** — Task, Escalation, Unsent Message in all priority states
9. **Hunch card** — in-chat appearance + accepted state banner
10. **Metering / usage tiles** — Org Admin view

**Format:** Figma preferred. Deliver component library alongside page mockups.
**Store approved mockup URL in:** `.agent_docs/rules/operational-context.md`
