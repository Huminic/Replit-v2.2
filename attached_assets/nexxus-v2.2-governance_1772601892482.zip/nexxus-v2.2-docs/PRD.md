# PRD.md — Nexxus v2.2 Product Requirements Document
# PURPOSE: Plain-language strategy document for stakeholders and owners.
# Audience: Business owners, project sponsors, non-technical stakeholders.
# This document defines WHAT and WHY. HOW is in SRS.md and SPEC.md.
# Last updated: 2026-03-04

---

## 1. EXECUTIVE SUMMARY

Nexxus v2.2 is a reset of the Nexxus platform focused on delivering the contracted MVP to Serra Auto Group
before adding new features. The March 3 incident (82 unauthorized SMS messages to real customers) created
an urgent need for governance, a kill switch, and controlled delivery. This document defines what we are
building, why, and in what order.

**Customer:** Serra Auto Group (3 dealerships)
**Contract value:** $17,700 upfront + $7,200/month
**Primary contact:** Durran (Serra)
**Delivery approach:** Wave-based sprints, each requiring owner sign-off before the next begins

---

## 2. PROBLEM STATEMENT

The current platform has several critical gaps:

1. **Inflated metrics** — the active pipeline count shows 247 but this is incorrect. There is no defined
   filter for what "active" means, so all leads are counted regardless of age or status.

2. **No outbound safety controls** — outbound messages (SMS, calls, emails) can fire without any
   authorization check. This caused the March 3 incident.

3. **Incomplete MVP** — the contracted feature set (10 functions) is only partially built. Some claimed
   completions were never verified with evidence.

4. **Feature sprawl** — non-contracted features were added speculatively, creating complexity and
   maintenance burden without delivering contracted value.

5. **No governance layer** — no single source of truth for what is in scope, no audit trail of decisions,
   and no enforced boundaries on agent actions.

---

## 3. GOALS

| ID | Goal | Measure of Success |
|----|------|--------------------|
| G1 | Deliver contracted MVP to Serra | All 10 MVP functions pass acceptance criteria |
| G2 | Prevent recurrence of March 3 incident | Kill switch deployed, tested, and in place before any outbound code runs |
| G3 | Establish a single source of truth | All decisions traceable to locked governance documents |
| G4 | Ship incrementally with owner control | No wave begins without owner sign-off |
| G5 | Build a sustainable delivery rhythm | Each wave complete with evidence, no silent failures |

---

## 4. CONTRACTED MVP — 10 REQUIRED FUNCTIONS

These 10 items are the contractual deliverable. Nothing else ships before all 10 are complete.

| # | Function | Plain-language description |
|---|----------|-----------------------------|
| 1 | Accurate metrics and insights | Dashboard shows correct numbers. Active pipeline = leads created in last 14 days, excluding Lost/Sold/Duplicate. Verified with Durran before locking. |
| 2 | Voice lead capture | Incoming VAPI calls are captured as leads, transcription attached, pushed to VIN Solutions via 2-step flow. Failed pushes create escalations in TeamBox. |
| 3 | Third-party appointment sync | Appointments created via Google Calendar, Dealer.com, and Tekion connectors appear in the Nexxus calendar automatically. Manual and agent entry also supported. |
| 4 | Universal widget | Web chat, web call, form, and two-way video channels. Configurable per org. Embed code available. Video launches immediately when selected by customer. |
| 5 | Outbound trigger engine | Automated SMS, phone calls, and emails triggered by data events. All outbound gated by master kill switch and per-channel switches. Blocked triggers create escalations, never queue. |
| 6 | Advanced AI chat | Claude-level conversation with thinking cards, report generation, and persistent history. Persona name propagates from org Agent Name field. |
| 7 | CRM Guru agent | Data-query interface. Queries VIN Solutions first, supplements with internal data warehouse, cites source when warehouse data is used. |
| 8 | Customer experience view | Customer-facing interface showing the universal widget and (if enabled) the two-way video persona. Accessible via globe icon in header. |
| 9 | Hosted landing page | Public page at nexxus.ai/p/[org-slug] embedding the video persona and the widget. Slug auto-generated, editable by Org Admin. |
| 10 | Metering and usage | Usage events counted per org. Usage visible to Org Admin and above (no dollar amounts in v2.2). Billing MCP API exposes data to external systems (e.g., QuickBooks). |

---

## 5. SERVICE MODULE — PAID ADD-ON

Available as a paid upgrade after the 10 MVP functions are delivered.

- Service dashboard with relevant KPIs
- Five campaign types: appointment reminder, follow-up, service due, no-show, declined service
- CSV-based customer import with deduplication (one active campaign type per customer)
- Two-way conversation: if agent chat is in progress, staff can claim it in TeamBox
- "Stop all" toggle per campaign: prevent outbound for a campaign without disabling the entire kill switch
- Lead source performance reporting under Marketing
- Rate limit: maximum 3 messages per customer in any 24-hour rolling window across all campaigns

---

## 6. DROPPED FEATURES — NOT BUILDING IN v2.2

The following features were speculated on or partially built. They are not in the contract and will not
be shipped in v2.2. Remove all references from the codebase.

- Drive (file storage)
- Custom Agent builder
- Sharing / Artifacts
- Skills (outside Personal Assistant)
- System-wide dealer brain
- Email inbox (two-way email — outbound only in v2.2)
- File upload analysis
- Any UI referencing these features

---

## 7. DEFERRED FEATURES — FRENCH PASTRY

These features are architecturally planned but will not be built in v2.2. They appear as "Coming Soon"
if the module is enabled in admin UI, or are hidden if the module is disabled.

| Feature | Target wave |
|---------|-------------|
| Studio (Podcasts, Images, Landing Pages, Videos) | Wave 6 |
| SEO / AIO analysis under Marketing Insights | Wave 6 |
| Competitor intel | Wave 6 |
| Sales Coach / Priority Coach agents | Wave 6 |
| Personal Assistant with NanoClaw container | Wave 6 |
| Management Agent | Wave 6 |

---

## 8. NAVIGATION — HIGH LEVEL

Proposed v2.2 navigation (modular — sections hidden if disabled or not granted):

| Section | Sub-items | Default | Requires grant |
|---------|-----------|---------|----------------|
| AI Chat | Favorites, Chat History, Artifacts | Always visible | No |
| My Work | Assistant, Dashboard, Tasks, Chat | Always visible | No |
| TeamBox | Tasks, Conversations, Workflows | Hidden | Org Admin grant |
| Sales | Dashboard, Agents, Insights, Calendar | Hidden | Org Admin grant |
| Service | Dashboard, Agents, Campaigns, Insights, Calendar | Hidden | Org Admin grant + Service Module |
| Marketing | Dashboard, Agents, Campaigns, Studio, Insights | Hidden | Org Admin grant |
| Management | Dashboard, Insights, Hunches, Activities, ROI | Hidden | Org Admin grant |
| System | Users, Billing, Integrations, Kill Switch | Hidden | Admin roles only |

**Sales is the reference model section.** All existing dashboard and insights are built under
Sales first. Service, Marketing, and Management extract their relevant subset from that pattern.

**Artifacts:** Scoped to downloadable data reports only. Lives under AI Chat sub-nav.
The v2.1 standalone Artifacts section (with sharing) is removed. No Drive, no upload analysis.

**TeamBox Conversations:** All agent-to-customer conversations land in TeamBox → Conversations,
segmented by agent, channel, and status in the sub-popup column.

---

## 9. STAKEHOLDER RESPONSIBILITIES

| Stakeholder | Responsibility |
|-------------|---------------|
| Owner (Duane) | Sign off on each wave, approve governance docs, communicate with Serra, make architectural decisions |
| Durran (Serra) | Confirm pipeline filter definition, approve each wave demo |
| Designer | Produce mockups from DESIGNER_BRIEF.md before Wave 2 code begins |
| Development team | Implement per sprint specs, pass all quality gates, follow CLAUDE.md |
| Agent team | Operate within autonomy levels, stop on undefined items, submit to Enforcer |

---

## 10. SUCCESS CRITERIA

v2.2 is successful when:
1. All 10 contracted MVP functions pass acceptance criteria with evidence
2. The March 3 incident cannot recur (kill switch tested and operational)
3. Serra Auto Group demos and approves each wave
4. All decisions are traceable to governance documents
5. The platform is ready to add the Service Module without rework
