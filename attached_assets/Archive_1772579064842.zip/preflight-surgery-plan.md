# Pre-Flight Surgery Plan

**Created:** 2026-03-02
**Author:** Workbench session (orchestrator + owner collaboration)
**Purpose:** Prepare nexxus-v2 for a clean context reset with correct, complete governance files
**Timeline:** ~1 week
**Status:** APPROVED — ready to execute

---

## Overview

The nexxus-v2 project is ~75-80% built but accumulated file sprawl, tainted test results, ghost blockers, and architectural misunderstandings across prior sessions. This plan performs surgery on the development environment and governance files before handing off to a fresh nexxus-v2 agent context.

**Core workflow being restored:** PLAN.md (gaps) → test batteries → PLAN.md (update) → loop → launch

**Work location:** Sidekick/workbench prepares everything. Nexxus-v2 agent receives finalized files and executes the build.

---

## Governance File Target (6 files at nexxus-v2 root)

| File | Purpose | Read frequency |
|------|---------|----------------|
| CLAUDE.md | Agent rules, truth hierarchy, conventions | Every session |
| PRD.md | Plain language: what the product does, why, for whom | Reference when needed |
| SRS.md | Technical narrative: system behavior above + below the line | Reference when needed |
| SPEC.md | Architecture: services, routes, DB, how things connect | When agent needs arch context |
| PLAN.md | Marching orders: current phase, priorities, gap status | Every session |
| ACCEPTANCE_CRITERIA.md | Testable statements per feature (mirrors test battery) | When testing |

Supporting structures (unchanged):
- `.agent_docs/` — enforcer workspace (stays, may need tweaks)
- `.claude/agents/enforcer.md` — enforcer definition (stays)
- `.project/` — gutted, reserved for `/plan` mode scratch only

---

## Quality Control Pipeline

Every analysis step uses independent parallel agents to prevent bias and catch errors.

### Wave Analysis Quality Gate
```
Source files
    ├──→ Analyst agent (extracts findings for wave theme)
    └──→ Reviewer agent (independent extraction, same files, no analyst access)
              ↓
    Orchestrator merges both outputs, flags disagreements
              ↓
    Owner reviews, resolves conflicts
              ↓
    Wave output locked
```

### Ground Truth Diff Quality Gate
```
Wave output + codebase + existing claims
    ├──→ Diff agent A (wave output vs actual code)
    └──→ Diff agent B (wave output vs existing gap/blocker claims)
              ↓
    Orchestrator reconciles, produces unified gap list
              ↓
    Owner reviews, adds enhancements
              ↓
    Re-run diff incorporating owner additions
              ↓
    Final validated gap list locked
```

### Governance File Drafting Quality Gate
```
Orchestrator drafts file from reconciled notes + agreed outline
              ↓
Verifier agent checks every claim against source files
(reads draft + sources only, NOT wave notes — independent verification)
              ↓
Orchestrator incorporates verifier findings
              ↓
Owner reviews, corrections and enhancements
              ↓
Orchestrator updates draft with owner feedback
              ↓
Owner confirms final version
              ↓
File locked
```

**Key principle:** Analyst and reviewer never see each other's work. Verifier never sees wave notes. Independence prevents groupthink and assumption propagation.

---

## Phase 1: Setup

**Steps:**
1. Write surgery plan to disk (this file)
2. Write all session findings to disk (knowledge not yet persisted)
3. Owner uploads additional input files to workbench
4. Build file inventory — every input file with one-line description
5. Owner reviews inventory, flags anything missing or miscategorized

**Acceptance Criteria:**
- [ ] All input files inventoried with descriptions
- [ ] No known source files missing from inventory
- [ ] Owner confirms inventory is complete
- [ ] All session knowledge persisted to disk

---

## Phase 2: Wave Analysis

Each wave scans source files through a specific lens, extracting information relevant to one governance file. Files are read once; extractions are tagged by wave.

**Steps:**
6. Wave 1 — Business Context → PRD input notes → conflicts to owner → reconcile
7. Wave 2 — System Behavior → SRS input notes → conflicts to owner → reconcile
8. Wave 3 — Architecture → SPEC input notes → conflicts to owner → reconcile
9. Wave 4 — Testable Outcomes → AC input notes → conflicts to owner → reconcile
10. Wave 5 — Current State → PLAN input notes → conflicts to owner → reconcile
11. Wave 6 — Agent Rules → CLAUDE.md input notes → conflicts to owner → reconcile

**Per-wave process:**
- Analyst + Reviewer agents scan source files in parallel (independent, no shared output)
- Orchestrator merges, flags disagreements and conflicts
- Conflict log updated with "Document A says X, Document B says Y"
- "Not found" log updated with expected info that wasn't in any file
- Owner resolves conflicts and answers questions
- Wave output notes finalized and locked

**Acceptance Criteria:**
- [ ] All source files scanned exactly once
- [ ] All conflicts resolved by owner (no open questions)
- [ ] Each wave has a finalized input notes file
- [ ] Conflict log and not-found log are complete
- [ ] Owner confirms each wave output before proceeding to next

---

## Phase 3: Ground Truth Diff

Compare what SHOULD happen (wave output) against what DOES happen (code) and what IS CLAIMED (existing reports).

**Steps:**
12. Diff wave output against actual codebase — SHOULD vs IS
13. Diff wave output against existing gap/blocker claims (release_criteria.md, FINAL_REPORT.md)
14. Produce validated gap list (real) and retired claims list (false)
15. Owner reviews both lists, adds corrections and enhancements
16. Re-run steps 12-14 incorporating owner additions
17. Owner confirms final validated gap list

**Acceptance Criteria:**
- [ ] Every claimed gap either validated with code evidence or retired with reason
- [ ] Owner has reviewed, enhanced, and confirmed the final list
- [ ] No inherited claims survive without verification
- [ ] Retired claims list documents why each was false (prevents re-entry)

---

## Phase 4: Priority Triage

**Steps:**
18. Categorize validated gaps: must-have-for-launch vs can-wait
19. Owner makes final priority calls
20. Prioritized gaps feed into PLAN.md draft as marching orders

**Acceptance Criteria:**
- [ ] Every validated gap has a priority assignment
- [ ] Owner approves the launch-critical vs deferred split
- [ ] Priority list is ordered (what gets fixed first, second, etc.)

---

## Phase 4b: File Structure Agreement

Before drafting any governance file, agree on sections.

**Steps:**
21. Orchestrator proposes section outline for each of the 6 governance files
22. Each outline organized by major UI section with above-the-line / below-the-line mapping
23. Owner reviews, adjusts section structure to match mental model of the product
24. Final section outlines agreed and locked before drafting begins

**Acceptance Criteria:**
- [ ] All 6 file outlines proposed and reviewed
- [ ] Section structure reflects UI-to-backend mapping per owner's product thinking
- [ ] Owner approves all outlines
- [ ] No drafting begins until outlines are locked

---

## Phase 5: Draft Governance Files

**Steps:**
25. Draft PRD.md from reconciled Wave 1 notes + agreed outline
26. Draft SRS.md from reconciled Wave 2 notes + agreed outline
27. Draft SPEC.md from reconciled Wave 3 notes + agreed outline
28. Draft ACCEPTANCE_CRITERIA.md from reconciled Wave 4 notes + agreed outline
29. Draft PLAN.md from Wave 5 notes + prioritized gaps + agreed outline
30. Draft CLAUDE.md updates from reconciled Wave 6 notes + agreed outline
31. Convert test battery into spec.ts Playwright structure
32. Owner reviews all drafts — corrections and enhancements
33. Orchestrator updates steps 25-31 incorporating owner feedback
34. Owner confirms final versions of all files

**Per-file process:**
- Orchestrator drafts from reconciled notes + outline
- Verifier agent independently checks every claim against source files
- Orchestrator incorporates verifier findings
- Owner reviews, provides corrections
- Orchestrator updates
- Owner confirms final

**Acceptance Criteria:**
- [ ] All 6 governance files drafted, verified, and owner-approved
- [ ] Test battery converted to spec.ts format
- [ ] Every claim in every file traceable to a source
- [ ] No draft ships without owner sign-off
- [ ] Each file matches its agreed outline from Phase 4b

---

## Phase 6: Prepare Nexxus-v2 Environment

**Steps:**
35. Create git branches in nexxus-v2 (pre-remediation-snapshot + remediation)
36. Copy finalized governance files into staging directory (nexxus-v2/.preflight/)
37. Gut .project/ — remove /init artifacts, leave empty for /plan mode
38. Archive deprecated files (owner confirms archive list before any deletion)
39. Identify chmod changes needed (CLAUDE.md unlock/update/relock)

**Acceptance Criteria:**
- [ ] pre-remediation-snapshot branch created (frozen, never touched)
- [ ] remediation branch created (working branch)
- [ ] .preflight/ directory contains all finalized governance files
- [ ] .project/ contains only /plan mode scratch (everything else removed)
- [ ] No files deleted without owner confirmation
- [ ] Archive list documented

---

## Phase 7: Nexxus-v2 Agent Onboarding + Self-Audit

The nexxus-v2 agent gets a clean context with the new governance files and runs its own verification.

**Steps:**
40. Write handoff prompt for nexxus-v2 agent
41. Nexxus-v2 agent reads .preflight/ governance files
42. Agent runs self-audit: diffs governance files against RUI, codebase, AC, truth hierarchy
43. Agent produces its own gap list — things the sidekick may have missed
44. Owner reviews agent-found gaps, merges valid ones into PLAN.md
45. Agent moves files from .preflight/ to correct root locations
46. Owner unlocks CLAUDE.md, applies updates, relocks (chmod 644 → edit → chmod 444)
47. Delete .preflight/ staging directory
48. Verify all files in correct locations, agent confirms clean state

**Acceptance Criteria:**
- [ ] Agent self-audit complete with independent gap list
- [ ] Any new gaps triaged and added to PLAN.md by owner
- [ ] All governance files in final root locations
- [ ] CLAUDE.md updated and relocked by owner
- [ ] .preflight/ staging directory removed
- [ ] Agent confirms clean environment, no orphaned files

---

## Phase 8: Build

**Steps:**
49. Fix prioritized gaps per PLAN.md (must-have-for-launch first)
50. Run spec.ts Playwright batteries against live app
51. Update gap tracker with results
52. Loop: fix → retest → fix → retest
53. Launch verification — all must-have gaps closed, all batteries pass

**Acceptance Criteria:**
- [ ] All must-have-for-launch gaps closed
- [ ] Playwright spec.ts batteries pass
- [ ] Gap tracker shows zero open P0/P1 items
- [ ] Owner approves launch

---

## Input Files

### From this workbench session:
- verified-findings.md — 11 code-verified findings from fact-finding
- failure-analysis.md — 31 items across 8 failure categories
- session-knowledge.md — /init analysis, governance stacking, file structure decisions
- agent-remediation.md — 6 remediation items from prior unauthorized session

### From owner (to be uploaded):
- Files listed in preflight input manifest (pending upload)
- Additional context files with information from prior work

### From nexxus-v2 codebase (read during waves):
- Source code files (server/, client/)
- Existing governance files (.agent_docs/, .project/, CLAUDE.md)
- Existing reference files (filestore/, docs/)
- RUI mockup (filestore/nexus-v2-1-current/ and live URL)
- Test evidence and reports (evidence/)

---

## Key Decisions Made

1. Six governance files at root, not 4 — PRD, SRS, SPEC, AC, PLAN, CLAUDE.md each serve distinct purposes
2. .agent_docs/ stays — enforcer is owner's personal representative, Claude-native agent
3. .project/ gets gutted — reserved for /plan mode scratch only
4. Handoff happens at Phase 7 — governance files created in sidekick context, copied to nexxus-v2, agent places them
5. Agent self-audit in Phase 7 — safety net for gaps the sidekick missed
6. Wave structure for analysis — prevents context window overflow
7. Independent parallel agents for quality control — no shared outputs between analyst/reviewer
8. Review-and-redo loops at Phase 3 and Phase 5 — owner feedback triggers re-analysis
9. File structure agreement (Phase 4b) before any drafting — prevents structural rework
10. Priority triage before build — ensures time is spent on launch-critical items first

---

## Risk Mitigations

| Risk | Mitigation |
|------|------------|
| Analysis reveals more work than expected | Priority triage (Phase 4) — owner decides what ships first |
| Context window overflow during waves | Wave structure limits scope per pass |
| Assumptions in governance files | Verifier agent independently checks every claim against sources |
| Handoff introduces errors | Files staged in .preflight/, agent places them in-context |
| Agent self-audit finds major gaps | Gaps get triaged and added to PLAN.md, extending timeline if needed |
| CLAUDE.md chmod blocks updates | Explicit step: owner unlocks, updates, relocks (Phase 7 step 46) |
| Prior tainted findings re-enter | Retired claims list (Phase 3) documents false claims with reasons |
