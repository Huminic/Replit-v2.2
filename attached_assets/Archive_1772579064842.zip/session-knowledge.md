# Session Knowledge — 2026-03-02 (Workbench)

Knowledge from this session that was discussed but not yet written to any file.
This file is INPUT to the sidekick's wave analysis — not the final word.

---

## 0. Platform Mental Model (Owner-stated, 2026-03-02)

**This is the foundational frame. Every governance file and wave analysis orients around this.**

The application is made up of:
- **External interaction surfaces:** VAPI (voice), Tavus (video), Widgets (chat/SMS)
- **Internal interaction surfaces:** Automa Chat (assistant), Agents (chat agents), Metrics/Insights (data display)
- **Data flow:** Into/from VIN Solutions (CRM source of truth), internal DB (state/config/logs), external surfaces, user uploads (backend)

**Critical architecture concept: Widgets are portals to agents.**
- A widget is not its own thing — it's a portal to a VAPI agent, a Tavus agent, or an internal agent
- Externally-initiated conversations (via widget) can be continued internally in the Unified Inbox
- Staff can pick up where the agent left off — continuity between external and internal surfaces
- This is the same pattern as V1: 27 agents + a super chat. All agents were overlays on the super chat with prepopulated context and instructions. That's what a "skill" is in V2.
- This was listed as a blocker late in the game because the V1→V2 architecture transition wasn't understood by agents. It's not a blocker — it's how the system already works.

**Data flow (complete picture):**
- VIN Solutions → CRM data flows to Automa Chat, to/from Agents, and into Metrics
- Internal DB → Metrics pull from internal database
- User uploads (backend) → Additional data source for metrics
- External services → Data also flows from VAPI/Tavus/Widgets into the system
- Future: web scraping will be added as a skill (not implemented yet)
- Metrics are pulled from: internal database + CRM + user uploads + external services

**What users do:**
- Work in the **Hub** (direct actions: calendar, settings, manual tasks)
- Interact with **Agents** (agent-mediated: triggers, calls, texts, CRM updates)
- View **Insights** (read-only: data scored, displayed, alerted from multiple sources)
- Chat with **Automa** (cross-cutting assistant, has CRM data access)
- Receive **Notifications** (system-event driven, straggler category)

**Key rules:**
- Most actionable activities (CRM insertions, two-way calls, two-way texts) go through an agent at the user level
- Communication agent cannot be modified by user except triggers and instruction supplement
- User actions are either direct (hub) or agent-mediated
- Information comes from: VIN Solutions, internal user-set criteria, external interaction surfaces, user uploads
- Lead assignment is NOT part of requirements
- Scheduling is a hub action (both user and agent can do it)
- Widgets = portals to agents (not standalone features)
- Unified Inbox provides continuity between external agent conversations and internal staff follow-up
- Skills = agent overlays (context + instructions on top of Automa/super chat). This is the V1→V2 architecture. It was explained 3+ times by owner but never captured. MUST be in SRS.md.

**This model was never written in any document before.** It got "lost in the sauce" across 53 input files and the codebase. It must become the opening of PRD.md.

## 0b. Skills Architecture Clarification (Owner-stated, 2026-03-02)

**V1:** 27 separate agents + a super chat. Each agent was an overlay with prepopulated context and instructions.

**V2/V2.1 change:** Instead of 27 hardcoded agents, users CREATE their own agents and ADD skills to them. Skills are the same concept (pre-prompting, context, instructions that tell the agent what it's good at) but now user-selectable, not fixed. The skills catalog draws from what the old 27 agents used to do. On the Agents page, there is an option to add skills when creating/editing an agent.

**This is NOT a blocker.** It was reported as one because the V1→V2 transition wasn't understood. The architecture changed intentionally.

## 0c. Payment-Critical Functionality (Owner-stated, 2026-03-02)

**DO NOT call this MVP. This is the launch-critical demo set for customer payment.**

If the owner can sit in front of a customer and demonstrate ALL of the following, payment is secured:

1. **Metrics & Insights** — all current metrics and insights display correctly
2. **Communications Agent Configuration** — configure it to do special notifications using criteria from the system and from VIN Solutions fields
3. **Appointment Flow** — appointment comes in → appears in calendar → lead inserted into VIN Solutions with a note about that appointment
4. **Proactive Lead Follow-up** — when leads come into VIN Solutions, the communications agent proactively initiates an outbound phone call AND an outbound text message
5. **Reactive After-Hours Coverage** — SMS and phone coverage when staff is unavailable
6. **Widgets** — all three deployment modes work correctly:
   - Unified widget (bottom corner of customer's website)
   - Embed code (directly into customer's website)
   - Hosted landing pages
7. **Automa Chat** — ability to chat with Automa

**NOT launch-critical (contract requirement but not for payment):**
- Creating custom agents
- Skills configuration/catalog
- Other capabilities beyond the above

**How this maps to the interaction services model:**
- External surfaces: Widgets (all 3 modes) + VAPI (outbound calls) + TextMagic (outbound texts)
- Agent-mediated: Communications agent handles proactive follow-up + reactive after-hours
- Data flow: VIN Solutions → leads trigger follow-up; appointments → calendar → VIN Solutions insert
- Internal surfaces: Metrics/Insights display, Automa chat
- Hub: Calendar shows appointments

**This is the priority filter for Phase 4 (triage).** Every gap gets evaluated against: "Does this block the demo?" If yes → launch-critical. If no → can wait.

## 0d. Wave Analysis Watch List (Owner-stated, 2026-03-02)

**5 areas requiring extra attention during every wave:**

1. **Agent functionality/defaults** — what agents exist by default, what they can do, how they're configured
2. **Billing** — how it works, what's implemented, what's missing
3. **Unified inbox handoff** — how external agent conversations transition to internal staff follow-up
4. **Super Admin functionality** — undertested, owner has focused on customer-facing features. Needs thorough extraction of what super admin can see/do vs org admin vs staff.
5. **Context Router functionality** — how it works, what it routes, how it decides. Needs clear documentation.

These are not just triage filters — they are extraction priorities during every wave. Flag any information (or missing information) about these 5 areas.

---

## 1. /init Impact Analysis

### What /init did
- Nexxus-v2 used Tier 3 (Full Protocol) on 2026-02-22
- Ran a 12+ question interview and generated ~13 files in `.project/`
- Created its own governance layer: implementation plan (8 sprints with BDD AC), progress tracker, traceability matrix, architecture doc, testing strategy, core values, design system, goldenpath.yaml, agent team config, context anchor

### The problem it caused
Three governance layers now exist simultaneously, none reconciled:

| Layer | Source | Contains |
|-------|--------|----------|
| `.project/` | /init (Feb 22) | Implementation plan, BDD acceptance criteria, progress tracker, traceability, agent team config |
| `.agent_docs/` | Enforcer bootstrap (Mar 1) | Safety gates, quality gates, conventions, work tree, plan sequence, conflict resolution, placeholder AC |
| `filestore/` | Original project files | Release plan (1a_RELEASE_PLAN.md), authoritative AC (1b_ACCEPTANCE_CRITERIA.md), test kit, release criteria gap tracker |

Each layer has its own:
- Acceptance criteria (3 different files)
- Build sequence / plan
- Progress tracking

No layer references or defers to the others. Agents get confused about which to follow.

### Resolution (decided)
- `.project/` gets gutted — reserved for /plan mode scratch only
- `.agent_docs/` stays — enforcer's workspace
- `filestore/` originals become input to new consolidated governance files
- 6 new governance files at root replace the 3-layer system

---

## 2. Standard File Structure for AI-Agent Projects

### Where governance files live
```
project-root/
├── CLAUDE.md          ← agent rules (root, read every session)
├── PRD.md             ← business context (root, reference)
├── SRS.md             ← system behavior narrative (root, reference)
├── SPEC.md            ← architecture (root, read when needed)
├── PLAN.md            ← marching orders (root, read every session)
├── ACCEPTANCE_CRITERIA.md ← testable statements (root, read when testing)
├── .agent_docs/       ← enforcer workspace
├── .claude/agents/    ← agent definitions
├── .project/          ← /plan mode scratch only
└── docs/              ← deep reference material (if needed)
```

### What each file is (gradient)
- **PRD** (Strategy): Plain language. What the business does, why, for whom. A human reads this and understands the product.
- **SRS** (Precision): Technical narrative. What happens above AND below the line. "When a lead goes idle, the system checks dedup via two mechanisms..." Describes system behavior that users don't see but agents must know.
- **SPEC** (Build Logic): Architecture. Services, routes, DB schema, dependencies, workflow diagrams. How it's built, where things live.
- **PLAN** (Execution Momentum): Marching orders. Current phase, prioritized gap list, what's done, what's next.
- **AC** (Testable Outcomes): What a user should see and experience. Mirrors test battery. Above-the-line focused.
- **CLAUDE.md** (Agent Rules): Truth hierarchy, conventions, commit rules, enforcer config.

### Key distinction: SRS vs AC
- SRS describes what the system DOES (technical narrative, includes below-the-line behavior)
- AC describes what the user should EXPERIENCE (testable, above-the-line focused)
- They are NOT the same document. The SRS captures things like credential handling, dedup logic, trigger mechanics — things no user sees but agents must understand.

### Key distinction: PLAN.md vs /plan mode
- PLAN.md is a permanent project file — the roadmap, read every session
- /plan mode creates tactical scratchpad files in .project/ — for one session's task
- They don't reference each other

---

## 3. Test Battery Location

### Standard practice
Test batteries are executable code (*.test.ts, *.spec.ts) that live next to the source files they test. You run `npm test` or `npx playwright test` and get pass/fail.

### Current nexxus-v2 state
Test batteries are markdown prose in filestore/final_testing_kit/ — instructions for an agent to follow manually, producing written reports instead of pass/fail output.

### Plan
Convert prose batteries to Playwright spec.ts files. The test battery becomes the executable inverse of the acceptance criteria.

---

## 4. Gatekeeper vs Enforcer (from prior in session, on disk in failure-analysis.md Category H)

- Gatekeeper: sprint lifecycle quality — scope criteria, verify builder output, loop until ALL pass, handoff
- Enforcer: commit compliance — check governance, safety gates, quality gates before commit
- DIFFERENT JOBS. Gatekeeper was archived, enforcer doesn't fill its role.
- Gap: nobody currently loops builder output against AC + RUI until criteria pass
- Owner decision needed on how to restore this function

---

## 5. Confirmed Real P0s (from verified-findings.md)

1. **Hosted pages route mismatch**: Client fetches `/api/hosted-pages/public/${slug}`, server serves `/api/pages/:slug`. One-line fix in either client or server route.
2. **Insights crash**: 4 unsafe `.pct` accesses at lines 854, 1293, 2142, 2143. Direct array[0] without bounds checking.
3. **Appointment status notifications**: Needs live verification — no SMS/notification sent when appointment status changes.

---

## 6. Tainted Findings Summary (from verified-findings.md F1)

8 of 17 Run 2 P0s are WRONG due to architectural misunderstanding:
- Agent didn't understand V1→V2 architecture (skills model replaced individual agents)
- Agent tested TextMagic with .env credentials instead of per-org DB credentials
- Agent reported "no trigger dedup" — two mechanisms exist in code
- Agent reported "no widget tools" — 7 tools at system/widget level
- Agent reported "missing chat agents" — agents page IS chat agents, `type` = channel integration

2 additional P0s were resolved by owner during the session.

---

## 7. File Sprawl Root Causes

1. No issue tracker — gaps, bugs, test results became markdown files
2. /init created parallel governance layer on existing project
3. Enforcer bootstrap created third governance layer
4. Multiple sessions created new files instead of updating existing ones
5. Owner explanations (given 3 times) never written to files agents read
6. 89KB AC file tried to be a formal SRS — too dense for agents to use

---

## 8. Owner Clarifications (from this session)

- Enforcer is owner's personal representative, Claude-native agent, separate from agent team
- .agent_docs/ stays because it's the enforcer's operating directory
- Owner thinks about the product in above-the-line / below-the-line terms per UI section
- File structure agreement needed before drafting — sections should reflect this mental model
- Priority triage needed before build — not everything may make launch
- Timeline extended to ~1 week (was "by morning")
- Owner has archive folder outside nexxus-v2 root for deprecated files (get path)
- CLAUDE.md chmod 444 is in nexxus-v2, only owner can edit
- Gap tracker is release_criteria.md in filestore/final_testing_kit/
- Owner wants fresh analysis of everything — prior findings are input, not conclusions
