# Verified Findings — Nexxus V2 State Assessment
**Date:** 2026-03-02
**Source:** Workbench advisory session (fact-finding, read-only against nexxus-v2)
**Evidence Standard:** Every claim cites the file and line number read to verify it

---

## FINDING F0: Which File Is the Gap Tracker?

**Question:** The owner says "release_plan.md holds P0 gaps." Which file is that?

**Answer:** `filestore/final_testing_kit/release_criteria.md`

**Evidence:**
- Header (line 2): "Gap Queue & Release Gate Tracker"
- Line 9: "single source of truth for all gaps, defects, and release blockers"
- Line 14: "primary artifact for the production go/no-go decision"
- Contains 61 gaps organized by severity (P0-P3) with status tracking
- Currently shows: "All 12 P0 Gaps FIXED, 0 P0 Blockers" (from Run 1)

**NOT the gap tracker:** `filestore/nexxus_authoritative_plan/1a_RELEASE_PLAN.md`
- This is a governance document: truth hierarchy, RUI rule, phase definitions
- It does NOT track individual gaps/bugs with status
- It defines the operating rules, not the gap queue

**Potential confusion:** The owner may call the gap tracker "release_plan.md" because it's the file that gates release decisions. The actual filename is `release_criteria.md`. The two files serve completely different purposes and should not be consolidated.

---

## FINDING F1: Run 2 P0 Gap Verification

Cross-referenced each P0 from FINAL_REPORT.md (evidence/FINAL_REPORT.md) against owner corrections in agent-remediation.md Part 2 AND verified against actual code.

### TAINTED (Wrong — owner-confirmed + code-verified)

| # | Gap ID | Run 2 Claim | Why It's Wrong | Code Evidence |
|---|--------|-------------|----------------|---------------|
| 1 | GAP-B1-AGENT-001 | Serra Nissan: no chat agent | Automa IS the chat agent on homepage/popout | Owner statement, remediation Part 2 |
| 2 | GAP-B1-AGENT-002 | Tony Serra Ford: no chat agent | Same as above | Owner statement, remediation Part 2 |
| 3 | GAP-B1-AGENT-003 | Ford of Columbia: no chat agent | Same as above | Owner statement, remediation Part 2 |
| 4 | GAP-B1-SKILLS-001 | No tools on any agent (tools=[]) | Tools at widget/system level, not per-agent | WidgetConfigService.ts line 241: 7 tools in chatEnabledTools array |
| 5 | GAP-B1-INSTR-001 | Lead Follow-Up lacks CRM instructions | Measured raw DB field, not skill overlay system | Owner statement: skills are prompt overlays on Automa |
| 6 | GAP-B1-INSTR-002 | 15-min idle trigger not in instructions | Same — instructions include skill overlay context | Owner statement, remediation Part 2 |
| 7 | GAP-B1-TRIGGER-001 | No trigger dedup for active conversations | TWO dedup mechanisms exist | TriggerService.ts:856-871 (no_prior_contact → checkLeadCommunication), idleLeadChecker.ts:406-439 (hasActiveConversation) |
| 8 | GAP-B3-SMS-001 | TextMagic API returns 401 | Tested .env creds; service uses per-org DB creds | TextMagicService.ts:223-232 (getConfig from textmagic_config table), line 330 (decryptApiKey) |

**Count: 8 tainted P0s**

### RESOLVED BY OWNER

| # | Gap ID | Run 2 Claim | Owner Decision | Source |
|---|--------|-------------|----------------|--------|
| 9 | GAP-B5-VIN-SYNC-001 | VIN appointment sync never executes | VIN has no calendar API. Platform calendar is standalone. | Owner statement, remediation Part 2. Also in release_criteria.md line 69: marked N/A |
| 10 | GAP-B5-BIDIR-001 | Bidirectional calendar↔VIN impossible | Same as above | Owner statement, remediation Part 2 |

**Count: 2 resolved**

### CONFIRMED REAL

| # | Gap ID | Run 2 Claim | Verification | Code Evidence |
|---|--------|-------------|--------------|---------------|
| 11 | GAP-B2-HOSTED-001 | Hosted pages return 404 (route mismatch) | **CONFIRMED.** Client fetches wrong path. | Client: hosted-page-public.tsx:163 fetches `/api/hosted-pages/public/${slug}`. Server: routes.ts:175 mounts at `/api/pages`, hosted-pages-public.ts:44 defines GET `/:slug`. Full server path = `/api/pages/:slug`. MISMATCH. |
| 12 | GAP-B5-STATUS-001 | Status changes trigger zero notifications | **CONFIRMED.** updateAppointment() has no event hooks. | release_criteria.md line 70: "AppointmentService has reminder query but no trigger events. No appointment_status_change event type." Code confirms. |
| 13 | GAP-B6-INSIGHTS-001 | Insights dashboard crashes | **CONFIRMED CRASH RISK.** 4 unsafe .pct accesses without null guards. | insights.tsx: Lines 854 (freshness[0].pct), 1293 (currentPerformance.pctOfTotal), 2142-2143 (statusFlow[0].pct) — all direct array[0] access with no bounds check. Will throw TypeError if array is empty. |

**Count: 3 confirmed real**

### NEEDS LIVE VERIFICATION

| # | Gap ID | Run 2 Claim | Status | What's Needed |
|---|--------|-------------|--------|---------------|
| 14 | GAP-B2-PERSONA-001 | Widget header shows "Nexxus" not persona | UNKNOWN — may be viewport artifact or real JS issue | Re-test with corrected 1280x720 viewport via Playwright |
| 15 | GAP-B5-AVAIL-001 | No availability validation for AI bookings | LIKELY REAL but may be acceptable for MVP | Owner needs to decide: is availability checking required for launch? |
| 16 | GAP-B1-VIN-001 | Hyundai: no VIN integration config | OPERATIONAL — not a code bug | DB check needed: is VIN provisioned for this org? May be intentional. |
| 17 | GAP-B1-VIN-002 | Ford of Columbia: no VIN integration config | OPERATIONAL — same as above | Same DB check needed |

**Count: 4 need verification**

### ADJUSTED P0 COUNT

| Category | Count | Items |
|----------|-------|-------|
| TAINTED (remove) | 8 | AGENT-001/002/003, SKILLS-001, INSTR-001/002, TRIGGER-001, SMS-001 |
| RESOLVED (remove) | 2 | VIN-SYNC-001, BIDIR-001 |
| CONFIRMED REAL | 3 | HOSTED-001, STATUS-001, INSIGHTS-001 |
| NEEDS VERIFICATION | 4 | PERSONA-001, AVAIL-001, VIN-001, VIN-002 |
| **Actual P0s** | **3-7** | (vs. Run 2's claim of 17) |

**The 22/100 readiness score in FINAL_REPORT.md is significantly wrong.** With 8 tainted and 2 resolved P0s removed, the platform is in much better shape than reported.

---

## FINDING F2: Hosted Pages Route Mismatch (Detail)

This is the ONE gap that both Run 1 AND Run 2 identified, and both the release_criteria.md AND the owner confirmed as real.

**The problem:**
- Sprint 1 created `server/routes/hosted-pages-public.ts` with route GET `/:slug`
- Sprint 1 mounted it at `app.use("/api/pages", ...)` in `server/routes.ts:175`
- Sprint 1 created `client/src/pages/hosted-page-public.tsx` with fetch to `/api/hosted-pages/public/${slug}`
- **The client and server paths don't match.**

**The fix is simple:** Either:
- Option A: Change client fetch from `/api/hosted-pages/public/${slug}` to `/api/pages/${slug}`
- Option B: Change server mount from `/api/pages` to `/api/hosted-pages/public`
- Option A is simpler (1 line change in hosted-page-public.tsx:163)

**This was marked FIXED in release_criteria.md** but the fix is incomplete. The route was created but the client points to the wrong path.

---

## FINDING F3: Insights Page Crash Risk

**4 lines in insights.tsx access array elements or nested properties without guards:**
- Line 854: `pipelineHealthData.freshness[0].pct` — crashes if freshness array is empty
- Line 1293: `serviceLaneAnalysis.currentPerformance.pctOfTotal` — crashes if undefined
- Line 2142: `pipelineHealthData.statusFlow[0].pct` — crashes if statusFlow array is empty
- Line 2143: same

**The viewport fix (1280x720) may resolve the VISUAL issue** but does NOT fix the crash risk. If the API returns empty arrays for any metric, the page will throw a TypeError.

**Fix:** Add null guards (optional chaining or bounds checks) at these 4 lines.

---

## FINDING F4: Acceptance Criteria Conflict (UNRESOLVED)

**3 AC files exist with conflicting authority claims:**

| File | Size | Self-Declared Status | What CLAUDE.md Says |
|------|------|---------------------|---------------------|
| docs/ACCEPTANCE_CRITERIA.md | 89KB | "GOVERNING DOCUMENT" (Tier 3) | "Original... see reconciled version at .agent_docs/" |
| .agent_docs/acceptance_criteria.md | 58KB | "Reconciled" but **PLACEHOLDER** | Points here as Tier 2 authority |
| filestore/.../1b_ACCEPTANCE_CRITERIA.md | 49KB | "GOVERNING DOCUMENT" (Tier 3) | Not mentioned in CLAUDE.md |

**Critical issue:** CLAUDE.md (line 89) tells the agent to use `.agent_docs/acceptance_criteria.md` as Tier 2 authority. But that file is explicitly marked PLACEHOLDER with reconciliation incomplete (enforcer_context.md CONFLICT 2, still OPEN).

**The agent is being told to use a placeholder as its authoritative AC source.**

**Resolution needed:** Either complete the 3-way reconciliation into .agent_docs/acceptance_criteria.md, or update CLAUDE.md to point to the file the owner considers authoritative.

---

## FINDING F5: CLAUDE.md On-Disk vs. System Prompt

**enforcer_context.md CONFLICT 4 (NEW):**
- CLAUDE.md on disk at commit 95c0290 is the **PRE-ENFORCER** version
- The enforcer sections, incident record, truth hierarchy, commit authorization rule were added AFTER the rollback
- The system prompt cache (what Claude Code reads) has the updated version
- But CLAUDE.md on disk does NOT match
- CLAUDE.md is chmod 444 — only the owner can edit it

**Impact:** If a new Claude session reads CLAUDE.md from disk (not from cache), it won't see the enforcer rules, incident record, or truth hierarchy. This is a silent failure.

**This requires owner action** — manually update the file on disk.

---

## FINDING F6: Agent Team — Missing Files

**agent_team.md defines 5 agents:**
1. Enforcer — `.claude/agents/enforcer.md` EXISTS
2. Orchestrator/SRVO-MTC — `.claude/agents/orchestrator.md` DOES NOT EXIST
3. Builder 1 (Identity+Pipeline) — DOES NOT EXIST
4. Builder 2 (Trigger System) — DOES NOT EXIST
5. Builder 3 (Public Pages) — DOES NOT EXIST

**The enforcer is the only agent with a definition file.** The orchestrator and builders may be invoked inline from prompts rather than from agent definition files.

**Question for owner:** Are orchestrator and builder .md files needed? Or is agent_team.md sufficient as the reference?

---

## FINDING F7: nexxus-v2 MEMORY.md — Broken References

**Lines with problems in MEMORY.md:**
- Line 94: `READ .agent_docs/agent_architecture_v2.md BEFORE touching agents` — **FILE WAS DELETED.** This line will send the agent looking for a file that doesn't exist.
- Line 113: `see mvp-restart-handoff.md in workbench` — **FILE WAS DELETED.** Dead reference.
- Lines 93-101: Agent Architecture section — **content is valid** (owner-confirmed facts about Automa, tools, trigger dedup, TextMagic). Only the file reference on line 94 is wrong.
- Lines 103-107: Blocker vs Gap Classification — **content is valid.** Owner-confirmed definitions.
- Line 111-115: Recovery Status references "Phase 9 Run 3" and "MVP-focused restart" — **these haven't happened.** Current state is post-Run 2.

---

## FINDING F8: docs/ Directory Assessment

**Summary of 513 files:**

| Category | Count | Action | Details |
|----------|-------|--------|---------|
| KEEP (unique info) | 6 files | Leave in place or move to reference/ | Production deployments, VAPI/Tavus/VIN research, Automa knowledge, strategic analysis |
| SUPERSEDED | 8+ files | Archive | Old AC, architecture guide, VIN integration doc, specifications/, user manuals — all superseded by .agent_docs/ or codebase |
| HISTORICAL | ~499 files | Archive | Pre-rollback evidence, audit reports, old sprint artifacts, empty placeholders |

**Key KEEP files:**
1. `docs/reference/PRODUCTION_CUSTOMER_DEPLOYMENTS.md` — live deployment coordinates
2. `docs/research/VAPI_INTEGRATION_RESEARCH.md` — integration reference
3. `docs/research/TAVUS_INTEGRATION_RESEARCH.md` — integration reference
4. `docs/research/VIN_LEAD_API_RESEARCH.md` — integration reference
5. `docs/automa-knowledge/SYSTEM_KNOWLEDGE.md` — DealerBrain context
6. `docs/reference/STRATEGIC_PIVOT_ANALYSIS_2026-01-16.md` — historical context

**Key SUPERSEDED file:**
- `docs/specifications/AGENT_ARCHITECTURE.md` — this is the V1 architecture doc. The V2 architecture info is now in the owner-confirmed facts from remediation Part 2, which should go into the AC or MEMORY.md (NOT as a separate file).

---

## FINDING F9: release_criteria.md vs FINAL_REPORT.md Conflict

**The two files tell completely different stories:**

| Metric | release_criteria.md (Run 1) | FINAL_REPORT.md (Run 2) |
|--------|----------------------------|-------------------------|
| P0 count | 12 — ALL FIXED | 17-22 unique P0s |
| Readiness | "Deployed to Production" | 22/100, NOT READY |
| Sprint 1 fixes | 28 FIXED out of 61 | "0/42 prior gaps fixed" |
| Launch status | 0 P0 blockers remaining | NOT READY |

**Root cause:** FINAL_REPORT.md (Run 2) was produced by an agent that didn't understand the architecture. It re-discovered "problems" that were either already fixed, working as designed, or resolved by owner decision.

**What needs to happen:**
1. FINAL_REPORT.md needs a correction header noting the tainted findings
2. release_criteria.md needs Run 2's VALID findings merged in (the 3 confirmed real P0s and any valid P1s)
3. The next agent session needs to start from the CORRECTED state, not from either report as-is

---

## FINDING F10: What Actually Blocks Launch

After removing tainted/resolved findings, the REAL blockers are:

**Confirmed P0 (must fix):**
1. GAP-B2-HOSTED-001 — Route mismatch: change client fetch path (1 line fix)
2. GAP-B6-INSIGHTS-001 — 4 null guard fixes in insights.tsx
3. GAP-B5-STATUS-001 — Appointment status change notifications (code addition)

**Needs owner decision:**
4. GAP-B5-AVAIL-001 — Availability validation: is this MVP-required?
5. GAP-B1-VIN-001/002 — VIN config for 2 orgs: is this intentional or an oversight?
6. GAP-B2-PERSONA-001 — Widget persona display: needs live recheck after viewport fix

**P1 items that are likely valid (from release_criteria.md):**
- GAP-B1-STATUS-BYPASS-001 — Agent status toggle bypasses provisioning (OPEN)
- GAP-B1-SOURCE-MAP-001 — LeadMapper missing 6/8 source mappings (OPEN)
- GAP-B4-IDLE-RESET-001 — idle_trigger_count never resets (OPEN)
- GAP-B3-VIN-SYNC-001 — 0/22 successful VIN syncs at runtime (OPEN)
- GAP-B2-PERSONA-RESPONSE-001 — Persona data never reaches frontend (OPEN)
- GAP-B6-AGENT-NAME-001 — Legacy agent names block seed (OPEN)
- GAP-B6-SA-DATA-001 — Super Admin can't view other orgs' data (OPEN)
- GAP-B5-APPT-STARTTIME-001 — start_time returns null in API (OPEN)

**What WORKS (from both reports + code verification):**
- VAPI voice webhooks (processing live calls daily)
- VIN Solutions OAuth + API (3/5 orgs)
- Lead extraction pipeline (VAPI → internal DB → VIN sync for 3 orgs)
- Calendar UI (FullCalendar renders, CRUD works)
- Main dashboard (AI Key Metrics render)
- Chat AI / Automa / DealerBrain (functional)
- Trigger system (running every 16 minutes, business hours enforced)
- Trigger deduplication (2 mechanisms confirmed)
- TextMagic per-org credentials (architecture confirmed)
- Widget tools (7 at system level confirmed)
- Security (error handling tested, no vulnerabilities found)
- Email via Resend (API valid, domain verified)

---

## FINDING F11: Remediation Items Status

| Item | What Was Done | Current State | Action Needed |
|------|---------------|---------------|---------------|
| #1 agent_architecture_v2.md | DELETED by prior session | Contents preserved in agent-remediation.md Part 6 | Route valid content to .agent_docs/acceptance_criteria.md or MEMORY.md |
| #2 mvp-restart-handoff.md | DELETED by prior session | Contents preserved in agent-remediation.md Part 7 | Extract useful gap assessments to release_criteria.md |
| #3 Playwright .mcp.json | Viewport 1280x720 added | CORRECT — keep this change | No action needed |
| #4 nexxus-v2 MEMORY.md | Sections added about architecture, blocker classification | Valid content with dead file reference | Fix line 94 (remove deleted file reference), fix lines 111-115 (update recovery status) |
| #5 workbench MEMORY.md | Edited | References deleted files and Phase 9 Run 3 | Update to reflect current state |
| #6 /tmp/playwright-mcp-fix.json | Scratch file | Harmless | No action needed |

---

## SUMMARY: What the Remediation Plan Must Do

1. **Fix MEMORY.md dead references** (items #4, #5) — remove references to deleted files, keep valid owner-confirmed content
2. **Fix release_criteria.md** — annotate tainted Run 2 findings, merge valid Run 2 findings
3. **Fix FINAL_REPORT.md** — add correction header with tainted findings list
4. **Fix hosted pages route** — 1 line change in hosted-page-public.tsx:163
5. **Fix insights.tsx crash risk** — 4 null guard additions
6. **Resolve AC conflict** — determine authoritative file, update CLAUDE.md pointer if needed
7. **Route architecture corrections** to the right file (from remediation Part 2 to wherever AC lives)
8. **Archive docs/ clutter** — move ~499 historical files out of agent's path, keep 6 unique files
9. **Alert owner** about CLAUDE.md on-disk vs system prompt mismatch (CONFLICT 4)
10. **Prepare context reset prompt** for nexxus-v2 agent with corrected state
