# Phase 9 Battery Notes — From Workbench Session

Paste this into the nexxus-v2 session before starting Phase 9.

---

## Additional Context for Phase 9 Test Batteries

### Live RUI Mockup (Tier 1 Visual Reference)

**URL:** https://nexxusv2sample.replit.app/

This is a web-based mockup of the final Nexxus V2 UI. It is the live version of the
static files at `filestore/nexus-v2-1-current/`. Both are Tier 1 truth — the UI can be
added to but never modified.

**Important:** This is a client-side React SPA. It will not render with fetch/curl.
It requires a real browser or Playwright to navigate.

### Playwright MCP (Browser Automation)

Playwright MCP is installed and available. It gives you direct browser control —
navigate routes, click elements, read page structure, take screenshots — all from
within this conversation. It runs headless (no display needed).

**Use it for:**
- Battery B2 (Widgets/Pages): Navigate every route in both the built app AND the
  live RUI mockup. Compare structure, elements, and layout at each route.
- Visual verification of R7 (WidgetSettingsTab.tsx — 775-line rewrite),
  R8 (dashboard.tsx deleted, main.tsx supersedes), and R9 (hosted-page-public.tsx —
  1062-line public page renderer). These were flagged during patch evaluation as
  needing visual confirmation.
- Any page where you need to confirm RUI alignment beyond what code analysis can prove.

**How to use it:**
- The MCP tools are in your tool list (browser_navigate, browser_click, browser_snapshot, etc.)
- Navigate to the built app (likely http://localhost:PORT after npm run build + PM2 restart)
- Navigate to https://nexxusv2sample.replit.app/
- Compare the accessibility tree snapshots between them
- Take screenshots at each route for evidence artifacts

**What Playwright MCP does NOT replace:**
- The scripted test batteries (B1-B6) in `filestore/final_testing_kit/` — run those as designed
- Playwright MCP is an additional verification layer, not a substitute for the test scripts

### 28 Deferred Test Files

28 test files from the patch evaluation (Phase 5) were deferred to Phase 9. These are
test scripts from the 31 unauthorized commits. Evaluate them against the reconciled AC:
- If a test validates a reconciled AC criterion: use it (after reviewing for correctness)
- If a test validates something not in the reconciled AC: skip it
- If a test self-certifies or makes false claims: reject it

These test files are in the patch at `~/Claude-store/Nexxus_workbench/work_to_review.patch`.
Extract with: `git show 86c4734:tests/{filename}` (they exist in the pre-rollback history).

### Codebase State Context

A pre-incident audit (`/tmp/audit_results.txt`, Feb 24) found:
- The codebase at HEAD was already ~70% wired (not "all disconnected")
- 34 TanStack Query hooks already existed and were in active use
- 7/10 hooks mapped in the old plan didn't actually exist
- The previous session's plan misdiagnosed the situation

This means: many features may already pass their battery tests without additional work.
The re-applied patches from Phase 6 added more wiring on top of an already partially
functional system. Don't assume everything is broken — test and find out.

### Agent Persona Definitions

From `/tmp/agent_check.txt` (Feb 27), the 5 agent personas are:
1. Communications Chat
2. Sales Coach
3. Messaging Coach
4. Voice
5. Video

These use `${commsName}` and `${orgName}` template variables. Battery B1 (Agent Config)
should verify these persona definitions are correctly configured and wired.

### Webhook Verification Points

Per the recovery plan, verify the webhook (email on call complete) at:
- [ ] Before Battery B1 starts
- [ ] After Battery B6 completes
- [ ] After live Tavus test

If the webhook breaks at any point: STOP everything.

### Battery Sequence (Reminder)

| Order | Battery | Enforcer gate after? |
|-------|---------|---------------------|
| 1 | B1: Agent Config | YES — enforcer verdict before B2 |
| 2 | B2: Widgets/Pages (use Playwright MCP + RUI mockup) | YES — enforcer verdict before B3/B4 |
| 3 | B3 + B4 parallel: Inbound + Outbound | YES — enforcer verdict before B5 |
| 4 | B5: Calendar | YES — enforcer verdict before B6 |
| 5 | B6: E2E Regression | YES — enforcer verdict before Tavus test |
| 6 | Live Tavus video test with Duane Wells | Final evidence |

### Evidence Requirements

Every battery PASS must have:
- Executor (which agent ran it)
- Timestamp
- Evidence artifact (screenshot, log output, test report)
- AC criterion reference (which reconciled AC item this proves)

No self-certification. The agent that built a feature cannot certify its own test.

### 12 Open P1 Gaps

The reconciled AC identified 12 open P1 gaps. Running batteries first establishes
which are actually still open vs already resolved by the Phase 6 re-applied patches.
Fix after you know what's actually failing, not before.
