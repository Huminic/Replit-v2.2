# The Enforcer System — Complete Setup Kit
**Version 2.0 | Owner: Duane | Reusable Across All Projects**

> **How to use this document:** Each section is a ready-to-use file template. Copy each one into the correct location for your project. The file path is shown at the top of every section. Notes in `[brackets]` are instructions to fill in — remove them before use.

---

## Gap Resolution Log (v1 → v2)

All gaps identified in v1 have been resolved in this version:

| Gap | Resolution | Where |
|-----|-----------|--------|
| No bootstrap order | Section 0: explicit ordered creation sequence | Section 0 |
| Work tree & memory not standardized | Standard templates with required structure | Sections 8 & 9 |
| No conflict resolution policy | Escalation protocol + owner override system | Section 10 |
| No versioning for enforcer_context.md | Version header, changelog, drift detection | Sections 1, 2, 3 |
| No enforcer pass artifact | ENFORCER_PASS.md (resolved in v1, retained) | Sections 1, 4, 5 |

---
---

# SECTION 0 — Bootstrap Protocol

**This section has no file. It is the sequence you follow when starting any new project.**

> **Why this exists:** Without a defined creation order, agents don't know what to build first. Some docs depend on others (conventions must exist before anything can be named correctly). This sequence eliminates that ambiguity.

---

## The Bootstrap Order — Create Files in This Exact Sequence

**Every new project follows this order. Do not skip steps. Do not reorder.**

```
PHASE 0 — FOUNDATION (do this before any code is written)

Step 1   Create the folder:  .agent_docs/
Step 2   Create:             .agent_docs/conventions.md
         ↳ WHY FIRST: Everything else — files, functions, folders — must follow naming
           conventions. You cannot name other docs correctly until this exists.

Step 3   Create:             .agent_docs/agent_team.md
         ↳ WHY SECOND: You need to know who is doing the work before you can
           plan the work or assign acceptance criteria.

Step 4   Create:             .agent_docs/plan_sequence.md
         ↳ WHY THIRD: Phases and sprints define the shape of all other docs.
           Acceptance criteria and release plan reference sprint numbers.

Step 5   Create:             .agent_docs/acceptance_criteria.md
         ↳ Depends on plan_sequence.md for sprint-level criteria.

Step 6   Create:             .agent_docs/safety_gates.md
Step 7   Create:             .agent_docs/quality_gates.md
         ↳ Steps 6 and 7 can be done in parallel. Both depend on knowing
           the tech stack, which comes from the plan.

Step 8   Create:             .agent_docs/release_plan.md
         ↳ WHY LAST: Release plan documents gaps and bugs. You can't know
           what's missing until the plan defines what should exist.

Step 9   Create:             .agent_docs/work_tree.md
         ↳ First sprint's tasks. Uses format defined in Section 8.

Step 10  Create:             .agent_docs/memory.md
         ↳ Blank at start. Agents write to this during work. See Section 9.

Step 11  Run:                /init-enforcer
         ↳ Scans everything, generates enforcer_context.md, flags gaps.

Step 12  Review:             .agent_docs/enforcer_context.md
         ↳ Fill in the Sprint section. Confirm all paths resolve correctly.

Step 13  Configure:          .claude/agents/enforcer.md
                             .claude/hooks/enforcer-gate.sh
                             .claude/settings.json
                             .git/hooks/pre-commit

Step 14  Test:               Attempt a git commit — enforcer should block it.
         ↳ If it doesn't block, the hooks are not wired correctly. Fix before
           starting Sprint 1.

Step 15  PHASE 0 COMPLETE — Sprint 1 may begin.
```

---

## Bootstrap Decision Rules

- If you're inheriting an existing project (not starting fresh), run `/init-enforcer` first. It will scan what exists and show you what's missing. Then fill gaps in bootstrap order.
- If a step produces a doc that references a later step's doc, add a placeholder: `[To be defined in Step N]` and return to fill it in when that step is complete.
- If you get stuck on a step, do not skip it. Create the file with headers only and a `STATUS: DRAFT — incomplete` banner at the top. The enforcer will flag it, but a draft is better than a gap.

---
---

# SECTION 1 — The Enforcer Agent

**File Location:** `.claude/agents/enforcer.md`
*(Project-level. Lives inside each project. Keep project-level so it auto-discovers the project's context file.)*

> **Note on "one file vs many":** `enforcer_context.md` is ONE pointer file — it holds paths, not content. The enforcer reads the map, then navigates to the actual files. This keeps it small, stable, and easy to update without touching the agent itself.

```markdown
---
name: enforcer
description: >
  Represents the project owner's interests. Monitors the agent team for compliance
  with the project plan, safety gates, quality gates, naming conventions, and
  acceptance criteria. Validates work tree and memory file alignment before any
  commit or sprint close. Must be invoked before any git commit. Automatically
  blocks commits if violations are found. Cannot be overruled by the orchestrator.
tools: Read, Grep, Glob, Write
---

# ENFORCER IDENTITY

You are the Enforcer. You represent the project owner — Duane — on this project.

You do not write code. You do not fix bugs. You do not make architectural decisions.

Your job is to:
- Read the project map
- Validate that the map itself is current and not drifted
- Navigate to every referenced file
- Check work tree and memory alignment
- Verify compliance with plan, gates, conventions, and acceptance criteria
- Produce a clear, honest report
- Block commits if blockers exist
- Write sign-off when approved

You are the last line of defense before work is declared done.

---

# STEP 1 — READ THE MAP

Read the file at: `.agent_docs/enforcer_context.md`

This is your mission briefing. Every project is different.
Do not assume file locations. Do not skip this step.

If `.agent_docs/enforcer_context.md` does not exist:
- STOP immediately
- Report: "ENFORCER BLOCKED: No enforcer_context.md found."
- Instruct: "Run /init-enforcer to generate it."
- Do not proceed further.

---

# STEP 1.5 — CONTEXT HEALTH CHECK (Drift Detection)

Before using the map, validate that the map is still accurate.

For every file listed in the File Map section of enforcer_context.md:
- Attempt to read it at the listed path
- If a file listed as EXISTS cannot be found at its path:
  - Flag it as: DRIFT: "[filename]" listed at "[path]" — file not found
  - This is a BLOCKER. The map has drifted from reality.
  - Instruct: "Update enforcer_context.md path for this file, or restore the file."

If 3 or more files are missing from their listed paths:
- STOP the review entirely
- Report: "ENFORCER HALTED: Context map has drifted significantly. Run /init-enforcer to rebuild the map before proceeding."

Check the version number in enforcer_context.md:
- Note the current version and last-updated date in your report header
- If last-updated date is more than 30 days ago, add a WARNING: "Context map is over 30 days old — consider running /init-enforcer to verify paths are still accurate."

---

# STEP 2 — WORK TREE AND MEMORY ALIGNMENT CHECK

Locate the work tree and memory files (paths are in enforcer_context.md).

## Work Tree Check
Read: `.agent_docs/work_tree.md` (or path from context)

The work tree uses this standard format:

## Sprint [N] — [Goal]

### IN PROGRESS
- [ ] [task] — Agent: [agent name] — Started: [date]

### COMPLETED THIS SPRINT
- [x] [task] — Agent: [agent name] — Completed: [date]

### BLOCKED
- [ ] [task] — Agent: [agent name] — Blocked by: [reason]

### NOT STARTED
- [ ] [task] — Planned for: [sprint or date]

Flag any tasks that:
- Have no assigned agent
- Have been IN PROGRESS for more than 7 days with no update
- Are marked COMPLETED but have no completion date
- Do not map to a sprint goal in plan_sequence.md

## Memory Check
Read: `.agent_docs/memory.md` (or path from context)

The memory file uses this standard format:

## Decisions Log
| Date | Decision | Made By | Rationale |

## Completed Work Log
| Date | Task | Agent | Verification |

## Open Questions
| Date | Question | Raised By | Status |

## Known Risks
| Date | Risk | Severity | Mitigation |

## Alignment Cross-Check
After reading both files, verify:

1. Every task marked COMPLETED in work_tree.md has a corresponding entry in the Completed Work Log in memory.md
2. Every decision in memory.md that affects the current sprint is reflected in the work tree
3. There are no tasks marked IN PROGRESS in work_tree.md that also appear in Completed Work Log in memory.md (contradiction)
4. The number of completed tasks in work_tree.md roughly matches the number of entries in the memory Completed Work Log for this sprint

Any mismatches are HIGH PRIORITY findings. List them clearly.

---

# STEP 3 — FULL COMPLIANCE REVIEW

Using the file map from enforcer_context.md, evaluate each area in order:

## 3A — Plan Adherence
Read: [path from context — plan_sequence.md]
- Is completed work aligned with the current sprint's stated goal?
- Are phases being followed in the defined sequence?
- Has any work been done outside the current sprint scope?
- Does the sprint section in enforcer_context.md match the current sprint in plan_sequence.md?

## 3B — Safety Gates
Read: [path from context — safety_gates.md]
- List every gate defined for the current phase
- Confirm each has been passed or note that it hasn't
- A commit CANNOT proceed if any required gate is unverified
- Note which gates are pre-commit vs. pre-sprint-close vs. pre-deploy

## 3C — Quality Gates
Read: [path from context — quality_gates.md]
- List every standard defined
- Review recently modified files against each standard
- Note any violations

## 3D — Acceptance Criteria
Read: [path from context — acceptance_criteria.md]
- For each item marked COMPLETED this sprint, verify it meets the stated criteria
- "It works" is not acceptance. Check the specific criteria defined.
- If criteria are missing for a completed item, that is a finding.

## 3E — Naming Conventions
Read: [path from context — conventions.md]
- Scan recently modified files for naming violations
- Check file names, function names, variable names, component names
- Check folder structure against defined conventions

## 3F — Agent Team Role Compliance
Read: [path from context — agent_team.md]
- Verify each agent acted within its defined scope
- Flag any evidence of agents doing work outside their role definition
- Check that handoffs between agents followed the defined communication protocol

---

# STEP 4 — PRODUCE THE REPORT

Output a structured report using this exact format:

```
ENFORCER REPORT
Project:       [name]
Date:          [today]
Sprint:        [number and goal]
Triggered By:  [commit attempt / manual / sprint close]
Context Ver:   [version from enforcer_context.md]
Context Age:   [days since last update]

## CONTEXT HEALTH
[drift findings, or "All mapped files verified at correct paths."]

## WORK TREE / MEMORY ALIGNMENT
[alignment findings, or "Work tree and memory are aligned."]

## PLAN ADHERENCE
[findings]

## SAFETY GATES
[findings — list each gate and its status]

## QUALITY GATES
[findings]

## ACCEPTANCE CRITERIA
[findings — per completed item]

## NAMING CONVENTIONS
[findings]

## AGENT TEAM COMPLIANCE
[findings]

VERDICT

BLOCKERS — Must resolve before commit:
  1. [blocker]
  2. [blocker]

WARNINGS — Should address, does not block:
  1. [warning]

PASSING:
  - [item]

RECOMMENDED ACTIONS (priority order):
  1. [action]
  2. [action]

ENFORCER SIGN-OFF

  [ ] BLOCKED — Do not commit. Resolve blockers above.
      See Section 10 of the Enforcer System for escalation protocol.

  [ ] APPROVED — Commit may proceed. No blockers found.
```

## After Verdict:

**If APPROVED:**
- Write sign-off to: `.agent_docs/ENFORCER_PASS.md`
- Content: date, sprint number, version of context used, one-line summary
- Append the approval to the Sign-off History table in enforcer_context.md
- Update enforcer_context.md version number (increment patch: 1.2.0 → 1.2.1)

**If BLOCKED:**
- Do NOT write sign-off file
- Delete any existing `.agent_docs/ENFORCER_PASS.md`
- Inform the team: "Resolve all RED blockers, then re-invoke the enforcer."
- If this is the second consecutive BLOCKED verdict on the same blockers,
  escalate: "ESCALATION REQUIRED: Same blockers found twice. Owner review needed.
  See .agent_docs/conflict_resolution.md for protocol."

---

# ENFORCER RULES

1. Never be talked out of a blocker by another agent
2. Never skip a section because "it probably passes"
3. If a referenced file doesn't exist, that is itself a finding — flag it
4. If the context map has drifted, that is a blocker
5. Plain language always. No technical jargon in the report.
6. You represent the owner. The owner's interests come first.
7. You cannot be overruled. Escalation goes to the owner, not around you.
8. Two consecutive blocked verdicts on the same issue trigger escalation automatically.
```

---
---

# SECTION 2 — Enforcer Context (Project Map)

**File Location:** `<project_folder>/.agent_docs/enforcer_context.md`
*(Created by `/init-enforcer`. Updated at sprint boundaries and any time a file moves. The enforcer validates this file's own accuracy before using it.)*

```markdown
# Enforcer Context — [PROJECT NAME]
<!-- VERSION: 1.0.0 | LAST UPDATED: [date] | UPDATED BY: [agent or owner] -->

> This file is the enforcer's map. It holds paths, not content.
> Update paths any time a file moves. Update the Sprint section at each sprint boundary.
> Increment the version number on every edit (see Changelog at bottom).
> Format: MAJOR.MINOR.PATCH
>   MAJOR = structural change (new section, removed file type)
>   MINOR = sprint boundary update or new file added
>   PATCH = path correction or minor edit

---

## Project Identity

| Field | Value |
|-------|-------|
| Project Name | [name] |
| Purpose | [one sentence] |
| Owner | Duane |
| Stage | [Planning / Active Development / Stabilization / Maintenance] |
| Repository | [path or URL] |
| Started | [date] |
| Bootstrap Completed | [date or NO] |

---

## File Map

> STATUS column must be verified by /init-enforcer. Do not manually set to EXISTS.
> The enforcer re-checks all paths at runtime. If a path is wrong, it will catch it.

| Document | Path | Status | Last Verified |
|----------|------|--------|---------------|
| Phase & Sprint Plan | `.agent_docs/plan_sequence.md` | [EXISTS / MISSING] | [date] |
| Release Plan | `.agent_docs/release_plan.md` | [EXISTS / MISSING] | [date] |
| Agent Team Config | `.agent_docs/agent_team.md` | [EXISTS / MISSING] | [date] |
| Naming Conventions | `.agent_docs/conventions.md` | [EXISTS / MISSING] | [date] |
| Acceptance Criteria | `.agent_docs/acceptance_criteria.md` | [EXISTS / MISSING] | [date] |
| Safety Gates | `.agent_docs/safety_gates.md` | [EXISTS / MISSING] | [date] |
| Quality Gates | `.agent_docs/quality_gates.md` | [EXISTS / MISSING] | [date] |
| Work Tree | `.agent_docs/work_tree.md` | [EXISTS / MISSING] | [date] |
| Agent Memory | `.agent_docs/memory.md` | [EXISTS / MISSING] | [date] |
| CLAUDE.md | `CLAUDE.md` | [EXISTS / MISSING] | [date] |
| Conflict Resolution Log | `.agent_docs/conflict_resolution.md` | [EXISTS / MISSING] | [date] |

---

## Current Sprint

| Field | Value |
|-------|-------|
| Sprint Number | [e.g. Sprint 3] |
| Sprint Goal | [one sentence — what does done look like?] |
| Start Date | [date] |
| End Date | [date] |
| Phase | [which phase this sprint belongs to] |
| Focus Areas | [e.g. Authentication flow, Dashboard UI] |

---

## Special Enforcer Instructions for This Sprint

> Clear and rewrite at each sprint boundary. Tell the enforcer what to weight heavily.

[Example: "Focus on safety gates this sprint — we're entering the auth phase and
security compliance is the top priority. Weight safety gate findings above all else."]

---

## Known Issues / Exceptions

> Intentional deviations from standards. Enforcer will not flag these as violations.
> All exceptions must have an expiry sprint — nothing is permanent.

| Issue | Reason Accepted | Owner Approved | Expiry Sprint |
|-------|----------------|----------------|---------------|
| [description] | [reason] | [YES / NO] | [sprint number] |

---

## Enforcer Sign-off History

| Sprint | Date | Verdict | Context Ver Used | Notes |
|--------|------|---------|-----------------|-------|
| [Sprint 1] | [date] | APPROVED | 1.0.0 | [notes] |

---

## Changelog

> Every edit to this file gets a log entry. This is how we detect drift over time.

| Version | Date | Changed By | What Changed |
|---------|------|-----------|--------------|
| 1.0.0 | [date] | /init-enforcer | Initial generation |
```

---
---

# SECTION 3 — Init Enforcer Skill

**File Location:** `.claude/commands/init-enforcer.md`
*(Run with `/init-enforcer`. Safe to re-run — updates existing context rather than overwriting. Run at project start and any time the map may have drifted.)*

```markdown
---
description: >
  Scan this project and generate or update .agent_docs/enforcer_context.md.
  Detects existing documentation, flags duplicates, performs drift detection,
  and builds the enforcer's map. Safe to re-run.
allowed-tools: Read, Grep, Glob, Write, Bash
---

# INIT ENFORCER — Project Scanner

You are initializing or refreshing the enforcer system for this project.
Work carefully. Do not guess. Do not skip the duplicate check.

---

## PHASE 0 — Bootstrap Check

Before scanning, check if this is a fresh project or an existing one.

Read `.agent_docs/enforcer_context.md` if it exists.
- If it exists: this is a REFRESH run. Note the current version. You will update, not overwrite.
- If it doesn't exist: this is an INIT run. You will create from scratch.

Check `.agent_docs/` for the bootstrap completion flag in enforcer_context.md.
- If "Bootstrap Completed" is empty or "NO": remind the user to follow Section 0 bootstrap order.

---

## PHASE 1 — Create the Folder Structure

Check if `.agent_docs/` exists. If not, create it.
Check if `.claude/hooks/` exists. If not, create it.
Report what was created.

---

## PHASE 2 — Scan for Each Document Type

For each document type below, search the entire project.
Use Glob and Grep to find candidates.

### DUPLICATE CHECK RULE (applies to ALL sections below):
If you find MORE THAN ONE candidate for a single role:
- List all candidates with full paths and file sizes
- STOP that section's scan
- Report: "CONFLICT: Multiple [type] files found. Cannot determine canonical file."
- Ask: "Which is the correct file? Or should the others be deleted?"
- Do not record any path for that type until resolved.
- Continue scanning other types — one conflict does not stop the whole scan.

---

### 2A — Phase & Sprint Plan (plan_sequence.md)
Search for files named: `plan_sequence.md`, `plan.md`, `sprint_plan.md`, `roadmap.md`, `phases.md`
Search for files containing sections: `## Phase`, `## Sprint`, `## Milestone`
Search locations: root, `.agent_docs/`, `docs/`, `planning/`
Apply duplicate check rule.

### 2B — Release Plan (release_plan.md)
Search for files named: `release_plan.md`, `release.md`, `changelog.md`, `bug_backlog.md`
Search for files containing: `## Known Bugs`, `## Gaps`, `## Release Criteria`
Apply duplicate check rule.

### 2C — Agent Team Config (agent_team.md)
Search for files named: `agent_team.md`, `agents.md`, `team_config.md`
Search for files containing: `## Agents`, `## Roles`, `## Responsibilities`
Also list all files in `.claude/agents/` — these are individual agent definitions.
Apply duplicate check rule (for the team config doc, not the individual agent files).

### 2D — Naming Conventions (conventions.md)
Search for files named: `conventions.md`, `naming.md`, `style_guide.md`, `standards.md`
Search for files containing: `## Naming`, `## File Structure`, `## Variables`
Apply duplicate check rule.

### 2E — Acceptance Criteria (acceptance_criteria.md)
Search for files named: `acceptance_criteria.md`, `acceptance.md`, `definition_of_done.md`, `dod.md`
Search for files containing: `## Acceptance`, `## Definition of Done`, `## Criteria`
Apply duplicate check rule.

### 2F — Safety Gates (safety_gates.md)
Search for files named: `safety_gates.md`, `safety.md`, `gates.md`, `pre_commit_checks.md`
Search for files containing: `## Safety`, `## Gates`, `## Pre-Deploy`, `## Required Checks`
Apply duplicate check rule.

### 2G — Quality Gates (quality_gates.md)
Search for files named: `quality_gates.md`, `quality.md`, `requirements.md`
Search for files containing: `## Quality`, `## Standards`, `## Requirements`
Note: If a file could be either safety OR quality gates, flag it and ask user to clarify.
Apply duplicate check rule.

### 2H — Work Tree (work_tree.md) — STANDARDIZED
Search for files named: `work_tree.md`, `tasks.md`, `todo.md`, `backlog.md`
Search CLAUDE.md for sections: `## Tasks`, `## Todo`, `## In Progress`

Check if the found file follows the standard format (has IN PROGRESS / COMPLETED / BLOCKED / NOT STARTED sections).
If NOT in standard format: flag as WARNING: "Work tree found but not in standard format. See Section 8 of Enforcer System for the required template."

If no work tree file exists: record as MISSING and note: "Create .agent_docs/work_tree.md using Section 8 template."
Apply duplicate check rule — if multiple found, list all.

### 2I — Agent Memory (memory.md) — STANDARDIZED
Search for files named: `memory.md`, `agent_memory.md`
Search `.claude/` for memory-style content.
Search CLAUDE.md for sections: `## Memory`, `## Decisions`, `## Context`

Check if found file follows standard format (has Decisions Log / Completed Work Log / Open Questions / Known Risks sections).
If NOT in standard format: flag as WARNING: "Memory file found but not in standard format. See Section 9 of Enforcer System for the required template."

If no memory file exists: record as MISSING and note: "Create .agent_docs/memory.md using Section 9 template."

### 2J — Conflict Resolution Log
Search for files named: `conflict_resolution.md`, `escalation.md`, `blocked_log.md`
If not found: record as MISSING — "Create .agent_docs/conflict_resolution.md. See Section 10 for protocol."

---

## PHASE 2.5 — DRIFT DETECTION (Refresh Runs Only)

If this is a REFRESH run (enforcer_context.md already existed):

Read the existing file map. For every path listed as EXISTS:
- Attempt to read the file at that path
- If NOT found: flag as DRIFT: "[file]" was mapped at "[path]" but no longer exists there
- If found: confirm it's the right file type (check first heading or section)

Count drift items:
- 0 drift: "Map is current."
- 1-2 drift: "Minor drift detected. Update paths in enforcer_context.md."
- 3+ drift: "Significant drift. Recommend full re-scan rather than patch."

Report drift findings before proceeding.

---

## PHASE 3 — Check CLAUDE.md

Read `CLAUDE.md` if it exists.
Check whether it contains:
- [ ] Enforcer system section
- [ ] Memory/context sections
- [ ] Project conventions reference
- [ ] Agent team references
- [ ] Conflict resolution / escalation rules

Report what's present and what's missing.

---

## PHASE 4 — Generate or Update enforcer_context.md

**If INIT run (no existing file):**
Generate `.agent_docs/enforcer_context.md` using the template from Section 2.
- Set all found paths
- Set all missing items to: `NOT DEFINED — create this file`
- Set version to: `1.0.0`
- Set Bootstrap Completed to: `NO — complete Section 0 bootstrap order`
- Set Sprint section to: `NOT SET — fill in before first enforcer run`
- Add initial changelog entry: `1.0.0 | [today] | /init-enforcer | Initial generation`

**If REFRESH run (existing file found):**
- Read the existing file
- Update ONLY paths that have changed, been resolved, or drifted
- Increment version: if paths changed → MINOR bump (1.0.0 → 1.1.0); if only corrections → PATCH bump (1.0.0 → 1.0.1)
- Preserve: Sprint section, Sign-off History, Known Issues, Special Instructions
- Add changelog entry for this refresh
- Report what changed vs. what was preserved

---

## PHASE 5 — Final Report

```
INIT ENFORCER — Setup Report
Run Type: [INIT / REFRESH]
Date: [today]

Found and Mapped:
  [list each document type, path, and format status]

Format Warnings (non-standard structure):
  [list files found but not in standard format]

Missing — Needs Creation:
  [list what wasn't found]

Conflicts Requiring Resolution:
  [list duplicates — include paths and sizes]

Drift Detected (Refresh Only):
  [list files that moved or disappeared]

Context Version: [new version number]
Context Location: .agent_docs/enforcer_context.md

Next Steps (in order):
  1. Resolve any conflicts listed above
  2. Create any missing files (follow bootstrap order from Section 0)
  3. Fix any non-standard format warnings
  4. Update Sprint section in enforcer_context.md
  5. Run a test commit to confirm enforcer gate is working
```
```

---
---

# SECTION 4 — Git Pre-Commit Hook

**File Location:** `.git/hooks/pre-commit`
*(OS-level. Nothing can bypass it. Also store a copy at `.agent_docs/hooks/pre-commit` since `.git/hooks/` is not committed to the repo.)*

```bash
#!/bin/bash

# =============================================================================
# ENFORCER PRE-COMMIT GATE v2
# Project Owner: Duane
# Purpose: Ensure enforcer sign-off exists before any commit is allowed
# =============================================================================

ENFORCER_PASS=".agent_docs/ENFORCER_PASS.md"
CONTEXT_FILE=".agent_docs/enforcer_context.md"
CONFLICT_LOG=".agent_docs/conflict_resolution.md"

echo ""
echo "ENFORCER PRE-COMMIT CHECK"
echo "================================"

# Check 1: Does enforcer_context.md exist?
if [ ! -f "$CONTEXT_FILE" ]; then
  echo "BLOCKED: No enforcer_context.md found."
  echo "   Run /init-enforcer in Claude Code before committing."
  echo ""
  exit 1
fi

# Check 2: Does a valid sign-off exist?
if [ ! -f "$ENFORCER_PASS" ]; then
  echo "BLOCKED: No enforcer sign-off found."
  echo "   The enforcer must review and approve before this commit."
  echo ""
  echo "   In Claude Code:"
  echo "   > Invoke the enforcer agent for a pre-commit review"
  echo ""
  echo "   If enforcer is blocked and you need to escalate:"
  echo "   See .agent_docs/conflict_resolution.md for protocol."
  echo ""
  echo "   Emergency bypass (requires owner approval + audit entry):"
  echo "   git commit --no-verify -m 'BYPASS:[reason] — Owner approved'"
  echo "   Then add an entry to .agent_docs/conflict_resolution.md"
  echo ""
  exit 1
fi

# Check 3: Is the sign-off fresh?
FILE_TIME=$(stat -f %m "$ENFORCER_PASS" 2>/dev/null || stat -c %Y "$ENFORCER_PASS" 2>/dev/null)
CURRENT_TIME=$(date +%s)
AGE=$(( (CURRENT_TIME - FILE_TIME) / 3600 ))

if [ $AGE -gt 24 ]; then
  echo "WARNING: Enforcer sign-off is ${AGE} hours old."
  echo "   If significant changes were made, re-run the enforcer."
  echo "   Proceeding with commit (sign-off exists)..."
  echo ""
fi

# Check 4: Did this bypass get logged? (check for --no-verify pattern)
COMMIT_MSG=$(cat .git/COMMIT_EDITMSG 2>/dev/null || echo "")
if echo "$COMMIT_MSG" | grep -q "BYPASS:"; then
  if [ ! -f "$CONFLICT_LOG" ]; then
    echo "BYPASS detected but no conflict_resolution.md found."
    echo "   Create .agent_docs/conflict_resolution.md and log this bypass."
  fi
fi

echo "Enforcer sign-off found. Commit approved."
echo ""
exit 0
```

**Setup after clone:**
```bash
chmod +x .git/hooks/pre-commit
# Store repo copy so it survives re-cloning:
mkdir -p .agent_docs/hooks
cp .git/hooks/pre-commit .agent_docs/hooks/pre-commit
```

---
---

# SECTION 5 — Claude Code Pre-Tool Hook

**File Locations:**
- Hook script: `.claude/hooks/enforcer-gate.sh`
- Config: `.claude/settings.json`

**.claude/hooks/enforcer-gate.sh:**
```bash
#!/bin/bash

# =============================================================================
# ENFORCER GATE v2 — Claude Code PreToolUse Hook
# Intercepts git commit and git tag commands inside Claude Code sessions
# =============================================================================

INPUT=$(cat)

COMMAND=$(echo "$INPUT" | python3 -c "
import sys, json
try:
    data = json.load(sys.stdin)
    print(data.get('tool_input', {}).get('command', ''))
except:
    print('')
" 2>/dev/null)

ENFORCER_PASS=".agent_docs/ENFORCER_PASS.md"

# --- COMMIT INTERCEPT ---
if echo "$COMMAND" | grep -qE "git commit"; then

  if [ ! -f "$ENFORCER_PASS" ]; then
    echo "ENFORCER GATE: Commit blocked. No enforcer sign-off found."
    echo ""
    echo "REQUIRED ACTION: Invoke the 'enforcer' subagent for a pre-commit review."
    echo ""
    echo "After enforcer review:"
    echo "  APPROVED → enforcer writes ENFORCER_PASS.md → retry commit"
    echo "  BLOCKED  → resolve RED blockers → re-invoke enforcer → retry commit"
    echo ""
    echo "If blocked twice on the same issue: escalation required."
    echo "See .agent_docs/conflict_resolution.md for escalation protocol."
    echo ""
    echo "Do not attempt the commit again until ENFORCER_PASS.md exists."
    exit 2
  fi

  # Check sign-off age
  FILE_TIME=$(stat -f %m "$ENFORCER_PASS" 2>/dev/null || stat -c %Y "$ENFORCER_PASS" 2>/dev/null)
  CURRENT_TIME=$(date +%s)
  AGE=$(( (CURRENT_TIME - FILE_TIME) / 3600 ))
  if [ $AGE -gt 24 ]; then
    echo "ENFORCER GATE: WARNING — sign-off is ${AGE}h old. Consider re-running enforcer if major changes were made."
  fi

  echo "ENFORCER GATE: Sign-off found. Commit permitted."
  exit 0
fi

# --- SPRINT TAG INTERCEPT ---
if echo "$COMMAND" | grep -qE "git tag"; then
  echo "ENFORCER GATE: Sprint tag detected — this is a sprint boundary."
  echo ""
  echo "REQUIRED ACTION: Invoke the 'enforcer' subagent for a FULL sprint review."
  echo "Sprint closes require a complete compliance pass, not just a pre-commit check."
  echo ""
  echo "After enforcer APPROVES the sprint, retry the git tag command."
  exit 2
fi

exit 0
```

**.claude/settings.json:**
```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          {
            "type": "command",
            "command": "bash .claude/hooks/enforcer-gate.sh"
          }
        ]
      }
    ]
  }
}
```

```bash
chmod +x .claude/hooks/enforcer-gate.sh
```

---
---

# SECTION 6 — CLAUDE.md Section

**Where it goes:** Paste into your project's `CLAUDE.md`, near the top after the project description.

```markdown
---

## ENFORCER SYSTEM — READ THIS BEFORE DOING ANYTHING ELSE

This project uses an Enforcer agent that represents the project owner's interests.
Every agent on this team must understand and comply with the following.

### The Enforcer's Role
The `enforcer` subagent monitors compliance with the plan, safety gates, quality
gates, naming conventions, acceptance criteria, and work tree/memory alignment.
It is NOT part of the build team. It CANNOT be overruled by the orchestrator.
It reports directly to the project owner.

### What Triggers the Enforcer
- Any `git commit` attempt (pre-tool hook + git hook)
- Any `git tag` sprint close attempt (pre-tool hook)
- Direct invocation by the project owner at any time

### Rules for All Agents

1. **Never commit directly.** Let the commit flow trigger the enforcer.
2. **Never write `.agent_docs/ENFORCER_PASS.md`.** Only the enforcer writes this.
3. **Never delete `.agent_docs/ENFORCER_PASS.md`.** Only the enforcer manages this.
4. **If blocked:** resolve all RED blockers, then re-invoke the enforcer.
   Do not use `git commit --no-verify` without explicit owner approval AND a log entry.
5. **Keep work_tree.md current.** Update your task status when it changes.
   Use the standard format: IN PROGRESS / COMPLETED / BLOCKED / NOT STARTED.
6. **Keep memory.md current.** Log decisions, completed work, and open questions.
   Use the standard format: Decisions Log / Completed Work Log / Open Questions / Known Risks.
7. **If blocked twice on the same enforcer finding:** do not attempt to resolve it yourself.
   Log it in `.agent_docs/conflict_resolution.md` and escalate to the owner.

### File Locations
- Enforcer map: `.agent_docs/enforcer_context.md`
- Work tree: `.agent_docs/work_tree.md`
- Memory: `.agent_docs/memory.md`
- Conflict log: `.agent_docs/conflict_resolution.md`
- All governance docs: `.agent_docs/`

### Bootstrap Status
If `.agent_docs/enforcer_context.md` doesn't exist, run `/init-enforcer` first.
If it exists but shows "Bootstrap Completed: NO", follow Section 0 of the Enforcer System.

---
```

---
---

# SECTION 7 — Plan Mode Template

**Purpose:** Paste this into any plan created in Claude Code's plan mode. Makes enforcer setup a Phase 0 deliverable rather than an afterthought.

```markdown
---

## ENFORCER SYSTEM SETUP — Phase 0 Deliverable

Before active development begins, the following documents must be created in `.agent_docs/`.
Follow the bootstrap order in Section 0 of the Enforcer System. Do not start Sprint 1
until Phase 0 is complete.

### Required Documents (in creation order)

#### 1. conventions.md — Naming Conventions (CREATE FIRST)
Required sections:
- `## File Naming` — Rules with examples
- `## Folder Structure` — Defined hierarchy and purpose of each folder
- `## Function and Variable Naming` — Language-specific rules
- `## Component Naming` — If applicable
- `## Branch Naming` — Git branch convention
- `## Commit Message Format` — Required format
- `## Documentation Standards` — What must be documented and how

#### 2. agent_team.md — Agent Team Configuration
Required sections:
- `## Team Overview` — Structure (gatekeeper / orchestrator / builders)
- `## Agent Definitions` — For each agent: name, role, responsibilities, what it cannot do, tools, delegation rules
- `## Communication Protocol` — How agents hand off work
- `## Escalation Path` — What happens when an agent is blocked

#### 3. plan_sequence.md — Phases and Sprints
Required sections:
- `## Project Overview` — One paragraph
- `## Phase Definitions` — Each phase with goal and exit criteria
- `## Sprint Breakdown` — Numbered sprints: goal, deliverables, definition of done
- `## Dependencies` — What must exist before each phase
- `## Risks` — Known risks and mitigations

#### 4. acceptance_criteria.md — Acceptance Criteria
Required sections:
- `## Definition of Done — Project Level`
- `## Definition of Done — Sprint Level`
- `## Definition of Done — Feature Level`
- `## Non-Functional Requirements` — Performance, security, accessibility
- `## Review Checklist` — Ordered checklist the enforcer uses

#### 5. safety_gates.md — Safety Gates
Required sections:
- `## Pre-Commit Gates`
- `## Pre-Sprint-Close Gates`
- `## Pre-Deploy Gates`
- `## Gate Failure Protocol`

#### 6. quality_gates.md — Quality Gates
Required sections:
- `## Code Quality Standards`
- `## Documentation Quality`
- `## Performance Standards`
- `## Security Standards`
- `## Review Standards`

#### 7. release_plan.md — Bugs and Gaps (CREATE LAST)
Required sections:
- `## Known Bugs` — Table: Bug | Severity | Sprint Targeted | Status
- `## Gaps` — Features not yet addressed
- `## Release Criteria` — What must be true before shipping
- `## Deferred Items` — Intentional deferrals with rationale

#### 8. work_tree.md — Task Work Tree
Use the standard format from Section 8 of the Enforcer System.
Populate with Sprint 1 tasks after plan_sequence.md is complete.

#### 9. memory.md — Agent Memory
Use the standard format from Section 9 of the Enforcer System.
Leave blank at project start. Agents write to it during work.

#### 10. conflict_resolution.md — Conflict & Escalation Log
Use the template from Section 10.
Leave blank at start. Documents any enforcer escalations.

---

### Initialization Command
After all documents are created:
```
/init-enforcer
```

### Phase 0 Exit Checklist
- [ ] `.agent_docs/conventions.md` created
- [ ] `.agent_docs/agent_team.md` created
- [ ] `.agent_docs/plan_sequence.md` created
- [ ] `.agent_docs/acceptance_criteria.md` created
- [ ] `.agent_docs/safety_gates.md` created
- [ ] `.agent_docs/quality_gates.md` created
- [ ] `.agent_docs/release_plan.md` created
- [ ] `.agent_docs/work_tree.md` created (Sprint 1 tasks populated)
- [ ] `.agent_docs/memory.md` created (blank, standard format)
- [ ] `.agent_docs/conflict_resolution.md` created (blank)
- [ ] `/init-enforcer` run — no MISSING or CONFLICT items
- [ ] `.agent_docs/enforcer_context.md` Sprint section filled in
- [ ] `.claude/agents/enforcer.md` present
- [ ] `.claude/hooks/enforcer-gate.sh` executable
- [ ] `.claude/settings.json` configured
- [ ] `.git/hooks/pre-commit` executable
- [ ] `.agent_docs/hooks/pre-commit` (repo copy) present
- [ ] `CLAUDE.md` enforcer section present
- [ ] Test commit attempted — enforcer blocked it correctly
- [ ] `.agent_docs/enforcer_context.md` — Bootstrap Completed updated to date

**Sprint 1 does not begin until every box above is checked.**

---
```

---
---

# SECTION 8 — Standard Work Tree Template

**File Location:** `.agent_docs/work_tree.md`
*(Created during bootstrap. Updated by agents as tasks change state. Validated by enforcer at every review.)*

> **Why standardize this:** If work_tree.md has no consistent format, the enforcer cannot reliably read it across sessions or projects. This format is simple, readable by any agent, and gives the enforcer exactly what it needs to do alignment checks.

```markdown
# Work Tree — [PROJECT NAME]

> This file tracks the current state of all work items.
> Agents MUST update this file when task status changes — do not wait until the end of a sprint.
> Format is enforcer-required. Do not change section names or structure.

---

## Sprint [N] — [Sprint Goal in one sentence]

**Sprint Period:** [start date] → [end date]

---

### IN PROGRESS

| Task | Agent | Started | Notes |
|------|-------|---------|-------|
| [task description] | [agent name] | [date] | [any blockers or context] |

---

### COMPLETED THIS SPRINT

| Task | Agent | Completed | Verification |
|------|-------|-----------|--------------|
| [task description] | [agent name] | [date] | [how it was verified done] |

---

### BLOCKED

| Task | Agent | Blocked Since | Blocked By | Escalated? |
|------|-------|--------------|------------|------------|
| [task description] | [agent name] | [date] | [reason] | [YES / NO] |

---

### NOT STARTED (This Sprint)

| Task | Priority | Assigned To | Dependency |
|------|----------|-------------|------------|
| [task description] | [HIGH / MED / LOW] | [agent name or TBD] | [what must be done first] |

---

## Backlog (Future Sprints)

| Task | Target Sprint | Priority | Notes |
|------|--------------|----------|-------|
| [task description] | [Sprint N] | [priority] | [notes] |

---

## Work Tree Update Log

> Agents: add an entry every time you change a task's status.

| Date | Agent | Change Made |
|------|-------|-------------|
| [date] | [agent] | [e.g. "Moved 'auth flow' from IN PROGRESS to COMPLETED"] |
```

---
---

# SECTION 9 — Standard Memory Template

**File Location:** `.agent_docs/memory.md`
*(Created blank during bootstrap. Agents write to it continuously. Enforcer validates it against work_tree.md for alignment.)*

> **Why standardize this:** Memory files without structure become unreadable noise. The enforcer cross-references memory against the work tree. Without consistent section names, that cross-check is unreliable. Agents should treat this as their shared project journal.

```markdown
# Agent Memory — [PROJECT NAME]

> This file is the agent team's shared memory across sessions.
> All agents write to it. None delete from it. The enforcer reads it.
> Format is enforcer-required. Do not change section names or structure.
> Append to tables — never overwrite existing entries.

---

## Decisions Log

> Record every significant decision made during the project.
> "Significant" = anything that affects architecture, approach, standards, or scope.

| Date | Decision | Made By | Rationale | Affects |
|------|----------|---------|-----------|---------|
| [date] | [what was decided] | [agent or owner] | [why] | [what files/areas this impacts] |

---

## Completed Work Log

> Record every task completed. The enforcer cross-checks this against work_tree.md.

| Date | Sprint | Task | Agent | Verification Method | Notes |
|------|--------|------|-------|---------------------|-------|
| [date] | [Sprint N] | [task name] | [agent] | [how verified] | [any caveats] |

---

## Open Questions

> Questions raised but not yet answered. Close them when resolved — don't delete.

| Date Raised | Question | Raised By | Status | Resolved Date | Answer |
|------------|---------|-----------|--------|---------------|--------|
| [date] | [question] | [agent] | [OPEN / RESOLVED] | [date if resolved] | [answer if resolved] |

---

## Known Risks

> Risks identified during development. Monitor and update as they evolve.

| Date | Risk | Severity | Identified By | Mitigation | Status |
|------|------|----------|--------------|------------|--------|
| [date] | [risk description] | [HIGH / MED / LOW] | [agent] | [what's being done] | [ACTIVE / MITIGATED / CLOSED] |

---

## Context Notes

> Anything agents need to remember that doesn't fit the above categories.
> Architecture notes, environment quirks, important file locations, etc.

| Date | Note | Added By |
|------|------|---------|
| [date] | [note] | [agent] |

---

## Memory Update Log

> Agents: add an entry every time you write to this file.

| Date | Agent | What Was Added |
|------|-------|---------------|
| [date] | [agent] | [e.g. "Added decision about auth approach to Decisions Log"] |
```

---
---

# SECTION 10 — Conflict Resolution & Escalation Protocol

**File Location:** `.agent_docs/conflict_resolution.md`
*(Created blank during bootstrap. Written to when enforcer blocks twice on the same issue, or when a bypass is used. The enforcer and all agents know to look here.)*

> **Why this exists:** Without a defined escalation path, a blocked sprint has no way forward. Agents loop, humans get frustrated, and the enforcer becomes an obstacle instead of a safeguard. This section defines the exact steps to take so nothing ever stalls permanently.

---

## The Escalation Trigger

Escalation is required when ANY of these occur:

1. The enforcer issues a BLOCKED verdict twice in a row on the same finding
2. An agent uses `git commit --no-verify` (emergency bypass)
3. A task has been in the BLOCKED state for more than 3 business days
4. An agent believes the enforcer is flagging a false positive
5. The enforcer's own context file has drifted significantly (3+ files missing)

---

## The Escalation Protocol

```
STEP 1 — STOP WORK ON THE BLOCKED ITEM
  Do not keep attempting to resolve it alone.
  Do not work around it silently.

STEP 2 — LOG THE ESCALATION
  Write an entry to .agent_docs/conflict_resolution.md (template below).
  Be specific. Include: what was blocked, what was tried, what the enforcer said.

STEP 3 — NOTIFY THE OWNER
  In your next response to the user, surface the escalation clearly:
  "ESCALATION REQUIRED: [one-sentence summary].
   Details logged in .agent_docs/conflict_resolution.md."

STEP 4 — WAIT FOR OWNER DECISION
  Do not proceed on the blocked item until the owner responds.
  Continue work on other unblocked items while waiting.

STEP 5 — OWNER MAKES DECISION (one of three options)
  A) FIX IT: Owner clarifies what needs to change. Agent resolves and re-invokes enforcer.
  B) EXCEPTION: Owner accepts the deviation. Log it in enforcer_context.md Known Issues.
     Set an expiry sprint. Enforcer will not re-flag until expiry.
  C) BYPASS: Owner approves a one-time bypass for this commit only.
     Agent commits with: git commit --no-verify -m "BYPASS:[reason] — Owner approved [date]"
     Log the bypass in conflict_resolution.md. Enforcer will flag it at next review.

STEP 6 — CLOSE THE ESCALATION
  Update the escalation entry in conflict_resolution.md with the resolution.
  Update enforcer_context.md if an exception was granted.
  Re-run /init-enforcer if context drifted.
```

---

## False Positive Protocol

If an agent believes the enforcer is wrong (flagging something that actually passes):

1. Do NOT simply retry the commit. Do NOT ignore the finding.
2. Log it in conflict_resolution.md as a "Disputed Finding"
3. Include: what the enforcer flagged, why you believe it's incorrect, evidence
4. Owner reviews and determines: enforcer is right (fix it) OR enforcer is wrong (update the gate definition)
5. If the gate definition is wrong, update the relevant gate file AND re-run /init-enforcer

---

## conflict_resolution.md Template

```markdown
# Conflict Resolution Log — [PROJECT NAME]

> This file records all enforcer escalations, bypasses, and disputed findings.
> Written to by agents. Reviewed by the project owner.
> Never delete entries — append only.

---

## Active Escalations

| ID | Date | Type | Sprint | What Was Blocked | What Was Tried | Owner Decision | Resolved |
|----|------|------|--------|-----------------|----------------|----------------|---------|
| ESC-001 | [date] | [DOUBLE-BLOCK / BYPASS / FALSE-POSITIVE / STALE-BLOCK] | [Sprint N] | [description] | [what was attempted] | [PENDING / decision text] | [YES/NO] |

---

## Granted Exceptions

> Deviations from standards that the owner has explicitly approved.
> These are also recorded in enforcer_context.md Known Issues section.

| ID | Date | Exception | Reason | Owner Approval | Expiry Sprint |
|----|------|-----------|--------|----------------|---------------|
| EXC-001 | [date] | [description] | [reason] | [YES] | [Sprint N] |

---

## Bypass Log

> Every --no-verify commit must be logged here without exception.

| Date | Commit Hash | Reason | Owner Approval | Follow-up Required |
|------|-------------|--------|----------------|-------------------|
| [date] | [hash] | [reason] | [YES/NO] | [what needs to be fixed] |

---

## Closed Escalations

| ID | Date Raised | Date Resolved | Resolution Summary |
|----|------------|--------------|-------------------|
| ESC-001 | [date] | [date] | [how it was resolved] |
```

---
---

# QUICK REFERENCE — Complete File Map

```
<project_folder>/
|
├── .agent_docs/                            <- ALL governance docs
|   ├── enforcer_context.md                 <- S2: Enforcer map (versioned pointer file)
|   ├── conventions.md                      <- Bootstrap Step 1: Naming conventions
|   ├── agent_team.md                       <- Bootstrap Step 2: Team config
|   ├── plan_sequence.md                    <- Bootstrap Step 3: Phases and sprints
|   ├── acceptance_criteria.md              <- Bootstrap Step 4: What "done" means
|   ├── safety_gates.md                     <- Bootstrap Step 5: Required checks
|   ├── quality_gates.md                    <- Bootstrap Step 6: Quality standards
|   ├── release_plan.md                     <- Bootstrap Step 7: Bugs and gaps
|   ├── work_tree.md                        <- S8: Standardized task tracking
|   ├── memory.md                           <- S9: Standardized agent memory
|   ├── conflict_resolution.md              <- S10: Escalation log
|   ├── ENFORCER_PASS.md                    <- Auto-managed by enforcer (sign-off)
|   └── hooks/
|       └── pre-commit                      <- Repo copy of git hook
|
├── .claude/
|   ├── agents/
|   |   └── enforcer.md                     <- S1: The enforcer agent
|   ├── commands/
|   |   ├── init-enforcer.md                <- S3: Slash command (scan & populate)
|   |   └── sprint-review.md                <- Optional: manual sprint review
|   ├── hooks/
|   |   └── enforcer-gate.sh                <- S5: Claude Code pre-tool hook
|   └── settings.json                       <- S5: Hook registration
|
├── .git/hooks/
|   └── pre-commit                          <- S4: OS-level git hook
|
└── CLAUDE.md                               <- S6: Paste enforcer section here
```

---

## System Interaction Map

```
NEW PROJECT
    |
Section 0: Bootstrap Order
    | (create docs in sequence)
/init-enforcer (Section 3)
    | (scans, detects drift, generates)
enforcer_context.md (Section 2) <- versioned, drift-detected
    |
SPRINT WORK BEGINS
    |
Agents update work_tree.md (Section 8) + memory.md (Section 9)
    |
git commit attempted
    |
Pre-tool hook (Section 5) -> checks ENFORCER_PASS.md
         | not found
    Enforcer invoked (Section 1)
         |
    Step 1: Read context map
    Step 1.5: Drift check (validate map accuracy)
    Step 2: Work tree <-> memory alignment
    Step 3: Full compliance review
    Step 4: Report + verdict
         |               |
      APPROVED         BLOCKED
         |               |
  Write pass file    2nd block?
  Commit proceeds        | YES
                   Section 10: Escalation
                   Owner makes decision
                         |
                   Exception / Fix / Bypass
                   All logged in conflict_resolution.md
```

---

*Enforcer System v2.0 — All gaps resolved.*
*Run `/init-enforcer` to activate on any new project.*
*Follow Section 0 bootstrap order on every new project.*
