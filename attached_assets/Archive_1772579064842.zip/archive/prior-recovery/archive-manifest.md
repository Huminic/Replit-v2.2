# Archive Manifest — Nexxus v2 Recovery
**Prepared:** 2026-03-01
**Archive Location:** `~/Claude-store/filestore/archive/nexxus2_1/`
**Purpose:** Every file to move or delete during the recovery, with disposition and reason.

---

## Files to Archive

These files are moved from nexxus-v2 to the archive directory. They are preserved but no longer active.

| # | Source Path (in nexxus-v2) | Archive Destination | Reason |
|---|---------------------------|--------------------|---------|
| 1 | `.claude/agents/FRAMEWORK.md` | `archive/nexxus2_1/old-agents/FRAMEWORK.md` | Replaced by `.agent_docs/` governance structure |
| 2 | `.claude/agents/gatekeeper.md` | `archive/nexxus2_1/old-agents/gatekeeper.md` | Replaced by enforcer.md — gatekeeper role was never invoked |
| 3 | `.claude/agents/sentinel.md` | `archive/nexxus2_1/old-agents/sentinel.md` | Replaced by enforcer.md — sentinel merged into enforcer |
| 4 | `.claude/agents/builder.md` | `archive/nexxus2_1/old-agents/builder.md` | Replaced by new builder specs in agent_team.md |
| 5 | `.claude/agents/orchestrator.md` | `archive/nexxus2_1/old-agents/orchestrator.md` | Replaced by new orchestrator spec in agent_team.md |
| 6 | `CLAUDE.md` (backup before edit) | `archive/nexxus2_1/CLAUDE.md.pre-enforcer` | Pre-enforcer version preserved before owner edits |
| 7 | `.claude/projects/*/memory/session-state.md` | `archive/nexxus2_1/old-memory/session-state.md` | Contaminated session state from unauthorized session |
| 8 | `.claude/projects/*/memory/gate-keeper-sprint-b2.md` | `archive/nexxus2_1/old-memory/gate-keeper-sprint-b2.md` | From contaminated session — fabricated GK claims |

---

## Files to Delete (No Archive Value)

| # | Path | Reason |
|---|------|--------|
| 1 | `docs/RELEASE_PLAN.md` | Shadow copy — agent-modified, autonomy self-upgraded to L3. Authoritative version preserved at `filestore/nexxus_authoritative_plan/1a_RELEASE_PLAN.md`. Will be gone after rollback to 95c0290 anyway — verify absence after rollback. |

---

## Files That Stay (Not Archived, Not Deleted)

| Path | Reason |
|------|--------|
| `.claude/settings.local.json` | Contains permissions only (allow list for Bash commands). Coexists with new settings.json for hooks. |
| `filestore/nexxus_authoritative_plan/*` | Authoritative plan files — untouched, remain as source of truth |
| `filestore/final_testing_kit/*` | Testing kit — 11 files used for AC reconciliation and test batteries |
| `filestore/nexus-v2-1-current/*` | Reference UI — immutable spec (Tier 1 truth) |
| `database/migrations/001-040` | Migration files — remain in version control even after rollback |

---

## Archive Commands

Execute these during Phase 2 of the recovery plan (after the new session starts):

```bash
# Create archive subdirectories
mkdir -p ~/Claude-store/filestore/archive/nexxus2_1/old-agents
mkdir -p ~/Claude-store/filestore/archive/nexxus2_1/old-memory

# Archive old agents
cp .claude/agents/FRAMEWORK.md ~/Claude-store/filestore/archive/nexxus2_1/old-agents/
cp .claude/agents/gatekeeper.md ~/Claude-store/filestore/archive/nexxus2_1/old-agents/
cp .claude/agents/sentinel.md ~/Claude-store/filestore/archive/nexxus2_1/old-agents/
cp .claude/agents/builder.md ~/Claude-store/filestore/archive/nexxus2_1/old-agents/
cp .claude/agents/orchestrator.md ~/Claude-store/filestore/archive/nexxus2_1/old-agents/

# Remove archived agents from active location
rm .claude/agents/FRAMEWORK.md
rm .claude/agents/gatekeeper.md
rm .claude/agents/sentinel.md
rm .claude/agents/builder.md
rm .claude/agents/orchestrator.md

# Archive old memory files (path may vary — check .claude/projects/ structure)
find .claude/projects/ -name "session-state.md" -exec cp {} ~/Claude-store/filestore/archive/nexxus2_1/old-memory/session-state.md \;
find .claude/projects/ -name "gate-keeper-sprint-b2.md" -exec cp {} ~/Claude-store/filestore/archive/nexxus2_1/old-memory/gate-keeper-sprint-b2.md \;

# Verify archive
ls -la ~/Claude-store/filestore/archive/nexxus2_1/old-agents/
ls -la ~/Claude-store/filestore/archive/nexxus2_1/old-memory/
```

---

## Existing Archive Contents

The archive directory already has these subdirectories (from before this recovery):

```
~/Claude-store/filestore/archive/nexxus2_1/
├── [existing subdirectories — 4 found during exploration]
├── work_to_review.patch          ← backed up 2026-03-01
├── CLAUDE.md.pre-enforcer        ← created during Phase 1
├── old-agents/                   ← created during Phase 2
│   ├── FRAMEWORK.md
│   ├── gatekeeper.md
│   ├── sentinel.md
│   ├── builder.md
│   └── orchestrator.md
└── old-memory/                   ← created during Phase 2
    ├── session-state.md
    └── gate-keeper-sprint-b2.md
```

---

## Verification Checklist

After archival during the recovery:
- [ ] All 5 old agent files exist in `archive/nexxus2_1/old-agents/`
- [ ] All 5 old agent files removed from `.claude/agents/`
- [ ] Only `enforcer.md` remains in `.claude/agents/`
- [ ] Old memory files archived
- [ ] `docs/RELEASE_PLAN.md` does not exist after rollback (verify)
- [ ] `settings.local.json` still in place (permissions)
- [ ] `settings.json` installed (hooks)
- [ ] Patch file exists in archive
- [ ] CLAUDE.md.pre-enforcer exists in archive
