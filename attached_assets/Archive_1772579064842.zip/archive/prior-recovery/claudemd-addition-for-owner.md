# CLAUDE.md Addition — For Owner to Apply

Since CLAUDE.md is chmod 444 (read-only, owner-only), paste these lines into the nexxus-v2
CLAUDE.md at the appropriate location. The owner edits this in a terminal, not through Claude Code.

---

## Where to Add

After the "## CRITICAL LIVE FEATURE" section (around line 139), add:

```markdown
---

## METHOD ENFORCEMENT (Test Batteries)

Test batteries (B1-B6) are governed by method tiers defined in `.agent_docs/method_tiers.md`.

Every test case has a BINDING method assignment (M1-M5b). Using a lower tier when a higher
tier is available (e.g., M4 code analysis when M1 Playwright is available) is an automatic
enforcer blocker (Rules 8-15 in `.claude/agents/enforcer.md`).

Key rules:
- M1 (Playwright MCP) mandatory for all UI tests
- M2 (API round-trip) mandatory for all integration tests
- Every TC requires 2-delta proof (two independent evidence channels)
- M5a (automated precursor) must complete before any TC marked PENDING-OWNER
- Gap register: `filestore/final_testing_kit/release_criteria.md`
- Gap ID format: `GAP-B{battery}-{COMPONENT}-{NNN}`

This enforcement was installed 2026-03-01 after the initial battery run produced zero
browser interactions, zero API round-trips, and zero screenshots despite having all
tools available.
```

---

## Optional but Recommended

No other CLAUDE.md changes are needed. The enforcer rules, battery specs, MTC, quality gates,
and safety gates all reference `.agent_docs/method_tiers.md` as the authoritative source.
Adding this section to CLAUDE.md ensures any new session reads it immediately on startup
(CLAUDE.md is auto-loaded; method_tiers.md requires explicit reading).
