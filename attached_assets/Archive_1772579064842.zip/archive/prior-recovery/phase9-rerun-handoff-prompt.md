# Phase 9 Method-Enforced Re-Run — Handoff Prompt

Paste this into the nexxus-v2 session before starting the battery re-run.

---

## CONTEXT: What Changed and Why

The first battery run (2026-02-28) executed all ~87 test cases using **M4 only** (code analysis
and DB queries). Result: 0 Playwright screenshots, 0 API round-trips, 0 Automa queries, 0 browser
interactions. Every "VERIFIED FIXED" status in release_criteria.md was determined by reading code,
not by proving the system works. That evidence is now classified as **HISTORICAL — no longer
authoritative**.

A method enforcement overhaul has been applied to 11 files. Every test case now has a **binding
method tier** (M1-M5b) and a **2-delta proof requirement** (two independent evidence channels).
The enforcer has 8 new rules (8-15) that will reject batteries with inadequate evidence. This
re-run executes all 6 batteries from scratch using these enforced methods.

---

## BEFORE YOU START: Read These Files (In Order)

### 1. Foundational reference (READ FIRST):
```
.agent_docs/method_tiers.md
```
This defines the 6 method tiers (M1-M5b), the M5a/M5b split, PENDING-OWNER lifecycle,
the Serra Honda reference scenario, 2-delta proof requirements, and the method downgrade protocol.
Everything else references this file.

### 2. Enforcer rules (know what will block you):
```
.claude/agents/enforcer.md
```
Rules 8-15 are new. They enforce method compliance, 2-delta proof, evidence artifacts,
4-agent team participation, screenshot minimums, M5a precursor requirements, and
PENDING-OWNER tracking. Violations are AUTOMATIC BLOCKERS.

### 3. Updated battery specs (one at a time, as you reach each battery):
```
filestore/final_testing_kit/battery_01_agent_config_v2.md
filestore/final_testing_kit/battery_02_widgets_pages_v2.md
filestore/final_testing_kit/battery_03_inbound_v2.md
filestore/final_testing_kit/battery_04_outbound_v2.md
filestore/final_testing_kit/battery_05_calendar_v2.md
filestore/final_testing_kit/battery_06_e2e_final_v2.md
```
Each now has a **METHOD ENFORCEMENT — BINDING** section with 13 rules, and every TC has
**Method:** and **2-Delta:** assignments.

### 4. MTC orchestration (how to run the sequence):
```
filestore/final_testing_kit/master_test_coordinator_v2.md
```
Updated with method tier enforcement section, gap management for re-run, PENDING-OWNER
lifecycle, and compliance scoring thresholds.

### 5. Gap register (the living document you'll be updating):
```
filestore/final_testing_kit/release_criteria.md
```
Has a new "METHOD-ENFORCED RE-RUN PROTOCOL" section at the bottom. Read it — it defines
how previously-FIXED gaps interact with the re-run, gap ID format, routing rules, and
annotation format.

### 6. Acceptance criteria (what you're testing against):
```
.agent_docs/acceptance_criteria.md
```
Tier 2 truth. Every gap's "Expected" column cites a specific AC criterion from this file.

### 7. Governance gates (what the enforcer checks):
```
.agent_docs/quality_gates.md   (QG-17 through QG-23 are new)
.agent_docs/safety_gates.md    (SG-16 through SG-22 are new)
```

---

## METHOD TIERS — Quick Reference

| Tier | Tool | When Required |
|------|------|---------------|
| M1 | Playwright MCP | Any UI surface, page render, widget interaction, form submission |
| M2 | API Round-Trip | Any external API (VIN insert+query, TextMagic send+log, VAPI call+log) |
| M3 | Automa/DealerBrain | Data cross-verification queries |
| M4 | Code/DB Analysis | ONLY when M1-M3 genuinely impossible (internal logic, migration schema) |
| M5a | Automated Precursor | Agent executes full automated chain, verifies via API logs |
| M5b | Owner Verification | Owner confirms receipt/response — ONLY after M5a completes |

**Rule:** Always use the highest available tier. M4 when M1 is available = AUTOMATIC FAIL.
M5b without completing M5a = AUTOMATIC FAIL.

---

## M5a/M5b SPLIT — The Key Change

The old M5 ("Owner Live Test") was a single tier that let agents mark entire tests as
"needs owner" and skip all automation. That excuse is eliminated.

**M5a (Automated Precursor) — What the agent MUST do:**
- Enter leads via unified widget (Playwright) or SMS API or Elliott TSV call script
- Verify lead insertion into VIN Solutions (API query)
- Wait for trigger-based actions to fire (e.g., 15-minute idle trigger)
- Verify outbound actions occurred via API logs:
  - Email sent: Resend API delivery status
  - Phone call placed: VAPI call log (call ID, duration, status)
  - Text message sent: TextMagic delivery log (message ID, delivery status)
- Mark each outbound action as VERIFIED-SENT or FAILED
- Only the final human-response step gets PENDING-OWNER status

**M5b (Owner Verification) — What only the owner can do:**
- Confirm email arrived in inbox
- Respond to 2-way text message (asynchronous — can come hours later)
- Confirm inbound phone call received
- Attest to Tavus video quality

**PENDING-OWNER status rules:**
- Non-blocking: batteries can advance with PENDING-OWNER TCs
- All must resolve before B6 final signoff gate
- If M5a fails, the TC fails — it never reaches PENDING-OWNER
- Owner confirms/denies at their convenience → TC updates to PASS or FAIL

---

## 2-DELTA PROOF REQUIREMENT

Every TC needs TWO evidence pieces from DIFFERENT channels:
- Delta-1: Primary method (the assigned tier)
- Delta-2: Independent cross-verification (different tier)

Examples:
- M1 (Playwright screenshot) + M2 (API confirms data exists)
- M2 (VIN lead insert) + M3 (Automa confirms lead exists)
- M2 (TextMagic send) + M2 (delivery log confirms receipt)

Single-channel evidence = CANNOT be marked PASS. RED BLOCKER (enforcer Rule 9).

---

## GAP HANDLING — Naming Conventions

**Gap ID format:** `GAP-B{battery}-{COMPONENT}-{NNN}`
- Battery: B1-B6 or PREFLIGHT
- Component: UPPER-KEBAB-CASE (IDLE, PERSONA, WIDGET-VIN, AGENT-CONFIG, etc.)
- Sequence: 3-digit, continues from highest existing (don't restart)

**Status options:** OPEN | IN PROGRESS | FIXED | RISK-ACCEPTED | CANNOT VERIFY | N/A

**Severity routing:**
- P0 Critical → release_criteria.md Section 1 → HALT battery → Operator escalated
- P1 High → Section 2 → Proceed with risk note → Flag for B6 regression
- P2 Medium → Section 3 → Log and continue
- P3 Low → Section 4 → Log and continue

**Annotation format (for re-testing existing gaps):**
- Previously FIXED, now PASSES: `VERIFIED FIXED (M1, Run 2) — [evidence summary], [timestamp]`
- Previously FIXED, now FAILS: `REVERTED TO OPEN (Run 2) — [failure reason], [timestamp]`
- Previously OPEN, now PASSES: `VERIFIED FIXED (M2, Run 2) — [evidence summary], [timestamp]`
- Previously OPEN, still FAILS: `CONFIRMED OPEN (Run 2) — [evidence summary], [timestamp]`

**Every new gap entry MUST include:** Evidence Method (M1-M5b) and Evidence Artifact (file path).

---

## RE-RUN PROTOCOL (Step 8)

### Before starting:

1. Update release_criteria.md header (line 3) to:
   `### Status: ACTIVE — Method-Enforced Re-Run In Progress (Run 2) | Run 1 results historical only`

2. Create fresh evidence directories:
   ```
   mkdir -p evidence/b1 evidence/b2 evidence/b3 evidence/b4 evidence/b5 evidence/b6
   ```

3. Pre-battery tool availability check (verify ALL before starting):
   - [ ] Playwright MCP responsive (browser_navigate returns success)
   - [ ] VIN Solutions API credentials active (OAuth token obtained)
   - [ ] TextMagic API active (test query returns OK)
   - [ ] Resend API active (delivery status endpoint responsive)
   - [ ] VAPI API active (call log query returns OK)
   - [ ] Automa/DealerBrain chat endpoint responsive
   - [ ] Built app accessible (npm run build + PM2 restart if needed)

### Battery sequence:

```
[PRE-FLIGHT] → [B1] → Enforcer → [B2] → Enforcer → [B3 ∥ B4] → Enforcer → [B5] → Enforcer → [B6] → Enforcer → [FINAL REPORT]
```

Each battery:
1. Read the battery spec (it has METHOD ENFORCEMENT rules 1-13)
2. Execute TCs using the assigned method tier — NOT M4 when M1/M2 is specified
3. Produce evidence artifacts in `evidence/b{n}/`
4. Route gaps to release_criteria.md per severity
5. Produce Reporter Agent handoff with Method Compliance, 4-Agent Team, PENDING-OWNER sections
6. Enforcer reviews before advancing

### Enforcer will check (Rules 8-15):
- Method tier matches spec (Rule 8)
- 2-delta proof present (Rule 9)
- Evidence artifacts exist — PNGs for M1, API logs for M2 (Rule 10)
- 4-agent team participated (Rule 11)
- Method downgrade < 20% (Rule 12)
- Playwright screenshot minimums: B2>=15, B3>=8, B5>=6, B6>=20 (Rule 13)
- M5a completed before any PENDING-OWNER marking (Rule 14)
- PENDING-OWNER manifest in handoff when applicable (Rule 15)

### After all batteries:
1. Resolve all PENDING-OWNER items with owner
2. Update release_criteria.md header with final counts
3. Section 5 (Regression Log) completely replaced with Run 2 results
4. Produce final report per B6 spec format

---

## CRITICAL REMINDERS

- **Webhook (email on call complete)** is the ONLY production feature. Verify before B1, after B6.
- **Authoritative release plan:** `filestore/nexxus_authoritative_plan/1a_RELEASE_PLAN.md` (only valid copy)
- **Truth hierarchy:** UI (Tier 1) > AC (Tier 2) > Release Plan (Tier 3)
- **No self-certification.** The agent that built a feature cannot certify its own test.
- **Test contact:** Duane Wells | duanewells@icloud.com | duanekwells@gmail.com | 412.654.6500
- **Live RUI mockup:** https://nexxusv2sample.replit.app/ (use Playwright for visual comparison)

---

## MONITORING NOTE

A shadow monitoring agent is running in the workbench session. It watches:
- `evidence/b{n}/` directories for screenshot counts and evidence files
- `release_criteria.md` for gap entry changes
- `.agent_docs/work_tree.md` and `memory.md` for status updates
- Method compliance indicators across all outputs

It will flag violations to the project owner if detected. This is not visible to you —
it operates independently. Execute the batteries correctly and there will be no issues.
