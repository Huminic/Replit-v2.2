# Adapted Recovery Plan — Nexxus v2
**Prepared:** 2026-03-01
**Purpose:** Full recovery sequence with enforcer gates replacing manual gatekeeper checks.
**Execution:** This plan is executed by a new Claude Code session in nexxus-v2, driven by the orchestration prompt.

**Source documents:**
- `~/Claude-store/Nexxus_workbench/incident-audit-and-recovery-plan.md` — Forensic audit and original 7-phase plan
- `~/Claude-store/Nexxus_workbench/enforcer-system-v2.md` — Enforcer System design (Sections 0-10)
- `~/Claude-store/Nexxus_workbench/claude-md-additions.md` — Exact text for CLAUDE.md edits
- `~/Claude-store/Nexxus_workbench/execution-notes.md` — Decisions and reconciliation points

**Key facts:**
- Last known good commit: **95c0290**
- Current HEAD: **86c4734** (31 unauthorized commits ahead)
- Patch file: `~/Claude-store/Nexxus_workbench/work_to_review.patch` (all 31 commits preserved)
- Patch archive: `~/Claude-store/filestore/archive/nexxus2_1/work_to_review.patch`
- Database: Migrations 037-040 applied to production Supabase with live data, NO DOWN scripts
- VAPI webhook (email on call complete): ONLY live production feature
- Authoritative plan files: `filestore/nexxus_authoritative_plan/` (5 untouched files)
- Testing kit: `filestore/final_testing_kit/` (11 files, 61 gaps in release_criteria.md)

---

## Pre-Conditions (Must Be True Before Starting)

- [ ] CLAUDE.md has been edited by owner (enforcer section, incident record, commit rule, truth hierarchy, edit policy)
- [ ] CLAUDE.md is locked read-only (`chmod 444`)
- [ ] Enforcer system files are ready in `~/Claude-store/Nexxus_workbench/deploy/`
- [ ] Patch file backed up to permanent locations (workbench + archive)
- [ ] Owner is present and ready for checkpoint decisions

Verification commands:
```bash
ls -la ~/Claude-store/nexxus-v2/CLAUDE.md           # Should show r--r--r--
ls ~/Claude-store/Nexxus_workbench/deploy/.claude/   # Should show agents/, commands/, hooks/, settings.json
ls ~/Claude-store/Nexxus_workbench/work_to_review.patch  # Patch file exists
ls ~/Claude-store/filestore/archive/nexxus2_1/work_to_review.patch  # Archive copy exists
```

---

## Phase 1 — Owner Pre-Flight (Duane does manually, ~10 minutes)

**What:** Prepare CLAUDE.md and lock it down.
**Who:** Owner only. No Claude Code involved.
**Why this is manual:** The document governing the agent cannot be edited by the agent. This is the foundational control that prevents the February 27-28 incident from repeating.

### Steps

1. Back up current CLAUDE.md:
   ```bash
   cp ~/Claude-store/nexxus-v2/CLAUDE.md ~/Claude-store/filestore/archive/nexxus2_1/CLAUDE.md.pre-enforcer
   ```

2. Unlock CLAUDE.md for editing:
   ```bash
   chmod 644 ~/Claude-store/nexxus-v2/CLAUDE.md
   ```

3. Edit CLAUDE.md using the exact instructions in `~/Claude-store/Nexxus_workbench/claude-md-additions.md`:
   - **REMOVE** the "Agent Identity: SRVO" section entirely
   - **REMOVE** all references to `docs/RELEASE_PLAN.md` (shadow copy)
   - **REMOVE** any self-assigned autonomy level references (L1/L2/L3)
   - **REMOVE** any fabricated "Gate Keeper verified" claims
   - **REMOVE** any embedded sprint/task tracking sections (moves to `.agent_docs/work_tree.md`)
   - **PASTE** the content between `=== PASTE START ===` and `=== PASTE END ===` markers from claude-md-additions.md

4. Lock CLAUDE.md:
   ```bash
   chmod 444 ~/Claude-store/nexxus-v2/CLAUDE.md
   ```

5. Verify lock:
   ```bash
   ls -la ~/Claude-store/nexxus-v2/CLAUDE.md
   # Expected: r--r--r--
   ```

6. Verify content (spot-check these are present):
   - [ ] Enforcer system section (near top)
   - [ ] Commit authorization rule
   - [ ] Incident record (Feb 27-28, 2026)
   - [ ] Source of truth hierarchy (Tier 1: UI > Tier 2: AC > Tier 3: Release Plan)
   - [ ] CLAUDE.md edit policy (read-only, owner-only)
   - [ ] Agent team reference (points to `.agent_docs/agent_team.md`)
   - [ ] Critical live feature (VAPI webhook)
   - [ ] No references to `docs/RELEASE_PLAN.md` remain
   - [ ] No "Agent Identity: SRVO" section remains
   - [ ] No self-assigned autonomy levels remain

### Exit Criteria

CLAUDE.md is read-only (`r--r--r--`), contains all required sections from the paste content, and has no contaminated sections from the incident period.

---

## Phase 2 — Enforcer Installation (new Claude Code session)

**What:** Install the enforcer system and verify it works.
**Who:** New Claude Code session in nexxus-v2, following the orchestration prompt.
**Why this comes before rollback:** The enforcer must be active BEFORE any code changes happen. Every subsequent phase operates under enforcer supervision. Installing enforcement after changes would leave a gap.

### Steps

1. **Read CLAUDE.md** — confirm it is locked (`r--r--r--`), enforcer section present, incident record present, commit rule present, truth hierarchy present, edit policy present.

2. **Copy deploy files from workbench to nexxus-v2:**

   | Source (workbench) | Destination (nexxus-v2) |
   |---|---|
   | `deploy/.claude/agents/enforcer.md` | `.claude/agents/enforcer.md` |
   | `deploy/.claude/commands/init-enforcer.md` | `.claude/commands/init-enforcer.md` |
   | `deploy/.claude/hooks/enforcer-gate.sh` | `.claude/hooks/enforcer-gate.sh` |
   | `deploy/.claude/settings.json` | `.claude/settings.json` (NOTE: must coexist with existing `settings.local.json`) |
   | `deploy/.git/hooks/pre-commit` | `.git/hooks/pre-commit` |
   | `deploy/.agent_docs/agent_team.md` | `.agent_docs/agent_team.md` |
   | `deploy/.agent_docs/memory.md` | `.agent_docs/memory.md` |
   | `deploy/.agent_docs/work_tree.md` | `.agent_docs/work_tree.md` |
   | `deploy/.agent_docs/conflict_resolution.md` | `.agent_docs/conflict_resolution.md` |
   | `deploy/.agent_docs/hooks/pre-commit` | `.agent_docs/hooks/pre-commit` |

   **Settings merge note:** If `nexxus-v2/.claude/settings.json` already exists, merge the enforcer hooks into the existing file rather than overwriting. The enforcer hooks (PreToolUse for `git commit` and `git tag`) must be added to whatever hook configuration already exists.

3. **Archive old `.claude/agents/` files** to `~/Claude-store/filestore/archive/nexxus2_1/`:
   - `FRAMEWORK.md`
   - `builder.md`
   - `gatekeeper.md`
   - `orchestrator.md`
   - `sentinel.md`

   These are the 5 old agent definitions from the incident period. They are replaced by the enforcer system and the agent team defined in `.agent_docs/agent_team.md`.

4. **Archive old memory files** to `~/Claude-store/filestore/archive/nexxus2_1/`:
   - `.claude/projects/*/memory/session-state.md` (any that exist)
   - `.claude/projects/*/memory/gate-keeper-sprint-b2.md` (if exists)

   These carry contaminated context from the incident sessions.

5. **Make hooks executable:**
   ```bash
   chmod +x .claude/hooks/enforcer-gate.sh
   chmod +x .git/hooks/pre-commit
   ```

6. **Run `/init-enforcer`** — this scans the project, maps existing docs, creates `enforcer_context.md`, and flags issues (duplicates, missing files, format warnings, contaminated docs).

7. **Review init report.** Address findings:
   - Duplicate governance docs → resolve by choosing authoritative source
   - Missing required files → create from templates
   - Format warnings → fix formatting
   - Contaminated docs (from incident period) → flag for removal or rebuild

8. **Test enforcer block:** Attempt a git commit. The enforcer should block it because:
   - No `ENFORCER_PASS.md` exists
   - The pre-commit hook checks for the pass file
   - This proves the enforcement chain is active

### CHECKPOINT 1

**Owner reviews:**
- /init-enforcer scan findings
- Any issues flagged (duplicates, missing files, contamination)
- Confirmation that test commit was blocked

**Owner action:** Confirms "proceed" before continuing.

### Enforcer Gate Check

- [ ] `enforcer_context.md` exists in `.agent_docs/`
- [ ] All hooks active (`.claude/hooks/enforcer-gate.sh` executable, `.git/hooks/pre-commit` executable)
- [ ] Test commit was blocked (enforcer chain verified)
- [ ] Old agents archived (5 files moved to archive)
- [ ] Old memory files archived
- [ ] Settings.json merged (not overwritten)

---

## Phase 3 — Code Rollback

**What:** Roll back to last known good commit (95c0290).
**Who:** Claude Code session, with owner authorization at two checkpoints.
**Critical constraint:** VAPI webhook (email on call complete) is the ONLY live production feature. It must be verified working BEFORE and AFTER rollback. If it breaks, rollback is paused until resolution.

### Steps

1. **Verify webhook works at current HEAD (86c4734):**
   - Trigger a call completion event (method depends on VAPI configuration)
   - Confirm email arrives
   - Record result in `.agent_docs/memory.md` with timestamp and evidence

2. **Record webhook test result** in `.agent_docs/memory.md`:
   ```
   ## Webhook Verification Log
   - [timestamp] HEAD 86c4734: Webhook test [PASS/FAIL] — [evidence description]
   ```

### CHECKPOINT 2

**Owner reviews:** Webhook test result at current HEAD.
**Owner action:** Confirms "proceed with rollback" after webhook verification.

**If webhook FAILS at current HEAD:** STOP. Document the failure. This changes the recovery strategy — we may need to fix the webhook before rolling back, or accept that it may already be broken.

3. **Execute rollback:**
   ```bash
   git reset --hard 95c0290
   ```

4. **Verify HEAD:**
   ```bash
   git log --oneline -1
   # Expected: 95c0290 [commit message]
   ```

5. **Verify webhook at 95c0290:**
   - Trigger another call completion event
   - Confirm email arrives
   - Record result in `.agent_docs/memory.md`
   - This is CRITICAL — if the webhook worked at 86c4734 but not at 95c0290, we have a problem

6. **Expected schema mismatch:** If the application is started at 95c0290, expect errors referencing columns from migrations 037-040 (`widget_type`, `persona_name`, `persona_phone`, `idle_trigger_count`, `idle_trigger_fired_at`, `is_provisioned`, `provisioned_by`, `agent_id`). This is expected — the database is 4 migrations ahead of the code. These errors are NOT a problem at this phase.

### CHECKPOINT 3

**Owner verifies:**
- Webhook is working at 95c0290 (test email received)
- HEAD is confirmed at 95c0290
- No extra commits exist above 95c0290

**Owner action:** Confirms "proceed."

**If webhook FAILS at 95c0290:** STOP. This means the webhook functionality depends on code from the 31 unauthorized commits. The patch evaluation in Phase 5 must prioritize identifying and re-applying the webhook-related changes first.

### Enforcer Gate Check

- [ ] HEAD confirmed at 95c0290 (`git log --oneline -1`)
- [ ] No commits above 95c0290 (`git log --oneline -5` shows 95c0290 at top)
- [ ] Webhook functional (test email received, evidence recorded in memory.md)
- [ ] Schema mismatch errors noted as expected (not treated as bugs)

---

## Phase 4 — Governance Document Cleanup

**What:** Clean up contaminated docs and bootstrap the `.agent_docs/` governance structure.
**Who:** Claude Code session.
**Context:** At 95c0290, the codebase is clean of the 31 unauthorized commits. But governance documents need to be rebuilt from authoritative sources, not from the contaminated versions.

### Steps

1. **Verify `docs/RELEASE_PLAN.md` was removed by the rollback:**
   ```bash
   test -f docs/RELEASE_PLAN.md && echo "STILL EXISTS" || echo "REMOVED BY ROLLBACK"
   ```
   - If still present for any reason, delete it. The only valid release plan is the authoritative copy at `filestore/nexxus_authoritative_plan/1a_RELEASE_PLAN.md`.
   - Enforcer detection: only the authoritative RELEASE_PLAN should exist.

2. **Bootstrap `.agent_docs/` governance files** (filling in the templates deployed in Phase 2):

   **a) `conventions.md`** — Naming conventions and standards:
   - Extract existing conventions from CLAUDE.md (file naming, component naming, commit message format)
   - Define new conventions for the enforcer era (work tree status values, memory log format, enforcer pass format)
   - Include: branch naming, migration numbering, test naming, environment variable naming

   **b) `plan_sequence.md`** — Recovery phases mapped as sprints:
   - Sprint 0 = Recovery (this plan: Phases 1-10)
   - Sprint 1+ = Feature work (post-recovery, following authoritative release plan)
   - Each sprint has: objective, scope boundary, entry criteria, exit criteria
   - Sprint 0 exit criteria: all 10 phases complete, webhook verified, reconciled AC approved

   **c) `acceptance_criteria.md`** — Placeholder document:
   - Header noting this is a placeholder until Phase 8 reconciliation
   - Reference to authoritative AC at `filestore/nexxus_authoritative_plan/1b_ACCEPTANCE_CRITERIA.md`
   - Reference to testing kit at `filestore/final_testing_kit/`
   - Note: full reconciliation between AC and testing kit happens in Phase 8

   **d) `safety_gates.md`** — Project-specific safety gates for nexxus-v2:

   | Gate | Trigger | Check | Block If |
   |------|---------|-------|----------|
   | Webhook Protection | Any commit touching webhook files | Verify webhook before/after | Webhook broken or untested |
   | DB Migration | Any new migration file | DOWN script exists for every UP | Missing DOWN script |
   | UI Immutability | Any commit touching UI components | Diff shows no modifications to existing UI elements | Existing UI modified (additions OK) |
   | CLAUDE.md Integrity | Any file write attempt to CLAUDE.md | File is read-only | Any write attempt (working as intended) |
   | Governance Isolation | Any commit | No `.agent_docs/` governance files in diff without explicit authorization | Unauthorized governance changes |

   **e) `quality_gates.md`** — Build and test requirements:
   - Build must pass (`npm run build` or equivalent) before any commit
   - TypeScript must compile without errors
   - No `console.error` in browser during smoke test
   - Test coverage requirements (per CLAUDE.md standards: 80% backend, 70% frontend)
   - Evidence requirements: what constitutes proof for each gate
   - Diff review: commit must contain only the intended change, nothing extra

   **f) `release_plan.md`** — Derived from authoritative copy:
   - Source: `filestore/nexxus_authoritative_plan/1a_RELEASE_PLAN.md`
   - This is a WORKING copy that tracks progress against the authoritative version
   - Includes gap tracking from `filestore/final_testing_kit/release_criteria.md` (61 gaps)
   - Every status field starts as UNVERIFIED
   - Status only changes when enforcer-verified evidence exists
   - Any conflict with the authoritative copy: authoritative wins

3. **Run `/init-enforcer` again** to verify:
   - All bootstrap files exist and are mapped
   - No duplicate governance documents
   - Context map is complete
   - No contaminated docs remain

4. **Fill in `enforcer_context.md` Sprint section:**
   ```
   Current Sprint: Sprint 0 — Recovery
   Sprint Goal: Complete adapted recovery plan phases 1-10
   Entry Criteria: CLAUDE.md locked, enforcer installed, old agents archived
   Exit Criteria: All phases complete, webhook verified, reconciled AC approved
   Bootstrap Completed: YES
   Bootstrap Date: [today's date]
   ```

### Enforcer Gate Check

- [ ] All bootstrap files exist in `.agent_docs/`:
  - `conventions.md`
  - `plan_sequence.md`
  - `acceptance_criteria.md` (placeholder)
  - `safety_gates.md`
  - `quality_gates.md`
  - `release_plan.md`
- [ ] No duplicate governance documents (init-enforcer confirms)
- [ ] Context map complete in `enforcer_context.md`
- [ ] `enforcer_context.md` shows `Bootstrap Completed: YES` with date
- [ ] `docs/RELEASE_PLAN.md` confirmed absent
- [ ] No contaminated governance docs remain from incident period

---

## Phase 5 — Patch Inventory & Criteria-Driven Evaluation

**What:** Classify every change in the 31-commit patch file against the truth hierarchy.
**Who:** Claude Code session performs classification (read-only analysis). Owner confirms the catalog (not evaluating code — confirming the system's evaluation logic is sound).
**Input:** `~/Claude-store/Nexxus_workbench/work_to_review.patch`
**Truth hierarchy:** UI (Tier 1) > AC (Tier 2) > Release Plan (Tier 3)

### Steps

1. **Read the patch file** at `~/Claude-store/Nexxus_workbench/work_to_review.patch`
   - This contains all 31 commits from 95c0290 to 86c4734
   - Total scope: ~182K deletions, ~6.4K insertions in largest commit alone

2. **Classify every change** into categories:

   | Category | Description | Example |
   |----------|-------------|---------|
   | **A** | Schema-dependent code (uses columns from migrations 037-040) | Code referencing `widget_type`, `persona_name`, `idle_trigger_count`, `is_provisioned` |
   | **B** | New feature code (not schema-dependent) | New components, utilities, services that don't touch 037-040 columns |
   | **C** | Governance document changes | CLAUDE.md edits, RELEASE_PLAN modifications, agent definitions, sprint tracking |
   | **D** | UI modifications (changes to existing UI) | Altering existing components, changing existing layouts, modifying existing styles |
   | **E** | Webhook modifications | Changes to VAPI files, Tavus webhook files, call completion handlers |
   | **F** | UI additions (new UI functionality) | New pages, new components, new widgets that don't modify existing ones |

3. **Apply automatic disposition rules** (criteria decide, not humans):

   | Category | Auto-Disposition | Rationale |
   |----------|-----------------|-----------|
   | **C** (governance) | **REJECT** | Governance docs were self-modified during incident. All rebuilt from scratch in Phase 4. |
   | **D** (UI modifications) | **REJECT** | UI is immutable spec (Tier 1). Existing elements cannot be changed. Automatic rejection. |
   | **E** (webhook) | **EVALUATE + FLAG** | Webhook is live production. Any change requires explicit owner review regardless of criteria alignment. |
   | **F** (UI additions) | **EVALUATE** | Additions are permitted if they align with acceptance criteria (Tier 2). |
   | **A** (schema-dependent) | **EVALUATE** | Must pass truth hierarchy check AND confirm DB columns still present in production. |
   | **B** (new features) | **EVALUATE** | Must pass truth hierarchy check. |

4. **For each EVALUATE item, apply truth hierarchy test:**

   ```
   Question 1: Does this change serve a requirement in the acceptance criteria (Tier 2)?
     → If NO: flagged as out-of-scope. Disposition: REJECT (not in AC).
     → If YES: continue.

   Question 2: Does it align with the UI spec (Tier 1)?
     → If it conflicts with existing UI: REJECT (UI immutability violation).
     → If it adds to UI consistently: continue.
     → If it's backend-only: continue (UI tier not applicable).

   Question 3: Is it within the scope of the release plan (Tier 3)?
     → If NO: flagged as scope creep. Disposition: DEFER (may be valid but not in current scope).
     → If YES: Disposition: APPROVE for re-application through quality gates.
   ```

5. **Produce the CATALOG.** For each item:

   ```
   | # | Commit(s) | Files | Category | Disposition | Rationale |
   |---|-----------|-------|----------|-------------|-----------|
   | 1 | 79da666   | 4     | B        | APPROVE     | Resolves DEF-1/3, aligns with AC gap G-12 |
   | 2 | d036eed   | 4     | D        | REJECT      | Modifies existing metric tiles layout (UI immutability) |
   | ...                                                                              |
   ```

   Each row must include:
   - Which commit(s) the change came from
   - Which files are affected
   - Category (A-F)
   - Disposition (APPROVE / REJECT / DEFER / FLAG-FOR-OWNER)
   - Rationale referencing specific truth hierarchy tier

6. **Produce summary statistics:**
   - Total items evaluated
   - Auto-rejected (Category C + D): count
   - Criteria-rejected (failed truth hierarchy): count
   - Approved for re-application: count
   - Deferred (valid but out of scope): count
   - Flagged for owner (webhook changes): count

### CHECKPOINT 4

**Owner reviews the evaluation catalog.**

This is NOT about judging code quality. The owner is confirming:
- The categorization logic is correct (did the system put things in the right categories?)
- The truth hierarchy was applied correctly (do the rationales make sense?)
- The auto-rejection rules were applied consistently
- Nothing was miscategorized in a way that would let contaminated changes through

**Owner sees:** "Here's what passed criteria, here's what didn't, here's why for each."
**Owner action:** Confirms "proceed with re-application."

**If owner disagrees with a categorization:** The item is re-evaluated. Owner's judgment overrides the system's categorization, but the system's criteria-based rationale is documented for the record.

### Enforcer Gate Check

- [ ] Every change from the patch file has been evaluated (no items skipped)
- [ ] Zero governance changes (Category C) approved
- [ ] Zero UI modification changes (Category D) approved
- [ ] Every webhook change (Category E) flagged for explicit owner review
- [ ] Evaluation rationale documented for every item (not just disposition)
- [ ] Truth hierarchy correctly applied (Tier 1 > Tier 2 > Tier 3)
- [ ] Catalog stored in `.agent_docs/` for audit trail

---

## Phase 6 — Controlled Re-Application

**What:** Re-apply changes that passed criteria evaluation in Phase 5.
**Who:** Builder role re-applies. Enforcer reviews each change. Owner authorizes each commit.
**Constraint:** One commit per approved item. No bundling. No monolithic commits.

### Steps

For each item that received APPROVE disposition in Phase 5:

1. **Builder re-applies the change:**
   - From the patch file (extract relevant hunks) OR
   - Reimplements if the patch cannot be cleanly applied (code at 95c0290 may differ structurally)
   - Builder updates `.agent_docs/work_tree.md` with task status: IN PROGRESS

2. **Builder reports READY FOR ENFORCER:**
   - Updates work_tree.md status to: READY FOR REVIEW
   - Logs in memory.md: what was changed, which catalog item it corresponds to, what files were touched

3. **Enforcer reviews the staged change:**

   | Check | Pass Condition |
   |-------|---------------|
   | Scope compliance | Diff contains ONLY the intended change from the catalog item |
   | No extras | No unrelated files modified, no extra lines changed |
   | No governance | No `.agent_docs/` governance files in diff (unless explicitly authorized) |
   | No UI modifications | No existing UI elements altered (additions OK if catalog says APPROVE) |
   | No unauthorized webhook changes | Webhook files only if catalog item was Category E AND owner-flagged |
   | CLAUDE.md untouched | CLAUDE.md not in diff |
   | Diff-message alignment | Commit message accurately describes the diff content |

4. **If enforcer APPROVES:** Session presents summary to owner:
   ```
   Enforcer APPROVED: [catalog item #]
   Change: [description]
   Files: [list]
   Diff size: [lines added/removed]
   Catalog rationale: [from Phase 5]
   ```

### CHECKPOINT 5 (repeats for each commit)

**Owner sees:** Enforcer has already approved. The change matches the catalog.
**Owner action:** Says "commit" — this is authorization, not judgment.

5. **If enforcer BLOCKS:** Builder receives enforcer report with specific RED findings:
   - Builder resolves each RED finding
   - Builder re-invokes enforcer
   - No human judgment needed on what to fix — the enforcer report specifies exactly what is wrong
   - If blocked twice on the same finding: escalate to owner via `conflict_resolution.md`

6. **Schema-dependent code (Category A) — special handling:**
   - Before re-applying, confirm the database columns from migrations 037-040 are still present in production
   - Run verification query:
     ```sql
     SELECT column_name, table_name
     FROM information_schema.columns
     WHERE table_name IN ('widget_configs', 'organizations', 'leads', 'agents', 'trigger_rules')
     AND column_name IN ('widget_type', 'description', 'impressions', 'interactions',
                          'persona_name', 'persona_phone',
                          'idle_trigger_count', 'idle_trigger_fired_at',
                          'is_provisioned', 'provisioned_by', 'agent_id');
     ```
   - If columns exist: proceed with re-application
   - If columns are missing: STOP — database state has changed unexpectedly

7. **After all approved items are re-applied:**
   - Update work_tree.md: all re-application tasks marked COMPLETED
   - Update memory.md: log completion with total commit count
   - Verify total commits = total approved items from catalog

### Enforcer Gate Check

- [ ] Total commits equals total APPROVE items from Phase 5 catalog
- [ ] Every commit has an enforcer PASS recorded
- [ ] Every commit was explicitly authorized by owner ("commit" instruction)
- [ ] No commits without enforcer approval
- [ ] No bundled commits (one change per commit)
- [ ] Git log shows clean, sequential, authorized commits
- [ ] work_tree.md reflects all completed items
- [ ] memory.md has complete log of re-application

---

## Phase 7 — Database Reconciliation

**What:** Create DOWN migration scripts and migration tracking infrastructure.
**Who:** Claude Code drafts scripts and code. Owner reviews before any production database changes.
**Critical constraint:** Migrations 037-040 are applied to production with LIVE DATA in the new columns. DOWN scripts must handle data preservation.

### Steps

1. **Write DOWN migration scripts** for 037-040 in reverse order:

   | Order | Migration | DOWN Script Must Handle |
   |-------|-----------|------------------------|
   | 1st | 040_agent_provisioning | Drop `is_provisioned`, `provisioned_by` from agents; drop `agent_id` from trigger_rules. Data: agents with `is_provisioned: true` exist. |
   | 2nd | 039_idle_trigger_columns | Drop `idle_trigger_count`, `idle_trigger_fired_at` from leads; remove expanded CHECK constraint on trigger_rules.event_type. Data: leads with `idle_trigger_count: 2` and timestamps exist. |
   | 3rd | 038_org_persona_fields | Drop `persona_name`, `persona_phone` from organizations. Data: `persona_name: "Elizabeth"` for Hyundai of Columbia. |
   | 4th | 037_widget_type | Drop `widget_type`, `description`, `impressions`, `interactions` from widget_configs; remove CHECK constraint and index. |

   **Each DOWN script must:**
   - Include a comment block: what it reverses, what data will be lost, when it was written
   - Back up affected data to a `_migration_backup_NNN` table before dropping columns
   - Use `IF EXISTS` guards to be idempotent
   - Be wrapped in a transaction
   - NOT be executed automatically — owner reviews and runs manually

2. **Owner reviews DOWN scripts** before any execution:
   - Verify backup logic is correct
   - Verify no unintended side effects
   - Decide whether to execute now or hold (these may never need to run if the columns are re-adopted)

3. **Create migration tracking table.** Owner runs manually in Supabase:
   ```sql
   CREATE TABLE IF NOT EXISTS migration_tracking (
     id SERIAL PRIMARY KEY,
     migration_number VARCHAR(10) NOT NULL UNIQUE,
     migration_name VARCHAR(255) NOT NULL,
     direction VARCHAR(4) NOT NULL DEFAULT 'UP',
     applied_at TIMESTAMPTZ DEFAULT NOW(),
     applied_by VARCHAR(100) DEFAULT 'manual',
     down_script_exists BOOLEAN DEFAULT FALSE,
     notes TEXT
   );
   ```

4. **Insert records for migrations 001-040.** Owner runs manually:
   ```sql
   -- Migrations 001-036: applied before incident, no DOWN scripts
   INSERT INTO migration_tracking (migration_number, migration_name, direction, applied_by, down_script_exists, notes)
   VALUES
     ('001', '001_initial_schema.sql', 'UP', 'manual', false, 'Pre-incident'),
     -- ... (all through 036)
     ('036', '036_drive_sharing.sql', 'UP', 'manual', false, 'Pre-incident, last known good');

   -- Migrations 037-040: applied during incident, DOWN scripts now exist
   INSERT INTO migration_tracking (migration_number, migration_name, direction, applied_by, down_script_exists, notes)
   VALUES
     ('037', '037_widget_type.sql', 'UP', 'unauthorized-agent', true, 'Applied during Feb 27-28 incident. DOWN script created in recovery Phase 7.'),
     ('038', '038_org_persona_fields.sql', 'UP', 'unauthorized-agent', true, 'Applied during Feb 27-28 incident. DOWN script created in recovery Phase 7.'),
     ('039', '039_idle_trigger_columns.sql', 'UP', 'unauthorized-agent', true, 'Applied during Feb 27-28 incident. DOWN script created in recovery Phase 7.'),
     ('040', '040_agent_provisioning.sql', 'UP', 'unauthorized-agent', true, 'Applied during Feb 27-28 incident. DOWN script created in recovery Phase 7.');
   ```

5. **Claude Code adds DOWN script support to migration runner** (under explicit owner authorization):
   - Migration runner must support `--down` flag
   - DOWN scripts run in reverse order
   - Each DOWN execution creates a tracking record with `direction: 'DOWN'`
   - Safety check: refuse to run DOWN on a migration that has data in affected columns without `--force` flag

### Enforcer Gate Check

- [ ] DOWN scripts exist for migrations 037, 038, 039, 040 (4 files)
- [ ] DOWN scripts are in version control (committed through enforcer flow)
- [ ] Each DOWN script includes data backup logic
- [ ] Migration tracking table exists in production with 40 rows
- [ ] Migrations 037-040 marked with `applied_by: 'unauthorized-agent'` and `down_script_exists: true`
- [ ] Migration runner supports `--down` flag
- [ ] No DOWN scripts were executed without owner review

---

## Phase 8 — Acceptance Criteria Reconciliation

**What:** Produce a comprehensive, reconciled acceptance criteria document that covers both the authoritative AC and the testing kit.
**Who:** Claude Code performs the diff and reconciliation. Owner approves the result.
**Why this matters:** The authoritative AC and the testing kit were written at different times and may not fully align. The agent-based communication approach (late architectural shift) may have changed implementation paths. The reconciled AC becomes the single source of truth for testing in Phase 9.

### Steps

1. **Read authoritative AC:**
   `filestore/nexxus_authoritative_plan/1b_ACCEPTANCE_CRITERIA.md`

2. **Read all testing kit files:**
   `filestore/final_testing_kit/` (all 11 files):
   - `release_criteria.md` (61 gaps identified)
   - Battery files B1-B6
   - Supporting test definitions

3. **Perform three-way diff and identify:**

   | Gap Type | Description | Action |
   |----------|-------------|--------|
   | **Testing kit covers, AC doesn't** | Functionality tested by batteries but not specified in AC | Add to reconciled AC if it serves the product; flag as "addendum" if not in original scope |
   | **AC specifies, testing kit doesn't** | Requirements in AC with no corresponding test battery | Create test coverage plan; these are untested requirements |
   | **Implementation path changed** | Agent-based communication changed how a feature works vs. what AC describes | Document the delta; owner decides if AC updates or implementation changes |
   | **Conflicting definitions** | AC and testing kit describe the same feature differently | Truth hierarchy applies: UI (Tier 1) > AC (Tier 2) > Release Plan (Tier 3) |

4. **Produce reconciled AC document** at `.agent_docs/acceptance_criteria.md`:
   - Replaces the placeholder from Phase 4
   - Every criterion has: ID, description, source (AC/testing kit/both), test battery reference, status (UNVERIFIED)
   - Gap analysis section: what's covered, what's not, what needs owner decision
   - Traceability matrix: criterion ID → test battery → evidence requirement

5. **Reference the AC reconciliation guide** if it exists:
   `~/Claude-store/Nexxus_workbench/ac-reconciliation-guide.md`
   (Note: this file may not yet exist at execution time. If absent, proceed with the steps above.)

6. **Owner reviews and approves** the reconciled AC:
   - Are the gap classifications correct?
   - Are the "addendum" items actually in scope?
   - Do the implementation path changes require AC updates or code changes?
   - Is anything missing?

### CHECKPOINT 6

**Owner reviews:**
- Reconciled AC document
- Gap analysis (what's covered vs. what's not)
- Implementation path deltas (where agent approach changed things)
- Traceability matrix

**Owner action:** Approves reconciled AC before test batteries begin.

### Enforcer Gate Check

- [ ] Reconciled AC covers all testing kit batteries (no orphaned tests)
- [ ] Reconciled AC covers all authoritative AC requirements (no orphaned criteria)
- [ ] Every criterion has a test battery reference or explicit "no test" justification
- [ ] Gap analysis is complete with owner decisions on each gap
- [ ] Reconciled AC replaces placeholder in `.agent_docs/acceptance_criteria.md`
- [ ] Traceability matrix links criteria → tests → evidence requirements

---

## Phase 9 — Validation & Testing

**What:** Run test batteries with enforcer verification at each transition.
**Who:** Orchestrator/MTC coordinates. Builders execute. Enforcer verifies.
**Input:** Reconciled AC from Phase 8 defines what each battery must prove.

### Steps

1. **MTC (Master Test Coordinator) writes briefing doc:**
   - Test strategy: what are we proving and why
   - Battery sequence and rationale for ordering
   - What each battery proves relative to the reconciled AC
   - Pass/fail criteria for each battery (derived from reconciled AC, not from what was built)
   - Evidence requirements: what artifacts constitute proof

2. **Critic Agent reviews briefing:**
   Critical question: "Is this test plan proving what the acceptance criteria REQUIRE, or is it proving what was BUILT?"
   - If tests are shaped around implementation rather than requirements: flag for revision
   - If tests skip criteria that are hard to test: flag as gap
   - Critic report goes to owner alongside briefing

3. **Owner reviews MTC briefing** before batteries start:
   - Is the test strategy sound?
   - Are the pass/fail criteria correctly derived from the reconciled AC?
   - Are there criteria that should be tested but aren't?

### Battery Sequence

| Order | Battery | What It Proves | AC Coverage |
|-------|---------|---------------|-------------|
| 1 | B1: Agent Config | Persona/identity system works correctly | [mapped to AC criteria] |
| 2 | B2: Widgets/Pages | UI components match reference spec (Tier 1) | [mapped to AC criteria] |
| 3 | B3: Inbound Communication | SMS receipt, webhook handling, message routing | [mapped to AC criteria] |
| 3 | B4: Outbound Communication | SMS send, email dispatch, notification delivery | [mapped to AC criteria] |
| 4 | B5: Calendar | Scheduling integration, availability, booking flow | [mapped to AC criteria] |
| 5 | B6: E2E Regression | Full system integration, cross-feature interactions | [mapped to AC criteria] |

**Note:** B3 and B4 run in parallel (they test independent communication directions).

4. **Enforcer issues verdict before each battery transition:**
   - After B1 completes: enforcer reviews results against reconciled AC criteria for B1 scope
   - Enforcer PASS required before B2 begins
   - Pattern repeats for each battery boundary
   - If enforcer finds unresolved failures: battery is re-run or issues are fixed before proceeding

5. **For each battery:**
   - Builder executes test suite
   - Captures evidence (screenshots, API responses, logs, test reports)
   - Records results in `.agent_docs/memory.md`
   - Updates `release_criteria.md` with verified results (ONLY verified — no self-certification)
   - Enforcer cross-checks: do the claimed results match the evidence artifacts?

6. **Live Tavus video test** with Duane Wells as final validation:
   - This is the capstone test — a real video call through the production system
   - Tests the full communication pipeline end-to-end
   - Evidence: recording of the test call, screenshots, webhook email received

### Enforcer Gate Check

- [ ] All batteries passed (B1 through B6)
- [ ] `release_criteria.md` reflects ONLY verified results (every PASS has evidence)
- [ ] Chain of custody complete: every test has executor, timestamp, evidence path
- [ ] No self-certification (the agent that built a feature did not also certify its test)
- [ ] Enforcer transition verdicts recorded for each battery boundary
- [ ] Live Tavus test completed with evidence
- [ ] Webhook verified working after all test activities

---

## Phase 10 — Release Decision

**What:** Owner makes the final release decision based on complete evidence chain.
**Who:** Owner alone. This decision cannot be delegated, automated, or recommended by agents.

### Evidence Package for Owner

The following must be assembled and presented:

1. **Enforcer reports** — Every enforcer gate check from Phases 2-9 (should all show APPROVED)
2. **Test battery results** — B1 through B6 with evidence artifacts for every PASS
3. **Reconciled AC coverage** — Traceability matrix showing which criteria are verified
4. **Known risks and mitigations:**
   - Migrations 037-040 applied without authorization (tracked, DOWN scripts exist)
   - Any deferred items from Phase 5 (valid changes punted to future sprints)
   - Any AC criteria not fully covered by test batteries
5. **Chain of custody log** — Complete from Phase 3 rollback through Phase 9 testing
6. **Webhook verification log** — All webhook tests from Phase 3 through Phase 9
7. **Live Tavus test evidence** — Recording, screenshots, webhook email

### CHECKPOINT 7

**Owner reviews** the complete evidence package.

**Owner decides:**

| Decision | Meaning | Next Action |
|----------|---------|-------------|
| **RELEASE** | All criteria met, all evidence satisfactory | Deploy to production |
| **HOLD** | Evidence incomplete or risks too high | Identify what's needed, return to appropriate phase |
| **PARTIAL RELEASE** | Core features ready, some items deferred | Define what ships now vs. what waits for Sprint 1 |

**This decision cannot be:**
- Delegated to any agent
- Automated by any process
- Recommended by any agent (agents present evidence, owner decides)
- Rushed by any timeline pressure

---

## Checkpoint Summary

| # | Phase | When | What Owner Does | What System Has Already Done |
|---|-------|------|----------------|------------------------------|
| 1 | 2 | After /init-enforcer | Reviews scan findings, confirms "proceed" | Installed enforcer, scanned project, mapped docs, verified test commit blocked |
| 2 | 3 | Before rollback | Confirms "proceed with rollback" | Verified webhook at current HEAD (86c4734), recorded evidence |
| 3 | 3 | After rollback | Verifies webhook works (test email received), confirms "proceed" | Rolled back to 95c0290, verified HEAD, tested webhook |
| 4 | 5 | After patch evaluation | Reviews catalog, confirms "proceed with re-application" | Classified all 31 commits against truth hierarchy, applied auto-dispositions |
| 5 | 6 | Each commit (repeats) | Says "commit" for each approved change | Enforcer already approved the change, diff verified, scope checked |
| 6 | 8 | Before test batteries | Reviews reconciled AC + MTC briefing | Reconciled AC with testing kit, prepared test strategy, critic reviewed |
| 7 | 10 | Final release | Makes release decision (RELEASE / HOLD / PARTIAL) | All tests passed, all evidence collected, complete chain of custody |

---

## Decision Authority Matrix

| Decision | Who Decides | Agents' Role |
|----------|-------------|-------------|
| CLAUDE.md content | Owner only | Cannot read-write, only read |
| Commit authorization | Owner says "commit" | Enforcer approves/blocks, builder prepares |
| Patch item disposition | Criteria decide, owner confirms | System applies truth hierarchy, owner validates logic |
| AC reconciliation | Owner approves | Claude Code performs diff, produces reconciled doc |
| Test pass/fail | Evidence decides | Enforcer verifies evidence matches claims |
| Release decision | Owner alone | Agents present evidence, never recommend |
| Webhook changes | Owner explicitly authorizes | Flagged regardless of other criteria |
| DB schema changes | Owner reviews | Claude Code drafts, owner executes |

---

## Risk Register

| Risk | Impact | Mitigation | Phase |
|------|--------|-----------|-------|
| Webhook breaks during rollback | Production feature down | Test before AND after rollback; pause if broken | 3 |
| Webhook depends on code from 31 commits | Cannot roll back cleanly | Identify webhook-dependent changes in patch evaluation; re-apply first | 3, 5 |
| DOWN scripts lose production data | Data loss | Backup tables before column drops; owner reviews before execution | 7 |
| Patch items miscategorized | Contaminated code re-applied | Truth hierarchy provides objective criteria; owner confirms categorization | 5 |
| Schema mismatch after rollback | App won't start | Expected and documented; not a bug, resolved by re-applying Category A items | 3, 6 |
| Reconciled AC misses requirements | Incomplete testing | Three-way diff (AC + testing kit + UI spec); owner reviews | 8 |
| Enforcer hooks bypassed | Controls circumvented | Two-layer enforcement (Claude Code PreToolUse + git pre-commit); `--no-verify` requires owner approval + log entry | 2 |
| Session compaction loses recovery context | Phase steps repeated or skipped | `.agent_docs/memory.md` and `work_tree.md` persist state; enforcer_context.md tracks phase progress | All |

---

## File Inventory — What Goes Where

### Files deployed from workbench (`~/Claude-store/Nexxus_workbench/deploy/`)

| File | Destination | Purpose |
|------|-------------|---------|
| `.claude/agents/enforcer.md` | `nexxus-v2/.claude/agents/enforcer.md` | Enforcer agent definition |
| `.claude/commands/init-enforcer.md` | `nexxus-v2/.claude/commands/init-enforcer.md` | /init-enforcer command |
| `.claude/hooks/enforcer-gate.sh` | `nexxus-v2/.claude/hooks/enforcer-gate.sh` | PreToolUse hook script |
| `.claude/settings.json` | `nexxus-v2/.claude/settings.json` | Hook configuration (merge, don't overwrite) |
| `.git/hooks/pre-commit` | `nexxus-v2/.git/hooks/pre-commit` | Git pre-commit hook |
| `.agent_docs/agent_team.md` | `nexxus-v2/.agent_docs/agent_team.md` | Agent team definition |
| `.agent_docs/memory.md` | `nexxus-v2/.agent_docs/memory.md` | Memory log template |
| `.agent_docs/work_tree.md` | `nexxus-v2/.agent_docs/work_tree.md` | Work tree template |
| `.agent_docs/conflict_resolution.md` | `nexxus-v2/.agent_docs/conflict_resolution.md` | Conflict escalation log |
| `.agent_docs/hooks/pre-commit` | `nexxus-v2/.agent_docs/hooks/pre-commit` | Reference copy of pre-commit |

### Files created during recovery (by Claude Code)

| File | Created In | Purpose |
|------|-----------|---------|
| `.agent_docs/enforcer_context.md` | Phase 2 (by /init-enforcer) | Context map, sprint state |
| `.agent_docs/conventions.md` | Phase 4 | Naming conventions and standards |
| `.agent_docs/plan_sequence.md` | Phase 4 | Sprint definitions |
| `.agent_docs/acceptance_criteria.md` | Phase 4 (placeholder), Phase 8 (full) | Reconciled acceptance criteria |
| `.agent_docs/safety_gates.md` | Phase 4 | Project-specific safety gates |
| `.agent_docs/quality_gates.md` | Phase 4 | Build/test requirements |
| `.agent_docs/release_plan.md` | Phase 4 | Working copy of release plan |
| DOWN migration scripts (037-040) | Phase 7 | Rollback capability for DB |

### Files archived (moved to `~/Claude-store/filestore/archive/nexxus2_1/`)

| File | Archived In | Reason |
|------|-----------|--------|
| `CLAUDE.md.pre-enforcer` | Phase 1 | Backup before edits |
| `.claude/agents/FRAMEWORK.md` | Phase 2 | Old agent, replaced |
| `.claude/agents/builder.md` | Phase 2 | Old agent, replaced |
| `.claude/agents/gatekeeper.md` | Phase 2 | Old agent, replaced by enforcer |
| `.claude/agents/orchestrator.md` | Phase 2 | Old agent, replaced |
| `.claude/agents/sentinel.md` | Phase 2 | Old agent, replaced by enforcer |
| Session memory files | Phase 2 | Contaminated context |

---

## Recovery Sequence Diagram

```
Phase 1: Owner Pre-Flight (manual, ~10 min)
  └─ CLAUDE.md edited + locked
      │
Phase 2: Enforcer Installation
  ├─ Deploy files copied
  ├─ Old agents archived
  ├─ Hooks made executable
  ├─ /init-enforcer run
  └─ Test commit blocked ──→ CHECKPOINT 1 (owner confirms)
      │
Phase 3: Code Rollback
  ├─ Webhook verified at HEAD (86c4734)
  │   └──→ CHECKPOINT 2 (owner confirms rollback)
  ├─ git reset --hard 95c0290
  └─ Webhook verified at 95c0290 ──→ CHECKPOINT 3 (owner confirms)
      │
Phase 4: Governance Cleanup
  ├─ Shadow RELEASE_PLAN removed
  ├─ .agent_docs/ bootstrapped
  └─ /init-enforcer re-run (verify)
      │
Phase 5: Patch Evaluation
  ├─ 31 commits classified (Categories A-F)
  ├─ Truth hierarchy applied
  └─ Catalog produced ──→ CHECKPOINT 4 (owner confirms catalog)
      │
Phase 6: Controlled Re-Application
  ├─ For each APPROVE item:
  │   ├─ Builder applies
  │   ├─ Enforcer reviews
  │   └─ Owner says "commit" ──→ CHECKPOINT 5 (per commit)
  └─ All approved items committed
      │
Phase 7: Database Reconciliation
  ├─ DOWN scripts written (037-040)
  ├─ Owner reviews scripts
  ├─ Tracking table created
  └─ Migration runner updated
      │
Phase 8: AC Reconciliation
  ├─ Authoritative AC + testing kit diffed
  ├─ Reconciled AC produced
  └─ Owner approves ──→ CHECKPOINT 6
      │
Phase 9: Validation & Testing
  ├─ MTC briefing + Critic review
  ├─ B1 → B2 → B3+B4 → B5 → B6
  ├─ Enforcer verdict at each transition
  └─ Live Tavus test with Duane Wells
      │
Phase 10: Release Decision
  └─ Owner reviews evidence ──→ CHECKPOINT 7
      └─ RELEASE / HOLD / PARTIAL RELEASE
```

---

## Appendix A — Key Commits Reference

| Commit | Role |
|--------|------|
| `95c0290` | Last known good commit (rollback target) |
| `86c4734` | Current HEAD (31 unauthorized commits ahead) |
| `61556fc` | First unauthorized commit (governance reset, 753 files) |
| `897bde5` | Migration 037 + fabricated GK claim |
| `08d35dd` | Largest commit (38 files, migrations 038-040) |
| `adec847` | Fabricated "all merge criteria checked" claim |
| `9bf9898` | Self-upgraded autonomy to L3 |

## Appendix B — Authoritative File Locations

| Document | Location | Status |
|----------|----------|--------|
| Authoritative RELEASE_PLAN | `filestore/nexxus_authoritative_plan/1a_RELEASE_PLAN.md` | Untouched |
| Authoritative ACCEPTANCE_CRITERIA | `filestore/nexxus_authoritative_plan/1b_ACCEPTANCE_CRITERIA.md` | Untouched |
| Other authoritative plan files | `filestore/nexxus_authoritative_plan/` (3 more files) | Untouched |
| Testing kit | `filestore/final_testing_kit/` (11 files) | Untouched |
| Patch file (primary) | `~/Claude-store/Nexxus_workbench/work_to_review.patch` | Preserved |
| Patch file (archive) | `~/Claude-store/filestore/archive/nexxus2_1/work_to_review.patch` | Preserved |
| Incident audit | `~/Claude-store/Nexxus_workbench/incident-audit-and-recovery-plan.md` | Reference |
| CLAUDE.md additions | `~/Claude-store/Nexxus_workbench/claude-md-additions.md` | Reference |
| Enforcer system design | `~/Claude-store/Nexxus_workbench/enforcer-system-v2.md` | Reference |
| This plan | `~/Claude-store/Nexxus_workbench/adapted-recovery-plan.md` | Active |

## Appendix C — Emergency Procedures

### If webhook breaks at any point:
1. STOP all other work immediately
2. Identify which change broke it (last commit, last deployment, etc.)
3. Revert the breaking change
4. Verify webhook is restored
5. Record incident in memory.md
6. Resume from the phase where the break occurred

### If enforcer hooks are bypassed:
1. The bypass is logged (pre-commit hook logs all `--no-verify` attempts)
2. Owner must have explicitly authorized the bypass
3. If unauthorized: revert the commit, investigate how bypass occurred
4. Log in conflict_resolution.md

### If CLAUDE.md is modified:
1. This should be impossible (chmod 444)
2. If it happens: restore from backup at `~/Claude-store/filestore/archive/nexxus2_1/CLAUDE.md.pre-enforcer`
3. Re-apply the enforcer additions from `~/Claude-store/Nexxus_workbench/claude-md-additions.md`
4. Re-lock: `chmod 444`
5. Investigate how the modification occurred
