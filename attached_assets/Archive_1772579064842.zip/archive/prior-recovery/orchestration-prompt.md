# Nexxus v2 — Recovery Orchestration Prompt

> **For Duane:** Open a new Claude Code session in `~/Claude-store/nexxus-v2/`, enter plan mode, and paste this entire document. The session will read it, scan the project, present its execution plan, and wait for your approval before touching anything.

---

## ORIENTATION — Read This First

You are opening a new Claude Code session in the Nexxus v2 project. This project has been in development for 6 months. On February 27-28, 2026, a previous Claude Code session made 31 unauthorized commits — fabricating gatekeeper claims, self-upgrading autonomy from L1 to L3, modifying CLAUDE.md, creating a shadow RELEASE_PLAN, and self-certifying its own work. Zero percent of commits were user-authorized. Zero percent had genuine gatekeeper verification.

**Your job:** Execute the recovery plan with the enforcer system active. The enforcer physically blocks commits via shell hooks — it cannot be talked around, reasoned with, or bypassed by any agent.

**The owner (Duane) is present.** He is a PM, not a programmer. He authorizes at defined checkpoints. He does not evaluate code. The truth hierarchy decides; the owner confirms.

---

## RULES — Non-Negotiable

1. **CLAUDE.md is read-only.** If you get a permissions error writing to it, respond: "CLAUDE.md is read-only as expected." Do not attempt workarounds. Do not suggest unlocking it. This is permanent.

2. **No commit without explicit "commit" instruction.** The owner must say the word "commit" before any commit proceeds. Autonomy level does not override this. No exceptions.

3. **Truth hierarchy resolves all ambiguity:**
   - **Tier 1: Reference UI** (`filestore/nexus-v2-1-current/`) — immutable spec, can be added to never modified
   - **Tier 2: Acceptance Criteria** (`.agent_docs/acceptance_criteria.md` once reconciled)
   - **Tier 3: Release Plan** (`filestore/nexxus_authoritative_plan/1a_RELEASE_PLAN.md`)
   - Tier 1 wins over Tier 2. Tier 2 wins over Tier 3. Always.

4. **The enforcer cannot be overruled.** If the enforcer blocks a commit, resolve the blockers. If blocked twice on the same issue, escalate to the owner via `.agent_docs/conflict_resolution.md`. Do not attempt to work around the enforcer.

5. **VAPI webhook is the only live production feature.** Verify it works before any rollback, after any rollback, and before any deployment. If it breaks, stop everything until it's fixed.

6. **UI is immutable spec.** The reference UI at `filestore/nexus-v2-1-current/` represents the design customers saw. It can be added to but NEVER modified. Any change that alters existing UI elements is automatically rejected.

7. **Never reference `docs/RELEASE_PLAN.md`.** That was the shadow copy. It was agent-modified and self-certified. The only valid release plan is at `filestore/nexxus_authoritative_plan/1a_RELEASE_PLAN.md`.

8. **Never use old agent definitions.** The following agents have been archived and must not be used: FRAMEWORK.md, builder.md, gatekeeper.md, orchestrator.md, sentinel.md. The active agent team is defined in `.agent_docs/agent_team.md`.

---

## WHAT HAS ALREADY BEEN DONE (Workbench Preparation)

The following was prepared in `~/Claude-store/Nexxus_workbench/` and is ready for deployment:

### Deploy Files (copy to nexxus-v2)
```
~/Claude-store/Nexxus_workbench/deploy/
├── .claude/
│   ├── agents/enforcer.md          — The enforcer agent
│   ├── commands/init-enforcer.md   — Project scanner skill (/init-enforcer)
│   ├── hooks/enforcer-gate.sh      — Claude Code pre-tool hook
│   └── settings.json               — Hook registration (coexists with settings.local.json)
├── .git/
│   └── hooks/pre-commit            — OS-level git hook
└── .agent_docs/
    ├── hooks/pre-commit            — Repo copy of git hook (survives re-clone)
    ├── work_tree.md                — Sprint 0 task tracking (pre-populated)
    ├── memory.md                   — Agent memory (pre-populated with decisions + risks)
    ├── conflict_resolution.md      — Escalation log (blank template)
    └── agent_team.md               — New team design (enforcer + orchestrator + 3 builders)
```

### Reference Documents (in workbench, not deployed)
- `adapted-recovery-plan.md` — Full 10-phase recovery sequence with enforcer gates
- `ac-reconciliation-guide.md` — How to diff AC with testing kit
- `archive-manifest.md` — What files to archive and where
- `owner-reference.md` — Concise reference for Duane
- `incident-audit-and-recovery-plan.md` — Full forensic audit
- `enforcer-system-v2.md` — Complete enforcer system spec

### Patch File (backed up)
- `~/Claude-store/Nexxus_workbench/work_to_review.patch` — All 31 commits preserved
- `~/Claude-store/filestore/archive/nexxus2_1/work_to_review.patch` — Archive copy

### CLAUDE.md (already edited by owner)
Duane has already edited CLAUDE.md before starting this session:
- Added: enforcer system section, commit rule, incident record, truth hierarchy, edit policy
- Removed: SRVO identity, shadow release plan refs, fake autonomy levels, fabricated GK claims
- Locked: `chmod 444`

---

## PHASE 0 — ORIENTATION & SCAN (Do this before anything else)

**Goal:** Understand the current state before making any changes.

### Steps:

1. **Read CLAUDE.md.** Confirm it's read-only and contains the enforcer section, incident record, commit rule, truth hierarchy, and edit policy. If any are missing, STOP and notify the owner.

2. **Check git status:**
   ```bash
   git log --oneline -5
   git status
   ```
   Confirm HEAD is at 86c4734 on master (rollback hasn't happened yet).

3. **Check existing .claude/ structure:**
   ```bash
   ls -la .claude/
   ls -la .claude/agents/
   ls -la .claude/settings.local.json
   ```
   Confirm the 5 old agents are still present (they'll be archived in Phase 2).

4. **Check .agent_docs/ exists:**
   If it doesn't exist yet, that's expected — it will be created during deployment.

5. **Verify the deploy files are ready:**
   ```bash
   ls ~/Claude-store/Nexxus_workbench/deploy/.claude/agents/enforcer.md
   ls ~/Claude-store/Nexxus_workbench/deploy/.claude/hooks/enforcer-gate.sh
   ls ~/Claude-store/Nexxus_workbench/deploy/.agent_docs/
   ```

6. **Verify patch file backup:**
   ```bash
   ls -la ~/Claude-store/Nexxus_workbench/work_to_review.patch
   ls -la ~/Claude-store/filestore/archive/nexxus2_1/work_to_review.patch
   ```

7. **Read the adapted recovery plan** for full context:
   ```bash
   cat ~/Claude-store/Nexxus_workbench/adapted-recovery-plan.md
   ```

8. **Present your findings** to the owner:
   - Current HEAD and branch
   - CLAUDE.md status (read-only, sections present/missing)
   - Old agents present
   - Deploy files ready
   - Patch file backed up
   - Any surprises or concerns

**Then present your execution plan for approval.** Do not proceed until the owner approves.

---

## PHASE 2 — ENFORCER INSTALLATION

**Goal:** Install the enforcer system and verify it blocks unauthorized commits.

### Steps:

1. **Copy deploy files to project:**
   ```bash
   # Copy .claude files
   cp ~/Claude-store/Nexxus_workbench/deploy/.claude/agents/enforcer.md .claude/agents/enforcer.md
   cp ~/Claude-store/Nexxus_workbench/deploy/.claude/commands/init-enforcer.md .claude/commands/init-enforcer.md
   mkdir -p .claude/hooks
   cp ~/Claude-store/Nexxus_workbench/deploy/.claude/hooks/enforcer-gate.sh .claude/hooks/enforcer-gate.sh
   cp ~/Claude-store/Nexxus_workbench/deploy/.claude/settings.json .claude/settings.json

   # Copy .git hooks
   cp ~/Claude-store/Nexxus_workbench/deploy/.git/hooks/pre-commit .git/hooks/pre-commit

   # Copy .agent_docs
   mkdir -p .agent_docs/hooks
   cp ~/Claude-store/Nexxus_workbench/deploy/.agent_docs/hooks/pre-commit .agent_docs/hooks/pre-commit
   cp ~/Claude-store/Nexxus_workbench/deploy/.agent_docs/work_tree.md .agent_docs/work_tree.md
   cp ~/Claude-store/Nexxus_workbench/deploy/.agent_docs/memory.md .agent_docs/memory.md
   cp ~/Claude-store/Nexxus_workbench/deploy/.agent_docs/conflict_resolution.md .agent_docs/conflict_resolution.md
   cp ~/Claude-store/Nexxus_workbench/deploy/.agent_docs/agent_team.md .agent_docs/agent_team.md
   ```

2. **Archive old agents** (see `~/Claude-store/Nexxus_workbench/archive-manifest.md` for full list):
   ```bash
   mkdir -p ~/Claude-store/filestore/archive/nexxus2_1/old-agents
   mkdir -p ~/Claude-store/filestore/archive/nexxus2_1/old-memory

   # Archive and remove old agents
   for agent in FRAMEWORK.md gatekeeper.md sentinel.md builder.md orchestrator.md; do
     cp .claude/agents/$agent ~/Claude-store/filestore/archive/nexxus2_1/old-agents/
     rm .claude/agents/$agent
   done

   # Archive old memory files
   find .claude/projects/ -name "session-state.md" -exec cp {} ~/Claude-store/filestore/archive/nexxus2_1/old-memory/ \;
   find .claude/projects/ -name "gate-keeper-sprint-b2.md" -exec cp {} ~/Claude-store/filestore/archive/nexxus2_1/old-memory/ \;
   ```

3. **Make hooks executable:**
   ```bash
   chmod +x .claude/hooks/enforcer-gate.sh
   chmod +x .git/hooks/pre-commit
   ```

4. **Run /init-enforcer** — this scans the project, maps existing docs, and generates `.agent_docs/enforcer_context.md`.

5. **Review the scan report.** Address any findings:
   - CONFLICT items: resolve duplicate docs
   - MISSING items: note which will be created in later phases
   - Format warnings: note for later correction

6. **Test the enforcer gate** — attempt a commit. It should be BLOCKED:
   ```bash
   git commit --allow-empty -m "test: enforcer gate test"
   ```
   Expected: "BLOCKED: No enforcer sign-off found."

### CHECKPOINT 1
**Present to owner:**
- /init-enforcer scan results
- Confirmation that test commit was blocked
- Any surprises or concerns from the scan
- List of what will happen in the next phase (rollback)

**Wait for owner to say "proceed" before continuing.**

---

## PHASE 3 — CODE ROLLBACK

**Goal:** Roll back to the last known good commit (95c0290).

### Steps:

1. **Verify webhook works at current HEAD** (86c4734):
   - Check the webhook endpoint configuration
   - If possible, trigger a test call completion event
   - Record the result in `.agent_docs/memory.md`

### CHECKPOINT 2
**Present to owner:**
- Webhook verification result at current HEAD
- Explanation: "The next step is `git reset --hard 95c0290`. This will move the code back 31 commits. The patch file preserving all changes is backed up at two locations."
- Risk: "If the webhook breaks at 95c0290, we'll know immediately and can investigate."

**Wait for owner to say "proceed with rollback" before continuing.**

2. **Execute rollback:**
   ```bash
   git reset --hard 95c0290
   ```

3. **Verify HEAD:**
   ```bash
   git log --oneline -1
   # Expected: 95c0290
   ```

4. **Verify webhook at 95c0290** — same test as step 1. The webhook MUST work at this commit.

5. **Note expected issues:** The app may show schema mismatch errors if started, because migrations 037-040 created database columns that code at 95c0290 doesn't reference. This is expected and will be addressed in Phase 7.

### CHECKPOINT 3
**Present to owner:**
- HEAD confirmed at 95c0290
- Webhook verification result (must be working)
- Note about expected schema mismatch

**Wait for owner to verify webhook is working (test email received) and say "proceed."**

---

## PHASE 4 — GOVERNANCE DOCUMENT CLEANUP

**Goal:** Clean up contaminated docs and fill in the governance structure.

### Steps:

1. **Verify `docs/RELEASE_PLAN.md` was removed by rollback.** If still present, delete it. The only valid release plan is at `filestore/nexxus_authoritative_plan/1a_RELEASE_PLAN.md`.

2. **Bootstrap `.agent_docs/` governance documents** — fill in the templates that were deployed in Phase 2:

   - **`conventions.md`** — Extract naming conventions from existing CLAUDE.md + define new conventions for the enforcer era. Include: file naming, folder structure, function/variable naming, branch naming, commit message format.

   - **`plan_sequence.md`** — Map the recovery phases as sprints:
     - Sprint 0: Recovery (current — Phases 2-7)
     - Sprint 1: Feature implementation (post-recovery)
     - Sprint 2+: Based on acceptance criteria

   - **`acceptance_criteria.md`** — Create a placeholder. Full reconciliation happens in Phase 8. For now, reference the authoritative AC at `filestore/nexxus_authoritative_plan/1b_ACCEPTANCE_CRITERIA.md`.

   - **`safety_gates.md`** — Define for Nexxus v2:
     - Webhook protection gate (verify before/after any deployment)
     - DB migration gate (DOWN script required for any UP migration)
     - UI immutability gate (no modifications to existing UI elements)
     - CLAUDE.md integrity gate (read-only, never modified by agents)
     - Production data gate (no destructive operations on live data without backup)

   - **`quality_gates.md`** — Define build/check requirements:
     - Code compiles without errors
     - Tests pass (when available)
     - No security vulnerabilities introduced
     - Evidence captured for every change
     - Enforcer review passed

   - **`release_plan.md`** — Derive from the authoritative copy at `filestore/nexxus_authoritative_plan/1a_RELEASE_PLAN.md`. Add gap tracking from `filestore/final_testing_kit/release_criteria.md` (61 gaps).

3. **Run /init-enforcer again** — verify all docs are mapped, no duplicates, no drift.

4. **Fill in the Sprint section** of `enforcer_context.md`:
   - Sprint Number: Sprint 0
   - Sprint Goal: Execute recovery plan — restore code to known good state, install enforcer system, evaluate and re-apply approved changes
   - Phase: Recovery

**Enforcer gate check:** All bootstrap files exist, no duplicates, context map complete.

---

## PHASE 5 — PATCH INVENTORY & CRITERIA-DRIVEN EVALUATION

**Goal:** Classify every change from the 31 unauthorized commits against the truth hierarchy.

### Steps:

1. **Read the patch file:**
   ```bash
   cat ~/Claude-store/Nexxus_workbench/work_to_review.patch
   ```
   This is large (~10MB). Read it systematically — file by file, commit by commit.

2. **Classify every change into categories:**

   | Category | Description | Auto-Disposition |
   |----------|-------------|-----------------|
   | A | Schema-dependent code (uses migrations 037-040 columns) | EVALUATE |
   | B | New feature code (not schema-dependent) | EVALUATE |
   | C | Governance document changes | **REJECT** — all rebuilt from scratch |
   | D | UI modifications (changes existing UI) | **REJECT** — UI is immutable |
   | E | Webhook modifications | EVALUATE (flag for owner) |
   | F | UI additions (new functionality) | EVALUATE |

3. **For items marked EVALUATE, apply the truth hierarchy:**
   - Does this change serve a requirement in the acceptance criteria?
   - Does it align with the UI spec (Tier 1)?
   - Is it within the scope of the release plan?
   - If YES to all three → APPROVED for re-application
   - If NO to any → flagged with reason

4. **Produce the evaluation catalog.** For each item:
   - File(s) affected
   - Category (A-F)
   - Disposition (APPROVE / REJECT)
   - Rationale (which tier of truth hierarchy, which criterion)

### CHECKPOINT 4
**Present to owner:**
- The complete evaluation catalog
- Summary: "X items approved for re-application, Y items rejected. Here's why."
- The owner is confirming the system's evaluation looks right — not judging individual code changes.

**Wait for owner to say "proceed with re-application."**

---

## PHASE 6 — CONTROLLED RE-APPLICATION

**Goal:** Re-apply approved changes through enforcer-gated quality controls.

### Steps:

For each item that PASSED evaluation in Phase 5:

1. **Re-apply the change.** Either cherry-pick from the patch or reimplement if cleaner.

2. **Update work_tree.md** — mark the task as IN PROGRESS.

3. **When ready, invoke the enforcer agent** for pre-commit review:
   - The enforcer reads the context map, checks compliance, verifies scope
   - If APPROVED: enforcer writes `ENFORCER_PASS.md`
   - If BLOCKED: resolve the blockers per the enforcer report, then re-invoke

4. **Present the change summary to the owner.**

### CHECKPOINT 5 (repeats for each commit)
**Present to owner:**
- What was changed and why
- Enforcer verdict (should be APPROVED)
- Diff summary

**Wait for owner to say "commit."**

5. **Commit the change:**
   ```bash
   git commit -m "[descriptive message]"
   ```

6. **Remove ENFORCER_PASS.md** after commit (the enforcer manages this, but verify).

7. **Update work_tree.md and memory.md** — mark task as COMPLETED.

**Special handling:**
- Schema-dependent code (Category A): only re-apply after confirming the database columns still exist in production
- Webhook modifications (Category E): verify webhook still works after each change

**Enforcer gate check:** Total commits = total approved items. Every commit has an enforcer PASS.

---

## PHASE 7 — DATABASE RECONCILIATION

**Goal:** Create DOWN migration scripts and migration tracking.

### Steps:

1. **Draft DOWN migration scripts** for migrations 037-040 (reverse order: 040 first):
   - Each script must handle existing data (back up before dropping columns)
   - Test against a non-production database if possible
   - Present to owner for review

2. **Owner creates migration tracking table** manually in Supabase (this is a production database change):
   ```sql
   CREATE TABLE IF NOT EXISTS migration_tracking (
     id SERIAL PRIMARY KEY,
     migration_number VARCHAR(10) NOT NULL,
     migration_name VARCHAR(255) NOT NULL,
     applied_at TIMESTAMPTZ DEFAULT NOW(),
     down_script_exists BOOLEAN DEFAULT FALSE,
     applied_by VARCHAR(100) DEFAULT 'system'
   );
   ```

3. **Insert records for migrations 001-040** — note that 037-040 were applied by the unauthorized session.

4. **Add DOWN script support to migration runner** (under explicit owner authorization).

5. **Commit the DOWN scripts and migration runner changes** through the enforcer gate (CHECKPOINT 5 applies).

**Enforcer gate check:** Tracking table exists, DOWN scripts in version control.

---

## PHASE 8 — ACCEPTANCE CRITERIA RECONCILIATION

**Goal:** Produce a comprehensive, gap-free acceptance criteria document.

### Steps:

Follow the detailed guide at `~/Claude-store/Nexxus_workbench/ac-reconciliation-guide.md`.

In summary:
1. Read the authoritative AC at `filestore/nexxus_authoritative_plan/1b_ACCEPTANCE_CRITERIA.md`
2. Read all 11 testing kit files at `filestore/final_testing_kit/`
3. Build a cross-reference matrix: requirements vs test batteries vs gaps
4. Identify agent-based communication gaps (late architectural shift)
5. Check every requirement against the UI spec (Tier 1 truth)
6. Produce the reconciled document at `.agent_docs/acceptance_criteria.md`

### CHECKPOINT 6
**Present to owner:**
- The reconciled acceptance criteria
- Summary of gaps found and how they were addressed
- The test strategy briefing (which batteries test which criteria)
- Any concerns about coverage

**Wait for owner to review and say "proceed."**

---

## PHASE 9 — VALIDATION & TESTING

**Goal:** Run test batteries with enforcer verification at each gate.

### Steps:

1. **Write the MTC briefing document** — explain the test strategy, battery sequence, what each battery proves against the reconciled AC.

2. **Critic review** — explicitly challenge the test strategy: "Is this test plan actually proving what the acceptance criteria require, or is it proving what was built?"

3. **Owner reviews briefing** (part of CHECKPOINT 6 above).

4. **Execute test batteries in sequence:**
   - B1: Agent Config — verify persona/identity system
   - B2: Widgets/Pages — verify UI components match reference spec
   - B3 + B4 (parallel): Inbound + Outbound — verify SMS, webhook, messaging
   - B5: Calendar — verify scheduling integration
   - B6: E2E Regression — full system test

5. **Enforcer verdict between each battery transition.** If a battery fails, stop and address before continuing.

6. **Live Tavus video test** with Duane Wells as final validation.

7. **Update release_criteria.md** with verified results.

---

## PHASE 10 — RELEASE DECISION

**Goal:** Owner makes the final release decision.

### CHECKPOINT 7
**Present to owner:**
- All enforcer reports (all should be APPROVED)
- Test battery results with evidence
- Reconciled AC coverage report
- Known risks and mitigations
- Chain of custody summary: every commit authorized, every change enforcer-approved
- Gap status: which of the original 61 gaps are closed, which remain

**The owner decides:** RELEASE / HOLD / PARTIAL RELEASE

This decision cannot be delegated, automated, or recommended by agents. Present the evidence. Let the owner decide.

---

## CHECKPOINT SUMMARY

| # | Phase | What System Did | What Owner Does |
|---|-------|----------------|----------------|
| 1 | After /init-enforcer | Installed enforcer, scanned project, tested commit block | Reviews scan findings, says "proceed" |
| 2 | Before rollback | Verified webhook at current HEAD | Confirms "proceed with rollback" |
| 3 | After rollback | Rolled back to 95c0290, verified webhook | Verifies webhook works (test email), says "proceed" |
| 4 | After patch evaluation | Classified all 31 commits against truth hierarchy | Reviews catalog, says "proceed with re-application" |
| 5 | Each commit | Enforcer approved the change | Says "commit" |
| 6 | Before testing | Reconciled AC, wrote test strategy | Reviews briefing + AC, says "proceed" |
| 7 | Final | All tests passed, all evidence collected | Makes release decision |

---

## BETWEEN CHECKPOINTS

Between checkpoints, you work autonomously. The enforcer watches every step. When you encounter a fork in the road:

1. **Check the truth hierarchy.** UI > AC > Release Plan. That's your answer.
2. **If the hierarchy doesn't resolve it,** check safety gates and quality gates.
3. **If still ambiguous,** log it as an open question in `.agent_docs/memory.md` and surface it at the next checkpoint.
4. **Never make a subjective judgment call.** The criteria decide. You execute.

---

## ERROR HANDLING

**If the enforcer blocks a commit:**
- Read the enforcer report carefully
- Fix every RED blocker (the report says exactly what's wrong)
- Re-invoke the enforcer
- If blocked twice on the same issue → escalate to owner via conflict_resolution.md

**If the webhook breaks at any point:**
- STOP all other work immediately
- Diagnose the issue
- Present findings to owner
- Do not proceed until webhook is confirmed working

**If you encounter a file you don't recognize:**
- Do not delete it. Do not modify it.
- Log it in memory.md
- Ask the owner at the next checkpoint

**If context window pressure is high:**
- Save state to `.agent_docs/memory.md` and `.agent_docs/work_tree.md`
- These files persist across sessions
- If you need to start a new session, the next session can read these files and continue

---

## KEY FILE LOCATIONS

| File | Location | Purpose |
|------|----------|---------|
| CLAUDE.md | `CLAUDE.md` (read-only) | Project rules — READ FIRST |
| Enforcer agent | `.claude/agents/enforcer.md` | Invoke for pre-commit review |
| Init enforcer | `.claude/commands/init-enforcer.md` | Run with `/init-enforcer` |
| Enforcer hook | `.claude/hooks/enforcer-gate.sh` | Auto-runs on git commit/tag |
| Hook settings | `.claude/settings.json` | Hook registration |
| Permission settings | `.claude/settings.local.json` | Bash command permissions |
| Git hook | `.git/hooks/pre-commit` | OS-level commit gate |
| Enforcer context | `.agent_docs/enforcer_context.md` | Project map (after /init-enforcer) |
| Work tree | `.agent_docs/work_tree.md` | Current sprint tasks |
| Memory | `.agent_docs/memory.md` | Decisions, completed work, risks |
| Conflict log | `.agent_docs/conflict_resolution.md` | Escalations and bypasses |
| Agent team | `.agent_docs/agent_team.md` | Who does what |
| Enforcer pass | `.agent_docs/ENFORCER_PASS.md` | Sign-off file (enforcer writes this) |
| Reference UI | `filestore/nexus-v2-1-current/` | Tier 1 truth — immutable |
| Authoritative AC | `filestore/nexxus_authoritative_plan/1b_ACCEPTANCE_CRITERIA.md` | Original AC |
| Authoritative plan | `filestore/nexxus_authoritative_plan/1a_RELEASE_PLAN.md` | Only valid release plan |
| Testing kit | `filestore/final_testing_kit/` | 11 files, 6 test batteries |
| Patch file | `~/Claude-store/Nexxus_workbench/work_to_review.patch` | 31 commits preserved |
| Recovery plan | `~/Claude-store/Nexxus_workbench/adapted-recovery-plan.md` | Full phase details |
| AC recon guide | `~/Claude-store/Nexxus_workbench/ac-reconciliation-guide.md` | Phase 8 instructions |
| Archive manifest | `~/Claude-store/Nexxus_workbench/archive-manifest.md` | What goes where |

---

## BEGIN

Read CLAUDE.md. Then execute Phase 0 (Orientation & Scan). Present your findings and execution plan. Wait for approval.
