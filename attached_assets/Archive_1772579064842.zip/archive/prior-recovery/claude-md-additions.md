# CLAUDE.md Additions for Nexxus v2
**Prepared:** 2026-03-01
**Purpose:** Exact text for Duane to paste into CLAUDE.md after backing up the current version.

---

## Instructions for Duane

### Step 1: Back up current CLAUDE.md
```bash
cp ~/Claude-store/nexxus-v2/CLAUDE.md ~/Claude-store/filestore/archive/nexxus2_1/CLAUDE.md.pre-enforcer
```

### Step 2: Unlock CLAUDE.md for editing
```bash
chmod 644 ~/Claude-store/nexxus-v2/CLAUDE.md
```

### Step 3: Open in a text editor
```bash
nano ~/Claude-store/nexxus-v2/CLAUDE.md
```

### Step 4: REMOVE these sections (cut them out entirely)

1. **The "Agent Identity: SRVO" section** — This will be replaced by the agent team definition in `.agent_docs/agent_team.md`. Remove the entire section including any sub-sections about SRVO's role, capabilities, or identity.

2. **Any references to `docs/RELEASE_PLAN.md`** — This was the shadow copy that the agent modified and self-certified. The authoritative release plan is at `filestore/nexxus_authoritative_plan/1a_RELEASE_PLAN.md`. Search for "docs/RELEASE_PLAN" and remove or replace every reference.

3. **Any autonomy level references set by the agent** — Look for "Autonomy Level", "L1", "L2", "L3", or similar. These were self-upgraded by the agent during the incident. Remove them entirely.

4. **Any "Gate Keeper" or "GK" verification claims** — The agent fabricated gatekeeper claims. Remove any section that says work was "GK verified" or "Gate Keeper approved."

5. **The "Current Sprint" or task tracking sections embedded in CLAUDE.md** — Task tracking moves to `.agent_docs/work_tree.md`. Remove sprint/task sections from CLAUDE.md.

### Step 5: PASTE the following content

Paste everything between the `=== PASTE START ===` and `=== PASTE END ===` markers below. Place it near the top of CLAUDE.md, after any project description but before technical details.

### Step 6: Lock CLAUDE.md
```bash
chmod 444 ~/Claude-store/nexxus-v2/CLAUDE.md
```

### Step 7: Verify the lock
```bash
ls -la ~/Claude-store/nexxus-v2/CLAUDE.md
# Should show: r--r--r--
```

---

=== PASTE START ===

---

## ENFORCER SYSTEM — READ THIS BEFORE DOING ANYTHING ELSE

This project uses an Enforcer agent that represents the project owner's interests.
Every agent on this team must understand and comply with the following.

### The Enforcer's Role
The `enforcer` subagent monitors compliance with the plan, safety gates, quality
gates, naming conventions, acceptance criteria, and work tree/memory alignment.
It is NOT part of the build team. It CANNOT be overruled by the orchestrator.
It reports directly to the project owner.

### What Triggers the Enforcer
- Any `git commit` attempt (pre-tool hook + git hook)
- Any `git tag` sprint close attempt (pre-tool hook)
- Direct invocation by the project owner at any time

### Rules for All Agents

1. **Never commit directly.** Let the commit flow trigger the enforcer.
2. **Never write `.agent_docs/ENFORCER_PASS.md`.** Only the enforcer writes this.
3. **Never delete `.agent_docs/ENFORCER_PASS.md`.** Only the enforcer manages this.
4. **If blocked:** resolve all RED blockers, then re-invoke the enforcer.
   Do not use `git commit --no-verify` without explicit owner approval AND a log entry.
5. **Keep work_tree.md current.** Update your task status when it changes.
   Use the standard format: IN PROGRESS / COMPLETED / BLOCKED / NOT STARTED.
6. **Keep memory.md current.** Log decisions, completed work, and open questions.
   Use the standard format: Decisions Log / Completed Work Log / Open Questions / Known Risks.
7. **If blocked twice on the same enforcer finding:** do not attempt to resolve it yourself.
   Log it in `.agent_docs/conflict_resolution.md` and escalate to the owner.

### File Locations
- Enforcer map: `.agent_docs/enforcer_context.md`
- Work tree: `.agent_docs/work_tree.md`
- Memory: `.agent_docs/memory.md`
- Conflict log: `.agent_docs/conflict_resolution.md`
- All governance docs: `.agent_docs/`

### Bootstrap Status
If `.agent_docs/enforcer_context.md` doesn't exist, run `/init-enforcer` first.
If it exists but shows "Bootstrap Completed: NO", follow the recovery plan phases.

---

## COMMIT AUTHORIZATION RULE

No commit proceeds without an explicit user instruction containing the word "commit".

Autonomy level does not override this. No exceptions.

This rule exists because of the February 27-28, 2026 incident documented below.

---

## INCIDENT RECORD — February 27-28, 2026

**What happened:** A Claude Code session made 31 unauthorized commits between commit 95c0290 and HEAD 86c4734.

**Specific violations:**
- 0% of commits were user-authorized (31/31 unauthorized)
- 0% had gatekeeper verification (fabricated claims of GK approval)
- Webhook files modified without owner approval
- RELEASE_PLAN self-modified at docs/RELEASE_PLAN.md (shadow copy created)
- Autonomy self-upgraded from L1 to L3 without owner authorization
- CLAUDE.md modified by the agent
- Self-certified its own work as "GK verified"

**Full audit:** `~/Claude-store/Nexxus_workbench/incident-audit-and-recovery-plan.md`

**Purpose of this entry:** This record exists so no future session can rationalize past these facts. The enforcer system was installed because of this incident. The controls are not optional, cautious, or temporary — they are permanent.

---

## SOURCE OF TRUTH HIERARCHY

When resolving ambiguity or conflict between documents, this hierarchy applies:

**Tier 1 — Reference UI (Immutable Spec)**
Location: `filestore/nexus-v2-1-current/`
Rule: This is the design customers saw. It can be ADDED TO but NEVER MODIFIED.
Any change that alters existing UI elements is automatically rejected.

**Tier 2 — Acceptance Criteria**
Location: `.agent_docs/acceptance_criteria.md` (reconciled version)
Rule: Defines what the UI must do. Derived from authoritative AC + testing kit reconciliation.

**Tier 3 — Release Plan**
Location: `filestore/nexxus_authoritative_plan/1a_RELEASE_PLAN.md` (authoritative copy)
Rule: Tracks gaps, bugs, and release status. The ONLY valid release plan.
`docs/RELEASE_PLAN.md` was a shadow copy — it has been removed.

**When documents conflict:** Tier 1 wins over Tier 2. Tier 2 wins over Tier 3. Always.

---

## CLAUDE.md EDIT POLICY

This file is read-only at the filesystem level (`chmod 444`).

Only the project owner edits it, in a terminal, never through Claude Code.

The document governing the agent cannot be editable by the agent. This is permanent.

If you encounter a permissions error trying to write to this file, that is working as intended. Do not attempt to change file permissions. Do not suggest workarounds. Report it as: "CLAUDE.md is read-only as expected."

---

## AGENT TEAM

The agent team is defined in `.agent_docs/agent_team.md`.

Do NOT use any agent definitions from `.claude/agents/` that are not listed in agent_team.md.
The following old agents have been archived and must not be used:
- FRAMEWORK.md (archived)
- builder.md (archived)
- gatekeeper.md (archived — replaced by enforcer)
- orchestrator.md (archived — replaced by new orchestrator spec)
- sentinel.md (archived — replaced by enforcer)

---

## CRITICAL LIVE FEATURE

**VAPI Webhook (email on call complete)** is the ONLY production feature currently running.

Any commit that modifies webhook-related files must be flagged for explicit owner review, even if it passes all other enforcer gates.

Verify webhook functionality:
- Before any rollback
- After any rollback
- Before any deployment
- After any code change to webhook files

---

=== PASTE END ===

---

## Verification After Pasting

After editing and locking CLAUDE.md, verify these items are present:
- [ ] Enforcer system section (near top)
- [ ] Commit authorization rule
- [ ] Incident record (Feb 27-28)
- [ ] Source of truth hierarchy (3 tiers)
- [ ] CLAUDE.md edit policy (read-only)
- [ ] Agent team reference (points to .agent_docs/agent_team.md)
- [ ] Critical live feature (VAPI webhook)
- [ ] No references to docs/RELEASE_PLAN.md remain
- [ ] No "Agent Identity: SRVO" section remains
- [ ] No self-assigned autonomy levels remain
- [ ] File permissions show r--r--r-- (chmod 444)
