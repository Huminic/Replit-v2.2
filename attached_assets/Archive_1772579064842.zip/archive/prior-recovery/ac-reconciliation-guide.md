# Acceptance Criteria Reconciliation Guide
**Prepared:** 2026-03-01
**Purpose:** Instructions for reconciling the authoritative AC with testing kit batteries to produce a comprehensive, gap-free acceptance criteria document.
**Used in:** Phase 8 of the adapted recovery plan.

---

## Inputs

| Document | Location | Role |
|----------|----------|------|
| Authoritative AC | `filestore/nexxus_authoritative_plan/1b_ACCEPTANCE_CRITERIA.md` | Original acceptance criteria (5 ACs) |
| Release Criteria | `filestore/final_testing_kit/release_criteria.md` | 61 identified gaps |
| Battery B1 | `filestore/final_testing_kit/B1_agent_config_battery.md` | Agent configuration tests |
| Battery B2 | `filestore/final_testing_kit/B2_widget_page_battery.md` | Widget and page tests |
| Battery B3 | `filestore/final_testing_kit/B3_inbound_battery.md` | Inbound communication tests |
| Battery B4 | `filestore/final_testing_kit/B4_outbound_battery.md` | Outbound communication tests |
| Battery B5 | `filestore/final_testing_kit/B5_calendar_battery.md` | Calendar integration tests |
| Battery B6 | `filestore/final_testing_kit/B6_e2e_regression.md` | End-to-end regression tests |
| Reference UI | `filestore/nexus-v2-1-current/` | Immutable UI spec (Tier 1 truth) |

---

## Step 1 — Read All Inputs

Read every file listed above. Do not skip any. Take notes on:
- What requirements each AC covers
- What each test battery tests
- What gaps release_criteria.md identifies

---

## Step 2 — Build the Cross-Reference Matrix

Create a matrix mapping:

| Requirement | Source AC | Test Battery | Gap ID (if any) | Status |
|------------|----------|-------------|-----------------|--------|
| [requirement description] | [AC-1, AC-2, etc.] | [B1, B2, etc.] | [GAP-001, etc.] | [COVERED / GAP / PARTIAL] |

For each requirement:
- If it's in both AC and a test battery → COVERED
- If it's in AC but no test battery covers it → GAP (testing gap)
- If a test battery tests something not in AC → GAP (AC gap — AC needs to include this)
- If it's partially covered → PARTIAL (document what's missing)

---

## Step 3 — Identify Agent-Based Communication Gaps

The project had a late architectural shift to agent-based communication. This means:
- The original AC was written for a direct API/webhook communication model
- The current implementation uses AI agents as intermediaries
- Test batteries may or may not account for this shift

Specifically check:
- Does the AC mention agent personas, agent configuration, or agent-based routing?
- Do the test batteries test agent behavior (not just API endpoints)?
- Is there a gap between "the API works" and "the agent uses the API correctly"?

Flag every instance where the agent-based approach creates a new requirement not in the original AC.

---

## Step 4 — Check Against UI Spec (Tier 1)

For every requirement in the reconciled AC:
- Does it align with what the reference UI shows?
- Does the UI imply requirements that neither the AC nor the test batteries mention?
- Are there UI elements that suggest functionality not tested by any battery?

Remember: UI is Tier 1 truth. If the UI shows a feature, it's a requirement — even if the AC doesn't mention it.

---

## Step 5 — Produce the Reconciled Document

Write `.agent_docs/acceptance_criteria.md` with this structure:

```
# Acceptance Criteria — Nexxus v2
<!-- Reconciled from authoritative AC + testing kit on [date] -->

## Source Documents
[list all inputs with paths]

## Definition of Done — Project Level
[derived from release_criteria.md + AC]

## Definition of Done — Sprint Level
[derived from quality gates + AC]

## Definition of Done — Feature Level
[per-feature criteria below]

---

## AC-1: [First Acceptance Criterion]
**Source:** [original AC reference]
**Test Battery:** [which battery covers this]
**Gaps Identified:** [gap IDs from release_criteria.md]

### Requirements
- [ ] [requirement 1]
- [ ] [requirement 2]

### Agent-Based Communication Requirements
- [ ] [any additional requirements from the arch shift]

### UI Alignment
- [ ] [UI elements that relate to this AC]

---

[Repeat for each AC]

---

## New Requirements (Not in Original AC)

### From Testing Kit
[requirements discovered in test batteries that weren't in the AC]

### From UI Spec
[requirements implied by the UI that weren't in the AC]

### From Agent-Based Architecture
[requirements created by the communication model shift]

---

## Non-Functional Requirements
- Performance: [from quality gates]
- Security: [from safety gates]
- Accessibility: [from UI standards]

---

## Reconciliation Log
| Original AC Item | Test Battery Coverage | Gap Status | Notes |
|-----------------|---------------------|------------|-------|
```

---

## Step 6 — Verify Completeness

Before presenting to owner:
- [ ] Every AC from the authoritative document is represented
- [ ] Every test battery maps to at least one AC
- [ ] Every gap in release_criteria.md is addressed (either as a requirement or as a noted exception)
- [ ] Agent-based communication requirements are explicitly called out
- [ ] UI spec alignment is checked for every feature
- [ ] No requirements from the shadow RELEASE_PLAN (docs/RELEASE_PLAN.md) — that was contaminated
- [ ] The reconciled document follows the enforcer-required format

---

## Trust Rules During Reconciliation

1. If the UI shows it, it's a requirement — even if the AC doesn't mention it
2. If the AC says it but the UI doesn't show it, check if it's a backend requirement (still valid) or a UI gap (may need UI addition)
3. If the testing kit tests it but AC doesn't mention it, add it to AC — the testing kit may have caught something the AC missed
4. Never reference docs/RELEASE_PLAN.md — it was the shadow copy. Use only the authoritative copy at filestore/nexxus_authoritative_plan/1a_RELEASE_PLAN.md
5. When in doubt, the truth hierarchy decides: UI > AC > Release Plan
