#!/bin/bash
# Shadow Monitor — Nexxus v2 Method Enforcement Compliance Watcher
# Runs from the workbench, watches the nexxus-v2 project for violations
# Usage: ./shadow-monitor.sh [interval_seconds]
#   Default interval: 30 seconds
#   Output: shadow-monitor.log (appended)

NEXXUS="/home/ubuntu/Claude-store/nexxus-v2"
LOGFILE="/home/ubuntu/Claude-store/Nexxus_workbench/shadow-monitor.log"
INTERVAL="${1:-30}"
LAST_RC_HASH=""
LAST_WT_HASH=""
LAST_MEM_HASH=""

log() {
    echo "[$(date -u '+%Y-%m-%dT%H:%M:%SZ')] $1" >> "$LOGFILE"
}

alert() {
    echo "[$(date -u '+%Y-%m-%dT%H:%M:%SZ')] *** ALERT *** $1" >> "$LOGFILE"
}

check_evidence_dirs() {
    local battery="$1"
    local dir="$NEXXUS/evidence/$battery"
    if [ -d "$dir" ]; then
        local png_count=$(find "$dir" -name "*.png" 2>/dev/null | wc -l)
        local json_count=$(find "$dir" -name "*.json" 2>/dev/null | wc -l)
        local txt_count=$(find "$dir" -name "*.txt" -o -name "*.md" -o -name "*.log" 2>/dev/null | wc -l)
        local total=$(find "$dir" -type f 2>/dev/null | wc -l)
        echo "$battery: ${png_count}png ${json_count}json ${txt_count}txt (${total} total)"
    else
        echo "$battery: NO DIRECTORY"
    fi
}

check_screenshot_minimums() {
    local battery="$1"
    local minimum="$2"
    local dir="$NEXXUS/evidence/$battery"
    if [ -d "$dir" ]; then
        local png_count=$(find "$dir" -name "*.png" 2>/dev/null | wc -l)
        if [ "$png_count" -lt "$minimum" ]; then
            alert "SCREENSHOT DEFICIT: $battery has $png_count PNGs (minimum: $minimum) — Enforcer Rule 13"
        fi
    fi
}

check_release_criteria() {
    local rc_file="$NEXXUS/filestore/final_testing_kit/release_criteria.md"
    if [ -f "$rc_file" ]; then
        local current_hash=$(md5sum "$rc_file" | cut -d' ' -f1)
        if [ -n "$LAST_RC_HASH" ] && [ "$current_hash" != "$LAST_RC_HASH" ]; then
            log "CHANGE DETECTED: release_criteria.md updated"

            # Check if header was updated for Run 2
            if grep -q "Run 2" "$rc_file" | head -5; then
                log "  Run 2 header: PRESENT"
            else
                log "  Run 2 header: MISSING"
            fi

            # Count gaps by status
            local open=$(grep -c "| OPEN |" "$rc_file" 2>/dev/null || echo 0)
            local fixed=$(grep -c "| FIXED |" "$rc_file" 2>/dev/null || echo 0)
            local reverted=$(grep -c "REVERTED TO OPEN" "$rc_file" 2>/dev/null || echo 0)
            local verified=$(grep -c "VERIFIED FIXED (M" "$rc_file" 2>/dev/null || echo 0)
            log "  Gaps: OPEN=$open FIXED=$fixed REVERTED=$reverted VERIFIED(Run2)=$verified"

            # Check for new P0s
            local p0_open=$(grep "| P0 |" "$rc_file" | grep -c "| OPEN |" 2>/dev/null || echo 0)
            if [ "$p0_open" -gt 0 ]; then
                alert "P0 BLOCKER DETECTED: $p0_open open P0 gaps in release_criteria.md"
            fi

            # Check for gaps missing Evidence Method
            local gaps_no_method=$(grep "^| GAP-" "$rc_file" | grep -cv "M[1-5]" 2>/dev/null || echo 0)
            if [ "$gaps_no_method" -gt 0 ]; then
                log "  WARNING: $gaps_no_method gap entries may lack Evidence Method field"
            fi
        fi
        LAST_RC_HASH="$current_hash"
    fi
}

check_work_tree() {
    local wt_file="$NEXXUS/.agent_docs/work_tree.md"
    if [ -f "$wt_file" ]; then
        local current_hash=$(md5sum "$wt_file" | cut -d' ' -f1)
        if [ -n "$LAST_WT_HASH" ] && [ "$current_hash" != "$LAST_WT_HASH" ]; then
            log "CHANGE DETECTED: work_tree.md updated"
            local blocked=$(grep -c "BLOCKED" "$wt_file" 2>/dev/null || echo 0)
            if [ "$blocked" -gt 0 ]; then
                alert "BLOCKED TASK in work_tree.md ($blocked occurrences)"
            fi
        fi
        LAST_WT_HASH="$current_hash"
    fi
}

check_memory() {
    local mem_file="$NEXXUS/.agent_docs/memory.md"
    if [ -f "$mem_file" ]; then
        local current_hash=$(md5sum "$mem_file" | cut -d' ' -f1)
        if [ -n "$LAST_MEM_HASH" ] && [ "$current_hash" != "$LAST_MEM_HASH" ]; then
            log "CHANGE DETECTED: memory.md updated"
            # Check for risk entries
            local risks=$(grep -ic "risk\|blocker\|critical" "$mem_file" 2>/dev/null || echo 0)
            log "  Risk/blocker mentions: $risks"
        fi
        LAST_MEM_HASH="$current_hash"
    fi
}

check_webhook() {
    # Check if webhook endpoint is responding
    local webhook_status=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost:5020/api/webhooks/vapi" -X POST -H "Content-Type: application/json" -d '{}' 2>/dev/null)
    if [ "$webhook_status" != "200" ] && [ "$webhook_status" != "400" ]; then
        alert "WEBHOOK HEALTH: /api/webhooks/vapi returned HTTP $webhook_status (expected 200 or 400)"
    fi
}

check_method_compliance() {
    # Check for evidence of M4-only testing (the violation we're preventing)
    for battery in b1 b2 b3 b4 b5 b6; do
        local dir="$NEXXUS/evidence/$battery"
        if [ -d "$dir" ]; then
            local total=$(find "$dir" -type f 2>/dev/null | wc -l)
            local png_count=$(find "$dir" -name "*.png" 2>/dev/null | wc -l)
            local api_count=$(find "$dir" -name "*.json" -o -name "*api*" -o -name "*response*" 2>/dev/null | wc -l)

            # If evidence exists but zero screenshots AND zero API logs → M4-only violation
            if [ "$total" -gt 0 ] && [ "$png_count" -eq 0 ] && [ "$api_count" -eq 0 ]; then
                alert "METHOD VIOLATION: $battery has $total evidence files but 0 screenshots and 0 API logs — possible M4-only testing"
            fi
        fi
    done
}

check_enforcer_pass() {
    local ep_file="$NEXXUS/.agent_docs/ENFORCER_PASS.md"
    if [ -f "$ep_file" ]; then
        local verdict=$(grep -i "verdict\|result\|status" "$ep_file" | head -1)
        log "ENFORCER_PASS.md exists: $verdict"
        if grep -qi "BLOCKED\|FAIL\|REJECT" "$ep_file"; then
            alert "ENFORCER BLOCKED: $(grep -i 'blocked\|fail\|reject' "$ep_file" | head -1)"
        fi
    fi
}

# --- Main loop ---
log "=== Shadow Monitor Started (interval: ${INTERVAL}s) ==="
log "Monitoring: $NEXXUS"

# Initial state capture
LAST_RC_HASH=$(md5sum "$NEXXUS/filestore/final_testing_kit/release_criteria.md" 2>/dev/null | cut -d' ' -f1)
LAST_WT_HASH=$(md5sum "$NEXXUS/.agent_docs/work_tree.md" 2>/dev/null | cut -d' ' -f1)
LAST_MEM_HASH=$(md5sum "$NEXXUS/.agent_docs/memory.md" 2>/dev/null | cut -d' ' -f1)

log "Initial state captured"

while true; do
    # Evidence directory status
    for battery in b1 b2 b3 b4 b5 b6; do
        result=$(check_evidence_dirs "$battery")
        # Only log if directory exists (battery started)
        if [[ "$result" != *"NO DIRECTORY"* ]]; then
            log "EVIDENCE: $result"
        fi
    done

    # Screenshot minimums (per enforcer Rule 13)
    check_screenshot_minimums "b2" 15
    check_screenshot_minimums "b3" 8
    check_screenshot_minimums "b5" 6
    check_screenshot_minimums "b6" 20

    # Release criteria changes
    check_release_criteria

    # Work tree changes
    check_work_tree

    # Memory changes
    check_memory

    # Method compliance check
    check_method_compliance

    # Enforcer pass file
    check_enforcer_pass

    # Webhook health (every 5th cycle to avoid noise)
    CYCLE_COUNT=$((${CYCLE_COUNT:-0} + 1))
    if [ $((CYCLE_COUNT % 5)) -eq 0 ]; then
        check_webhook
    fi

    sleep "$INTERVAL"
done
