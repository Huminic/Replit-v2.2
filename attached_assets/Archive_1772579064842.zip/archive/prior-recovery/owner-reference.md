# Owner Reference Guide — Nexxus v2 Recovery
**Prepared:** 2026-03-01
**For:** Duane (Project Owner)
**Purpose:** Quick reference while the enforcer system runs. Not a manual — the system runs itself. This tells you what's happening and what to do when it pauses.

---

## 1. What the Enforcer System Is

A guard that physically blocks commits until verification passes. It's two shell scripts:
- One inside Claude Code (intercepts commit commands before they execute)
- One at the git level (blocks commits even if something bypasses Claude Code)

Neither can be talked around, reasoned with, or overridden by any agent. They check for a sign-off file. No file, no commit. Period.

The enforcer AGENT reads the project map, checks compliance, and writes the sign-off file when everything passes. The hooks just check if that file exists.

---

## 2. How the Hooks Work

**Layer 1 — Claude Code hook** (`.claude/hooks/enforcer-gate.sh`)
- Runs BEFORE any bash command in Claude Code
- If the command is `git commit`: checks for sign-off file → blocks or allows
- If the command is `git tag`: blocks and requires full sprint review
- All other commands: passes through

**Layer 2 — Git hook** (`.git/hooks/pre-commit`)
- Runs AFTER git commit is attempted at the OS level
- Same check: sign-off file exists? → allow or block
- Catches anything that gets past Layer 1

Both layers must pass. An agent cannot commit without the enforcer's written approval.

---

## 3. How to Read an Enforcer Report

The enforcer produces a structured report every time it reviews. Here's what the verdict means:

**BLOCKED** — Something failed. The report lists RED blockers that must be fixed.
- The system will NOT commit until all blockers are resolved
- You don't need to fix them — the builders do. Then the enforcer re-checks.
- If the same blocker appears twice in a row, the system escalates to you automatically.

**WARNING** — Something is concerning but not blocking. The commit can proceed.
- Read these — they might become blockers later.

**APPROVED** — Everything passed. The enforcer has written its sign-off.
- The system will present the change summary to you.
- You say "commit" to authorize it.

---

## 4. Your Checkpoints

The system pauses at exactly 7 points. At each one, you make a decision:

| # | When | What You Do |
|---|------|-------------|
| 1 | After enforcer scans the project | Review the scan report. Any surprises? Say "proceed" |
| 2 | Before rollback | The system has verified the webhook works. Say "proceed with rollback" |
| 3 | After rollback | Check your email — did the webhook test email arrive? Say "proceed" |
| 4 | Patch evaluation complete | Review the catalog of what passed/failed criteria. Say "proceed with re-application" |
| 5 | Each commit | Enforcer already approved it. Say "commit" to authorize |
| 6 | Before test batteries | Review the test strategy briefing. Say "proceed" |
| 7 | Final release | All evidence presented. You decide: release, hold, or partial release |

**Between checkpoints:** The system works autonomously. The enforcer watches every step.

---

## 5. Emergency Bypass

If something is stuck and you need to force a commit:

```bash
git commit --no-verify -m "BYPASS:[reason] — Owner approved [date]"
```

Rules:
- This skips BOTH hooks
- You MUST log it: tell the session to add an entry to `.agent_docs/conflict_resolution.md`
- The enforcer will flag it at next review
- Use sparingly — this is the escape hatch, not the normal path

---

## 6. How to Edit CLAUDE.md

CLAUDE.md is locked read-only. If you need to edit it:

```bash
# 1. Unlock
chmod 644 ~/Claude-store/nexxus-v2/CLAUDE.md

# 2. Edit
nano ~/Claude-store/nexxus-v2/CLAUDE.md

# 3. Re-lock
chmod 444 ~/Claude-store/nexxus-v2/CLAUDE.md

# 4. Verify
ls -la ~/Claude-store/nexxus-v2/CLAUDE.md
# Should show: r--r--r--
```

Never do this through Claude Code. Always in your terminal.

---

## 7. What the Agents Do

**Enforcer** — Your representative. Reviews everything, blocks bad commits, writes sign-offs. Cannot be overruled. Reports directly to you.

**Orchestrator/MTC** — Project manager + test coordinator. Assigns work to builders, coordinates sprints, runs test batteries. Does NOT write code. Does NOT self-certify.

**Builder 1 (Identity + Pipeline)** — Builds persona system, agent config, widget integration, SMS integration. Works in isolated worktree.

**Builder 2 (Triggers)** — Builds the idle trigger system. Isolated scope, isolated worktree.

**Builder 3 (Public Pages)** — Builds hosted pages and embeddable widgets. Isolated scope, isolated worktree.

---

## 8. Quick Reference

| Action | Command / Location |
|--------|-------------------|
| Check enforcer status | Look for `.agent_docs/ENFORCER_PASS.md` — exists means approved |
| Read enforcer report | The session will display it inline |
| Check work progress | `.agent_docs/work_tree.md` |
| Check decisions log | `.agent_docs/memory.md` |
| Check escalations | `.agent_docs/conflict_resolution.md` |
| Check project map | `.agent_docs/enforcer_context.md` |
| Authoritative release plan | `filestore/nexxus_authoritative_plan/1a_RELEASE_PLAN.md` |
| Reference UI (immutable) | `filestore/nexus-v2-1-current/` |
| Testing kit | `filestore/final_testing_kit/` |
| Patch file (backup) | `~/Claude-store/Nexxus_workbench/work_to_review.patch` |
| Archive | `~/Claude-store/filestore/archive/nexxus2_1/` |
| Full audit | `~/Claude-store/Nexxus_workbench/incident-audit-and-recovery-plan.md` |

---

## What To Do If...

**The system seems stuck:** Check if it's waiting at a checkpoint for your input. Say "proceed" or "commit" as appropriate.

**The enforcer keeps blocking:** Read the report. If the same blocker appears twice, the system will escalate to you automatically. Decide: fix it, grant an exception, or bypass.

**You want to stop everything:** Just close the Claude Code session. Nothing commits without your "commit" command. The enforcer system remains installed for next time.

**You see something wrong:** Say "stop" or "wait." The system respects stop commands. Then explain what you noticed.

**The webhook breaks:** This is the one thing that matters right now. If the webhook stops working at any point, say "stop — webhook is broken" and the system halts until it's fixed.
