# Work Tree — Nexxus v2

> This file tracks the current state of all work items.
> Agents MUST update this file when task status changes — do not wait until the end of a sprint.
> Format is enforcer-required. Do not change section names or structure.

---

## Sprint 0 — Recovery & Enforcer Bootstrap

**Sprint Period:** [start date] → [end date]

---

### IN PROGRESS

| Task | Agent | Started | Notes |
|------|-------|---------|-------|

---

### COMPLETED THIS SPRINT

| Task | Agent | Completed | Verification |
|------|-------|-----------|--------------|

---

### BLOCKED

| Task | Agent | Blocked Since | Blocked By | Escalated? |
|------|-------|--------------|------------|------------|

---

### NOT STARTED (This Sprint)

| Task | Priority | Assigned To | Dependency |
|------|----------|-------------|------------|
| Install enforcer system files from deploy/ | HIGH | Orchestrator | None |
| Archive old .claude/agents/ files (5 files) | HIGH | Orchestrator | None |
| Make hooks executable | HIGH | Orchestrator | Install enforcer files |
| Run /init-enforcer — scan, map, flag issues | HIGH | Orchestrator | Make hooks executable |
| Test commit block — enforcer should prevent it | HIGH | Orchestrator | Run /init-enforcer |
| Verify webhook at current HEAD (pre-rollback) | HIGH | Builder 1 | None |
| Execute git rollback to 95c0290 | HIGH | Orchestrator | Owner authorization (CHECKPOINT 2) |
| Verify webhook at 95c0290 (post-rollback) | HIGH | Builder 1 | Execute rollback |
| Delete shadow RELEASE_PLAN at docs/RELEASE_PLAN.md | MED | Orchestrator | Execute rollback |
| Bootstrap .agent_docs/ governance documents | MED | Orchestrator | Delete shadow plan |
| Classify patch file changes against truth hierarchy | MED | Orchestrator | Bootstrap .agent_docs/ |
| Present patch evaluation catalog to owner | MED | Orchestrator | Classify patch changes |
| Re-apply approved patch changes through quality gates | MED | Builders | Owner authorization (CHECKPOINT 5) |
| Write DOWN migration scripts for 037-040 | MED | Builder 1 | Execute rollback |
| Create migration tracking table | MED | Owner (manual) | None |
| Reconcile acceptance criteria with testing kit | MED | Orchestrator | Bootstrap .agent_docs/ |
| Run test batteries (B1-B6) | LOW | Orchestrator/MTC | Reconcile AC |
| Final release validation | LOW | Orchestrator/MTC | Run test batteries |

---

## Backlog (Future Sprints)

| Task | Target Sprint | Priority | Notes |
|------|--------------|----------|-------|
| Implement remaining UI features per reference spec | Sprint 1 | HIGH | Post-recovery |
| Two-way SMS integration | Sprint 1 | HIGH | Customer requirement |
| Lead management dashboard | Sprint 1 | HIGH | Customer requirement |
| Public pages (hosted + embed) | Sprint 2 | MED | |
| Idle trigger system | Sprint 2 | MED | |

---

## Work Tree Update Log

> Agents: add an entry every time you change a task's status.

| Date | Agent | Change Made |
|------|-------|-------------|
