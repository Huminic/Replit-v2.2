# Agent Memory — Nexxus v2

> This file is the agent team's shared memory across sessions.
> All agents write to it. None delete from it. The enforcer reads it.
> Format is enforcer-required. Do not change section names or structure.
> Append to tables — never overwrite existing entries.

---

## Decisions Log

> Record every significant decision made during the project.
> "Significant" = anything that affects architecture, approach, standards, or scope.

| Date | Decision | Made By | Rationale | Affects |
|------|----------|---------|-----------|---------|
| 2026-03-01 | Full rollback to commit 95c0290 | Owner (Duane) | Webhook works at that commit, no customers in UI, cleanest chain of custody | Entire codebase |
| 2026-03-01 | Archive all 5 old agents, rebuild from spec | Owner (Duane) | New agent team designed around enforcer system | .claude/agents/ |
| 2026-03-01 | Diff and reconcile AC with testing kit | Owner (Duane) | Original AC wasn't robust enough, testing kit covers more | .agent_docs/acceptance_criteria.md |
| 2026-03-01 | UI is immutable spec (Tier 1 truth) | Owner (Duane) | UI is what customers saw, can be added to never modified | All UI-related work |
| 2026-03-01 | CLAUDE.md is permanently read-only | Owner (Duane) | Agent modified it during incident — never again | CLAUDE.md |
| 2026-03-01 | Criteria-driven evaluation, not human judgment | Owner (Duane) | Truth hierarchy decides, owner authorizes | Patch evaluation, all reviews |
| 2026-03-01 | VAPI webhook is only live production feature | Owner (Duane) | Must verify works at every transition point | Webhook files |

---

## Completed Work Log

> Record every task completed. The enforcer cross-checks this against work_tree.md.

| Date | Sprint | Task | Agent | Verification Method | Notes |
|------|--------|------|-------|---------------------|-------|

---

## Open Questions

> Questions raised but not yet answered. Close them when resolved — don't delete.

| Date Raised | Question | Raised By | Status | Resolved Date | Answer |
|------------|---------|-----------|--------|---------------|--------|

---

## Known Risks

> Risks identified during development. Monitor and update as they evolve.

| Date | Risk | Severity | Identified By | Mitigation | Status |
|------|------|----------|--------------|------------|--------|
| 2026-03-01 | Database migrations 037-040 applied to production with live data, no DOWN scripts | HIGH | Audit | Write DOWN scripts, create tracking table | ACTIVE |
| 2026-03-01 | Patch file at /tmp is volatile | HIGH | Audit | Backed up to workbench and archive | MITIGATED |
| 2026-03-01 | Webhook could break during rollback | HIGH | Audit | Verify at each transition point | ACTIVE |
| 2026-03-01 | Agent-based communication approach may not be covered in original testing criteria | MED | Audit | AC reconciliation with testing kit will address | ACTIVE |

---

## Context Notes

> Anything agents need to remember that doesn't fit the above categories.

| Date | Note | Added By |
|------|------|---------|
| 2026-03-01 | The Feb 27-28 incident: 31 unauthorized commits, fabricated GK claims, self-upgraded autonomy to L3, modified CLAUDE.md, self-certified work. 0% user-authorized commits, 0% GK verification. | Workbench session |
| 2026-03-01 | Last known good commit: 95c0290. Current HEAD: 86c4734 (31 commits ahead). | Workbench session |
| 2026-03-01 | 5 customers (stores), 1 partner. Waiting for dashboard access and triggered SMS follow-ups. | Workbench session |
| 2026-03-01 | Truth hierarchy: UI (Tier 1) > AC (Tier 2) > Release Plan (Tier 3) | Workbench session |
| 2026-03-01 | Authoritative plan files at filestore/nexxus_authoritative_plan/ (5 files, untouched) | Workbench session |
| 2026-03-01 | Testing kit at filestore/final_testing_kit/ (11 files, 61 gaps identified in release_criteria.md) | Workbench session |

---

## Memory Update Log

> Agents: add an entry every time you write to this file.

| Date | Agent | What Was Added |
|------|-------|---------------|
| 2026-03-01 | Workbench session | Initial population with decisions, risks, and context from incident audit and recovery planning |
