# Conflict Resolution Log — Nexxus v2

> This file records all enforcer escalations, bypasses, and disputed findings.
> Written to by agents. Reviewed by the project owner.
> Never delete entries — append only.

---

## Escalation Triggers

Escalation is required when ANY of these occur:

1. The enforcer issues a BLOCKED verdict twice in a row on the same finding
2. An agent uses `git commit --no-verify` (emergency bypass)
3. A task has been in the BLOCKED state for more than 3 business days
4. An agent believes the enforcer is flagging a false positive
5. The enforcer's own context file has drifted significantly (3+ files missing)

---

## Escalation Protocol

1. STOP work on the blocked item
2. Log the escalation in the Active Escalations table below
3. Notify the owner: "ESCALATION REQUIRED: [summary]. Details in conflict_resolution.md."
4. Wait for owner decision — continue other unblocked work
5. Owner decides: FIX IT / EXCEPTION / BYPASS
6. Close the escalation with resolution details

---

## Active Escalations

| ID | Date | Type | Sprint | What Was Blocked | What Was Tried | Owner Decision | Resolved |
|----|------|------|--------|-----------------|----------------|----------------|---------|

---

## Granted Exceptions

> Deviations from standards the owner has explicitly approved.
> Also recorded in enforcer_context.md Known Issues section.

| ID | Date | Exception | Reason | Owner Approval | Expiry Sprint |
|----|------|-----------|--------|----------------|---------------|

---

## Bypass Log

> Every use of --no-verify is recorded here. The enforcer flags these at next review.

| Date | Agent | Commit Hash | Reason | Owner Approved |
|------|-------|-------------|--------|----------------|

---

## Disputed Findings

> When an agent believes the enforcer is wrong.

| ID | Date | Agent | What Enforcer Flagged | Why Agent Disagrees | Evidence | Owner Ruling |
|----|------|-------|--------------------|--------------------|---------|----|
