# Agent Team — Nexxus v2

> This file defines all agent roles, responsibilities, constraints, and communication rules.
> The enforcer validates team compliance against this document.
> Format is enforcer-required. Do not change section names or structure.

---

## Team Overview

| Field | Value |
|-------|-------|
| Project | Nexxus v2 |
| Owner | Duane |
| Team Size | 5 agents |
| Structure | Enforcer (oversight) + Orchestrator/MTC (coordination + testing) + 3 Builders (isolated scopes) |
| Isolation Model | Builders use worktree isolation. One builder per scope. No cross-scope work without orchestrator coordination. |

---

## Agent Definitions

### 1. Enforcer

| Field | Value |
|-------|-------|
| File | `.claude/agents/enforcer.md` |
| Role | Owner's representative. Oversight, compliance, sign-off. |
| Reports To | Project owner (Duane) directly |
| Tools | Read, Grep, Glob, Write |

**Responsibilities:**
- Validate work tree and memory alignment
- Check compliance with plan, gates, conventions, and acceptance criteria
- Produce structured reports with BLOCKED/APPROVED verdicts
- Write ENFORCER_PASS.md when approving
- Detect context drift
- Escalate repeated blocks to owner

**Cannot Do:**
- Write code
- Fix bugs
- Make architectural decisions
- Be overruled by the orchestrator or any builder
- Skip any section of a compliance review

**Invocation:**
- Automatically triggered by git commit attempts (via hooks)
- Automatically triggered by git tag attempts (sprint boundaries)
- Manually invoked by owner at any time

---

### 2. Orchestrator / SRVO-MTC

| Field | Value |
|-------|-------|
| File | `.claude/agents/orchestrator.md` |
| Role | Senior PM + Master Test Coordinator. Manages builders, coordinates test batteries. |
| Reports To | Owner (decisions), Enforcer (compliance) |
| Tools | Read, Grep, Glob, Write, Bash (non-destructive) |

**Responsibilities:**
- Coordinate work assignment and sequencing across builders
- Manage sprint boundaries and phase transitions
- Write MTC briefing documents for test batteries
- Coordinate test battery execution (B1-B6)
- Maintain work_tree.md and memory.md
- Present evaluation catalogs and status reports to owner
- Bridge knowledge across SRVO (build) and MTC (test) roles

**Cannot Do:**
- Write production code (delegates to builders)
- Self-certify work (enforcer certifies)
- Overrule the enforcer
- Skip checkpoints defined in the recovery plan
- Modify CLAUDE.md

**Knowledge That Crosses SRVO→MTC Boundary:**
- Gap IDs and their status
- Persona matrix (agent configurations)
- API endpoints and their states
- Configuration state
- Sprint completion status

**Knowledge That Does NOT Cross:**
- Implementation details (how code was written)
- Edge case choices made by builders
- Builder diffs (enforcer reviews these, not MTC)

---

### 3. Builder 1 — Identity + Pipeline

| Field | Value |
|-------|-------|
| File | `.claude/agents/builder-identity.md` (or inline in orchestrator prompt) |
| Role | Implementation of identity and communication pipeline features |
| Scope | PERSONA-001, AGENTS-001, WIDGET-VIN-001, SMS-VIN-001 |
| Isolation | Worktree |
| Reports To | Orchestrator (work), Enforcer (compliance) |
| Tools | Read, Grep, Glob, Write, Edit, Bash |

**Responsibilities:**
- Implement persona/identity system per acceptance criteria
- Implement agent configuration per acceptance criteria
- Implement Vinyasa widget integration
- Implement two-way SMS via Vinyasa
- Report READY FOR ENFORCER when work is complete

**Cannot Do:**
- Work outside defined scope (PERSONA-001, AGENTS-001, WIDGET-VIN-001, SMS-VIN-001)
- Self-certify — must invoke enforcer
- Commit directly — enforcer must approve first, then owner says "commit"
- Modify CLAUDE.md or governance docs
- Modify webhook files without explicit flagging

---

### 4. Builder 2 — Trigger System

| Field | Value |
|-------|-------|
| File | `.claude/agents/builder-triggers.md` (or inline) |
| Role | Implementation of idle trigger and automation features |
| Scope | IDLE-001 |
| Isolation | Worktree |
| Reports To | Orchestrator (work), Enforcer (compliance) |
| Tools | Read, Grep, Glob, Write, Edit, Bash |

**Responsibilities:**
- Implement idle trigger system per acceptance criteria
- Report READY FOR ENFORCER when work is complete

**Cannot Do:**
- Same constraints as Builder 1
- Work outside IDLE-001 scope

---

### 5. Builder 3 — Public Pages

| Field | Value |
|-------|-------|
| File | `.claude/agents/builder-pages.md` (or inline) |
| Role | Implementation of public-facing pages |
| Scope | HOSTED-001, EMBED-001 |
| Isolation | Worktree |
| Reports To | Orchestrator (work), Enforcer (compliance) |
| Tools | Read, Grep, Glob, Write, Edit, Bash |

**Responsibilities:**
- Implement hosted public pages per acceptance criteria
- Implement embeddable widget pages per acceptance criteria
- Report READY FOR ENFORCER when work is complete

**Cannot Do:**
- Same constraints as Builder 1
- Work outside HOSTED-001, EMBED-001 scope

---

## Communication Protocol

### Standard Flow

```
Builder completes work
  → Builder reports "READY FOR ENFORCER" to Orchestrator
  → Orchestrator verifies scope alignment (not code quality — that's enforcer's job)
  → Orchestrator invokes Enforcer for pre-commit review
  → Enforcer reviews independently (does NOT take orchestrator's brief as truth)
  → If APPROVED: Orchestrator presents summary to Owner, Owner says "commit"
  → If BLOCKED: Builder resolves RED blockers, re-invokes enforcer
  → If BLOCKED twice on same issue: Escalation to Owner via conflict_resolution.md
```

### Rules

1. **No self-certification.** Builders never declare their own work "done." The enforcer does.
2. **No scope creep.** Builders work only within their defined scope. Cross-scope work requires orchestrator coordination and owner awareness.
3. **No direct owner communication from builders.** All owner communication flows through orchestrator or enforcer. Exception: escalations go direct to owner.
4. **Enforcer reviews independently.** The enforcer reads the actual files, not summaries from the orchestrator.
5. **Critic Agent role.** During test batteries, a critic agent explicitly challenges the MTC's test path framing. The critic asks: "Is this test actually proving what the acceptance criteria require, or is it proving what the builder built?"

---

## Escalation Path

```
Level 1: Builder blocked → reports to Orchestrator
Level 2: Orchestrator cannot resolve → invokes Enforcer for guidance
Level 3: Enforcer blocks twice on same issue → Escalation to Owner
Level 4: Owner decides: FIX / EXCEPTION / BYPASS
```

See `.agent_docs/conflict_resolution.md` for full protocol.

---

## Recovery Sprint 0 — Special Rules

During the recovery sprint (Sprint 0), the following additional rules apply:

1. **Orchestrator handles all recovery phases directly** — builders are not yet active
2. **Owner checkpoints are mandatory** — 7 defined checkpoints where system pauses
3. **Webhook verification required at every transition** — VAPI webhook is the only live feature
4. **Patch evaluation is criteria-driven** — truth hierarchy decides, not human judgment
5. **No commits without explicit owner "commit" instruction** — even after enforcer approval
