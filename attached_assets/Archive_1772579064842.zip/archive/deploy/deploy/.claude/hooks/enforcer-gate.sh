#!/bin/bash

# =============================================================================
# ENFORCER GATE v2 — Claude Code PreToolUse Hook
# Project: Nexxus v2 | Owner: Duane
# Intercepts git commit and git tag commands inside Claude Code sessions
#
# IMPORTANT: This hook communicates via JSON on stdout with exit 0.
# - To BLOCK: exit 0 with {"hookSpecificOutput":{"permissionDecision":"deny","permissionDecisionReason":"..."}}
# - To ALLOW: exit 0 with {"hookSpecificOutput":{"permissionDecision":"allow"}}
# - exit 0 is used for BOTH outcomes. Do NOT use exit 2.
# =============================================================================

INPUT=$(cat)

# Extract the command from hook stdin JSON using jq
COMMAND=$(echo "$INPUT" | jq -r '.tool_input.command // ""' 2>/dev/null)

# If jq fails or no command, allow (not a Bash tool call we care about)
if [ -z "$COMMAND" ]; then
  echo '{"hookSpecificOutput":{"permissionDecision":"allow"}}'
  exit 0
fi

ENFORCER_PASS=".agent_docs/ENFORCER_PASS.md"

# --- COMMIT INTERCEPT ---
if echo "$COMMAND" | grep -qE "git\s+commit"; then

  if [ ! -f "$ENFORCER_PASS" ]; then
    REASON="ENFORCER GATE: Commit blocked. No enforcer sign-off found at .agent_docs/ENFORCER_PASS.md. Invoke the enforcer agent for a pre-commit review. After enforcer review: APPROVED → enforcer writes ENFORCER_PASS.md → retry commit. BLOCKED → resolve RED blockers → re-invoke enforcer → retry commit. If blocked twice on same issue: escalation required — see .agent_docs/conflict_resolution.md"
    echo "{\"hookSpecificOutput\":{\"permissionDecision\":\"deny\",\"permissionDecisionReason\":\"$REASON\"}}"
    exit 0
  fi

  # Check sign-off age
  FILE_TIME=$(stat -c %Y "$ENFORCER_PASS" 2>/dev/null || stat -f %m "$ENFORCER_PASS" 2>/dev/null)
  CURRENT_TIME=$(date +%s)
  if [ -n "$FILE_TIME" ]; then
    AGE=$(( (CURRENT_TIME - FILE_TIME) / 3600 ))
    if [ "$AGE" -gt 24 ]; then
      REASON="ENFORCER GATE: WARNING — sign-off is ${AGE}h old. Re-run the enforcer if major changes were made since last approval."
      # Still allow but with warning in reason
      echo "{\"hookSpecificOutput\":{\"permissionDecision\":\"allow\"}}"
      exit 0
    fi
  fi

  echo '{"hookSpecificOutput":{"permissionDecision":"allow"}}'
  exit 0
fi

# --- SPRINT TAG INTERCEPT ---
if echo "$COMMAND" | grep -qE "git\s+tag"; then
  REASON="ENFORCER GATE: Sprint tag detected — this is a sprint boundary. Invoke the enforcer agent for a FULL sprint review. Sprint closes require a complete compliance pass, not just a pre-commit check. After enforcer APPROVES the sprint, retry the git tag command."
  echo "{\"hookSpecificOutput\":{\"permissionDecision\":\"deny\",\"permissionDecisionReason\":\"$REASON\"}}"
  exit 0
fi

# --- DEFAULT: Allow all other commands ---
echo '{"hookSpecificOutput":{"permissionDecision":"allow"}}'
exit 0
