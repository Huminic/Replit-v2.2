---
description: >
  Scan this project and generate or update .agent_docs/enforcer_context.md.
  Detects existing documentation, flags duplicates, performs drift detection,
  and builds the enforcer's map. Safe to re-run.
allowed-tools: Read, Grep, Glob, Write, Bash
---

# /init-enforcer — Enforcer Context Scanner & Generator

You are running the **init-enforcer** skill for the Nexxus v2 project. Follow every phase below sequentially. Do not skip phases. Do not invent files that do not exist. Report only what you find.

---

## PHASE 0 — Bootstrap Check

1. Attempt to read `.agent_docs/enforcer_context.md`.
2. **If the file exists:**
   - This is a **REFRESH** run. You will update, not overwrite.
   - Extract the current `Context Version` from the file and note it.
   - Extract the current file map (all paths listed under each document type).
   - Preserve any Sprint History, Known Issues, and Decisions Log sections.
3. **If the file does not exist:**
   - This is an **INIT** run. You will create from scratch.
4. Check for a bootstrap completion flag (`bootstrap_complete: YES` or `bootstrap_complete: NO`) in the existing file. If absent, treat as `NO`.
5. Announce the run type before proceeding:
   ```
   INIT-ENFORCER: [INIT / REFRESH] run detected.
   [If REFRESH] Current version: X.Y.Z
   Proceeding with Phase 1...
   ```

---

## PHASE 1 — Create Folder Structure

Check for and create (if missing) the following directories:

- `.agent_docs/`
- `.claude/hooks/`

Report what was created vs. what already existed:

```
Folder Structure:
  .agent_docs/     [CREATED / EXISTS]
  .claude/hooks/   [CREATED / EXISTS]
```

---

## PHASE 2 — Scan for Each Document Type

For **each** document type below, search the entire project tree. Apply the following rule universally:

### DUPLICATE CHECK RULE

If you find **multiple candidates** for a single document role:
1. List ALL candidates with their full paths and file sizes.
2. **STOP** processing that section.
3. Report it as a **CONFLICT**.
4. Ask the user which file is authoritative.
5. Continue scanning the remaining sections — do not block on one conflict.

---

### 2A — Phase & Sprint Plan (`plan_sequence.md`)

**Search for files named:**
- `plan_sequence.md`, `plan.md`, `sprint_plan.md`, `roadmap.md`, `phases.md`

**Search file content for patterns:**
- `## Phase`, `## Sprint`, `## Milestone`

**Search locations (in order):**
- Project root
- `.agent_docs/`
- `docs/`
- `planning/`
- `filestore/nexxus_authoritative_plan/`

**Record:** path, size, last modified, and whether format matches expected structure.

---

### 2B — Release Plan (`release_plan.md`)

**Search for files named:**
- `release_plan.md`, `release.md`, `changelog.md`, `bug_backlog.md`, `RELEASE_PLAN.md`

**Search file content for patterns:**
- `## Known Bugs`, `## Gaps`, `## Release Criteria`

**Search locations (in order):**
- Project root
- `.agent_docs/`
- `docs/`
- `filestore/nexxus_authoritative_plan/`

**IMPORTANT — Shadow Copy Detection:**
The **authoritative** release plan is at:
```
filestore/nexxus_authoritative_plan/1a_RELEASE_PLAN.md
```
Any copy found at `docs/RELEASE_PLAN.md` is a **SHADOW COPY**. Flag it as a **CONFLICT** with the note:
```
CONFLICT: docs/RELEASE_PLAN.md is a shadow copy of the authoritative
filestore/nexxus_authoritative_plan/1a_RELEASE_PLAN.md.
Recommend: delete the shadow or replace with a symlink.
```

---

### 2C — Agent Team Config (`agent_team.md`)

**Search for files named:**
- `agent_team.md`, `agents.md`, `team_config.md`

**Search file content for patterns:**
- `## Agents`, `## Roles`, `## Responsibilities`

**Additional:**
- List all files found in `.claude/agents/` (if directory exists).
- Apply the duplicate check rule to the team config document only (agent definition files in `.claude/agents/` are expected to be multiple).

---

### 2D — Naming Conventions (`conventions.md`)

**Search for files named:**
- `conventions.md`, `naming.md`, `style_guide.md`, `standards.md`

**Search file content for patterns:**
- `## Naming`, `## File Structure`, `## Variables`

---

### 2E — Acceptance Criteria (`acceptance_criteria.md`)

**Search for files named:**
- `acceptance_criteria.md`, `acceptance.md`, `definition_of_done.md`, `dod.md`, `ACCEPTANCE_CRITERIA.md`

**Search file content for patterns:**
- `## Acceptance`, `## Definition of Done`, `## Criteria`

**Search locations (in order):**
- Project root
- `.agent_docs/`
- `docs/`
- `filestore/nexxus_authoritative_plan/`

**Additional:**
- Check `filestore/final_testing_kit/` for test battery files. List any found — these supplement acceptance criteria but are not the criteria document itself.

---

### 2F — Safety Gates (`safety_gates.md`)

**Search for files named:**
- `safety_gates.md`, `safety.md`, `gates.md`, `pre_commit_checks.md`

**Search file content for patterns:**
- `## Safety`, `## Gates`, `## Pre-Deploy`

---

### 2G — Quality Gates (`quality_gates.md`)

**Search for files named:**
- `quality_gates.md`, `quality.md`, `requirements.md`

**Search file content for patterns:**
- `## Quality`, `## Standards`, `## Requirements`

---

### 2H — Work Tree (`work_tree.md`) — STANDARDIZED FORMAT

**Search for files named:**
- `work_tree.md`, `tasks.md`, `todo.md`, `backlog.md`

**Also check CLAUDE.md for embedded sections:**
- `## Tasks`, `## Todo`, `## In Progress`

**Format validation — expected sections:**
- `IN PROGRESS`
- `COMPLETED`
- `BLOCKED`
- `NOT STARTED`

If the file exists but does **not** follow the standard format, report:
```
WARNING: work_tree found at [path] but format is non-standard.
  Missing sections: [list missing sections]
  Recommend: reformat to standard work_tree layout.
```

---

### 2I — Agent Memory (`memory.md`) — STANDARDIZED FORMAT

**Search for files named:**
- `memory.md`, `agent_memory.md`

**Also search `.claude/` directory for memory-style content.**

**Format validation — expected sections:**
- `Decisions Log`
- `Completed Work Log`
- `Open Questions`
- `Known Risks`

If the file exists but does **not** follow the standard format, report:
```
WARNING: memory found at [path] but format is non-standard.
  Missing sections: [list missing sections]
  Recommend: reformat to standard memory layout.
```

---

### 2J — Conflict Resolution Log

**Search for files named:**
- `conflict_resolution.md`, `escalation.md`, `blocked_log.md`

---

## PHASE 2.5 — DRIFT DETECTION (Refresh Runs Only)

**Skip this phase entirely on INIT runs.**

On REFRESH runs:

1. Read the existing file map from the current `enforcer_context.md`.
2. For every path listed as `EXISTS` in the old map, verify the file still exists at that path.
3. For every path listed as `MISSING`, check if it has since been created.
4. Count the total number of drift items (moved, disappeared, or newly appeared).
5. Report:

```
DRIFT DETECTION:
  Files verified in place:  [count]
  Files disappeared:        [count] — [list paths]
  Files newly appeared:     [count] — [list paths]
  Drift severity: [NONE (0) / MINOR (1-2) / SIGNIFICANT (3+)]
```

---

## PHASE 3 — Check CLAUDE.md

Read the project's `CLAUDE.md` (or `claude.md`) and check for the following sections or references:

| Check                          | Status           |
|-------------------------------|------------------|
| Enforcer system section        | PRESENT / MISSING |
| Memory/context references      | PRESENT / MISSING |
| Conventions reference          | PRESENT / MISSING |
| Agent team references          | PRESENT / MISSING |
| Conflict resolution rules      | PRESENT / MISSING |

Report the table. Do not modify CLAUDE.md — only report what is present or missing.

---

## PHASE 4 — Generate or Update `enforcer_context.md`

### Project Identity (Nexxus v2)

Use these values in the generated file:

```
Project Name: Nexxus v2
Purpose: AI-powered customer engagement platform with multi-channel communication
Owner: Duane
Repository: ~/Claude-store/nexxus-v2
```

### On INIT Run

Create `.agent_docs/enforcer_context.md` from scratch using the template below. Set:
- `Context Version: 1.0.0`
- All scanned paths from Phase 2 results
- Items not found set to `MISSING — needs creation`
- `bootstrap_complete: NO`

### On REFRESH Run

Update the existing `.agent_docs/enforcer_context.md`:
- Update **only** the paths/status fields that changed.
- Increment the version number:
  - Patch bump (X.Y.Z+1) for minor path updates or drift corrections.
  - Minor bump (X.Y+1.0) for new documents found or conflicts resolved.
  - Major bump (X+1.0.0) only if project identity or structure fundamentally changes.
- **Preserve** these sections from the existing file (do not overwrite):
  - Sprint History
  - Known Issues
  - Decisions Log
- Update the `Last Scanned` timestamp.
- Update drift detection results if applicable.

### Template Structure

The generated file should follow this structure:

```markdown
# Enforcer Context — Nexxus v2

> Auto-generated by /init-enforcer. Safe to re-run.
> Manual edits to the Sprint and History sections are preserved on refresh.

## Metadata
- **Context Version:** [version]
- **Last Scanned:** [date]
- **Run Type:** [INIT / REFRESH]
- **Bootstrap Complete:** [YES / NO]

## Project Identity
- **Project Name:** Nexxus v2
- **Purpose:** AI-powered customer engagement platform with multi-channel communication
- **Owner:** Duane
- **Repository:** ~/Claude-store/nexxus-v2

## Document Map

| Document Type         | Role File                  | Status  | Path                          | Format  |
|-----------------------|----------------------------|---------|-------------------------------|---------|
| Phase & Sprint Plan   | plan_sequence.md           | [status]| [path or MISSING]             | [OK/WARN]|
| Release Plan          | release_plan.md            | [status]| [path or MISSING]             | [OK/WARN]|
| Agent Team Config     | agent_team.md              | [status]| [path or MISSING]             | [OK/WARN]|
| Naming Conventions    | conventions.md             | [status]| [path or MISSING]             | [OK/WARN]|
| Acceptance Criteria   | acceptance_criteria.md     | [status]| [path or MISSING]             | [OK/WARN]|
| Safety Gates          | safety_gates.md            | [status]| [path or MISSING]             | [OK/WARN]|
| Quality Gates         | quality_gates.md           | [status]| [path or MISSING]             | [OK/WARN]|
| Work Tree             | work_tree.md               | [status]| [path or MISSING]             | [OK/WARN]|
| Agent Memory          | memory.md                  | [status]| [path or MISSING]             | [OK/WARN]|
| Conflict Resolution   | conflict_resolution.md     | [status]| [path or MISSING]             | [OK/WARN]|

## Conflicts

[List any conflicts found during scanning, or "None detected."]

## Drift Report

[Drift detection results from Phase 2.5, or "N/A — INIT run."]

## CLAUDE.md Coverage

[Table from Phase 3]

## Sprint (Current)

[On INIT: "Not yet configured. Update after first sprint planning."]
[On REFRESH: Preserve existing content.]

## Sprint History

[On INIT: "No history yet."]
[On REFRESH: Preserve existing content.]

## Known Issues

[On INIT: "None recorded."]
[On REFRESH: Preserve existing content.]

## Decisions Log

[On INIT: "No decisions recorded."]
[On REFRESH: Preserve existing content.]

## Bootstrap Checklist

- [ ] enforcer_context.md created (this file)
- [ ] CLAUDE.md has enforcer section
- [ ] All document types either found or intentionally deferred
- [ ] No unresolved conflicts
- [ ] Work tree in standard format
- [ ] Agent memory in standard format
- [ ] Safety gates configured
- [ ] Quality gates configured
- [ ] First test commit passed enforcer gate
```

---

## PHASE 5 — Final Report

After generating or updating `enforcer_context.md`, produce the following summary:

```
INIT ENFORCER — Setup Report
Run Type: [INIT / REFRESH]
Date: [today's date]

Found and Mapped:
  [For each document type: name — path — format status]
  [Example: Phase & Sprint Plan — .agent_docs/plan_sequence.md — OK]
  [Example: Release Plan — MISSING]

Format Warnings (non-standard structure):
  [List files found but not in standard format, with details]
  [Or: "None"]

Missing — Needs Creation:
  [List document types not found anywhere in the project]
  [Or: "All document types located."]

Conflicts Requiring Resolution:
  [List duplicates with full paths and sizes]
  [Include shadow copy warnings]
  [Or: "None"]

Drift Detected (Refresh Only):
  [List files that moved or disappeared since last scan]
  [Or: "N/A — INIT run" / "No drift detected"]

Context Version: [new version number]
Context Location: .agent_docs/enforcer_context.md

Next Steps (in order):
  1. Resolve any conflicts listed above
  2. Create any missing files (follow bootstrap order from Section 0)
  3. Fix any non-standard format warnings
  4. Update Sprint section in enforcer_context.md
  5. Run a test commit to confirm enforcer gate is working
```

Present the report to the user. Do not proceed with any next steps automatically — wait for user direction.
