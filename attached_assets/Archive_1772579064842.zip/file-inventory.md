# File Inventory — Pre-Flight Surgery Phase 1

**Created:** 2026-03-02
**Total input files:** 53 (48 in preflight-input/ + 5 in other_notes/)
**Plus:** 5 active workbench files at root

---

## Flags Requiring Owner Attention

1. **DUPLICATE:** `—Insights Layout copy.md` is identical to `—Insights Layout.md` — recommend deleting the copy
2. **UNUSABLE:** `replit_reference.textClipping` — macOS binary artifact, no readable content
3. **SECURITY:** `VIN_SOLUTIONS_INTEGRATION.md` (lines 69-71) — contains production credentials in plaintext. Do not commit or share.
4. **BLANK TEMPLATE:** `Chat-Checklist.pdf` — unfilled QA checklist template, not Nexxus-specific
5. **SUPERSEDED:** `INSIGHT_CARDS_SPECIFICATION.md` — predates MASTER_SRS, uses prohibited vendor naming
6. **SUPERSEDED:** `SYSTEM_REQUIREMENTS_SPECIFICATION_v3.0.md` — superseded by MASTER_SRS.md
7. **PRE-ENFORCER:** `CLAUDE.md` (in preflight-input) — this is a prior version, not the current one in nexxus-v2

---

## Owner-Authored Intent Files (HIGH priority — owner's direct voice)

| File | Date | Description |
|------|------|-------------|
| app_identity.md | 2026-02-16 | Owner's formalized platform identity, business model, partner structure, customer goals — stated as authoritative over all subsequent docs |
| — Acceptance Criteria.md | ~Feb 2026 | 13-item demo AC for customer sign-off + full Replit mockup AC spec covering navigation, shell, all pages, design standards |
| opinions_facts.md.md | ~Mar 2026 | Owner's structured separation of facts, suspicions, and 7 evidence-first rules for future governance |
| Standards.md | ~Mar 2026 | Owner's explicit definition of what each governance file type should contain (PRD, SRS, SPEC, PLAN, AC) with outline templates |
| Current_State.md.md | ~Mar 2026 | Analysis of 3 conflicting governance layers causing agent confusion |
| CLARIFICATION_ANSWERS.md | 2026-02-16 | Owner's recorded decisions on 9+ questions: VIN write-back, webhooks, data warehouse, widget channels, SMS, Context Router |
| ===DevDesign Notes===.md | pre-Feb 2026 | Owner's raw design notes covering UI redesign intent, agent architecture vision, feature requirements |

---

## Governing Documents (HIGH priority — define what to build)

| File | Date | Description |
|------|------|-------------|
| MASTER_SRS.md | 2026-02-18 | Master SRS v2.0 — platform identity, 4-tier RBAC, naming conventions, all 257 requirements. Supersedes all prior SRS versions. |
| CONSTITUTION.md | 2026-02-18 | Truth hierarchy (VIN > VAPI > Local DB > Derived), RBAC mapping, honest AI rules, non-destructive operations policy |
| IMPLEMENTATION_PLAN.md | 2026-02-18 | V2 governing implementation plan v2.0 — all remaining work organized by gaps, with file-level fix references and AC traceability |
| DO_NOT_TOUCH.md | 2026-02-22 | Backend freeze manifest — every server, DB, webhook, infra file that must not be modified during frontend rebuild |
| UNIFIED_HANDOFF_PROMPT.md | 2026-02-22 | Most recent governance-style doc — 6-tier document reading order, frozen backend rules, production protection constraints |
| CARRY_FORWARD_MANIFEST.md | 2026-02-22 | File-by-file verdicts (PRESERVE/REFERENCE/REPLACEABLE) for frontend integration plumbing |

---

## Architecture & Technical Reference (HIGH priority — how it's built)

| File | Date | Description |
|------|------|-------------|
| ARCHITECTURE_GUIDE.md | 2026-01-17 | Component architecture: 3-pane grid, sidebar states, RBAC roles, view configurations |
| ARCHITECTURE_VISUAL_MAP.md | 2026-01-20 | ASCII 7-layer architecture map: UI, Daria, Coordination, Memory Tiers, Integrations, Deployment |
| REVERSE_SRS_old.md | 2026-02-21 | Forensic as-built audit: 117K LOC, 237 endpoints, 53 tables, YELLOW health, zero unit tests, RLS mismatch |
| VIN_SOLUTIONS_INTEGRATION.md | 2026-01-28 | Sprint 2 VIN Solutions OAuth2 integration: file list, endpoints, job schedule, encryption approach |
| UI_INTERACTIVE_ELEMENTS_MAP.md | 2026-02-01 | Tabular map of every interactive UI element to its handler function and behavior |
| DATA_SOURCE_INVENTORY.md | 2026-02-18 | Complete API endpoint and field schema inventory for VIN, VAPI, Tavus, local DB with gap analysis |

---

## UI Layout Specifications (HIGH priority — above-the-line reference)

| File | Date | Description |
|------|------|-------------|
| —Insights Layout.md | ~Feb 2026 | 3-zone alert dashboard (Red/Yellow/Green), named sub-pages, data refresh philosophy, table wireframes |
| —Org admin Metrics - Main - org admin.md | ~Feb 2026 | Score formulas and tile design for 4 org-admin dashboard tiles |
| —Staff Metrics.md | ~Feb 2026 | Score formulas for 4 staff-role dashboard tiles |
| —Reports.md | ~Feb 2026 | Layout spec for Loss/Quality Analysis, Lead Source Quality reports |
| —Tiles - Available data..md | ~Feb 2026 | Data dictionary: ~80+ computable metrics from VIN Solutions data |
| —Hunches.md | ~Feb 2026 | Agent prompt for Hunches feature: automotive sales intelligence detective |

---

## Audit Reports (MEDIUM-HIGH — codebase snapshots, may be pre-rollback)

| File | Date | Description |
|------|------|-------------|
| database-audit.md | 2026-02-21 | All 33 migrations, 53 tables, schema evolution — definitive schema reference |
| server-audit.md | 2026-02-21 | 34 route files, ~185 endpoints, 36 services, middleware, webhooks, jobs, 7 integrations |
| client-audit.md | 2026-02-21 | 174 source files, 21 pages, 59 components, routing, state management |
| docs-audit.md | 2026-02-21 | Full doc hierarchy inventory with gap/conflict analysis |
| health-audit.md | 2026-02-21 | Project-wide metrics: 402 TS files, 117k LOC, 181 commits, 747 E2E tests, 0 unit tests |
| DATA_ACCURACY_REPORT.md | 2026-02-19 | 72% of post-V2 VAPI calls missing from DB; all records from manual bulk imports, not live webhooks |
| ACCEPTANCE_VERIFICATION_REPORT.md | 2026-02-19 | Claims 13/13 AC items PASS — partially refuted by Phase 9 Run 2 |

---

## SRS Chain (MEDIUM — reference, mostly superseded by MASTER_SRS)

| File | Date | Description |
|------|------|-------------|
| SYSTEM_REQUIREMENTS_SPECIFICATION_v3.0.md | 2026-01-30 | Base SRS — superseded by MASTER_SRS.md |
| Nexxus_SRS_Addendum_v3.1_MVP_Critical.md | 2026-02-03 | Addendum: architecture clarifications, VAPI/Tavus insights, post-MVP features |
| Nexxus_SRS_Addendum_v3.2_Widget_SMS_Notifications.md | 2026-02-03 | Addendum: widget architecture, TextMagic SMS, tracking pixel, hosted pages |

---

## Agent & Development Process (MEDIUM — process docs)

| File | Date | Description |
|------|------|-------------|
| Agent Instructions.md | ~Feb 2026 | Multi-agent protocol: team topology, phase gates, interface-first implementation |
| DEVELOPMENT_TEAM_BRIEFING.md | 2026-02-22 | Hard-won lessons: VIN API limitations, header bugs, RLS mismatch, SET LOCAL risk |
| DESIGNER_UPDATE_SPEC.md | 2026-02-22 | UI elements needing addition to Replit reference design |
| ARCHITECTURE_GUIDE_RBAC_ADDITION.md | ~Jan 2026 | Partner entity RBAC addendum |

---

## Supplemental / Context (MEDIUM-LOW)

| File | Date | Description |
|------|------|-------------|
| CUSTOMER_ONBOARDING_KICKOFF.md | 2026-02-17 | Per-customer readiness checklist (Serra, Columbia) |
| INIT_PROJECT_ANSWERS.txt | ~Feb 2026 | Pre-filled /init-project interview answers |
| DESIGN_FLAGS.md | no date | Empty agent-to-owner decision flag template |
| UI_DEVELOPER_HANDOFF.md | 2026-01-21 | Original frontend handoff doc — likely superseded by V2.1 rebuild |
| THEME_CONTRACT.md | 2026-01-21 | Design token system for theming |
| NEXXUS_V2_BOOTSTRAP_PROMPT.md | no date | Session bootstrap prompt — already executed, superseded |
| Forensics.md.md | ~Mar 2026 | Evidence audit framework: verified vs derived vs unverified claims |
| known_issues.md.md | ~Mar 2026 | Phase 9 Run 2 verification: 3 confirmed P0s, root-cause analysis |

---

## Low Relevance / Remove

| File | Date | Description |
|------|------|-------------|
| —Insights Layout copy.md | — | DUPLICATE of —Insights Layout.md |
| replit_reference.textClipping | — | macOS binary artifact, no content |
| Chat-Checklist.pdf | — | Blank QA template, not Nexxus-specific |
| INSIGHT_CARDS_SPECIFICATION.md | 2026-01-21 | Superseded by MASTER_SRS; uses prohibited vendor naming |

---

## Active Workbench Files (root — current session outputs)

| File | Description |
|------|-------------|
| preflight-surgery-plan.md | The surgery plan (53 steps, 8 phases) |
| session-knowledge.md | Session findings not previously on disk |
| verified-findings.md | 11 code-verified findings from fact-finding |
| failure-analysis.md | 31 items across 8 failure categories |
| agent-remediation.md | 6 items from prior unauthorized session (input) |
