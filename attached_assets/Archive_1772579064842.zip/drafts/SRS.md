# Nexxus V2 -- System Requirements Specification

**Version:** 1.0 DRAFT
**Date:** 2026-03-03
**Audience:** Owner + technical staff
**Companion Files:** PRD.md (business context), SPEC.md (architecture reference), ACCEPTANCE_CRITERIA.md (test criteria), PLAN.md (current marching orders), CLAUDE.md (agent rules)

---

## 1. System Overview

### 1.1 Architecture Pattern

Nexxus V2 is a single-server application with a React single-page application (SPA) frontend and an Express.js backend, backed by a PostgreSQL database hosted on Neon. The server runs as a single Node.js process managed by PM2 on port 5020, with Caddy as the reverse proxy.

The frontend is built with Vite, React 18, and TypeScript. It uses Wouter for client-side routing, TanStack Query for server state management, and shadcn/ui (47 primitives) with Tailwind CSS for the interface layer. The backend is Express.js 5 with TypeScript, compiled via esbuild, using Drizzle ORM for database access.

External services provide the AI and communication capabilities: Anthropic Claude for conversational AI (DealerBrain), VAPI for voice AI, Tavus for video AI, TextMagic for SMS, and Resend for email. VIN Solutions provides CRM data (lead management, contacts, inventory). All external service credentials are stored per-organization in the database -- not in environment variables -- enabling multi-tenant isolation.

### 1.2 Request Flow

When a user interacts with Nexxus, the request follows this path:

1. The browser sends an HTTP request to the Caddy reverse proxy.
2. Caddy forwards the request to the Express server on port 5020.
3. The Express middleware chain processes the request: JSON body parsing, CORS headers, Helmet security headers, then authentication.
4. For authenticated routes, the JWT middleware extracts the access token from the `Authorization: Bearer` header, validates it, and populates the request with `user_id`, `organization_id`, `role_id`, and `permissions`.
5. The route handler delegates to the appropriate service layer.
6. The service layer uses `SecureQueryBuilder` for all database queries. SecureQueryBuilder sets `app.current_organization_id` via `SET LOCAL` before every query, enabling PostgreSQL Row-Level Security (RLS) policies to enforce data isolation.
7. If the request involves an external service (VIN Solutions, VAPI, TextMagic, Tavus), the service retrieves per-org credentials from the database and makes the outbound API call.
8. The response returns through the same chain to the browser.

For streaming responses (DealerBrain chat), the server opens a Server-Sent Events (SSE) connection instead of returning a single HTTP response. Tokens stream back one at a time until the response completes.

### 1.3 Authentication Flow

Nexxus uses JWT-based authentication with no server-side session store.

**Login:** When a user submits credentials at `/login`, the server validates the password (hashed with bcrypt), then issues two tokens:
- An **access token** (24-hour expiry) containing `user_id`, `organization_id`, `role_id`, and `permissions`.
- A **refresh token** (7-day expiry) for renewing the access token.

Both tokens are stored in the browser's localStorage under the keys `nexxus_access_token` and `nexxus_refresh_token`.

**Token Refresh:** The client checks token expiry every 60 seconds. When the access token is within 5 minutes of expiring, the client calls `POST /api/auth/refresh` with the refresh token. The server issues a fresh pair of tokens. If the refresh token itself has expired, the client logs out and redirects to `/login`.

**Organization Switching:** Partner Admins and Super Admins can access multiple organizations. When they switch organizations, the client calls `POST /api/auth/switch-org` with the target organization ID. The server issues new tokens scoped to that organization. The client clears all cached data (via `queryClient.invalidateQueries()`), navigates to `/`, and displays a 3-second confirmation overlay.

**Auth Endpoints:**
- `POST /api/auth/login` -- returns access + refresh tokens
- `POST /api/auth/refresh` -- exchanges refresh token for new access token
- `GET /api/auth/me` -- returns the current authenticated user
- `POST /api/auth/switch-org` -- returns new tokens scoped to target org
- `POST /api/auth/logout` -- invalidates the session

**Public Routes (no authentication required):** `/login`, `/forgot-password`, `/reset-password`, `/w/:slug` (widget hosted pages).

**Protected Routes:** All other routes wrap in `<ProtectedRoute>`, which shows a loading spinner during authentication checks and redirects to `/login` if the user is not authenticated. There is no route-level role gating -- role restrictions are applied at the component and tab level within each page.

---

## 2. Capability Behaviors

### 2.1 Automa Chat

Automa is the always-available AI assistant built into every Nexxus account. It is the master agent -- listed at the top of the agents list, present on the main dashboard, and aware of the organization's goals, page context, and CRM data. Automa is powered by Claude (currently `claude-sonnet-4-20250514`) via the DealerBrain service.

**Message Flow:**

1. When the user sends a message in the chat interface, the client sends `POST /api/conversations/{id}/stream` with `{ content: string }` and a Bearer token header.
2. The server opens an SSE connection and sends events as the response generates.
3. DealerBrainService sends the conversation to the Claude API with the system prompt (configurable per-org via AI Configuration settings), goal awareness context, and the 24-tool inventory.
4. If Claude decides to call a tool, the server executes the tool call. When the tool involves VIN Solutions data, the Context Router's SourceSelector checks VIN API first (primary source) and falls back to the local database if VIN is unavailable. The CacheManager applies TTL-based caching: 5 minutes for VIN data, 1 hour for VAPI/Tavus data.
5. The response streams token-by-token back to the client.
6. The conversation and its messages persist in the database for history.

**SSE Event Types:**

| Event | Payload | Purpose |
|-------|---------|---------|
| `thinking` | `{ type, message }` | Indicates the AI is processing |
| `tool_start` | `{ type, toolName, toolDescription }` | A tool call has begun |
| `tool_end` | `{ type, toolName, success, summary, chartData? }` | A tool call has completed |
| `token` | `{ type, content }` | A single token of the response |
| `done` | `{ type, tokensUsed: { input, output }, toolCalls? }` | Response complete |
| `error` | `{ type, message }` | An error occurred |

**Tool Inventory (24 Tools):**

The following tools are available to DealerBrain during any conversation. Tools are assigned at the system level (via widget_configs), not per-agent.

| # | Tool | What It Does |
|---|------|-------------|
| 1 | `searchLeads` | Searches leads in VIN Solutions or local database by criteria (name, phone, email, status) |
| 2 | `getLeadDetails` | Retrieves full detail for a specific lead including contact info, status history, and notes |
| 3 | `createLead` | Creates a new lead record and queues it for VIN Solutions sync |
| 4 | `updateLead` | Updates lead fields (status, contact info, notes) |
| 5 | `searchInventory` | Searches vehicle inventory by make, model, year, price range, stock number |
| 6 | `getInventoryDetails` | Retrieves full vehicle detail including pricing, features, and availability |
| 7 | `createAppointment` | Creates a new appointment on the calendar with customer, date/time, type, and notes |
| 8 | `updateAppointment` | Modifies an existing appointment (reschedule, change status, add notes) |
| 9 | `getAppointments` | Lists appointments for a date range, optionally filtered by status or assignee |
| 10 | `sendSMS` | Sends an outbound SMS via TextMagic using per-org credentials |
| 11 | `sendEmail` | Sends an outbound email via Resend |
| 12 | `makeCall` | Initiates an outbound VAPI voice call to a phone number |
| 13 | `getCallHistory` | Retrieves call records for a lead or date range |
| 14 | `getConversationHistory` | Retrieves past chat/SMS/email conversation threads with a contact |
| 15 | `createTask` | Creates a task assigned to a user or agent |
| 16 | `updateTask` | Updates task status, assignee, or details |
| 17 | `getTasks` | Lists tasks filtered by status, assignee, or due date |
| 18 | `searchKnowledgeBase` | Searches the organization's uploaded knowledge base documents |
| 19 | `getMetrics` | Retrieves specific metrics from the DealerPulse data (e.g., close rate, response time) |
| 20 | `getInsights` | Retrieves AI-generated insights and hunches for the organization |
| 21 | `getDealerInfo` | Retrieves dealership profile information and configuration |
| 22 | `getAgentInfo` | Retrieves information about available agents and their capabilities |
| 23 | `calculateFinancing` | Runs financing calculations (payment estimates, rate comparisons) |
| 24 | `generateChart` | Produces chart data that the frontend renders as a visual in the chat |

**Skill Overlay System:**

Agents in Nexxus V2 use a skills model instead of hardcoded personas. There are 74 pre-built skills organized into 4 categories:

- **Sales** (20 skills) -- objection handling, needs assessment, follow-up cadences
- **Finance** (20 skills) -- payment calculation, credit guidance, F&I product presentation
- **Operations** (20 skills) -- scheduling, inventory management, service coordination
- **General** (14 skills) -- greeting, FAQ, escalation, data lookup

Skills are managed in AI Configuration > Skills tab (Super Admin only). When a skill is attached to an agent, it modifies the agent's behavior by injecting additional context, instructions, and pre-prompting into the Claude system prompt. Skills are system-level constructs -- they are not stored as a per-agent database field but applied as overlays at conversation time.

**Context Window Management:**

DealerBrainService injects the following into the Claude context before each request:
- Organization goals (if configured)
- Relevant page context (what the user is currently viewing)
- Conversation history (prior messages in the thread)
- Skill instructions (if skills are attached to the active agent)

The DealerBrainProcessor middleware currently operates in Stage 1 (monitoring only) -- it observes tool calls and token usage but does not enforce limits.

### 2.2 Insights & Metrics

The Insights page provides analytics, reports, and AI-generated intelligence about dealership performance. It has four main sections: Dashboard, Reports, Metric Library, and Hunches.

#### DealerPulse -- Metrics Collection

DealerPulse is a background job that runs every 4 hours. When it runs, the system:

1. Queries data from four sources:
   - **VIN Solutions** -- lead counts, status distributions, activity data (polled every 60 minutes with a 48-hour lookback window)
   - **Internal database** -- call logs, video sessions, task completions, credit usage, agent activity
   - **External services** -- VAPI call data, Tavus session data (received via webhooks)
   - **User uploads** -- Excel/CSV data uploaded for backfill (excluded from lead-related metrics via `source = 'excel_upload'` filter across 32+ queries)

2. Computes each metric according to its formula (see Metric Library below).

3. Stores snapshots in the database for historical trending.

**Data Truth Hierarchy:** When the same data exists in multiple sources, the system trusts them in this order: VIN Solutions API (highest) > VAPI/Tavus APIs > Local Database > Derived Metrics (lowest).

#### Hunch Generation Pipeline

The Hunch Generation job runs every 6 hours. When it fires, the system:

1. Collects current metrics, recent trends, and notable patterns from the DealerPulse data.
2. Sends this data to a Claude "Detective" agent with specific hunch-generation instructions.
3. Claude analyzes the data and produces hunches in 7 categories: `opportunity`, `risk`, `trend`, `anomaly`, `recommendation`, `prediction`, `insight`.
4. Each hunch includes a confidence score, category tag, and supporting evidence.
5. Hunches are stored in the database and appear in the Hunches tab on the Insights page.

When a user reviews a hunch:
- **Accept** -- the hunch creates an action item (task, follow-up, goal adjustment).
- **Dismiss** -- the hunch is archived with the user's feedback, creating a reinforcement learning loop for future hunch quality.

Hunch generation settings (enable/disable, daily digest, confidence thresholds) are controlled by Super Admins in AI Configuration > Hunches tab.

#### Report Data Aggregation

Reports come in 3 types, each with 3 sub-reports:
- **Loss Reports** -- analyze where and why leads are lost
- **Channel Reports** -- compare performance across communication channels (voice, SMS, email, chat, video)
- **Trend Reports** -- show performance over time with period comparisons

When the user opens a report, the system queries the relevant metrics for the selected date range, aggregates them according to the report type, and renders the results as charts (via Recharts) and summary tables.

#### Metric Library (34 Metrics)

The Metric Library contains 34 defined metrics that the system tracks. Each metric has a name, formula, data source, and display format. The library is searchable and browsable from the Insights page. Metrics feed into the Dashboard gauges, Reports, and Hunch generation.

Metrics span these areas: lead conversion rates, response times, channel effectiveness, appointment rates, call volume and duration, SMS engagement, credit consumption, agent utilization, and dealership health scores.

### 2.3 Agent Management

Agents are AI-powered workers that handle communication and tasks on behalf of dealership staff. The Agents page lets users create, edit, delete, and chat with agents.

**Agent Types:**
- **Voice** -- powered by VAPI, handles phone calls
- **Video** -- powered by Tavus, handles video conversations
- **Chat** -- powered by DealerBrain (Claude), handles text-based interactions
- **Email** -- powered by Resend, handles email communication
- **Task** -- internal automation agents

**Agent CRUD:**

When a user creates an agent, the system stores:
- Name and description
- Agent type (voice, video, chat, email, task)
- Persona configuration: system instructions, temperature, model selection
- Status: `active`, `inactive`, or `draft`
- Skills attachments (selected from the 74-skill catalog)
- Trigger rules (configured per-agent -- see Section 2.7)

**Agent-to-Widget Association:**

Agents can be associated with widgets for external deployment. When a widget is configured, it references one or more agents that handle conversations through that widget. The routing is configured at the widget level.

**Default Agents:**

Two default agents ship with every account -- one voice (VAPI) and one video (Tavus). These are Communications Agents: configured by Super Admin, they handle proactive lead follow-up (outbound call + text when new leads arrive) and reactive after-hours coverage (SMS and phone when staff is unavailable). Users cannot modify Communications Agents except for their triggers and an instruction supplement.

**Production Inventory:** 12 active agents -- 5 voice (each with a VAPI assistant ID linked), 2 chat, 4 task, 0 video.

**Favorites:** Users can mark agents as favorites. Favorited agents appear prominently in the agent list for quick access.

**Agent Chat:** Each agent has its own chat interface accessible from the Agents page. When the user sends a message to an agent, the system routes it through DealerBrainService with that agent's persona and skills applied to the context.

**Emergency Kill Switch:** Super Admins have access to an emergency kill switch that turns off ALL agent activity for ALL users in ALL organizations. Activating it requires a confirmation dialog.

### 2.4 Hub -- Calendar

The Calendar is one of three tabs in Hub (alongside Leads and Inbox). It shows appointments across four view modes: day, week, month, and year.

**Appointment Lifecycle:**

1. **Creation:** When a user creates an appointment (or a voice agent captures one during a call), the system stores it in the `appointments` table with: customer name, date/time, appointment type, assigned staff, notes, and status.

2. **Display:** The appointment appears on the Calendar in the appropriate view mode. Users can switch between day, week, month, and year views.

3. **Updates:** When a user modifies an appointment (reschedules, adds notes, changes status), the system updates the record in the database.

4. **Reminders:** The Appointment Reminder background job runs every 5 minutes. When it detects an upcoming appointment within the reminder window, it generates a notification.

5. **VIN Solutions Sync:** When an appointment involves a lead, the system should create or update the lead record in VIN Solutions with an appointment note. This uses the 2-step VIN API process: create contact first, then create lead with href references.

6. **Google Calendar Sync:** If the user has connected Google Calendar via OAuth, appointments sync bidirectionally. The `useGoogleCalendar` hook manages connection, disconnection, sync, and auto-sync toggling.

**Appointment Confirmation Tokens:** When an appointment generates an email confirmation, the system includes a special 48-hour JWT token (with `nexxus-appointment` audience) in the email link. When the customer clicks the link, the token validates without requiring login.

**Known Gap:** When appointment status changes (e.g., confirmed, cancelled, rescheduled), `updateAppointment()` currently fires zero events. No SMS notification and no in-app notification is sent on status change. This is a confirmed P0 gap requiring a fix.

### 2.5 Hub -- Leads

The Leads tab shows the active lead pipeline. Leads arrive primarily through VIN Solutions polling and secondarily through VAPI/Tavus/widget interactions.

**VIN Solutions Inbound Polling Pipeline:**

1. A scheduled job runs every 60 minutes.
2. It authenticates with VIN Solutions using OAuth 2.0 Client Credentials (per-org credentials stored encrypted in the database).
3. It queries `GET /leads` with a `lastModified` filter using a 48-hour lookback window.
4. New leads (identified by `vin_customer_id`) are stored in the internal database with their VIN external IDs.
5. The Context Router's SourceSelector tags these records with a "VIN" source label.
6. Deduplication is by `vin_customer_id` -- any lead already present with that ID is updated rather than duplicated.

**Coverage:** By design, Nexxus stores only the active working set of leads. In production: 293,859 total leads in VIN Solutions vs 775 in the local database (0.26% coverage). This is intentional -- Nexxus is a companion to VIN Solutions, not a replacement.

**Lead Import from Calls/Widgets:**

When a VAPI call ends or a widget captures customer information:
1. Customer data is extracted from the call transcript or widget form.
2. A lead record is created internally.
3. The lead is inserted into the `sync_queue` table with `action: 'create_lead'`.
4. The Sync Queue Worker (1-minute outbound interval) picks it up and executes the 2-step VIN API process: create contact, then create lead with href references.

**Known Bug:** The VIN sync currently fails 100% of the time (12/12 production sync jobs failed). Root cause: the `leadSource` field is sent as a string ("Phone") but the VIN API requires a URL reference (`/leadSources/id/36`). The fix requires querying `GET /leadSources?dealerId=X` first to get valid hrefs.

**Lead Status Transitions (Internal):**

`new` -> `contacted` -> `qualified` -> `appointment_set` -> `closed`

These are Nexxus pipeline stages. VIN Solutions has its own status taxonomy (5 status types: ACTIVE, SOLD, LOST with 38 sub-statuses, BAD with sub-statuses, Unknown/Other) and 3 lead group categories (NEW, WAITING, CONTACTED). Both systems track status independently.

**Lead Detail View:** When the user opens a lead, the detail panel shows contact information, status, source, communication history, appointment history, and action buttons for call, text, and email.

**Lead Deduplication:** Matching is by phone number and email address. When a new lead arrives with a phone or email that matches an existing lead, the system links them rather than creating a duplicate.

### 2.6 Hub -- Inbox

The Inbox tab provides a unified view of all customer communications across channels: email, SMS, and voicemail. Staff see all inbound and outbound messages in a single threaded interface.

**Cross-Channel Routing:**

When a message arrives from any channel, the system routes it based on the channel type:

- **Inbound SMS** (TextMagic webhook): The phone number is matched to an organization via per-org database credentials. The conversation state machine determines handling (see below).
- **Inbound Email** (IMAP sync every 5 minutes): New emails are pulled and matched to existing conversation threads or create new ones.
- **Voicemail** (VAPI): When a call is not answered or goes to voicemail, the recording and transcript appear in the Inbox.
- **Widget Chat**: When a customer starts a conversation through a widget and it requires human attention, the conversation surfaces in the Inbox.

**SMS Conversation State Machine:**

SMS conversations have three states:

| State | Meaning | What Happens |
|-------|---------|-------------|
| `AI_ACTIVE` | AI agent is handling the conversation | Inbound SMS messages receive automated AI responses (via Claude Haiku) |
| `HUMAN_ACTIVE` | A staff member has claimed the conversation | Messages appear in the Inbox for manual response; AI does not auto-reply |
| `DORMANT` | The conversation has been inactive for a configured duration | No active handler |

**Transitions:**
- When a new SMS arrives on a dormant conversation, the state changes to `AI_ACTIVE` and the AI begins responding.
- When a staff member claims a conversation in the Inbox, the state changes to `HUMAN_ACTIVE`.
- When a staff member releases the conversation or a timeout occurs, the state returns to `AI_ACTIVE`.
- When no activity occurs for the configured timeout period, the state becomes `DORMANT`.
- When a new inbound message arrives on a dormant conversation, the cycle restarts at `AI_ACTIVE`.

**Implementation Note:** The schema for this state machine is defined in migration 032 (`sms_conversation_state` table) and the state constants are referenced in code, but the runtime enforcement of all transitions is not fully implemented.

**Inbox Conversation States:** Conversations in the Inbox are managed with statuses: open, assigned, resolved, archived. Status transitions are handled via the `useUpdateConversationStatus` hook.

**After-Hours Routing:**

When a message arrives outside business hours (per-org timezone configuration):
- SMS: The AI agent auto-responds (`AI_ACTIVE` state) since no staff is available.
- Phone: VAPI voice agent handles the call.
- The system marks these as after-hours interactions for the trigger system to evaluate.

### 2.7 Trigger System

The trigger system spans multiple areas of the application. Triggers are configured per-agent and evaluate conditions against incoming events to execute automated actions.

#### Event Types

The trigger system recognizes the following event types. (Note: Multiple source documents use different naming conventions. The names below are the reconciled canonical names. Where naming conflicts exist between documents, both names are noted.)

| # | Canonical Event Type | Definition | Status |
|---|---------------------|------------|--------|
| 1 | `new_lead` | A new lead arrives in the system (from VIN polling, VAPI call, widget, or manual entry) | Active in codebase |
| 2 | `hot_lead` | A lead's score exceeds the configured threshold | Defined but no call site exists in codebase |
| 3 | `idle_lead` | A lead has had no contact for a configured duration | Referenced in spec documents |
| 4 | `missed_call` | An inbound phone call was not answered by staff | Active in codebase |
| 5 | `appointment_created` | A new appointment has been created | Active in codebase (also referenced as `appointment_scheduled`) |
| 6 | `appointment_reminder` | An appointment is approaching its scheduled time | Referenced in spec documents |
| 7 | `stale_lead` | A lead has aged beyond a configured threshold without progress | Referenced in spec documents |

**Additional event types found in some documents but not confirmed in the primary codebase:** `lead_status_change`, `widget_interaction`, `sms_received` / `inbound_message`. Owner resolution is needed to confirm the canonical list.

#### Condition Evaluation

When an event fires, the trigger system evaluates conditions before executing any action:

- **Business hours check:** Is the current time within the organization's configured business hours (per-org timezone)?
- **Rate limiting:** Has this trigger already fired within its configured cooldown period (per trigger rule)?
- **Lead age:** For time-based triggers, has the lead been idle/stale for the configured duration?
- **Lead score:** For score-based triggers, does the lead score exceed the threshold?
- **Lead status:** Is the lead in the correct pipeline stage for this trigger?
- **Prior-contact detection:** Has this lead already been contacted through this channel?

#### Action Types

When conditions are met, the trigger executes one of the following action types:

| # | Canonical Action Type | What It Does |
|---|----------------------|-------------|
| 1 | `outbound_call` | Initiates an outbound VAPI voice call to the lead's phone number |
| 2 | `outbound_sms` | Sends an outbound SMS via TextMagic using per-org credentials (also referenced as `send_sms`) |
| 3 | `email_notification` | Sends an email notification via Resend (also referenced as `send_notification` / `send_email`) |
| 4 | `create_task` | Creates a task record assigned to a user or agent |
| 5 | `update_lead_status` | Changes the lead's pipeline status (also referenced as `assign_lead` / `webhook`) |

**Owner resolution needed:** Confirm canonical action type names, particularly for items 2, 3, and 5 where documents disagree.

#### Execution Pipeline

The full trigger execution pipeline works as follows:

1. An event occurs (new lead imported, call missed, appointment created, etc.).
2. `TriggerService` queries all active trigger rules for the organization.
3. For each matching rule, the system evaluates conditions: business hours, rate limits, lead criteria, prior contact.
4. If all conditions pass, the system executes the configured action.
5. The execution is logged with: `trigger_id`, action taken, result (success/failure), timestamp.
6. A re-evaluation job runs every 5 minutes for age-based conditions (e.g., idle leads that have now exceeded the threshold).

#### Trigger Deduplication

Two deduplication mechanisms prevent the same action from firing multiple times:

1. **`notification_sent` column:** Uses an atomic `UPDATE ... WHERE notification_sent = false RETURNING *` pattern. Only the first execution succeeds; subsequent attempts find `notification_sent = true` and skip.
2. **`credit_recorded` column:** Uses the same atomic pattern for credit-related actions, preventing double-counting of usage credits.

#### Business Hours Handling

Each organization configures its business hours with timezone. When a trigger evaluates:
- If the event occurs during business hours, the trigger proceeds normally.
- If the event occurs outside business hours, the trigger may be deferred (for staff-required actions) or executed immediately (for AI-handled actions like auto-response SMS).

#### Trigger Configuration UI

Triggers are configured in the Agent Config Pane (per-agent, not global):
- The trigger editor supports two types: **Event type** (fires on a specific event) and **Schedule type** (fires on a cron expression or simple interval).
- Each trigger has an on/off toggle.

#### Production Status

- 8 active trigger rules exist in the production database.
- 0 of 84 trigger executions completed successfully in production.
- 45 failed and 39 were skipped (all from E2E tests, not real production traffic).
- Likely causes: missing VAPI `phoneNumberId` per org, business hours restrictions, or rate limit configuration.

### 2.8 Widget System

Widgets allow dealerships to deploy AI-powered engagement on their external websites. A widget is a portal to an agent -- not a standalone feature.

#### Three Deployment Modes

| Mode | How It Renders | Use Case |
|------|---------------|----------|
| **Hosted Page** | A standalone page served at `/w/:slug` on the Nexxus domain | Shareable link for direct customer access |
| **Embedded** | An iframe or script tag injected into the dealership's website | Integrated into existing web pages |
| **Unified (Corner Widget)** | A floating button in the bottom corner of the dealership's site that expands into a chat panel | Always-available engagement without page takeover |

**Widget Bundle:** The widget is a Preact-based bundle (50.13 KB minified) served at `/widget/nexxus-widget.js?code=WIDGET_CODE`. The `WIDGET_CODE` identifies the specific widget configuration.

#### Domain Whitelisting

When a widget loads on an external website, the system checks whether the hosting domain is in the widget's whitelist. If the domain is not whitelisted, the widget does not render. This prevents unauthorized deployment of the widget on sites the dealership does not control.

**Widget endpoint rate limiting:** 100 requests per hour per IP address.

#### Agent Routing

Each widget configuration specifies which agent(s) handle conversations. When a customer interacts with the widget:

1. The widget presents channel options: text chat, voice inbound, voice outbound, video agent, web audio, send a text.
2. For text chat: a conversation is created in the `inbox_conversations` table and assigned to AI (Claude Haiku handles initial responses).
3. For voice: the widget connects to a VAPI assistant.
4. For video: the widget connects to a Tavus persona.

#### Conversation Lifecycle in Widget Context

1. Customer opens the widget and starts a conversation.
2. AI handles the conversation initially.
3. If the AI cannot resolve the request, or if a staff member manually claims it, the conversation transitions from AI to human handling.
4. The conversation is visible in the staff's Unified Inbox (Hub > Inbox), where staff continues from where the AI left off. There is full continuity between the external widget surface and the internal Inbox.

**Widget Branding:** Widgets are branded per-organization, not with platform branding.

**Production Status:** 19 active widget configurations across organizations.

### 2.9 Drive

Drive provides document management within the organization.

**File CRUD Operations:**

- **Upload:** Users upload files which are stored and associated with the organization.
- **Download:** Files can be downloaded by users with appropriate permissions.
- **Rename/Move:** Files and folders can be renamed and moved within the hierarchy.
- **Delete:** Files can be deleted (subject to permissions).

**Permission Model:**

Each file or folder has a permission level:
- **Read** -- can view and download
- **Comment** -- can view and add comments
- **Edit** -- can modify, rename, move, and delete

Permissions are enforced per-user and per-organization.

**Folder Structure:** Drive supports up to 10 levels of folder nesting.

**Templates:** Drive includes a templates section where reusable document templates are stored and managed. Templates can be applied when creating new documents.

**View Modes:** Files can be viewed in grid mode (visual thumbnails) or list mode (detailed table).

### 2.10 Settings & Configuration

The Settings page provides system configuration across 9 tiles. Which tiles are visible depends on the user's role.

#### RBAC Tile Visibility

| Tile | Super Admin | Partner Admin | Org Admin | Staff |
|------|:-----------:|:------------:|:---------:|:-----:|
| Users | Yes | Yes | Yes | No |
| Organization | Yes | Yes | Yes | No |
| Tools & Integrations | Yes | No | No | No |
| Knowledge Base | Yes | No | Yes | No |
| AI Configuration | Yes | No | No | No |
| Security & Privacy | Yes | No | No | No |
| Notifications | Yes | Yes | Yes | Yes |
| Data Management | Yes | No | No | No |
| Appearance | Yes | Yes | Yes | Yes |

#### Integration Credential Flow

When an administrator configures an external service integration:

1. The admin navigates to Settings > Tools & Integrations.
2. Each integration is displayed as a tool card with: name, description, status (enabled/disabled), and Economy settings (pricing per unit).
3. The admin enters credentials (API keys, OAuth details).
4. Credentials are stored **per-organization in the database** (encrypted with AES-256-GCM, PBKDF2 key derivation with 100,000 iterations). They are NOT stored in .env files.
5. The admin enables or disables the integration.
6. Super Admins can see technical names on tool cards and access the API Keys tab, Webhooks tab, and Economy settings.

**Tool Provisioning Hierarchy:** Super Admin provisions tools -> Partner Admin manages orgs -> Org Admin uses tools within their org. Tools flow top-down.

#### Knowledge Base Management

Org Admins and Super Admins can upload documents to the organization's knowledge base:
1. Documents are uploaded via the Knowledge Base settings tile.
2. Uploaded documents become searchable by Automa and other chat agents via the `searchKnowledgeBase` tool.
3. This enables agents to answer organization-specific questions (inventory details, policies, promotions) using the dealership's own content.

#### Widget Configuration

Widget setup flows through Settings:
1. Create a widget configuration (name, mode, branding).
2. Assign agent(s) to handle widget conversations.
3. Configure domain whitelisting.
4. Generate embed code for external deployment.
5. The system produces a hosted page URL (`/w/:slug`) for the hosted mode.

---

## 3. Webhook Specifications

### 3.1 VAPI Webhook Handling

**Endpoint:** `POST /api/webhooks/vapi`

When VAPI sends a webhook event, the system processes it as follows:

1. **Organization Resolution:**
   - First, check `metadata.organizationId` in the webhook payload.
   - If not present, look up the `assistantId` in the `voice_agents` database table to find the registered organization.
   - If no organization can be resolved, the event is rejected.

2. **Event Processing:**

| Event | Handler Behavior |
|-------|-----------------|
| `call.started` | Should INSERT an initial call record into `vapi_call_logs`. **BROKEN:** This event is never received for production calls, causing downstream failures. |
| `call.ended` | UPDATE the call record with duration and end status. |
| `end-of-call-report` | UPDATE the call record with transcript, summary, and recording URL. Extract lead data from the call. Queue a VIN Solutions sync entry. This is the primary data event. |
| `transcript` | Append transcript segments to the call record. |
| `status-update` | Update the call status field. |

3. **Post-Processing (on `end-of-call-report`):**
   - Credit deduction: `duration_minutes * $0.15` (VAPI cost); customer charged at `duration_minutes * $0.25`.
   - Lead extraction from call data (customer name, phone, intent).
   - Sync queue entry created for VIN Solutions lead insertion.
   - Activity event logged.

4. **Idempotency:** The `notification_sent` and `credit_recorded` boolean columns use atomic `UPDATE ... WHERE ... = false RETURNING *` to prevent double-processing.

5. **Security:** Organization resolution via metadata or assistant lookup. There is no HMAC or cryptographic signature verification on VAPI webhooks.

**Critical Production Issue:** Real-time call ingestion is broken. The `call.started` event never arrives for production calls, so `handleEndOfCallReport` attempts an UPDATE on a row that does not exist. Result: 832 VAPI API calls vs 159 local database records. All 137 post-deployment records were from manual bulk import, not live webhook processing.

### 3.2 TextMagic Webhook Handling

**Inbound SMS Endpoint:** `POST /api/webhooks/textmagic`

When TextMagic sends an inbound SMS notification:

1. The incoming phone number is matched to an organization via per-org database credentials (NOT the `.env` `TEXTMAGIC_API_KEY`).
2. The conversation state machine is checked: `AI_ACTIVE`, `HUMAN_ACTIVE`, or `DORMANT`.
3. If `AI_ACTIVE`: an automated response is generated by the communications agent (Claude Haiku) and sent back via TextMagic.
4. If `HUMAN_ACTIVE`: the message is routed to the Unified Inbox for staff to respond manually.
5. If `DORMANT`: the conversation transitions to `AI_ACTIVE` and an automated response is generated.
6. The SMS is stored in the conversation thread.

**Compliance:** STOP keyword handling is implemented for SMS compliance.

**Phone Number Routing Note:** Phone number `18338096836` is shared across 3 organizations. The system uses first-database-match routing, meaning the first org match in the DB query wins.

**Outbound SMS:**
1. A trigger action or manual user action initiates the SMS.
2. Per-org TextMagic credentials are retrieved from the database.
3. The SMS is sent via TextMagic API (E.164 phone format required -- `+` prefix).
4. Credit usage tracked: $0.02 per message (cost), $0.05 per message (customer charge), 60% margin.

### 3.3 Tavus Webhook Handling

**Endpoint:** `POST /api/webhooks/tavus`
**Security:** HMAC-SHA256 signature verification with 5-minute timestamp tolerance.

When Tavus sends a webhook event:

| Event | Handler Behavior |
|-------|-----------------|
| `conversation.started` | Create a video session record in the database |
| `conversation.ended` | Update the record with duration and end status |
| `replica.ready` | Update the persona status (replica is available for use) |
| `video.ready` | Update the record with the video URL |

**Cost Tracking:**
- Tavus cost: $0.20 per minute
- Customer charge: $0.32 per minute
- Nexxus margin: 37.5%

**Production Status:** Zero real video sessions have been captured. 136 Tavus API conversations exist vs 1 seed record in the local database. Root causes:
- No V2 callback URLs are configured in Tavus.
- No video agents are registered in the database (0 agents of type 'video').
- 47 conversations had undefined callback URLs.

### 3.4 VIN Solutions -- No Inbound Webhooks

The VIN Solutions integration is query-only (polling-based). There are no inbound webhooks from VIN Solutions. Some architecture documents describe a webhook handler at `POST /api/webhooks/vin` with HMAC + IP whitelist security, but this is aspirational architecture that has not been implemented. The actual VIN data flow is outbound polling every 60 minutes.

---

## 4. Background Jobs

All background jobs use `setInterval` (not cron). They run continuously while the server process is alive. Each job has a singleton guard (boolean flag) that prevents overlapping runs when a previous execution has not completed. Jobs use staggered startup delays to avoid thundering herd on server boot.

| # | Job | Interval | What It Does |
|---|-----|----------|-------------|
| 1 | **VIN Token Refresh** | 30 min | Checks the OAuth 2.0 access token for VIN Solutions. If the token is within 10 minutes of its 60-minute expiry, refreshes it proactively. If refresh fails, the next API call triggers a fresh token acquisition. |
| 2 | **Sync Queue Worker (Outbound)** | 1 min | Processes pending items in the `sync_queue` table. Each item represents a lead that needs to be created in VIN Solutions. Executes the 2-step process: create contact, then create lead with href references. On failure, the item remains in the queue with error details. |
| 3 | **Sync Queue Worker (Inbound)** | 4 hr | Polls VIN Solutions for new or modified leads from the last 48 hours. Uses OAuth 2.0 Client Credentials authentication. New leads are stored locally with VIN external IDs. Deduplication via `vin_customer_id`. |
| 4 | **Appointment Reminder** | 5 min | Checks for upcoming appointments within the reminder window. When one is found, generates a notification for the assigned staff member. |
| 5 | **Email Sync (IMAP)** | 5 min | Pulls new emails from configured IMAP servers. New emails are matched to conversation threads and appear in the Inbox. |
| 6 | **Trigger Re-evaluation** | 5 min | Re-checks age-based and time-based trigger conditions against current state. This catches leads that have become idle or stale since the last check. |
| 7 | **DealerPulse** | 4 hr | Computes dealership health metrics from all data sources. Stores metric snapshots for historical trending. Feeds the Insights Dashboard and Reports. |
| 8 | **Hunch Generation** | 6 hr | Runs the Claude "Detective" agent against current metrics and trends. Produces AI-generated hunches categorized by type and confidence. Stores results for the Insights > Hunches tab. |

**PM2 Restart Impact:** PM2 has restarted 3,247 times in production. Each restart resets the singleton guard flags and can lose any in-flight work. Webhook processing that was mid-execution when a restart occurs is lost entirely.

---

## 5. Data Flow Diagrams

### 5.1 New Lead Flow

**Trigger:** VIN Solutions has a new or modified lead.

1. The Sync Queue Worker (Inbound) job fires on its 4-hour interval.
2. The worker authenticates with VIN Solutions (OAuth 2.0, per-org credentials from encrypted DB storage).
3. The worker queries `GET /leads` with a `lastModified` filter (48-hour window).
4. For each new lead not already in the local database (matched by `vin_customer_id`):
   a. The lead is stored in the internal database with VIN external IDs.
   b. The Context Router tags it with source "VIN".
5. The Trigger Re-evaluation job (5-minute interval) detects the new lead.
6. Active trigger rules for the organization are evaluated against the `new_lead` event.
7. Conditions are checked: business hours, rate limits, prior contact, lead criteria.
8. If conditions pass, the configured action executes:
   - If `outbound_call`: VAPI initiates a call to the lead's phone number.
   - If `outbound_sms`: TextMagic sends an SMS using per-org credentials.
   - If `email_notification`: Resend sends an email.
   - If `create_task`: a task is created and assigned.
9. The execution is logged with trigger ID, action, and result.

### 5.2 Inbound Call Flow

**Trigger:** A customer calls a VAPI-connected phone number.

1. VAPI's voice AI agent handles the call (greeting, conversation, information gathering).
2. When the call starts, VAPI should send a `call.started` webhook to `POST /api/webhooks/vapi`. (**Currently broken:** this event is never received for production calls.)
3. During the call, VAPI sends `transcript` events as conversation segments are captured.
4. When the call ends, VAPI sends `call.ended` with duration and status.
5. VAPI then sends `end-of-call-report` with the full transcript, summary, and recording URL.
6. The webhook handler resolves the organization (via `metadata.organizationId` or `assistantId` lookup).
7. Lead data is extracted from the call (customer name, phone, intent).
8. Credit usage is recorded: `duration * $0.15` (cost) / `duration * $0.25` (customer charge).
9. A sync queue entry is created with `action: 'create_lead'` for VIN Solutions insertion.
10. An activity event is logged.
11. The call record, transcript, and recording appear in the Inbox for staff review.

### 5.3 Inbound SMS Flow

**Trigger:** A customer sends an SMS to a TextMagic-connected phone number.

1. TextMagic sends a webhook to `POST /api/webhooks/textmagic`.
2. The system matches the phone number to an organization via per-org database credentials.
3. The system checks the conversation state:
   - If `DORMANT`: transition to `AI_ACTIVE`.
   - If `AI_ACTIVE`: continue in AI mode.
   - If `HUMAN_ACTIVE`: route to the staff Inbox.
4. If `AI_ACTIVE`: the Communications Agent (Claude Haiku) generates a response based on conversation context and organization knowledge.
5. The response is sent back via TextMagic API.
6. The inbound message and response are stored in the conversation thread.
7. The conversation appears in the Inbox with the full thread visible.
8. If a staff member claims the conversation, the state transitions to `HUMAN_ACTIVE` and subsequent messages appear for manual response.

### 5.4 Widget Chat Flow

**Trigger:** A customer opens a widget on a dealership's external website.

1. The widget bundle loads from `nexxusv2.huminicdev.com/widget/nexxus-widget.js?code=WIDGET_CODE`.
2. The system verifies the hosting domain against the widget's whitelist. If the domain is not whitelisted, the widget does not render.
3. The customer selects a channel (text chat, voice, video, etc.).
4. For text chat:
   a. A conversation is created in the `inbox_conversations` table.
   b. The conversation is assigned to AI (the agent configured for this widget).
   c. The AI (Claude Haiku) generates responses as the customer types.
   d. If the AI cannot resolve the issue, or the customer requests a human, the conversation status changes.
   e. The conversation surfaces in the staff Unified Inbox (Hub > Inbox).
   f. Staff sees the full conversation history and continues from where the AI stopped.
5. For voice: the widget connects the customer to the VAPI assistant configured for this widget.
6. For video: the widget connects the customer to the Tavus persona configured for this widget.

---

## 6. Error Handling & Degradation

### 6.1 VIN Solutions Unavailable

When the VIN Solutions API is unreachable or returns errors:

- **Inbound polling:** The Sync Queue Worker (Inbound) logs the error to `vin_audit_log` and retries on the next 4-hour interval. No leads are lost -- they will be picked up on the next successful poll.
- **Outbound sync:** Failed items remain in the `sync_queue` table with `status: 'failed'` and error details. They are retried on subsequent worker runs. (Retry count and backoff strategy are not fully specified.)
- **Token refresh:** If the OAuth token refresh fails, it is logged and retried on the next 30-minute interval. Meanwhile, any API call that encounters a 401 triggers a fresh token acquisition attempt.
- **DealerBrain queries:** When the Context Router's SourceSelector cannot reach VIN, it falls back to the local database. The user may see slightly stale data but the system does not crash.

### 6.2 VAPI Service Down

When VAPI is unreachable:

- **Outbound calls:** Trigger actions that attempt `outbound_call` will fail. The failure is logged in the trigger execution record.
- **Inbound calls:** VAPI handles inbound calls on its own infrastructure. If VAPI is down, calls do not connect -- this is outside Nexxus's control.
- **Webhooks:** If VAPI cannot deliver webhooks, the `end-of-call-report` data is lost for that window. There is no queuing mechanism on VAPI's side to retry failed deliveries to Nexxus.

### 6.3 TextMagic Service Down

When TextMagic is unreachable:

- **Outbound SMS:** Trigger actions that attempt `outbound_sms` will fail. The failure is logged.
- **Inbound SMS:** TextMagic webhooks will not arrive. Incoming SMS messages are effectively lost until the service recovers.
- **AI auto-response:** Cannot be generated without inbound message delivery.

### 6.4 Database Connection Issues

- PostgreSQL is hosted on Neon with connection pooling.
- `SecureQueryBuilder` handles all queries. If the connection fails, the query throws an error that propagates to the API response.
- There is no React ErrorBoundary wrapper on the frontend -- a database error that causes an API 500 response will show as an unhandled error in the component.

### 6.5 Claude API Unavailable

When the Anthropic Claude API is unreachable:

- **DealerBrain chat:** The SSE stream returns an `error` event with a message. The chat interface shows the error to the user.
- **Hunch generation:** The background job fails silently and retries on the next 6-hour interval.
- **AI auto-response (SMS):** Inbound SMS in `AI_ACTIVE` state cannot generate a response. The message is stored but no reply is sent.

### 6.6 Client-Side Error Handling

- The API client (`fetchApi()`) attaches the Bearer token to every request. On a 401 response, behavior is configurable: return null or throw.
- TanStack Query is configured with `staleTime: Infinity` (data never auto-stales), `refetchOnWindowFocus: false`, and `retry: false` (no automatic retries).
- There is no React ErrorBoundary -- unhandled component errors crash the component tree without graceful degradation.
- TypeScript strict mode is enforced throughout.

### 6.7 Known P0 Error Conditions

Three confirmed critical error conditions exist in the current codebase:

1. **Hosted pages route mismatch:** The client fetches `/api/hosted-pages/public/${slug}` but the server serves `/api/pages/:slug`. This causes hosted widget pages to 404. One-line fix required.

2. **Insights crash risk:** Four unsafe `.pct` property accesses at lines 854, 1293, 2142, and 2143 in `insights.tsx`. Direct `array[0]` access without bounds checking. When the array is empty, this crashes the component. Null guards are needed at each location.

3. **Appointment status notifications:** `updateAppointment()` fires zero status change events. No SMS and no in-app notification is sent when an appointment status changes (confirmed, cancelled, rescheduled). Event emission must be added.

### 6.8 Webhook Error Patterns

- **VAPI webhooks:** The handler wraps processing in try/catch. On internal errors, it still returns HTTP 200 to prevent VAPI from entering a retry storm that could overwhelm the system.
- **Tavus webhooks:** HMAC verification failure returns HTTP 401. Processing errors are caught and logged.
- **VIN sync queue:** Failed items remain in the queue with error status. Currently 12/12 production sync items are in failed state due to the `leadSource` format bug.

### 6.9 PM2 Restart Impact

The server process is managed by PM2. PM2 has restarted 3,247 times in production. On each restart:
- All singleton job guard flags (boolean) reset to false, allowing jobs to run immediately.
- Any in-flight webhook processing is lost.
- Any in-progress sync queue work is abandoned mid-execution.
- SSE connections to active DealerBrain chats are severed.
- Background job intervals restart from zero.

---

## Appendix A: RBAC Role Hierarchy

| Level | Role | Scope | Can Create |
|-------|------|-------|-----------|
| 1 | Super Admin | System-wide. All settings, all orgs, user/org management, billing. | All roles in all organizations |
| 2 | Partner Admin | Multi-org. Org switching, resource utilization, creates orgs within partnership. | Org Admin and Staff in partner's organizations |
| 3 | Org Admin | Single org. Knowledge, email, widget, pages, triggers settings. User management within org. | Staff in own organization only |
| 4 | Org Staff | Basic access. Dashboard, agents, drive, insights, work center. | Cannot create users |

**Role-Level Mapping:** `1=super_admin, 2=partner_admin, 3=org_admin, 4+=org_staff`

**Partner Admin Model:**
- The `partners` table stores company info and `credit_pool`.
- The `partner_org_assignments` table creates a many-to-many relationship between partners and organizations.
- The `user_org_assignments` table grants user access to organizations with a per-org role.
- RLS policies ensure partner admins can only access their assigned organizations.

**Server Enforcement:** The `requireRole()` middleware enforces the role hierarchy on API endpoints.

**Client-Side Enforcement:** `ROLE_VISIBILITY` maps in dashboard components control tab-level and tile-level RBAC. Sidebar items are role-gated. There is no route-level RBAC guard -- all restrictions are applied at the component or tab level within pages.

---

## Appendix B: Economic Model

| Service | Cost Per Unit | Customer Price Per Unit | Nexxus Margin |
|---------|:------------:|:----------------------:|:-------------:|
| Voice AI (VAPI) | $0.15/min | $0.25/min | 40% |
| Video AI (Tavus) | $0.20/min | $0.32/min | 37.5% |
| SMS (TextMagic) | $0.02/msg | $0.05/msg | 60% |
| AI Tokens (Claude) | Variable | Tracked | N/A |

**Credit Tables:**
- `credit_policies` -- pricing rules and limits per service type per organization
- `credit_allocations` -- budget allocations per org per service per period
- `credit_usage` -- actual usage records (timestamp, service, amount, org)
- `service_quotas` -- maximum voice minutes, video minutes, SMS messages per org
- `service_allocations` -- allocated resources per agent per org

**Idempotency:** The `credit_recorded` boolean column with atomic `UPDATE ... WHERE credit_recorded = false RETURNING *` prevents double-counting on webhook replays.

**Usage Alert:** 80% quota threshold triggers an alert notification.

**Payment Processing:** No payment processor integration exists (no Stripe). All billing is manual Super Admin actions. The billing page is commented out in routes (marked `PHASE-FUTURE`).

---

## Appendix C: Database Overview

- **53 tables** with Row-Level Security enabled
- **~100 RLS policies** across 6-7 patterns
- **33 migration files** (001-033, with 011 missing)
- **58 JSONB columns**, ~80 foreign key relationships
- **2 database functions**, 11 triggers
- **SecureQueryBuilder** enforces org isolation on every query via `SET LOCAL`

**Known Security Bug:** Two RLS-related issues:
1. Variable name mismatch: `SecureQueryBuilder` sets `app.current_organization_id`, but some RLS policies check `app.current_org_id`. This means some policies may not enforce data isolation.
2. `SET LOCAL` without an explicit transaction: the variable persists for the entire database connection lifetime. In a connection pool, this could leak organization context between requests.

---

## Appendix D: Real-Time Communication Patterns

| Pattern | Used For | Mechanism |
|---------|---------|-----------|
| SSE (Server-Sent Events) | DealerBrain chat streaming | Persistent HTTP connection, server pushes tokens |
| Polling (30s) | Notification bell updates | Client-side interval fetch |
| Polling (15s) | Inbox message updates | Client-side interval fetch |
| Polling (60s) | Activity feed, Insights dashboard | Client-side interval fetch |

**Note:** `socket.io` is in the package.json dependencies, but no WebSocket connections exist in the client code. The SRS specification called for SSE-based notifications; an implementation note specified WebSocket; the actual implementation appears to be polling-based for all real-time features except DealerBrain streaming.

---

## Appendix E: Encryption Standards

**At Rest (Credentials):**
- Algorithm: AES-256-GCM
- Key Derivation: PBKDF2 with 100,000 iterations, SHA-256
- Per-credential random salt and initialization vector
- Applied to: VIN Solutions OAuth tokens (`vin_credentials` table), TextMagic API keys, and other integration credentials

**In Transit:**
- TLS 1.3 for all connections

**Password Storage:**
- bcrypt v6.0.0 for user password hashing

---

## Appendix F: VIN Solutions API Reference

**Protocol:** REST over HTTPS
**Authentication:** OAuth 2.0 Client Credentials
**Token Endpoint:** `https://api.vinsolutions.com/oauth2/token`
**Token Expiry:** 60 minutes (3,922+ seconds observed empirically)

**Accessible Endpoints (13):** leads, contacts, lead sources, lead types, lead groups, dealers, users, inventory (partial)

**Blocked Endpoints (17):** activities, deals, tasks, repair orders, notes -- most return HTTP 403

**Header Requirements:**
- Gateway endpoints (`/gateway/v1/`): `Content-Type: application/json`
- Newer endpoints: `Content-Type: application/vnd.coxauto.v3+json` (lowercase `v3` -- uppercase `V3` causes failures)

**2-Step Lead Creation:**
1. `POST /contacts` with customer data -> returns `ContactId`
2. Construct contact href: `/contacts/id/{ContactId}?dealerid={dealerId}` (must include `dealerid` query param)
3. Query `GET /leadSources?dealerId=X` for valid source hrefs
4. `POST /leads` with `leadSource` (href), `leadType` (href), `contact` (href) -- all must be URL references, not string names

**Audit Trail:** The `vin_audit_log` table records 5 action types: `token_refresh`, `api_call`, `sync_started`, `sync_completed`, `error`.

---

## Appendix G: Approval Workflow

The approval workflow provides a structured review process for AI-generated content and high-impact actions.

**States:** `pending` -> `approved` | `rejected` | `timeout`

**Flow:**
1. A hunch or external communication generates an approval request. Status: `pending`.
2. An authorized user reviews and approves. Status: `approved`. The target entity is updated.
3. Alternatively, the user rejects. Status: `rejected`.
4. If no action is taken within `timeout_hours`, the request expires. Status: `timeout`.

**Schema:** `approval_workflows` (configuration), `approval_requests` (instances), `approval_actions` (decisions).

---

## Appendix H: Notification Routing

**Notification Channels:**

| Channel | Service | Status |
|---------|---------|--------|
| In-App | Notification bell in TopBar (last 10, badge count) | Implemented |
| Email | Resend API | Implemented |
| SMS | TextMagic API | Implemented (per-org credentials) but not wired to notification events |

**Notification Events:**
- Call completion (VAPI webhook -> email notification)
- Low credit balance (in-app notification)
- Approval request assigned
- Task assigned or due
- Lead status change
- System alerts and errors
- Appointment reminders
- Daily digest (configurable)
- New hunch generated

**Routing Hierarchy:**
- Organization-level events -> all admins of that organization
- User-level events -> the specific user
- System-level events -> Super Admins
- Partner-level events -> Partner Admin for their assigned organizations

**Per-User Settings:**
- Global toggles: email ON/OFF, SMS ON/OFF, push ON/OFF
- Quiet hours: start time / end time
- Per-event channel preferences

**Polling:** The notification bell polls every 30 seconds for unread count. The `useNotifications` hook manages: list, unread count, mark read, mark all read, bulk update settings, and event type configuration.

---

## Document Status

**Unresolved Items Requiring Owner Decision:**

| # | Item | Reference | Impact |
|---|------|-----------|--------|
| 1 | Canonical trigger event type names | DISAGREE-1 | Triggers may use inconsistent names across docs and code |
| 2 | Canonical trigger action type names | DISAGREE-2 | Same as above |
| 3 | RLS variable name mismatch fix | C-11 | Security-critical -- data isolation may not be enforcing |
| 4 | Main page layout (V2.1) | C-13 | Dashboard vs chat-only vs metrics+chat |
| 5 | Insights sub-tabs (Goals removed?) | C-14 | DevDesign Notes removes Goals; code still has it |
| 6 | Activity page location | C-15 | Standalone page vs Insights sub-tab |
| 7 | Notification transport mechanism | C-04 | SSE vs WebSocket vs polling -- actual implementation unclear |
| 8 | SMS state machine transition details | MI-01 | Timeout durations and transition triggers unspecified |
| 9 | Widget-to-Inbox handoff mechanism | MI-03 | Technical trigger for surfacing conversations not specified |
| 10 | Voice call handoff (VAPI to human) | MI-02 | Mechanism not documented |
| 11 | Sync queue retry policy | MI-04 | Retry count, backoff, dead letter behavior unspecified |
| 12 | Multi-org query resolution | MI-20 | Unresolved design question for multi-org Org Admin users |

---

*End of System Requirements Specification*
