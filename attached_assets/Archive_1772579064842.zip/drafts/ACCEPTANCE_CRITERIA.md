# Nexxus V2 — Acceptance Criteria

**Version:** 1.0 DRAFT
**Date:** 2026-03-03
**Source:** Wave 4 reconciled analysis (151 testable outcomes from dual-agent extraction)
**Audience:** Tester/agent verifying features
**Status:** All items UNTESTED — pending validation runs

---

## How to Read This File

- Each AC has a unique stable ID (AC-NNN). Tests reference these IDs directly.
- Format: `Given [context], When [action], Then [expected result]`
- **Status values:** UNTESTED | PASS | FAIL | BLOCKED
- **Priority values:**
  - **LAUNCH-CRITICAL** — Required for demo readiness and payment-critical flows
  - **IMPORTANT** — Required for complete product experience; watch areas
  - **NICE-TO-HAVE** — Deferred or low-risk items
- Feature areas map to the Reference UI (RUI) navigation structure.
- Items tagged `[OWNER DECISION]` require owner resolution before testing.

---

## 1. Authentication & Access (AC-001 through AC-011)

### AC-001: Login Page Renders
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user navigates to /login,
When the page loads,
Then an email field, password field, and "Sign In" button are visible.

### AC-002: Successful Login Redirect and Token Storage
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user is on the login page with valid credentials,
When the user submits email and password,
Then the user is redirected to the Main page, and JWT tokens are stored in localStorage (access token with 15-minute expiry, refresh token with 7-day expiry).

### AC-003: Invalid Login Error
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user is on the login page with invalid credentials,
When the user submits email and password,
Then an error message is displayed and no redirect occurs.

### AC-004: JWT Token Auto-Refresh
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user is logged in and the access token is within 5 minutes of expiry,
When the auto-refresh mechanism fires,
Then a POST to /api/auth/refresh returns a new access token without user intervention.

### AC-005: Organization Switching
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user is a Partner Admin or Super Admin with access to multiple orgs,
When the user selects a different org from the org switcher,
Then POST /api/auth/switch-org returns new org-scoped tokens and the UI reloads with data from the selected org.

### AC-006: Super Admin Nexxus System View
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user is a Super Admin,
When the org switcher is opened,
Then a "Nexxus System" option is visible and selectable, showing default system configuration.

### AC-007: Logout Clears State
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user is logged in,
When the user clicks Logout,
Then all 4 localStorage keys are cleared and the user is redirected to /login.

### AC-008: Password Reset Flow
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user is on the login page,
When the user clicks "Forgot Password" and submits their email,
Then a password reset email is sent, and the user can set a new password via the reset link.

### AC-009: RBAC Role Enforcement
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the system has 4 roles (super_admin, partner_admin, org_admin, org_staff),
When a user logs in with a given role,
Then only features authorized for that role are visible and accessible.

### AC-010: Protected Route Guard
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user is not authenticated,
When the user attempts to navigate to any protected route,
Then the user is redirected to /login.

### AC-011: RLS Tenant Isolation
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user is logged in to Org A,
When any API request is made,
Then no data from Org B, Org C, or any other org is visible or modifiable.

---

## 2. Navigation & Layout (AC-012 through AC-031)

### AC-012: Sidebar Navigation Order
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED
**Note:** `[OWNER DECISION]` — Canonical sidebar order requires owner resolution. DevDesign Notes says Main, Insights, Agents, Hub, Drive. MASTER_SRS says Main, Agents, Drive, Insights, Hub, Activity, Settings.

Given the user is logged in,
When the sidebar is visible,
Then sidebar items appear in the owner-confirmed canonical order.

### AC-013: Sidebar Collapsed Width
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the sidebar is in collapsed state,
When measured,
Then the sidebar width is 64px.

### AC-014: Desktop 3-Pane Grid Layout
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the viewport is wider than 1024px,
When any page with a 3-pane layout renders,
Then the layout has sidebar (64px), left panel (240-400px), center panel (flexible), and optional right panel (320-500px).

### AC-015: Settings Submenu Access
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user is org_admin or higher,
When the user opens Settings,
Then 9 tile-based setting categories are displayed as a submenu.

### AC-016: No Vendor Names Visible to End Users
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given any page in the application,
When the user inspects visible text,
Then no vendor names (VIN Solutions, VAPI, Tavus, TextMagic, Resend, Anthropic, Claude) appear in the user-facing UI.

### AC-017: No Data Source Labels Visible
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given any page in the application,
When the user inspects visible text,
Then no internal data source labels ("excel_upload", "vin_api", "manual_entry", etc.) appear in the user-facing UI.

### AC-018: Nexxus Logo Without Icon Element
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the application header,
When the logo renders,
Then the Nexxus logo is displayed WITHOUT an icon element.

### AC-019: Activity Feed Indicator in Header
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user is logged in,
When the header renders,
Then an activity feed icon/indicator shows current org lead activity.

### AC-020: Mobile Responsive Layout
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the viewport width is less than 768px,
When any page renders,
Then the sidebar collapses to a hamburger menu and the layout switches to single-column.

### AC-021: Theme Toggle
**Priority:** NICE-TO-HAVE
**Status:** UNTESTED

Given the top nav bar,
When the user toggles light/dark theme,
Then the theme switches immediately and persists across page reloads via localStorage.

### AC-022: Layout Type System
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the 5 defined layout types (A: chat-only, B: info+chat, C: chat+info, D: settings, E: library),
When each page renders,
Then it uses the correct layout type for its navigation section.

### AC-023: Notification Bell with Unread Count
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user has unread notifications,
When the header renders,
Then a notification bell icon displays with an unread count badge.

### AC-024: Sidebar Pop-Out Submenu
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the sidebar is collapsed,
When the user hovers over a sidebar item with a submenu,
Then a pop-out submenu appears; clicking the double-arrow icon locks it open.

### AC-025: Layout Type B on Main Dashboard
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user navigates to the Main page,
When the page renders,
Then Layout Type B is applied (info center, chat right), and the chat panel opens by default on this page only.

### AC-026: Layout Type C on Agents Page
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user navigates to the Agents page,
When the page renders,
Then Layout Type C is applied (chat center, config in right pane).

### AC-027: Staff Cannot See Settings
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user is logged in as org_staff,
When the sidebar renders,
Then Settings is not visible in the sidebar.

### AC-028: Activity Tab Hidden from Staff
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user is logged in as org_staff,
When the sidebar or Insights sub-tabs render,
Then Activity is not visible.

### AC-029: Zero Console Errors on Navigation
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the browser developer console is open,
When the user navigates through all major pages,
Then zero JavaScript errors appear in the console.

### AC-030: Page Load Performance
**Priority:** IMPORTANT
**Status:** UNTESTED

Given any page in the application,
When the page is navigated to,
Then it loads within 3 seconds.

### AC-031: Product Tour RBAC
**Priority:** NICE-TO-HAVE
**Status:** UNTESTED

Given a first-time user logs in,
When the product tour initiates,
Then the tour content adapts based on the user's role (admin sees admin features, staff sees staff features).

---

## 3. Main — Automa Chat (AC-032 through AC-045)

### AC-032: Automa Chat Present on Main
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user navigates to the Main page,
When the page loads,
Then the Automa chat interface is present and ready to accept input.

### AC-033: Automa Name in UI
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given any surface where the chat assistant is referenced,
When the UI renders,
Then the chat is labeled "Automa" and the name "DealerBrain" does NOT appear anywhere in the UI.

### AC-034: SSE Streaming with Event Types
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user sends a message to Automa,
When the response is generated,
Then the response streams via SSE with the 6 defined event types: thinking, tool_start, tool_end, token, done, error.

### AC-035: Thinking Animation
**Priority:** IMPORTANT
**Status:** UNTESTED

Given Automa is processing a response,
When the thinking state is active,
Then a flat line wave animation is displayed (not dots, not a spinner).

### AC-036: Message Alignment
**Priority:** IMPORTANT
**Status:** UNTESTED

Given a chat conversation,
When messages render,
Then bot messages appear on the left, user messages on the right, with no bot icon displayed.

### AC-037: Automa as Dealership Context Assistant
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user sends a dealership-related question,
When Automa processes the message,
Then the response demonstrates CRM-aware context appropriate for dealership operations.

### AC-038: Per-Org System Context
**Priority:** IMPORTANT
**Status:** UNTESTED

Given an org admin has configured system context in Settings,
When a user in that org chats with Automa,
Then Automa's responses incorporate the org-specific system context.

### AC-039: Tool Call Visibility
**Priority:** IMPORTANT
**Status:** UNTESTED

Given Automa invokes a tool during response generation,
When the tool executes,
Then the user sees a tool_start indicator followed by tool_end with the result.

### AC-040: Chart Rendering in Chat
**Priority:** IMPORTANT
**Status:** UNTESTED

Given Automa returns a tool_end event with chartData payload,
When the response renders,
Then a chart is rendered inline within the chat conversation.

### AC-041: VIN Query Limitation Disclosure
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the VIN API has limited endpoints (17 of 30 return 403),
When the user asks Automa a question that hits a limited VIN endpoint,
Then Automa discloses the limitation to the user rather than returning empty or incorrect data.

### AC-042: Multi-Turn Conversation Context
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user has an active chat session with Automa,
When the user sends 5-10 consecutive messages,
Then Automa maintains context across all turns, referencing earlier messages appropriately.

### AC-043: Automa Chat Popout Overlay
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user is on any page other than the Main dedicated chat view,
When Automa chat is opened,
Then it appears as a floating popout overlay (not inline).

### AC-044: CRM Data Query via Automa
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user types "Search VIN for [name]" in Automa,
When the message is sent,
Then Automa queries VIN Solutions and returns matching lead information.

### AC-045: Automa First-Token Response Time
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user sends a message to Automa,
When the response begins streaming,
Then the first token appears within 3 seconds.

---

## 4. Insights — Dashboard & Reports (AC-046 through AC-065)

### AC-046: Command Center Alert Zones
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user navigates to Insights > Dashboard > Command Center,
When the dashboard renders,
Then 3 alert zones are displayed: Red (immediate), Yellow (watch list), Green (performance).

### AC-047: Insights Sub-Navigation Structure
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user is on the Insights page,
When the sub-navigation renders,
Then two sections are available: Dashboard (Command Center, Pipeline Health, Performance Scorecard) and Reports (Loss & Quality, Channel Intelligence, Trend & Forecast).

### AC-048: Hunches Sub-Tab
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user is on the Insights page,
When the sub-tabs render,
Then a Hunches tab is available showing AI-generated insights.

### AC-049: Goals Removed from Insights
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the Insights page,
When the user inspects all tabs and sub-sections,
Then no Goals tab or section is present in the UI.

### AC-050: Activity as Insights Sub-Tab
**Priority:** IMPORTANT
**Status:** UNTESTED
**Note:** `[OWNER DECISION]` — Confirm Activity moved from standalone sidebar to Insights sub-tab per DevDesign Notes.

Given the Insights page,
When the sub-tabs render,
Then Activity appears as a sub-tab within Insights (not as a standalone sidebar item).

### AC-051: Priority Reports Available
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user navigates to Insights > Reports,
When the reports section renders,
Then 6 priority reports are available across the 3 report categories.

### AC-052: Grid/Tile View Toggle on Insights
**Priority:** NICE-TO-HAVE
**Status:** UNTESTED

Given the user is viewing Insights data cards,
When the user toggles grid/tile view,
Then the display mode switches between grid and tile layouts.

### AC-053: Voice Metrics Display
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the org has VAPI call data,
When the user views voice metrics in Insights,
Then total calls, average duration, and calls by status are displayed.

### AC-054: Video Metrics Display
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the org has Tavus video session data,
When the user views video metrics in Insights,
Then video session metrics are displayed accurately.

### AC-055: Data Accuracy Mandate
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given any metric displayed in Insights,
When compared against ground truth data,
Then displayed values are within 2% of ground truth.

### AC-056: Excel Upload Exclusion from Metrics
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given records imported via excel_upload exist in the database,
When any metric calculation runs,
Then excel_upload records are excluded from all metric calculations.

### AC-057: Null Guard Safety on Insights
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given a metric has null or undefined percentage values,
When the Insights dashboard renders,
Then the page does not crash — null values are handled gracefully (no crash on null .pct).

### AC-058: Hunch Lifecycle Management
**Priority:** IMPORTANT
**Status:** UNTESTED

Given AI-generated hunches exist,
When the user views the Hunches sub-tab,
Then hunches display with status tracking and actionable recommendations.

### AC-059: Metric Tile Drill-Down
**Priority:** IMPORTANT
**Status:** UNTESTED

Given a metric tile on the Insights dashboard,
When the user clicks the tile,
Then a detailed view opens showing underlying data and records.

### AC-060: View Call Transcript
**Priority:** IMPORTANT
**Status:** UNTESTED

Given a completed voice call exists in the system,
When the user clicks "View Transcript" on the call record,
Then the full transcript displays in a modal.

### AC-061: Test Calls Excluded from Metrics
**Priority:** IMPORTANT
**Status:** UNTESTED

Given test call records exist (IDs matching test-e2e-* pattern),
When metrics are calculated,
Then test calls are excluded from all metric aggregations.

### AC-062: Dashboard Refresh Button
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user is on the Insights dashboard,
When the user clicks the Refresh button,
Then all metrics queries are invalidated and reloaded with fresh data.

### AC-063: No Placeholder Metrics
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given a metric cannot be calculated (insufficient data or error),
When the dashboard renders,
Then the metric is not displayed at all — no placeholder, mock, or zero values shown.

### AC-064: Date Range Filter on Insights
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user is on the Insights dashboard,
When the user selects a date range filter (24h, 48h, 7d, 30d),
Then all displayed metrics update to reflect the selected time window.

### AC-065: CSV Export from Command Center
**Priority:** NICE-TO-HAVE
**Status:** UNTESTED

Given the user is viewing the Command Center stale leads section,
When the user clicks CSV export,
Then a CSV file downloads containing the stale leads data.

---

## 5. Agents (AC-066 through AC-079)

### AC-066: Agent List Page
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user navigates to the Agents page,
When the page loads,
Then configured agents for the current org are displayed in a list.

### AC-067: Automa Not Listed on Agents Page
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED
**Note:** `[OWNER DECISION]` — DevDesign Notes says Automa is NOT listed on Agents page. MASTER_SRS says "always at top." Both agents used DevDesign Notes resolution. Owner must confirm.

Given the user is on the Agents page,
When the agent list renders,
Then Automa does NOT appear in the agent list.

### AC-068: New Agent Creation Dialog
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user clicks "New Agent" on the Agents page,
When the creation dialog opens,
Then a center dialog appears with name input, channel buttons, and tool tiles below; clicking tool tiles opens a configuration modal.

### AC-069: Agent Right Pane Details
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user selects an agent from the list,
When the right pane opens,
Then it shows: configuration, activity log, triggers, prompt, knowledge, customer-facing link, phone number, and chat link.

### AC-070: Communications Agent Default
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the system is initialized for an org,
When the agent list is viewed,
Then a Communications Agent is available out of the box, configured by Super Admin only, and marked as static (non-deletable).

### AC-071: Agent Name Consistency Across Channels
**Priority:** IMPORTANT
**Status:** UNTESTED

Given an agent has a configured name,
When the agent is used across Tavus video, VAPI voice, and internal UI,
Then the agent name is consistent across all surfaces.

### AC-072: Agent Instructions Editable
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user navigates to Settings > AI Configuration,
When agent instructions are edited and saved,
Then the updated instructions are applied to the agent's behavior.

### AC-073: Skills Architecture
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the Agents page or Settings > AI Configuration,
When skills are viewed,
Then users can select from a catalog of pre-built skills (74 from V1 as baseline).

### AC-074: Skills Tab Super Admin Only
**Priority:** IMPORTANT
**Status:** UNTESTED

Given a user who is NOT a Super Admin,
When navigating to Settings > AI Configuration,
Then the Skills tab is not visible; for Super Admin, it is visible with an emergency kill switch.

### AC-075: Agent CRUD Operations
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the Agents page,
When the user performs create, read, update, delete, duplicate, or status toggle operations,
Then each operation completes successfully and the agent list reflects the change.

### AC-076: Agent Customer-Facing Links
**Priority:** IMPORTANT
**Status:** UNTESTED

Given an agent is selected in the right pane,
When the contact information section renders,
Then customer-facing link, phone number, and text chat link are displayed.

### AC-077: Agent List Search and Filters
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the Agents page,
When the user enters a search term or selects type/status filters,
Then the agent list filters to show only matching agents.

### AC-078: Agent Chat Interaction
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user selects an agent from the list,
When the user sends messages in the center chat pane,
Then the agent responds correctly for 5-10 turns with context maintained.

### AC-079: Agent Active/Inactive Toggle
**Priority:** IMPORTANT
**Status:** UNTESTED

Given an agent exists in the list,
When the user toggles the agent's active/inactive status,
Then the status updates immediately and the agent's availability changes accordingly.

---

## 6. Hub — Calendar (AC-080 through AC-089)

### AC-080: Hub Tab Structure
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user navigates to Hub (/work-center),
When the page loads,
Then exactly 3 tabs are visible: Calendar, Leads, Inbox.

### AC-081: Calendar View by Role
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user is on Hub > Calendar,
When the calendar renders,
Then staff see their own appointments and org_admin+ see all users' appointments.

### AC-082: Appointment CRUD
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user is on Hub > Calendar,
When the user creates, reads, updates, or deletes an appointment via /api/appointments/* endpoints,
Then the operation completes successfully and the calendar reflects the change.

### AC-083: Appointment Confirmation SMS
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given an appointment is created or updated with a customer phone number,
When the appointment is saved,
Then a confirmation SMS is sent to the customer via the configured SMS service.

### AC-084: Appointment Status Change Fires Events
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given an appointment exists,
When the appointment status is updated (e.g., confirmed, cancelled, completed),
Then notification events fire correctly (fix for known P0: updateAppointment() previously fired zero events).

### AC-085: Hub Activity Filtered by Role
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user is viewing Hub activity,
When the activity feed renders,
Then staff see their own activity only, and org_admin see all activity with color-coded user key.

### AC-086: Hub User Filter for Admins
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user is org_admin or partner_admin,
When a user filter is applied in Hub,
Then the Hub view filters to show only the selected user's data.

### AC-087: Google Calendar Integration
**Priority:** NICE-TO-HAVE
**Status:** UNTESTED

Given the org has Google Calendar integration configured,
When an appointment is created or updated,
Then the appointment pushes to the connected Google Calendar.

### AC-088: Appointment Creates VIN Lead Note
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given an appointment is created for a lead,
When the appointment is saved,
Then a lead record is inserted (or updated) in VIN Solutions with the appointment note.

### AC-089: Appointment Drag-and-Drop Reschedule
**Priority:** NICE-TO-HAVE
**Status:** UNTESTED

Given the user is viewing Hub > Calendar in week or month view,
When the user drags an appointment to a different time slot,
Then the appointment is rescheduled to the new time.

---

## 7. Hub — Leads (AC-090 through AC-097)

### AC-090: Leads List with Action Buttons
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user navigates to Hub > Leads,
When the leads list renders,
Then each lead row shows text, call, and schedule buttons.

### AC-091: Lead Follow-Up Trigger
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED
**Note:** `[OWNER DECISION]` — Time threshold conflict. Analyst extracted "lead age > 2h, no contact." Reviewer extracted "not addressed within 5 minutes." Owner must clarify correct threshold.

Given a new lead is imported and remains uncontacted past the configured threshold,
When the trigger evaluation runs,
Then an outbound call or SMS is triggered for the uncontacted lead.

### AC-092: Lead Insertion to VIN Solutions
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given a lead is created from VAPI or Tavus interaction,
When the sync queue processes,
Then the lead is inserted into VIN Solutions (2-step: create contact, then create lead). No other write operations to VIN.

### AC-093: Mark Lead as Contacted
**Priority:** IMPORTANT
**Status:** UNTESTED

Given a lead exists in the list,
When the user clicks "Mark Contacted" or calls PATCH /api/leads/:id/mark-contacted,
Then the lead status updates to contacted and VIN CRM sync triggers.

### AC-094: Lead Status Update
**Priority:** IMPORTANT
**Status:** UNTESTED

Given a lead exists,
When the user updates the lead status via PUT /api/leads/:id/status,
Then the status change persists and the leads list reflects the new status.

### AC-095: VIN Lead Data Accuracy
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given leads are imported from VIN Solutions,
When lead detail is displayed,
Then all displayed fields match the VIN API response exactly.

### AC-096: Lead Detail Modal
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user is on Hub > Leads,
When the user clicks on a lead ID,
Then a full information modal opens with complete lead details.

### AC-097: Lead Duplicate Detection
**Priority:** IMPORTANT
**Status:** UNTESTED

Given a new lead is about to be created in VIN Solutions,
When the system checks for duplicates,
Then phone number and email are matched against existing leads to prevent duplicates.

---

## 8. Hub — Inbox (AC-098 through AC-108)

### AC-098: Unified Messaging Inbox
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user navigates to Hub > Inbox,
When the inbox renders,
Then all conversation threads are displayed: widget chats, SMS, and callbacks.

### AC-099: Two-Way SMS Messaging
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the org has SMS configured,
When staff sends an SMS and the customer replies,
Then the reply appears in the Inbox thread.

### AC-100: New Message Modal
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user is in Hub > Inbox,
When the user clicks "New Message,"
Then a modal opens with SMS and Email composition options.

### AC-101: Conversation Assignment
**Priority:** IMPORTANT
**Status:** UNTESTED

Given a conversation thread exists,
When an admin assigns it to a staff member,
Then the conversation moves to the assigned staff member's view.

### AC-102: Conversation Status Tracking
**Priority:** IMPORTANT
**Status:** UNTESTED

Given a conversation exists,
When the user filters by status (open, in_progress, closed),
Then only conversations matching the selected status are displayed.

### AC-103: Inbox Unread Count Badge
**Priority:** IMPORTANT
**Status:** UNTESTED

Given unread messages exist in the Inbox,
When the Hub tabs render,
Then the Inbox tab displays an unread count badge.

### AC-104: Staff SMS Send from Inbox
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user is viewing a conversation thread in Hub > Inbox,
When the user composes and sends an SMS reply,
Then the SMS is sent via the configured SMS service and appears in the thread.

### AC-105: External Agent Conversation Handoff
**Priority:** IMPORTANT
**Status:** UNTESTED

Given an external agent (widget) has an active conversation with a customer,
When a staff member takes over the conversation,
Then the staff member sees the full conversation history and can continue the thread.

### AC-106: After-Hours AI SMS Response
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given an inbound SMS arrives after business hours,
When the system processes the message,
Then an AI-generated response is sent via Claude API (not voice), and the conversation is logged.

### AC-107: SMS Human Takeover
**Priority:** IMPORTANT
**Status:** UNTESTED

Given an AI is actively responding to an SMS conversation,
When a staff member sends a manual reply,
Then AI responses stop immediately (conversation enters HUMAN_ACTIVE state).

### AC-108: Email in Inbox
**Priority:** IMPORTANT
**Status:** UNTESTED
**Note:** `[OWNER DECISION]` — Backend hooks exist. Owner says "email missing from interface." Scope TBD.

Given the org has email integration (IMAP/SMTP) configured,
When the user navigates to Hub > Inbox,
Then email threads appear alongside SMS and chat, with rich-text compose available for email replies.

---

## 9. Widgets (AC-109 through AC-122)

### AC-109: Master Widget Communication Options
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given a widget is configured for an org,
When the widget renders,
Then 6 communication options are available: Text Chat, Web Video Agent, Call Us, Call You, Web Audio, Send a Text.

### AC-110: Widget Configuration UI
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user navigates to Settings > Tools & Integrations > Widgets,
When the configuration page loads,
Then sections for appearance, channels, targeting, and embed code are available.

### AC-111: Hosted Widget Pages
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given a widget with slug "demo" is configured for org "acme,"
When a visitor navigates to /hosted/acme/demo/chat (or /video or /callback),
Then the hosted page renders with the correct widget and agent.

### AC-112: Hosted Pages Route Match
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the client requests a hosted page,
When the client route and server route are compared,
Then they match correctly (known P0 fix: client and server route patterns aligned).

### AC-113: Widget Demo Functional
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given a configured widget,
When the widget demo is loaded,
Then the widget loads within 1.5 seconds with all enabled channels functional.

### AC-114: Widget Domain Restrictions
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given a widget has domain whitelisting configured,
When the widget embed is loaded on an unauthorized domain,
Then the widget does not render.

### AC-115: Widget Load Performance
**Priority:** IMPORTANT
**Status:** UNTESTED

Given a widget embed code is placed on a page,
When the page loads,
Then the widget fully renders within 1.5 seconds.

### AC-116: Widget Channel Enable/Disable
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the widget configuration UI,
When the org admin enables or disables individual channels,
Then only enabled channels appear in the deployed widget.

### AC-117: Three Deployment Modes
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the widget system,
When each deployment mode is tested,
Then all 3 modes function: unified widget (corner overlay), embed code (customer site), hosted landing page.

### AC-118: Widget Chat AI Response Time
**Priority:** IMPORTANT
**Status:** UNTESTED

Given a user sends a message through the widget chat,
When the AI processes the message,
Then a response appears within 5 seconds.

### AC-119: Widget Contains No Vendor Names
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given any widget deployment mode,
When the widget UI renders,
Then zero vendor names appear in the widget interface.

### AC-120: Widget Responsive Design
**Priority:** IMPORTANT
**Status:** UNTESTED

Given a widget deployment,
When accessed from mobile, tablet, and desktop viewports,
Then the widget functions correctly on all device sizes.

### AC-121: Inbound Calls via Widget
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given a widget with "Call Us" or "Web Audio" enabled,
When a visitor initiates a call,
Then the call connects to the configured voice assistant.

### AC-122: Outbound Call from Widget
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given a widget with "Call You" enabled,
When a visitor enters their phone number and requests a callback,
Then an outbound call is triggered to the customer's phone number.

---

## 10. Triggers (AC-123 through AC-131)

### AC-123: Automatic Outbound Call Triggering
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given a trigger rule is configured for conditions (new lead, hot lead, missed call),
When the conditions are met,
Then an automatic outbound call is initiated.

### AC-124: Trigger CRUD Operations
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the trigger management interface or /api/triggers/* endpoints,
When the user creates, reads, updates, or deletes a trigger rule,
Then the operation completes successfully and the trigger list reflects the change.

### AC-125: Trigger Deduplication
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given a trigger fires for a lead,
When the same trigger conditions are met again within the dedup time window,
Then only one action executes — no duplicate calls, SMS, or notifications.

### AC-126: Business Hours Enforcement
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given a trigger rule has business_hours_only enabled,
When the trigger fires outside of configured business hours,
Then the action is deferred until business hours resume.

### AC-127: Global Trigger Enable/Disable
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user is a Super Admin,
When the global trigger toggle is flipped to disabled,
Then ALL triggers across ALL orgs are immediately suspended.

### AC-128: Trigger Notification Delivery Time
**Priority:** IMPORTANT
**Status:** UNTESTED

Given a trigger event occurs,
When the trigger action generates a notification,
Then the notification is delivered within 60 seconds.

### AC-129: Existing Triggers Deactivated by Default
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the 15 existing trigger rules in the database,
When the trigger list is queried,
Then all 15 have status=inactive (none firing until explicitly activated).

### AC-130: Five Trigger Action Types
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the trigger action configuration,
When creating or editing a trigger rule,
Then 5 action types are available: outbound_call, send_sms, send_email, create_task, webhook.

### AC-131: Trigger Visibility on Agent Pane
**Priority:** IMPORTANT
**Status:** UNTESTED

Given an agent has associated triggers,
When the agent's right pane is opened,
Then associated triggers are listed in the triggers section.

---

## 11. Drive (AC-132 through AC-137)

### AC-132: File Management CRUD
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user navigates to Drive,
When the user creates folders, uploads files, renames, or deletes via /api/drive/* endpoints,
Then each operation completes successfully and the file browser reflects the change.

### AC-133: File Sharing via Email or SMS
**Priority:** IMPORTANT
**Status:** UNTESTED

Given a file exists in Drive,
When the user shares it via email or SMS,
Then the recipient receives a share link through the selected channel.

### AC-134: Storage Usage Display
**Priority:** NICE-TO-HAVE
**Status:** UNTESTED

Given the user is on the Drive page,
When storage info renders,
Then the organization's current storage usage is displayed.

### AC-135: Personal and Shared Drive Spaces
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user navigates to Drive,
When the file browser renders,
Then two spaces are available: Personal and Shared.

### AC-136: Drive Grid/List View Toggle
**Priority:** NICE-TO-HAVE
**Status:** UNTESTED

Given the user is on the Drive page,
When the user toggles between grid and list view,
Then the file browser switches display modes.

### AC-137: Chat Artifacts Auto-Saved to Drive
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user creates an artifact in Automa chat,
When the artifact is generated,
Then it is automatically saved to the user's Drive.

---

## 12. Settings (AC-138 through AC-152)

### AC-138: Nine Settings Tile Categories
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user navigates to Settings,
When the settings page renders,
Then 9 tile-based categories are displayed (Users, Organization, Tools & Integrations, Knowledge Base, AI Configuration, Security, Notifications, Data Management, Appearance).

### AC-139: Settings RBAC Tile Visibility
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given users of different roles,
When each role views Settings,
Then Super Admin sees all 9 tiles, Partner Admin sees a subset, Org Admin sees a subset, and Staff sees none (Settings hidden per AC-027).

### AC-140: Tools & Integrations Tabs
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user opens Settings > Tools & Integrations,
When the page loads,
Then 5 tabs are visible (MCP, API, Other, Widgets, Landing Pages) plus 2 additional tabs for Super Admin (API Keys, Webhooks).

### AC-141: AI Configuration Tabs
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user opens Settings > AI Configuration,
When the page loads,
Then 4 tabs are visible: System Prompt, Agent Behavior, Skills, Hunches.

### AC-142: Knowledge Base Management
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user opens Settings > Knowledge Base,
When the page loads,
Then 4 tabs are visible: Documents, Web Pages, Databases, Settings.

### AC-143: Billing Page
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user navigates to the Billing page,
When the page loads,
Then subscription tiers, usage meters, and invoice information are displayed.

### AC-144: User Management CRUD
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user is org_admin or higher in Settings > Users,
When the user adds, edits, or removes users within the current org,
Then the operation completes and the user list updates accordingly.

### AC-145: Org Creation Wizard
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user is a Super Admin,
When the user initiates org creation,
Then a wizard guides through the org setup process.

### AC-146: Economy/Billing Rate on Tool Cards
**Priority:** NICE-TO-HAVE
**Status:** UNTESTED

Given the user is viewing Settings > Tools & Integrations,
When tool cards render,
Then each card displays its economy/billing rate information.

### AC-147: Data Management Tabs
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user opens Settings > Data Management,
When the page loads,
Then 2 tabs are visible: Database Uploads and Data Health.

### AC-148: Integration Test Connection
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user is configuring an integration in Settings > Tools & Integrations,
When the user clicks "Test Connection,"
Then a success or failure message is displayed with specific feedback.

### AC-149: Emergency Kill Switch
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user is a Super Admin in Settings > AI Configuration > Skills,
When the emergency kill switch is activated (with confirmation dialog),
Then ALL agent activity for ALL users and ALL orgs is immediately disabled.

### AC-150: Widget Configuration with Live Preview
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user is in Settings > Tools & Integrations > Widgets,
When appearance or channel settings are changed,
Then a live preview updates in real-time to reflect the changes.

### AC-151: Agent Instructions from Settings Applied
**Priority:** IMPORTANT
**Status:** UNTESTED

Given custom instructions are saved in Settings > AI Configuration,
When an agent processes a message,
Then the agent's behavior reflects the custom instructions.

### AC-152: Lead Assignment Configurable
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the Settings page for lead management,
When lead assignment rules are configured,
Then new leads are assigned according to the configuration (not hardcoded). Default assignee: Dustin Herman.

---

## 13. Metrics & Scores (AC-153 through AC-164)

### AC-153: Org Admin Main Page Tiles
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user is logged in as org_admin,
When the Main page renders,
Then 4 metric tiles are displayed: Pipeline Health, Lead Source Performance, Lead Quality, Market Demand Insight — each scored 0-100.

### AC-154: Staff Main Page Tiles
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the user is logged in as org_staff,
When the Main page renders,
Then 4 metric tiles are displayed: Hot Opportunities, Buying Intelligence, Competitive Threats, Pipeline Urgency.

### AC-155: Partner Admin Main Page Tiles
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user is logged in as partner_admin,
When the Main page renders,
Then 4 aggregate tiles are displayed: # sub-orgs, # customer logins (24h), # actions taken (24h), # agent actions (24h).

### AC-156: Pipeline Health Score Formula
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given the Pipeline Health metric is calculated,
When the formula is applied,
Then the result equals: (0.3 * lead_volume_trend) + (0.25 * conversion_rate) + (0.25 * avg_response_time_score) + (0.2 * pipeline_stage_distribution_score).

### AC-157: Certified Metrics Registry
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user or agent queries GET /api/metrics/registry,
When the request is processed,
Then a role-filtered list of certified metrics is returned.

### AC-158: Metrics Accuracy Within 2%
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given any certified metric value,
When compared against ground truth data source,
Then the value is within 2% of ground truth.

### AC-159: Field Fill Rate Threshold
**Priority:** IMPORTANT
**Status:** UNTESTED

Given all certified metrics,
When field fill rates are checked,
Then every certified metric has >50% field fill rate.

### AC-160: Staff Tile Modal Drill-Down
**Priority:** IMPORTANT
**Status:** UNTESTED

Given a staff user views Main page metric tiles,
When the user clicks a tile,
Then a modal opens with a detailed breakdown per the metric's formula components.

### AC-161: Org Admin Minimum 10 Certified Metrics
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the org_admin metrics registry,
When the metric count is checked,
Then at least 10 certified metrics exist covering pipeline, team, and AI activity categories.

### AC-162: Staff Minimum 5 Certified Metrics
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the org_staff metrics registry,
When the metric count is checked,
Then at least 5 certified personal metrics exist.

### AC-163: Partner Admin Minimum 5 Aggregate Metrics
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the partner_admin metrics registry,
When the metric count is checked,
Then at least 5 certified aggregate metrics exist, with no individual PII exposed.

### AC-164: Agent Performance Metrics Auto-Update
**Priority:** IMPORTANT
**Status:** UNTESTED

Given a VAPI or Tavus webhook event is received,
When the webhook is processed,
Then the agent's performance_metrics JSONB field is automatically updated.

---

## 14. Notifications (AC-165 through AC-172)

### AC-165: In-App Notification List
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user clicks the notification bell,
When the notification list opens,
Then notifications display with read/unread status.

### AC-166: Hunch Notification
**Priority:** IMPORTANT
**Status:** UNTESTED

Given a new AI-generated hunch is created,
When the hunch is saved,
Then a visible notification appears for the relevant user(s).

### AC-167: Notification Settings CRUD
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user navigates to notification settings,
When the user toggles notification types on or off,
Then the preferences are saved and respected for future notifications.

### AC-168: Unread Count Polling
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user is logged in,
When 30 seconds elapse,
Then the notification unread count refreshes automatically via polling.

### AC-169: Email on VAPI Call Complete
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given a VAPI call completes (webhook received),
When the call-complete event processes,
Then an email notification is sent to the configured recipient. (This is a live production feature — must be verified at every transition.)

### AC-170: Mark All as Read
**Priority:** NICE-TO-HAVE
**Status:** UNTESTED

Given the user has multiple unread notifications,
When the user clicks "Mark All as Read" (PUT /api/notifications/read-all),
Then all notifications are marked as read and the unread count resets to zero.

### AC-171: Lead Assignment Notification
**Priority:** IMPORTANT
**Status:** UNTESTED

Given a lead is assigned to a staff member,
When the assignment is saved,
Then the assignee receives an in-app notification, SMS, and email.

### AC-172: Trigger Notification Delivery Timing
**Priority:** IMPORTANT
**Status:** UNTESTED

Given a trigger fires and generates a notification,
When the notification is dispatched,
Then it is delivered within 60 seconds of the trigger event.

---

## 15. Activity & Governance (AC-173 through AC-179)

### AC-173: AI Usage Event Logging
**Priority:** IMPORTANT
**Status:** UNTESTED

Given any AI interaction (chat, tool call, agent action),
When the interaction completes,
Then tokens consumed, tool calls made, and cost are logged as an event.

### AC-174: Activity Feed in Insights
**Priority:** IMPORTANT
**Status:** UNTESTED

Given the user navigates to Insights > Activity,
When the activity feed renders,
Then recent AI usage events display with action type, description, and timestamp.

### AC-175: Credit Balance Tracking
**Priority:** IMPORTANT
**Status:** UNTESTED

Given an AI-billable action occurs,
When the credit balance is queried,
Then the balance has been deducted by the correct amount and updates in real time.

### AC-176: Approval Workflow
**Priority:** NICE-TO-HAVE
**Status:** UNTESTED

Given a pending approval exists,
When the user approves or rejects via /api/approvals/:id/resolve with a comment,
Then the approval status updates and the comment is saved.

### AC-177: Artifacts Associated with Source Conversation
**Priority:** IMPORTANT
**Status:** UNTESTED

Given an artifact is created during a chat conversation,
When the artifact is viewed in Drive or chat history,
Then it is linked to the originating conversation.

### AC-178: Activity Feed CSV Export
**Priority:** NICE-TO-HAVE
**Status:** UNTESTED

Given the user is viewing the Activity feed,
When the user clicks CSV export,
Then a CSV file downloads with columns: timestamp, user, action, target, details.

### AC-179: Quality Gates Before Deployment
**Priority:** LAUNCH-CRITICAL
**Status:** UNTESTED

Given a build is being prepared for deployment,
When quality gate checks run (npm run check, npm run build, npx playwright test),
Then all checks pass with zero errors.

---

## Appendix A: Owner Decisions Required

The following items are flagged `[OWNER DECISION]` and cannot be fully tested until resolved.

| ID | Decision | Affected ACs | Reference |
|----|----------|-------------|-----------|
| D-1 | Canonical sidebar navigation order | AC-012 | DISAGREE-1, CONFLICT-R01 |
| D-2 | Automa on Agents page — listed or not | AC-067 | CONFLICT-R14 |
| D-3 | Lead follow-up trigger threshold (2h or 5 min) | AC-091 | AC-101 in reconciled |
| D-4 | Email in Hub Inbox — in scope or deferred | AC-108 | CONFLICT-R12, M-06 |
| D-5 | Dealer Pulse placement | — | CONFLICT-R15 |
| D-6 | Activity location (Insights sub-tab confirmed?) | AC-050 | CONFLICT-R06 |
| D-7 | Goals removal confirmed? | AC-049 | CONFLICT-R05 |

---

## Appendix B: Resolved Conflicts (Informational)

These conflicts were resolved during reconciliation. Documented here for traceability.

| ID | Conflict | Resolution |
|----|----------|-----------|
| R02 | Hub tab count (3 vs 4+) | 3 tabs: Calendar, Leads, Inbox (DESIGNER_UPDATE_SPEC authoritative) |
| R03 | VIN write-back scope | Lead creation only (2-step). No other writes. |
| R04 | Settings tile count (9 vs 10) | 9 tiles (API & Webhooks moved inside Tools & Integrations) |
| R07 | DealerBrain vs Automa naming | "Automa" in all user-facing surfaces. "DealerBrain" is internal only. |
| R08 | VIN integration model | Query-driven with caching. No bidirectional sync. |
| R10 | Hosted pages URL pattern | Known P0 one-line fix. AC tests the corrected route. |
| R11 | TextMagic credential storage | Per-org in database (textmagic_config table). Not in .env. |
| R13 | Report upload location | Settings > Data Management is primary path. |

---

## Appendix C: Missing AC Areas (Not Yet Covered)

These feature areas have specifications in source documents but no testable AC above. They are candidates for future AC additions.

| ID | Area | Risk | Notes |
|----|------|------|-------|
| M-01 | Billing page UI | HIGH | DESIGNER_UPDATE_SPEC Section 11 has design spec |
| M-02 | Profile page CRUD | LOW | Basic profile view/edit |
| M-04 | Tracking pixel / UTM capture | MEDIUM | SRS Addendum v3.2 |
| M-07 | Drive sharing flow (email/SMS details) | MEDIUM | Share action specifics |
| M-08 | Reporting PDF export | MEDIUM | Report generation and download |
| M-09 | VIN API graceful degradation (403) | HIGH | Fallback behavior on blocked endpoints |
| M-10 | Context Router UI in Settings | MEDIUM | 3 sections per owner spec |
| M-11 | SMS opt-out compliance (STOP keyword) | HIGH | SRS Addendum v3.2 lines 699-706 |
| M-12 | Data Health Dashboard | MEDIUM | Under Data Management tile |
| M-14 | Dealer Pulse feature | LOW | Pending owner decision (D-5) |
| M-15 | Tour system with RBAC | MEDIUM | First-login walkthrough |
| M-16 | Communications Agent default behavior | MEDIUM | Default config when absent |
| M-17 | After-hours voice routing | MEDIUM | Voice routing after hours (SMS covered in AC-106) |
| M-18 | Hunch lifecycle management details | LOW | Hunch state transitions |
| M-19 | Embed code copy action | LOW | Copy-to-clipboard UX |
| M-20 | Search / Command Palette (Cmd+K) | LOW | Pending scope decision |

---

## Appendix D: Priority Summary

| Priority | Count | Percentage |
|----------|-------|-----------|
| LAUNCH-CRITICAL | 72 | 40% |
| IMPORTANT | 95 | 53% |
| NICE-TO-HAVE | 12 | 7% |
| **Total** | **179** | **100%** |

**Note:** The 179 total ACs include the 151 reconciled outcomes plus additional granularity from the outline structure. Watch area items (billing, agent defaults, inbox handoff, super admin, context router) are incorporated where testable outcomes existed and noted in Appendix C where they remain uncovered.

---

*End of Acceptance Criteria document.*
