# Nexxus V2 -- Product Requirements Document

**Version:** Draft 1.0
**Date:** 2026-03-03
**Owner:** Duane Wells, Huminic
**Status:** DRAFT -- Pending Owner Review

---

## 1. Product Identity

### What Nexxus V2 Is

Nexxus V2 is an AI-powered engagement platform that sits alongside a dealership's existing CRM. It bridges the gap between incoming leads and human follow-up by deploying AI agents across voice, video, chat, and SMS channels.

The core problem Nexxus solves: **Dealerships don't lose because of lead volume -- they lose because of response gaps and execution failures.** A new internet lead comes in at 9:47 PM, nobody calls back until 10 AM the next day, and by then the customer has moved on. Nexxus fills that gap with AI agents that respond immediately, 24/7, across every channel.

Nexxus is a partner-enabled platform. Domain experts (called "partners") recruit dealerships into the platform, configure their AI agents, and manage their accounts. The first partner is Duran Cage, an automotive sales expert. The first vertical is automotive dealerships, but the platform is industry-agnostic by design -- automotive is the launch vertical, not the only one.

**Operated by:** Huminic (Duane Wells)
**Live at:** https://nexxusv2.huminicdev.com

### What Nexxus V2 Is NOT

- **Not a CRM.** Nexxus works alongside VIN Solutions (or any future CRM). It reads lead data from the CRM and writes notes back. It does not replace the CRM.
- **Not a marketing automation tool.** Nexxus does not create campaigns, send mass emails, or manage marketing funnels.
- **Not a content development platform.** Nexxus does not generate marketing content, social media posts, or advertising materials.
- **Not a lead generation tool.** Nexxus acts on leads that already exist in the CRM. It does not source new leads.

### Target Users

| User | Role | What They Do in Nexxus |
|------|------|----------------------|
| Platform operator | Super Admin | Manages the entire platform, provisions tools and partners, monitors system health |
| Domain expert / partner | Partner Admin | Manages multiple dealerships, views aggregate performance, configures AI agents |
| Dealership manager | Org Admin | Manages their store's settings, users, agents, and daily operations |
| Salesperson / BDC agent | Staff | Works leads, responds to messages, manages appointments, uses AI assistant |

### Value Proposition

AI agents handle routine engagement -- the initial response, the after-hours text, the appointment reminder, the follow-up call on a stale lead -- so that dealership staff can focus on what only humans can do: building relationships and closing deals.

For dealerships: faster response times, 24/7 coverage, consistent follow-up, fewer lost leads.

For partners: scalable management of multiple stores through a single platform with aggregate visibility.

### Naming Conventions

| Term | Meaning |
|------|---------|
| DealerBrain | The AI intelligence layer that powers all AI interactions across the platform |
| Automa | The user-facing name for the AI chat assistant (powered by DealerBrain) |
| Skills | Configurable capability overlays that shape how an agent behaves -- what it knows, what it can do, how it responds |
| Agents | AI personas that users create, configure with skills, and deploy across channels |
| Hub | The daily operations area (Calendar, Leads, Inbox) -- sometimes called "Work Center" in older documents |

**Branding rule:** No third-party vendor names appear in the user interface. Voice AI is labeled "Voice Agent," video AI is "Video Agent," and the chat assistant is "Automa" or "AI Assistant." Users never see the names VAPI, Tavus, TextMagic, or Claude.

---

## 2. Platform Capabilities

Each section below corresponds to a main navigation area in the Reference UI. "Above the line" describes what users see and interact with. "Below the line" describes what powers it, in business terms.

### 2.1 Main -- Command Center

**Above the line:**
- Dashboard metric tiles showing at-a-glance store health
- Automa Chat -- an always-available AI assistant accessible from every page via a floating chat overlay
- Automa understands the dealership's data: it can look up leads, check call history, review appointment schedules, query metrics, create tasks, and send messages -- all through natural conversation
- Suggested prompts help new users discover what Automa can do
- Conversation history and favorites for returning to past interactions

**Below the line:**
- DealerBrain connects to 24 different data and action tools, drawing from the CRM, call logs, appointment records, metrics, and more
- Responses stream in real-time as the AI thinks and acts
- The AI is goal-aware -- it knows what the store is trying to achieve and factors that into its responses
- The AI never fabricates information. When data is unavailable, it says so and explains why

**Dashboard tiles are role-specific:**

| Role | Tiles Shown |
|------|------------|
| Partner Admin | Number of sub-orgs, customer logins (24h), actions (24h), agent actions (24h) |
| Org Admin | Pipeline Health, Lead Source Performance, Lead Quality, Market Demand Insight (each scored 0-100) |
| Staff | Hot Opportunities, Buying Intelligence, Competitive Threat Alert, Pipeline Urgency (each scored 0-100) |

### 2.2 Insights -- Analytics & Intelligence

**Above the line:**
- **Dashboard gauges** -- DealerPulse health indicators showing store performance across multiple dimensions, using a three-zone alert system (Red / Yellow / Green)
- **Reports** -- Six priority reports, each answering a specific business question:
  - Deal Death Autopsy: Why are deals being lost?
  - Lead Source Quality: Which lead sources produce results?
  - Channel Performance: Which communication channels are most effective?
  - Pipeline Velocity: How fast are leads moving through the pipeline?
  - Active Lead Triage: Which leads need immediate attention?
  - Deal Status Snapshot: What does the current pipeline look like?
- **Metric Library** -- 34 defined metrics that users can browse, search, and add to their dashboards
- **Hunches** -- AI-generated insights that surface patterns humans might miss, each with a confidence score (e.g., "Leads from Source X close 40% faster when contacted within 2 hours")
- **Lead Feed** -- real-time stream of lead activity
- **Team Leaderboard** -- performance ranking across staff members

**Below the line:**
- DealerPulse collects health snapshots every 4 hours, building trend data over time
- Hunches are generated every 6 hours by an AI process that looks across multiple data dimensions
- All metrics are calculated from real data sources. Metrics that depend on data the platform cannot access (due to CRM limitations) are excluded entirely -- no placeholders, no estimates
- Data accuracy rule: a metric must have greater than 50% data fill rate and stay within 2% of ground truth to be shown. If it cannot be certified, it is not displayed.

### 2.3 Agents -- AI Workforce

**Above the line:**
- **Agent roster** -- a list of all AI agents configured for the organization
- **Chat interface** -- select any agent and chat with it directly, each agent responds according to its configured personality and skills
- **Agent creation wizard** with five steps: Basic Info, Channel Configuration (voice, video, chat, email, task), Skills, Triggers, Review
- **Favorites** -- bookmark frequently used agents for quick access
- **Agent info panel** -- view an agent's skills, stats, and recent activity

**Default agents provided out of the box:**
- Automa (system agent, always present, cannot be deleted)
- Sales Coach
- Message Crafter
- Voice agent (for phone interactions)

**Communications Agent:** A special agent type configured by the platform operator (Super Admin). Users cannot modify its core behavior, only its triggers and supplementary instructions. Two communications agents are provided out of the box.

**Below the line:**
- The V2 architecture uses a skills model: users create agents and add skills to them. This replaces the V1 approach of 27 pre-built agents. Skills are configurable overlays that define what an agent knows and can do.
- Each agent has a personality (instructions, response style) and channel assignment (voice, video, chat, email, or task)
- Agents deployed to external channels (voice calls, video, website widgets) are the same agents managed on this page -- there is one roster, not separate internal and external agent lists

### 2.4 Hub -- Daily Operations

The Hub has three tabs: **Calendar**, **Leads**, and **Inbox**.

#### Calendar

**Above the line:**
- View appointments across four time scales: year, month, week, day
- Create, edit, and reschedule appointments with drag-and-drop
- Appointment detail modal with status management
- Quick actions for common operations

**Below the line:**
- Appointments live in the Nexxus calendar, not in the CRM (the CRM does not have a calendar endpoint)
- Appointment reminders are sent via SMS and email at 24 hours and 2 hours before the appointment
- Google Calendar sync is available per user (Nexxus is the source of truth; Google Calendar is the sync target, not the other way around)
- Public appointment confirmation via secure link

#### Leads

**Above the line:**
- Lead list showing the active pipeline with status indicators
- Lead detail view with full history
- Quick actions: initiate call, send text, mark as contacted
- Status management and transitions

**Below the line:**
- Leads are imported from VIN Solutions through periodic polling
- The CRM is the authoritative source for lead data; Nexxus reads from it and writes notes back
- Records imported via bulk upload (Excel) are excluded from all standard lead queries -- they are kept separate to preserve data integrity
- Lead assignment is not part of the current requirements

#### Inbox

**Above the line:**
- Unified inbox merging SMS, widget chat, and email into a single view
- Channel filtering (view all, or filter by SMS / email / voicemail)
- Message thread display with full conversation history
- Reply and compose functionality with a rich-text editor
- Read/unread filtering

**Below the line:**
- When an external interaction happens (a customer chats with a widget, or an AI agent handles a call), that conversation can be continued internally by staff through the Inbox -- providing continuity between external AI interactions and human follow-up
- Dialer with keypad for outbound calls

### 2.5 Drive -- Document Management

**Above the line:**
- File browser with grid and list view toggle
- Folder navigation with breadcrumb trail (up to 10 levels deep)
- Upload, create, delete, and download files
- Templates for commonly used documents
- Storage usage display

**Below the line:**
- Permission enforcement (read, comment, edit) per file and folder
- File sharing across the organization

### 2.6 Widgets -- External Deployment

Widgets are the external-facing surfaces of Nexxus -- how AI agents reach customers outside the platform.

**Above the line:**
- **Six channel options** available through widgets:
  - Text Chat (website chat)
  - Voice Inbound (customer calls in)
  - Voice Outbound (AI calls customer)
  - Video Agent (face-to-face AI interaction)
  - Web Audio (browser-based voice)
  - Send a Text (SMS from website)
- **Three deployment modes:**
  - Hosted landing page (standalone page at a unique URL, e.g., `/w/serra-honda-video`)
  - Embedded widget (JavaScript snippet added to dealer's website)
  - Unified floating widget (small icon in the corner of any page, expands on click)
- Currently 5 deployed hosted page slugs across customer organizations

**Below the line:**
- Widgets are portals to agents -- each widget is connected to a specific AI agent from the Agents page
- Domain whitelisting ensures widgets only load on approved websites
- Rate limiting: 100 interactions per hour per visitor
- Widget bundle is lightweight (approximately 50 KB)
- Widget branding is per-organization (org logo + 2 accent colors), not platform-branded

### 2.7 Settings -- Configuration

**Above the line:**
Nine settings tiles, each visible based on the user's role:

| Tile | Description |
|------|-------------|
| User Management | Add, edit, deactivate users within the organization |
| Organization | Organization profile, branding (logo + colors), business hours |
| Tools & Integrations | Connect and configure external services (CRM, phone, email). Includes API & Webhook management. |
| Knowledge Base | Upload documents and data that AI agents can reference |
| AI Configuration | System prompt, agent behavior rules, skills management, emergency kill switch |
| Security & Privacy | Security settings and data privacy controls |
| Notifications | Configure notification preferences per channel (in-app, email, SMS) per event type |
| Data Management | Data import/export, bulk operations (Super Admin only) |
| Appearance | Theme customization |

**Below the line:**
- Role-based access controls which tiles each user can see (see Section 4 for the full matrix)
- AI Configuration has three sections: System Prompt, Agent Behavior, and Skills. Partner Admins get read-only access to the first two; full access is Super Admin only.
- Context Router configuration (under AI Configuration or Data Management): three sections for Memory Stores, Sync Data, and Upload Data Store + Web/3rd Party
- Org Creation Wizard (Super Admin only) for onboarding new dealerships
- Integration credentials are stored per organization, not at the platform level

### 2.8 Activity -- Audit Trail

**Above the line:**
- Activity feed showing all platform events
- Filters: All, User actions, Agent actions, System events
- Search functionality
- CSV export for compliance and reporting

**Below the line:**
- Logs all significant events across the platform: user logins, agent interactions, system operations, configuration changes
- Restricted to Org Admin and above (staff cannot see the Activity page)

---

## 3. External Integration Ecosystem

Nexxus connects to several external services to deliver its capabilities. None of these vendor names are visible to end users.

### VIN Solutions (CRM Data)

**Purpose:** VIN Solutions is the dealership's CRM -- the authoritative source for lead and customer data. Nexxus reads lead data from VIN Solutions and writes notes back (e.g., "AI agent called this lead at 9:47 PM, customer confirmed appointment").

**Data flow:**
- Nexxus polls VIN Solutions periodically to import new and updated leads
- A manual refresh button is also available for on-demand sync
- Nexxus can create contacts and leads in the CRM
- Lead creation in VIN Solutions is a two-step process (create contact, then create lead)

**Data truth hierarchy:**
1. VIN Solutions data (highest authority)
2. AI interaction records (voice/video call logs)
3. Nexxus internal data (appointments, tasks, agent configs)
4. Derived data (calculated metrics, scores, aggregations -- lowest authority)

**Known limitations:**
- 17 of 30 available endpoints are blocked (return 403 errors) -- these are CRM restrictions, not Nexxus limitations
- No appointment or calendar endpoint exists in the CRM API
- Nexxus can see the beginning (lead creation) and end (sold/lost status) of a deal, but not the middle (follow-up activity, deal economics, execution quality within the CRM)
- Many data fields are sparsely populated (selling price, down payment often blank)
- Minimum 250ms delay required between API calls (rate limit)

**What Nexxus CAN measure from CRM data:**
- AI agent performance
- Pipeline state and velocity
- Lead outcomes (sold, lost, active)
- Vehicle demand patterns
- Staff roster

**What Nexxus CANNOT measure (data not accessible):**
- Human execution quality within the CRM
- Deal economics (gross profit, trade values)
- Appointment show rates (no CRM appointment data)
- Physical inventory metrics
- Detailed CRM activity logs

### VAPI (Voice AI)

**Purpose:** Powers all voice interactions -- both inbound (customer calls the dealership) and outbound (AI calls the customer proactively).

**How it works:**
- Voice assistants are tagged with organization information so calls route to the correct store
- When a call ends, the system receives a report with call details, transcript, and duration
- Call costs are tracked at $0.25/minute (charged to the customer's organization)

**Current state:**
- 18 voice assistants configured on the account, 5 registered in Nexxus
- 5 named video personas deployed: Caroline, Magnolia, Georgia, Elizabeth, Savannah

### Tavus (Video AI)

**Purpose:** Powers video agent interactions -- customers can have face-to-face conversations with AI personas through widgets.

**How it works:**
- Video personas are configured per organization with unique appearances and personalities
- Sessions tracked with start/end events
- Video costs tracked at $0.32/minute (charged to the customer's organization)
- Secure callback verification ensures only legitimate session updates are processed

### TextMagic (SMS)

**Purpose:** Powers all SMS interactions -- outbound messages from AI agents and inbound messages from customers.

**How it works:**
- Each organization can have its own phone number for SMS
- Inbound messages route to the appropriate organization based on phone number
- AI-powered SMS responses (using DealerBrain) handle after-hours and automated conversations
- Conversation state tracking prevents conflicts: when a human takes over an SMS thread, the AI stops responding

**SMS conversation states:**
- AI Active -- AI is handling the conversation
- Human Active -- a staff member has taken over
- Dormant -- conversation has gone idle

**Current state:**
- SMS is currently outbound-only for most operations; full bi-directional SMS activates when each store gets its own dedicated number
- One shared phone number is currently assigned across 3 organizations (first match wins routing)
- SMS costs: $0.05/message (charged to customer's organization)

### Resend (Transactional Email)

**Purpose:** Delivers system emails -- welcome messages, password resets, appointment reminders, notification routing.

**How it works:**
- Email templates stored in the database per organization
- Used for transactional messages, not marketing campaigns
- IMAP/SMTP integration handles email sync for the Inbox

### Google Calendar

**Purpose:** Syncs Nexxus appointments to users' personal Google Calendars.

**How it works:**
- Per-user OAuth connection (each user connects their own Google account)
- One-way sync: Nexxus is the source of truth, Google Calendar is the display target
- Connect, disconnect, and toggle sync from Profile preferences

---

## 4. User Roles & Access

### Role Hierarchy

Nexxus uses a four-tier role system. Each tier inherits the permissions of the tier below it and adds more.

| Level | Role | Scope | Typical User |
|-------|------|-------|-------------|
| 1 | Super Admin | Entire platform, all organizations | Huminic (platform operator) |
| 2 | Partner Admin | Multiple organizations under their partnership | Duran Cage (domain expert / partner) |
| 3 | Org Admin | Single organization (one dealership) | Sales Manager, BDC Manager |
| 4 | Staff | Personal data within one organization | Salesperson, BDC Agent |

### Key Access Rules

- **Staff** cannot see Settings, Activity, or other users' lead data. They see only their own assignments and personal metrics.
- **Org Admin** sees all data within their organization. Can manage users, configure agents, view all leads.
- **Partner Admin** sees aggregate data across their organizations but **cannot see individual lead data or PII**. Has read-only access to AI Configuration.
- **Super Admin** has unrestricted access. All administrative endpoints are Super Admin only.

### Settings Access Matrix

| Settings Tile | Super Admin | Partner Admin | Org Admin | Staff |
|--------------|:-----------:|:------------:|:---------:|:-----:|
| User Management | Full | Full | Full | No access |
| Organization | Full | Full | Full | No access |
| Tools & Integrations | Full | Full | Full | No access |
| Knowledge Base | Full | Full | Full | No access |
| AI Configuration | Full | Read-only | No access | No access |
| Security & Privacy | Full | Full | No access | No access |
| Notifications | Full | Full | Full | No access |
| Data Management | Full | No access | No access | No access |
| Appearance | Full | Full | Full | No access |

### Multi-Organization Isolation

Every piece of data in Nexxus is tagged with an organization identifier. Data from one dealership is never visible to another dealership. This isolation is enforced at the database level, not just the application level -- even if the application has a bug, the database itself prevents cross-organization data access.

---

## 5. Business Rules & Constraints

### Data Integrity

- **Accuracy is non-negotiable.** A metric must meet certification standards (greater than 50% data fill rate, within 2% of ground truth, traceable to an accessible data source) before it is shown to users. Uncertifiable metrics are excluded entirely -- no placeholders, no approximations, no "coming soon" labels.
- **No source labels in the UI.** Users never see where a data point came from (CRM, voice system, local database). Data attribution is internal-only.
- **No placeholder UI.** If a feature or data point is not ready, the UI element is not shown. Empty states with fake data or "lorem ipsum" are prohibited.
- **Excel upload exclusion.** Records imported via bulk upload are excluded from all standard lead queries to preserve data integrity of CRM-sourced metrics.
- **Non-destructive operations.** Soft deletes are preferred over hard deletes. Audit logging for sensitive operations. No cascading deletes without explicit approval.

### Branding

- **No vendor names in the UI.** All third-party services are presented under Nexxus-branded labels (Voice Agent, Video Agent, AI Assistant, etc.).
- **Per-org widget branding.** Widgets display the organization's logo and colors, not Nexxus branding. Limited to logo + 2 accent colors.
- **White-label capability.** Organizations see their own branding throughout their Nexxus experience.

### Voice and Video Economics

| Channel | Rate Charged to Customer | Platform Cost | Margin |
|---------|------------------------|---------------|--------|
| Voice AI | $0.25 per minute | $0.15 per minute | 40% |
| Video AI | $0.32 per minute | $0.20 per minute | 37.5% |
| SMS | $0.05 per message | $0.02 per message | 60% |

- Credits are tracked per organization with service-specific quotas
- An 80% usage alert fires before an organization exhausts its allocation
- Billing UI exists in the design specification but is not yet customer-facing (backend credit tracking is operational)

### CRM Limitations

- VIN Solutions has no appointment endpoint -- appointments live in Nexxus only (with Google Calendar sync as an option)
- 17 of 30 CRM endpoints are inaccessible (403 blocked)
- Metrics that require blocked data are excluded, not estimated
- Nexxus does not attempt to replace or duplicate CRM functionality -- it complements it

### Communication Rules

- Most customer-facing actions route through an AI agent rather than happening as raw system operations
- The Communications Agent is locked down: users can modify its triggers and add supplementary instructions, but cannot change its core behavior
- Scheduling (appointments) is a Hub-level action that both users and agents can perform
- AI agents never fabricate information -- when asked about data that is unavailable or blocked, they explain the limitation

### Notification System

- Three notification channels: in-app (bell icon badge), email, and SMS
- Users configure notification preferences per channel, per event type
- Idempotency controls prevent duplicate notifications for the same event

### Trigger System

- Seven event types: new lead, lead status change, missed call, appointment scheduled, inbound message, hot lead, custom
- Five action types: outbound call, send SMS, send email, create task, webhook
- Triggers respect business hours (configurable per organization)
- Deduplication prevents the same action from firing twice for the same event
- Rate limiting prevents runaway trigger chains

---

## 6. Non-Goals (Explicitly Out of Scope)

The following are intentionally **not** part of Nexxus V2:

1. **Replacing VIN Solutions or any CRM.** Nexxus is a companion platform. It reads from and writes to the CRM but does not attempt to replicate CRM functionality.

2. **Standalone CRM features.** Lead assignment, deal desk, desking tools, F&I workflows, and inventory management are CRM responsibilities, not Nexxus responsibilities.

3. **Mobile native application.** Nexxus is a web application with responsive design. There is no iOS or Android native app planned for the current launch.

4. **Marketing automation.** Mass email campaigns, drip sequences, social media management, and advertising tools are out of scope.

5. **Content generation.** Marketing copy, social media posts, listing descriptions, and advertising creative are not Nexxus features.

6. **Lead generation.** Nexxus acts on leads that already exist. It does not source leads from third-party providers, run advertising, or operate lead capture forms (beyond its widget system for existing website visitors).

7. **Inventory management.** Physical inventory tracking, pricing tools, and vehicle merchandising are CRM/DMS functions.

8. **Multi-language support.** The current launch is English-only.

9. **Self-service billing portal.** While credit tracking and usage monitoring exist on the backend, a customer-facing billing portal with invoice history and payment management is deferred beyond the current launch scope.

---

## Appendix A: Current Customer Base

| Customer | Organizations | Deployed |
|----------|--------------|----------|
| Serra Automotive | Serra Honda (21043), Serra Nissan (21044), Tony Serra Ford (21047) | 2026-01-16 |
| Hyundai of Columbia | Hyundai of Columbia (6374), Ford of Columbia (3027) | 2026-01-16 |

Five video agent personas are deployed: Caroline, Magnolia, Georgia, Elizabeth, Savannah.

Twelve active AI agents in production: 5 voice, 2 chat, 4 task, 0 video (video agent activation is an operational gap).

---

## Appendix B: Onboarding Requirements

Each new customer organization requires 11 configuration items and 5 customer decisions before go-live. These include CRM credentials, phone number assignment, business hours, widget deployment preferences, and agent configuration choices.

---

## Appendix C: Unresolved Items

The following items were identified during analysis but require owner decisions before they can be finalized in this document:

| # | Item | Question |
|---|------|----------|
| 1 | Subscription pricing | Per-usage rates are documented ($0.25/min voice, etc.) but no monthly subscription or per-seat pricing model has been defined. What is the subscription structure? |
| 2 | Skills catalog | The skills architecture is defined (users create agents and add skills), but the complete catalog of available skills and what each one does has not been documented. Is "64+ skill templates" an actual specification or aspirational? |
| 3 | Partner credit pool | How do credits work at the partner level? Does a partner buy a pool and distribute to their orgs? |
| 4 | Inbox handoff mechanics | When an external AI conversation transitions to the staff Inbox, what triggers the handoff? Is it automatic or manual? |
| 5 | Super Admin capabilities | No single document lists all Super Admin capabilities comprehensively. |
| 6 | Video agent configuration | Tavus persona setup, video agent deployment details, and the operational gap (0 active video agents despite 5 personas) need clarification. |
| 7 | Aspirational vs. current architecture | Some older documents describe a multi-layer AI architecture that does not reflect the current implementation. Should this document describe the vision, the reality, or both? |

---

*This document describes what Nexxus V2 is and what it does in business terms. For system behavior details, see SRS.md. For architecture specifics, see SPEC.md. For testable verification criteria, see ACCEPTANCE_CRITERIA.md. For current work priorities, see PLAN.md.*
