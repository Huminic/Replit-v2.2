# Nexxus V2 -- Architecture Specification

**Purpose:** Technical reference for developers and agents writing or modifying code.
**Audience:** Developer / agent navigating the codebase.
**Scope:** Structure and location of every service, route, table, config, and build artifact. No behavioral descriptions (see SRS.md for system behavior).

---

## 1. Technology Stack

### 1.1 Frontend

| Technology | Version / Detail | Package |
|-----------|-----------------|---------|
| Build tool | Vite 7.3.0 | `vite` |
| Framework | React 18.3.1 | `react`, `react-dom` |
| Language | TypeScript 5.6.3 (strict mode) | `typescript` |
| Routing | Wouter 3.3.5 | `wouter` |
| Server state | TanStack Query 5.60.5 | `@tanstack/react-query` |
| Client state | React Context API (3 providers: Auth, App, Theme) | built-in |
| UI library | shadcn/ui (48 Radix-based primitives) | `@radix-ui/*` (28 packages) |
| Styling | Tailwind CSS v4 (614 lines custom CSS in `index.css`) | `tailwindcss`, `@tailwindcss/vite` |
| Icons | lucide-react 0.453.0 (60+ unique icons) | `lucide-react` |
| Calendar | FullCalendar 6.1.20 (core, daygrid, timegrid, list, interaction) | `@fullcalendar/*` |
| Rich text editor | Tiptap 3.18.0 (starter-kit, link, placeholder) | `@tiptap/*` |
| Charts | Recharts 2.15.2 (via shadcn chart component) | `recharts` |
| Onboarding | driver.js 1.4.0 (9-step product tour) | `driver.js` |
| Date utility | date-fns 3.6.0 | `date-fns` |
| HTTP client | Native fetch wrapped in `client/src/lib/api.ts` | built-in |
| Forms | React Hook Form 7.55.0 + Zod 3.24.2 | `react-hook-form`, `zod` |
| Animations | Framer Motion 11.13.1 | `framer-motion` |
| Resizable panels | react-resizable-panels 2.1.7 | `react-resizable-panels` |
| Command palette | cmdk 1.1.1 | `cmdk` |
| Drawer | Vaul 1.1.2 | `vaul` |
| Carousel | Embla Carousel React 8.6.0 | `embla-carousel-react` |
| Fonts | Inter (sans), Merriweather (serif), Fira Code (mono) | CSS imports |

**NOTE:** `ARCHITECTURE_VISUAL_MAP.md` claims "Next.js 14 App Router" and "Zustand." Both are wrong. The actual codebase uses Vite + React 18 + Wouter + React Context.

### 1.2 Backend

| Technology | Version / Detail | Package |
|-----------|-----------------|---------|
| Runtime | Node.js v20.19.5 | `@types/node: 20.19.27` |
| Framework | Express.js 5.0.1 (pre-release) | `express` |
| Language | TypeScript 5.6.3 (strict mode) | `typescript` |
| TypeScript execution | tsx 4.20.5 | `tsx` |
| Database driver | pg 8.16.3 (Pool, max 10 connections) | `pg` |
| ORM (schema only) | Drizzle ORM 0.39.3 + Drizzle Zod 0.7.0 | `drizzle-orm`, `drizzle-zod` |
| Migration tooling | Drizzle Kit 0.31.8 | `drizzle-kit` |
| Process manager | PM2 6.0.13 (no ecosystem config file) | system-level |
| AI SDK | Anthropic Claude API 0.72.1 | `@anthropic-ai/sdk` |
| VAPI SDK | @vapi-ai/server-sdk 0.11.0 | `@vapi-ai/server-sdk` |
| Email (transactional) | Resend 6.9.1 | `resend` |
| Email (IMAP) | ImapFlow 1.2.8 | `imapflow` |
| Email (SMTP) | Nodemailer 7.0.13 | `nodemailer` |
| File upload | Multer 2.0.2 (in-memory, max 50MB) | `multer` |
| JWT | jsonwebtoken 9.0.3 | `jsonwebtoken` |
| Password hashing | bcrypt 6.0.0 (10 salt rounds) | `bcrypt` |
| Encryption | AES-256-GCM via Node.js built-in `crypto` | built-in |
| Security headers | Helmet 8.1.0 (CSP disabled for SPA) | `helmet` |
| Rate limiting | express-rate-limit 8.2.1 | `express-rate-limit` |
| PDF parsing | pdf-parse 1.1.1 | `pdf-parse` |
| PDF generation | Puppeteer 24.37.2 | `puppeteer` |
| Spreadsheet | xlsx 0.18.5 (2 known CVEs, no fix available) | `xlsx` |
| Validation | Zod 3.24.2 | `zod` |
| WebSocket | Socket.io 4.8.3 (installed, NOT actively used) | `socket.io` |
| Build tool (server) | esbuild 0.25.0 | `esbuild` |
| Session store | connect-pg-simple 10.0.0 + memorystore 1.6.7 | `connect-pg-simple`, `memorystore` |

### 1.3 External Services

| Service | Auth Method | Purpose |
|---------|------------|---------|
| VIN Solutions | OAuth2 Client Credentials (60-min tokens) | CRM: leads, contacts, dealers, users |
| VAPI | Shared secret (timing-safe compare, optional) | Voice AI call data, transcripts, webhooks |
| Tavus | HMAC-SHA256 + API key (5-min timestamp tolerance) | Video AI sessions, persona management |
| Resend | API key (SDK) | Transactional email (notifications, confirmations) |
| TextMagic | Username + API key per org (REST v2) | SMS send/receive |
| Anthropic Claude | API key (SDK) | AI chat, tool calling, content generation, extraction |
| Google Calendar | OAuth2 (Authorization Code flow, per-user) | Calendar sync, appointment push |

### 1.4 Database

| Aspect | Detail |
|--------|--------|
| Provider | Supabase (PostgreSQL) |
| Hosting | AWS us-west-2 |
| Connection | `pg.Pool`, max 10 connections, prefers direct URL (port 5432) over pgbouncer (port 6543) |
| Tables | 53 |
| Migrations | 40 SQL files (001-040, 011 missing, two files share `004` prefix) |
| RLS policies | ~100 across all tables |
| Indexes | ~160 |
| Foreign keys | ~80 |
| JSONB columns | 58 (no DB-level schema validation) |
| Functions | 2 (`update_updated_at_column`, `create_default_notification_settings`) |
| Triggers | 12+ (4 from migration 003, plus notification settings trigger, plus inconsistent `updated_at` coverage) |

### 1.5 Widget (Embeddable)

| Aspect | Detail |
|--------|--------|
| Framework | Preact 10.28.3 (smaller bundle than React) |
| Build | Vite (separate build target at `widget/vite.config.ts`) |
| Tracking pixel | IIFE bundle via esbuild, minified |
| Output | `dist/public/widget/` |

### 1.6 Testing

| Aspect | Detail |
|--------|--------|
| E2E framework | Playwright 1.58.1 |
| E2E spec files | 50 across `tests/e2e/` |
| Browser | Chromium, Desktop Chrome, 1280x720 |
| Base URL | `https://nexxusv2.huminicdev.com` (tests against production) |
| Unit tests | None (no Jest configuration) |
| Component tests | None (no React Testing Library) |
| ESLint | NOT configured |
| Prettier | NOT configured |
| CI/CD | NOT configured |

### 1.7 npm Dependencies

| Category | Count |
|----------|-------|
| Production | 91 |
| Development | 31 |
| Total | 122 |
| Known vulnerabilities | 7 (0 critical, 4 high, 2 moderate, 1 low) |

HIGH: `xlsx` (2 CVEs, no fix), `minimatch`, `glob`, `sucrase`. MODERATE: `lodash` (prototype pollution), `markdown-it` (ReDoS).

---

## 2. Project Structure

```
nexxus-v2/
  client/                              # Vite + React frontend (SPA)
    src/
      components/                      # ~107 components (59 custom + 48 shadcn/ui)
        admin/              (2 files)  # User/org management dialogs
        auth/               (1 file)   # ProtectedRoute
        calendar/           (2 files)  # FullCalendar integration
        chat/               (6 files)  # Chat panel, streaming, charts
        communication/      (3 files)  # Email inbox/compose
        help/                          # Help components
        hunches/                       # Hunch display
        inbox/              (1 file)   # Messaging panel
        insights/           (5 files)  # Dashboard cards
        layout/             (8 files)  # AppLayout, TopBar, Sidebar, SubMenu, RightPane, FavoritesBar
        modals/             (8+ files) # Transcript, lead detail, table modals
        notifications/      (3 files)  # Bell, settings, barrel export
        onboarding/         (1 file)   # Product tour (driver.js)
        reports/            (8 files)  # Report catalog, viewer, charts
        settings/           (8 files)  # Tab components
        sms/                (1 file)   # SMS compose dialog
        ui/                 (48 files) # shadcn/ui Radix-based primitives
      contexts/             (3 files)  # AuthContext, AppContext, ThemeContext
      hooks/                (36 files) # TanStack Query hooks + utility hooks
      lib/                  (3 files)  # api.ts, queryClient.ts, utils.ts
      mocks/                (9 files)  # Mock data modules
      pages/                (20 files) # Page components
        hosted/             (4 files)  # HostedPage, HostedChat, HostedVideo, HostedCallback
      App.tsx                          # Route definitions (Wouter Switch)
      index.css                        # 614 lines custom Tailwind CSS
      main.tsx                         # React entry point
  server/                              # Express.js API
    auth/                              # JWT + auth middleware
      jwt.ts                           # Token signing, verification, expiry config
      middleware.ts                    # authenticate middleware, attaches req.user
    db/                                # Database utilities
      SecureQueryBuilder.ts            # RLS context setter (KNOWN BUG: sets wrong variable name)
      index.ts                         # Barrel export
      __tests__/                       # SecureQueryBuilder tests
    db.ts                              # pg.Pool configuration (13,619 bytes)
    index.ts                           # Main entry point: Express app, HTTP server, Helmet, body parsers
    jobs/                              # 10 scheduled background jobs
      appointmentReminderJob.ts        # 5-min interval: check upcoming appointments, send reminders
      dealerPulseJob.ts                # 4-hr interval: collect health snapshots
      emailSyncJob.ts                  # 5-min interval: IMAP sync (up to 50 integrations/run)
      hunchGenerationJob.ts            # 6-hr interval: AI hunch generation
      idleLeadChecker.ts               # Trigger re-evaluation for idle leads
      invoiceGenerator.ts              # Invoice generation
      syncQueueWorker.ts               # 1-min outbound, 4-hr inbound: VIN sync queue processing
      triggerReevalJob.ts              # 5-min interval: trigger rule re-evaluation
      vinLeadPollingJob.ts             # 60-min interval: poll VIN for new leads
      vinTokenRefreshJob.ts            # 30-min interval: refresh VIN OAuth tokens
    middleware/                        # Express middleware
      enforceOrganizationContext.ts    # Creates SecureQueryBuilder with RLS context from JWT
      validateResourceOwnership.ts     # Validates resource belongs to requesting org
      index.ts                         # Barrel export
    routes/                            # 36 route files
    routes.ts                          # Master route registry (imports and mounts all route modules)
    scripts/                           # Server scripts (currently empty)
    services/                          # 37 top-level service files + 5 subdirectories
      contextRouter/                   # Unified data query orchestration
        ContextRouterService.ts        # VIN API primary, local DB fallback
        SourceSelector.ts              # Data source priority resolver
        CacheManager.ts                # TTL-based cache (VIN 5 min, reports 1 hr)
        index.ts
      insights/                        # Analytics services
        DashboardAnalyticsService.ts   # Dashboard data aggregation (65,155 bytes -- large)
        VoiceInsightService.ts         # Voice call analytics
        VideoInsightService.ts         # Video session analytics
        LeadInsightService.ts          # Lead pipeline analytics
        index.ts
      leads/                           # Lead management
        LeadCreationService.ts         # VIN 2-step lead creation
        LeadExtractionService.ts       # AI extraction from transcripts
        index.ts
      notifications/                   # Email dispatch
        notificationEmailService.ts    # Resend email dispatch for call events
      sync/                            # VIN bidirectional sync
        SyncCoordinator.ts             # sync_queue processing
        LeadMapper.ts                  # VIN-to-local lead field mapping
        index.ts
    static.ts                          # Serves dist/public/ in production
    storage.ts                         # Storage interface (in-memory implementation)
    utils/                             # Utility modules
      encryption.ts                    # AES-256-GCM encrypt/decrypt
      requireEnv.ts                    # Environment variable validation
    vite.ts                            # Vite dev server middleware for HMR
    webhooks/                          # Webhook handlers
      vapi.ts                          # VAPI webhook (29,621 bytes)
      tavus.ts                         # Tavus webhook with HMAC verification
      index.ts                         # Barrel export
      utils/
        signatureVerifier.ts           # HMAC-SHA256 signature verification
    websocket/                         # WebSocket (installed, not actively used)
      WebSocketServer.ts               # Socket.io server
      index.ts
  shared/
    schema.ts                          # Shared types: Drizzle users table + Zod schema (18 lines)
  database/
    migrations/                        # 40 SQL files (001-040, 011 missing)
      down/                            # Rollback migrations
    seed.sql                           # Development seed data
  tests/
    e2e/                               # 50 Playwright spec files
      helpers/                         # global-setup.ts, test-utils.ts
  widget/                              # Preact embeddable widget (separate Vite build)
    src/
    vite.config.ts
    tsconfig.json
    postcss.config.js
  docs/                                # Documentation (40+ files)
    audit/                             # 5 forensic audit reports
    evidence/                          # Certification evidence
    reference/                         # Production deployment docs
    archive/                           # Pre-stabilization archives
  dist/                                # Build output (not in git)
    public/                            # Client SPA
      widget/                          # Embeddable widget + tracking pixel
    index.cjs                          # Server bundle (CJS)
  uploads/                             # User file uploads (not in git)
  script/
    build.ts                           # Build orchestrator
  .env                                 # 33 environment variables (not in git, no .env.example)
  .agent_docs/                         # Enforcer workspace
  .claude/agents/
    enforcer.md                        # Only agent definition file
  deploy.sh                            # Deploy script (master branch guard)
  playwright.config.ts                 # E2E test configuration
  package.json                         # Dependencies and scripts
  tsconfig.json                        # TypeScript config (strict mode, noEmit)
  vite.config.ts                       # Client Vite build configuration
  tailwind.config.ts                   # Tailwind CSS configuration
  postcss.config.js                    # PostCSS configuration
  components.json                      # shadcn/ui component configuration
```

### 2.1 Key Configuration Files

| File | Purpose |
|------|---------|
| `package.json` | Dependencies, npm scripts, module type (`"type": "module"`) |
| `tsconfig.json` | TypeScript strict mode, `noEmit` (type checking only) |
| `vite.config.ts` | Client Vite build configuration |
| `widget/vite.config.ts` | Widget Preact build configuration |
| `tailwind.config.ts` | Tailwind CSS configuration |
| `postcss.config.js` | PostCSS plugins |
| `components.json` | shadcn/ui component registry |
| `playwright.config.ts` | E2E test config (Chromium, 1280x720, base URL) |
| `.env` | 33 environment variables (not in git) |

### 2.2 Build Output

| Output | Location | Tool |
|--------|----------|------|
| Client SPA | `dist/public/` | Vite |
| Widget bundle | `dist/public/widget/` | Vite (Preact) |
| Tracking pixel | `dist/public/widget/nexxus-pixel.js` | esbuild (IIFE, minified) |
| Server bundle | `dist/index.cjs` | esbuild (CJS, minified) |

### 2.3 npm Scripts

| Script | Command | Purpose |
|--------|---------|---------|
| `dev` | `NODE_ENV=development tsx server/index.ts` | Development server with HMR |
| `build` | `tsx script/build.ts` | Full build (client + widget + pixel + server) |
| `start` | `NODE_ENV=production node dist/index.cjs` | Production server |
| `check` | `tsc` | TypeScript type checking (no emit) |
| `db:push` | `drizzle-kit push` | Push schema to database |
| `build:widget` | `cd widget && npx vite build` | Widget-only build |
| `test:env` | `npx tsx tests/env-check.ts` | Environment variable validation |
| `test:accuracy` | `npx tsx tests/data-accuracy.ts` | Data accuracy checks |
| `test:smoke` | `npx tsx tests/dealerbrain-smoke.ts` | DealerBrain smoke test |
| `test:quality` | `check && build && test:env && test:accuracy` | Full quality gate |

Missing scripts: no `lint`, `format`, `test` (Playwright requires `npx playwright test`), no `test:unit`.

---

## 3. Frontend Architecture

### 3.1 Route Registration

Routes are defined in `client/src/App.tsx` using Wouter's `<Switch>` and `<Route>` components.

**Public Routes (no authentication):**

| Route | Component | File |
|-------|-----------|------|
| `/login` | LoginPage | `pages/login.tsx` |
| `/forgot-password` | ForgotPasswordPage | `pages/forgot-password.tsx` |
| `/reset-password` | ResetPasswordPage | `pages/reset-password.tsx` |
| `/w/:slug` | HostedPage | `pages/hosted/HostedPage.tsx` |
| `/p/:slug` | HostedPagePublic | `pages/hosted-page-public.tsx` |
| `/embed` | EmbedShowcasePage | `pages/embed-showcase.tsx` |

**Protected Routes (wrapped in `<ProtectedRoute>` + `<AppLayout>`):**

| Route | Component | File |
|-------|-----------|------|
| `/` | MainPage | `pages/main.tsx` |
| `/agents` | AgentsPage | `pages/agents.tsx` |
| `/agents/create` | AgentCreatePage | `pages/agents-create.tsx` |
| `/agents/:id/edit` | AgentEditPage | `pages/agents-edit.tsx` |
| `/drive` | DrivePage | `pages/drive.tsx` |
| `/insights` | InsightsPage | `pages/insights.tsx` |
| `/credits` | CreditsPage | `pages/credits.tsx` |
| `/billing` | BillingManagementPage | `pages/billing-management.tsx` |
| `/work-center` | WorkCenterPage | `pages/work-center.tsx` |
| `/activity` | ActivityPage | `pages/activity.tsx` |
| `/notifications` | NotificationsPage | `pages/notifications.tsx` |
| `/settings/system` | SettingsPage | `pages/settings.tsx` |
| `/profile` | ProfilePage | `pages/profile.tsx` |
| `/profile/preferences` | ProfilePage | `pages/profile.tsx` |
| `/profile/billing` | ProfilePage | `pages/profile.tsx` |
| `*` (catch-all) | NotFound | `pages/not-found.tsx` |

Route protection: `ProtectedRoute` wraps `AppLayout` wrapping page component. No route-level RBAC; role restrictions are applied at component/tab level.

### 3.2 Component Hierarchy

```
App
  QueryClientProvider
    TooltipProvider
      ThemeProvider
        AuthProvider
          AppProvider
            Toaster
            Router (Switch)
              ProtectedRoute
                AppLayout
                  TopBar           (h-14: logo, org switcher, notifications, theme toggle)
                  Sidebar          (w-16 desktop, collapsible to w-10)
                  MobileSidebar    (Sheet-based nav with labels, <1024px)
                  SubMenuManager   (w-64 contextual navigation panel)
                  [Page Component] (center pane, flexible width)
                  RightPane        (w-80 quick-chat, dual mode: inline or Sheet)
                  FavoritesBar     (bookmark bar with star toggle)
            SessionTimeoutDialog
            ProductTour
```

### 3.3 Layout Grid

```css
grid-template-columns: [sidebar] 64px [left-pane] 240px [center-pane] 1fr [right-pane] 320px;
height: 100vh;
```

| Pane | Width | Purpose |
|------|-------|---------|
| Vertical Sidebar | 64px fixed (collapsible to 40px) | Main navigation icons |
| Left Pane / SubMenu | 240-400px resizable (w-64 default) | Contextual popout menus |
| Center Pane | Flexible, min 600px | Primary content area |
| Right Pane | 320-500px resizable (w-80 default) | Automa chat or contextual tools |

**ViewConfig system:** AppLayout supports view modes: `chat-only`, `data-display`, `sub-menu`, `heavy-chat`.

**Responsive breakpoints (from code audit):**
- Mobile (<1024px / `lg` breakpoint): Sheet-based sidebar, bottom navigation
- Desktop (>=1024px): Icon sidebar w-16
- Wide desktop (1280px+): Optional right pane w-80

### 3.4 State Management

**Dual-layer architecture:**

1. **Server state:** TanStack Query -- 38 `useQuery` calls, 34 `useMutation` calls across 36 custom hooks
2. **Client state:** 3 React Context providers

**Context Providers:**

| Context | File | Responsibilities |
|---------|------|-----------------|
| AuthContext | `contexts/AuthContext.tsx` | JWT login/logout/refresh, token storage (localStorage), user state, org switching, auto-refresh timer (60s, refreshes < 5 min to expiry) |
| AppContext | `contexts/AppContext.tsx` | Derives currentUser/currentOrganization, sidebar/panel states, favorites |
| ThemeContext | `contexts/ThemeContext.tsx` | Light/dark toggle, localStorage persistence (`nexxus:theme`), system preference detection |

**TanStack Query defaults (configured in `lib/queryClient.ts`):**
- `staleTime: Infinity` (data never auto-stales)
- `refetchOnWindowFocus: false`
- `retry: false`
- Cache invalidation on org switch (invalidates ALL queries)

### 3.5 Custom Hooks Inventory

All hooks are in `client/src/hooks/`. Each wraps TanStack Query for a specific domain.

| Hook File | Domain |
|-----------|--------|
| `useActivity.ts` | Activity feed + AI usage events |
| `useAdmin.ts` | Super Admin user/org management |
| `useAgents.ts` | Agent CRUD + stats |
| `useAiConfig.ts` | AI configuration settings |
| `useAppearanceSettings.ts` | Appearance/theme settings |
| `useAppointments.ts` | Appointment CRUD + calendar |
| `useApprovals.ts` | Approval workflow |
| `useBilling.ts` | Billing management |
| `useConversations.ts` | DealerBrain chat conversations |
| `useCredits.ts` | Credit balance/usage |
| `useDashboardTiles.ts` | Dashboard tile data |
| `useDealerBrainConfig.ts` | DealerBrain system config |
| `useDealerPulse.ts` | Dealer pulse health scores |
| `useDrive.ts` | File/folder management |
| `useEmail.ts` | Email inbox operations |
| `useFirstLogin.ts` | First login welcome flow |
| `useGoals.ts` | Goal tracking |
| `useGoogleCalendar.ts` | Google Calendar OAuth + sync |
| `useHunches.ts` | AI-generated hunches |
| `useInbox.ts` | Unified inbox messaging |
| `useInsights.ts` | Dashboard cards + analytics |
| `useLeads.ts` | Lead list + operations |
| `useMetrics.ts` | Certified metrics registry |
| `useNotificationPrefs.ts` | Notification preferences |
| `useNotifications.ts` | Notification feed + settings |
| `useOrganizationSettings.ts` | Organization settings |
| `useProfile.ts` | User profile editing |
| `useReports.ts` | Report data |
| `useSessionTimeout.ts` | Session timeout detection |
| `useSkills.ts` | Skills catalog |
| `useStreamingMessage.ts` | SSE streaming for AI chat |
| `useTasks.ts` | Task management |
| `useTracking.ts` | Tracking pixel events |
| `use-mobile.tsx` | Mobile breakpoint detection |
| `use-toast.ts` | Toast notification utility |

### 3.6 API Client Layer

| File | Purpose |
|------|---------|
| `client/src/lib/api.ts` | Authenticated fetch wrapper: `fetchApi`, `apiGet`, `apiPost`, `apiPut`, `apiPatch`, `apiDelete`. Reads JWT from localStorage. |
| `client/src/lib/queryClient.ts` | TanStack Query client singleton, `getQueryFn` helper, `apiRequest` utility. |
| `client/src/lib/utils.ts` | `cn()` utility (clsx + tailwind-merge). |

### 3.7 SSE Streaming Protocol

| Aspect | Detail |
|--------|--------|
| Endpoint | `POST /api/conversations/:id/stream` |
| Auth | `Authorization: Bearer {token}` header |
| Body | `{ content: string }` |
| Event types | `thinking`, `tool_start`, `tool_end`, `token`, `done`, `error` |
| Client hook | `useStreamingMessage.ts` |
| Widget SSE | `POST /api/widgets/public/chat/stream` (public, rate-limited) |

### 3.8 Theme Contract

| Aspect | Implementation |
|--------|---------------|
| Strategy | CSS class (`dark` on `<html>` element) |
| Toggle | ThemeContext reads/writes `nexxus:theme` in localStorage |
| System preference | Detected via `prefers-color-scheme` media query |
| Variables | CSS custom properties in `index.css` (614 lines) |

### 3.9 localStorage Keys

| Key | Purpose |
|-----|---------|
| `nexxus_access_token` | JWT access token |
| `nexxus_refresh_token` | JWT refresh token |
| `nexxus_token_expiry` | Token expiry timestamp |
| `nexxus_accessible_orgs` | Partner Admin org list |
| `nexxus:theme` | Light/dark theme preference |
| `nexxus_welcome_shown` | Welcome modal state |
| `nexxus_hide_welcome` | Welcome modal suppression |

---

## 4. Backend Architecture

### 4.1 Server Entry Points

| File | Purpose |
|------|---------|
| `server/index.ts` | Main entry point. Express app, HTTP server, Helmet, body parsers (`express.json` with rawBody capture, `express.urlencoded`), global error handlers, API logging. PM2 runs compiled `dist/index.cjs`. |
| `server/routes.ts` | Master route registry. Imports and mounts 38 route modules + webhook routers + background jobs. Registration order matters for Express path matching. |
| `server/db.ts` | PostgreSQL pool configuration (`pg.Pool`, max 10 connections). |
| `server/storage.ts` | Storage interface and in-memory implementation. |
| `server/static.ts` | Serves `dist/public/` in production. Fallback 503 if build missing. |
| `server/vite.ts` | Vite dev server middleware for HMR in development. |

### 4.2 Middleware Chain

Applied in order as defined in `server/index.ts` and `server/routes.ts`:

| Order | Middleware | Location | Purpose |
|-------|-----------|----------|---------|
| 1 | Helmet | `server/index.ts` | Security headers (CSP disabled for SPA compatibility) |
| 2 | `express.json` | `server/index.ts` | JSON body parser with rawBody capture |
| 3 | `express.urlencoded` | `server/index.ts` | URL-encoded body parser |
| 4 | API Logging | `server/index.ts` | Request/response logging; redacts fields matching `/token\|secret\|password/i` |
| 5 | `authenticate` | `server/auth/middleware.ts` | JWT validation, attaches `req.user` and `req.rlsVariables` |
| 6 | `enforceOrganizationContext` | `server/middleware/enforceOrganizationContext.ts` | Creates SecureQueryBuilder with RLS context from JWT |
| 7 | `validateResourceOwnership` | `server/middleware/validateResourceOwnership.ts` | Validates resource belongs to requesting org |

**Role-level middleware functions (applied per-route, not globally):**

| Function | Requirement |
|----------|-------------|
| `requireSuperAdmin` | `role_level === 1` |
| `requirePartnerAdminOrHigher` | `role_level <= 2` |
| `requireOrgAdminOrHigher` | `role_level <= 3` |
| `requireRoleLevel(minLevel)` | `role_level <= minLevel` |

### 4.3 Route Registration Order

Defined in `server/routes.ts`. Registration order matters for Express path matching (first match wins).

| # | Mount Point | Route File | Auth Level |
|---|-------------|-----------|------------|
| 1 | `/api/webhooks/vapi` | `webhooks/vapi.ts` | Public (optional shared secret) |
| 2 | `/api/webhooks/tavus` | `webhooks/tavus.ts` | Public (HMAC verified) |
| 3 | `/api/auth` | `routes/auth.ts` | Mixed (public + JWT) |
| 4 | `/api/vin` | `routes/vin.ts` | Mixed (Any + Super Admin + Org Admin+) |
| 5 | `/api/integrations` | `routes/integrations.ts` | Mixed (Any + Org Admin+) |
| 6 | `/api/insights` | `routes/insights.ts` | Mixed (Any + Org Admin+) |
| 7 | `/api/agents` | `routes/agents.ts` | Mixed (Any + Org Admin+) |
| 8 | `/api/credits` | `routes/credits.ts` | Mixed (Any + Org Admin+) |
| 9 | `/api/tasks` | `routes/tasks.ts` | Any |
| 10 | `/api/appointments` | `routes/appointments.ts` | Mixed (Any + Org Admin+ + public confirm) |
| 11 | `/api/conversations` | `routes/conversations.ts` | Any (file upload 50MB) |
| 12 | `/api/admin` | `routes/admin.ts` | Super Admin |
| 13 | `/api/admin/knowledge` | `routes/knowledge.ts` | Org Admin+ |
| 14 | `/api/settings` | `routes/settings.ts` | Org Admin+ |
| 15 | `/api/skills` | `routes/skills.ts` | Org Admin+ |
| 16 | `/api/email` | `routes/email.ts` | Any |
| 17 | `/api/user/integrations` | `routes/userIntegrations.ts` | Any |
| 18 | `/api/dealerbrain` | `routes/dealerbrain.ts` | Super Admin |
| 19 | `/api/notifications` | `routes/notifications.ts` | Any |
| 20 | `/api/sms` | `routes/sms.ts` | Mixed (public webhook + Any + Admin) |
| 21 | `/api/widgets/public` | `routes/widget-public.ts` | Public (rate limited 100/hr/IP) |
| 22 | `/api/widgets` | `routes/widgets.ts` | Mixed (Any + Org Admin+) |
| 23 | `/api/inbox` | `routes/inbox.ts` | Mixed (Any + Org Admin+) |
| 24 | `/api/tracking` | `routes/tracking.ts` | Mixed (public + Org Admin+) |
| 25 | `/api/triggers` | `routes/triggers.ts` | Mixed (Any + Org Admin+) |
| 26 | `/api/activity` | `routes/activity.ts` | Mixed (Any + Org Admin+) |
| 27 | `/api/goals` | `routes/goals.ts` | Mixed (Any + Org Admin+) |
| 28 | `/api/reports` | `routes/reports.ts` | Mixed (Any + Org Admin+) |
| 29 | `/api/drive` | `routes/drive.ts` | Any |
| 30 | `/api/hunches` | `routes/hunches.ts` | Any |
| 31 | `/api/approvals` | `routes/approvals.ts` | Any |
| 32 | `/api/leads` | `routes/leads.ts` | Any |
| 33 | `/api/dashboard` | `routes/dashboard.ts` | Any |
| 34 | `/api/metrics` | `routes/metrics.ts` | Mixed (Any + Super Admin) |
| 35 | `/api` (google-calendar) | `routes/google-calendar.ts` | Mixed (Any + public callback) |
| 36 | `/api/hosted-pages` | `routes/hosted-pages.ts` | Mixed (Any + Org Admin+) |
| 37 | `/api/pages` | `routes/hosted-pages-public.ts` | Public |
| 38 | `/api/billing` | `routes/billing.ts` | Mixed |
| 39 | `/api/health` | inline in `routes.ts` | Public |

**NOTE:** Webhook routes (#1-2) are registered before the JSON body parser to capture raw bodies for signature verification.

**NOTE:** `/api/widgets/public` (#21) must be registered before `/api/widgets` (#22) so that `/api/widgets/public/*` matches first.

### 4.4 Route Endpoint Summary

| Route Prefix | File | Approx. Endpoints |
|-------------|------|-------------------|
| `/api/webhooks/vapi` | `webhooks/vapi.ts` | 1 (multi-event POST) |
| `/api/webhooks/tavus` | `webhooks/tavus.ts` | 1 (multi-event POST) |
| `/api/auth` | `routes/auth.ts` | 9 |
| `/api/vin` | `routes/vin.ts` | 10 |
| `/api/integrations` | `routes/integrations.ts` | 6 |
| `/api/insights` | `routes/insights.ts` | 15 |
| `/api/agents` | `routes/agents.ts` | 9 |
| `/api/credits` | `routes/credits.ts` | 5 |
| `/api/tasks` | `routes/tasks.ts` | 9 |
| `/api/appointments` | `routes/appointments.ts` | 10 |
| `/api/conversations` | `routes/conversations.ts` | 11 |
| `/api/admin` | `routes/admin.ts` | 14 |
| `/api/admin/knowledge` | `routes/knowledge.ts` | 4 |
| `/api/settings` | `routes/settings.ts` | 4 |
| `/api/skills` | `routes/skills.ts` | varies |
| `/api/email` | `routes/email.ts` | 7 |
| `/api/user/integrations` | `routes/userIntegrations.ts` | 7 |
| `/api/dealerbrain` | `routes/dealerbrain.ts` | 3 |
| `/api/notifications` | `routes/notifications.ts` | 8 |
| `/api/sms` | `routes/sms.ts` | 7 |
| `/api/widgets/public` | `routes/widget-public.ts` | 8 |
| `/api/widgets` | `routes/widgets.ts` | 9 |
| `/api/inbox` | `routes/inbox.ts` | 8 |
| `/api/tracking` | `routes/tracking.ts` | 6 |
| `/api/triggers` | `routes/triggers.ts` | 10 |
| `/api/activity` | `routes/activity.ts` | 6 |
| `/api/goals` | `routes/goals.ts` | 7 |
| `/api/reports` | `routes/reports.ts` | 5 |
| `/api/drive` | `routes/drive.ts` | 8 |
| `/api/hunches` | `routes/hunches.ts` | 4 |
| `/api/approvals` | `routes/approvals.ts` | 5 |
| `/api/leads` | `routes/leads.ts` | 6 |
| `/api/dashboard` | `routes/dashboard.ts` | 1 |
| `/api/metrics` | `routes/metrics.ts` | 3 |
| `/api` (google-calendar) | `routes/google-calendar.ts` | 7 |
| `/api/hosted-pages` | `routes/hosted-pages.ts` | 5 |
| `/api/pages` | `routes/hosted-pages-public.ts` | 1 |
| `/api/billing` | `routes/billing.ts` | varies |
| `/api/health` | inline | 1 |

**Total endpoints:** ~237 (approximate; varies by counting method).

**Auth distribution:**

| Auth Level | Approx. Endpoint Count |
|-----------|----------------------|
| Public (no auth) | ~15 |
| Any authenticated user | ~110 |
| Org Admin+ (role level <= 3) | ~40 |
| Super Admin only (role level = 1) | ~20 |

### 4.5 Rate Limiting

| Route | Limit | Window | Scope |
|-------|-------|--------|-------|
| `POST /api/auth/login` | 30 | 1 minute | Per IP |
| `POST /api/auth/register` | 5 | 1 hour | Per IP |
| `POST /api/auth/forgot-password` | 3 | 1 hour | Per IP |
| `/api/widgets/public/*` | 100 | 1 hour | Per IP |
| `POST /api/insights/dealer-pulse/refresh` | 1 | 15 minutes | Per org |

No global rate limiting is applied.

### 4.6 Service Inventory

All services are in `server/services/`. Listed alphabetically with file size for relative complexity assessment.

**Top-Level Services (37 files):**

| Service File | Size | Purpose |
|-------------|------|---------|
| `AccessibleOrganizationsService.ts` | 5.3 KB | Resolves user-to-org access by RBAC role hierarchy |
| `ActivityService.ts` | 16.7 KB | Activity feed aggregation from `ai_usage_events` table |
| `AgentService.ts` | 11.6 KB | VAPI + Tavus agent CRUD, metadata tagging, status toggle |
| `AppointmentService.ts` | 36.1 KB | Calendar CRUD with RBAC; deps: GoogleCalendarService, AppointmentConfirmationService |
| `ApprovalService.ts` | 6.3 KB | Approval workflow state machine (pending -> approved/rejected) |
| `appointmentConfirmationService.ts` | 15.0 KB | Confirmation email/SMS dispatch; deps: Resend, TextMagicService |
| `appointmentExtractionService.ts` | 8.6 KB | AI extraction of appointment details from call transcripts (Claude API) |
| `ConversationService.ts` | 10.1 KB | DealerBrain conversation persistence and retrieval |
| `CreditService.ts` | 17.2 KB | Usage tracking, billing, credit recording; tables: `credit_policies`, `credit_allocations`, `credit_usage` |
| `DailyDigestService.ts` | 8.3 KB | Daily digest email generation |
| `DashboardService.ts` | 31.8 KB | Dashboard data aggregation (multiple service dependencies) |
| `DealerBrainService.ts` | 112.5 KB | **LARGEST FILE.** Claude API with 24-tool function calling (non-streaming). System instructions, tool definitions, context assembly. |
| `DealerBrainStreamingService.ts` | 88.1 KB | Claude API SSE streaming variant of DealerBrain |
| `DealerPulseService.ts` | 16.4 KB | 5-phase health snapshots; deps: Claude Haiku, VinSolutionsService |
| `DriveService.ts` | 9.1 KB | File/folder management (local filesystem + DB, 1GB quota) |
| `EmailService.ts` | 21.1 KB | IMAP/SMTP operations for email inbox |
| `FeedbackService.ts` | 5.9 KB | User feedback collection and storage |
| `GoalsService.ts` | 11.1 KB | Goal tracking with progress calculation |
| `GoogleCalendarService.ts` | 23.8 KB | Google Calendar API (OAuth2), event sync, appointment push |
| `HostedPageService.ts` | 12.9 KB | Hosted widget page rendering and configuration |
| `HunchesService.ts` | 15.2 KB | AI-generated insights using Claude API |
| `InboxService.ts` | 22.8 KB | Unified messaging inbox (cross-channel threading) |
| `KnowledgeUploadService.ts` | 10.2 KB | CSV/XLSX file import for knowledge base |
| `MetricsEngine.ts` | 19.0 KB | Certified metrics registry, role-based filtering, metric definitions |
| `NotificationService.ts` | 19.2 KB | In-app notifications; deps: Resend (email), local DB |
| `PasswordResetService.ts` | 11.5 KB | Token generation/validation; deps: Resend (email) |
| `PdfReportService.ts` | 14.8 KB | Puppeteer-based PDF report generation |
| `ReportService.ts` | 26.2 KB | Report data aggregation (loss, channel, trend reports) |
| `TaskService.ts` | 15.3 KB | Task management with status tracking |
| `TextMagicService.ts` | 37.9 KB | SMS send/receive via TextMagic REST v2 API |
| `TrackingService.ts` | 11.1 KB | Tracking pixel event recording |
| `TriggerService.ts` | 42.4 KB | Event-driven automation engine; deps: VAPI API, TextMagicService, NotificationService, TaskService |
| `vinOAuthService.ts` | 6.9 KB | VIN Solutions OAuth2 token management (156 lines core logic) |
| `vinSolutionsService.ts` | 42.5 KB | VIN CRM API client (OAuth2), encryption utils, lead/contact CRUD |
| `WidgetAgentService.ts` | 32.5 KB | Widget AI chat using Claude API (separate from DealerBrain) |
| `WidgetConfigService.ts` | 17.9 KB | Widget configuration CRUD |
| `WidgetInteractionService.ts` | 17.4 KB | Widget chat, callbacks, SMS, video; deps: WidgetAgentService, InboxService, TriggerService |

**Service Subdirectories:**

| Directory | Files | Purpose |
|-----------|-------|---------|
| `contextRouter/` | `ContextRouterService.ts`, `SourceSelector.ts`, `CacheManager.ts`, `index.ts` | Unified data query orchestration (VIN API primary, local DB fallback) |
| `insights/` | `DashboardAnalyticsService.ts` (65.2 KB), `VoiceInsightService.ts`, `VideoInsightService.ts`, `LeadInsightService.ts`, `index.ts` | Voice/video/lead analytics and dashboard aggregation |
| `leads/` | `LeadCreationService.ts`, `LeadExtractionService.ts`, `index.ts` | VIN 2-step lead creation, AI extraction from transcripts |
| `notifications/` | `notificationEmailService.ts` (17.5 KB) | Resend email dispatch for call events |
| `sync/` | `SyncCoordinator.ts`, `LeadMapper.ts`, `index.ts` | VIN bidirectional lead sync via `sync_queue` table |

### 4.7 Service-to-Route Mapping

| Route Prefix | Primary Service(s) |
|-------------|-------------------|
| `/api/auth` | `PasswordResetService`, `AccessibleOrganizationsService` |
| `/api/vin` | `vinSolutionsService`, `vinOAuthService`, `contextRouter/*`, `sync/*` |
| `/api/integrations` | `vinSolutionsService` (credential CRUD) |
| `/api/insights` | `insights/*`, `DealerPulseService` |
| `/api/agents` | `AgentService` |
| `/api/credits` | `CreditService` |
| `/api/tasks` | `TaskService` |
| `/api/appointments` | `AppointmentService`, `appointmentConfirmationService`, `GoogleCalendarService` |
| `/api/conversations` | `ConversationService`, `DealerBrainService`, `DealerBrainStreamingService` |
| `/api/admin` | `AccessibleOrganizationsService`, inline admin queries |
| `/api/admin/knowledge` | `KnowledgeUploadService` |
| `/api/email` | `EmailService` |
| `/api/dealerbrain` | `DealerBrainService` (config management) |
| `/api/notifications` | `NotificationService` |
| `/api/sms` | `TextMagicService` |
| `/api/widgets/public` | `WidgetInteractionService`, `WidgetAgentService` |
| `/api/widgets` | `WidgetConfigService` |
| `/api/inbox` | `InboxService` |
| `/api/tracking` | `TrackingService` |
| `/api/triggers` | `TriggerService` |
| `/api/activity` | `ActivityService` |
| `/api/goals` | `GoalsService` |
| `/api/reports` | `ReportService`, `PdfReportService` |
| `/api/drive` | `DriveService` |
| `/api/hunches` | `HunchesService` |
| `/api/approvals` | `ApprovalService` |
| `/api/leads` | `leads/*` (LeadCreationService, LeadExtractionService) |
| `/api/dashboard` | `DashboardService` |
| `/api/metrics` | `MetricsEngine` |
| `/api/hosted-pages` | `HostedPageService` |
| Webhook: VAPI | `webhooks/vapi.ts` -> `leads/*`, `sync/*`, `CreditService`, `NotificationService`, `appointmentExtractionService` |
| Webhook: Tavus | `webhooks/tavus.ts` -> `CreditService`, `NotificationService` |

### 4.8 Scheduled Background Jobs

All jobs are in `server/jobs/`. They use native `setInterval` (no Redis, no Bull). Each has an `isRunning` singleton guard flag. Staggered startup delays (0-90s) prevent thundering herd at process start.

| Job File | Interval | Purpose |
|----------|----------|---------|
| `vinTokenRefreshJob.ts` | 30 min | Refreshes VIN Solutions OAuth tokens (within 10 min of expiry) |
| `syncQueueWorker.ts` | 1 min (outbound), 4 hrs (inbound) | Processes `sync_queue` table entries for VIN sync |
| `appointmentReminderJob.ts` | 5 min | Checks upcoming appointments, sends reminder notifications |
| `emailSyncJob.ts` | 5 min | IMAP sync (up to 50 integrations per run) |
| `vinLeadPollingJob.ts` | 60 min | Polls VIN Solutions for new/updated leads |
| `triggerReevalJob.ts` | 5 min | Re-evaluates trigger rules against current state |
| `dealerPulseJob.ts` | 4 hrs | Collects dealer health snapshots via Claude Haiku |
| `hunchGenerationJob.ts` | 6 hrs | Generates AI hunches using Claude API |
| `idleLeadChecker.ts` | (part of trigger re-eval) | Checks for idle leads needing follow-up |
| `invoiceGenerator.ts` | varies | Invoice generation |

### 4.9 Database Schema Overview

**53 tables across 40 migration files (001-040, migration 011 missing, two files share `004` prefix).**

| Group | Tables | Count |
|-------|--------|-------|
| Core Identity | `organizations`, `locations`, `roles`, `users`, `partner_admin_organizations` | 5 |
| Integrations | `integrations`, `user_integrations` | 2 |
| AI Agents | `agents`, `skills`, `agent_runs` | 3 |
| Conversations | `conversations`, `messages` | 2 |
| Leads & CRM | `leads`, `sync_queue`, `vin_reports_cache` | 3 |
| Voice/Video | `vapi_call_logs`, `tavus_sessions` | 2 |
| Communication | `textmagic_config`, `textmagic_messages`, `textmagic_opt_outs`, `sms_conversation_state`, `cached_emails`, `sent_emails`, `email_templates` | 7 |
| Work Center | `tasks`, `appointments`, `availability_blocks`, `appointment_reminders`, `inbox_conversations`, `inbox_messages` | 6 |
| Insights & Analytics | `dashboards`, `widgets`, `goals`, `insight_card_config`, `insight_card_state`, `dealer_pulse_cache`, `report_benchmarks` | 7 |
| Widget System | `widget_configs`, `widget_callback_requests`, `widget_visitors`, `widget_chat_messages`, `hosted_pages` | 5 |
| Governance & Tracking | `ai_usage_events`, `trigger_rules`, `trigger_executions`, `trigger_templates`, `tracking_events`, `audit_log` | 6 |
| Business | `credit_policies`, `credit_allocations`, `credit_usage`, `service_quotas` | 4 |
| Drive & Artifacts | `drive_folders`, `drive_files`, `artifacts`, `knowledge_uploads` | 4 |
| Workflow | `hunches`, `approval_requests` | 2 |
| Auth | `password_reset_tokens` | 1 |
| Notifications | `notification_settings`, `notifications` | 2 |
| Config | `dealerbrain_config`, `vin_api_calls` | 2 |

**JSONB-heavy tables (58 JSONB columns total, no CHECK constraints or JSON Schema validation):**
- `organizations`: `settings`, `billing_info`
- `locations`: `address`, `business_hours`, `contact_info`, `settings`
- `agents`: `config`, `performance_metrics`
- `conversations`: `customer_info`, `metadata`
- `widget_configs`: `config_appearance`, `config_channels`, `config_targeting`, `allowed_domains`, `chat_enabled_tools`
- `roles`: `permissions`

**Migration file location:** `database/migrations/`

**Migration anomalies:**
- Migration `011` is missing (gap between 010 and 012)
- Two files share the `004` prefix (`004_create_user_integrations.sql` and `004_serra_seed_data.sql`)
- 16+ tables have `updated_at` columns but no automatic trigger (only 12 tables have `updated_at` triggers)

**Foreign key notes:**
- ~80 total FK relationships
- Most org-linked tables cascade on delete
- Missing FKs: `textmagic_messages.linked_lead_id` and `linked_appointment_id`
- Deferred/circular FKs: `leads.vapi_call_id`, `leads.tavus_session_id`, `vapi_call_logs.lead_id`, `tavus_sessions.lead_id`
- 1 table with NO RLS: `report_benchmarks` (public reference data, intentional)

### 4.10 Connection Pooling

```typescript
// server/db.ts
const pool = new Pool({
  connectionString: process.env.DATABASE_URL, // direct URL preferred (port 5432)
  max: 10,
});
```

Prefers direct Supabase URL (port 5432) over pgbouncer (port 6543).

---

## 5. Integration Architecture

### 5.1 VIN Solutions (CRM)

| Aspect | Detail |
|--------|--------|
| Type | REST API |
| Base URL | `https://api.vinsolutions.com` |
| Auth | OAuth2 Client Credentials (tokens expire 60 min) |
| Token storage | AES-256-GCM encrypted in `integrations.credentials` column |
| Key derivation | PBKDF2 (100k iterations) from `SESSION_SECRET` env var |
| Token refresh | Job every 30 min; refreshes within 10 min of expiry |
| Credentials | Per-org, stored in `integrations` table (NOT in `.env`) |
| Service files | `server/services/vinSolutionsService.ts`, `server/services/vinOAuthService.ts` |
| Sub-services | `server/services/sync/SyncCoordinator.ts`, `server/services/sync/LeadMapper.ts` |
| Context Router | `server/services/contextRouter/ContextRouterService.ts`, `SourceSelector.ts`, `CacheManager.ts` |
| Routes | 10 endpoints at `/api/vin` |
| API telemetry | `vin_api_calls` table (endpoint, params, duration, status, result_count) |

**Header versioning:**
- v1 endpoints: `Accept: application/vnd.coxauto.v1+json`
- v3 endpoints: `Accept: application/vnd.coxauto.v3+json` (lowercase)
- Gateway endpoints: `Accept: application/json`

**Accessible endpoints (13):** Leads CRUD, contacts, lead sources/types/statuses, CRM users, dealers.

**Blocked endpoints (17):** All return 403. Includes: calendar, appointments, tasks, notes write, vehicle inventory, deal management.

**Lead creation (2-step):**
1. `POST /gateway/v1/contact` -> get ContactId
2. `POST /leads` with href references to contact

**Known bug:** Lead creation code calls `/leadSources` and `/leadTypes` with v3 headers, but these endpoints require v1 headers. Calls fail silently (caught in try/catch).

**Context Router source priority:**
1. VIN Solutions API (live, primary)
2. Local DB (fallback)
3. Exclusion: `excel_upload` records filtered out

**Cache TTLs:** VIN leads 5 min, VIN reports 1 hr, VAPI/Tavus 1 hr.

**Config toggle:** `CONTEXT_ROUTER_ENABLED` env var (was `false` before 2026-02-16).

### 5.2 VAPI (Voice AI)

| Aspect | Detail |
|--------|--------|
| Type | Webhook inbound + outbound API |
| Webhook endpoint | `/api/webhooks/vapi` (registered BEFORE body parsers in `routes.ts`) |
| Auth (inbound) | Optional shared secret (`X-Vapi-Secret` header, timing-safe comparison). Accepts without verification if header absent. |
| Events handled | `call.started`, `call.ended`, `end-of-call-report`, `transcript`, `status-update` |
| Org resolution | `metadata.organizationId` from payload, or `assistantId` lookup in `agents` table |
| Idempotency | `notification_sent` and `credit_recorded` columns with atomic `UPDATE...WHERE...RETURNING` pattern |
| Service file | `server/webhooks/vapi.ts` (29,621 bytes) |
| Cost tracking | Voice $0.15/min cost, $0.25/min charge (40% margin) |

**Processing chain (on call end):**
1. Create/update call log in `vapi_call_logs`
2. Lead extraction (AI, from transcript)
3. `sync_queue` entry (lead_to_vin)
4. Credit recording (idempotent)
5. Email notification (via Resend)
6. In-app notification
7. Appointment extraction (if confidence >= 70%)

### 5.3 Tavus (Video AI)

| Aspect | Detail |
|--------|--------|
| Type | Webhook inbound + outbound API |
| Webhook endpoint | `/api/webhooks/tavus` (raw body capture for HMAC verification) |
| Auth | HMAC-SHA256 with 5-minute timestamp tolerance |
| Events handled | `conversation.started`, `conversation.ended`, `replica.ready`, `video.ready` |
| Org resolution | `custom_data.organization_id` from payload, or `persona_id` lookup in `agents` table |
| Service file | `server/webhooks/tavus.ts` |
| Signature verifier | `server/webhooks/utils/signatureVerifier.ts` |
| Deployed personas | 5 (Caroline, Magnolia, Georgia, Elizabeth, Savannah) across 2 customers |
| Cost tracking | Video $0.20/min cost, $0.32/min charge (37.5% margin) |

### 5.4 TextMagic (SMS)

| Aspect | Detail |
|--------|--------|
| Type | REST API v2 |
| Auth | Username + API key (per-org, stored in `textmagic_config` table) |
| Inbound webhook | `/api/sms/webhook/inbound` (public, NO signature verification -- TextMagic does not sign) |
| Service file | `server/services/TextMagicService.ts` (37,939 bytes) |
| Tables | `textmagic_config`, `textmagic_messages`, `textmagic_opt_outs`, `sms_conversation_state` |
| Routes | 7 endpoints at `/api/sms` |
| Cost tracking | SMS $0.02/msg cost, $0.05/msg charge (60% margin) |

**Not built (schema exists, logic not implemented):**
- AI auto-reply (`ai_auto_reply_enabled` field exists)
- Business hours routing
- Collision avoidance state machine (`sms_conversation_state` table exists)

### 5.5 Resend (Email)

| Aspect | Detail |
|--------|--------|
| Type | SDK |
| Auth | API key (in `.env`) |
| Service file | `server/services/notifications/notificationEmailService.ts` (17,510 bytes) |
| Purpose | Transactional email: lead notifications, welcome emails, appointment confirmations, password resets |

### 5.6 Anthropic Claude (AI/LLM)

| Aspect | Detail |
|--------|--------|
| Type | SDK (`@anthropic-ai/sdk`) |
| Auth | API key (in `.env`) |
| Model | Configurable (defaults to claude-3-5-sonnet) |
| Tools | 24 tools exposed for function calling |

**Service files using Claude API:**

| Service | Model | Purpose |
|---------|-------|---------|
| `DealerBrainService.ts` (112.5 KB) | claude-3-5-sonnet (configurable) | Non-streaming AI chat with 24 tools |
| `DealerBrainStreamingService.ts` (88.1 KB) | claude-3-5-sonnet (configurable) | SSE streaming AI chat |
| `DealerPulseService.ts` | Claude Haiku | Health snapshot generation |
| `HunchesService.ts` | Claude API | AI insight generation |
| `appointmentExtractionService.ts` | Claude API | Appointment extraction from transcripts |
| `WidgetAgentService.ts` | Claude API | Widget-specific AI chat |

**DealerBrain Processor middleware:** Stage 1 only (monitoring). Stages 2-3 (intervention, approval gates) deferred.

### 5.7 Google Calendar

| Aspect | Detail |
|--------|--------|
| Type | OAuth2 (Authorization Code flow) |
| Auth | Per-user OAuth tokens (stored in `user_integrations` table) |
| Service file | `server/services/GoogleCalendarService.ts` (23,784 bytes) |
| Routes | 7 endpoints mounted at `/api` (OAuth flow + calendar management) |
| Background job | `startCalendarSyncJob()` called from `routes.ts` |
| Purpose | Calendar sync, appointment push to Google Calendar |

---

## 6. Security Model

### 6.1 JWT Authentication

| Aspect | Detail |
|--------|--------|
| Implementation | `server/auth/jwt.ts` (signing, verification, expiry config) |
| Middleware | `server/auth/middleware.ts` (validates token, attaches `req.user`) |
| Access token | 24-hour expiry, audience `nexxus-api` |
| Refresh token | 7-day expiry, audience `nexxus-api` |
| Appointment confirmation token | 48-hour expiry, audience `nexxus-appointment` |
| Password hashing | bcrypt, 10 salt rounds |
| Client storage | `nexxus_access_token`, `nexxus_refresh_token`, `nexxus_token_expiry` in localStorage |
| Auto-refresh | Client polls every 60s, refreshes when < 5 min to expiry |

### 6.2 RBAC Role Hierarchy

4-tier RBAC roles seeded in `roles` table:

| Level | Role | Capabilities |
|-------|------|-------------|
| 1 | Super Admin | All operations. Global user/org management. System configuration. |
| 2 | Partner Admin | Multi-org access. Organization management for assigned orgs. |
| 3 | Org Admin | Organization-scoped management. User management, integration config, settings. |
| 4 | Org Staff | Organization-scoped read/write. Limited to own data and assigned resources. |

Middleware enforcement: `requireSuperAdmin`, `requirePartnerAdminOrHigher`, `requireOrgAdminOrHigher`, `requireRoleLevel(n)`.

### 6.3 RLS Policies

**CRITICAL BUG:** `SecureQueryBuilder` (at `server/db/SecureQueryBuilder.ts`) sets the PostgreSQL session variable `app.current_organization_id`, but all ~100 RLS policies check `app.current_org_id`. These are **different variable names**. The system works because most routes bypass `SecureQueryBuilder` and use `set_config('app.current_org_id', ...)` directly on the pool connection.

**RLS pattern distribution:**

| Pattern | Description | Table Count |
|---------|-------------|-------------|
| A: `app.current_org_id` | Organization isolation (most common) | 43 |
| B: `app.current_user_id` | User-self-access (personal data) | 7 |
| C: `app.user_role_level = 1` | Super Admin bypass | 16 |
| D: `TO service_role` | Background job/webhook bypass | 17 |
| E: Role-tiered | Org Admin+ manages, Staff reads | 5 |
| F: Open read | Authenticated read for all | 2 (`roles`, `skills`) |
| G: Special/anomalous | Uses variables that are never set | 4 |

**Additional RLS anomalies:**
- `app.current_role_level` is set in `triggers.ts` line 38, but should be `app.user_role_level`
- `app.current_role` is checked in `dealer_pulse_cache` and `knowledge_uploads` RLS policies but is never set by application code
- `SET LOCAL` used without transaction wrapper in `SecureQueryBuilder`, risking cross-tenant leakage on pooled connections
- 1 table has NO RLS: `report_benchmarks` (public reference data, intentional)

### 6.4 Webhook Security

| Webhook | Security |
|---------|----------|
| VAPI | Optional shared secret (`X-Vapi-Secret`). Timing-safe comparison. **Accepts requests without verification if header is absent.** |
| Tavus | HMAC-SHA256 with 5-minute timestamp tolerance. Strict verification. |
| TextMagic (inbound SMS) | No verification. TextMagic does not sign webhook payloads. |

### 6.5 Credential Encryption

| Aspect | Detail |
|--------|--------|
| Algorithm | AES-256-GCM |
| Key derivation | PBKDF2 (100,000 iterations) from `SESSION_SECRET` env var |
| Implementation | `server/utils/encryption.ts` |
| Used for | VIN Solutions OAuth tokens in `integrations.credentials` column |

### 6.6 Helmet / CSP

| Aspect | Detail |
|--------|--------|
| Helmet | Enabled in `server/index.ts` |
| CSP | **Disabled** for SPA compatibility |
| Reason | React SPA requires inline scripts and style-src unsafe-inline |

---

## 7. Deployment

### 7.1 Infrastructure

| Component | Detail |
|-----------|--------|
| Server | Oracle Cloud, Linux 5.15.0-1081-oracle |
| Runtime | Node.js v20.19.5 |
| Process manager | PM2 6.0.13, process name `nexxus-v2`, ID 13 |
| Port | Default 5000 (configurable via `PORT` env var); actual production is 5020 |
| Reverse proxy | Caddy (managed by sysadmin project at `/home/ubuntu/Claude-store/sysadmin`) |
| SSL | Managed by Caddy/sysadmin (automatic HTTPS) |
| Live URL | `https://nexxusv2.huminicdev.com` |
| Health check | `GET /api/health` |
| Docker | NOT used |
| CI/CD | NOT configured |
| Monitoring | None project-specific |
| Ecosystem config | NOT present (no `ecosystem.config.cjs`) |

### 7.2 Build Pipeline

Orchestrated by `script/build.ts`:

| Step | Tool | Input | Output |
|------|------|-------|--------|
| 1 | `rm -rf` | `dist/` | (clean) |
| 2 | Vite build | `client/` | `dist/public/` (React SPA) |
| 3 | Vite build | `widget/` | `dist/public/widget/` (Preact widget) |
| 4 | esbuild | tracking pixel source | `dist/public/widget/nexxus-pixel.js` (IIFE, minified) |
| 5 | esbuild | `server/` | `dist/index.cjs` (CJS, minified) |

### 7.3 Deploy Process

**Script:** `./deploy.sh`

1. Checks current branch is `master` (refuses feature branches)
2. Warns about uncommitted changes (y/N prompt)
3. Runs `npm run build`
4. Runs `pm2 restart nexxus-v2`
5. Shows `pm2 status`

**Missing:** No pre-deploy tests, no health check after restart, no rollback mechanism, no deploy notification.

### 7.4 PM2 Runtime Metrics (as of last audit)

| Metric | Value |
|--------|-------|
| Memory | 148.9 MB |
| CPU | 0.2% |
| Total restarts | 3,327 in 31 days (~107/day) |
| Unstable restarts | 0 |

### 7.5 Disk Usage

| Directory | Size |
|-----------|------|
| Source + docs + assets | 34 MB |
| `node_modules/` | 575 MB |
| `dist/` (build output) | 12 MB |
| **Total** | **656 MB** |

### 7.6 Environment Variables Reference

33 environment variables in `.env` (no `.env.example` exists).

**Known variables:**

| Variable | Purpose |
|----------|---------|
| `NODE_ENV` | `production` or `development` |
| `PORT` | Server port (default 5000, production 5020) |
| `DATABASE_URL` | Supabase PostgreSQL direct connection URL |
| `SESSION_SECRET` | Key derivation for AES-256-GCM credential encryption |
| `VIN_SOLUTIONS_CLIENT_ID` | VIN OAuth client ID |
| `VIN_SOLUTIONS_CLIENT_SECRET` | VIN OAuth client secret |
| `VIN_SOLUTIONS_API_KEY` | VIN API key |
| `VAPI_WEBHOOK_SECRET` | VAPI webhook signature verification |
| `CONTEXT_ROUTER_ENABLED` | Toggle Context Router (`true`/`false`) |
| `ANTHROPIC_API_KEY` | Claude API key |
| `RESEND_API_KEY` | Resend email API key |
| `TAVUS_API_KEY` | Tavus API key |
| `GOOGLE_CLIENT_ID` | Google Calendar OAuth client ID |
| `GOOGLE_CLIENT_SECRET` | Google Calendar OAuth client secret |

Remaining ~19 variables are not individually documented. They include database URLs (pgbouncer), additional service keys, and configuration toggles.

### 7.7 Database Configuration Tables

These tables store runtime configuration (not in `.env`):

| Table | Purpose |
|-------|---------|
| `dealerbrain_config` | 3 key-value rows: `system_instructions`, `feedback_enabled`, `feedback_instructions` |
| `integrations` | Per-org API credentials (VIN Solutions OAuth tokens, AES-256-GCM encrypted) |
| `textmagic_config` | Per-org SMS config (`api_username`, `api_key_encrypted`, `phone_number`, `business_hours`) |
| `user_integrations` | Per-user email/calendar settings (IMAP/SMTP creds, calendar OAuth tokens) |
| `widget_configs` | Per-org widget config (appearance, channels, targeting, allowed domains) |
| `credit_policies` | Per-org pricing (`rate_per_unit`, `cost_per_unit`, `monthly_allowance`) |
| `service_quotas` | Per-org monthly limits (schema only -- no enforcement logic) |
| `organizations.settings` | Organization settings (JSONB) |
| `roles` | 4 RBAC roles with `permissions` JSONB |

### 7.8 Feature Flags

No formal feature flag system exists. Current flags:

| Flag | Type | Status |
|------|------|--------|
| `CONTEXT_ROUTER_ENABLED` | env var | `true` (was `false` before 2026-02-16) |
| Credits page route | Code comment | Intentionally deferred (route commented out in App.tsx) |
| Billing profile tab | Code comment | Intentionally deferred |

---

## 8. Widget Build

### 8.1 Build Configuration

| Aspect | Detail |
|--------|--------|
| Framework | Preact 10.28.3 |
| Build tool | Vite (config at `widget/vite.config.ts`) |
| TypeScript config | `widget/tsconfig.json` |
| PostCSS config | `widget/postcss.config.js` |
| Output | `dist/public/widget/` |
| npm script | `npm run build:widget` (`cd widget && npx vite build`) |
| Also built | Tracking pixel via esbuild -> `dist/public/widget/nexxus-pixel.js` (IIFE, minified) |

### 8.2 Three Deployment Modes

| Mode | Description | Entry Point |
|------|-------------|-------------|
| Hosted page | Full-page widget at `/w/:slug` | `client/src/pages/hosted/HostedPage.tsx` (React, not widget build) |
| Embedded | `<script>` tag on external site loads widget bundle | `dist/public/widget/` (Preact build) |
| Unified (corner) | Bottom-corner chat bubble on external site | `dist/public/widget/` (Preact build) |

### 8.3 Hosted Page Components

Located at `client/src/pages/hosted/`:

| Component | Purpose |
|-----------|---------|
| `HostedPage.tsx` | Router for hosted page types (chat, video, callback, multi) |
| `HostedChat.tsx` | Chat-only hosted page |
| `HostedVideo.tsx` | Video agent hosted page |
| `HostedCallback.tsx` | Callback request hosted page |

Public route: `/w/:slug` (renders HostedPage)
Alternative public route: `/p/:slug` (renders HostedPagePublic)

### 8.4 Domain Whitelisting

Widget configuration includes an `allowed_domains` JSONB column in `widget_configs` table. The widget public API (`/api/widgets/public/*`) checks the `Origin` or `Referer` header against the allowed domains list before serving widget content.

Rate limit: 100 requests per hour per IP on `/api/widgets/public/*`.

### 8.5 Known Route Mismatch (P0)

The client-side hosted page fetches `/api/hosted-pages/public/${slug}`, but the server serves hosted page content at `/api/pages/:slug`. This is a one-line fix in either the client fetch URL or the server route mount point.

---

## Appendix A: Webhook Endpoint Quick Reference

| Webhook | Endpoint | Method | Auth |
|---------|----------|--------|------|
| VAPI | `/api/webhooks/vapi` | POST | Optional `X-Vapi-Secret` header |
| Tavus | `/api/webhooks/tavus` | POST | HMAC-SHA256 (`X-Tavus-Signature` header) |
| TextMagic inbound | `/api/sms/webhook/inbound` | POST | None |
| Google Calendar | `/api/google-calendar/callback` | GET | OAuth2 callback |

## Appendix B: RBAC Quick Reference

| Level | Role | Admin Routes | Settings Tabs | RLS Bypass |
|-------|------|-------------|---------------|------------|
| 1 | Super Admin | All 14 `/api/admin` + 3 `/api/dealerbrain` | Users, Orgs, Partner Links, Tools, Hunches, Automa, SMS | 16 tables |
| 2 | Partner Admin | Multi-org access | Org-scoped management | None |
| 3 | Org Admin | None | Knowledge, Email, Widget, Pages, Report Upload, Triggers | None |
| 4 | Org Staff | None | Application, Integrations | None |

## Appendix C: Token Configuration

| Token | Expiry | Audience | Storage |
|-------|--------|----------|---------|
| Access | 24 hours | `nexxus-api` | Client localStorage |
| Refresh | 7 days | `nexxus-api` | Client localStorage |
| Appointment confirmation | 48 hours | `nexxus-appointment` | Email link |
| Password reset | Configurable | n/a | `password_reset_tokens` table |
| VIN OAuth | 60 minutes | VIN Solutions API | `integrations` table (encrypted) |

## Appendix D: Known Architectural Issues

| Issue | Location | Severity | Detail |
|-------|----------|----------|--------|
| RLS variable mismatch | `server/db/SecureQueryBuilder.ts` vs all RLS policies | HIGH | Sets `app.current_organization_id`; policies check `app.current_org_id`. System works because most routes bypass SecureQueryBuilder. |
| `SET LOCAL` without transaction | `SecureQueryBuilder.ts` | HIGH | Risks cross-tenant leakage on pooled connections |
| VAPI webhook soft-check | `server/webhooks/vapi.ts` | MEDIUM | Accepts requests without secret header if header is absent |
| `app.current_role` never set | RLS policies on `dealer_pulse_cache`, `knowledge_uploads` | LOW | Policies reference a variable that application code never sets |
| `app.current_role_level` vs `app.user_role_level` | `triggers.ts` line 38 | LOW | Sets wrong variable name for RLS |
| Hosted pages route mismatch | Client fetch vs server route | P0 | Client fetches `/api/hosted-pages/public/${slug}`; server serves `/api/pages/:slug` |
| VIN header version mismatch | `vinSolutionsService.ts` lead creation | MEDIUM | `/leadSources` and `/leadTypes` called with v3 headers instead of v1; fails silently |
| Missing migration 011 | `database/migrations/` | LOW | Gap in migration numbering |
| Duplicate migration 004 | `database/migrations/` | LOW | Two files share `004` prefix |
| No unit tests | entire codebase | MEDIUM | Zero Jest/Vitest configuration |
| No ESLint/Prettier | entire codebase | LOW | No linting or formatting enforcement |
| No CI/CD | entire codebase | MEDIUM | No automated pipeline |
| 242 unstructured console.log | server code | LOW | No structured logging |
| Socket.io installed but unused | `server/websocket/` | LOW | Dependency present, no production features use it |
| Service quotas unenforced | `service_quotas` table | LOW | Schema exists but no enforcement logic in routes |

---

**END OF ARCHITECTURE SPECIFICATION**
