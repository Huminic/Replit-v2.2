# CLAUDE.md -- Nexxus V2 Agent Operating Rules

**This file is chmod 444 (read-only). Only the owner edits it. Do not attempt to modify this file.**

---

## 1. Truth Hierarchy

When sources conflict, the higher-ranked source wins. No exceptions.

### 1a. Document Truth Hierarchy

| Rank | Source | Governs |
|------|--------|---------|
| 1 | Reference UI (RUI) | Visual layout, navigation structure, component placement. Immutable -- can be added to, never modified. |
| 2 | ACCEPTANCE_CRITERIA.md | Testable pass/fail criteria per feature. |
| 3 | CLAUDE.md (this file) | Agent operating rules, constraints, conventions. |
| 4 | PRD.md | Business context, product identity, what and why. |
| 5 | SRS.md | System behavior narratives, how the system works. |
| 6 | SPEC.md | Architecture reference, exact file paths, service names. |
| 7 | PLAN.md | Current marching orders, gap tracker, cluster status. |

If a governance document contradicts the RUI on a visual matter, the RUI is correct. If PLAN.md contradicts ACCEPTANCE_CRITERIA.md on what constitutes a passing feature, AC wins.

### 1b. Data Truth Hierarchy (Runtime Data Conflicts)

| Priority | Source | Authoritative For |
|----------|--------|-------------------|
| 1 (highest) | VIN Solutions API | Leads, statuses, sources, types, CRM users |
| 2 | VAPI / Tavus APIs | AI call and video session data |
| 3 | Local Database | Nexxus-only data: tasks, goals, agents, preferences, activity |
| 4 (lowest) | Derived Metrics | Computed from above; never cached as truth |

If VIN API returns data that differs from the local database, VIN wins. Update local to match. Derived metrics are recomputed on demand, not stored as authoritative values.

### 1c. What Is NOT Governance

| Directory | Status |
|-----------|--------|
| `.project/` | NOT authoritative -- `/plan` mode scratch only |
| `.agent_docs/` | Operational reference for enforcer only |
| `filestore/` | Historical input, not governance |
| `docs/archive/` | Historical, not current truth |

Do not treat any file in these directories as authoritative for product decisions.

---

## 2. Every-Session Checklist

Before doing any work, complete these steps in order.

### 2a. Mandatory (Every Session)

1. Read this file (CLAUDE.md).
2. Read PLAN.md -- identify current phase, active cluster, blocking issues.
3. Read session state from memory directory -- recover context from prior sessions.
4. Run `git status` and `git branch --show-current` -- verify working branch and clean state.
5. If the current branch is `master`, create a feature branch before writing code.

### 2b. Before Starting New Feature Work

Read these in addition to the mandatory list:

1. ACCEPTANCE_CRITERIA.md -- know the pass/fail criteria for what you are building.
2. SRS.md -- understand the behavioral specification for the feature area.
3. SPEC.md -- locate the relevant services, routes, and tables.
4. DO_NOT_TOUCH.md -- verify which files are frozen before touching anything.

### 2c. State Verification

Confirm all of the following before writing code:

- [ ] On a feature branch (not `master`)
- [ ] PLAN.md identifies the cluster you are working on
- [ ] No uncommitted changes from a prior session
- [ ] PM2 process is running (`pm2 status`)
- [ ] `.env` file exists and is not empty

---

## 3. Governance File Map

Six governance files live at the project root. Each serves a distinct audience and purpose.

| File | Audience | Purpose | Read When |
|------|----------|---------|-----------|
| CLAUDE.md | Agent | Operating rules, truth hierarchy, constraints, conventions | Every session |
| PRD.md | Owner, stakeholders | Plain language: what the product is, business context | Understanding business intent |
| SRS.md | Owner, technical staff | System behavior narratives: "when X happens, Y occurs" | Understanding feature behavior |
| SPEC.md | Developer/agent | Architecture reference: file paths, service names, configs | Locating code, understanding structure |
| ACCEPTANCE_CRITERIA.md | Tester/agent | Testable pass/fail statements per feature | Building or verifying features |
| PLAN.md | Agent, owner | Current marching orders: active cluster, gap tracker, status | Every session |

### File Locations

- Governance files: `{project-root}/CLAUDE.md`, `PRD.md`, `SRS.md`, `SPEC.md`, `ACCEPTANCE_CRITERIA.md`, `PLAN.md`
- RUI mockup (live): https://nexxusv2sample.replit.app/ (SPA -- requires Playwright or real browser)
- RUI static files: `filestore/nexus-v2-1-current/`
- Enforcer definition: `.claude/agents/enforcer.md`
- Enforcer workspace: `.agent_docs/`
- VIN documentation: `filestore/VinDocs/`
- Frozen file list: `DO_NOT_TOUCH.md`
- Preserve list: `CARRY_FORWARD_MANIFEST.md`

---

## 4. Development Workflow

### 4a. Work Loop

```
1. Read PLAN.md
2. Identify the current cluster (do NOT skip ahead to later clusters)
3. For each gap in the cluster:
   a. Read the gap description and fix criteria
   b. Locate the relevant code (use SPEC.md for paths)
   c. Verify the gap exists (do not fix what is not broken)
   d. Implement the fix
   e. Test (3-proof validation -- see Section 8)
   f. Commit with evidence
4. Update PLAN.md gap tracker (mark gaps as FIXED with evidence)
5. When all gaps in a cluster are FIXED, report to owner for verification
6. Owner verifies -> proceed to next cluster
7. Loop
```

### 4b. When to Stop and Report

Stop work and report to the owner when:

- A gap requires server-side changes (server/ directory is frozen)
- A gap requires a new API endpoint
- The fix would contradict a governance document
- You discover a new gap not listed in PLAN.md
- You encounter a blocker not documented anywhere
- You are uncertain about the correct approach

Present 2-3 options with tradeoffs. Wait for guidance. Do not guess.

### 4c. Execution Order

Follow the plan's defined execution order. If PLAN.md specifies that certain clusters can run in parallel, parallelism is allowed. If PLAN.md specifies sequential order, execute sequentially. The plan is the authority on execution order, not a blanket rule.

### 4d. Branch Strategy

- Feature branches for all development: `feature/phase-{N}-{name}` or `feature/{name}`
- Deploy only from `master`
- Never commit to master directly
- Merge flow: `git checkout master && git merge feature/{name}` then `./deploy.sh`

### 4e. Pre-Deploy Quality Gate

```
npm run check -> npm run build -> npx playwright test
```

All three must pass with zero errors before any deploy. Deploy only via `./deploy.sh`, which enforces master branch, warns on uncommitted changes, runs build, and restarts PM2.

### 4f. Deployment Understanding

```
Working Directory -> TypeScript (.ts files)
                  -> npm run build
               dist/ -> Compiled JavaScript (.cjs)
                  -> PM2 serves
             Webserver -> Users see compiled code
```

Editing `.ts` files does NOT affect the webserver until you rebuild. The compiled output at `dist/index.cjs` is what PM2 serves.

---

## 5. Agent Team

### 5a. Roles

| Role | Type | Responsibility | Access |
|------|------|---------------|--------|
| Architect | Plan (read-only) | Decompose specs, define interfaces, resolve ambiguity | Read-only |
| Implementer(s) | General-purpose | Write code within assigned scope | Full |
| Validator | General-purpose | Write/run tests, verify metrics | Full |
| Auditor | Explore (read-only) | Review for gaps, inconsistencies, security | Read-only |
| Lead | Orchestrator | Assign work, enforce gates, make decisions | Full |

### 5b. Scaling

- 1 Architect (always)
- min(N, 3) Implementers (each in a worktree, max 3 parallel)
- 1 Validator per 2 Implementers
- 1 Auditor (after each phase gate)

### 5c. Enforcer

The enforcer is the owner's personal representative. It is separate from the agent team.

- Lives at: `.claude/agents/enforcer.md` (only agent definition file that exists)
- Workspace: `.agent_docs/` directory
- Checks: commit compliance, safety gates, quality gates
- Flags conflicts in `enforcer_context.md`
- Does NOT gate read-only testing passes (only commits)
- Cannot check comprehension of architecture (only document compliance)
- Cannot force resolution of flagged conflicts (requires owner)

### 5d. Communication Protocol

- Implementer discovers interface needs to change: STOP. Message Lead. Do not modify unilaterally.
- Implementer blocked by another task: Message Lead for reassignment.
- Spec ambiguity: Message Lead with 2-3 options. Do not guess.
- Status updates: DM to Lead only (not broadcast).

### 5e. Task Lifecycle

```
CREATED -> ASSIGNED -> IN_PROGRESS -> REVIEW -> VALIDATED -> DONE
                    |                           ^
                  BLOCKED -----------------------|
```

A task is not DONE until it passes through Validator AND Auditor. No self-certification.

### 5f. Quality Verification Gap

The gatekeeper agent (which looped builder output against AC + RUI until all criteria passed) was archived after an incident involving 31 unauthorized commits. The enforcer replaced it but serves a different function: the enforcer gates commits for compliance; the gatekeeper performed quality verification loops. The quality verification loop function currently has no replacement. Until the owner defines a replacement mechanism, the Validator role in Section 5a is the closest approximation. All work must still pass 3-proof validation (Section 8) before being marked DONE.

---

## 6. Architecture Facts

**This is the most critical section in this file.** Prior agent sessions produced tainted findings because they did not understand the architecture. Every fact below is code-verified. Treating any of these incorrectly will produce invalid findings.

### 6a. Automa IS the Chat Agent

There are no separate "comms agent", "sales coach", or "messaging agent" entities in V2. Automa is the always-available AI assistant. It appears at the top of the agents list and is accessible from the main dashboard.

- V1 had 27 separate hardcoded agents, each with fixed personas.
- V2 uses a different model: users CREATE their own agents and ADD skills to them.
- Skills are pre-prompting, context, and instructions -- user-selectable overlays, not fixed agent definitions.
- DealerBrain is the underlying AI service that powers Automa. DealerBrain is not a sidebar link and not a user-facing concept.

Do NOT report "missing chat agents" or "3/5 orgs have no agents." Automa IS the chat agent.

### 6b. Skills Model

Skills are a system-level overlay, not a per-agent database field.

- `agents` table stores: persona instructions, temperature, model selection.
- Skills are defined in the `skills` catalog table and attached to agents via a junction table.
- The `tools` field on the agents table is NOT the primary tool assignment mechanism.
- Migration 034 seeds 4 skills (not 74). The catalog is intentionally small at launch.

Do NOT report "tools=[] means agents have no tools." Tool assignment happens at the widget/system level.

### 6c. Tool Assignment

Tools are assigned at the `widget_configs` level, not per-agent in the database.

- 7 tools are configured at the system/widget level.
- 24 DealerBrain tools are available to Automa via the DealerBrainService.
- The `tools` column in the `agents` table is supplementary, not primary.

Do NOT report "no tools assigned" based on an empty `tools` DB field.

### 6d. TextMagic Credentials

TextMagic credentials are stored per-organization in the `textmagic_config` database table, NOT in `.env`.

- Testing with `.env` credentials produces 401 errors for org-level operations.
- The service reads credentials from the database at runtime, keyed by organization ID.
- This is the correct production design (multi-tenant, per-org isolation).

Do NOT report "TextMagic 401" based on testing with `.env` credentials.

### 6e. Trigger Deduplication

Two dedup mechanisms exist. They are not missing.

1. **execution_log** -- `TriggerService` records each trigger execution. Duplicate check before firing.
2. **idle_trigger_count** -- `idleLeadChecker` tracks follow-up attempts per lead. Stops after threshold.

Known issue: `idle_trigger_count` may not reset correctly (P1-14 in gap tracker). This is a bug in the reset logic, not a missing feature.

Do NOT report "no trigger dedup exists."

### 6f. VIN Solutions Limitations

- 17 of 30 VIN gateway endpoints return 403 Forbidden.
- Nexxus sees lead creation (beginning) and SOLD/LOST (end) but NOT the middle (deals, appointments, communication logs).
- VIN Solutions has no calendar API. Appointment-to-VIN sync is one-directional (Nexxus writes notes to VIN, not appointment records).
- VIN API has full history access. There is NO 48-hour data retention limit. Prior claims of a 48-hour limit are FALSE (verified against CLARIFICATION_ANSWERS.md Q6).
- VIN documentation says uppercase `V3` in headers. Production rejects uppercase. Use lowercase `v3`. Reference endpoints use `v1`. Gateway endpoints use `application/json`.
- VIN OAuth tokens expire every 60 minutes (handled by VinOAuthService).
- Lead creation is two-step: (1) create contact via gateway POST to get ContactId, (2) create lead with contact as URL reference. `leadSource`, `leadType`, and `contact` fields are href references, not string names. `dealerId` goes in query parameter, not request body.

Do NOT build UI for data that requires blocked endpoints. Do NOT report "VIN appointment sync missing" as a bug -- it is a platform limitation (owner decision).

### 6g. Billing Routes ARE Wired

Billing routes are registered and active:

- `routes.ts:178` -- server-side billing routes registered.
- `App.tsx:95` -- client-side billing route registered.

Do NOT report billing as "commented out" or "PHASE-FUTURE."

### 6h. VAPI Webhook Uses UPSERT

`handleCallStarted` in the VAPI webhook handler uses `ON CONFLICT DO UPDATE` (UPSERT), not UPDATE-only. This is defensive coding. The issue with VAPI was configuration, which the owner resolved.

Do NOT report "handleEndOfCallReport is UPDATE-only."

### 6i. Context Router Is Implemented

The Context Router is fully implemented:

- 44 `excel_upload` exclusion occurrences confirmed.
- SourceSelector and CacheManager are implemented.
- `CONTEXT_ROUTER_ENABLED=true` in env.
- Originally configured backwards (local DB primary); now corrected (VIN API primary, local DB fallback).

### 6j. Goals Tab Is Correctly Absent

Goals tab is correctly absent from Insights tabs. The current Insights tabs are: Dashboard, Reports, Library, Hunches. Do NOT report "goals tab should be removed from Insights" -- it is already gone.

### 6k. RLS Variable Name Mismatch (Known Bug)

`SecureQueryBuilder.ts:244` sets `app.current_organization_id` but RLS policies check `app.current_org_id`. Different variable names. The system works because most routes bypass SecureQueryBuilder. Additionally, `SET LOCAL` is used without a transaction, so the variable can persist on a pooled connection (potential cross-tenant data leak).

- Do NOT add new routes that depend on SecureQueryBuilder for org isolation.
- This is tracked as P1-1 in the gap tracker.

### 6l. Authentication Is JWT-Based

The system uses JWT authentication (access + refresh tokens in localStorage), NOT express-session. If any document says express-session, that document is wrong on this point. Ignore it.

- Keys: `nexxus_access_token`, `nexxus_refresh_token`, `nexxus_token_expiry`, `nexxus_accessible_orgs`
- Auto-refresh: checks every 60s, refreshes when < 5 min to expiry
- Login: `POST /api/auth/login`, Refresh: `POST /api/auth/refresh`, Org switch: `POST /api/auth/switch-org`

---

## 7. Code Conventions

### 7a. Technology Stack

- **Frontend:** Vite, React 18, TypeScript, Wouter (routing), TanStack Query (data fetching), shadcn/ui (47 primitives), Tailwind CSS v4, Recharts
- **Backend:** Node.js v20.19.5, Express.js 5, TypeScript, PostgreSQL (Neon), Drizzle ORM, esbuild (bundling)
- **External:** VIN Solutions, VAPI, Tavus, TextMagic, Resend, Anthropic (Claude)

### 7b. TypeScript Rules

- Strict mode enabled.
- No `any` type annotations in new code. (380 existing `any` annotations are tech debt, not precedent.)
- No linter, formatter, or pre-commit hooks exist beyond the enforcer.
- `shared/schema.ts` is FROZEN. Do not modify.

### 7c. Frontend Patterns

- API calls use relative URLs (no `VITE_` env vars in frontend).
- `client/src/lib/api.ts` request format must remain compatible with server expectations.
- `@shared` alias points to `./shared` -- do not change.
- `vite.config.ts` build.outDir must remain `dist/public`.
- `x-organization-id` header behavior must not change.

### 7d. Service Layer

- 40+ service modules in `server/services/`.
- Business logic lives in services, not in route handlers.
- Route handlers call services; services call database or external APIs.

### 7e. Configuration Over Hard-Coding

- Integration credentials: per-org in database, never in `.env` (TextMagic, VIN Solutions).
- System-level secrets (API keys for Anthropic, VAPI, Tavus): in `.env`.
- Feature flags and thresholds: database config or environment variables, not code constants.
- Lead assignment: configurable via Settings, never hardcoded.

### 7f. Data Query Rules

- Filter `source != 'excel_upload'` on ALL lead queries. This is already applied in 32+ queries across 11 files. Any new lead query must include it.
- All data responses include internal source tags (`VIN`, `VAPI`, `TAVUS`, `LOCAL`) for traceability. These tags are never displayed to users.

### 7g. Cache TTL

| Data Source | Cache TTL |
|-------------|-----------|
| VIN leads | 5 minutes |
| VAPI/Tavus | 1 hour |
| Local-only data | No cache |

On VIN failure: fall back to local cache with staleness warning in LOGS (not UI).

---

## 8. Testing Protocol

### 8a. Three-Proof Validation (Per Feature)

Every feature requires THREE pieces of evidence before it can be marked complete:

1. **Configuration test** -- verify configs, env vars, settings work.
2. **Functional test** -- verify feature works (unit/integration test).
3. **Visual/E2E test** -- verify UI/API produces expected results.

A feature is CERTIFIED only after all three proofs pass. Until then, it is IN PROGRESS regardless of how much code has been written.

### 8b. Pre-Deploy Gate

```
npm run check -> npm run build -> npx playwright test
```

All three must pass with zero errors.

### 8c. Playwright Configuration

- Viewport: 1280x720 (fixed).
- RUI is an SPA -- it will not render with simple fetch/curl. Use Playwright or a real browser for visual comparison.
- Test battery: 747 existing tests across 46 files.

### 8d. Testing Channels

| Channel | Test Method | Notes |
|---------|------------|-------|
| Voice | Use "Elliot" test-only VAPI agent | Never use production agents for testing |
| SMS | Loopback to self via TextMagic API | Never send test SMS to real customers |
| Email | Use `neoweaver@gmail.com` | Designated test email address |
| Video | Test sessions only | Never use production Tavus sessions |

### 8e. Metric Certification

A metric is only certified if:

- It has a defined name, data source(s), formula, field dependencies, and fill rate requirement.
- Underlying data fields are actually populated (>50% fill rate from 50+ record sample).
- Computed result matches ground truth (direct API query) within 2%.
- Data source is accessible (not a blocked 403 endpoint).
- Metrics depending on blocked endpoints are excluded entirely -- not shown, not placeholdered, not guessed.

### 8f. Evidence Standards

- No finding listed without file citation (path + line number or commit hash).
- Any "COMPLETED" label requires: link to artifact, timestamp, verifiable reference.
- Prove functionality with tests, screenshots, or logs. "It passed" is not evidence.
- Results are captured as artifacts (log files, screenshots, test output).
- Metrics require automated verification, not manual checks.

### 8g. Data Accuracy Mandate

"We cannot have data that is wrong. We cannot have metrics that are wrong."

A metric showing correct data is worth more than ten metrics showing guesses.

---

## 9. Prohibited Actions

28 rules. Violation of any rule is a blocker requiring remediation.

### Production Safety

| # | Rule |
|---|------|
| P1 | NEVER modify production v1 (`/home/ubuntu/Claude-store/nexxus/`) |
| P2 | NEVER share credentials between v1 and v2 |
| P3 | NEVER deploy from a feature branch |
| P4 | NEVER break webhook processing, VIN sync, or notification delivery |
| P5 | NEVER modify `server/webhooks/vapi.ts` without explicit owner approval |
| P6 | NEVER modify `server/webhooks/tavus.ts` without explicit owner approval |
| P7 | NEVER drop, truncate, or destructively migrate database tables |

### Data Integrity

| # | Rule |
|---|------|
| D1 | NEVER fabricate data or show unverified metrics |
| D2 | NEVER display metrics depending on blocked VIN endpoints |
| D3 | NEVER show placeholder data, "coming soon" indicators, or speculative numbers |
| D4 | NEVER serve stale/cached data as truth (respect cache TTLs) |
| D5 | NEVER bypass RLS or multi-tenant isolation |
| D6 | NEVER hardcode integration-specific values (API keys, phone numbers, credentials, lead assignments) |

### UI Rules

| # | Rule |
|---|------|
| U1 | NEVER expose vendor names ("Tavus", "VAPI", "VIN Solutions", "TextMagic", "DealerBrain") in customer-facing UI |
| U2 | NEVER show source attribution labels ("VIN API", "Local + VIN") in UI |
| U3 | NEVER copy visual patterns from existing frontend -- build fresh from RUI designs |

### Code and File Rules

| # | Rule |
|---|------|
| F1 | NEVER modify files in `server/`, `database/`, `widget/`, `scripts/` without explicit owner approval |
| F2 | NEVER modify `shared/schema.ts` |
| F3 | NEVER modify existing npm dependency versions or remove dependencies |
| F4 | NEVER modify the `scripts` section of `package.json` |
| F5 | NEVER reorder route registrations in `server/routes.ts` (webhook order matters) |
| F6 | NEVER modify WebSocket protocol or JWT token format/storage location |
| F7 | NEVER rewrite PRESERVE files listed in CARRY_FORWARD_MANIFEST.md |

### Process Rules

| # | Rule |
|---|------|
| X1 | NEVER mark something COMPLETED without artifact + timestamp + verifiable reference |
| X2 | NEVER modify CLAUDE.md (this file is chmod 444 -- owner only) |
| X3 | NEVER self-certify work as complete -- a separate validator is required |
| X4 | NEVER assume -- when in doubt, STOP and ask with 2-3 options |
| X5 | NEVER treat archived materials (`.project/`, `filestore/`, `docs/archive/`) as current truth |

### Plan Discipline

| # | Rule |
|---|------|
| L1 | NEVER ad-lib features or work on unplanned items -- follow the plan |
| L2 | NEVER skip ahead to later clusters or phases |
| L3 | NEVER build features that imply VIN data access without first checking which endpoints are accessible (17 of 30 are blocked) |

---

## 10. File Management

### 10a. Change Consent Boundaries

| Scope | Rule |
|-------|------|
| Governance files at root (CLAUDE.md, PRD.md, SRS.md, SPEC.md, AC, PLAN.md) | Owner consent required for any modification. CLAUDE.md is chmod 444. |
| `client/` directory | Modifiable within constraints (see 10b). |
| `server/`, `database/`, `widget/`, `scripts/`, `shared/schema.ts` | Frozen. See DO_NOT_TOUCH.md. Explicit owner approval required. |
| `.agent_docs/` | Enforcer workspace. Do not modify unless acting as enforcer. |
| `.project/` | `/plan` mode scratch only. Not governance. |
| `filestore/` | Read-only historical input. Do not modify. |
| New files | May create new files in `client/` only. New files elsewhere require approval. |

### 10b. Frontend Modification Constraints

The `client/` directory is safe to modify with these constraints:

- API contracts are immutable (request/response shapes defined by server).
- `shared/schema.ts` is frozen (client imports types from it).
- `vite.config.ts` build.outDir must remain `dist/public`.
- `@shared` alias must remain pointing to `./shared`.
- Do NOT add new API routes from the frontend (server is frozen).
- Do NOT modify WebSocket protocol.
- Do NOT change JWT token format or storage location.
- Do NOT change `x-organization-id` header behavior.
- `client/src/lib/api.ts` request format must remain compatible.

### 10c. Package.json Rules

- New client-side dependencies MAY be added.
- Do NOT remove, upgrade, or downgrade any existing dependency.
- Do NOT modify the `scripts` section.
- Do NOT modify `overrides` or `optionalDependencies`.

### 10d. Database Migrations

Must be additive only. Never destructive. Never drop, truncate, or destructively alter existing data or columns.

### 10e. Archive Policy

Do not delete files. If a file is no longer needed, move it to an archive directory. Document the move in the commit message with the reason.

---

## 11. Operational Context

### 11a. Server

- **Port:** 5020
- **Process manager:** PM2
- **Compiled output:** `dist/index.cjs`
- **Live URL:** https://nexxusv2.huminicdev.com
- **Deploy script:** `./deploy.sh` (master branch only)

### 11b. Production Customers

Serra Automotive and Hyundai of Columbia are live. Two customers with active data. Do not break webhook processing, VIN sync, or notification delivery.

### 11c. Live Production Feature

The webhook that sends email on call complete is the only confirmed live production feature operating in real-time. Verify it works at every transition point (branch merge, deploy, migration).

### 11d. Environment Variables

- 33 environment variables required (see `.env` for current values).
- No `VITE_` env vars in frontend -- all API calls use relative URLs.
- Key categories: Database, Auth, AI (Anthropic), VIN Solutions, VAPI, Tavus, Email (Resend), SMS (TextMagic), Google Calendar.
- `CONTEXT_ROUTER_ENABLED=true` is set.

### 11e. Webhook Route Order

VAPI webhook is registered BEFORE body parsers in `server/routes.ts`. Tavus webhook needs raw body capture for HMAC verification. Do NOT move webhook registrations or change their order.

### 11f. Infrastructure Coordination

Infrastructure changes (DNS, ports, webserver config, monitoring) must coordinate through the sysadmin project at `/home/ubuntu/Claude-store/sysadmin`. Do not modify Caddy config, allocate ports, or change DNS directly. Use the safe wrappers documented in the sysadmin project.

### 11g. Central-MCP

Central-MCP proxy exists at `../central-mcp/` (port 4002). Integration rules are not yet defined (deferred by owner). Do not attempt to integrate with it without owner direction.

---

## 12. Vocabulary

### 12a. Naming Rules

| Internal/Vendor Name | User-Facing Name | Rule |
|----------------------|-----------------|------|
| VAPI | Voice Agent | Never show "VAPI" in UI |
| Tavus | Video Agent | Never show "Tavus" in UI |
| DealerBrain | *(not shown)* | Underlying AI service, not a user concept |
| Automa | Automa | Always at top of agents list |
| Tools (agent capabilities) | Skills | User-facing term is "Skills" |
| Hub (route: `/work-center`) | Work Center | UI label is "Work Center" |
| TextMagic | *(not shown)* | SMS is the user concept |
| VIN Solutions | *(not shown)* | Never show "VIN Solutions" in UI |

### 12b. Terminology

- Do NOT use the word "MVP." The correct terms are "launch-critical" or "payment-critical."
- Nexxus is an AI orchestration layer. It is NOT a CRM replacement, NOT a marketing automation tool, NOT a content development platform.
- Automotive is the first vertical. The architecture must not be permanently locked to automotive.
- Widgets are portals to agents, not standalone features. Externally-initiated conversations (via widget) can be continued internally in Unified Inbox.

### 12c. RBAC Role Values

| Role | System Value | Level |
|------|-------------|-------|
| Super Admin | `super_admin` | 1 |
| Partner Admin | `partner_admin` | 2 |
| Org Admin | `org_admin` | 3 |
| Staff | `org_staff` | 4 |

Platform operator is Huminic (`super_admin`). First partner is Duran Cage.

### 12d. Feature Branch Naming

Format: `feature/phase-{N}-{name}` or `feature/{name}`

---

## 13. Retired Claims -- Do Not Re-Report

The following claims from prior tracking files are FALSE, TAINTED, or RESOLVED. They must NOT re-enter the gap tracker. If you encounter evidence that appears to support any of these claims, re-read Section 6 (Architecture Facts) before filing a finding.

| Claim | Verdict | Why It Is Wrong |
|-------|---------|-----------------|
| "3/5 orgs missing chat agents" (GAP-B1-AGENT-001/002/003) | TAINTED | Automa IS the chat agent (Section 6a) |
| "No tools (tools=[])" (GAP-B1-SKILLS-001) | TAINTED | 7 tools at widget/system level, not per-agent DB field (Section 6c) |
| "Instructions lack CRM/trigger docs" (GAP-B1-INSTR-001/002) | TAINTED | Measured raw DB field, not skill overlay system (Section 6b) |
| "No trigger dedup" (GAP-B1-TRIGGER-001) | TAINTED | Two dedup mechanisms exist (Section 6e) |
| "TextMagic 401" (GAP-B3-SMS-001) | TAINTED | Agent tested .env creds; service uses per-org DB creds (Section 6d) |
| "VIN appointment sync missing" (GAP-B5-VIN-SYNC-001) | RESOLVED | VIN Solutions has no calendar API -- owner decision, not a bug (Section 6f) |
| "Bidirectional sync impossible" (GAP-B5-BIDIR-001) | RESOLVED | Same as above -- owner decision (Section 6f) |
| "Widget persona shows Nexxus" (FR-P0-11) | DISPUTED | Widget header branding is a P1, not P0 |
| Platform readiness score 22/100 (FINAL_REPORT) | INVALID | Score contaminated by 8 tainted + 2 resolved findings |
| "All 12 P0 FIXED, 0 Blockers" (release_criteria header) | PARTIALLY INACCURATE | Original 12 were fixed, but additional P0s exist in current gap tracker |
| "Billing routes commented out as PHASE-FUTURE" | FALSE | Billing routes ARE registered (`routes.ts:178`, `App.tsx:95`) (Section 6g) |
| "handleEndOfCallReport is UPDATE-only" | FALSE | Code uses UPSERT (`ON CONFLICT DO UPDATE`) (Section 6h) |
| "VIN API has 48-hour data retention limit" | FALSE | VIN API has full history access (Section 6f) |
| "Goals tab should be removed from Insights" | FALSE | Goals tab is already absent from Insights (Section 6j) |

---

## 14. Known Gotchas Quick Reference

For agent convenience, consolidated from Sections 6 and 11.

| # | Gotcha | Section |
|---|--------|---------|
| 1 | VIN header: use lowercase `v3`, not uppercase `V3` | 6f |
| 2 | RLS variable mismatch: `current_organization_id` vs `current_org_id` | 6k |
| 3 | Excel upload: filter `source != 'excel_upload'` on ALL lead queries | 7f |
| 4 | VIN lead creation is two-step (contact then lead, href references) | 6f |
| 5 | 17/30 VIN endpoints return 403 | 6f |
| 6 | Context Router was inverted, now corrected (VIN primary) | 6i |
| 7 | Webhook route order matters (VAPI before body parsers) | 11e |
| 8 | TextMagic creds are per-org in DB, not in .env | 6d |
| 9 | CLAUDE.md is chmod 444 -- owner only | This notice |
| 10 | No 48-hour VIN retention limit (false claim) | 6f |
| 11 | VIN OAuth tokens expire every 60 minutes | 6f |
| 12 | Three governance layers historically stacked (.project/, .agent_docs/, filestore/) -- .project/ is NOT governance | 1c |

---

## 15. Economics Reference

| Service | Customer Price | Cost | Margin |
|---------|---------------|------|--------|
| Voice AI (VAPI) | $0.25/min | $0.15/min | 40% |
| Video AI (Tavus) | $0.32/min | $0.20/min | 37.5% |
| SMS (TextMagic) | $0.05/msg | $0.02/msg | 60% |

---

## 16. Backend Freeze Summary

If a file is NOT listed in DO_NOT_TOUCH.md Section 20 ("SAFE TO MODIFY"), it must not be modified. When in doubt, do not touch it.

**Frozen (345+ files):** server core, routes, services, middleware, auth, webhooks, websocket, jobs, utils (88 files), database migrations (38 files), shared schema (1 file), widget (17 files), build system (2 files), root configs (15 files), tests (65 files), scripts (19 files), documentation (100+ files).

**Safe to modify:** `client/` directory (~130 files) with constraints listed in Section 10b.

**Specific never-touch files:**
- `server/webhooks/vapi.ts` -- live VAPI webhook processing
- `server/webhooks/tavus.ts` -- live Tavus webhook with HMAC verification
- `server/db/SecureQueryBuilder.ts` -- RLS enforcement
- `server/middleware/enforceOrganizationContext.ts` -- org isolation
- `shared/schema.ts` -- Drizzle ORM schema
- `database/migrations/*` -- all 33 migration files
- `.env` -- production secrets

---

*End of agent operating rules. This file is the complete reference. An agent reading only this file has all operating constraints needed to work correctly on Nexxus V2.*
