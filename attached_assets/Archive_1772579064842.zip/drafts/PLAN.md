# Nexxus V2 — Execution Plan

**Authority:** This file is the single source of truth for gap status and build sequencing. It replaces `release_criteria.md` as the gap tracker. Read this file at the start of every session.

**Last Updated:** 2026-03-03
**Phase:** Incremental Build
**Cluster:** 0 (Foundation Fixes)
**Status:** NOT STARTED

---

## 1. Current Phase

| Field | Value |
|-------|-------|
| Phase Name | Incremental Build |
| Objective | Fix all payment-critical gaps, verify all 7 demo items end-to-end |
| Current Cluster | Cluster 0 — Foundation Fixes |
| Blocking Issues | None (Cluster 0 has no dependencies) |
| Next Milestone | Cluster 0 complete: hosted pages load, Insights doesn't crash, no vendor names in UI |

**How this phase works:** Gaps are organized into 8 clusters (0-7) with dependency ordering. Complete each cluster, verify its done-when criteria, then advance to the next. Owner verifies completion at each cluster boundary. Do not skip clusters.

---

## 2. Demo Readiness Summary

7 payment-critical demo items. These are the items that must work before a customer sees the product.

| # | Demo Item | Status | Blocking Gaps | Unblocked At |
|---|-----------|--------|---------------|--------------|
| 1 | Metrics & Insights display | PARTIAL | P0-2 (crash risk on empty data) | Cluster 1 |
| 2 | Communications Agent configuration | NOT WORKING | P0-4 (0 trigger executions), P1-2 (hot_lead no callsite) | Cluster 4 |
| 3 | Appointment flow -> calendar -> VIN note | PARTIAL | P0-3 (no status notifications), P0-5 (no VIN note link), P1-3 (appointment_created no callsite) | Cluster 3 |
| 4 | Proactive lead follow-up (outbound call + text) | NOT WORKING | P0-4 (0 trigger executions), operational config (VAPI phones, TextMagic creds) | Cluster 5 |
| 5 | Reactive after-hours coverage (SMS + phone) | NOT WORKING | P1-9 (SMS routing not wired), P0-4 (business hours blocking) | Cluster 6 |
| 6 | Widgets (all 3 deployment modes) | MOSTLY WORKING | P0-1 (hosted pages `/p/:slug` broken; `/w/:slug` works) | Cluster 0 |
| 7 | Automa Chat | WORKING | None | Already done |

**Bottom line:** 1 of 7 works (Automa Chat). 1 mostly works (Widgets — 1-line fix). 5 have blocking gaps.

---

## 3. Incremental Build Clusters

### Cluster 0: Foundation Fixes (Quick Wins)

**Goal:** Clear trivial P0s and safety issues in one pass. No feature dependencies.
**Estimated effort:** Small — mostly one-line fixes.

| Gap | Description | Fix |
|-----|-------------|-----|
| P0-1 | `/p/:slug` fetches wrong API path (`/api/hosted-pages/public/${slug}` vs server's `/api/pages/:slug`) | Change fetch URL in `hosted-page-public.tsx:163` OR add redirect `/p/:slug` -> `/w/:slug` |
| P0-2 | 5 unguarded `.pct` accesses in Insights (`insights.tsx:854,2087-2088,2136,2142-2143`) | Add optional chaining (`?.`) at each location |
| P1-13 | Vendor names visible in UI: "VIN Solutions" at `settings.tsx:1880,1982,1995`; "DealerBrain" at `activity.tsx:546` | Replace with user-facing names ("CRM" / "AI Assistant") in ~5 locations. Ref: AC-016 |

**Done-when criteria:**
1. Navigate to `/p/{any-slug}` — hosted page renders (no 404)
2. Open Insights page with zero or partial data — no crash, no white screen
3. Search all UI text for "VIN Solutions", "DealerBrain", "Tavus", "VAPI" — zero results visible to non-admin users

---

### Cluster 1: Metrics & Insights (DEMO-1)

**Goal:** Metrics and Insights display correctly with real data.
**Dependencies:** Cluster 0 (P0-2 null guards must be in place first)

| Gap | Description | Fix |
|-----|-------------|-----|
| P0-2 | Already fixed in Cluster 0 | -- |
| -- | Verify DealerPulse job runs and populates data | Check job interval in cron config, query DB for pulse snapshots |
| -- | Verify main dashboard tiles show real data (not static fallbacks) | Confirm API returns live values from DashboardService |

**Done-when criteria:**
1. Owner logs in and sees real metrics on dashboard tiles (not zeros, not placeholder text)
2. Insights page loads without crash risk
3. DealerPulse gauges show populated data
4. At least one report type (Loss/Channel/Trend) renders with data

---

### Cluster 2: Automa Chat Verification (DEMO-7)

**Goal:** Confirm Automa Chat works end-to-end. No code changes expected.
**Dependencies:** None (can run in parallel with any cluster)

| Gap | Description | Fix |
|-----|-------------|-----|
| -- | No code gaps found. Automa is the most complete feature. | Verification only |

**Verification checklist:**
- [ ] Send message to Automa, receive response
- [ ] Automa uses CRM data in response (tool calls execute)
- [ ] SSE streaming works (response appears incrementally, not all at once)
- [ ] Conversation history persists across page reloads
- [ ] Floating overlay opens and closes correctly

**Done-when criteria:**
1. Owner chats with Automa, gets a meaningful response that references real CRM data
2. All 5 verification items above checked off

---

### Cluster 3: Appointment Flow (DEMO-3)

**Goal:** Appointment creation -> calendar display -> notification -> VIN note sync.
**Dependencies:** Cluster 0

| Gap | Description | Fix |
|-----|-------------|-----|
| P0-3 | `updateAppointment()` in `AppointmentService.ts:663-750` fires no notifications or events | Add event emission (`appointment_status_change`) + trigger evaluation call to the update path |
| P0-5 | No appointment-to-VIN note pipeline. `AppointmentService.ts` has no import of `VinSolutionsService`, no `sync_queue` insert. | Add VIN sync queue insert from `createAppointment()`. Wire `VinSolutionsService` import. |
| P1-3 | `appointment_created` trigger event defined in `TriggerService.ts:25` but never emitted anywhere | Add `evaluateEvent('appointment_created')` call in appointment creation path |

**Done-when criteria:**
1. Create appointment -> appears in calendar view
2. Change appointment status -> notification fires (visible in notification panel or DB)
3. Create appointment -> note appears in VIN Solutions lead record (for orgs with VIN config)
4. Trigger rule matching `appointment_created` event -> action executes

---

### Cluster 4: Trigger System (DEMO-2, foundation for DEMO-4 and DEMO-5)

**Goal:** Make triggers actually execute in production. This cluster is the foundation for Clusters 5 and 6.
**Dependencies:** Cluster 0

| Gap | Description | Fix |
|-----|-------------|-----|
| P0-4 | Zero production trigger executions. Three root causes: (a) `lead_age_minutes` condition evaluated at import time when lead is 0 min old; (b) business hours skip blocks all rules if org hours not configured; (c) `hot_lead` event has no call site | (a) Fix condition logic to evaluate at re-evaluation time, not import time. (b) Verify org business hours config in DB; ensure test rules aren't all `businessHoursOnly: true`. (c) See P1-2 below. |
| P1-2 | `hot_lead` event type defined in `TriggerService.ts:24`, configurable in UI, but never emitted anywhere in codebase | Add emission call site — likely in VIN polling service when a lead matches hot criteria (score threshold or recency) |

**Done-when criteria:**
1. A new lead enters from VIN polling -> trigger rule matches -> action executes (call, SMS, or notification)
2. At least 1 real (non-test) trigger execution recorded in `trigger_execution_log`
3. `lead_age_minutes` condition correctly evaluates against current time (not import time)
4. Business hours check does not silently block all rules

---

### Cluster 5: Proactive Follow-up (DEMO-4)

**Goal:** New leads automatically get outbound call + text.
**Dependencies:** Cluster 4 (triggers must execute first)

| Gap | Description | Fix |
|-----|-------------|-----|
| -- | VAPI phone numbers must be configured per org | OPERATIONAL: Owner configures `phoneNumberId` in trigger rule `action_config` per org. Requires VAPI dashboard phone purchase. |
| -- | TextMagic credentials must be configured per org | OPERATIONAL: Populate `textmagic_config` table with per-org API key + secret (encrypted). |
| -- | Verify outbound call + SMS fire on new lead | End-to-end test after trigger system works and operational config is in place |

**Operational config required (owner action):**
- VAPI phone numbers purchased and assigned per org (see Operational Config Checklist below)
- TextMagic API credentials stored per org in DB
- Customer approval for trigger rule activation

**Done-when criteria:**
1. New VIN lead imported -> outbound VAPI call initiated to lead's phone number
2. Same lead -> TextMagic SMS sent with configured message
3. Both actions logged in `trigger_execution_log` with `status: completed`

---

### Cluster 6: After-Hours Coverage (DEMO-5)

**Goal:** SMS + phone AI coverage when dealership staff are unavailable.
**Dependencies:** Cluster 4 (triggers), Cluster 5 (SMS wiring must work)

| Gap | Description | Fix |
|-----|-------------|-----|
| P1-9 | SMS after-hours AI routing not wired. Migration 032 exists, state machine exists, but routing decision point not connected to org business hours + Claude Haiku. | Wire routing logic: inbound SMS -> check org business hours -> if outside hours -> route to AI responder (Claude Haiku) |
| -- | Business hours config must be set per org | OPERATIONAL: Verify org hours exist in DB for each customer org |

**Done-when criteria:**
1. Inbound SMS received outside business hours -> AI auto-response sent via TextMagic
2. Inbound call outside business hours -> AI handles (VAPI voice agent responds)
3. Same messages/calls during business hours -> routed to staff inbox (no AI auto-response)

---

### Cluster 7: Widgets Verification (DEMO-6)

**Goal:** All 3 widget deployment modes verified working.
**Dependencies:** Cluster 0 (hosted pages route fix)

| Gap | Description | Fix |
|-----|-------------|-----|
| P0-1 | Already fixed in Cluster 0 | -- |
| -- | Verify unified widget (bottom corner) loads on external site | OPERATIONAL: Test with widget embed code on a whitelisted domain |
| -- | Verify embed code mode works | OPERATIONAL: Test direct embed HTML snippet |
| -- | Verify hosted page renders at `/w/:slug` | Already works per code verification |
| -- | Domain whitelisting configured for customer domains | OPERATIONAL: Populate `allowedDomains` in widget config for each customer site |

**Done-when criteria:**
1. Hosted page at `/w/{slug}` renders with correct agent and branding
2. Hosted page at `/p/{slug}` also renders (after Cluster 0 fix)
3. Embed code pasted into external HTML page loads the widget
4. Unified (corner) widget appears on whitelisted external domain
5. Widget on non-whitelisted domain is blocked

---

## 4. Gap Tracker

This table is the single source of truth for all validated gaps. Update the Status column as work progresses. Do not add gaps here without evidence — see Retired Claims (Section 8) for claims that must NOT re-enter this tracker.

### P0 Gaps (Block Payment-Critical Demo)

| ID | Description | Evidence | Demo Impact | Cluster | Status | AC Ref |
|----|-------------|----------|-------------|---------|--------|--------|
| P0-1 | Hosted pages `/p/:slug` broken — client fetches `/api/hosted-pages/public/${slug}`, server serves `/api/pages/:slug` | `hosted-page-public.tsx:163` vs `routes.ts:175` | DEMO-6 (Widgets) | C0 | OPEN | AC-092+ |
| P0-2 | Insights crash risk — 5 unguarded `.pct` accesses without null/bounds checks | `insights.tsx:854,2087-2088,2136,2142-2143` | DEMO-1 (Metrics) | C0 | OPEN | AC-040+ |
| P0-3 | Appointment status change notifications missing — `updateAppointment()` fires nothing | `AppointmentService.ts:663-750` | DEMO-3 (Appointments) | C3 | OPEN | AC-068+ |
| P0-4 | Zero production trigger executions — condition timing bug + business hours skip + hot_lead no callsite | `lead_age_minutes` evaluates at import (age=0), business hours blocks all if unconfigured | DEMO-2, DEMO-4 | C4 | OPEN | AC-104+ |
| P0-5 | Appointment-to-VIN note link missing — no `VinSolutionsService` import, no `sync_queue` insert in `AppointmentService.ts` | Code inspection of `AppointmentService.ts` | DEMO-3 (Appointments) | C3 | OPEN | AC-068+ |
| P0-6 | VAPI webhook ingestion — code now has UPSERT (defensive), owner resolved config | Owner action + code update | Was DEMO-2/4 | -- | RESOLVED | -- |

### P1 Gaps (Important, Not Immediately Demo-Blocking)

| ID | Description | Evidence | Cluster | Status | AC Ref |
|----|-------------|----------|---------|--------|--------|
| P1-1 | RLS variable name mismatch — `SecureQueryBuilder.ts:244` sets `app.current_organization_id`, RLS policies check `app.current_org_id` | Code + `REVERSE_SRS_old.md:203-216` | Deferred | OPEN | -- |
| P1-2 | `hot_lead` event type — defined in `TriggerService.ts:24`, configurable in UI, never emitted anywhere | Code search: 0 call sites | C4 | OPEN | AC-104+ |
| P1-3 | `appointment_created` trigger event — defined in `TriggerService.ts:25`, no `evaluateEvent('appointment_created')` anywhere | Code search: 0 call sites | C3 | OPEN | AC-104+ |
| P1-4 | `updatePerformanceMetrics()` defined but never called — agent performance data always empty | `AgentService` method exists, 0 callers | Deferred | OPEN | -- |
| P1-5 | Mark Contacted doesn't write to VIN — local DB updated but VIN PUT endpoint never called | Code inspection | Deferred | OPEN | -- |
| P1-6 | Tavus: zero real video sessions captured — no V2 callback URLs, 5 personas named but not wired | 0 sessions in DB, 0 callback URLs | Deferred | OPEN | -- |
| P1-7 | 19-28% VIN lead capture gap — polling misses leads vs VIN API count over same 7-day window | `DATA_ACCURACY_REPORT.md:450-454` | Deferred | OPEN | -- |
| P1-8 | 38 unregistered VAPI assistant calls — calls from Elliott, Andor, Gabrielle not in agents table | `DATA_ACCURACY_REPORT.md:86-91` | Deferred | OPEN | -- |
| P1-9 | SMS after-hours AI routing not wired — migration 032 exists, state machine exists, routing decision not connected | Code inspection | C6 | OPEN | AC-083+ |
| P1-10 | Hub has 6 tabs, spec/RUI says 3 — `work-center.tsx:473-506` has calendar, tasks, hunches, approvals, communication, leads | Code vs RUI comparison | Deferred | OPEN | AC-012+ |
| P1-11 | Activity is standalone page, not Insights sub-tab — `App.tsx:109` renders `/activity` as standalone | Code vs RUI comparison | Deferred | OPEN | AC-012+ |
| P1-12 | Skills catalog has 4 seeds, not 74 — `migration 034` inserts only 4 skills | Migration inspection | Deferred | OPEN | -- |
| P1-13 | Vendor names visible in UI — "VIN Solutions" at `settings.tsx:1880,1982,1995`, "DealerBrain" at `activity.tsx:546` | Code search | C0 | OPEN | AC-016 |
| P1-14 | `idle_trigger_count` never resets — leads permanently stop getting follow-up after 3 attempts | Wave 5 analysis | Deferred | OPEN | AC-104+ |
| P1-15 | VAPI webhook security is soft-check only — `vapi.ts:140` proceeds without auth if header missing | Code inspection | Deferred | OPEN | -- |

### P2 Gaps (Documentation / Process / Coverage)

| ID | Description | Notes | Status |
|----|-------------|-------|--------|
| P2-1 | 20 feature areas have no acceptance criteria | Billing, profile CRUD, password reset, tracking pixel, knowledge base, email, Drive, reports PDF, VIN degradation, Context Router UI, SMS compliance, data health, kill switch, DealerPulse, product tour, comms defaults, voice after-hours, hunches, embed copy, search/Cmd+K | OPEN |
| P2-2 | 18 missing PRD information items | Subscription pricing, skills catalog content, inbox handoff mechanics, Super Admin capabilities, partner credit pools, orchestration agent, inventory data, org creation wizard, video agent config | OPEN |
| P2-3 | 10 architecture/spec contradictions unresolved | Hub tab count, table count, endpoint count, framework, agent architecture, goals location, Work Center vs Hub naming, SRS authority | OPEN |
| P2-4 | PM2 restart count (3,349) — stability unknown | 42h uptime at last check; if stabilized = historical artifact; if still looping = P0 | NEEDS VERIFICATION |

### P3 Gaps (Low Priority)

| ID | Description | Status |
|----|-------------|--------|
| P3-1 | No CI/CD pipeline — manual deploys only | OPEN |
| P3-2 | 7 npm dependency vulnerabilities (0 critical, 4 high) | OPEN |

---

## 5. Operational Config Checklist

These are not code fixes. They require owner action, customer input, or external dashboard configuration. Several clusters cannot complete without these.

| # | Config Item | Required For | Who Owns | Status |
|---|-------------|-------------|----------|--------|
| OC-1 | VAPI phone numbers purchased and assigned per org | DEMO-4 (Proactive Follow-up), DEMO-5 (After-Hours) | Owner (VAPI dashboard) | NOT DONE |
| OC-2 | TextMagic API credentials stored per org in `textmagic_config` table | DEMO-4 (Proactive Follow-up), DEMO-5 (After-Hours) | Owner (DB config) | NOT DONE |
| OC-3 | Business hours configured per org in database | DEMO-5 (After-Hours), Cluster 4 (trigger evaluation) | Owner (DB config) | NOT VERIFIED |
| OC-4 | Customer website domains provided and whitelisted in widget config | DEMO-6 (Widgets — embed and unified modes) | Customer -> Owner | NOT DONE |
| OC-5 | VIN Solutions credentials for Ford of Columbia and Hyundai of Columbia | VIN integration for 2 orgs | Customer -> Owner | NOT DONE |
| OC-6 | Customer approval for trigger rule activation | DEMO-4 (Proactive Follow-up) | Customer -> Owner | NOT DONE |
| OC-7 | VAPI dashboard: org-level server URL configured for webhook delivery | DEMO-2, DEMO-4 (call event ingestion) | Owner (VAPI dashboard) | NEEDS VERIFICATION |
| OC-8 | Lead source tagging decision for VIN insertion | VIN note writing (Cluster 3) | Owner decision | NOT DECIDED |

---

## 6. Watch Areas

These items are not demo-blocking but need attention. The agent should not prioritize these over cluster work, but should flag regressions or new information about them.

### Watch Area 1: Agent Defaults and Skills
- 12 active agents: 5 voice, 2 chat, 4 task, 0 video
- Skills catalog has only 4 seeds (P1-12) — users see a nearly empty catalog
- Agent status toggle bypasses provisioning (P1-1 from wave5)
- Video agents (Tavus) have 0 sessions — not in demo items, but broken
- **Flag if:** Any agent CRUD changes break existing agents or Automa

### Watch Area 2: Billing Flow
- CreditService exists and is wired (DO_NOT_TOUCH)
- 0/137 VAPI records have `credit_recorded=true` — blocked by P0-6 (now resolved)
- Credits page UI intentionally hidden (`App.tsx:106-114`)
- Revenue model defined: Voice $0.25/min, Video $0.32/min, SMS $0.05/msg
- **Flag if:** VAPI webhook fix (P0-6 resolved) doesn't trigger credit recording for new calls

### Watch Area 3: Unified Inbox Handoff
- InboxService exists with conversations, messages, assignment
- Widget -> inbox continuity is the intended architecture
- SMS conversations not visible (0 sends) — will populate after Cluster 5
- IMAP auth failure was causing PM2 crash-loops (may be resolved)
- **Flag if:** Widget chat conversations don't appear in staff inbox

### Watch Area 4: Super Admin Capabilities
- RBAC role level 1 = Super Admin, 14 admin API endpoints
- Cannot view other orgs' data (P1-7 from wave5)
- Undertested — no dedicated Super Admin test pass
- **Flag if:** Any RBAC changes affect Super Admin access

### Watch Area 5: Context Router
- 3 files: ContextRouterService.ts, SourceSelector.ts, CacheManager.ts
- Routes requests to VIN API (primary) or local DB (fallback)
- Marked "ALREADY CERTIFIED" in IMPLEMENTATION_PLAN.md
- CacheManager has false "48-hour API retention limit" comment
- May be affected by RLS variable name mismatch (P1-1)
- **Flag if:** Lead data queries return stale or incorrect results

---

## 7. Deferred Items

These are real gaps confirmed by evidence. They do not block any of the 7 demo items. Fix after payment is secured.

| ID | Description | Severity | Why Deferred |
|----|-------------|----------|-------------|
| P1-1 | RLS variable name mismatch (`app.current_organization_id` vs `app.current_org_id`) | P1 | System works via bypass; only matters if someone refactors to use SecureQueryBuilder |
| P1-4 | Agent performance metrics never populated (`updatePerformanceMetrics()` never called) | P1 | Analytics feature, not demo-critical |
| P1-5 | Mark Contacted doesn't write to VIN (local DB only) | P1 | CRM write-back is desirable but not in the 7 demo items |
| P1-6 | Tavus zero sessions — 5 personas named, none wired, 0 callback URLs | P1 | Video agents not in demo items |
| P1-7 | 19-28% VIN lead capture gap — polling timing/pagination issue | P1 | Polling works; gap is a tuning issue, not a blocker |
| P1-8 | 38 unregistered VAPI assistant calls (Elliott, Andor, Gabrielle) | P1 | Historical data issue, not forward-blocking |
| P1-10 | Hub has 6 tabs, RUI spec says 3 | P1 | UI mismatch — must fix per RUI, but cosmetic for demo purposes |
| P1-11 | Activity is standalone page, should be Insights sub-tab per RUI | P1 | UI consolidation — cosmetic for demo |
| P1-12 | Skills catalog has 4 seeds, not 74 | P1 | Skills selection not in demo items |
| P1-14 | `idle_trigger_count` never resets — leads stop getting follow-up after 3 attempts | P1 | Edge case; leads need 3+ idle cycles to hit this |
| P1-15 | VAPI webhook security is soft-check only (proceeds without auth if header missing) | P1 | Security hardening, not demo-blocking |
| P2-1 | 20 feature areas lack acceptance criteria | P2 | Governance files (PRD, SRS, SPEC, AC) address this |
| P2-2 | 18 missing PRD information items | P2 | PRD draft addresses this |
| P2-3 | 10 architecture/spec contradictions unresolved | P2 | SPEC draft addresses this |
| P2-4 | PM2 restart count — stability unknown | P2 | Needs live `pm2 status` check; if stable, historical artifact |
| P3-1 | No CI/CD pipeline | P3 | Infrastructure, not demo-blocking |
| P3-2 | 7 npm dependency vulnerabilities (0 critical, 4 high) | P3 | No critical CVEs; address post-launch |

---

## 8. Retired Claims (Do Not Re-Open)

These claims from prior sessions were proven false, tainted by architecture misunderstanding, or resolved by owner decision. They must NOT re-enter the gap tracker. If an agent or test run produces a finding that matches any of these, discard it and cite this section.

| # | Claim | Source | Verdict | Why It Is Wrong |
|---|-------|--------|---------|-----------------|
| R1 | "3/5 orgs missing chat agents" (GAP-B1-AGENT-001/002/003) | FINAL_REPORT (Run 2) | TAINTED | Automa IS the chat agent. It is present in every account via the homepage and popout. The agent that filed this did not understand the V1-to-V2 architecture: users create agents and add skills; Automa is the master chat agent, not a per-org DB record. |
| R2 | "No tools on any agent (tools=[])" (GAP-B1-SKILLS-001) | FINAL_REPORT (Run 2) | TAINTED | Tools are assigned at the widget/system level (7 tools in `chatEnabledTools` at `WidgetConfigService.ts:241`), not per-agent in the DB `tools` field. The empty DB field is by design. |
| R3 | "Agent instructions lack CRM/trigger documentation" (GAP-B1-INSTR-001/002) | FINAL_REPORT (Run 2) | TAINTED | Skills are prompt overlays on Automa at runtime. Measuring the raw DB `instructions` field does not reflect what the agent actually receives. The skill overlay system augments instructions dynamically. |
| R4 | "No trigger deduplication for active conversations" (GAP-B1-TRIGGER-001) | FINAL_REPORT (Run 2) | TAINTED | Two dedup mechanisms exist: (1) `TriggerService.ts:856-871` — execution log check, (2) `idleLeadChecker.ts:406-439` — idle count check. Both verified in code. |
| R5 | "TextMagic API returns 401" (GAP-B3-SMS-001) | FINAL_REPORT (Run 2) | TAINTED | The agent tested `.env` credentials. The TextMagic service uses per-org DB credentials (`TextMagicService.ts:223-232`, line 330 `decryptApiKey`). The `.env` creds are not used at runtime. |
| R6 | "VIN appointment sync missing" (GAP-B5-VIN-SYNC-001) | FINAL_REPORT (Run 2) | RESOLVED | VIN Solutions has no calendar API. Owner decision: platform calendar is standalone. This is not a bug. Marked N/A in `release_criteria.md` line 69. |
| R7 | "Bidirectional VIN sync impossible" (GAP-B5-BIDIR-001) | FINAL_REPORT (Run 2) | RESOLVED | Same as R6. VIN Solutions API limitation, not a platform gap. Owner confirmed. |
| R8 | "Widget persona shows Nexxus" (FR-P0-11) | FINAL_REPORT (Run 2) | DISPUTED | Widget header branding is a narrower issue than claimed. Severity is P1 (cosmetic), not P0. The claim overstated both scope and severity. |
| R9 | Platform readiness score 22/100 | FINAL_REPORT (Run 2) | INVALID | Score was contaminated by 8 tainted findings (R1-R5 above) + 2 resolved findings (R6-R7). Actual readiness is ~40-50% demo-ready per validated wave analysis. |
| R10 | "All 12 P0 FIXED, 0 Blockers" | release_criteria.md header | PARTIALLY INACCURATE | The original 12 P0s from the build sprint were fixed. But 5 new/incomplete P0s exist (P0-1 through P0-5 in this tracker). The header gave a false sense of completion. |

**Root cause of tainted claims (R1-R5):** The Run 2 testing agent did not understand the V1-to-V2 architecture transition. Specifically: (a) Automa-as-chat-agent model, (b) skills as prompt overlays not DB fields, (c) tools at widget level not agent level, (d) per-org DB credentials not .env credentials. These architectural facts are now documented in the governance files to prevent recurrence.

---

## 9. Cluster Dependency Graph

```
Cluster 0 (Foundation)
  |
  +---> Cluster 1 (Metrics/Insights — DEMO-1)
  +---> Cluster 3 (Appointments — DEMO-3)
  +---> Cluster 4 (Triggers — DEMO-2)
  |       |
  |       +---> Cluster 5 (Proactive Follow-up — DEMO-4)
  |               |
  |               +---> Cluster 6 (After-Hours — DEMO-5)
  +---> Cluster 7 (Widgets — DEMO-6)

Cluster 2 (Automa Chat — DEMO-7) — No dependencies, verify anytime
```

**Critical path:** Cluster 0 -> Cluster 4 -> Cluster 5 -> Cluster 6
This is the longest chain because DEMO-4 and DEMO-5 both depend on the trigger system working.

---

## 10. Progress Log

Update this section after each cluster completion. Format: date, cluster, outcome, evidence.

| Date | Event | Evidence |
|------|-------|----------|
| 2026-03-03 | PLAN.md created. Phase: Incremental Build. Starting at Cluster 0. | This file |

---

*End of Execution Plan. This file is read every session. The Gap Tracker (Section 4) is the single source of truth for gap status. The Retired Claims (Section 8) prevents tainted findings from re-entering the tracker.*
