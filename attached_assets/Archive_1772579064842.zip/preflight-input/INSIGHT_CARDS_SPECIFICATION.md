# Insight Cards Specification

**Document Version:** 1.0
**Date:** January 21, 2026
**Status:** To Be Merged into SRS v3.0

---

## Overview

Insight Cards are 3 default real-time data visualization cards on the Insights page showing key metrics.

**3 Card Types:**
1. **Voice Agent Card** - VAPI call history and statistics
2. **Video Data Card** - Tavus video conversation metrics
3. **VIN Solutions Lead Feed** - Live lead data from VIN CRM

---

## 1. Voice Agent Card

### Purpose
Display VAPI call history and statistics

### Data Source
- `vapi_call_logs` table
- `vapi_events` table

### Display Elements
- Call duration (total, average)
- Call status (completed, failed, in-progress)
- Call outcome (appointment scheduled, info provided, escalated)
- Sentiment analysis (if available)
- Audio playback UI (listen to recordings)
- Transcript viewer (expandable modal)

### Filters
- Date range (last 24h, 7d, 30d, custom)
- Assistant (filter by VAPI assistant ID)
- Outcome (filter by call result)
- Status (filter by call status)

### Real-Time Updates
- WebSocket subscription to `vapi_call_logs` table
- Update latency: <2 seconds
- Auto-refresh on new call event

### UI Mockup
```
┌─────────────────────────────────────────┐
│ 🎙️ Voice Agent Card                    │
├─────────────────────────────────────────┤
│ Calls Today: 47       Avg Duration: 3m  │
│ Completed: 42         Failed: 5         │
│                                         │
│ Recent Calls:                           │
│ ┌─────────────────────────────────────┐ │
│ │ John Doe          3m 24s    ✓       │ │
│ │ Appointment scheduled               │ │
│ │ [▶ Play]  [📄 Transcript]          │ │
│ ├─────────────────────────────────────┤ │
│ │ Jane Smith        1m 45s    ✗       │ │
│ │ Call dropped                        │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ [View All Calls →]                      │
└─────────────────────────────────────────┘
```

### API Requirements

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/v1/insights/voice-calls` | GET | Fetch call data |
| `/api/v1/insights/voice-calls/:callId/recording` | GET | Get audio URL |
| `/api/v1/insights/voice-calls/:callId/transcript` | GET | Get transcript |

**Query Parameters:**
- `orgId` - Organization ID (required)
- `dateRange` - ISO 8601 date range (default: last 30 days)
- `assistantId` - Filter by VAPI assistant
- `outcome` - Filter by call outcome
- `status` - Filter by call status
- `limit` - Pagination limit (default: 20, max: 100)
- `offset` - Pagination offset (default: 0)

### Database Queries

```sql
-- Call statistics
SELECT
  COUNT(*) as total_calls,
  AVG(duration_seconds) as avg_duration,
  COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_calls,
  COUNT(CASE WHEN status = 'failed' THEN 1 END) as failed_calls
FROM vapi_call_logs
WHERE organization_id = $1
  AND created_at >= $2
  AND created_at <= $3;

-- Recent calls (last 10)
SELECT
  id,
  customer_name,
  duration_seconds,
  status,
  outcome,
  sentiment,
  created_at
FROM vapi_call_logs
WHERE organization_id = $1
ORDER BY created_at DESC
LIMIT 10;
```

---

## 2. Video Data Card

### Purpose
Display Tavus video conversation metrics

### Data Source
- `tavus_events` table
- `tavus_personas` table

### Display Elements
- Video engagement time (total, average per session)
- Session count (active, completed)
- Conversation outcomes (engaged, disengaged, converted)
- Replay link (if available)
- Engagement score (calculated from watch time, interactions)

### Filters
- Date range (last 24h, 7d, 30d, custom)
- Persona (filter by Tavus persona ID)
- Outcome (filter by conversation result)

### Real-Time Updates
- WebSocket subscription to `tavus_events` table
- Update latency: <2 seconds
- Live session indicator (green dot for active sessions)

### UI Mockup
```
┌─────────────────────────────────────────┐
│ 🎥 Video Data Card                     │
├─────────────────────────────────────────┤
│ Sessions Today: 23    Avg Time: 2m 15s  │
│ Active Now: 2         Completed: 21     │
│                                         │
│ Engagement Chart:                       │
│ ┌─────────────────────────────────────┐ │
│ │   ▁▃▅▇█▇▅▃▁                        │ │
│ │   Last 7 Days                       │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ Recent Sessions:                        │
│ ┌─────────────────────────────────────┐ │
│ │ Customer A    2m 45s    Engaged     │ │
│ │ [🔄 Replay]                         │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ [View All Sessions →]                   │
└─────────────────────────────────────────┘
```

### API Requirements

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/v1/insights/video-sessions` | GET | Fetch session data |
| `/api/v1/insights/video-sessions/:sessionId/replay` | GET | Get replay URL |
| `/api/v1/insights/video-engagement-chart` | GET | Get chart data |

**Query Parameters:**
- `orgId` - Organization ID (required)
- `dateRange` - ISO 8601 date range (default: last 30 days)
- `personaId` - Filter by Tavus persona
- `outcome` - Filter by conversation outcome
- `limit` - Pagination limit (default: 20, max: 100)
- `offset` - Pagination offset (default: 0)

### Database Queries

```sql
-- Session statistics
SELECT
  COUNT(*) as total_sessions,
  AVG(engagement_time_seconds) as avg_engagement_time,
  COUNT(CASE WHEN status = 'active' THEN 1 END) as active_sessions,
  COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed_sessions
FROM tavus_events
WHERE organization_id = $1
  AND created_at >= $2;

-- Engagement chart (daily buckets)
SELECT
  DATE(created_at) as date,
  COUNT(*) as session_count,
  AVG(engagement_time_seconds) as avg_engagement
FROM tavus_events
WHERE organization_id = $1
  AND created_at >= $2
GROUP BY DATE(created_at)
ORDER BY date DESC;
```

---

## 3. VIN Solutions Lead Feed Card

### Purpose
Display live lead data from VIN CRM

### Data Source
- `unified_events` table (VIN webhook data)

### Display Elements
- Recent leads (last 24-48 hours)
- Lead score (calculated by VIN Solutions)
- Lead status (new, contacted, appointment set, lost)
- Lead source (web, phone, walk-in, referral)
- Quick actions (view details, assign to staff, update status)

### Filters
- Date range (last 24h, 48h, 7d, custom)
- Location (filter by dealership location)
- Status (filter by lead status)
- Source (filter by lead source)

### Real-Time Updates
- WebSocket subscription to `unified_events` table
- Filter: `event_type = 'vin_lead_created'`
- Update latency: <2 seconds
- Badge notification for new leads (unread count)

### UI Mockup
```
┌─────────────────────────────────────────┐
│ 🚗 VIN Solutions Lead Feed             │
├─────────────────────────────────────────┤
│ New Leads Today: 12   Hot Leads: 3      │
│                                         │
│ Recent Leads:                           │
│ ┌─────────────────────────────────────┐ │
│ │ 🔥 John Smith      Score: 95        │ │
│ │    2024 Civic - Web Lead            │ │
│ │    [View] [Assign] [Call]          │ │
│ ├─────────────────────────────────────┤ │
│ │ Jane Doe           Score: 72        │ │
│ │    2023 Accord - Phone Inquiry      │ │
│ │    [View] [Assign] [Call]          │ │
│ ├─────────────────────────────────────┤ │
│ │ Bob Johnson        Score: 58        │ │
│ │    2025 CR-V - Walk-in              │ │
│ │    [View] [Assign] [Call]          │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ [View All Leads →]                      │
└─────────────────────────────────────────┘
```

### API Requirements

| Endpoint | Method | Purpose |
|----------|--------|---------|
| `/api/v1/insights/vin-leads` | GET | Fetch lead data |
| `/api/v1/insights/vin-leads/:leadId` | GET | Get lead details |
| `/api/v1/insights/vin-leads/:leadId/assign` | POST | Assign lead to staff |
| `/api/v1/insights/vin-leads/:leadId/status` | PUT | Update lead status |

**Query Parameters:**
- `orgId` - Organization ID (required)
- `dateRange` - ISO 8601 date range (default: last 48 hours)
- `location` - Filter by dealership location
- `status` - Filter by lead status
- `source` - Filter by lead source
- `minScore` - Minimum lead score (0-100)
- `limit` - Pagination limit (default: 20, max: 100)
- `offset` - Pagination offset (default: 0)

### Database Queries

```sql
-- Lead statistics
SELECT
  COUNT(*) as total_leads,
  COUNT(CASE WHEN lead_score >= 80 THEN 1 END) as hot_leads,
  COUNT(CASE WHEN status = 'new' THEN 1 END) as new_leads
FROM unified_events
WHERE organization_id = $1
  AND event_type = 'vin_lead_created'
  AND created_at >= $2;

-- Recent leads (last 20)
SELECT
  id,
  customer_name,
  lead_score,
  vehicle_interest,
  lead_source,
  status,
  created_at
FROM unified_events
WHERE organization_id = $1
  AND event_type = 'vin_lead_created'
ORDER BY created_at DESC
LIMIT 20;
```

---

## Technical Requirements

### Real-Time Subscriptions
- Use Supabase real-time (WebSocket)
- Subscribe to specific tables with org filter
- Update UI <2 seconds after data change
- Handle reconnection on network loss

### Performance
- Initial load: <1 second
- Subsequent updates: <500ms
- Pagination: Load 10-20 records initially
- Infinite scroll for historical data

### Caching
- React Query: 30s stale time
- Redis: 60s cache for aggregated metrics
- Invalidate on new event

### Error Handling
- Show stale data with "Reconnecting..." indicator
- Fallback to polling if WebSocket fails
- Graceful degradation (show cached data)

### Accessibility
- Screen reader announcements for new leads
- Keyboard navigation for quick actions
- ARIA labels for all interactive elements

---

## Integration with InsightAgent

The InsightAgent (from NEXXUS_AGENTIC_IMPLEMENTATION_PLAN.md) will dynamically generate Insight Cards:

### Card Generation Example

```typescript
// InsightAgent generates card on demand
async function generateInsightCard(query: string, orgId: string): Promise<InsightCard> {
  // 1. Parse query to determine card type
  const cardType = classifyQuery(query);

  // 2. Query relevant data sources
  const data = await fetchCardData(cardType, orgId);

  // 3. Generate card schema
  const card: InsightCard = {
    id: uuidv4(),
    type: cardType,
    title: generateTitle(query),
    data,
    metrics: calculateMetrics(data),
    chart: cardType === 'voice_agent' ? generateCallChart(data) : undefined,
    refreshInterval: 30000, // 30s
    lastUpdated: new Date()
  };

  // 4. Store in database (if persistent)
  await db.insight_cards.create({ ...card, organization_id: orgId });

  // 5. Broadcast to frontend (WebSocket)
  await broadcastCardUpdate(orgId, card);

  return card;
}
```

### Card Schema

```typescript
interface InsightCard {
  id: string;
  type: 'voice_agent' | 'video_data' | 'vin_lead_feed' | 'custom';
  title: string;
  data: any; // Card-specific data structure
  metrics: {
    primary: { label: string; value: number | string };
    secondary?: { label: string; value: number | string }[];
  };
  chart?: {
    type: 'line' | 'bar' | 'pie' | 'area';
    data: any[];
  };
  actions?: {
    label: string;
    action: string; // 'view_all', 'filter', 'export'
  }[];
  refreshInterval?: number; // Milliseconds (30000 = 30s)
  lastUpdated: Date;
}
```

### Database Table

```sql
CREATE TABLE insight_cards (
  id UUID PRIMARY KEY,
  organization_id UUID REFERENCES organizations(id),
  card_type VARCHAR(50), -- 'voice_agent', 'video_data', 'vin_lead_feed', 'custom'
  title VARCHAR(255),
  config JSONB, -- Card configuration (filters, display options)
  position INT, -- Display order on Insights page
  is_default BOOLEAN DEFAULT false, -- 3 default cards vs user-created
  created_by UUID REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
```

---

**END OF SPECIFICATION**
