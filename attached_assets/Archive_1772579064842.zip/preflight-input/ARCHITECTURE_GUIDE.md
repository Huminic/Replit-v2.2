# Nexxus V2 - Architecture Guide

**Purpose**: Architectural blueprint for modular, themeable, testable implementation
**Date**: 2026-01-17
**Status**: Planning

---

## 1. User Interface & Navigation Architecture

Nexxus v2 uses a **ClickUp-inspired 3-pane layout** with context-aware view configurations.

## 1.1 Layout Architecture

### 3-Pane System

All pages use a flexible 3-pane grid:

```css
.app-layout {
  display: grid;
  grid-template-columns: [sidebar] 64px [left-pane] 240px [center-pane] 1fr [right-pane] 320px;
  height: 100vh;
}
```

**Panes:**
1. **Vertical Sidebar** (64px, fixed) - Main navigation menu
2. **Left Pane** (240-400px, resizable) - Contextual popout menus
3. **Center Pane** (flexible width, min 600px) - Primary content
4. **Right Pane** (320-500px, resizable) - Automa chat or contextual tools

**Responsive Breakpoints:**
- Mobile (<768px): Single pane (center), sidebar overlay
- Tablet (768-1024px): Sidebar + Center OR Sidebar + Center + Right (toggle)
- Desktop (>1024px): All panes visible

---

## 1.2 Vertical Sidebar (Main Navigation)

### Visual Structure

```
┌──────┐
│  ⌘   │  Search (⌘K)
├──────┤
│  🏠  │  Main (Home/Chat)
│ Main │
├──────┤
│  🤖  │  Agents
│Agent │
├──────┤
│  📁  │  Drive
│Drive │
├──────┤
│  📊  │  Insights
│Insig │
├──────┤
│  💼  │  Work Center
│ Work │
├──────┤
│  📋  │  Activity
│Activ │
├──────┤
│      │  (spacer)
├──────┤
│  ⚙️  │  System
│Systm │
├──────┤
│  👤  │  Profile
│User  │
└──────┘
```

### States

**Collapsed (Icon Only - 64px):**
- Shows icon only
- Tooltip on hover (300ms delay)
- Click to navigate

**Expanded (Icon + Text - 200px):**
- Shows icon + full text label
- User preference saved in localStorage
- Toggle button at bottom

### Popout Behavior

**Desktop (Hover):**
- Hover over menu item → Wait 300ms → Popout appears to right
- Popout stays open while hovering icon or popout
- Mouse leaves both → Wait 200ms → Close

**Mobile (Click):**
- Tap menu item → Toggle popout open/closed
- Tap outside → Close popout
- No hover behavior

---

## 1.3 Main Menu Items & Popout Menus

### 1.3.1 Main (Home/Chat)

**Icon:** 🏠
**Route:** `/`
**View Mode:** Chat Only (View A)

**Popout Menu:**
- 📌 Favorites (saved conversations)
- 💬 Message History (past 7 days)
- 🗂️ Recent Projects (if applicable)

**Layout:**
- Left Pane: Popout (favorites/history)
- Center Pane: Automa chat interface
- Right Pane: Not visible

---

### 1.3.2 Agents

**Icon:** 🤖
**Route:** `/agents`
**View Mode:** Heavy Chat Work (View D)

**Popout Menu:**
- 💬 Agent Chat (interact with specific agent)
- ➕ Create Agent
- 🔧 Interact With Agents (agent execution panel)
- 📜 Agent Templates (64+ skill templates)

**Layout:**
- Left Pane: Popout (agent list + message history separator)
- Center Pane: Agent configuration or chat
- Right Pane: Agent artifacts (execution logs, outputs)

---

### 1.3.3 Drive

**Icon:** 📁
**Route:** `/drive`
**View Mode:** Data Display (View B)

**Popout Menu:**
- 📂 My Files
- 🔗 Shared Files
- 📄 Templates (document templates)
- ☁️ Cloud Storage (connect Google Drive, Dropbox)

**Layout:**
- Left Pane: Folder tree + file filters
- Center Pane: File browser (grid or list view)
- Right Pane: Automa chat (file-related help)

---

### 1.3.4 Insights

**Icon:** 📊
**Route:** `/insights`
**View Mode:** Data Display (View B)

**Popout Menu:**
- 🔍 Insight Engine (generate custom insights)
- 🎯 Goals (set and track business goals)
- 📈 Saved Reports

**Layout:**
- Left Pane: Filters (date range, location, agent)
- Center Pane: 3 Insight Cards (Voice, Video, VIN Lead Feed)
- Right Pane: Automa chat (insight analysis help)

**Insight Cards:**
1. 🎙️ Voice Agent Card - VAPI call history
2. 🎥 Video Data Card - Tavus session metrics
3. 🚗 VIN Lead Feed - Live lead data

---

### 1.3.5 Work Center

**Icon:** 💼
**Route:** `/work-center`
**View Mode:** Sub Menu (View C)

**Popout Menu:**
- 💬 Messages (inbox from agents)
- 📅 Calendar (events, appointments)
- ✅ Tasks (agent-generated + manual)
- 💡 Hunches (AI insights)
- ✋ Approvals (pending approvals queue)

**Layout:**
- Left Pane: Tabs (Messages, Calendar, Tasks, Hunches, Approvals)
- Center Pane: Selected tab content
- Right Pane: Automa chat (workflow help)

---

### 1.3.6 Activity

**Icon:** 📋
**Route:** `/activity`
**View Mode:** Data Display (View B)

**Popout Menu:**
- 👤 Users (filter by user activity)
- 🤖 Agents (filter by agent activity)
- ⚙️ System (system-level events)
- 🔍 Advanced Filters

**Layout:**
- Left Pane: Filters (users, agents, event types, date range)
- Center Pane: Activity timeline (infinite scroll)
- Right Pane: Automa chat (activity analysis)

---

### 1.3.7 System (Bottom Menu)

**Icon:** ⚙️
**Route:** `/system`
**View Mode:** Sub Menu (View C)
**Access:** Super Admin, Partner Admin, Org Admin (limited)

**Popout Menu:**
- 👥 Users (user management)
- 🔧 Application Settings (org config, branding)
- 🛠️ Tools (integration configuration - Super Admin only)
- 📚 Knowledge (knowledge base upload)
- 💡 Hunch Configuration (hunch generation settings)
- 🏢 Partners (partner management - Super Admin only)

**Layout:**
- Left Pane: Settings sections
- Center Pane: Settings forms/tables
- Right Pane: Automa chat (config help)

---

### 1.3.8 Profile (Bottom Menu)

**Icon:** 👤 (User Avatar)
**Route:** `/profile`
**View Mode:** Sub Menu (View C)

**Popout Menu:**
- 📝 Profile CRUD (edit name, email, avatar)
- ⚙️ Preferences (notifications, theme, language)
- 🚪 Logout

**Layout:**
- Left Pane: Profile sections
- Center Pane: Profile form
- Right Pane: Automa chat (account help)

---

## 1.4 Top Bar (Persistent Across All Pages)

### Elements (Left to Right)

```
[Search ⌘K] [🔔 3] [💬 5] [📊] [🌓] [🔄 Acme Deal...▼] [👤]
```

**1. Global Search (⌘K)**
- Keyboard shortcut: Command+K (Mac), Ctrl+K (Windows)
- Opens command palette (fuzzy search)
- Search: Pages, agents, files, users, conversations

**2. Notifications (🔔)**
- Badge count: Unread notifications
- Dropdown: Last 10 notifications
- Types: Low credits, approvals required, task assigned
- Mark as read, dismiss, click to view

**3. Messages (💬)**
- Badge count: Unread messages from agents
- Dropdown: Last 10 messages from Automa/agents
- Click message → Navigate to conversation

**4. Feed (📊)**
- No badge (always live stream)
- Dropdown: Last 50 activity events
- Real-time updates (<2s latency)
- Shows org-wide activity

**5. Theme Toggle (🌓)**
- Click to toggle light/dark mode
- Stored in localStorage
- System default option (follows OS)

**6. Org Switcher (🔄)**
- **Visibility:** Only if user has 2+ assigned orgs
- **Display:** [Org Logo] "Org Name" ▼
- **Dropdown:** List of assigned orgs (with logos, checkmark on current)
- **Action:** Switch org → Confirmation modal → Context clear → Reload

**7. User Avatar (👤)**
- Display: User initials or profile picture
- Dropdown: Profile, Preferences, Logout

---

## 1.5 View Configurations (4 Types)

View mode is **auto-selected by route** (no manual toggle in MVP).

### View A: Chat Only

**When Used:** Landing page (`/`), standalone chat

**Layout:**
```
┌─────┬──────────────────────────┐
│ SB  │ Left Pane │ Center Pane  │
│     │ Popout    │ Chat         │
│     │ (Favs)    │ Interface    │
└─────┴──────────────────────────┘
```

**Panes:**
- Sidebar: Main menu
- Left: Popout menu (favorites, history)
- Center: Automa chat (full width focus)
- Right: **NOT VISIBLE**

---

### View B: Data Display

**When Used:** Reports (`/insights`), files (`/drive`), activity (`/activity`)

**Layout:**
```
┌─────┬────────┬──────────┬─────────┐
│ SB  │ Left   │ Center   │ Right   │
│     │ Filter │ Data     │ Chat    │
│     │ List   │ Display  │ Automa  │
└─────┴────────┴──────────┴─────────┘
```

**Panes:**
- Sidebar: Main menu
- Left: Selection list (filters, folder tree)
- Center: Data displayed (charts, tables, files)
- Right: Automa chat (contextual help)

---

### View C: Sub Menu Selections

**When Used:** Settings (`/system`), Work Center (`/work-center`)

**Layout:**
```
┌─────┬────────┬──────────┬─────────┐
│ SB  │ Left   │ Center   │ Right   │
│     │ Sectns │ Forms/   │ Chat    │
│     │ Tabs   │ Tables   │ Automa  │
└─────┴────────┴──────────┴─────────┘
```

**Panes:**
- Sidebar: Main menu
- Left: Settings sections or tabs
- Center: Forms, tables, configuration UI
- Right: Automa chat (config help)

---

### View D: Heavy Chat Work

**When Used:** Agents (`/agents`), Projects (future)

**Layout:**
```
┌─────┬────────┬──────────┬─────────┐
│ SB  │ Left   │ Center   │ Right   │
│     │ List + │ Chat     │ Artifs  │
│     │ Histy  │ Dialogue │ Light   │
└─────┴────────┴──────────┴─────────┘
```

**Panes:**
- Sidebar: Main menu
- Left: Selection list + separator + message history
- Center: Chat dialogue (main interaction)
- Right: Artifacts or light data display (context, logs)

---

## 1.6 Responsive Behavior

### Mobile (<768px)

**Layout:** Single pane (center pane only)

**Navigation:**
- Sidebar becomes hamburger menu (overlay)
- Left/Right panes accessible via bottom sheet or modal
- Top bar condensed (icons only, overflow menu)

**Org Switcher:** Icon only (org logo), dropdown on tap

---

### Tablet (768-1024px)

**Layout:** Sidebar + Center OR Sidebar + Center + Right (toggle)

**Navigation:**
- Sidebar visible (icon + text)
- Left pane: Collapsible (swipe or button)
- Right pane: Toggle visibility (button in top bar)

**Default:** Show Center + Right (hide Left)

---

### Desktop (>1024px)

**Layout:** All panes visible

**Navigation:**
- All panes resizable (drag separator)
- Pane widths saved in localStorage per user
- Default widths: Left 240px, Center flexible, Right 320px

---

## 1.7 State Management

### Pane Visibility

Stored in `ViewConfigurationContext`:

```typescript
interface ViewConfig {
  leftPaneVisible: boolean;
  rightPaneVisible: boolean;
  leftPaneWidth: number;  // 240-400px
  rightPaneWidth: number; // 320-500px
  sidebarExpanded: boolean;
}

// Per-page state
const viewConfigs: Record<string, ViewConfig> = {
  '/': { leftPaneVisible: true, rightPaneVisible: false, ... },
  '/insights': { leftPaneVisible: true, rightPaneVisible: true, ... },
  // ...
};
```

### Persistence

- `localStorage.setItem('viewConfig', JSON.stringify(viewConfigs))`
- Load on mount, apply per route
- User preferences override defaults

---

## 1.8 Accessibility

**Keyboard Navigation:**
- Tab order: Sidebar → Left Pane → Center Pane → Right Pane → Top Bar
- Arrow keys: Navigate menu items in sidebar
- Enter/Space: Activate menu item
- Escape: Close popovers/modals

**Screen Readers:**
- Landmark regions: `<nav>`, `<main>`, `<aside>`
- ARIA labels: "Main navigation", "Content area", "Chat assistant"
- Live regions: Announce new notifications, messages

**Focus Management:**
- Visible focus indicators (3:1 contrast)
- Skip links: "Skip to main content"
- Trap focus in modals

---

## 1.9 Implementation Reference

**Component Structure:**

```typescript
<AppLayout>
  <TopBar />
  <Sidebar />
  <LeftPane>
    {currentRoute.popoutMenu}
  </LeftPane>
  <CenterPane>
    {currentRoute.component}
  </CenterPane>
  <RightPane>
    {viewMode === 'CHAT_ONLY' ? null : <AutomaChat />}
  </RightPane>
</AppLayout>
```

**Route Configuration:**

```typescript
const routes = [
  { path: '/', viewMode: 'CHAT_ONLY', popoutMenu: <FavoritesMenu />, component: <HomePage /> },
  { path: '/agents', viewMode: 'HEAVY_CHAT_WORK', popoutMenu: <AgentsMenu />, component: <AgentsPage /> },
  { path: '/insights', viewMode: 'DATA_DISPLAY', popoutMenu: <FiltersMenu />, component: <InsightsPage /> },
  // ...
];
```

---


## 2. Theming Architecture (Easy Skinning)

### Design Token System

#### Token Structure

```typescript
// Design tokens separate from components
// tokens/theme.ts

export interface ThemeTokens {
  // Colors
  colors: {
    // Semantic colors (what, not how)
    brand: {
      primary: string;
      secondary: string;
      accent: string;
    };
    surface: {
      base: string;
      elevated: string;
      overlay: string;
    };
    text: {
      primary: string;
      secondary: string;
      disabled: string;
      inverse: string;
    };
    status: {
      success: string;
      warning: string;
      error: string;
      info: string;
    };
    interactive: {
      default: string;
      hover: string;
      active: string;
      disabled: string;
    };
  };

  // Typography
  typography: {
    fonts: {
      sans: string;
      mono: string;
      display: string;
    };
    sizes: {
      xs: string;
      sm: string;
      md: string;
      lg: string;
      xl: string;
      '2xl': string;
    };
    weights: {
      normal: number;
      medium: number;
      semibold: number;
      bold: number;
    };
    lineHeights: {
      tight: number;
      normal: number;
      relaxed: number;
    };
  };

  // Spacing
  spacing: {
    xs: string;
    sm: string;
    md: string;
    lg: string;
    xl: string;
    '2xl': string;
  };

  // Layout
  layout: {
    sidebarWidth: string;
    sidebarCollapsedWidth: string;
    topbarHeight: string;
    contentMaxWidth: string;
    borderRadius: {
      sm: string;
      md: string;
      lg: string;
      full: string;
    };
  };

  // Shadows
  shadows: {
    sm: string;
    md: string;
    lg: string;
    xl: string;
  };

  // Animations
  animations: {
    durations: {
      fast: string;
      normal: string;
      slow: string;
    };
    easings: {
      default: string;
      in: string;
      out: string;
      inOut: string;
    };
  };
}
```

#### Theme Provider Architecture

```typescript
// contexts/ThemeContext.tsx
import { createContext, useContext } from 'react';

interface ThemeConfig {
  mode: 'light' | 'dark';
  tokens: ThemeTokens;
  branding: {
    logo: string;
    favicon: string;
    companyName: string;
  };
}

const ThemeContext = createContext<ThemeConfig | null>(null);

export function ThemeProvider({
  children,
  theme
}: {
  children: React.ReactNode;
  theme: ThemeConfig;
}) {
  return (
    <ThemeContext.Provider value={theme}>
      <div className="theme-root" style={generateCSSVariables(theme.tokens)}>
        {children}
      </div>
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) throw new Error('useTheme must be used within ThemeProvider');
  return context;
}
```

#### Database-Driven Theming

```sql
-- Add to organizations table
ALTER TABLE organizations ADD COLUMN theme_config JSONB DEFAULT '{}';

-- Example theme_config structure:
{
  "mode": "light",
  "tokens": {
    "colors": {
      "brand": {
        "primary": "#0066cc",
        "secondary": "#004499",
        "accent": "#ff6600"
      }
    }
  },
  "branding": {
    "logo": "https://cdn.example.com/org-123/logo.svg",
    "favicon": "https://cdn.example.com/org-123/favicon.ico",
    "companyName": "Acme Dealership"
  }
}
```

#### Component Skinning Pattern

```typescript
// ❌ BAD: Hard-coded colors
function Button({ children }) {
  return (
    <button className="bg-blue-600 text-white">
      {children}
    </button>
  );
}

// ✅ GOOD: Semantic token-based
function Button({ children, variant = 'primary' }) {
  const { tokens } = useTheme();

  return (
    <button
      className="btn"
      style={{
        backgroundColor: variant === 'primary'
          ? tokens.colors.brand.primary
          : tokens.colors.interactive.default,
        color: tokens.colors.text.inverse
      }}
    >
      {children}
    </button>
  );
}

// ✅ BETTER: CSS Variables (preferred)
function Button({ children, variant = 'primary' }) {
  return (
    <button className={`btn btn-${variant}`}>
      {children}
    </button>
  );
}

/* CSS using variables */
.btn {
  background-color: var(--color-brand-primary);
  color: var(--color-text-inverse);
  border-radius: var(--border-radius-md);
  padding: var(--spacing-sm) var(--spacing-md);
  font-family: var(--font-sans);
  font-weight: var(--font-weight-medium);
  transition: all var(--animation-duration-fast) var(--animation-easing-default);
}

.btn:hover {
  background-color: var(--color-interactive-hover);
}
```

#### White-Label Configuration

```typescript
// services/branding.service.ts

export async function loadOrganizationTheme(orgId: string): Promise<ThemeConfig> {
  const org = await db.organizations.findUnique({
    where: { id: orgId },
    select: { theme_config: true }
  });

  // Merge with defaults
  return {
    mode: org.theme_config?.mode || 'light',
    tokens: mergeDeep(defaultTokens, org.theme_config?.tokens || {}),
    branding: {
      logo: org.theme_config?.branding?.logo || '/default-logo.svg',
      favicon: org.theme_config?.branding?.favicon || '/favicon.ico',
      companyName: org.theme_config?.branding?.companyName || 'Nexxus'
    }
  };
}
```

### Theme Switching

```typescript
// Allow runtime theme switching
function ThemeSettings() {
  const { theme, updateTheme } = useTheme();

  return (
    <div>
      <select
        value={theme.mode}
        onChange={(e) => updateTheme({ mode: e.target.value })}
      >
        <option value="light">Light</option>
        <option value="dark">Dark</option>
      </select>

      <ColorPicker
        label="Primary Brand Color"
        value={theme.tokens.colors.brand.primary}
        onChange={(color) => updateTheme({
          tokens: {
            ...theme.tokens,
            colors: {
              ...theme.tokens.colors,
              brand: {
                ...theme.tokens.colors.brand,
                primary: color
              }
            }
          }
        })}
      />
    </div>
  );
}
```

---

## 3. Modular Architecture & Layer Testing

### Layer Architecture (Clean Architecture + DDD)

```
┌────────────────────────────────────────────────────────────┐
│                    Layer 1: Presentation                    │
│  (UI Components, Pages, State Management, Routing)          │
│  Technology: Next.js 14 App Router, React, Tailwind         │
│  Test: Component tests, E2E tests                           │
└─────────────────────┬──────────────────────────────────────┘
                      │
┌─────────────────────▼──────────────────────────────────────┐
│                 Layer 2: Application                        │
│  (Use Cases, Business Logic, DealerBrain Orchestration)    │
│  Technology: TypeScript services, Claude SDK                │
│  Test: Integration tests, use case tests                   │
└─────────────────────┬──────────────────────────────────────┘
                      │
┌─────────────────────▼──────────────────────────────────────┐
│                   Layer 3: Domain                           │
│  (Entities, Domain Logic, Business Rules)                  │
│  Technology: Pure TypeScript, no dependencies               │
│  Test: Unit tests (pure functions)                         │
└─────────────────────┬──────────────────────────────────────┘
                      │
┌─────────────────────▼──────────────────────────────────────┐
│                Layer 4: Infrastructure                      │
│  (Database, External APIs, File Storage, Cache)             │
│  Technology: Supabase, VIN/VAPI/Tavus clients, Redis        │
│  Test: Integration tests with test doubles                 │
└────────────────────────────────────────────────────────────┘
```

### Module Breakdown

#### Core Modules (Foundation)

**Module 1: Authentication & Authorization**

The authentication module implements a 4-tier role-based access control system with granular page-level and resource-level permissions.

**4-Tier Role Hierarchy:**

| Role           | Level | Scope                                | Access Pattern                          |
| -------------- | ----- | ------------------------------------ | --------------------------------------- |
| Super Admin    | 1     | All organizations, system-wide       | Full platform configuration             |
| Partner Admin  | 2     | Assigned organizations only          | Multi-org management, no system access  |
| Org Admin      | 3     | Single organization                  | Organization management                 |
| Org Staff      | 4     | Single organization, limited access  | Day-to-day operations                   |

```
auth/
├── presentation/
│   ├── components/
│   │   ├── LoginForm.tsx
│   │   ├── MFASetup.tsx
│   │   ├── SessionExpiry.tsx
│   │   ├── OrgSwitcher.tsx          # NEW: Partner Admin multi-org switching
│   │   └── RoleGuard.tsx            # NEW: Page-level permission guard
│   └── pages/
│       ├── LoginPage.tsx
│       ├── RegisterPage.tsx
│       └── ResetPasswordPage.tsx
├── application/
│   ├── use-cases/
│   │   ├── login.use-case.ts
│   │   ├── logout.use-case.ts
│   │   ├── refresh-token.use-case.ts
│   │   ├── verify-mfa.use-case.ts
│   │   ├── switch-organization.use-case.ts    # NEW: Partner Admin org switching
│   │   └── check-permissions.use-case.ts       # NEW: Permission verification
│   └── services/
│       ├── jwt.service.ts
│       ├── session.service.ts
│       ├── rbac.service.ts                     # NEW: RBAC enforcement
│       └── permission.service.ts               # NEW: Page/resource permissions
├── domain/
│   ├── entities/
│   │   ├── User.ts
│   │   ├── Session.ts
│   │   ├── Role.ts
│   │   ├── PagePermission.ts                   # NEW: Page-level permissions
│   │   └── ResourcePermission.ts               # NEW: Resource-level permissions
│   ├── value-objects/
│   │   ├── Email.ts
│   │   ├── Password.ts
│   │   └── RoleLevel.ts                        # NEW: Role hierarchy enforcement
│   └── rules/
│       ├── partner-admin-constraints.rule.ts   # NEW: Partner Admin limitations
│       └── resource-visibility.rule.ts         # NEW: Resource access rules
└── infrastructure/
    ├── repositories/
    │   ├── user.repository.ts
    │   ├── session.repository.ts
    │   ├── page-permission.repository.ts       # NEW: Page permission queries
    │   └── resource-permission.repository.ts   # NEW: Resource permission queries
    ├── adapters/
    │   └── supabase-auth.adapter.ts
    └── middleware/
        ├── auth.middleware.ts
        ├── role-guard.middleware.ts            # NEW: Role-based route protection
        └── permission-guard.middleware.ts      # NEW: Permission-based access control

Tests:
✓ Unit: Password hashing, JWT generation, RBAC rules, permission logic
✓ Integration: Login flow, session management, org switching, permission checks
✓ E2E: Full login → MFA → dashboard flow → role-based navigation
```

**Partner Admin Constraints:**

The Partner Admin role is designed for partners who manage multiple customer organizations but should NOT have system-level access.

**What Partner Admin CAN do:**
- ✅ Manage users within assigned organizations
- ✅ Configure organization-level settings (branding, business rules)
- ✅ View analytics for assigned organizations
- ✅ Switch between assigned organizations
- ✅ Configure organization-level integrations (VIN, VAPI, Tavus credentials per org)

**What Partner Admin CANNOT do:**
- ❌ Add tools to system-level tool library
- ❌ Manage system-level external integration credentials
- ❌ Access system-wide configuration
- ❌ Modify platform security policies
- ❌ Access organizations not assigned to them
- ❌ Provision other Partner Admin users (only Super Admin can)

**Multi-Organization Switching:**

Partner Admin users can switch between assigned organizations using the organization switcher component:

```typescript
// Example: Partner Admin switching organizations
interface OrgSwitcherProps {
  currentOrgId: string;
  assignedOrgs: Organization[];
  onSwitch: (orgId: string) => void;
}

function OrgSwitcher({ currentOrgId, assignedOrgs, onSwitch }: OrgSwitcherProps) {
  // Displays dropdown of assigned organizations
  // Updates RLS context on switch
  // Logs switch in audit trail
  // Preserves session across switch
}
```

**Permission Enforcement Pattern:**

```typescript
// Page-level permission check
async function canAccessPage(userId: string, route: string): Promise<boolean> {
  const user = await getUserWithRole(userId);
  const permission = await getPagePermission(user.role, route);

  return permission?.can_access ?? false;
}

// Resource-level permission check
async function canAccessResource(
  userId: string,
  resourceType: string,
  resourceId: string,
  action: 'view' | 'edit' | 'delete'
): Promise<boolean> {
  const resource = await getResourcePermission(resourceType, resourceId);
  const user = await getUser(userId);

  // Check visibility rules
  if (resource.visibility === 'public') return true;
  if (resource.owner_id === userId) return true;
  if (resource.visibility === 'org_wide' && resource.organization_id === user.organization_id) {
    return true;
  }
  if (resource.visibility === 'shared') {
    const isSharedWithUser = resource.shared_with_users.includes(userId);
    const isSharedWithRole = resource.shared_with_roles.includes(user.role);
    return isSharedWithUser || isSharedWithRole;
  }

  return false;
}
```

**Module 2: Multi-Tenancy (Organizations)**

Multi-tenancy module handles organization isolation with special support for Partner Admin multi-organization switching.

```
organizations/
├── presentation/
│   ├── components/
│   │   ├── OrgSwitcher.tsx              # Dropdown for Partner Admin org switching
│   │   ├── OrgSettings.tsx
│   │   ├── LocationSelector.tsx
│   │   ├── PartnerOrgList.tsx           # NEW: List of assigned orgs for Partner Admin
│   │   └── OrgAccessIndicator.tsx       # NEW: Shows current org context
│   └── pages/
│       ├── OrganizationDashboard.tsx
│       └── PartnerDashboard.tsx         # NEW: Aggregated view for Partner Admins
├── application/
│   ├── use-cases/
│   │   ├── create-organization.use-case.ts
│   │   ├── switch-organization.use-case.ts
│   │   ├── manage-locations.use-case.ts
│   │   ├── assign-partner-org.use-case.ts        # NEW: Super Admin assigns org to Partner
│   │   └── get-partner-orgs.use-case.ts          # NEW: Get assigned orgs for Partner Admin
│   └── services/
│       ├── tenant-context.service.ts
│       └── partner-org-access.service.ts # NEW: Partner Admin org access control
├── domain/
│   ├── entities/
│   │   ├── Organization.ts
│   │   ├── Location.ts
│   │   └── PartnerOrgAssignment.ts      # NEW: Partner-to-Org mapping
│   ├── rules/
│   │   ├── data-isolation.rule.ts
│   │   └── partner-org-access.rule.ts   # NEW: Partner can only access assigned orgs
│   └── events/
│       └── org-switched.event.ts        # NEW: Audit trail for org switches
└── infrastructure/
    ├── repositories/
    │   ├── organization.repository.ts
    │   ├── location.repository.ts
    │   └── partner-org.repository.ts    # NEW: Partner org assignments
    └── middleware/
        ├── tenant-context.middleware.ts
        └── partner-org-guard.middleware.ts # NEW: Verify Partner can access org

Tests:
✓ Unit: Data isolation rules, tenant context, partner org access rules
✓ Integration: RLS verification, org switching, partner org assignment
✓ E2E: Multi-org user workflow, Partner Admin switching orgs, audit trail
```

**Multi-Organization Switching Architecture:**

Partner Admin users can seamlessly switch between assigned organizations:

```typescript
// Domain: Partner Organization Assignment
interface PartnerOrgAssignment {
  id: string;
  userId: string;           // Partner Admin user
  organizationId: string;   // Assigned organization
  assignedAt: Date;
  assignedBy: string;       // Super Admin who assigned
}

// Use Case: Switch Organization
interface SwitchOrganizationRequest {
  userId: string;
  targetOrgId: string;
}

interface SwitchOrganizationResponse {
  success: boolean;
  organizationId: string;
  organizationName: string;
  updatedContext: TenantContext;
  auditLogId: string;
}

async function switchOrganization(
  request: SwitchOrganizationRequest
): Promise<SwitchOrganizationResponse> {
  // 1. Verify user is Partner Admin
  const user = await userRepository.findById(request.userId);
  if (user.role !== 'partner_admin') {
    throw new UnauthorizedError('Only Partner Admins can switch organizations');
  }

  // 2. Verify Partner Admin has access to target org
  const hasAccess = await partnerOrgRepository.hasAccess(
    request.userId,
    request.targetOrgId
  );
  if (!hasAccess) {
    throw new ForbiddenError('Partner Admin not assigned to this organization');
  }

  // 3. Update session context
  const updatedContext = await tenantContextService.switchContext(
    request.userId,
    request.targetOrgId
  );

  // 4. Log org switch in audit trail
  const auditLogId = await auditLogRepository.create({
    userId: request.userId,
    action: 'organization_switched',
    resourceType: 'organization',
    resourceId: request.targetOrgId,
    details: {
      previousOrgId: updatedContext.previousOrgId,
      newOrgId: request.targetOrgId,
      switchedAt: new Date()
    }
  });

  // 5. Return updated context
  const org = await organizationRepository.findById(request.targetOrgId);
  return {
    success: true,
    organizationId: org.id,
    organizationName: org.name,
    updatedContext,
    auditLogId
  };
}

// Component: Organization Switcher
function OrgSwitcher() {
  const { user } = useAuth();
  const { currentOrg, switchOrganization } = useOrganizationContext();
  const { data: assignedOrgs } = useQuery(['partner-orgs', user.id], () =>
    getAssignedOrganizations(user.id)
  );

  if (user.role !== 'partner_admin') {
    return null; // Only show for Partner Admins
  }

  return (
    <Dropdown>
      <DropdownTrigger>
        <Button variant="ghost">
          {currentOrg.name} <ChevronDown />
        </Button>
      </DropdownTrigger>
      <DropdownContent>
        {assignedOrgs.map(org => (
          <DropdownItem
            key={org.id}
            selected={org.id === currentOrg.id}
            onClick={() => switchOrganization(org.id)}
          >
            {org.name}
          </DropdownItem>
        ))}
      </DropdownContent>
    </Dropdown>
  );
}
```

**Row-Level Security (RLS) with Partner Admin:**

```sql
-- RLS Policy: Partner Admin can access assigned organizations
CREATE POLICY partner_admin_access ON organizations
  FOR SELECT
  USING (
    -- Super Admin: all orgs
    (auth.role() = 'super_admin')
    OR
    -- Partner Admin: assigned orgs only
    (
      auth.role() = 'partner_admin'
      AND id IN (
        SELECT organization_id
        FROM partner_admin_organizations
        WHERE user_id = auth.uid()
      )
    )
    OR
    -- Org Admin/Staff: own org only
    (
      auth.role() IN ('org_admin', 'org_staff')
      AND id = auth.organization_id()
    )
  );

-- RLS Policy: Data scoped to current organization context
CREATE POLICY tenant_isolation ON conversations
  FOR ALL
  USING (
    organization_id = auth.organization_id()
    -- auth.organization_id() returns current session org context
    -- For Partner Admin, this is the org they've switched to
  );
```

**Session Context Management:**

```typescript
interface TenantContext {
  userId: string;
  role: 'super_admin' | 'partner_admin' | 'org_admin' | 'org_staff';
  organizationId: string;      // Current active organization
  previousOrgId?: string;      // Previous org (for audit)
  assignedOrgIds?: string[];   // All assigned orgs (Partner Admin only)
  switchedAt?: Date;           // When org was switched
}

class TenantContextService {
  async switchContext(userId: string, targetOrgId: string): Promise<TenantContext> {
    // Get current context from session
    const currentContext = await this.getCurrentContext(userId);

    // Validate switch is allowed
    if (currentContext.role === 'partner_admin') {
      if (!currentContext.assignedOrgIds?.includes(targetOrgId)) {
        throw new ForbiddenError('Organization not assigned to Partner Admin');
      }
    }

    // Create new context
    const newContext: TenantContext = {
      ...currentContext,
      previousOrgId: currentContext.organizationId,
      organizationId: targetOrgId,
      switchedAt: new Date()
    };

    // Update session
    await this.updateSession(userId, newContext);

    // Update JWT claims
    await this.updateJWTClaims(userId, {
      organization_id: targetOrgId,
      role: currentContext.role
    });

    return newContext;
  }
}
```

#### Integration Modules

**Module 3: VIN Solutions Integration**
```
integrations/vin/
├── presentation/
│   ├── components/
│   │   ├── VINStatus.tsx
│   │   ├── CustomerSync.tsx
│   │   └── AppointmentForm.tsx
│   └── pages/
│       └── VINIntegrationSettings.tsx
├── application/
│   ├── use-cases/
│   │   ├── create-customer.use-case.ts
│   │   ├── schedule-appointment.use-case.ts
│   │   └── sync-customers.use-case.ts
│   └── services/
│       ├── vin-oauth.service.ts
│       └── vin-sync.service.ts
├── domain/
│   ├── entities/
│   │   ├── VINCustomer.ts
│   │   └── VINAppointment.ts
│   └── mappers/
│       └── vin-customer.mapper.ts
└── infrastructure/
    ├── clients/
    │   └── vin-api.client.ts
    ├── repositories/
    │   └── vin-integration.repository.ts
    └── webhooks/
        └── vin-webhook.handler.ts

Tests:
✓ Unit: Data mapping, OAuth token refresh
✓ Integration: API calls with mocks
✓ E2E: Full customer creation → VIN sync
```

**Module 4: VAPI (Voice) Integration**
```
integrations/vapi/
├── presentation/
│   ├── components/
│   │   ├── VoiceAgentCard.tsx
│   │   ├── CallLog.tsx
│   │   └── PhoneNumberConfig.tsx
│   └── pages/
│       └── VoiceAssistantsPage.tsx
├── application/
│   ├── use-cases/
│   │   ├── create-assistant.use-case.ts
│   │   ├── make-call.use-case.ts
│   │   └── handle-webhook.use-case.ts
│   └── services/
│       └── vapi-assistant.service.ts
├── domain/
│   ├── entities/
│   │   ├── VoiceAssistant.ts
│   │   ├── Call.ts
│   │   └── PhoneNumber.ts
│   └── events/
│       └── call-completed.event.ts
└── infrastructure/
    ├── clients/
    │   └── vapi-api.client.ts
    └── webhooks/
        └── vapi-webhook.handler.ts

Tests:
✓ Unit: Assistant configuration, call state machine
✓ Integration: VAPI API calls, webhook processing
✓ E2E: Create assistant → make call → receive webhook
```

**Module 5: Tavus (Video) Integration**
```
integrations/tavus/
├── presentation/
│   ├── components/
│   │   ├── VideoPersonaCard.tsx
│   │   ├── ReplicaManager.tsx
│   │   └── ConversationViewer.tsx
│   └── pages/
│       └── VideoAssistantsPage.tsx
├── application/
│   ├── use-cases/
│   │   ├── create-persona.use-case.ts
│   │   ├── start-conversation.use-case.ts
│   │   └── handle-callback.use-case.ts
│   └── services/
│       └── tavus-persona.service.ts
├── domain/
│   ├── entities/
│   │   ├── VideoPersona.ts
│   │   ├── Replica.ts
│   │   └── VideoConversation.ts
│   └── events/
│       └── conversation-ended.event.ts
└── infrastructure/
    ├── clients/
    │   └── tavus-api.client.ts
    └── webhooks/
        └── tavus-callback.handler.ts

Tests:
✓ Unit: Persona configuration, conversation state
✓ Integration: Tavus API calls, callback processing
✓ E2E: Create persona → start conversation → embed test
```

#### Feature Modules

**Module 6: Conversations**
```
conversations/
├── presentation/
│   ├── components/
│   │   ├── ConversationList.tsx
│   │   ├── MessageThread.tsx
│   │   ├── ChatInput.tsx
│   │   └── ConversationFilters.tsx
│   └── pages/
│       ├── ChatPage.tsx
│       └── ConversationDetailPage.tsx
├── application/
│   ├── use-cases/
│   │   ├── list-conversations.use-case.ts
│   │   ├── send-message.use-case.ts
│   │   └── archive-conversation.use-case.ts
│   └── services/
│       ├── conversation.service.ts
│       └── real-time-sync.service.ts
├── domain/
│   ├── entities/
│   │   ├── Conversation.ts
│   │   └── Message.ts
│   ├── value-objects/
│   │   └── ConversationType.ts
│   └── events/
│       └── message-received.event.ts
└── infrastructure/
    ├── repositories/
    │   ├── conversation.repository.ts
    │   └── message.repository.ts
    └── real-time/
        └── supabase-realtime.adapter.ts

Tests:
✓ Unit: Message validation, conversation state
✓ Integration: Database queries, real-time updates
✓ E2E: Full conversation flow
```

**Module 7: Credits & Billing**
```
credits/
├── presentation/
│   ├── components/
│   │   ├── CreditBalance.tsx
│   │   ├── UsageChart.tsx
│   │   └── BillingHistory.tsx
│   └── pages/
│       └── BillingPage.tsx
├── application/
│   ├── use-cases/
│   │   ├── allocate-credits.use-case.ts
│   │   ├── consume-credits.use-case.ts
│   │   └── calculate-cost.use-case.ts
│   └── services/
│       ├── credit-tracking.service.ts
│       └── billing-calculator.service.ts
├── domain/
│   ├── entities/
│   │   ├── CreditPolicy.ts
│   │   ├── CreditAllocation.ts
│   │   └── CreditUsage.ts
│   └── rules/
│       └── credit-limit.rule.ts
└── infrastructure/
    └── repositories/
        ├── credit-policy.repository.ts
        └── credit-usage.repository.ts

Tests:
✓ Unit: Cost calculations, margin validation
✓ Integration: Credit consumption, balance tracking
✓ E2E: Full billing cycle
```

**Module 8: Agents & Skills**
```
agents/
├── presentation/
│   ├── components/
│   │   ├── AgentCard.tsx
│   │   ├── SkillLibrary.tsx
│   │   ├── AgentBuilder.tsx
│   │   └── PerformanceMetrics.tsx
│   └── pages/
│       ├── AgentsPage.tsx
│       └── AgentDetailPage.tsx
├── application/
│   ├── use-cases/
│   │   ├── create-agent.use-case.ts
│   │   ├── execute-agent.use-case.ts
│   │   └── assign-skills.use-case.ts
│   └── services/
│       ├── agent-orchestration.service.ts
│       └── skill-execution.service.ts
├── domain/
│   ├── entities/
│   │   ├── Agent.ts
│   │   ├── Skill.ts
│   │   └── AgentRun.ts
│   └── rules/
│       └── skill-chaining.rule.ts
└── infrastructure/
    ├── repositories/
    │   ├── agent.repository.ts
    │   └── skill.repository.ts
    └── executors/
        └── skill-executor.ts

Tests:
✓ Unit: Skill validation, agent configuration
✓ Integration: Agent execution, skill chaining
✓ E2E: Create agent → execute → view results
```

**Module 9: DealerBrain (AI Orchestration)**
```
dealerbrain/
├── presentation/
│   ├── components/
│   │   ├── CommandPalette.tsx
│   │   ├── AIChat.tsx
│   │   ├── ContextualSuggestions.tsx
│   │   └── FloatingBrainIcon.tsx
│   └── sidebar/
│       └── DealerBrainSidebar.tsx
├── application/
│   ├── use-cases/
│   │   ├── process-command.use-case.ts
│   │   ├── generate-suggestion.use-case.ts
│   │   └── execute-workflow.use-case.ts
│   └── services/
│       ├── claude-ai.service.ts
│       ├── context-manager.service.ts
│       └── workflow-orchestrator.service.ts
├── domain/
│   ├── entities/
│   │   ├── Command.ts
│   │   ├── Suggestion.ts
│   │   └── Workflow.ts
│   └── context/
│       └── page-context.ts
└── infrastructure/
    ├── ai/
    │   ├── claude-client.ts
    │   └── prompt-templates.ts
    └── memory/
        └── context-store.ts

Tests:
✓ Unit: Command parsing, context extraction
✓ Integration: AI API calls, workflow execution
✓ E2E: Full command → AI response → action
```

**Module 10: Reporting & Analytics**
```
reporting/
├── presentation/
│   ├── components/
│   │   ├── QueryBuilder.tsx
│   │   ├── Dashboard.tsx
│   │   ├── WidgetLibrary.tsx
│   │   └── ChartRenderer.tsx
│   └── pages/
│       ├── ReportsPage.tsx
│       └── DashboardEditor.tsx
├── application/
│   ├── use-cases/
│   │   ├── create-report.use-case.ts
│   │   ├── execute-query.use-case.ts
│   │   └── schedule-report.use-case.ts
│   └── services/
│       ├── query-builder.service.ts
│       └── export.service.ts
├── domain/
│   ├── entities/
│   │   ├── Dashboard.ts
│   │   ├── Widget.ts
│   │   └── Query.ts
│   └── builders/
│       └── query.builder.ts
└── infrastructure/
    ├── repositories/
    │   ├── dashboard.repository.ts
    │   └── widget.repository.ts
    └── exporters/
        ├── csv.exporter.ts
        ├── xlsx.exporter.ts
        └── pdf.exporter.ts

Tests:
✓ Unit: Query building, data transformation
✓ Integration: Query execution, exports
✓ E2E: Build report → execute → export
```

### Testing Strategy by Layer

#### Layer 1: Presentation Tests

**Component Tests (Jest + React Testing Library)**
```typescript
// Example: Button.test.tsx
describe('Button', () => {
  it('should render with correct theme colors', () => {
    const { getByRole } = render(
      <ThemeProvider theme={mockTheme}>
        <Button variant="primary">Click me</Button>
      </ThemeProvider>
    );

    const button = getByRole('button');
    expect(button).toHaveStyle({
      backgroundColor: mockTheme.tokens.colors.brand.primary
    });
  });
});
```

**E2E Tests (Playwright)**
```typescript
// Example: auth.e2e.ts
test('user can login and access dashboard', async ({ page }) => {
  await page.goto('/login');
  await page.fill('[name="email"]', 'user@example.com');
  await page.fill('[name="password"]', 'password123');
  await page.click('button[type="submit"]');

  // Should redirect to dashboard
  await expect(page).toHaveURL('/dashboard');
  await expect(page.locator('h1')).toContainText('Dashboard');
});
```

#### Layer 2: Application Tests

**Use Case Tests**
```typescript
// Example: login.use-case.test.ts
describe('LoginUseCase', () => {
  it('should return JWT token for valid credentials', async () => {
    const mockUserRepo = createMockUserRepository();
    const mockJWTService = createMockJWTService();

    const useCase = new LoginUseCase(mockUserRepo, mockJWTService);
    const result = await useCase.execute({
      email: 'user@example.com',
      password: 'password123'
    });

    expect(result.success).toBe(true);
    expect(result.data.token).toBeDefined();
  });
});
```

#### Layer 3: Domain Tests

**Pure Function Tests**
```typescript
// Example: Password.test.ts
describe('Password Value Object', () => {
  it('should reject weak passwords', () => {
    expect(() => Password.create('weak')).toThrow('Password too weak');
  });

  it('should hash strong passwords', () => {
    const password = Password.create('StrongP@ssw0rd!');
    expect(password.isHashed()).toBe(true);
    expect(password.matches('StrongP@ssw0rd!')).toBe(true);
  });
});
```

#### Layer 4: Infrastructure Tests

**Integration Tests with Test Doubles**
```typescript
// Example: user.repository.test.ts
describe('UserRepository', () => {
  let testDb: SupabaseClient;

  beforeAll(async () => {
    testDb = createTestDatabase();
  });

  it('should create user with RLS isolation', async () => {
    const repo = new UserRepository(testDb);
    const user = await repo.create({
      email: 'test@example.com',
      organizationId: 'org-123'
    });

    // Verify user can only access own org data
    const users = await repo.findByOrganization('org-456');
    expect(users).not.toContain(user);
  });
});
```

### Module Build Order (Dependency-Aware)

**Phase 1: Foundation (Weeks 1-2)**
1. Auth & Authorization (Module 1)
2. Multi-Tenancy (Module 2)
3. Theme System (setup)

**Phase 2: Integrations (Weeks 3-4)**
4. VIN Solutions (Module 3)
5. VAPI (Module 4)
6. Tavus (Module 5)

**Phase 3: Core Features (Weeks 5-6)**
7. Conversations (Module 6)
8. Credits & Billing (Module 7)
9. DealerBrain (Module 9) - Basic version

**Phase 4: Enhanced Features (Weeks 7-10)**
10. Agents & Skills (Module 8)
11. Reporting (Module 10)
12. DealerBrain (Module 9) - Advanced features

---

## 4. Fine-Grained Permissions Architecture

### Page-Level Permissions

Page-level permissions control which routes users can access based on their role.

**Permission Model:**

```typescript
interface PagePermission {
  id: string;
  role: 'super_admin' | 'partner_admin' | 'org_admin' | 'org_staff';
  pageRoute: string;              // e.g., '/settings/system', '/agents/create'
  canAccess: boolean;             // Can view the page
  canCreate: boolean;             // Can create resources on this page
  canEdit: boolean;               // Can edit resources on this page
  canDelete: boolean;             // Can delete resources on this page
}
```

**Example Permission Matrix:**

| Route                    | Super Admin | Partner Admin | Org Admin | Org Staff |
| ------------------------ | ----------- | ------------- | --------- | --------- |
| `/dashboard`            | Access      | Access        | Access    | Access    |
| `/agents`               | CRUD        | CRUD          | CRUD      | CR (View/Create only) |
| `/agents/create`        | Access      | Access        | Access    | Access    |
| `/settings/system`      | CRUD        | ❌ No Access   | ❌ No Access | ❌ No Access |
| `/settings/organizations` | CRUD      | CRU (Assigned orgs) | RU (Own org) | R (View only) |
| `/settings/users`       | CRUD        | CRUD (Assigned orgs) | CRUD (Own org) | R (View only) |
| `/settings/integrations` | CRUD       | ❌ No Access   | CRUD (Own org) | R (View only) |
| `/reports`              | CRUD        | CRUD          | CRUD      | CR (View/Create) |

**Permission Enforcement:**

```typescript
// Route Guard Component
function RouteGuard({ children, route }: { children: React.ReactNode; route: string }) {
  const { user } = useAuth();
  const { data: permission, isLoading } = useQuery(
    ['page-permission', user.role, route],
    () => checkPagePermission(user.role, route)
  );

  if (isLoading) return <LoadingSpinner />;

  if (!permission?.canAccess) {
    return <Navigate to="/403" replace />;
  }

  return <>{children}</>;
}

// Usage in routing
<Route path="/settings/system" element={
  <RouteGuard route="/settings/system">
    <SystemSettingsPage />
  </RouteGuard>
} />

// Permission-based UI elements
function AgentCard({ agent }: { agent: Agent }) {
  const { user } = useAuth();
  const { data: permission } = useQuery(
    ['page-permission', user.role, '/agents'],
    () => checkPagePermission(user.role, '/agents')
  );

  return (
    <Card>
      <CardHeader>{agent.name}</CardHeader>
      <CardContent>{agent.description}</CardContent>
      <CardActions>
        <Button>View</Button>
        {permission?.canEdit && <Button>Edit</Button>}
        {permission?.canDelete && <Button variant="danger">Delete</Button>}
      </CardActions>
    </Card>
  );
}
```

### Resource-Level Permissions

Resource-level permissions control access to individual resources (agents, files, workflows, dashboards).

**Permission Model:**

```typescript
interface ResourcePermission {
  id: string;
  resourceType: 'agent' | 'file' | 'template' | 'workflow' | 'dashboard';
  resourceId: string;
  organizationId: string;
  visibility: 'public' | 'private' | 'shared' | 'org_wide';
  ownerId: string;
  sharedWithUsers?: string[];     // User IDs for 'shared' visibility
  sharedWithRoles?: string[];     // Role names for 'shared' visibility
  createdAt: Date;
  updatedAt: Date;
}
```

**Visibility Levels:**

1. **public**: System-wide templates created by Super Admin
   - Accessible by all users across all organizations
   - Read-only for non-Super Admins
   - Example: System skill templates

2. **org_wide**: Organization-level resources
   - Accessible by all users within the organization
   - Editable by owner and Org Admins
   - Example: Organization brand templates

3. **shared**: Selectively shared resources
   - Accessible by owner + explicitly shared users/roles
   - Editable by owner only (shared users have read access)
   - Example: Shared agent configuration

4. **private**: User-owned resources
   - Accessible only by owner
   - Example: Personal dashboard

**Permission Check Logic:**

```typescript
interface ResourceAccessRequest {
  userId: string;
  userRole: string;
  userOrgId: string;
  resourceType: string;
  resourceId: string;
  action: 'view' | 'edit' | 'delete';
}

async function canAccessResource(request: ResourceAccessRequest): Promise<boolean> {
  const { userId, userRole, userOrgId, resourceType, resourceId, action } = request;

  // Get resource permission
  const resource = await resourcePermissionRepository.findByResource(
    resourceType,
    resourceId
  );

  if (!resource) {
    // No permission record = private by default
    return false;
  }

  // Super Admin can access everything
  if (userRole === 'super_admin') {
    return true;
  }

  // Owner always has full access
  if (resource.ownerId === userId) {
    return true;
  }

  // Check visibility
  switch (resource.visibility) {
    case 'public':
      // Everyone can view public resources
      if (action === 'view') return true;
      // Only owner/Super Admin can edit/delete
      return false;

    case 'org_wide':
      // Must be in same organization
      if (resource.organizationId !== userOrgId) return false;
      // All org users can view
      if (action === 'view') return true;
      // Only owner and Org Admins can edit/delete
      return userRole === 'org_admin';

    case 'shared':
      // Check if user is in shared list
      const isSharedWithUser = resource.sharedWithUsers?.includes(userId);
      const isSharedWithRole = resource.sharedWithRoles?.includes(userRole);
      if (!isSharedWithUser && !isSharedWithRole) return false;
      // Shared users can only view
      if (action === 'view') return true;
      return false;

    case 'private':
      // Only owner can access
      return false;

    default:
      return false;
  }
}

// Usage in component
function AgentDetailPage({ agentId }: { agentId: string }) {
  const { user } = useAuth();
  const { data: canEdit } = useQuery(
    ['resource-permission', user.id, 'agent', agentId, 'edit'],
    () => canAccessResource({
      userId: user.id,
      userRole: user.role,
      userOrgId: user.organizationId,
      resourceType: 'agent',
      resourceId: agentId,
      action: 'edit'
    })
  );

  return (
    <div>
      <AgentViewer agentId={agentId} />
      {canEdit && <AgentEditor agentId={agentId} />}
    </div>
  );
}
```

**Resource Sharing UI:**

```typescript
// Component: Share Resource Modal
function ShareResourceModal({
  resourceType,
  resourceId,
  currentVisibility,
  onClose
}: {
  resourceType: string;
  resourceId: string;
  currentVisibility: string;
  onClose: () => void;
}) {
  const [visibility, setVisibility] = useState(currentVisibility);
  const [sharedUsers, setSharedUsers] = useState<string[]>([]);
  const [sharedRoles, setSharedRoles] = useState<string[]>([]);

  const handleSave = async () => {
    await updateResourcePermission(resourceType, resourceId, {
      visibility,
      sharedWithUsers: sharedUsers,
      sharedWithRoles: sharedRoles
    });
    onClose();
  };

  return (
    <Modal onClose={onClose}>
      <ModalHeader>Share Resource</ModalHeader>
      <ModalBody>
        <FormGroup>
          <Label>Visibility</Label>
          <Select value={visibility} onChange={(e) => setVisibility(e.target.value)}>
            <Option value="private">Private (Only me)</Option>
            <Option value="org_wide">Organization-wide</Option>
            <Option value="shared">Shared with specific users/roles</Option>
            <Option value="public" disabled={!isSuperAdmin()}>
              Public (All organizations)
            </Option>
          </Select>
        </FormGroup>

        {visibility === 'shared' && (
          <>
            <FormGroup>
              <Label>Share with Users</Label>
              <UserMultiSelect
                value={sharedUsers}
                onChange={setSharedUsers}
                organizationId={currentOrg.id}
              />
            </FormGroup>

            <FormGroup>
              <Label>Share with Roles</Label>
              <CheckboxGroup>
                <Checkbox
                  checked={sharedRoles.includes('org_admin')}
                  onChange={(checked) =>
                    setSharedRoles(prev =>
                      checked ? [...prev, 'org_admin'] : prev.filter(r => r !== 'org_admin')
                    )
                  }
                >
                  Org Admins
                </Checkbox>
                <Checkbox
                  checked={sharedRoles.includes('org_staff')}
                  onChange={(checked) =>
                    setSharedRoles(prev =>
                      checked ? [...prev, 'org_staff'] : prev.filter(r => r !== 'org_staff')
                    )
                  }
                >
                  Org Staff
                </Checkbox>
              </CheckboxGroup>
            </FormGroup>
          </>
        )}
      </ModalBody>
      <ModalFooter>
        <Button variant="ghost" onClick={onClose}>Cancel</Button>
        <Button onClick={handleSave}>Save</Button>
      </ModalFooter>
    </Modal>
  );
}
```

**Permission Management (Super Admin Only):**

```typescript
// Super Admin can configure default page permissions
function PermissionManagementPage() {
  const { data: permissions } = useQuery('page-permissions', getPagePermissions);

  return (
    <div>
      <h1>Permission Management</h1>
      <PermissionMatrix permissions={permissions} />
    </div>
  );
}

function PermissionMatrix({ permissions }: { permissions: PagePermission[] }) {
  const routes = Array.from(new Set(permissions.map(p => p.pageRoute)));
  const roles = ['super_admin', 'partner_admin', 'org_admin', 'org_staff'];

  return (
    <Table>
      <TableHead>
        <TableRow>
          <TableCell>Route</TableCell>
          {roles.map(role => (
            <TableCell key={role}>{role}</TableCell>
          ))}
        </TableRow>
      </TableHead>
      <TableBody>
        {routes.map(route => (
          <TableRow key={route}>
            <TableCell>{route}</TableCell>
            {roles.map(role => {
              const permission = permissions.find(
                p => p.pageRoute === route && p.role === role
              );
              return (
                <TableCell key={role}>
                  <PermissionBadge permission={permission} />
                </TableCell>
              );
            })}
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}
```

---

## Summary

### 1. User Interface & Navigation
- **ClickUp-style vertical menu** with 7 main items + 2 bottom items (icon + text, collapsible to icon-only)
- **3-pane layout system** with resizable left (200-400px) and right (250-500px) panes
- **4 view configurations** (Chat Only, Data Display, Sub Menu, Heavy Chat Work)
- **Persistent top bar** with 7 elements (Notifications, Messages, Feed, Org Switcher, Theme, Help, User Avatar)
- **Responsive design** (Mobile: single pane, Tablet: dual pane, Desktop: 3-pane)
- **Navigation state management** with localStorage persistence and ViewConfigurationContext
- **Keyboard navigation** and full ARIA accessibility support

### 2. Theming
- **Design token system** with CSS variables
- **Database-driven** theme config per organization
- **Semantic tokens** (brand, surface, text, status, interactive)
- **White-label ready** (logo, colors, fonts configurable)

### 3. Modular Architecture
- **4 layers**: Presentation → Application → Domain → Infrastructure
- **10 core modules**: Auth, Multi-Tenancy, VIN, VAPI, Tavus, Conversations, Credits, Agents, DealerBrain, Reporting
- **Test at each layer**: Component, Use Case, Unit, Integration, E2E
- **Dependency-aware build order**: Foundation → Integrations → Features → Enhancements

### 4. RBAC & Permissions (4-Tier System)
- **4 roles**: Super Admin (L1), Partner Admin (L2), Org Admin (L3), Org Staff (L4)
- **Partner Admin**: Multi-org management without system access
- **Page-level permissions**: Route-based access control per role
- **Resource-level permissions**: Visibility (public, org_wide, shared, private)
- **Multi-org switching**: Partner Admin can switch between assigned organizations
- **Audit trail**: All org switches and permission changes logged

This architecture enables:
- ✅ Parallel development (modules are independent)
- ✅ Easy skinning (theme tokens + database config)
- ✅ Layer-by-layer testing (catch issues early)
- ✅ Incremental delivery (module by module)
- ✅ Clean separation of concerns
- ✅ Future extensibility (new modules, new skins)
- ✅ Granular access control (page + resource level)
- ✅ Partner management (multi-org without system risk)
- ✅ Security by default (permission checks at every layer)
