# **—>Tiles - Available data. **  
  
  
  
This goes on to the Insights library page  
  
**Pipeline Volume & Velocity Metrics**  
1. **Total Active Pipeline** - Count of leads where leadStatusType = "ACTIVE"  
2. **Daily New Lead Volume** - Count of leads created per day from createdUtc  
3. **Weekly Lead Trend** - 7-day rolling average of new leads  
4. **Month-over-Month Lead Growth** - % change in lead volume comparing current 30 days vs previous 30 days  
5. **Lead Velocity Rate** - Average leads per day over trailing 30/60/90 days  
6. **Pipeline Stagnation Index** - Count of ACTIVE leads older than 30 days  
7. **Fresh Lead Ratio** - % of leads created in last 7 days vs total active pipeline  
**Conversion & Win Rate Metrics**  
1. **Overall Win Rate** - SOLD / (SOLD + LOST) from leadStatusType  
2. **Close Rate by Lead Type** - Win rate segmented by leadType (INTERNET vs WALK_IN vs PHONE)  
3. **Digital vs Physical Close Rate** - Win rate comparing INTERNET/WEBSITE_CHAT vs WALK_IN  
4. **Service-to-Sales Conversion** - % of SERVICE type leads that become SOLD  
5. **Hot Lead Conversion Rate** - Win rate for leads where isHot = true vs false  
6. **Showroom Conversion Rate** - Win rate for leads where isOnShowroom = true  
7. **Loss Rate** - LOST / (SOLD + LOST + ACTIVE)  
8. **Bad Lead Rate** - BAD / Total leads (quality indicator)  
**Response & Engagement Metrics**  
1. **Contact Rate** - % of leads in leadGroupCategory = "CONTACTED" vs "NEW"  
2. **New Lead Aging** - Average age (days) of leads still in "NEW" category  
3. **Response Gap Count** - Number of leads in "NEW" status older than 24/48/72 hours  
4. **Waiting Lead Volume** - Count of leads in "WAITING" status (implies ball in customer's court)  
5. **Engagement Transition Rate** - % of leads that move from NEW → CONTACTED within X hours  
6. **Average Time to First Contact** - Mean hours from createdUtc to status change from NEW  
**Lead Source Performance Metrics**  
1. **Lead Source Distribution** - % breakdown by leadSourceId  
2. **Top 3 Sources by Volume** - Which leadSourceName values generate most leads  
3. **Source Win Rate Analysis** - Close rate per leadSourceId  
4. **Source ROI Proxy** - SOLD count / Total leads per source (conversion efficiency)  
5. **Source Diversity Score** - Number of active lead sources / total available sources  
6. **Source Concentration Risk** - % of leads from single largest source (over-reliance indicator)  
7. **Underperforming Source Identification** - Sources with win rate below dealership average  
8. **Source Quality Score** - (SOLD count - BAD count) / Total per source  
**Lead Type & Channel Metrics**  
1. **Digital Lead Percentage** - (INTERNET + WEBSITE_CHAT) / Total leads  
2. **Walk-In Traffic Volume** - Count of WALK_IN type leads (showroom health)  
3. **Phone Inquiry Rate** - Count of PHONE type leads  
4. **Referral Lead Count** - Count of REFERRAL type leads (customer satisfaction proxy)  
5. **Previous Customer Return Rate** - PREVIOUS_CUSTOMER type as % of total  
6. **Service Lane Cross-Sell** - SERVICE leads / Total leads (parts/service → sales opportunity)  
7. **Channel Win Rate Comparison** - Win rate by each leadType value  
**Vehicle Interest & Inventory Metrics**  
1. **New vs Used Interest** - % breakdown by inventoryType from vehicles of interest  
2. **Average Vehicle MSRP** - Mean of msrp values where not null  
3. **Price Point Distribution** - Lead count grouped by MSRP bands ($0-25k, $25-40k, $40-60k, $60k+)  
4. **Top 5 Makes in Demand** - Most frequent make values from vehicles of interest  
5. **Top 5 Models in Demand** - Most frequent model values  
6. **Luxury vs Economy Mix** - % of high-end makes (Mercedes, BMW, Lexus) vs volume brands  
7. **Trade-In Penetration** - % of leads with non-empty tradeVehicles array  
8. **Average Down Payment Request** - Mean of downPaymentRequested where not null  
9. **Cash vs Finance Preference** - Distribution of paymentMethod values  
10. **High-Value Lead Count** - Leads with msrp > $60,000  
11. **Vehicle Availability Match** - % of leads with VIN populated (in-stock vs special order)  
**Lead Age & Lifecycle Metrics**  
1. **Average Lead Age** - Mean days from createdUtc to current date for ACTIVE leads  
2. **Lead Age Distribution** - Count in buckets: 0-7 days, 8-14, 15-30, 31-60, 60+ days  
3. **Overdue Lead Count** - ACTIVE leads older than 14 days  
4. **Stale Lead Percentage** - ACTIVE leads older than 30 days / Total ACTIVE  
5. **Lead Lifespan (Closed)** - Average days from createdUtc to SOLD status  
6. **Lead Lifespan (Lost)** - Average days from createdUtc to LOST status  
7. **Fast Close Rate** - % of SOLD leads closed within 7 days of creation  
**Lead Status & Stage Metrics**  
1. **Status Distribution Breakdown** - Count per each of 38 leadStatus values  
2. **Appointment Set Count** - Leads in "ACTIVE_SET_APPOINTMENT" status  
3. **Waiting for Response Volume** - "ACTIVE_WAITING_FOR_PROSPECT_RESPONSE" count  
4. **Pending Finance Count** - "SOLD_PENDING_FINANCE" status count  
5. **Delivered Count (Current Month)** - "SOLD_DELIVERED" status in period  
6. **Lost Reason Analysis** - Distribution across LOST_* subcategories  
7. **Bad Lead Reason Analysis** - Distribution across BAD_* subcategories  
8. **No Response Loss Rate** - "LOST_DID_NOT_RESPOND" / Total LOST  
9. **Credit Issue Loss Rate** - "LOST_BAD_CREDIT" / Total LOST  
10. **Competitive Loss Rate** - (LOST_PURCHASED_SAME_BRAND + LOST_PURCHASED_DIFFERENT_BRAND) / Total LOST  
**Dealership Operational Metrics**  
1. **Staff Roster Size** - Count of users from /tenant/user  
2. **Salesperson Count** - Users where IlmAccess = "SalesPerson"  
3. **Manager Count** - Users where IlmAccess = "Manager"  
4. **Orphaned User Count** - Users in "12- Orphan" UserGroup (process issue indicator)  
5. **Active User Percentage** - Users with EmailAddress not null / Total users  
**Hot Lead & Priority Metrics**  
1. **Hot Lead Volume** - Count where isHot = true  
2. **Hot Lead Percentage** - Hot leads / Total ACTIVE leads  
3. **Hot Lead Close Rate** - SOLD hot leads / Total hot leads  
4. **Hot Lead Age** - Average age of hot leads still ACTIVE  
5. **Showroom Visit Count** - Leads where isOnShowroom = true  
6. **Showroom Close Rate** - SOLD showroom leads / Total showroom leads  
**Time-Based Comparison Metrics**  
1. **Current vs Previous Month Win Rate** - Trend direction  
2. **YoY Lead Volume Growth** - This month vs same month last year  
3. **Quarter-over-Quarter Pipeline Growth** - Q current vs Q previous  
4. **Weekend vs Weekday Lead Volume** - Leads by day of week from createdUtc  
5. **After-Hours Lead Volume** - Leads created outside business hours (6pm-8am)  
**Lead Quality Indicators**  
1. **Lead Quality Score** - (SOLD + ACTIVE) / (SOLD + ACTIVE + LOST + BAD)  
2. **First-Time vs Repeat Customer Mix** - PREVIOUS_CUSTOMER / Total  
3. **In-Market Signal Strength** - % with VIN specified (serious shoppers)  
4. **Budget Clarity Rate** - % with monthlyPaymentRequested or downPaymentRequested not null  
5. **Vehicle Specificity Score** - % with trim level specified (detailed interest)  
**Multi-Dealership Comparison Metrics (if applicable)**  
1. **Cross-Store Lead Volume Ranking** - Using /organization/dealers DealerId  
2. **Store Performance Variance** - Standard deviation of win rates across dealerships  
3. **Best Performing Store** - Highest win rate from DealerId comparison  
4. **Market Penetration by Location** - Lead volume per store by City/State  
**Advanced Composite Metrics**  
1. **Pipeline Efficiency Score** - (SOLD count / ACTIVE count) × (1 - Avg Age/30)  
2. **Lead Momentum Index** - (7-day lead volume / 30-day average) × Contact Rate  
3. **Conversion Funnel Health** - (CONTACTED/NEW) × (SOLD/CONTACTED)  
4. **Sales Velocity** - SOLD count / Average days to close  
5. **Lead Saturation Index** - ACTIVE count / Salesperson count (workload indicator)  
6. **Digital Maturity Score** - (Digital leads / Total) × (Digital win rate / Overall win rate)  
**Predictive & Forecasting Metrics**  
1. **Projected Month-End Close Count** - Current SOLD + (ACTIVE × Historical win rate)  
2. **Pipeline Coverage Ratio** - ACTIVE leads / Monthly SOLD target  
3. **Lead Burn Rate** - Rate at which ACTIVE leads move to SOLD or LOST  
4. **Forecasted Lead Volume (Next 30 Days)** - Based on trailing 90-day trend  
5. **At-Risk Lead Count** - ACTIVE leads older than average time-to-close (likely to be lost)  
