# VIN Solutions Integration - V2

**Status:** ✅ Complete
**Date:** 2026-01-28
**Phase:** Sprint 2 - Step 2.1

## Overview

The VIN Solutions OAuth integration has been successfully ported from v1 to v2. This integration provides:

- OAuth2 authentication with encrypted token storage
- Automatic token refresh (every 6 hours)
- VIN Solutions API client for leads and dealer management
- Complete audit logging of all OAuth operations

## Architecture

### Files Created

#### 1. Core Services
- **`server/services/vinSolutionsService.ts`** (592 lines)
  - OAuth2 authentication flow
  - Token management with auto-refresh
  - VIN Solutions API methods (dealers, leads, webhooks)
  - Token encryption/decryption

- **`server/services/vinOAuthService.ts`** (156 lines)
  - Automatic token refresh logic
  - Checks all active VIN integrations
  - Refreshes tokens within 24 hours of expiry
  - Audit logging for all refresh attempts

#### 2. Background Jobs
- **`server/jobs/vinTokenRefreshJob.ts`** (193 lines)
  - Scheduled job running every 6 hours
  - Uses native Node.js intervals (no Redis dependency)
  - Runs on server startup and every 6 hours thereafter
  - Logs all operations to audit_log table

#### 3. Utilities
- **`server/utils/encryption.ts`** (73 lines)
  - AES-256-GCM encryption for OAuth tokens
  - Derived key from SESSION_SECRET
  - Identical to v1 implementation for compatibility

#### 4. Database Layer
- **`server/db.ts`** (170 lines)
  - Database connection pool (PostgreSQL)
  - Storage interface for integrations table
  - Audit log creation methods
  - Type-safe interfaces for Integration and AuditLog

#### 5. API Routes
- **`server/routes/vin.ts`** (189 lines)
  - POST `/api/vin/initialize` - Initialize OAuth connection
  - GET `/api/vin/integrations` - List organization's VIN integrations
  - GET `/api/vin/test/dealers/:integrationId` - Test VIN API (dealers)
  - GET `/api/vin/test/leads/:integrationId` - Test VIN API (leads)
  - POST `/api/vin/refresh-tokens` - Manually trigger token refresh
  - GET `/api/vin/job-status` - Check token refresh job status

## Configuration

### Environment Variables

Added to `.env`:
```bash
VIN_SOLUTIONS_CLIENT_ID=4262c0e318d147d6baf6362c61c533d2
VIN_SOLUTIONS_CLIENT_SECRET=pI2QIp5cVuq9C7ctoJNXncCvgWD2xKwG
VIN_SOLUTIONS_API_KEY=ZDz7G7yp8UnovMlGSqXP1H7ZGp7jlUJa3gYweCFh
```

**Note:** These are production credentials from v1 (user confirmed safe to reuse).

### Database Schema

Uses existing tables:
- **`integrations`** - Stores OAuth connections
  - `type`: "vin_solutions"
  - `config`: {clientId, apiKey, endpoint}
  - `credentials`: {accessToken (encrypted), refreshToken (encrypted), expiresAt, tokenType}

- **`audit_log`** - Logs all OAuth operations
  - Actions: VIN_TOKEN_REFRESH_SCHEDULED, VIN_TOKEN_REFRESH_COMPLETED, VIN_TOKEN_REFRESH_SUCCESS, etc.

## Integration Points

### Server Initialization

Updated `server/index.ts` to initialize VIN token refresh job on startup:

```typescript
// Initialize VIN Solutions OAuth token auto-refresh job
try {
  const { dbStorage } = await import("./db");
  const { initializeVinTokenRefreshJob } = await import("./jobs/vinTokenRefreshJob");
  const vinTokenJob = await initializeVinTokenRefreshJob(dbStorage);
  log("VIN OAuth token auto-refresh job initialized (runs every 6 hours)");
} catch (error: any) {
  log(`⚠️  VIN OAuth token auto-refresh job failed to initialize: ${error.message}`);
}
```

### Route Registration

Updated `server/routes.ts`:

```typescript
import { createVinRoutes } from "./routes/vin";

// VIN Solutions integration routes
app.use("/api/vin", createVinRoutes());
```

## Testing

### 1. Check Job Status

```bash
curl -X GET https://nexxusv2.huminicdev.com/api/vin/job-status \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

Expected response:
```json
{
  "success": true,
  "enabled": true,
  "schedule": "Every 6 hours"
}
```

### 2. Initialize OAuth Connection

```bash
curl -X POST https://nexxusv2.huminicdev.com/api/vin/initialize \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json"
```

Expected response:
```json
{
  "success": true,
  "integrationId": "uuid-here",
  "message": "VIN Solutions OAuth initialized successfully"
}
```

### 3. Test VIN API - Get Dealers

```bash
curl -X GET https://nexxusv2.huminicdev.com/api/vin/test/dealers/INTEGRATION_ID \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

Expected response:
```json
{
  "success": true,
  "dealers": [
    {
      "dealerId": 12345,
      "name": "Serra Automotive",
      "city": "Grand Blanc",
      "state": "MI"
    }
  ],
  "count": 1
}
```

### 4. Test VIN API - Search Leads

```bash
curl -X GET "https://nexxusv2.huminicdev.com/api/vin/test/leads/INTEGRATION_ID?limit=5" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

Expected response:
```json
{
  "success": true,
  "leads": [...],
  "count": 5
}
```

### 5. Manual Token Refresh

```bash
curl -X POST https://nexxusv2.huminicdev.com/api/vin/refresh-tokens \
  -H "Authorization: Bearer YOUR_JWT_TOKEN"
```

Expected response:
```json
{
  "success": true,
  "result": {
    "totalChecked": 1,
    "refreshed": 0,
    "failed": 0,
    "skipped": 1,
    "errors": []
  }
}
```

## Token Refresh Logic

### Empirical Findings (2026-01-28)

**Experiment Results:** See `experiments/reports/VIN_TOKEN_EXPIRY_FINDINGS.md`

- **Documented Lifetime:** 3600s (60 minutes)
- **Actual Lifetime:** 3922+ seconds (65+ minutes)
- **Grace Period:** 5+ minutes past documented expiry
- **Conclusion:** VIN uses conservative `expires_in` or has grace period

### Automatic Refresh Schedule
- **Frequency:** Every 30 minutes (updated based on empirical testing)
- **Threshold:** Refreshes tokens within 10 minutes of documented expiry
- **Method:** Client credentials grant (no refresh token needed)
- **Safety Margin:** 10 min before documented + 5 min grace = 15 min total buffer

### Refresh Flow
1. Job runs every 6 hours (startup + interval)
2. Queries all active VIN Solutions integrations
3. For each integration:
   - Checks token expiry time
   - If < 24 hours remaining → refresh token
   - Logs attempt to audit_log
   - Updates credentials in database
   - Logs success/failure
4. Completes with summary stats

### Audit Logging
All operations logged to `audit_log` table:
- `VIN_TOKEN_REFRESH_SCHEDULED` - Job started
- `VIN_TOKEN_REFRESH_ATTEMPT` - Attempting to refresh specific integration
- `VIN_TOKEN_REFRESH_SUCCESS` - Token refreshed successfully
- `VIN_TOKEN_REFRESH_COMPLETED` - Job completed with stats
- `VIN_TOKEN_REFRESH_JOB_FAILED` - Job failed with error

## Differences from V1

### Simplified
- No BullMQ/Redis dependency (uses native intervals)
- Simpler storage interface (direct database queries)
- Removed unused features (webhooks not yet implemented)

### Database Structure
- V1: `api_connections` table with complex metadata
- V2: `integrations` table with cleaner structure
  - `config` (JSONB): non-sensitive configuration
  - `credentials` (JSONB): encrypted tokens

### Environment Handling
- V2 supports production, integration, and sandbox environments
- Defaults to production (can be overridden per integration)

## Security

### Token Encryption
- **Algorithm:** AES-256-GCM
- **Key Derivation:** PBKDF2 (100,000 iterations, SHA-256)
- **Salt:** "vin-solutions-encryption-salt" (same as v1)
- **Source:** SESSION_SECRET environment variable

### Access Control
All VIN API routes require authentication:
- Uses JWT bearer token
- Validates user permissions via `authenticate` middleware
- Organization-scoped data access

## Monitoring

### Server Logs
```
[VinTokenRefresh] Initializing token refresh job...
[VinTokenRefresh] ✅ Token refresh job enabled (runs every 6 hours)
[VinOAuth] Starting token refresh check...
[VinOAuth] Found 0 active VIN Solutions integrations
[VinTokenRefresh] ✅ Token refresh complete: Checked: 0, Refreshed: 0, Failed: 0, Skipped: 0
```

### Audit Log Queries

Check recent token refreshes:
```sql
SELECT * FROM audit_log
WHERE action LIKE 'VIN_TOKEN%'
ORDER BY created_at DESC
LIMIT 10;
```

Get refresh statistics:
```sql
SELECT action, COUNT(*)
FROM audit_log
WHERE action LIKE 'VIN_TOKEN%'
  AND created_at > NOW() - INTERVAL '24 hours'
GROUP BY action;
```

## Next Steps

### Step 2.2: VIN Solutions API Integration
- Create lead insertion endpoint
- Implement VAPI → VIN lead flow
- Implement Tavus → VIN lead flow
- Test with real dealer IDs (user to provide)

### Future Enhancements
- Webhook registration support
- Lead update/sync functionality
- Bulk operations support
- Enhanced error recovery

## Production Readiness

✅ **Non-Disruptive:** Uses same credentials as v1, no impact on production
✅ **Isolated:** Separate database, separate integrations table
✅ **Tested:** TypeScript compiles, server starts successfully
✅ **Monitored:** Complete audit logging of all operations
✅ **Secure:** Encrypted token storage, authenticated API access

## Support

### Common Issues

**Issue:** Token refresh fails
- **Check:** VIN_SOLUTIONS credentials in .env
- **Check:** Audit log for error details
- **Solution:** Verify credentials with VIN Solutions

**Issue:** No integrations found
- **Reason:** Must initialize OAuth first
- **Solution:** Call POST /api/vin/initialize

**Issue:** 401 Unauthorized
- **Reason:** Missing or invalid JWT token
- **Solution:** Login first, use bearer token

## References

- **V1 Implementation:** `/home/ubuntu/Claude-store/nexxus/server/services/vinSolutionsService.ts`
- **VIN API Docs:** https://api.vinsolutions.com
- **OAuth Endpoint:** https://authentication.vinsolutions.com/connect/token
- **Grant Type:** client_credentials
- **Scope:** PublicAPI

---

**Last Updated:** 2026-01-28
**Author:** Claude Code
**Status:** Sprint 2.1 Complete ✅
