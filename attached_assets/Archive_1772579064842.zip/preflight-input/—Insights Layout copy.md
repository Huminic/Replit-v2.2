# —>Insights Layout  
  
##   
##   
🏗️** INFORMATION ARCHITECTURE**  
**Navigation Structure**  
```
📊 DASHBOARD (Real-time, Glanceable, Action-Oriented)
├── 🔴 Command Center (default landing page)
├── 📈 Pipeline Health
└── 🎯 Performance Scorecard

📑 REPORTS (Historical, Deep-Dive, Strategic)
├── 💀 Loss & Quality Analysis
├── 📊 Channel Intelligence
└── 📅 Trend & Forecast Reports

```
##   
📊** DASHBOARD SECTION**  
*Philosophy: Live data, refreshed every 15-60 minutes. Designed for daily operations. Answer: “What needs my attention RIGHT NOW?”*  
##   
🔴** Dashboard → Command Center**  
*Default landing page. Refreshed every 15 minutes.*  
**Layout: 3-Zone Alert System**  
```
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃  🔴 RED ZONE: Immediate Action Required                          ┃
┃  Last updated: 8:45 AM | Next refresh: 9:00 AM                   ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┌─────────────────────────────────────────────────────────────────┐
│ 🔥 HOT LEADS GOING COLD (8)                    [View All →]     │
├─────────────────────────────────────────────────────────────────┤
│ Lead ID │ Days Old │ Type     │ Source    │ Vehicle     │ Action│
├─────────┼──────────┼──────────┼───────────┼─────────────┼───────┤
│ #12847  │ 18 days  │ Internet │ Facebook  │ 2024 F-150  │ [Call]│
│ #12756  │ 17 days  │ Walk-In  │ Organic   │ 2023 Camry  │ [Call]│
│ #12688  │ 16 days  │ Phone    │ AutoTrader│ 2024 Accord │ [Call]│
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ ⏰ NEW LEADS WITHOUT CONTACT >48 HRS (12)      [View All →]     │
├─────────────────────────────────────────────────────────────────┤
│ Lead ID │ Hours Old│ Type     │ Source    │ Hot? │ Action      │
├─────────┼──────────┼──────────┼───────────┼──────┼─────────────┤
│ #12891  │ 73 hrs   │ Internet │ AutoTrader│ No   │ [Assign Now]│
│ #12889  │ 68 hrs   │ Internet │ Facebook  │ Yes  │ [Assign Now]│
│ #12876  │ 55 hrs   │ Phone    │ Call-In   │ No   │ [Assign Now]│
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ 🏢 SHOWROOM VISITORS NOT CLOSED >7 DAYS (5)    [View All →]    │
├─────────────────────────────────────────────────────────────────┤
│ Lead ID │ Days Old │ Type     │ Vehicle         │ Status       │
├─────────┼──────────┼──────────┼─────────────────┼──────────────┤
│ #12823  │ 23 days  │ Walk-In  │ 2024 Accord     │ Contacted    │
│ #12801  │ 19 days  │ Internet │ 2023 RAV4       │ Appointment  │
└─────────────────────────────────────────────────────────────────┘

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃  🟡 YELLOW ZONE: Watch List                                      ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┌─────────────────────────────────────────────────────────────────┐
│ ⚠️  LEADS APPROACHING STALE (28-35 DAYS)                        │
│                                                                  │
│     42 leads need status update                [Export CSV →]   │
│     Avg Age: 32 days                                            │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│ 💰 DEALS PENDING FINANCE (7)                                    │
│                                                                  │
│     2 deals over 5 days old                    [View Details →] │
└─────────────────────────────────────────────────────────────────┘

┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃  🟢 GREEN ZONE: Today's Performance                              ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┌──────────────┬──────────────┬──────────────┬──────────────────┐
│ New Leads    │ Active       │ Week Close   │ MTD Sold         │
│ Today        │ Pipeline     │ Rate         │                  │
├──────────────┼──────────────┼──────────────┼──────────────────┤
│   23         │   225        │   22%        │   48             │
│ ↗️ +15% vs avg│ → Stable     │ ↗️ +3% vs LW │ 65% to target   │
└──────────────┴──────────────┴──────────────┴──────────────────┘

```
## **Interaction Features:**  
* Click any lead ID → Opens lead detail modal  
* [Call] button → Initiates phone call (if integrated)  
* [Assign Now] → Quick-assign dropdown  
* [Export CSV] → Download full list for offline work  
* Auto-refresh toggle (ON by default, 15-min intervals)  
* Mobile-responsive: Red zone collapses to card view  
##   
📈** Dashboard → Pipeline Health**  
*Refreshed every 60 minutes. Focus: Flow & Velocity*  
**Layout: Metric Cards + Trend Visualization**  
```
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃  Pipeline Health Monitor                                         ┃
┃  Week of Jan 15-21, 2024                                         ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┌─────────────────────────────────────────────────────────────────┐
│  VELOCITY INDICATORS                                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │
│  │ 7-Day Avg    │  │ 30-Day Avg   │  │ Trend        │         │
│  │   18.4       │  │   16.8       │  │  ↗️ Accel.    │         │
│  │ leads/day    │  │ leads/day    │  │  +9.5%       │         │
│  └──────────────┘  └──────────────┘  └──────────────┘         │
│                                                                  │
│  [Line Chart: Daily new lead volume, last 90 days]             │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  PIPELINE FRESHNESS                                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  [Horizontal Stacked Bar: 225 Active Leads]                     │
│  ███████████░░░░░░░░░░░░░░░░░░░░                               │
│  38%       21%    28%    10%   3%                               │
│  0-7d     8-14d  15-30d  31-60d 60d+                           │
│  (85)     (48)   (62)    (22)  (8) ← STALE                     │
│                                                                  │
│  ✅ Freshness Score: HEALTHY (38% created in last 7 days)      │
│  ⚠️  Stale Pipeline: 3% (Target: <5%)                          │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  HOT LEAD TRACKING                                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Total Hot Leads: 32  (14% of active)                           │
│  Avg Age: 8.4 days                                              │
│  🚨 Over 14 days old: 5 leads  [View →]                         │
│                                                                  │
│  [Donut Chart: Hot lead age distribution]                       │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  LEAD STATUS FLOW                                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  NEW (42)  ──────→  WAITING (28)  ──────→  CONTACTED (155)     │
│   19%                   12%                      69%            │
│                                                                  │
│  ⚠️  NEW category high - check response capacity                │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  MONTH-END FORECAST                                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Current Sold (MTD):         48                                 │
│  Active Pipeline:           225                                 │
│  Historical Win Rate:        21%                                │
│  ─────────────────────────────────────────                      │
│  Projected Month-End:        95 deals                           │
│  Monthly Target:            110 deals                           │
│  Gap:                   🔴  -15 deals (-14%)                    │
│                                                                  │
│  💡 Action: Need to accelerate conversion by 3% to hit target   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

```
## **Interaction Features:**  
* Hover over chart data points → Tooltip with exact values  
* Click “View →” on hot leads → Filters Command Center to show those 5  
* Click any segment of stacked bar → Drills into lead list for that age bucket  
* [Export] button in header → PDF snapshot of entire dashboard  
##   
🎯** Dashboard → Performance Scorecard**  
*Refreshed daily at 6 AM. Focus: Win/Loss Metrics*  
**Layout: Scorecard Grid + Trend Sparklines**  
```
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃  Performance Scorecard                                           ┃
┃  Rolling 30-Day Performance (Dec 22 - Jan 21)                    ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

┌─────────────────────────────────────────────────────────────────┐
│  KEY CONVERSION METRICS                                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌──────────┐ │
│  │ Win Rate    │ │ Loss Rate   │ │ Bad Rate    │ │ Active   │ │
│  │             │ │             │ │             │ │ Pipeline │ │
│  │    21%      │ │    38%      │ │    14%      │ │   225    │ │
│  │ ─▲─▲─▲─     │ │ ─▼─▼──      │ │ ────▲──     │ │ ──▲──▲─  │ │
│  │ ↗️ +2% vs LM │ │ ↘️ -3% vs LM │ │ ↗️ +1% vs LM │ │ ↗️ +8    │ │
│  └─────────────┘ └─────────────┘ └─────────────┘ └──────────┘ │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  TOP 5 LEAD SOURCES (by Quality Score)          [View All →]    │
├─────────────────────────────────────────────────────────────────┤
│ Rank│Source      │Volume│Win Rate│Quality│Bad %│Trend │Grade  │
├─────┼────────────┼──────┼────────┼───────┼─────┼──────┼───────┤
│  1  │Walk-In     │  67  │  31%   │ 0.89  │ 3%  │  →   │ 🟢 A+ │
│  2  │Referrals   │  34  │  28%   │ 0.82  │ 5%  │ ↗️ +12│ 🟢 A  │
│  3  │Facebook    │ 178  │  18%   │ 0.62  │ 13% │ ↗️ +5 │ 🟡 B  │
│  4  │Website     │  95  │  16%   │ 0.58  │ 12% │  →   │ 🟡 B- │
│  5  │AutoTrader  │ 115  │  12%   │ 0.48  │ 16% │ ↘️ -8 │ 🔴 D  │
└─────────────────────────────────────────────────────────────────┘
🚨 AutoTrader graded D for 2nd consecutive week

┌─────────────────────────────────────────────────────────────────┐
│  CHANNEL PERFORMANCE                             [View All →]   │
├─────────────────────────────────────────────────────────────────┤
│ Channel   │Volume│% Total│Win Rate│Loss Rate│Bad Rate│Hot %   │
├───────────┼──────┼───────┼────────┼─────────┼────────┼────────┤
│ INTERNET  │ 285  │  45%  │  14%   │   41%   │  15%   │  12%   │
│ WALK_IN   │ 142  │  28%  │  26%   │   20%   │   3%   │  22%   │
│ PHONE     │  95  │  15%  │  18%   │   40%   │  11%   │   8%   │
│ REFERRAL  │  25  │   4%  │  32%   │   22%   │   2%   │  41%   │
│ SERVICE   │  48  │   8%  │  11%   │   46%   │  17%   │   3%   │
└─────────────────────────────────────────────────────────────────┘
💡 Referral has highest win rate (32%) but lowest volume (4%)
   → Opportunity: Launch referral incentive program

┌─────────────────────────────────────────────────────────────────┐
│  WEEK-OVER-WEEK TRENDS                                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  This Week vs Last Week:                                        │
│  • New Leads:     +12  (142 vs 130)  ↗️                         │
│  • Win Rate:      +1%  (22% vs 21%)  ↗️                         │
│  • Response Time: -4hr (estimated)   ↗️                         │
│  • Hot Leads:     +5   (32 vs 27)    ↗️                         │
│                                                                  │
│  ✅ 4 of 4 indicators trending positive                         │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

```
## **Interaction Features:**  
* Click source/channel name → Drills into full breakdown report  
* Grade badges → Click to see grading methodology tooltip  
* [View All →] → Opens full Lead Source Quality Report  
* Sparkline hover → Shows exact values for each time point  
* Alert icons (🚨) → Click for recommended actions  
##   
📑** REPORTS SECTION**  
*Philosophy: Historical data, point-in-time snapshots. Designed for strategic planning. Answer: “What happened and why?”*  
##   
💀** Reports → Loss & Quality Analysis**  
**Subsections (tabbed interface):**  
**Tab 1: Deal Death Autopsy**  
*Monthly retrospective on losses*  
```
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃  Deal Death Autopsy Report                                       ┃
┃  Period: December 2024 | 128 Losses | 95 Bad Leads             ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

[Date Range Selector: Last 30 days ▼] [Export PDF] [Export CSV]

┌─────────────────────────────────────────────────────────────────┐
│  LOSS REASON BREAKDOWN                                           │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  [Horizontal Bar Chart]                                         │
│                                                                  │
│  LOST_LEAD_PROCESS_COMPLETED        ████████████░ 45 (35%)     │
│  LOST_PURCHASED_SAME_BRAND          ███████░░░░░░ 28 (22%)     │
│  LOST_PURCHASED_DIFF_BRAND          ████░░░░░░░░░ 18 (14%)     │
│  LOST_CHANGED_MIND                  ███░░░░░░░░░░ 12 (9%)      │
│  LOST_WAITING_ON_TRADE              ██░░░░░░░░░░░ 8 (6%)       │
│  Other LOST reasons                 ████░░░░░░░░░ 17 (14%)     │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  BAD LEAD BREAKDOWN                                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  BAD_BAD_OR_NO_CONTACT_INFO         ███████████░░ 32 (34%)     │
│  BAD_DUPLICATE                      ████████░░░░░ 24 (25%)     │
│  BAD_INVALID_INFORMATION            █████░░░░░░░░ 15 (16%)     │
│  BAD_OUTSIDE_MARKET_AREA            ████░░░░░░░░░ 12 (13%)     │
│  Other BAD reasons                  ████░░░░░░░░░ 12 (12%)     │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  LOSS PATTERNS BY SOURCE                                         │
├─────────────────────────────────────────────────────────────────┤
│ Source      │Total│Lost│Bad│Loss %│Bad %│Primary Loss Reason   │
├─────────────┼─────┼────┼───┼──────┼─────┼──────────────────────┤
│ AutoTrader  │ 115 │ 52 │18 │ 45%  │ 16% │BAD_NO_CONTACT        │
│ Facebook    │ 178 │ 68 │24 │ 38%  │ 13% │LOST_PROCESS_COMPLETE │
│ Website     │  95 │ 38 │12 │ 40%  │ 13% │LOST_PROCESS_COMPLETE │
│ Walk-In     │  67 │ 12 │ 2 │ 18%  │  3% │LOST_PURCHASED_SAME   │
│ Phone       │  95 │ 38 │12 │ 40%  │ 13% │LOST_PROCESS_COMPLETE │
└─────────────────────────────────────────────────────────────────┘
🚨 AutoTrader has 45% loss rate (dealership avg: 38%)
   → Recommended Action: Renegotiate or cancel contract

┌─────────────────────────────────────────────────────────────────┐
│  LOSS TIMING ANALYSIS                                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  When are deals dying?                                          │
│                                                                  │
│  [Column Chart: Losses by lead age bucket]                      │
│     45                                                          │
│     40                                                          │
│     35    ██                                                    │
│     30    ██  ██                                                │
│     25    ██  ██  ██                                            │
│     20    ██  ██  ██  ██                                        │
│     15    ██  ██  ██  ██  ██                                    │
│     10    ██  ██  ██  ██  ██                                    │
│      5    ██  ██  ██  ██  ██                                    │
│      0  ──┴───┴───┴───┴───┴──                                   │
│         0-7d 8-14 15-30 31-60 60d+                              │
│                                                                  │
│  💡 28% of losses occur in first 7 days                         │
│     → Focus on rapid response and early engagement              │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  COMPETITIVE INTELLIGENCE                                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Competitor Losses Trend (6 months)                             │
│                                                                  │
│  [Line Chart: Month-over-month]                                 │
│  30 │                                              ╱            │
│  25 │                                          ╱──╱             │
│  20 │                                      ╱──╱                 │
│  15 │                  ╱──────────────╱──╱                      │
│  10 │  ──────────╱────╱                                         │
│   5 │                                                            │
│   0 └────────────────────────────────────────────               │
│     Aug  Sep  Oct  Nov  Dec  Jan                                │
│                                                                  │
│  🚨 LOST_PURCHASED_SAME_BRAND up 43% since August              │
│     Competitors are winning on price or experience              │
│     → Recommended: Mystery shop top 3 competitors               │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

```
**Tab 2: Re-Engagement Opportunities**  
*Recoverable leads from past losses*  
```
┌─────────────────────────────────────────────────────────────────┐
│  RE-ENGAGEMENT CANDIDATE LIST                                    │
│  Leads lost 90-180 days ago - Ready for "We Miss You" campaign  │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Filters: ☑ LOST_LEAD_PROCESS_COMPLETED                        │
│           ☑ 90-180 days old                                     │
│           ☐ Had showroom visit                                  │
│           ☐ Was marked hot                                      │
│                                        [Apply Filters] [Reset]  │
│                                                                  │
│  📊 Results: 142 leads                 [Export for CRM →]       │
│                                                                  │
├─────────────────────────────────────────────────────────────────┤
│ Lead ID│Lost Date │Type    │Source   │Vehicle      │Est. Value│
├────────┼──────────┼────────┼─────────┼─────────────┼──────────┤
│ #12245 │Oct 15 '24│Internet│Facebook │2024 F-150   │High      │
│ #12198 │Oct 12 '24│Walk-In │Organic  │2023 Camry   │Medium    │
│ #12156 │Oct 08 '24│Referral│Customer │2024 Accord  │High      │
│  ...   │   ...    │  ...   │  ...    │    ...      │  ...     │
└─────────────────────────────────────────────────────────────────┘
                                   [1] [2] [3] ... [15]  →

💡 Campaign Suggestion:
   "It's been a few months - still interested in that [Vehicle]?
    We've got 3 new [Model] that just arrived. Coffee's on us
    if you stop by this week!"

```
**Tab 3: Source Quality Trends**  
*Historical quality tracking by source*  
```
┌─────────────────────────────────────────────────────────────────┐
│  LEAD SOURCE QUALITY TRENDS (6 MONTHS)                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Select Source: [AutoTrader ▼]                                 │
│                                                                  │
│  [Multi-line Chart]                                             │
│  50% │                                                           │
│  40% │  ────●────●─────●────●────●────●  Win Rate              │
│  30% │                                                           │
│  20% │                                  ●─────●────●──●  Bad %  │
│  10% │  ──●───●────●───●─────●                                  │
│   0% └────────────────────────────────────────────              │
│      Aug  Sep  Oct  Nov  Dec  Jan                               │
│                                                                  │
│  ⚠️  Concerning Trends:                                         │
│  • Win rate declining 8% since August                           │
│  • Bad rate increasing 6% since August                          │
│  • Currently graded D (was B in August)                         │
│                                                                  │
│  📋 Recommended Action: Schedule vendor review call             │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

```
##   
📊** Reports → Channel Intelligence**  
**Subsections:**  
**Tab 1: Channel Performance Deep-Dive**  
*Full 10-channel comparison*  
```
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃  Channel Performance Intelligence                                ┃
┃  Period: December 2024 | 637 Total Leads                        ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

[Date Range: Last 30 days ▼] [Compare to: Previous 30 days ▼]

┌─────────────────────────────────────────────────────────────────┐
│  FULL CHANNEL COMPARISON                                         │
├─────────────────────────────────────────────────────────────────┤
│ Channel     │Vol│%  │Win│Loss│Bad│Hot%│Show%│Trade%│Δ Win│Rank│
├─────────────┼───┼───┼───┼────┼───┼────┼─────┼──────┼─────┼────┤
│REFERRAL     │25 │4% │32%│22% │2% │41% │45%  │68%   │+4%  │ 1  │
│PREV_CUSTOMER│18 │3% │28%│18% │4% │35% │38%  │72%   │+2%  │ 2  │
│WALK_IN      │142│28%│26%│20% │3% │22% │100% │58%   │+1%  │ 3  │
│PHONE        │95 │15%│18%│40% │11%│8%  │15%  │55%   │  0% │ 4  │
│WEBSITE_CHAT │32 │5% │16%│38% │12%│15% │5%   │60%   │-1%  │ 5  │
│INTERNET     │285│45%│14%│41% │15%│12% │8%   │62%   │-2%  │ 6  │
│SERVICE      │48 │8% │11%│46% │17%│3%  │12%  │48%   │+1%  │ 7  │
│IMPORT       │12 │2% │8% │50% │25%│0%  │0%   │40%   │-3%  │ 8  │
│WHOLESALE    │8  │1% │6% │55% │20%│0%  │0%   │35%   │  0% │ 9  │
│PARTS_ORDER  │5  │1% │4% │60% │30%│0%  │0%   │25%   │-1%  │ 10 │
└─────────────────────────────────────────────────────────────────┘

🏆 Top Performer: REFERRAL (32% win rate, 41% hot lead rate)
⚠️  Underperformer: SERVICE (only 11% despite 8% volume)
↗️  Improving: PREV_CUSTOMER (+2% win rate)
↘️  Declining: INTERNET (-2% win rate)

```
**Tab 2: Digital vs. Physical Analysis**  
*Strategic channel grouping*  
```
┌─────────────────────────────────────────────────────────────────┐
│  DIGITAL vs PHYSICAL BREAKDOWN                                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Digital: INTERNET + WEBSITE_CHAT + PARTS_ORDER                 │
│  Physical: WALK_IN + PHONE + SERVICE + REFERRAL + PREV_CUST    │
│                                                                  │
│  [Side-by-side comparison cards]                                │
│                                                                  │
│  ┌──────────────────────────┬──────────────────────────┐       │
│  │ 🌐 DIGITAL CHANNELS      │ 🏢 PHYSICAL CHANNELS     │       │
│  ├──────────────────────────┼──────────────────────────┤       │
│  │ Volume: 322 (51%)        │ Volume: 315 (49%)        │       │
│  │ Win Rate: 14%            │ Win Rate: 24%            │       │
│  │ Loss Rate: 42%           │ Loss Rate: 26%           │       │
│  │ Bad Rate: 16%            │ Bad Rate: 5%             │       │
│  │ Hot Lead %: 12%          │ Hot Lead %: 22%          │       │
│  │ Trade-In %: 61%          │ Trade-In %: 59%          │       │
│  │                          │                          │       │
│  │ Trend: ↗️ Volume +8%     │ Trend: ↘️ Volume -3%     │       │
│  │        ↘️ Win Rate -2%   │        ↗️ Win Rate +1%   │       │
│  └──────────────────────────┴──────────────────────────┘       │
│                                                                  │
│  📊 Digital Maturity Score: 0.65                                │
│     (Digital % × Digital WR / Overall WR)                       │
│     Industry Benchmark: 0.75-0.85                               │
│                                                                  │
│  💡 Insight: Digital volume is growing but conversion is        │
│     lagging physical by 10%. Opportunity to improve digital     │
│     lead handling could yield 20-30 additional monthly sales.   │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

```
**Tab 3: Service-to-Sales Opportunity**  
*Focused analysis on underutilized channel*  
```
┌─────────────────────────────────────────────────────────────────┐
│  SERVICE LANE CROSS-SELL ANALYSIS                                │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Current Performance:                                           │
│  • SERVICE leads: 48 (8% of total volume)                       │
│  • Win rate: 11%                                                │
│  • Industry best practice: 8-12% conversion                     │
│                                                                  │
│  [Bar chart: SERVICE channel vs others]                         │
│                                                                  │
│  Opportunity Sizing:                                            │
│  • Estimated monthly service customers: 500                     │
│  • Current capture rate: 9.6% (48/500)                          │
│  • Current conversion: 11%                                      │
│  • Current monthly sales from service: 5.3                      │
│                                                                  │
│  What-If Scenarios:                                             │
│                                                                  │
│  Scenario A: Improve capture rate to 15%                        │
│  → 75 service leads/month × 11% = 8.3 sales (+3 sales)         │
│  → Additional gross profit: $6,000/month                        │
│                                                                  │
│  Scenario B: Improve conversion to 15%                          │
│  → 48 service leads × 15% = 7.2 sales (+2 sales)               │
│  → Additional gross profit: $4,000/month                        │
│                                                                  │
│  Scenario C: Both improvements                                  │
│  → 75 leads × 15% = 11.3 sales (+6 sales) 🎯                   │
│  → Additional gross profit: $12,000/month                       │
│                                                                  │
│  🎯 Recommended Actions:                                        │
│  1. Train service advisors on warm handoff process              │
│  2. Implement service lane "upgrade checker" tool               │
│  3. Offer trade appraisal with every service visit              │
│  4. Sales manager meet-and-greet for customers waiting          │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

```
##   
📅** Reports → Trend & Forecast Reports**  
**Subsections:**  
**Tab 1: Monthly Performance Summary**  
*Executive-level monthly retrospective*  
```
┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃  Monthly Performance Summary                                     ┃
┃  December 2024 vs November 2024                                 ┃
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛

[Select Month: December 2024 ▼] [Export PDF →]

┌─────────────────────────────────────────────────────────────────┐
│  KEY METRICS AT-A-GLANCE                                         │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ┌──────────────┬──────────────┬──────────────┬──────────────┐ │
│  │ New Leads    │ Total Sold   │ Win Rate     │ Avg Lead Age │ │
│  ├──────────────┼──────────────┼──────────────┼──────────────┤ │
│  │    637       │    142       │    21%       │   12.4 days  │ │
│  │ ↗️ +42 (+7%) │ ↗️ +18 (+15%)│ ↗️ +2%       │ ↘️ -1.2 days │ │
│  │ vs Nov: 595  │ vs Nov: 124  │ vs Nov: 19%  │ vs Nov: 13.6│ │
│  └──────────────┴──────────────┴──────────────┴──────────────┘ │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  VOLUME TRENDS (12 MONTHS)                                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  [Dual-axis line + bar chart]                                   │
│  700│                                          ██               │
│  600│                              ██      ██  ██               │
│  500│              ██      ██      ██  ██  ██  ██               │
│  400│      ██  ██  ██  ██  ██  ██  ██  ██  ██  ██               │
│  300│  ██  ██  ██  ██  ██  ██  ██  ██  ██  ██  ██               │
│  200│  ██  ██  ██  ██  ██  ██  ██  ██  ██  ██  ██               │
│  100│  ██  ██  ██  ██  ██  ██  ██  ██  ██  ██  ██               │
│    0└──┴───┴───┴───┴───┴───┴───┴───┴───┴───┴───┴──             │
│      J   F   M   A   M   J   J   A   S   O   N   D             │
│      '24                                        '24             │
│                                                                  │
│  ──●──●──●──●──●──●──●──●──●──●──●──●  Win Rate (line)         │
│                                                                  │
│  ✅ Strongest month: December (637 leads, 142 sold)            │
│  📈 YoY Growth: +18% volume, +3% win rate                      │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  SOURCE PERFORMANCE CHANGES                                      │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Biggest Winners (Month-over-Month):                            │
│  🏆 Facebook:    +42 leads (+31%), win rate +1%                │
│  🏆 Referrals:   +8 leads (+31%), win rate +4%                 │
│  🏆 Walk-In:     +12 leads (+9%), win rate +1%                 │
│                                                                  │
│  Biggest Losers:                                                │
│  ⚠️  AutoTrader:  -18 leads (-14%), win rate -3%               │
│  ⚠️  Phone:       -8 leads (-8%), win rate 0%                  │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│  EXECUTIVE SUMMARY                                               │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  ✅ Wins:                                                        │
│  • Record volume month (637 leads, +7% MoM)                     │
│  • Win rate improved to 21% (+2% MoM, +3% YoY)                  │
│  • Facebook and Referral channels accelerating                  │
│  • Pipeline freshness improved (38% <7 days old)                │
│                                                                  │
│  ⚠️  Concerns:                                                   │
│  • AutoTrader declining for 2nd consecutive month               │
│  • SERVICE channel still underperforming (11% win rate)         │
│  • Digital win rate (14%) lags physical (24%) by 10%           │
│                                                                  │
│  🎯 Recommendations:                                             │
│  1. Renegotiate/cancel AutoTrader if no improvement by Feb      │
│  2. Launch referral incentive program ($500 bonus)              │
│  3. Implement service lane cross-sell training                  │
│  4. Improve digital lead response time (target <5 min)          │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

```
**Tab 2: Rolling Forecast**  
*Predictive 90-day outlook*  
```
┌─────────────────────────────────────────────────────────────────┐
│  90-DAY ROLLING FORECAST                                         │
│  Generated: Jan 21, 2024 at 6:00 AM                             │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Forecast Methodology:                                          │
│  • Based on trailing 90-day velocity and conversion patterns    │
│  • Accounts for seasonal trends (if 12+ months of data)         │
│  • Conservative estimate (uses 25th percentile win rate)        │
│                                                                  │
│  [3-month projection chart]                                     │
│                                                                  │
│       │ January (partial) │  February     │    March            │
│  ─────┼───────────────────┼───────────────┼───────────          │
│  Lead │ 285 (projected)   │ 590-620       │ 600-630             │
│  Vol  │                   │               │                     │
│  ─────┼───────────────────┼───────────────┼───────────          │
│  Sold │ 48 (actual MTD)   │ 118-130       │ 120-132             │
│       │ 95 (projected)    │               │                     │
│  ─────┼───────────────────┼───────────────┼───────────          │
│  vs   │ 110 target        │ 110 target    │ 110 target          │
│  Goal │ ⚠️  -15 gap        │ ✅ +8 to +20  │ ✅ +10 to +22       │
│       │                   │               │                     │
│                                                                  │
│  🎯 January Gap-to-Goal Analysis:                               │
│  • Need 62 more sales in remaining 10 days                      │
│  • Current pipeline: 225 ACTIVE leads                           │
│  • Required win rate: 28% (vs 21% baseline)                     │
│  • Assessment: ⚠️  CHALLENGING - need 7pt lift in conversion    │
│                                                                  │
│  💡 Recommendations to Close Gap:                               │
│  1. Weekend sales event (Jan 27-28)                             │
│  2. Accelerate SOLD_PENDING_FINANCE deals (7 pending)           │
│  3. Manager outreach to all hot leads >7 days (32 leads)        │
│  4. Re-engage showroom visitors from last 14 days (18 leads)    │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

```
**Tab 3: Year-over-Year Comparison**  
*Long-term trend analysis*  
```
┌─────────────────────────────────────────────────────────────────┐
│  YEAR-OVER-YEAR PERFORMANCE                                      │
│  2024 vs 2023                                                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                  │
│  [Stacked bar chart: Monthly comparison]                        │
│                                                                  │
│  Annual Summary:                                                │
│  ┌───────────────────┬──────────┬──────────┬──────────┐        │
│  │                   │   2023   │   2024   │  Change  │        │
│  ├───────────────────┼──────────┼──────────┼──────────┤        │
│  │ Total Leads       │  6,842   │  7,254   │ +412 (+6%)│       │
│  │ Total Sold        │  1,285   │  1,468   │ +183 (+14%)│      │
│  │ Win Rate          │   19%    │   20%    │ +1%      │        │
│  │ Loss Rate         │   41%    │   39%    │ -2%      │        │
│  │ Bad Rate          │   15%    │   15%    │  0%      │        │
│  └───────────────────┴──────────┴──────────┴──────────┘        │
│                                                                  │
│  🏆 Key Achievements 2024:                                      │
│  • Volume growth: +6% YoY                                       │
│  • Sales growth: +14% YoY (outpaced volume by 2.3x)            │
│  • Conversion improvement: +1 percentage point                  │
│  • Q4 was strongest quarter (1,842 leads, 412 sold)            │
│                                                                  │
└─────────────────────────────────────────────────────────────────┘

```
##   
🎨** DESIGN & UX PRINCIPLES**  
**Visual Hierarchy**  
1. **Alert Red** (#DC2626): Critical items needing immediate action  
2. **Warning Yellow** (#F59E0B): Watch list items  
3. **Success Green** (#10B981): Healthy metrics, positive trends  
4. **Neutral Gray** (#6B7280): Standard data  
5. **Primary Blue** (#3B82F6): Interactive elements, links  
**Data Visualization Best Practices**  
* **Sparklines** for trends in tight spaces (dashboards)  
* **Bar charts** for comparisons (loss reasons, source volume)  
* **Line charts** for time series (velocity, forecasts)  
* **Donut/Pie charts** for composition (status distribution) - use sparingly  
* **Traffic lights** (🟢🟡🔴) for quick status assessment  
* **Trend arrows** (↗️↘️→) for direction indicators  
**Interaction Patterns**  
* **Click lead ID** → Opens lead detail modal overlay  
* **Click metric card** → Drills into detailed report  
* **Hover chart element** → Tooltip with exact values  
* **[Export]** buttons → PDF (formatted report) or CSV (raw data)  
* **Date range selectors** → Common presets (Last 7d, 30d, 90d, MTD, Last Month)  
* **Filter badges** → Click to remove, show active filter count  
**Mobile Responsiveness**  
* **Dashboard**: Stacks vertically, cards become full-width  
* **Tables**: Horizontal scroll with sticky first column  
* **Charts**: Simplified on mobile, full detail on tap/click  
* **Command Center**: Red zone shows top 5 only, “View All” expands  
**Performance Optimization**  
* **Dashboard**: Cache for 15 min, preload on login  
* **Reports**: Generate on-demand, cache for 24 hours  
* **Large tables**: Paginate at 50 rows, lazy load  
* **Export**: Generate server-side, deliver via download link  
##   
🚀** IMPLEMENTATION PHASES**  
**Phase 1: MVP (Weeks 1-2)**  
* Dashboard → Command Center (Red Zone only)  
* Dashboard → Performance Scorecard (key metrics cards)  
* Reports → Deal Death Autopsy (loss reason breakdown)  
**Phase 2: Core (Weeks 3-4)**  
* Dashboard → Command Center (Yellow + Green zones)  
* Dashboard → Pipeline Health (full dashboard)  
* Reports → Lead Source Quality (full scorecard)  
**Phase 3: Complete (Weeks 5-6)**  
* Reports → Channel Intelligence (all tabs)  
* Reports → Trend & Forecast (monthly summary)  
* Polish, mobile optimization, performance tuning  
##   
**This structure gives you:**  
1. **Clear separation** between operational (dashboard) and analytical (reports)  
2. **Intuitive navigation** - dashboards for “what now?”, reports for “what happened?”  
3. **Scalability** - easy to add new dashboard widgets or report tabs  
4. **User-appropriate** - managers live in dashboards, executives consume reports  
5. **100% buildable** with confirmed available data  
##   
