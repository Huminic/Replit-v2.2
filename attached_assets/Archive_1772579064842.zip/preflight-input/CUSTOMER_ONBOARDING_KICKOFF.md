# Customer Onboarding — Acceptance Criteria Kickoff

**Prepared:** 2026-02-17
**Purpose:** Human relay dependencies, informational requirements, and readiness status for customer acceptance criteria onboarding.

---

## Acceptance Criteria Summary

| AC | Description | Code Status | Ready to Demo? | Blocking On |
|----|-------------|-------------|----------------|-------------|
| AC-1 | Automatic outbound call triggering | Complete | Partial | VAPI phone numbers, trigger rule activation |
| AC-2 | Intelligent analysis of VIN Solutions data | Complete | Yes (Serra orgs) | Columbia orgs need VIN integration |
| AC-3 | VAPI/Tavus leads inserted into VIN Solutions | Bug | No | VIN API format fix (our side), Columbia VIN credentials |
| AC-4 | Dashboard metrics accurate and usable | Complete | Yes | Hard refresh needed; names still resolving for some leads |
| AC-5 | Widget deployment | Complete | Partial | Customer domains needed, voice agent wiring |

---

## Section 1: What We Need FROM Each Customer

### All Customers (Serra + Columbia)

| # | What We Need | Why | Who Decides |
|---|-------------|-----|-------------|
| 1 | **Production website domains** (e.g., `serrahonda.com`, `fordofcolumbia.com`) | Widget embed code only works on whitelisted domains. Currently set to `localhost`. | Dealership GM or marketing lead |
| 2 | **VAPI phone number selection** — one outbound number per dealership | Required for AC-1 (auto-call triggers). VAPI charges per number. Must be purchased/registered in VAPI dashboard. | Huminic (purchase) + dealership (approve number/area code) |
| 3 | **Trigger rule preferences** — which auto-actions to activate | System has templates ready ("Neglected Lead Auto-Call" = call if no contact after 2 hours). Customer decides: enable it? Change the delay? Add others? | Dealership ops manager or GM |
| 4 | **Business hours for triggers** — what hours should auto-calls fire? | Outbound calls will only fire during these windows. Default: M-F 9am-6pm. | Dealership manager |
| 5 | **Widget channel preferences** — which channels to enable per dealership | Options: text chat, voice call, video call, SMS, callback request, appointment scheduling. Currently text/voice/SMS/callback/scheduling are ON, video is OFF. | Dealership marketing or GM |
| 6 | **Hosted page preferences** — do they want standalone Nexxus landing pages? | These are QR-code-friendly pages hosted on our domain. Useful for print ads, showroom displays, etc. Optional. | Marketing lead |

### Columbia Orgs Only (Ford of Columbia + Hyundai of Columbia)

| # | What We Need | Why | Who Decides | Impact if Not Provided |
|---|-------------|-----|-------------|----------------------|
| 7 | **Do these dealerships use VIN Solutions CRM?** | We need to know if VIN integration applies to them at all | Dealership GM | If no VIN: AC-2 uses local data only, AC-3 skips VIN sync (leads stay in Nexxus only) |
| 8 | **VIN Solutions Dealer IDs** (if yes to #7) | Required to connect API. Serra orgs: 21043, 21044, 21047. Columbia: unknown. | VIN Solutions account manager or dealership IT | Cannot query VIN data, cannot push leads to VIN |
| 9 | **VIN Solutions API credentials** (if yes to #7) | OAuth2 client credentials. May be shared across the group or per-dealership. | VIN Solutions support or Cage Automotive IT | Same as above |

### Serra Orgs (Serra Honda, Serra Nissan, Tony Serra Ford)

| # | What We Need | Why |
|---|-------------|-----|
| 10 | **Confirm existing VIN integrations are correct** | All 3 are wired and refreshing tokens. Just need verbal confirmation they're seeing correct data. |
| 11 | **Review trigger templates** | Show them the "Neglected Lead Auto-Call" template and get go/no-go to activate. |

---

## Section 2: What Customers Need to DECIDE

These are decisions the customer must make — we cannot make them on their behalf.

### Decision 1: Agent Voice & Personality
**Question:** "What should your AI voice agent sound like and say?"
- Each dealership has a named voice agent (e.g., "Savannah" at Ford, "Elizabeth" at Hyundai)
- They can customize: greeting script, personality tone, what info to collect
- Default behavior is professional, appointment-focused
- **We need:** Approval of current agent behavior OR change requests

### Decision 2: Lead Routing After AI Contact
**Question:** "When the AI agent qualifies a lead, who gets notified?"
- Currently: Org Admins get email + in-app notification on every new VAPI call
- Options: route to specific salesperson, round-robin, manager-first
- **We need:** Notification routing preference per dealership

### Decision 3: VIN Lead Source Tagging
**Question:** "How should AI-generated leads appear in VIN Solutions?"
- When a VAPI/Tavus interaction creates a lead in VIN, it needs a "Lead Source" tag
- Options: "Nexxus AI", "Phone - AI", "Internet - Chatbot", or match existing CRM sources
- **We need:** Preferred lead source name per dealership (must exist or be created in VIN)

### Decision 4: Call Duration Threshold
**Question:** "How long should a call last before it counts as a real lead?"
- Currently: 10 seconds (calls shorter than this are ignored)
- Range: 0-300 seconds
- **We need:** Threshold per dealership (or approval of 10s default)

### Decision 5: Widget Placement
**Question:** "Where on your website should the AI widget appear?"
- Options: bottom-right floating bubble (default), dedicated page, embedded in specific sections
- **We need:** Placement preference + website admin access (or their web developer contact) to install the embed code

---

## Section 3: Readiness Status Per Acceptance Criteria

### AC-1: Automatic Outbound Call Triggering

**What's built:**
- TriggerService with 6 integration points (new lead, missed call, SMS received, widget interaction, appointment created, lead status change)
- Real VAPI outbound call API integration (`POST https://api.vapi.ai/call`)
- Business hours checking, rate limiting, prior-contact detection
- "Neglected Lead Auto-Call" template (call if no contact after 2 hours)
- Full trigger CRUD (create, edit, activate, deactivate, delete)

**Ready to demo:** Yes, for the trigger management UI and template activation flow.
**Ready to go live:** No — needs VAPI phone numbers assigned per org + trigger rules activated.

**Internal note:** The trigger execution path is fully wired but has never fired a real outbound call in production. Recommend a controlled test call before customer demo.

### AC-2: Intelligent Analysis of VIN Solutions Data

**What's built:**
- DealerBrain (Claude AI) with 6 VIN-specific tools: `query_vin_customers`, `get_vin_lead_stats`, `get_vin_dealer_info`, `query_leads`, `get_lead_stats`, `analyze_pipeline`
- Context Router queries VIN API live (primary source, local DB fallback)
- Multi-org analysis tools for Partner Admin/Super Admin
- Goal awareness injected into AI context
- Follow-up prompt suggestions for contextual conversation flow

**Ready to demo:** Yes, for Serra orgs (VIN integration active).
**Ready to go live:** Yes for Serra, blocked for Columbia (no VIN integration).

**Demo talking points:**
- Ask DealerBrain "How are my leads doing?" — it queries VIN API live
- Ask "Compare our stores" (as Partner Admin) — cross-org analysis
- Ask "Create a voice agent for missed call follow-ups" — NL agent creation
- Show Dealer Pulse gauges (live VIN API data, refreshes every 4 hours)

### AC-3: Incoming Leads from VAPI/Tavus Inserted into VIN Solutions

**What's built:**
- VAPI webhook captures call data, creates local lead, queues VIN sync
- Tavus webhook captures session data, creates local lead, queues VIN sync
- SyncCoordinator processes queue with retry logic
- VIN lead creation: 2-step (create contact, then create lead with reference)

**Ready to demo:** No.
**Known bug:** VIN API v3 `leadSource` field format mismatch. The code sends a string ("Phone") but the API expects a URL reference to a lead source. 12/12 sync jobs have failed in production.

**Fix required (our side):**
1. Query the org's lead sources from VIN API to get valid URLs
2. Use the URL format for `leadSource` instead of a string
3. Ensure contact URL is correctly formed before lead creation
4. Retry the 12 failed jobs after fix

**Columbia blocker:** No VIN integration = no VIN sync. Local lead creation works fine.

### AC-4: Lead Metrics and Data on Dashboards

**What's built:**
- Dashboard with 6 sections: Dealer Pulse, Lead Cards, Goal Progress, Lead Feed, Agent Actions, Team Leaderboard
- Context Router routes lead feed to VIN API live
- All queries exclude stale excel_upload records (691 records filtered out)
- Source badges on every section show data provenance
- Manual refresh with 5-min cooldown
- Insight cards: Voice Agent (VAPI data), Video Data (Tavus data), VIN Lead Feed (VIN + local)

**Ready to demo:** Yes.
**Ready to go live:** Yes, with caveat that some lead names show as "Unknown" when the VIN Lead Poll hasn't enriched contact names yet (resolves automatically over time).

**What the customer will see:**
- Dealer Pulse: Live VIN API counts (Active, Waiting Response, Sold, Lost)
- Lead cards: Overdue/New/Active counts from locally synced VIN data
- Lead Feed: Live VIN API results with enriched names where available
- Leaderboard: Salesperson ranking by lead count (last 30 days)

### AC-5: Widget Deployment

**What's built:**
- Master Widget system: embed code, public API, rate limiting (100 req/hr/IP)
- Channels: text chat, voice (VAPI Web SDK), video (Tavus), SMS, callback, scheduling
- Widget configuration UI in Settings
- Hosted Pages system with slug-based public URLs
- Individual code widgets per org

**Ready to demo:** Yes (on localhost or our domain).
**Ready to go live:** No — domains need whitelisting, voice agent IDs need wiring in widget config.

**Embed code example** (what customer's web developer needs):
```html
<script src="https://nexxusv2.huminicdev.com/widget/nexxus-widget.js"
        data-widget-code="widget_XXXXXX"></script>
```

---

## Section 4: Suggested Kickoff Meeting Agenda

### Part 1: Platform Overview (15 min)
- What Nexxus does (AI voice, video, chat for dealerships)
- Live demo: log in as their org, show dashboard with real VIN data
- Show DealerBrain: ask a question about their leads

### Part 2: Acceptance Criteria Walkthrough (30 min)
- Walk through each AC, show what's working
- For each AC: explain what we need from them (Section 1 above)
- Collect decisions (Section 2 above) or schedule follow-up

### Part 3: Technical Setup (15 min)
- **For each dealership, collect:**
  - Website domain(s) for widget whitelisting
  - Preferred outbound phone number area code
  - VIN Solutions credentials (Columbia) or confirm existing (Serra)
  - Web developer contact for embed code installation
- **Schedule follow-up for:**
  - Widget installation assistance (15 min per site)
  - Trigger rule configuration (15 min per org)
  - Agent voice/personality review (15 min per org)

### Part 4: Timeline & Next Steps (10 min)
- What's live now vs. what's coming
- When they can start using each feature
- Support contact and feedback process

---

## Section 5: Internal Notes (For Huminic Team Only)

### Before the Kickoff Meeting

1. **Fix AC-3 VIN lead creation bug** — this is the highest-priority code fix. The leadSource URL format issue needs to be resolved before demoing AC-3.

2. **Test AC-1 outbound call** — make one controlled test call through the trigger system to verify the VAPI outbound API works end-to-end. Use a test phone number.

3. **Verify dashboard data freshness** — do a hard refresh on each org's dashboard and screenshot. Dealer Pulse should show live numbers. Lead feed should show VIN API data with names.

4. **Prepare embed codes** — generate the widget embed snippet for each org so we can hand it off during the meeting.

5. **Columbia VIN question** — if they don't use VIN Solutions, we need to decide: do we build a different CRM integration (DealerSocket, etc.) or do they use Nexxus as their primary lead tracker?

### Known Limitations to Be Transparent About

- **Lead names from VIN API** sometimes show as "Unknown" — the VIN API returns contact URLs, not inline names. Our background poll enriches names but there can be a delay.
- **Video AI (Tavus)** is not configured for Columbia orgs and video channel is OFF in their widgets. Enabling it requires creating Tavus personas.
- **Email integration** has a credential issue for one integration (non-blocking, just noisy in logs).
- **SMS (TextMagic)** is configured but needs customer approval before sending outbound messages.

### Risk Items

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| Columbia doesn't use VIN Solutions | Medium | High — AC-2 and AC-3 don't apply | Ask early. Alternative: local-only lead management |
| VAPI outbound call fails in prod | Low | High — AC-1 blocked | Test before demo with controlled call |
| Customer wants VIN lead source that doesn't exist | Medium | Low — can create in VIN CRM | Pre-check available lead sources per dealer |
| Widget breaks on customer's site | Low | Medium — AC-5 affected | Test on their actual domain before going live |

---

## Section 6: Per-Organization Checklist

### Serra Honda of Sylacauga (Dealer ID: 21043)
- [x] VIN integration active
- [x] Voice agent configured
- [ ] VAPI phone number assigned for outbound
- [ ] Trigger rules activated
- [ ] Widget domain whitelisted
- [ ] Widget voice agent ID configured
- [ ] Hosted page created (if wanted)

### Serra Nissan of Sylacauga (Dealer ID: 21044)
- [x] VIN integration active
- [x] Voice agent configured
- [ ] VAPI phone number assigned for outbound
- [ ] Trigger rules activated
- [ ] Widget domain whitelisted
- [ ] Widget voice agent ID configured
- [ ] Hosted page created (if wanted)

### Tony Serra Ford (Dealer ID: 21047)
- [x] VIN integration active
- [ ] Voice agent configured (needs verification)
- [ ] VAPI phone number assigned for outbound
- [ ] Trigger rules activated
- [ ] Widget domain whitelisted
- [ ] Widget voice agent ID configured
- [ ] Hosted page created (if wanted)

### Hyundai of Columbia (Dealer ID: 6374 — NEEDS VERIFICATION)
- [ ] VIN integration created (blocked: need credentials)
- [x] Voice agent "Elizabeth" configured (missing phoneNumberId)
- [ ] VAPI phone number assigned for outbound
- [ ] Trigger rules activated
- [ ] Widget domain whitelisted (`hyundaiofcolumbia.com` ?)
- [ ] Widget voice agent ID configured
- [ ] Hosted page created (if wanted)

### Ford of Columbia (Dealer ID: 3027 — NEEDS VERIFICATION)
- [ ] VIN integration created (blocked: need credentials)
- [x] Voice agent "Savannah" configured (missing phoneNumberId)
- [ ] VAPI phone number assigned for outbound
- [ ] Trigger rules activated
- [ ] Widget domain whitelisted (`fordofcolumbia.com` ?)
- [ ] Widget voice agent ID configured
- [ ] Hosted page created (if wanted)
