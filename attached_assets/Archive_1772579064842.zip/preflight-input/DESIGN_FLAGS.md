# Design Flags

**Purpose:** Async communication channel between autonomous agents and the project owner. Flags are written here when a design decision needs human review. The owner reviews this file during check-ins (1-2x daily).

**Protocol:**
- Agents write flags when they encounter decisions with long-term architectural impact
- Owner responds inline with `APPROVED`, `REJECTED`, or `MODIFY: <instructions>`
- Resolved flags move to the "Resolved" section at the bottom

---

## When to Flag

Flag here (don't just decide):
- Changes to auth/RBAC model
- Schema changes affecting >3 existing tables
- External service integration approach
- Credit economy logic changes
- RLS policy modifications
- Breaking API changes
- Governance architecture decisions
- Any choice where 2+ reasonable approaches exist and the decision has long-term impact

Don't flag (just decide and document in commit):
- Implementation patterns, error handling, code organization
- File structure and component design
- Which existing patterns/utilities to reuse
- Test strategy within E2E framework
- Performance optimizations, database indexes
- New tables or endpoints (migration/commit IS the documentation)

---

## Open Flags

_None currently._

---

## Resolved Flags

_None yet._
