# Nexxus SRS Addendum v3.1: MVP Critical Features & Architecture Clarifications

**Document Version:** 3.1-ADD1
**Date:** February 3, 2026
**Status:** Active Addendum
**Classification:** Confidential
**Addendum Type:** Requirements Extension & Architecture Clarification

---

## Document Addendum Strategy

### Purpose of Addendum Approach

Due to the complexity and size of the Nexxus System Requirements Specification, we are adopting a **chained addendum strategy** rather than continuously updating a single massive document. This approach provides:

1. **Version Control**: Clear tracking of requirement changes over time
2. **Focus**: Each addendum addresses a specific set of features or clarifications
3. **Flexibility**: Easier to review, approve, and implement discrete requirement sets
4. **Traceability**: Clear audit trail of when requirements were added
5. **Maintainability**: Reduces risk of document corruption or loss during large edits

### Addendum Chain Structure

```
Nexxus_SRS_v3.0_MASTER.md (January 30, 2026)
    ↓ [References]
Nexxus_SRS_Addendum_v3.1_MVP_Critical.md (February 3, 2026) ← YOU ARE HERE
    ↓ [References]
Nexxus_SRS_Addendum_v3.2_[Future Topic].md (TBD)
    ↓ [References]
[Additional addendums as needed]
```

### How to Use This Addendum

1. **Read the Base SRS First**: Review `Nexxus_SRS_v3.0_MASTER.md` for foundational architecture
2. **Apply Addendum Requirements**: All requirements in this addendum are additive or clarifying - they do not replace base SRS content unless explicitly stated
3. **Implementation Priority**: Requirements are grouped by phase priority (see Phase Definitions below)
4. **Code Implementation Caveat**: Any code examples in this addendum are **illustrative only** - they should inform implementation decisions but NOT override existing working code or architectural approaches already established in the codebase

### Document References

- **Base Document**: `Nexxus_SRS_v3.0_MASTER.md` (January 30, 2026)
- **Previous Addendum**: None (this is the first addendum)
- **Next Addendum**: TBD (will be created as new requirements emerge)

---

## Table of Contents

1. **Architecture Clarifications**
   - 1.1 VIN Solutions Integration Architecture (CRITICAL CORRECTION)
   - 1.2 Context Router Data Aggregation Strategy

2. **Phase 1: MVP Critical - Customer-Facing Features**
   - 2.1 Chat UX Enhancements
   - 2.2 VAPI Activity Insights (CRITICAL)
   - 2.3 Tavus Activity Insights (CRITICAL)

3. **Phase 2: Post-MVP High Priority**
   - 3.1 Calendar & Scheduling System
   - 3.2 Universal Inbox & Email System
   - 3.3 Data Visualization & Charts in Chat
   - 3.4 Password Reset

4. **Phase 3: Advanced Features**
   - 4.1 Goals Integration (Center of Orbit)
   - 4.2 Agent Instructions in Chat Context
   - 4.3 Complex Data Visualization

5. **Phase 4: Automation & Intelligence**
   - 5.1 VIN Triggers for Outbound Actions
   - 5.2 Super Admin Automa Settings

6. **Implementation Roadmap**

7. **Database Schema Additions**

---

## 1. Architecture Clarifications

### 1.1 VIN Solutions Integration Architecture (CRITICAL CORRECTION)

> **IMPORTANT**: This section corrects and clarifies assumptions that may have been made in the base SRS v3.0 regarding VIN Solutions integration.

#### REQ-VIN-CLARIFY-001 [ARCHITECTURE]: VIN Solutions Integration Model

**Current Integration Tier:** Lead Management API (query-only access)

**What We HAVE:**
- Query-driven access to VIN Solutions Lead Management API
- OAuth 2.0 Client Credentials authentication
- Ability to GET lead data, customer data, vehicle inventory on-demand
- Manual/scheduled report upload capability

**What We DO NOT HAVE:**
- Bidirectional sync capability
- Webhook subscriptions for real-time events
- Batch sync endpoints
- Write-back capabilities to VIN Solutions CRM

**Why This Matters:**
- **API Quota Preservation**: Batch syncing would rapidly consume our limited API call quota
- **Cost Management**: Higher-tier integrations with webhook/sync capabilities are not currently purchased
- **Architecture Design**: System must be designed around query-driven aggregation, not push-based sync

---

#### REQ-VIN-CLARIFY-002 [ARCHITECTURE]: Query-Driven Aggregation Strategy

The Nexxus platform SHALL implement a **query-driven data aggregation model** for VIN Solutions integration:

**Implementation Approach:**

1. **On-Demand Queries**: Data is fetched from VIN Solutions API only when needed
   - User views a lead → Query VIN API for lead details
   - DealerBrain needs lead context → Query VIN API
   - Report generation → Query VIN API for specific data ranges

2. **Report Upload Strategy**: Background data is filled via report uploads
   - Daily/weekly VIN Solutions reports exported manually or via scheduled automation
   - Reports uploaded to Nexxus Drive
   - DealerBrain parses and indexes report data
   - Indexed data used for background context without API calls

3. **Smart Caching**: Reduce API calls through intelligent caching
   - Cache lead data for 15-30 minutes after fetch
   - Cache vehicle inventory data for 1-2 hours
   - Invalidate cache on user-initiated refresh

**Database Schema for VIN Cache:**

```sql
CREATE TABLE vin_lead_cache (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,

    -- VIN Solutions identifiers
    vin_lead_id VARCHAR(255) NOT NULL,
    vin_customer_id VARCHAR(255),

    -- Cached lead data
    lead_data JSONB NOT NULL,
    customer_data JSONB,

    -- Cache metadata
    fetched_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    cache_hit_count INTEGER DEFAULT 0,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    UNIQUE(organization_id, vin_lead_id)
);

CREATE INDEX idx_vin_lead_cache_org_expires ON vin_lead_cache(organization_id, expires_at);
CREATE INDEX idx_vin_lead_cache_vin_id ON vin_lead_cache(vin_lead_id);
```

**Acceptance Criteria:**
- ✓ VIN API queries triggered only on explicit user actions or DealerBrain context needs
- ✓ Cached data served for repeat requests within expiration window
- ✓ API call quota monitored and alerts triggered at 80% usage
- ✓ Report uploads successfully parsed and indexed
- ✓ No automatic batch syncing or polling loops

---

#### REQ-VIN-CLARIFY-003 [ARCHITECTURE]: Report Upload & Analysis Pipeline

The system SHALL support manual and automated upload of VIN Solutions reports for background data enrichment:

**Report Types Supported:**
- Lead activity reports (CSV, Excel)
- Vehicle inventory reports
- Sales performance reports
- Service appointment reports

**Upload & Processing Flow:**

```
1. User uploads VIN report via Drive or direct upload button
   ↓
2. System detects file type and identifies as VIN report
   ↓
3. DealerBrain parses report structure and extracts data
   ↓
4. Data indexed in vin_report_cache table with metadata
   ↓
5. Context Router makes data available for queries
   ↓
6. User can ask questions about report data via chat
```

**Database Schema for Report Cache:**

```sql
CREATE TABLE vin_report_cache (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,

    -- Report metadata
    report_type VARCHAR(100) NOT NULL, -- 'leads', 'inventory', 'sales', 'service'
    report_date_range DATERANGE,
    artifact_id UUID REFERENCES drive_artifacts(id), -- Link to uploaded file

    -- Parsed data
    report_data JSONB NOT NULL, -- Structured/indexed report content
    record_count INTEGER,

    -- Processing metadata
    uploaded_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    processed_at TIMESTAMP WITH TIME ZONE,
    processing_status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'processing', 'completed', 'error'
    error_message TEXT,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_vin_report_cache_org_type ON vin_report_cache(organization_id, report_type);
CREATE INDEX idx_vin_report_cache_date ON vin_report_cache(report_date_range);
```

**Acceptance Criteria:**
- ✓ User uploads CSV/Excel VIN report via Drive
- ✓ System auto-detects VIN report format
- ✓ DealerBrain successfully parses and indexes report data
- ✓ User can query report data via chat without API calls
- ✓ Report data integrated with Context Router queries

---

### 1.2 Context Router Data Aggregation Strategy

#### REQ-CONTEXT-001 [ARCHITECTURE]: Context Router as Data Taming Layer

**The Soul of This Phase:** The Context Router is the central orchestration layer that **tames chaotic data** from multiple sources.

**Data Sources Handled:**

1. **VIN Solutions API Queries** (on-demand, cached)
2. **VIN Report Uploads** (background enrichment)
3. **Chat Conversations** (DealerBrain interactions)
4. **Manual File Uploads** (PDFs, CSVs, Excel, images)
5. **Third-Party Integrations** (VAPI call logs, Tavus session data)
6. **Tool Outputs** (agent execution results, calculations)

**Context Router Responsibilities:**

```typescript
// ILLUSTRATIVE EXAMPLE ONLY - DO NOT OVERRIDE EXISTING IMPLEMENTATION
interface ContextRouterQuery {
  organizationId: UUID;
  userId: UUID;
  queryType: 'lead' | 'customer' | 'inventory' | 'conversation' | 'report';
  queryParams: Record<string, any>;
  requiredFreshness?: number; // minutes - prefer cached data unless older than this
}

interface ContextRouterResponse {
  data: any;
  source: 'vin_api' | 'vin_cache' | 'report_upload' | 'chat_history' | 'drive_artifact';
  timestamp: Date;
  cacheStatus: 'hit' | 'miss' | 'expired';
}

// Context Router aggregates data without making unnecessary API calls
async function queryContextRouter(query: ContextRouterQuery): Promise<ContextRouterResponse> {
  // 1. Check cache first
  const cached = await checkCache(query);
  if (cached && isFresh(cached, query.requiredFreshness)) {
    return { ...cached, cacheStatus: 'hit' };
  }

  // 2. Check report uploads
  const reportData = await checkReportCache(query);
  if (reportData) {
    return { ...reportData, source: 'report_upload' };
  }

  // 3. Check chat history / drive artifacts
  const historicalData = await checkHistoricalData(query);
  if (historicalData) {
    return historicalData;
  }

  // 4. Only if no cached/uploaded data exists, query VIN API
  if (requiresRealTimeData(query)) {
    const apiData = await queryVinAPI(query);
    await cacheResult(apiData, query);
    return { ...apiData, source: 'vin_api', cacheStatus: 'miss' };
  }

  throw new Error('No data available for query');
}
```

**Acceptance Criteria:**
- ✓ Context Router checks cache before making API calls
- ✓ Report upload data prioritized over API calls when available
- ✓ Chat history and artifacts searchable via Context Router
- ✓ API call metrics tracked per organization
- ✓ Quota alerts triggered at 80% usage

---

## 2. Phase 1: MVP Critical - Customer-Facing Features

**Priority:** P0 - MUST be working for customer demos and initial rollout
**Timeline:** Immediate (Days 1-5)

### 2.1 Chat UX Enhancements

#### REQ-CHAT-UX-001 [P0]: Streaming Thinking Indicators

The chat interface SHALL display real-time thinking/activity indicators that show nested activities and sub-tasks, similar to advanced AI chat interfaces.

**User Experience:**

When DealerBrain is processing a request, users see:

```
💭 Thinking...
  → Analyzing your request
  → Querying VIN Solutions for lead data
  → Generating insights
  ✓ Analysis complete
```

Or for artifact creation:

```
🔨 Creating artifact...
  → Extracting data from uploaded report
  → Building visualization
  → Generating chart with 847 data points
  ✓ Visualization ready
```

**Implementation Requirements:**
- Stream status updates via SSE (Server-Sent Events)
- Show hierarchical activity tree (parent task → sub-tasks)
- Display completion checkmarks for finished tasks
- Show estimated time for long-running operations
- Collapsible activity log after completion

**Database Schema for Activity Tracking:**

```sql
CREATE TABLE chat_activities (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id UUID NOT NULL REFERENCES chat_conversations(id) ON DELETE CASCADE,
    message_id UUID REFERENCES chat_messages(id),

    -- Activity details
    activity_type VARCHAR(100) NOT NULL, -- 'thinking', 'artifact_creation', 'data_query', 'analysis'
    parent_activity_id UUID REFERENCES chat_activities(id), -- For nested activities

    description TEXT NOT NULL, -- "Analyzing your request"
    status VARCHAR(20) DEFAULT 'in_progress', -- 'in_progress', 'completed', 'error'

    -- Timing
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    duration_ms INTEGER, -- Calculated on completion

    -- Metadata
    metadata JSONB DEFAULT '{}', -- Additional context (data counts, API calls, etc.)

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_chat_activities_conversation ON chat_activities(conversation_id, started_at);
CREATE INDEX idx_chat_activities_parent ON chat_activities(parent_activity_id);
```

**Acceptance Criteria:**
- ✓ User sees real-time thinking indicators during AI processing
- ✓ Nested activities (sub-tasks) displayed with indentation
- ✓ Completion checkmarks appear when tasks finish
- ✓ Activity log collapsible after completion
- ✓ Smooth streaming without UI jank

---

#### REQ-CHAT-UX-002 [P0]: Upload Button in Chat Interface

The chat interface SHALL include an upload button that allows users to upload files and reports for immediate analysis by DealerBrain.

**User Experience:**

```
[Chat Input Field]  [📎 Upload]  [Send]
```

User clicks Upload → File picker → Selects VIN report CSV → File uploaded → DealerBrain automatically:
1. Acknowledges upload
2. Detects file type
3. Begins analysis
4. Provides smart follow-up prompts

**Supported File Types:**
- **Reports**: CSV, Excel (XLSX, XLS)
- **Documents**: PDF, DOCX, TXT
- **Images**: JPEG, PNG (for OCR analysis if needed)
- **Archives**: ZIP (extracts and processes contents)

**Smart Context Detection:**

After upload, DealerBrain suggests contextual actions:

```
✅ VIN Solutions Lead Report uploaded (847 leads)

💡 What would you like to know?
• Show me leads from the last 7 days
• Which leads have the highest engagement score?
• Create a visualization of lead sources
• Identify leads that need immediate follow-up
```

**Acceptance Criteria:**
- ✓ Upload button visible in chat interface
- ✓ File picker supports all specified file types
- ✓ Files upload to Drive and link to conversation
- ✓ DealerBrain auto-detects file type and purpose
- ✓ Smart follow-up prompts generated after upload
- ✓ Upload progress indicator during large file uploads

---

#### REQ-CHAT-UX-003 [P0]: Smart Follow-Up Prompts

DealerBrain SHALL generate contextual, clickable follow-up prompts after each response to guide users toward deeper insights and actions.

**User Experience:**

After DealerBrain responds, users see 3-5 smart suggestions:

```
DealerBrain: Based on the uploaded report, you have 47 high-priority leads...

💡 Try asking:
• [Show me the top 5 leads by engagement score]
• [Which leads should I call today?]
• [Create a chart showing lead trends this week]
• [Find leads interested in SUVs]
• [Schedule follow-ups for hot leads]
```

**Prompt Generation Logic:**

```typescript
// ILLUSTRATIVE ONLY - DO NOT OVERRIDE EXISTING IMPLEMENTATION
interface SmartPromptContext {
  conversationHistory: Message[];
  lastResponse: string;
  availableData: string[]; // ['vin_leads', 'call_logs', 'reports']
  userRole: string;
}

async function generateSmartPrompts(context: SmartPromptContext): Promise<string[]> {
  const prompt = `Based on this conversation context, suggest 3-5 relevant follow-up questions
  that would help the user take action or gain deeper insights. Make them specific and actionable.

  Context: ${JSON.stringify(context)}

  Return as JSON array of strings.`;

  const suggestions = await claude.generateSuggestions(prompt);
  return suggestions;
}
```

**Acceptance Criteria:**
- ✓ 3-5 clickable prompts displayed after each DealerBrain response
- ✓ Prompts contextually relevant to conversation and available data
- ✓ Clicking prompt sends it as next user message
- ✓ Prompts updated dynamically based on conversation flow
- ✓ Prompts prioritize actionable insights over generic questions

---

### 2.2 VAPI Activity Insights (CRITICAL)

#### REQ-VAPI-INSIGHTS-001 [P0]: VAPI Call Activity Dashboard

The Insights section SHALL display comprehensive VAPI call activity data in a dedicated dashboard view.

**Dashboard Components:**

1. **Call Log Table**
   - Columns: Timestamp, Phone Number, Direction (Inbound/Outbound), Duration, Status, Agent Used, Outcome
   - Sortable and filterable
   - Click row → View full call details
   - Real-time updates via SSE

2. **Call Details View**
   - Full transcript with speaker labels (Customer / AI Agent)
   - Call recording playback (if available and within 30-day retention)
   - Sentiment analysis per turn
   - Key topics detected
   - Action items extracted
   - Lead/customer linking

3. **Call Analytics**
   - Total calls today/week/month
   - Average call duration
   - Success rate (appointment booked, info provided, etc.)
   - Top reasons for calls
   - Peak call times

**Database Schema:**

```sql
CREATE TABLE vapi_call_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,

    -- VAPI identifiers
    vapi_call_id VARCHAR(255) NOT NULL UNIQUE,
    vapi_assistant_id VARCHAR(255) NOT NULL,

    -- Call details
    direction VARCHAR(20) NOT NULL, -- 'inbound', 'outbound'
    phone_number VARCHAR(50) NOT NULL,
    customer_name VARCHAR(255),

    -- Timing
    started_at TIMESTAMP WITH TIME ZONE NOT NULL,
    ended_at TIMESTAMP WITH TIME ZONE,
    duration_seconds INTEGER,

    -- Call data
    transcript JSONB, -- Full transcript with speaker turns
    recording_url TEXT, -- VAPI recording URL (30-day retention)
    recording_expires_at TIMESTAMP WITH TIME ZONE,

    -- Analysis
    call_status VARCHAR(50), -- 'completed', 'no_answer', 'busy', 'failed'
    call_outcome VARCHAR(100), -- 'appointment_booked', 'info_provided', 'callback_requested'
    sentiment VARCHAR(20), -- 'positive', 'neutral', 'negative'
    topics JSONB DEFAULT '[]', -- ["pricing", "test_drive", "financing"]
    action_items JSONB DEFAULT '[]',

    -- Linking
    linked_lead_id UUID,
    linked_customer_id UUID,
    appointment_id UUID REFERENCES appointments(id),
    conversation_id UUID REFERENCES chat_conversations(id), -- If discussed in chat

    -- Metadata
    cost_usd DECIMAL(10,4), -- VAPI usage cost

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_vapi_call_logs_org_time ON vapi_call_logs(organization_id, started_at DESC);
CREATE INDEX idx_vapi_call_logs_phone ON vapi_call_logs(phone_number);
CREATE INDEX idx_vapi_call_logs_status ON vapi_call_logs(call_status);
```

**Data Sync Strategy:**

Since webhooks are disabled (`ENABLE_WEBHOOKS=false`), the system SHALL:
1. Poll VAPI API for call logs every 5 minutes
2. Fetch new calls since last sync timestamp
3. Download transcripts and metadata
4. Run AI analysis on transcripts (sentiment, topics, action items)
5. Auto-link to leads/customers by phone number
6. Update dashboard via SSE real-time push

**Acceptance Criteria:**
- ✓ VAPI calls displayed in Insights dashboard within 5 minutes of completion
- ✓ Full transcript viewable with speaker labels
- ✓ Recording playback available (within 30-day retention)
- ✓ AI sentiment analysis shows per-turn and overall sentiment
- ✓ Topics and action items extracted and displayed
- ✓ Calls auto-linked to existing leads/customers
- ✓ Dashboard updates in real-time as new calls come in
- ✓ Call log exportable to CSV/Excel

---

#### REQ-VAPI-INSIGHTS-002 [P0]: VAPI Recording Retention Management

The system SHALL implement automatic 30-day recording retention with daily cleanup as specified in SRS v3.0 Section 4.5.

**Retention Policy:**
- Recordings expire 30 days after call completion
- Daily cron job at 2:00 AM deletes expired recordings
- Database records retained (transcript remains, recording URL nullified)
- User notification if attempting to play expired recording

**Cleanup Job:**

```typescript
// ILLUSTRATIVE ONLY - DO NOT OVERRIDE EXISTING IMPLEMENTATION
async function vapiRecordingCleanupJob() {
  const expiredCalls = await db.query(`
    SELECT id, vapi_call_id, recording_url
    FROM vapi_call_logs
    WHERE recording_expires_at < NOW()
    AND recording_url IS NOT NULL
  `);

  for (const call of expiredCalls) {
    // Delete from VAPI storage
    await vapiClient.deleteRecording(call.vapi_call_id);

    // Nullify URL in database
    await db.query(`
      UPDATE vapi_call_logs
      SET recording_url = NULL
      WHERE id = $1
    `, [call.id]);
  }

  console.log(`Cleaned up ${expiredCalls.length} expired VAPI recordings`);
}

// Run daily at 2:00 AM
cron.schedule('0 2 * * *', vapiRecordingCleanupJob);
```

**Acceptance Criteria:**
- ✓ Recordings expire exactly 30 days after call completion
- ✓ Cron job runs daily at 2:00 AM
- ✓ Expired recordings deleted from VAPI storage
- ✓ Database recording URLs nullified after deletion
- ✓ User sees "Recording expired" message if attempting to play
- ✓ Transcript remains accessible after recording expiration

---

### 2.3 Tavus Activity Insights (CRITICAL)

#### REQ-TAVUS-INSIGHTS-001 [P0]: Tavus Video Session Dashboard

The Insights section SHALL display comprehensive Tavus video session data in a dedicated dashboard view.

**Dashboard Components:**

1. **Session Log Table**
   - Columns: Timestamp, Customer Name/Email, Persona Used, Duration, Status, Engagement Score
   - Sortable and filterable
   - Click row → View full session details
   - Real-time updates via SSE

2. **Session Details View**
   - Conversation transcript with timestamps
   - Video recording playback (if available and within 30-day retention)
   - Engagement metrics (attention score, facial expressions, interaction quality)
   - Key topics discussed
   - Action items extracted
   - Lead/customer linking

3. **Session Analytics**
   - Total sessions today/week/month
   - Average session duration
   - Average engagement score
   - Top personas used
   - Conversion metrics (sessions → appointments/sales)

**Database Schema:**

```sql
CREATE TABLE tavus_session_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,

    -- Tavus identifiers
    tavus_conversation_id VARCHAR(255) NOT NULL UNIQUE,
    tavus_persona_id VARCHAR(255) NOT NULL,
    tavus_replica_id VARCHAR(255),

    -- Session details
    customer_name VARCHAR(255),
    customer_email VARCHAR(255),
    customer_phone VARCHAR(50),

    -- Timing
    started_at TIMESTAMP WITH TIME ZONE NOT NULL,
    ended_at TIMESTAMP WITH TIME ZONE,
    duration_seconds INTEGER,

    -- Session data
    transcript JSONB, -- Full conversation transcript with timestamps
    recording_url TEXT, -- Tavus recording URL (30-day retention)
    recording_expires_at TIMESTAMP WITH TIME ZONE,

    -- Engagement metrics
    session_status VARCHAR(50), -- 'completed', 'abandoned', 'error'
    engagement_score DECIMAL(3,2), -- 0.00 to 1.00
    attention_score DECIMAL(3,2),
    interaction_quality VARCHAR(20), -- 'excellent', 'good', 'fair', 'poor'

    -- Analysis
    topics JSONB DEFAULT '[]', -- ["vehicle_specs", "financing", "test_drive"]
    sentiment VARCHAR(20), -- 'positive', 'neutral', 'negative'
    action_items JSONB DEFAULT '[]',

    -- Linking
    linked_lead_id UUID,
    linked_customer_id UUID,
    appointment_id UUID REFERENCES appointments(id),
    conversation_id UUID REFERENCES chat_conversations(id),

    -- Metadata
    cost_usd DECIMAL(10,4), -- Tavus usage cost

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_tavus_session_logs_org_time ON tavus_session_logs(organization_id, started_at DESC);
CREATE INDEX idx_tavus_session_logs_email ON tavus_session_logs(customer_email);
CREATE INDEX idx_tavus_session_logs_status ON tavus_session_logs(session_status);
CREATE INDEX idx_tavus_session_logs_engagement ON tavus_session_logs(engagement_score DESC);
```

**Data Sync Strategy:**

Since webhooks are disabled, the system SHALL:
1. Poll Tavus API for session logs every 5 minutes
2. Fetch new sessions since last sync timestamp
3. Download transcripts and engagement metrics
4. Run AI analysis on transcripts (topics, sentiment, action items)
5. Auto-link to leads/customers by email/phone
6. Update dashboard via SSE real-time push

**Acceptance Criteria:**
- ✓ Tavus sessions displayed in Insights dashboard within 5 minutes of completion
- ✓ Full transcript viewable with timestamps
- ✓ Video recording playback available (within 30-day retention)
- ✓ Engagement score and attention metrics displayed
- ✓ Topics and action items extracted and displayed
- ✓ Sessions auto-linked to existing leads/customers
- ✓ Dashboard updates in real-time as new sessions complete
- ✓ Session log exportable to CSV/Excel

---

#### REQ-TAVUS-INSIGHTS-002 [P0]: Tavus Recording Retention Management

The system SHALL implement automatic 30-day recording retention with daily cleanup as specified in SRS v3.0 Section 4.5.

**Retention Policy:**
- Recordings expire 30 days after session completion
- Daily cron job at 2:00 AM deletes expired recordings
- Database records retained (transcript remains, recording URL nullified)
- User notification if attempting to play expired recording

**Cleanup Job:**

```typescript
// ILLUSTRATIVE ONLY - DO NOT OVERRIDE EXISTING IMPLEMENTATION
async function tavusRecordingCleanupJob() {
  const expiredSessions = await db.query(`
    SELECT id, tavus_conversation_id, recording_url
    FROM tavus_session_logs
    WHERE recording_expires_at < NOW()
    AND recording_url IS NOT NULL
  `);

  for (const session of expiredSessions) {
    // Delete from Tavus storage
    await tavusClient.deleteRecording(session.tavus_conversation_id);

    // Nullify URL in database
    await db.query(`
      UPDATE tavus_session_logs
      SET recording_url = NULL
      WHERE id = $1
    `, [session.id]);
  }

  console.log(`Cleaned up ${expiredSessions.length} expired Tavus recordings`);
}

// Run daily at 2:00 AM (same time as VAPI cleanup)
cron.schedule('0 2 * * *', tavusRecordingCleanupJob);
```

**Acceptance Criteria:**
- ✓ Recordings expire exactly 30 days after session completion
- ✓ Cron job runs daily at 2:00 AM
- ✓ Expired recordings deleted from Tavus storage
- ✓ Database recording URLs nullified after deletion
- ✓ User sees "Recording expired" message if attempting to play
- ✓ Transcript remains accessible after recording expiration

---

#### REQ-TAVUS-INSIGHTS-003 [P0]: Unified Insights Activity Feed

The Insights section SHALL provide a unified activity feed that combines VAPI calls and Tavus sessions in chronological order.

**Feed View:**

```
📊 All Activity (Last 7 Days)

🎙️ [10:43 AM] Voice Call - Inbound from (555) 123-4567
   Duration: 4m 32s | Status: Appointment Booked | Agent: Sales Assistant

🎥 [10:15 AM] Video Session - John Smith
   Duration: 8m 12s | Engagement: 92% | Persona: Product Specialist

🎙️ [9:58 AM] Voice Call - Outbound to (555) 987-6543
   Duration: 2m 18s | Status: No Answer | Agent: Follow-up Bot

📊 [9:30 AM] Data Report - VIN Lead Activity Uploaded
   847 leads analyzed | 47 high-priority identified

🎥 [9:12 AM] Video Session - Sarah Johnson
   Duration: 12m 45s | Engagement: 88% | Persona: Finance Advisor
```

**Filtering & Search:**
- Filter by activity type (Voice, Video, Reports, Chat)
- Filter by date range
- Filter by status/outcome
- Search by customer name, phone, email
- Export filtered view to CSV

**Acceptance Criteria:**
- ✓ Unified feed shows all activity types chronologically
- ✓ Clear visual distinction between activity types (icons, colors)
- ✓ Filtering works smoothly without page reload
- ✓ Search finds activities by customer identifiers
- ✓ Feed updates in real-time as new activities occur
- ✓ Click any activity → Navigate to detailed view

---

## 3. Phase 2: Post-MVP High Priority

**Priority:** P1 - High priority for full product launch
**Timeline:** Days 6-15

### 3.1 Calendar & Scheduling System

**Status:** Deferred from MVP Critical to Post-MVP High Priority

Full Requirements: See separate planning document for complete Calendar & Scheduling specifications with:
- FullCalendar integration
- Appointment management
- AI-powered booking via VAPI
- SMS confirmations
- Availability management
- Google Calendar sync (Phase 2b)

**Database Schemas:** `appointments`, `availability_blocks`, `appointment_reminders`

**Phase 2a:** Core calendar UI and manual scheduling (Days 6-9)
**Phase 2b:** Google Calendar OAuth sync (Days 10-12)
**Phase 2c:** AI booking integration with VAPI (Days 13-15)

---

### 3.2 Universal Inbox & Email System

**Status Verification Needed:** User reported this might already be working and ready to go.

IF NOT WORKING, full requirements include:
- Open-source stack: React Email + ImapFlow + Nodemailer + Tiptap
- User-level email integrations (Gmail, Outlook, IMAP/SMTP)
- Background sync workers
- AI email analysis (category, priority, sentiment, summary)
- Auto-linking to customers/leads
- OAuth for Gmail/Outlook (Phase 2b)

**Action Required:** Verify current implementation status before including in Phase 2 scope.

---

### 3.3 Data Visualization & Charts in Chat

#### REQ-DATAVIZ-001 [P1]: Chart Generation in Chat Responses

DealerBrain SHALL generate interactive charts and visualizations as part of chat responses when analyzing data.

**Supported Chart Types:**
- Bar charts (comparisons, rankings)
- Line charts (trends over time)
- Pie charts (distribution, percentages)
- Scatter plots (correlations)
- Heatmaps (complex multi-dimensional data)
- Tables with sorting/filtering

**User Experience:**

```
User: "Show me lead trends for the last 30 days"

DealerBrain: Based on your VIN Solutions data, here's the trend analysis:

[📊 Interactive Line Chart]
Leads Per Day (Last 30 Days)
[Chart shows daily lead volume with 30-day trend line]

Key insights:
• Average: 28 leads/day
• Peak: 47 leads on Jan 15 (Presidents Day Sale)
• Low: 12 leads on Jan 27 (Sunday)
• 15% increase vs. previous 30 days

💡 Try asking:
• [Break down leads by source]
• [Show me conversion rates by day]
• [Which days should we increase staffing?]
```

**Implementation Approach:**

```typescript
// ILLUSTRATIVE ONLY - DO NOT OVERRIDE EXISTING IMPLEMENTATION
interface ChartArtifact {
  type: 'chart';
  chartType: 'bar' | 'line' | 'pie' | 'scatter' | 'heatmap' | 'table';
  data: any[];
  config: {
    title: string;
    xAxis?: string;
    yAxis?: string;
    colors?: string[];
  };
}

async function generateChart(prompt: string, data: any[]): Promise<ChartArtifact> {
  // Ask Claude to determine best chart type and configuration
  const chartSpec = await claude.analyzeDataForVisualization(prompt, data);

  // Generate chart artifact
  return {
    type: 'chart',
    chartType: chartSpec.recommendedType,
    data: chartSpec.processedData,
    config: chartSpec.config
  };
}
```

**Frontend Rendering:**

Use **Tremor** (already in tech stack per SRS v3.0 Section 7.1) for chart rendering:
- `BarChart`
- `LineChart`
- `DonutChart`
- `ScatterChart`
- `AreaChart`

**Acceptance Criteria:**
- ✓ DealerBrain generates charts when analyzing numeric data
- ✓ Charts interactive (hover for details, zoom, pan)
- ✓ Charts responsive and mobile-friendly
- ✓ Charts exportable as PNG/SVG
- ✓ Data table view available as alternative to chart
- ✓ Chart type selection automatic based on data structure

---

### 3.4 Password Reset

#### REQ-AUTH-001 [P1]: Password Reset Flow

The system SHALL implement standard password reset functionality as part of user management CRUD operations.

**User Flow:**
1. User clicks "Forgot Password" on login page
2. User enters email address
3. System sends password reset email via Resend
4. Email contains secure reset link (token expires in 1 hour)
5. User clicks link → Redirected to reset password page
6. User enters new password (validated for strength)
7. Password updated → User automatically logged in

**Security Requirements:**
- Reset tokens expire in 1 hour
- Tokens single-use only
- Password strength validation (min 12 characters, mix of upper/lower/numbers/symbols)
- Rate limiting on reset requests (max 3 per hour per email)
- Email notification sent when password changed

**Database Schema:**

```sql
CREATE TABLE password_reset_tokens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token VARCHAR(255) NOT NULL UNIQUE,
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL,
    used_at TIMESTAMP WITH TIME ZONE,
    ip_address INET,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_password_reset_tokens_token ON password_reset_tokens(token) WHERE used_at IS NULL;
CREATE INDEX idx_password_reset_tokens_expires ON password_reset_tokens(expires_at) WHERE used_at IS NULL;
```

**Acceptance Criteria:**
- ✓ User receives password reset email within 30 seconds
- ✓ Reset link works and loads password reset page
- ✓ Expired tokens rejected with clear error message
- ✓ Used tokens cannot be reused
- ✓ Password strength validated before acceptance
- ✓ User automatically logged in after successful reset
- ✓ Security notification email sent after password change

---

## 4. Phase 3: Advanced Features

**Priority:** P2 - Important for competitive differentiation
**Timeline:** Days 16-30

### 4.1 Goals Integration (Center of Orbit)

**Status:** Already defined in SRS v3.0 Section 8.2.16

**Enhancement Requirements:**

#### REQ-GOALS-001 [P2]: Goals as Central Dashboard Element

The Goals system SHALL become the "center of orbit" for the Nexxus platform, serving as the primary focus of the main dashboard.

**Dashboard Layout:**

```
┌─────────────────────────────────────────────────────────────┐
│  NEXXUS - Dashboard                                         │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  🎯 MONTHLY GOALS                                           │
│                                                              │
│  ┌─────────────────┐  ┌─────────────────┐  ┌──────────────┐│
│  │ Sales           │  │ Appointments    │  │ Lead Response││
│  │ $487K / $600K   │  │ 142 / 180       │  │ <30s         ││
│  │ ████████░░░░    │  │ ███████░░░░     │  │ ✓ On Target  ││
│  │ 81% (on track)  │  │ 79% (at risk)   │  │ 28s avg      ││
│  └─────────────────┘  └─────────────────┘  └──────────────┘│
│                                                              │
│  🔔 Goal Alerts                                             │
│  • Appointments goal at risk - 11 days left                 │
│  • 3 hot leads need follow-up today                         │
│                                                              │
│  📊 Activity Feed        🎙️ Recent Calls   🎥 Video Sessions│
│  [...]                  [...]              [...]            │
└─────────────────────────────────────────────────────────────┘
```

**Integration Points:**
- Goals tracked via VAPI calls, Tavus sessions, VIN data
- Real-time progress updates
- Automated alerts when goals at risk
- DealerBrain proactive suggestions to reach goals

**Acceptance Criteria:**
- ✓ Goals prominently displayed on main dashboard
- ✓ Real-time progress updates as activities occur
- ✓ Visual indicators for on-track vs. at-risk goals
- ✓ Automated alerts 3 days before goal period ends if at risk
- ✓ DealerBrain suggests actions to achieve goals

---

### 4.2 Agent Instructions in Chat Context

#### REQ-AGENT-CONTEXT-001 [P2]: Display Active Agent Instructions

When an account-level agent is active in a conversation, the chat interface SHALL display the agent's instructions and configuration in a collapsible context panel.

**User Experience:**

```
[Chat Interface]

┌─────────────────────────────────────────────────────────┐
│ 🤖 Active Agent: Follow-up Bot                          │
│ [Show Instructions ▼]                                   │
├─────────────────────────────────────────────────────────┤
│ Instructions:                                            │
│ • Call leads who haven't responded in 48 hours          │
│ • Qualify interest in test drive                        │
│ • Book appointments for qualified leads                 │
│ • Log outcome in VIN Solutions                          │
│                                                          │
│ Triggers: New lead added, 48hrs no response            │
│ Tools: VAPI outbound call, VIN API, Calendar           │
└─────────────────────────────────────────────────────────┘

[Chat Messages Continue Below]
```

**Acceptance Criteria:**
- ✓ Agent instructions visible when agent active in conversation
- ✓ Instructions collapsible to save space
- ✓ Clear indication of triggers and tools available to agent
- ✓ User can edit agent instructions from chat context (if Org Admin)

---

### 4.3 Complex Data Visualization

#### REQ-DATAVIZ-002 [P2]: Advanced Visualization Types

Expand chart generation capabilities to support complex, multi-dimensional visualizations:

**Additional Chart Types:**
- Funnel charts (conversion funnels)
- Sankey diagrams (flow visualization)
- Network graphs (relationship mapping)
- Geospatial heatmaps (location-based analysis)
- Multi-axis combo charts

**Use Cases:**
- Lead conversion funnel visualization
- Sales process flow analysis
- Customer journey mapping
- Territory performance mapping
- Multi-metric correlation analysis

---

## 5. Phase 4: Automation & Intelligence

**Priority:** P2-P3 - Important for automation value proposition
**Timeline:** Days 30-45

### 5.1 VIN Triggers for Outbound Actions

#### REQ-VIN-TRIGGERS-001 [P2]: Event-Driven Outbound Actions

The system SHALL support automated actions triggered by VIN Solutions events (via report analysis and scheduled checks).

**Trigger Types:**

1. **New Lead Trigger**
   - Detection: Daily report upload shows new leads
   - Action: VAPI outbound call during business hours
   - Configuration: Time window, agent to use, script parameters

2. **No-Response Trigger**
   - Detection: Lead hasn't been contacted in 48 hours
   - Action: VAPI follow-up call or email
   - Configuration: Wait time, escalation path

3. **Hot Lead Trigger**
   - Detection: High engagement score or specific behaviors
   - Action: Immediate VAPI call, SMS, or notification to sales rep
   - Configuration: Score thresholds, priority routing

4. **Appointment Reminder Trigger**
   - Detection: Appointment scheduled
   - Action: VAPI confirmation call 24 hours before
   - Configuration: Reminder timing, agent script

**Implementation Approach:**

```sql
CREATE TABLE vin_triggers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,

    -- Trigger definition
    trigger_type VARCHAR(100) NOT NULL, -- 'new_lead', 'no_response', 'hot_lead', 'appointment_reminder'
    trigger_name VARCHAR(255) NOT NULL,

    -- Conditions
    conditions JSONB NOT NULL, -- { "leadAge": "< 48h", "noContact": true, "businessHours": "9am-6pm" }

    -- Actions
    actions JSONB NOT NULL, -- [{ "type": "vapi_call", "agentId": "...", "script": "..." }]

    -- Schedule
    enabled BOOLEAN DEFAULT true,
    check_frequency VARCHAR(50) DEFAULT 'hourly', -- 'realtime', 'hourly', 'daily'
    business_hours_only BOOLEAN DEFAULT true,

    -- Tracking
    last_triggered_at TIMESTAMP WITH TIME ZONE,
    trigger_count INTEGER DEFAULT 0,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE vin_trigger_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    trigger_id UUID NOT NULL REFERENCES vin_triggers(id) ON DELETE CASCADE,

    -- Execution details
    triggered_by JSONB NOT NULL, -- Lead data that triggered the action
    actions_taken JSONB NOT NULL, -- Log of each action executed

    -- Outcome
    status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'completed', 'failed'
    error_message TEXT,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE
);

CREATE INDEX idx_vin_triggers_org ON vin_triggers(organization_id, enabled);
CREATE INDEX idx_vin_trigger_executions_trigger ON vin_trigger_executions(trigger_id, created_at);
```

**Acceptance Criteria:**
- ✓ Org Admins can create and configure VIN triggers
- ✓ Triggers checked at specified frequency
- ✓ VAPI outbound calls initiated automatically within business hours
- ✓ Trigger execution logged with outcome
- ✓ Failed triggers retry with exponential backoff
- ✓ Users can view trigger execution history

---

### 5.2 Super Admin Automa Settings

#### REQ-AUTOMA-ADMIN-001 [P3]: Super Admin Configuration Panel

Super Admins SHALL have access to advanced Automa (DealerBrain) configuration settings.

**Configurable Settings:**

1. **Model Selection**
   - Primary model (Claude 3.5 Sonnet, GPT-4, etc.)
   - Fallback models
   - Model-specific parameters (temperature, max tokens)

2. **System Instructions**
   - Global system prompt
   - Organization-specific instructions
   - Role-based instruction overrides

3. **Tool Availability**
   - Enable/disable specific tools platform-wide
   - Configure tool quotas and rate limits

4. **Context Router Settings**
   - Cache TTL configurations
   - API quota thresholds
   - Data source priorities

5. **Safety & Moderation**
   - Content filtering rules
   - PII detection and redaction
   - Approval thresholds

**Acceptance Criteria:**
- ✓ Super Admins access Automa Settings page
- ✓ Model selection dropdown with real-time switching
- ✓ System instructions editable with live preview
- ✓ Tool toggles affect availability immediately
- ✓ All changes logged in audit trail

---

## 6. Implementation Roadmap

### Timeline Overview

| Phase | Priority | Timeline | Focus Areas |
|-------|----------|----------|-------------|
| Phase 1: MVP Critical | P0 | Days 1-5 | Chat UX, VAPI Insights, Tavus Insights |
| Phase 2: Post-MVP | P1 | Days 6-15 | Calendar, Email (if needed), Data Viz, Password Reset |
| Phase 3: Advanced | P2 | Days 16-30 | Goals Center, Agent Context, Complex Viz |
| Phase 4: Automation | P2-P3 | Days 30-45 | VIN Triggers, Automa Admin |

### Phase 1 Details: MVP Critical (Days 1-5)

**Day 1-2: Chat UX Enhancements**
- Implement streaming thinking indicators
- Add upload button to chat interface
- Build smart follow-up prompt generation
- Database: `chat_activities` table

**Day 3: VAPI Insights Dashboard**
- Create VAPI call log table and sync worker
- Build call log dashboard UI
- Implement transcript viewer
- Add recording playback (with 30-day retention notice)

**Day 4: Tavus Insights Dashboard**
- Create Tavus session log table and sync worker
- Build session log dashboard UI
- Implement transcript viewer
- Add video recording playback

**Day 5: Unified Insights & Polish**
- Build unified activity feed
- Implement filtering and search
- Add real-time updates via SSE
- Testing and bug fixes

### Phase 2 Details: Post-MVP (Days 6-15)

**Days 6-9: Calendar System (Phase 2a)**
- FullCalendar integration
- Appointment CRUD operations
- Availability management
- Drag-and-drop scheduling

**Days 10-12: Calendar (Phase 2b)**
- Google Calendar OAuth
- Two-way sync implementation
- Conflict detection

**Days 13-15: Calendar (Phase 2c) & Other P1 Items**
- AI booking integration with VAPI
- SMS confirmations via Resend
- Data visualization (basic charts)
- Password reset flow

**Email:** Verify implementation status - if not working, add 3-4 days

### Phase 3 Details: Advanced Features (Days 16-30)

**Days 16-20: Goals Center**
- Goals dashboard redesign
- Real-time progress tracking
- Goal alerts and notifications

**Days 21-25: Agent Context & Complex Viz**
- Agent instructions in chat UI
- Advanced chart types
- Multi-dimensional visualizations

**Days 26-30: Polish & Testing**
- User acceptance testing
- Performance optimization
- Documentation updates

### Phase 4 Details: Automation (Days 30-45)

**Days 30-37: VIN Triggers**
- Trigger configuration UI
- Execution engine
- VAPI integration for outbound calls
- Execution logging and monitoring

**Days 38-42: Automa Admin**
- Super Admin settings panel
- Model configuration
- System instruction editor
- Tool management

**Days 43-45: Final Testing & Launch Prep**
- End-to-end testing
- Load testing
- Security audit
- Documentation finalization

---

## 7. Database Schema Additions

### Summary of New Tables

This addendum introduces the following new database tables:

| Table Name | Section | Purpose |
|------------|---------|---------|
| `vin_lead_cache` | 1.1 | Cache VIN API queries to reduce quota usage |
| `vin_report_cache` | 1.1 | Store parsed VIN report data |
| `chat_activities` | 2.1 | Track nested chat activities for UI indicators |
| `vapi_call_logs` | 2.2 | Store VAPI call history and transcripts |
| `tavus_session_logs` | 2.3 | Store Tavus session history and metrics |
| `password_reset_tokens` | 3.4 | Secure password reset token storage |
| `vin_triggers` | 5.1 | Define automated VIN event triggers |
| `vin_trigger_executions` | 5.1 | Log trigger execution history |

### Future Tables (Deferred to Later Addendums)

- `appointments` (Phase 2)
- `availability_blocks` (Phase 2)
- `appointment_reminders` (Phase 2)
- `user_integrations` (Phase 2 - if email not ready)
- `cached_emails` (Phase 2 - if email not ready)
- `sent_emails` (Phase 2 - if email not ready)

---

## Document Chain

- **Previous**: `Nexxus_SRS_v3.0_MASTER.md` (January 30, 2026)
- **Current**: `Nexxus_SRS_Addendum_v3.1_MVP_Critical.md` (February 3, 2026)
- **Next**: TBD (will be created as new requirements emerge)

---

## Code Implementation Caveat

> **IMPORTANT**: All code examples provided in this addendum are **illustrative only** and serve to clarify requirements and architectural patterns. They are NOT intended to replace or override any existing working code or established architectural approaches in the Nexxus V2 codebase.

**Implementation Guidelines:**

1. **Review Existing Code First**: Before implementing any requirement from this addendum, review the current codebase to understand existing patterns and approaches.

2. **Adapt, Don't Replace**: Use code examples as reference for understanding requirements, but adapt them to fit existing architectural patterns.

3. **Consult Context Files**: Reference `CLAUDE.md`, `.project/progress.md`, and session history for current implementation status.

4. **Preserve Working Features**: If a feature is already working (e.g., email system), do NOT reimplement based on addendum specs.

5. **Incremental Integration**: Integrate new requirements incrementally, ensuring each addition works with existing systems before proceeding.

6. **Test Thoroughly**: All new features must pass existing test suites and any new tests written for the feature.

---

## Approval & Sign-Off

| Role | Name | Date | Status |
|------|------|------|--------|
| Prepared By | AI Documentation Agent | February 3, 2026 | Draft |
| Reviewed By | | | Pending |
| Approved By | | | Pending |

---

**Document Version:** 3.1-ADD1
**Last Updated:** February 3, 2026
**Status:** Draft - Awaiting Review
