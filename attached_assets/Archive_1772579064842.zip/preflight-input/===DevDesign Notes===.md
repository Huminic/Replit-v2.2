# ===>Dev/Design Notes===  
  
  
I'm going to make a crack at creating an SRS for Nexus 2.1.   
  
I'm going to start a new claude agent and explain to them that they are taking the existing code base and using the new UI design and they are going to use the UI design as the source of truth.   
  
What I'm trying to do is I realized that Claude has bastardized our original design. I have not looked at it since we did the design contract. When I went back to Replit and looked at what we had created, I had an epiphany. There were so many things that I thought about and that went into our work that were lost that I didn't even realize how much had changed and how far it has drifted off course. What I'm going to do is I'm going to go back to our original design with the chat being the first thing you see when you log in except I'm going to add metrics On that page, and I'm going to have 4 tiles at the top.   
  
Included:   
home page infor with (4 main tiles at top and cat  
Chat Quality Acceptance  
Some design notes below  
Data probe to show fields and end points are available.    
Acceptance Criteria   
Site Map  
Design Contract  
Theme Contract  
UI Rules  
Hunches doc  
Insights data   
Main page data   
Reports info for insights  
HTML and UI with related notes and info  
  
Claude code must use the UI as a source of truth and maintain the UI components, subtleties and design elements.   
  
  
  
===============================Development notes===============================  
  
=====Overall=====  
  
  
  
Automa should be very very clear about any queries that are limited because of vin solutions.   
Super admin should be able to switch org like partner admin except there is an option to switch to “Nexxus System” which allows it to see the org UI as its configured  
partner admin should be able to switch org like partner admin except there is an option to switch to “[customer name slug]” which allows it to see the org UI as its configured  
Partner admin has similar settings to Super admin with exception of anything system wide  
WE HAVE TO REMEMBER TO REACTIVATE THE TOUR AND SET IT UP WITH RBAC SO THE TOUR WORKS DIFFERENTLY DEPENDING ON THE ROLE  
Content router should have 3 clear sections Memory stores, Synch Data, Upload Data Store and Web/3rd party data store  
  
  
  
=====Main=====  
  
Need to make sure tiles are there and wired (See design notes)  
  
  
=====Insights=====  
  
Insights is changing completely.   
```
📊 DASHBOARD (Real-time, Glanceable, Action-Oriented)
├── 🔴 Command Center (default landing page)
├── 📈 Pipeline Health
└── 🎯 Performance Scorecard

📑 REPORTS (Historical, Deep-Dive, Strategic)
├── 💀 Loss & Quality Analysis
├── 📊 Channel Intelligence
└── 📅 Trend & Forecast Reports

```
Hunches  
Goals - Remove   
  
=====Agents=====  
  
Everything's gonna be built around the chat or around agents. We're trying to make it a SaaS product. when we should be making an intelligent product.   
  
Communications Agent (Caroline for example)  
The communications agent for a dealer will be static and configured by the super admin which means there are two ages that will be available outside the box which will be agents that we control. The rest of the agents will be agents that are created by the user.   
  
Agent is the name of the Tavus agent and the vapi agent.   
Inside of Nexus she has access to all that data so she will also have the name of Caroline.   
  
From inside Agent can:  
-You can send an SMS to a customer or several.   
- can send an email to a customer or several.   
-Have the ability to attach an artifact from the drive or upload from chat to include in the transmission From in the chat.   
  
From inside of the right pane for the agent, there should be a link Which is the same link that a customer would use to talk to Caroline.   
The phone number should show up also inside of this pane.   
A link to the customer text chat should show up inside of this pane.   
  
Every agent should have contextual instructions/prompt and the ability to modify in the pane  
Automa  should have a per org setting that adds to ystem context.   
  
  
=====Hub=====  
Hub activities should be filtered by user in the system, but org admin sees all activity with a key that shows a colors mapped to users in the nexxus system depending on what page you are on  
Org admins and partner admins should be able to filter by a user or choose only to see their own stuff.   
  
=====Drive=====  
  
Drive was changed too much and should work as is  
we will need to add sharing functionality via email or sms  
  
  
  
  
===============================DESIGN NOTES==================================  
  
  
  
=====Main=====  
  
We are going back to the original design but we are adding 4 tiles at the top.   
  
  
=====Insights=====  
  
  
  
=====Overall=====  
  
  
Need to work extra to add meta data that coding agents can use to enforce continuity with design  
Remove the Icon From The logo   
Need to make sure we build out the configuration screen for the agents and that agents and automa have a place to insert instructions  
Activity Feed in the header should show lead activity for the org  
Notifications should come from Hunches  
Strong controls need put in place to prevent design drift, and there needs to be a design gate needs to compare against the contract and the mockups to ensure nothing has changed or shifted.   
All of the chat thinking animations should be a flat line that rolls like a wave  
haveing the dialouge for the bot on the left and user on the right is enough, no bot icon or initial icon is needed.   
Automa aka dealer brain Has created some confusion. The chat on the main page and any place where there's a right side pop-out will be named Automa. The dealer brain will simply be ommited.   
We are going to move activity in to a sub-tab in insights  
The order of the left side menu will be Main, Insights, Agents, Hub, Drive  
  
  
=====Main=====  
  
1. The section that says “nexxus connect” Should be replaced with a metrics section with 4 tiles   
2. Keep the chat on the main page as is  
  
top Metrics(4 TILES):   
  
Partner:  all partner metrics will be system based:    
  
1. # of sub orgs  
2.  # Customer logins last 24 hrs   
3. # of actions taken 24 hours   
4. Agent actions in 24 hours  
  
Org Admin:   
  
Pipeline Health  
Lead Source Performance  
Lead Quality  
Market Demand Insight  
  
  
Sales person (Staff) :   
  
1. **Hot Opportunities** (where to hunt)  
2. **Buying Intelligence** (what customers want)  
3. **Threats** (what's going wrong)  
4. **Urgency** (what's about to expire)  
5.   
=====Insights=====  
  
Sub Menu Items:   
  
```
📊 DASHBOARD (Real-time, Glanceable, Action-Oriented)
├── 🔴 Command Center (default landing page)
├── 📈 Pipeline Health
└── 🎯 Performance Scorecard

📑 REPORTS (Historical, Deep-Dive, Strategic)
├── 💀 Loss & Quality Analysis
├── 📊 Channel Intelligence
└── 📅 Trend & Forecast Reports

```
Library - Tiles with trend data for every metric we can see  
Hunches - See file for instructions  
Goals (Remove)  
  
Note: we should have the ability to view by grid or tiles where apprpriate and fliter by specific internal fields   
  
=====Agents=====  
  
1. The new agent button should open a center page with the dialouge in the center and tiles with the tools that are available below it. Clicking on the tiles opens a modal to allow the user to describes what it does.  (see clickup screenshot)  
2. For all agents the right side pop out should show the config in the right side pop out, and should include a log of activities (similar to screenshot)  
3. Automa will not be listed on the agent page anymore, And being that the right pop-out is gonna represent agent configuration settings, automa slash dealer brain does not need a presence on the agents page.   
4. Should be able to see triggers in right pane pop out  
5. Agent Prompt in right pane pop out  
6. Agent Knowledge in right pane pop out  
  
=====Hub=====  
  
When clicked it takes you to a page that has quick action button that for new message that opens modal (SMS, Email selection) ,   
Calendar - Opens calaendar and h  
Leads  - List of leads with a text button and a call button and a schedule button.   
Inbox - Takes you to a unniversal inbox that shows you all communication with a prospect. From here you can create an sms, create an email,  
  
  
  
=====Drive=====  
  
The drive needs the ability to send a file via email or SMS. So it needs a share button for each file.   
  
  
=====Settings =====  
  
These can be popup items but if someone clicks settings itself it should take to page with tiles  
  
Settings Sub Menu:   
Accounts   
Billing   
System - System Prompt, System Instructions, Misc System Settings(Super admin only)   
Tools - 3rd party api and mcp settings  (Super admin only)   
—Org admin only—  
Users - full CRUD for adding / removing users (partner admin can see all, partner admin can see their orgs, org admins can see org currently selected   
Knowledge - Data Uploads (ability to back out of uploads or delete), Data usage, Drive Data   
Instructions - Organization instructions,Organizational Prompt Hunch Instructions,  (per org),    
  
Staff cannot see settings  
  
  
  
  
  
  
  
  
