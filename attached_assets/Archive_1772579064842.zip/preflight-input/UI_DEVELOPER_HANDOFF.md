# Nexxus V2 - UI Developer Handoff Document

**Version:** 2.0
**Date:** January 21, 2026
**Status:** Ready for Implementation
**Classification:** Internal
**Target Audience:** UI/UX Developers, Frontend Engineers

---

## Table of Contents

1. [Navigation Map](#1-navigation-map)
2. [User Flows](#2-user-flows)
3. [User Features Matrix](#3-user-features-matrix)
4. [Screens Across States](#4-screens-across-states)
5. [Component Specifications](#5-component-specifications)
6. [Data Requirements](#6-data-requirements)
7. [Theme System](#7-theme-system)
8. [Wiring Guide](#8-wiring-guide)

---

## Document Purpose

This document is the **PRIMARY HANDOFF DOCUMENT** for UI developers to build the Nexxus V2 frontend. It contains:

- Complete navigation hierarchy and routes
- Detailed user flows with decision trees
- Role-based feature access matrix (4-tier RBAC)
- UI state documentation (5 states per screen)
- Component specifications with props and examples
- API endpoints and data contracts
- Theme system implementation guide
- Real-time subscription patterns
- Authentication and authorization wiring

**Target:** Enable frontend developers to build the complete UI without additional questions.

---

## 1. Navigation Map

### 1.1 Main Vertical Menu Structure

The application uses a **ClickUp-inspired vertical navigation menu** with 8 main items:

#### Main Menu Items (6 Items)

| # | Item | Icon | Route | Default | Popout Menu | View Config | Access |
|---|------|------|-------|---------|-------------|-------------|--------|
| 1 | **Main** | Home | `/` | Yes | • Favorites<br>• Message History | Chat Only View | All |
| 2 | **Agents** | Robot | `/agents` | No | • Agent Chat<br>• Create Agent<br>• Interact With Agents | Heavy Chat Work View | All |
| 3 | **Drive** | Folder | `/drive` | No | • My Files<br>• Shared Files<br>• Templates | Data/Information Display View | All |
| 4 | **Insights** | Chart | `/insights` | No | • Insight Engine<br>• Goals | Data/Information Display View | All |
| 5 | **Work Center** | Briefcase | `/work-center` | No | • Messages<br>• Calendar<br>• Tasks<br>• Hunches<br>• Approvals | Sub Menu Selections View | All |
| 6 | **Activity** | Activity | `/activity` | No | • Users<br>• Agents<br>• System | Data/Information Display View | Org Admin+ |

#### Bottom Menu Icons (2 Items)

| # | Item | Icon | Route | Position | Popout Menu | Access |
|---|------|------|-------|----------|-------------|--------|
| 7 | **System** | Settings | `/settings/system` | Bottom (fixed) | • Users<br>• Application Settings<br>• Tools<br>• Knowledge<br>• Hunch Configuration | Super Admin, Partner Admin (limited), Org Admin (limited) |
| 8 | **Profile** | User Avatar | `/profile` | Bottom (below System) | • Profile CRUD<br>• Preferences<br>• Logout | All |

#### Menu Behavior

**Display States:**
- **Expanded**: 240px wide, icon + text label (icon on top, title underneath)
- **Collapsed**: 64px wide, icon-only mode
- **Toggle**: User-controlled via menu icon or keyboard shortcut (`Ctrl+B`)
- **Persistence**: Menu state saved to `localStorage` per user

**Visual Design:**
- Clean, modern icons with consistent sizing (24x24px)
- Subtle hover states (background opacity: 10%)
- Active indicator (left border: 3px solid primary color)
- Smooth expand/collapse animation (200ms ease-in-out)

### 1.2 Top Bar Structure

The top bar is **always visible** across all pages and contains 7 persistent elements (left to right):

| # | Element | Icon | Behavior | Content |
|---|---------|------|----------|---------|
| 1 | **Notifications** | Bell + badge | Dropdown panel | Enumerated event types (system, user, agent activities) |
| 2 | **Messages** | Chat bubble + count | Dropdown panel | Messages from agents (AI-generated communications) |
| 3 | **Feed** | Activity icon | Dropdown panel | Real-time system activity feed |
| 4 | **Org Switcher** | Org name + dropdown | Dropdown list | Switch between assigned organizations (Partner Admin only) |
| 5 | **Theme Toggle** | Sun/Moon icon | Toggle | Switch light/dark mode |
| 6 | **Help** | Question mark | Dropdown panel | Documentation, support, keyboard shortcuts |
| 7 | **User Avatar** | Profile image/initials | Dropdown menu | Profile, Billing, Help, System (Super Admin), Logout |

### 1.3 Complete Route Hierarchy

```
/
├── / (Main - Chat Interface)
│   ├── /chat/{conversationId}
│   └── /favorites
│
├── /agents (Agent Management)
│   ├── /agents/create
│   ├── /agents/{agentId}
│   ├── /agents/{agentId}/configure
│   ├── /agents/{agentId}/executions
│   └── /agents/{agentId}/performance
│
├── /drive (Artifacts/File Management)
│   ├── /drive/my-files
│   ├── /drive/shared
│   ├── /drive/templates
│   └── /drive/{fileId}
│
├── /insights (Smart Data Segments)
│   ├── /insights/engine
│   ├── /insights/goals
│   └── /insights/goals/{goalId}
│
├── /work-center (Task/Communication Hub)
│   ├── /work-center/messages
│   ├── /work-center/calendar
│   ├── /work-center/tasks
│   ├── /work-center/hunches
│   └── /work-center/approvals
│
├── /activity (System Activity Log)
│   ├── /activity/users
│   ├── /activity/agents
│   └── /activity/system
│
├── /settings/system (System Settings - Super Admin+)
│   ├── /settings/system/users
│   ├── /settings/system/application
│   ├── /settings/system/tools
│   ├── /settings/system/knowledge
│   └── /settings/system/hunches
│
└── /profile (User Profile)
    ├── /profile/edit
    ├── /profile/preferences
    └── /profile/billing
```

### 1.4 Access Control Matrix

| Route | Super Admin | Partner Admin | Org Admin | Org Staff |
|-------|-------------|---------------|-----------|-----------|
| `/` | ✓ | ✓ | ✓ | ✓ |
| `/agents` | ✓ | ✓ | ✓ | ✓ (view/create/edit) |
| `/drive` | ✓ | ✓ | ✓ | ✓ |
| `/insights` | ✓ | ✓ | ✓ | ✓ (read-only) |
| `/work-center` | ✓ | ✓ | ✓ | ✓ |
| `/activity` | ✓ (all orgs) | ✓ (assigned orgs) | ✓ (own org) | ✗ |
| `/settings/system/users` | ✓ (all users) | ✓ (org users) | ✓ (org users) | ✗ |
| `/settings/system/application` | ✓ (system-level) | ✗ | ✓ (org-level) | ✗ |
| `/settings/system/tools` | ✓ (system library) | ✗ | ✗ | ✗ |
| `/settings/system/knowledge` | ✓ | ✓ | ✓ | ✗ |
| `/profile` | ✓ | ✓ | ✓ | ✓ |

---

## 2. User Flows

### 2.1 Primary Flow: Login to Dashboard

```mermaid
graph TD
    A[User visits /] --> B{Authenticated?}
    B -->|No| C[Redirect to /login]
    C --> D[Enter credentials]
    D --> E[Submit login form]
    E --> F{Valid credentials?}
    F -->|No| G[Show error message]
    G --> D
    F -->|Yes| H[Store JWT token]
    H --> I[Load user profile]
    I --> J[Check user role]
    J --> K{Multi-org Partner Admin?}
    K -->|Yes| L[Show Org Switcher in top bar]
    K -->|No| M[Set current org from user.organization_id]
    L --> N[Select organization]
    N --> O[Update RLS context]
    M --> O
    O --> P[Redirect to / - Main Chat Interface]
    P --> Q[Load DealerBrain chat UI]
    Q --> R[Display left pane: Favorites & History]
    R --> S[Center pane: Chat dialogue]
    S --> T[Right pane: Hidden - Chat Only View]
```

### 2.2 Primary Flow: Create Agent

```mermaid
graph TD
    A[Navigate to /agents] --> B[Load Agent Library - Heavy Chat Work View]
    B --> C[Left pane: Agent list + Message history]
    C --> D[Center pane: Chat dialogue]
    D --> E[Right pane: Artifact selection]
    E --> F[Click 'Create Agent' from popout menu]
    F --> G[Navigate to /agents/create]
    G --> H[Load Agent Builder UI]
    H --> I[Select agent type: Voice/Video/Chat/Task]
    I --> J[Configure agent properties]
    J --> K[Select skills from library 64+ templates]
    K --> L[Chain skills for complex workflows]
    L --> M[Configure agent permissions - MCP tools]
    M --> N[Test agent in preview mode]
    N --> O{Test successful?}
    O -->|No| P[Debug configuration]
    P --> N
    O -->|Yes| Q[Save agent]
    Q --> R[Store in agents table]
    R --> S[Create agent_skills associations]
    S --> T[Set resource_permissions - org_wide]
    T --> U[Navigate to /agents/{agentId}]
    U --> V[Display agent details]
```

### 2.3 Primary Flow: View Insights (3 Insight Cards)

```mermaid
graph TD
    A[Navigate to /insights] --> B[Load Insights Page - Data Display View]
    B --> C[Left pane: Filters, Views, Tags]
    C --> D[Center pane: Insight Cards Grid]
    D --> E[Right pane: DealerBrain chat]
    E --> F[Render 3 default Insight Cards]
    F --> G[Voice Agent Card - VAPI data]
    F --> H[Video Data Card - Tavus data]
    F --> I[VIN Lead Feed Card - VIN Solutions data]
    G --> J[Fetch data from /api/v1/insight-cards/voice-agent]
    H --> K[Fetch data from /api/v1/insight-cards/video-data]
    I --> L[Fetch data from /api/v1/insight-cards/vin-leads]
    J --> M[Display summary metrics: Total Calls, Avg Duration, Success Rate]
    K --> N[Display summary metrics: Total Sessions, Engagement Time, Conversion Rate]
    L --> O[Display summary metrics: Total Leads, Avg Score, Status Breakdown]
    M --> P[Render recent calls table with playback UI]
    N --> Q[Render recent sessions table with replay links]
    O --> R[Render recent leads table with quick actions]
    P --> S[WebSocket subscription: insight-card:voice-agent:update]
    Q --> T[WebSocket subscription: insight-card:video-data:update]
    R --> U[WebSocket subscription: insight-card:vin-leads:update]
    S --> V{New VAPI event?}
    T --> W{New Tavus event?}
    U --> X{New VIN webhook?}
    V -->|Yes| Y[Update Voice Agent Card in real-time <2s]
    W -->|Yes| Z[Update Video Data Card in real-time <2s]
    X -->|Yes| AA[Update VIN Lead Feed Card in real-time <2s]
```

---

## 3. User Features Matrix

### 3.1 Feature Availability by Role

| Feature | Super Admin | Partner Admin | Org Admin | Org Staff |
|---------|-------------|---------------|-----------|-----------|
| **Authentication** |
| Login/Logout | ✓ | ✓ | ✓ | ✓ |
| MFA Enrollment | Required | Required | Optional | Optional |
| **Agent Management** |
| View Agents | ✓ | ✓ | ✓ | ✓ |
| Create Agent | ✓ | ✓ | ✓ | ✓ |
| Edit Agent | ✓ (all) | ✓ (org agents) | ✓ (org agents) | ✓ (own agents) |
| Delete Agent | ✓ (all) | ✓ (org agents) | ✓ (org agents) | ✗ |
| **User Management** |
| View Users | ✓ (all) | ✓ (assigned orgs) | ✓ (own org) | ✗ |
| Create User | ✓ | ✓ (assigned orgs) | ✓ (own org) | ✗ |
| Edit User | ✓ | ✓ (assigned orgs) | ✓ (own org) | ✗ |
| Delete User | ✓ | ✓ (assigned orgs) | ✓ (own org) | ✗ |
| **Insights & Reporting** |
| View Insight Cards | ✓ | ✓ | ✓ | ✓ |
| Create Custom Cards | ✓ | ✓ | ✓ | ✗ |
| Export Data | ✓ | ✓ | ✓ | ✓ (limited) |

---

## 4. Screens Across States

### 4.1 Insights Page (3 Insight Cards)

**Route:** `/insights`
**View Configuration:** Data/Information Display View
**Layout:** Left pane (Filters) + Center pane (Cards) + Right pane (DealerBrain)

#### State 4: Populated (Normal Data - All 3 Cards)

```
┌─────────────────────────────────────────────────────────────┐
│ Top Bar: [🔔 2] [💬 5] [📊] [Acme Dealership ▾] ... [@JS]   │
├───────┬─────────────────────────────────────┬───────────────┤
│ Left  │          Center Pane                │  Right Pane   │
│ Pane  │                                     │               │
│       │ ┌───────────────────────────────┐   │ ┌─────────────┤
│Filter:│ │ Voice Agent Card - VAPI       │   │ │DealerBrain  │
│       │ │ ────────────────────────────── │   │ ├─────────────│
│ Date: │ │ Total: 156 | Avg: 3m 24s | ✓92%│   │ │🤖 Need help │
│[Last  │ │                                 │   │ │  analyzing  │
│ 30day]│ │ Recent Calls:                   │   │ │  these?     │
│       │ │ Time   Customer    Dur  Outcome │   │ │             │
│ View: │ │ 2:15PM John Doe    4m  ✓Complete│   │ │👤 Show top  │
│ • All │ │ 1:45PM Jane Smith  2m  ✓Complete│   │ │   performer │
│       │ │ 1:20PM Mike Jones  1m  ⚠NoAnswer│   │ │             │
│ Tags: │ │ ... (10 more)  [▶️ Play] [📄 T] │   │ │🤖 Analyzing │
│ (None)│ │ [Load more]                     │   │ │  ... Top:   │
│       │ ├───────────────────────────────┤   │ │  Sarah      │
│       │ │ Video Data Card - Tavus       │   │ │  Martinez   │
│       │ │ ────────────────────────────── │   │ │  (23 calls  │
│       │ │ Total: 48 | Eng: 5m 12s | ⬆85%│   │ │  92% ✓)     │
│       │ │                                 │   │ │             │
│       │ │ Recent Sessions:                │   │ │  [View]     │
│       │ │ Time   Customer    Dur  Score   │   │ │             │
│       │ │ 3:30PM Emily Chen  6m   95      │   │ └─────────────┘
│       │ │ 2:50PM Carlos Ruiz 4m   88      │   │               │
│       │ │ ... (10 more)  [▶️ Replay] [💬] │   │               │
│       │ │ [Load more]                     │   │               │
│       │ ├───────────────────────────────┤   │               │
│       │ │ VIN Lead Feed - 48h window    │   │               │
│       │ │ ────────────────────────────── │   │               │
│       │ │ Leads: 34 | Score: 72 | ⬆18%  │   │               │
│       │ │ Status: 🆕12 📞14 ✓5 📅2 ✅1   │   │               │
│       │ │                                 │   │               │
│       │ │ Recent Leads:                   │   │               │
│       │ │ Time  Customer  Score Status    │   │               │
│       │ │ 4:15P Tom Baker  85  🆕 New     │   │               │
│       │ │ 3:50P Lisa Wong  78  📞 Contact │   │               │
│       │ │ ... (10 more) [👁️] [📝] [📅]   │   │               │
│       │ │ [Load more]                     │   │               │
│       │ └───────────────────────────────┘   │               │
└───────┴─────────────────────────────────────┴───────────────┘

Features:
- Each card: Summary metrics + Recent items table + Actions
- Real-time updates: WebSocket badges (🔴 Live)
- Quick actions: Playback (▶️), Transcript (📄), Replay (▶️), View (👁️), Edit (📝), Schedule (📅)
- Load more: Pagination (20 items/page)
- DealerBrain: Contextual data analysis in right pane
```

---

## 5. Component Specifications

### 5.1 Insight Card Component (Custom)

**Specific to Nexxus Insights page**

**Props:**
```typescript
interface InsightCardProps {
  type: 'voice_agent' | 'video_data' | 'vin_leads';
  data: InsightCardData;
  filters?: InsightCardFilters;
  onFilterChange?: (filters: InsightCardFilters) => void;
  refreshing?: boolean;
  onRefresh?: () => void;
}

interface InsightCardData {
  metrics: {
    label: string;
    value: string | number;
    trend?: {
      value: number;
      direction: 'up' | 'down';
    };
  }[];
  recentItems: any[];
  chartData?: ChartDataPoint[];
}
```

**Structure:**
```tsx
<Card className="insight-card">
  <CardHeader>
    <div className="flex justify-between items-center">
      <div>
        <CardTitle>{cardTitle}</CardTitle>
        <CardDescription>{cardDescription}</CardDescription>
      </div>
      <Button
        variant="ghost"
        size="icon"
        onClick={onRefresh}
        disabled={refreshing}
      >
        <RefreshIcon className={refreshing ? 'animate-spin' : ''} />
      </Button>
    </div>
  </CardHeader>

  <CardContent>
    {/* Summary Metrics */}
    <div className="grid grid-cols-3 gap-4 mb-6">
      {metrics.map(metric => (
        <MetricCard
          key={metric.label}
          label={metric.label}
          value={metric.value}
          trend={metric.trend}
        />
      ))}
    </div>

    {/* Recent Items Table */}
    <DataTable
      data={recentItems}
      columns={getColumnsForType(type)}
      pagination={{ pageSize: 20 }}
    />
  </CardContent>

  <CardFooter>
    <CardFilters
      filters={filters}
      onChange={onFilterChange}
    />
  </CardFooter>
</Card>
```

---

## 6. Data Requirements

### 6.1 API Endpoint Specifications

#### 6.1.1 Insight Cards API

**Get Voice Agent Card Data:**
```typescript
GET /api/v1/insight-cards/voice-agent?organizationId={orgId}&dateRange={start}/{end}

// Response
interface VoiceAgentCardData {
  totalCalls: number;
  avgDuration: number; // seconds
  successRate: number; // 0-100
  recentCalls: Array<{
    id: string;
    timestamp: Date;
    duration: number; // seconds
    outcome: 'completed' | 'no_answer' | 'voicemail' | 'failed';
    customerName?: string;
    phoneNumber: string;
    transcriptUrl?: string;
    recordingUrl?: string;
    assistantName: string;
  }>;
  filters: {
    dateRange: { start: Date; end: Date };
  };
}
```

**Get Video Data Card Data:**
```typescript
GET /api/v1/insight-cards/video-data?organizationId={orgId}&dateRange={start}/{end}

// Response
interface VideoDataCardData {
  totalSessions: number;
  avgEngagementTime: number; // seconds
  conversionRate: number; // 0-100
  recentSessions: Array<{
    id: string;
    timestamp: Date;
    duration: number; // seconds
    outcome: 'appointment_scheduled' | 'info_provided' | 'no_engagement';
    customerName?: string;
    replayUrl?: string;
    conversationSummary?: string;
    personaName: string;
    engagementScore: number; // 0-100
  }>;
}
```

**Get VIN Lead Feed Card Data:**
```typescript
GET /api/v1/insight-cards/vin-leads?organizationId={orgId}&dateRange={start}/{end}

// Response
interface VINLeadFeedData {
  totalLeads: number;
  avgLeadScore: number; // 0-100
  conversionRate: number; // 0-100
  statusBreakdown: {
    new: number;
    contacted: number;
    qualified: number;
    appointment_set: number;
    closed: number;
  };
  recentLeads: Array<{
    id: string;
    timestamp: Date;
    customerName: string;
    leadScore: number; // 0-100
    status: 'new' | 'contacted' | 'qualified' | 'appointment_set' | 'closed';
    source: 'web' | 'phone' | 'walk_in' | 'referral' | 'social';
    location: string;
    vehicleInterest?: string;
    assignedTo?: string;
    quickActions: Array<'view' | 'assign' | 'update_status' | 'schedule'>;
  }>;
}
```

### 6.2 Real-Time Subscriptions (Supabase)

**Insight Cards WebSocket Subscriptions:**

```typescript
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

// Subscribe to VAPI events for Voice Agent Card
const voiceAgentSubscription = supabase
  .channel('vapi_events')
  .on(
    'postgres_changes',
    {
      event: 'INSERT',
      schema: 'public',
      table: 'vapi_events',
      filter: `organization_id=eq.${organizationId}`
    },
    (payload) => {
      // Refresh Voice Agent Card
      queryClient.invalidateQueries(['insight-card', 'voice-agent']);
    }
  )
  .subscribe();

// Subscribe to Tavus events for Video Data Card
const videoDataSubscription = supabase
  .channel('tavus_events')
  .on(
    'postgres_changes',
    {
      event: 'INSERT',
      schema: 'public',
      table: 'tavus_events',
      filter: `organization_id=eq.${organizationId}`
    },
    (payload) => {
      // Refresh Video Data Card
      queryClient.invalidateQueries(['insight-card', 'video-data']);
    }
  )
  .subscribe();

// Subscribe to VIN webhook events
const vinLeadSubscription = supabase
  .channel('unified_events')
  .on(
    'postgres_changes',
    {
      event: 'INSERT',
      schema: 'public',
      table: 'unified_events',
      filter: `event_source=eq.vin_solutions AND organization_id=eq.${organizationId}`
    },
    (payload) => {
      // Refresh VIN Lead Feed Card
      queryClient.invalidateQueries(['insight-card', 'vin-leads']);
    }
  )
  .subscribe();
```

---

## 7. Theme System

### 7.1 Theme Architecture

Nexxus V2 uses **CSS custom properties** (CSS variables) for theming, enabling runtime theme switching.

**Theme Provider:**

```typescript
// contexts/ThemeContext.tsx
import React, { createContext, useContext, useEffect, useState } from 'react';

type Theme = 'light' | 'dark';

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setTheme] = useState<Theme>(() => {
    const saved = localStorage.getItem('nexxus:theme');
    if (saved) return saved as Theme;

    return window.matchMedia('(prefers-color-scheme: dark)').matches
      ? 'dark'
      : 'light';
  });

  useEffect(() => {
    document.documentElement.classList.remove('light', 'dark');
    document.documentElement.classList.add(theme);
    localStorage.setItem('nexxus:theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  return (
    <ThemeContext.Provider value={{ theme, setTheme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) throw new Error('useTheme must be used within ThemeProvider');
  return context;
}
```

---

## 8. Wiring Guide

### 8.1 Replacing Mock Data with Real API Calls

**Step 1: Setup API Client**

```typescript
// lib/api-client.ts
import axios from 'axios';

const apiClient = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || 'https://api.nexxus.dev',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add auth token to requests
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('nexxus:auth_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default apiClient;
```

**Step 2: Create API Service Functions**

```typescript
// services/insight-cards-service.ts
import apiClient from '@/lib/api-client';

export const insightCardsService = {
  getVoiceAgentCard: async (organizationId: string) => {
    const { data } = await apiClient.get(`/api/v1/insight-cards/voice-agent`, {
      params: { organizationId }
    });
    return data;
  },

  getVideoDataCard: async (organizationId: string) => {
    const { data } = await apiClient.get(`/api/v1/insight-cards/video-data`, {
      params: { organizationId }
    });
    return data;
  },

  getVINLeadFeed: async (organizationId: string) => {
    const { data } = await apiClient.get(`/api/v1/insight-cards/vin-leads`, {
      params: { organizationId }
    });
    return data;
  }
};
```

**Step 3: Use in Components with React Query**

```typescript
import { useQuery } from '@tanstack/react-query';
import { insightCardsService } from '@/services/insight-cards-service';

function InsightsPage() {
  const { user } = useAuth();

  const { data: voiceData, isLoading: voiceLoading } = useQuery(
    ['insight-card', 'voice-agent', user.organizationId],
    () => insightCardsService.getVoiceAgentCard(user.organizationId),
    {
      staleTime: 30 * 1000, // 30 seconds
      refetchInterval: 60 * 1000 // Auto-refresh every 60 seconds
    }
  );

  return (
    <div className="grid gap-6">
      <VoiceAgentCard data={voiceData} loading={voiceLoading} />
      <VideoDataCard data={videoData} loading={videoLoading} />
      <VINLeadFeedCard data={vinData} loading={vinLoading} />
    </div>
  );
}
```

---

## Final Notes

This document provides comprehensive guidance for UI developers to implement the Nexxus V2 frontend with focus on the **Insights page and 3 Insight Cards**.

**Key Implementation Steps:**

1. **Setup project structure** with Next.js 14, shadcn/ui, Tailwind CSS, Tremor
2. **Implement navigation system** (vertical menu, top bar, 3-pane layout)
3. **Build Insight Cards** (Voice Agent, Video Data, VIN Lead Feed)
4. **Integrate real-time subscriptions** (Supabase WebSocket)
5. **Apply theme system** (CSS variables, light/dark mode)
6. **Connect to APIs** (React Query, cache management)

**Priority Order:**

1. Voice Agent Card (VAPI data)
2. Video Data Card (Tavus data)
3. VIN Lead Feed Card (VIN Solutions data)

**Next Steps:**
- Review specifications with UI team
- Create mockups based on documented states
- Begin component implementation
- Schedule regular sync meetings

---

**Document Version:** 2.0
**Last Updated:** January 21, 2026
**Status:** Ready for Implementation
