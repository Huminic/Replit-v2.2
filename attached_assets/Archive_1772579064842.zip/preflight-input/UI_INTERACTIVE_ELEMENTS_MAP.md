# Nexxus V2 - UI Interactive Elements Map

This document maps all interactive UI elements (buttons, links, forms) to their associated handler functions.

**Generated:** 2026-02-01

---

## PAGES

### 1. Login Page (`client/src/pages/login.tsx`)

| Element | Handler | Function |
|---------|---------|----------|
| Email Input | `setEmail` | Update email state |
| Password Input | `setPassword` | Update password state |
| Sign In Button | `handleSubmit` | Calls `login(email, password)` → redirects to `/` |

---

### 2. Main/Home Page (`client/src/pages/main.tsx`)

| Element | Handler | Function |
|---------|---------|----------|
| Expand Panel Button | `setLeftPanelOpen(true)` | Show favorites/conversations sidebar |
| Collapse Panel Button | `setLeftPanelOpen(false)` | Hide sidebar |
| New Conversation Button | `handleNewConversation` | `createConversation.mutateAsync()` |
| Favorite Item | `setLocation(fav.path)` | Navigate to favorited page |
| Conversation Item | `setActiveConversationId(conv.id)` | Select conversation |
| Delete Conversation Button | `handleDeleteConversation` | `deleteConversation.mutateAsync()` |
| Suggestion Buttons | `setInputValue(suggestion)` | Auto-fill input |
| Send Message Button | `handleSend` | Send message via `sendMessage()` |
| Chat Input (Enter key) | `handleKeyDown` | Send on Enter (not Shift+Enter) |

---

### 3. Insights Page (`client/src/pages/insights.tsx`)

| Element | Handler | Function |
|---------|---------|----------|
| Date Range Selector | `setDateRange` | Filter by '24h', '48h', '7d', '30d' |
| Refresh Button | `handleRefresh` | Invalidate queries and reload |
| Dashboard/Goals/Reports Tabs | automatic | Switch tab views |
| View All Calls | `handleViewAllCalls` | `setVoiceTableOpen(true)` |
| View Transcript | `handleViewTranscript(id)` | Open transcript modal |
| Play Recording | `handlePlayRecording(url)` | Open audio modal |
| View All Sessions | `handleViewAllSessions` | `setVideoTableOpen(true)` |
| Watch Replay | `handleWatchReplay(url)` | Open video modal |
| View All Leads | `handleViewAllLeads` | `setLeadsTableOpen(true)` |
| View Lead | `handleViewLead(id)` | Open lead detail modal |
| Assign Lead | `handleAssignLead(id)` | Toast (Phase 6 feature) |
| Call Lead | `handleCallLead(phone)` | Toast (MCP integration coming) |

---

### 4. Agents Page (`client/src/pages/agents.tsx`)

| Element | Handler | Function |
|---------|---------|----------|
| Search Input | `setSearchQuery` | Filter agents by name/description |
| Type Filter Select | `setTypeFilter` | Filter by agent type |
| Status Filter Select | `setStatusFilter` | Filter by status |
| Refresh Button | `handleRefresh` | Refetch agents list |
| Agent List Item | `setSelectedAgentId(agent.id)` | Select agent for chat |
| Create Agent Button | `setLocation('/agents/create')` | Navigate to create page |
| Play/Pause Status | `handleToggleStatus(agent)` | `updateStatusMutation.mutate()` |
| Edit Agent MenuItem | `setLocation(/agents/{id}/edit)` | Navigate to edit |
| Duplicate Agent MenuItem | `handleDuplicate(agent)` | `duplicateMutation.mutate()` |
| Delete Agent MenuItem | `setDeleteConfirmAgent(agent)` | Show delete confirmation |
| Send Chat Button | `handleSendChat` | Add message, simulate response |
| Delete Confirmation | `handleDelete` | `deleteMutation.mutate()` |

---

### 5. Work Center Page (`client/src/pages/work-center.tsx`)

| Element | Handler | Function |
|---------|---------|----------|
| Add Task Button | `setCreateTaskOpen(true)` | Open create task dialog |
| Calendar/Tasks/Hunches/etc. Tabs | automatic | Switch views |
| Calendar Event Click | `handleAppointmentClick` | Open appointment modal (view) |
| Calendar Date Select | `handleDateSelect` | Open modal (create mode) |
| Task Checkbox | `handleToggleTaskStatus(task)` | `updateTaskStatus.mutateAsync()` |
| Lead Call Button | `handleCall(lead)` | Open dialer with phone |
| Dialer Keypad (0-9, *, #) | `handleDialerInput(digit)` | Append digit |
| Dialer Clear Button | `handleClearDialer` | Clear number and contact |
| Create Task Submit | `handleCreateTask` | `createTask.mutateAsync()` |

---

### 6. Settings Page (`client/src/pages/settings.tsx`)

| Element | Handler | Function |
|---------|---------|----------|
| Add User Button | `setCreateUserOpen(true)` | Open create user dialog |
| Users/Orgs/Partners/etc. Tabs | automatic | Switch sections |
| User Search Input | `setUserSearch` | Filter users |
| User Page Previous/Next | `setUserPage(page ± 1)` | Paginate users |
| User Edit MenuItem | `onEdit(user)` | Open edit user dialog |
| User Deactivate MenuItem | `onDeactivate(user)` | Open deactivate confirmation |
| Add Organization Button | `onAdd()` | Open create org dialog |
| Tool Switches | automatic | Enable/disable tools |
| Add Integration Button | `setIsAddDialogOpen(true)` | Open integration dialog |
| Integration Test Button | `handleTestConnection(id)` | `integrationsApi.test()` |
| Integration Delete | `handleDelete` | `integrationsApi.delete()` |
| Integration Submit | `handleAddIntegration` | `integrationsApi.create()` |

---

### 7. Agent Create Page (`client/src/pages/agents-create.tsx`)

| Element | Handler | Function |
|---------|---------|----------|
| Back Button | `setLocation('/agents')` | Return to agents list |
| Create Agent Button | `handleSubmit` | `createAgentMutation.mutateAsync()` |
| Agent Name/Description Inputs | `setFormData({...})` | Update form state |
| Channel Buttons | `setFormData({ channel })` | Select voice/chat/video/email/task |
| Trigger Switches | `setFormData({ triggers[type] })` | Enable/disable triggers |
| Tool Badges | `setFormData({ tools[id] })` | Toggle tool selection |

---

### 8. Drive Page (`client/src/pages/drive.tsx`)

| Element | Handler | Function |
|---------|---------|----------|
| Grid/List View Buttons | `setViewMode('grid'/'list')` | Switch view mode |
| Folder Item Click | `setCurrentFolder(file.id)` | Navigate into folder |
| Download/Share/Star/Delete MenuItems | placeholder | Phase 6 features |

---

## LAYOUT COMPONENTS

### Sidebar (`client/src/components/layout/Sidebar.tsx`)

| Element | Handler | Function |
|---------|---------|----------|
| Menu Items | `handleClick(item)` | Navigate and set active panel |
| Menu Item Hover | `handleMouseEnter(item)` | Show sub-menu |
| Toggle Sub-menu Button | `toggleSubMenuExpanded()` | Expand/collapse panel |
| Logout Button | `handleLogout` | `logout()`, navigate to `/login` |

---

### Top Bar (`client/src/components/layout/TopBar.tsx`)

| Element | Handler | Function |
|---------|---------|----------|
| Mobile Menu Button | `setMobileMenuOpen(!open)` | Toggle mobile sidebar |
| Notification Item | `markNotificationRead(id)` | Mark read, navigate if action URL |
| Theme Toggle | `toggleTheme()` | Switch light/dark |
| Switch Organization | `handleSwitchOrg(orgId)` | `switchOrganization(orgId)`, reload |
| Logout MenuItem | `handleLogout` | `logout()`, navigate to `/login` |

---

## KEY HOOKS & MUTATIONS

| Hook | Action |
|------|--------|
| `useConversations()` | Fetch conversation list |
| `useCreateConversation()` | Create new conversation |
| `useOptimisticSendMessage()` | Send message (optimistic) |
| `useDeleteConversation()` | Delete conversation |
| `useAgents()` | Fetch agents with filters |
| `useCreateAgent()` | Create new agent |
| `useUpdateAgentStatus()` | Toggle agent active/inactive |
| `useDeleteAgent()` | Delete agent |
| `useDuplicateAgent()` | Duplicate agent |
| `useTasks()` | Fetch tasks list |
| `useCreateTask()` | Create new task |
| `useUpdateTaskStatus()` | Update task status |
| `useCalendarAppointments()` | Fetch appointments |
| `useRescheduleAppointment()` | Reschedule via drag-drop |
| `useVoiceInsights()` | Fetch VAPI metrics |
| `useAdminUsers()` | Fetch users (paginated) |
| `useAdminOrganizations()` | Fetch organizations |

---

## CONTEXTS

| Context | Key Functions |
|---------|---------------|
| **AuthContext** | `login()`, `logout()`, `switchOrganization()` |
| **AppContext** | `setActivePanel()`, `toggleSubMenuExpanded()`, `markNotificationRead()` |
| **ThemeContext** | `toggleTheme()` |

---

## FILE PATHS

All source files located in: `/home/ubuntu/Claude-store/nexxus-v2/client/src/`

| Directory | Contents |
|-----------|----------|
| `pages/` | Page components |
| `components/layout/` | Sidebar, TopBar, AppLayout |
| `components/insights/` | Insight card components |
| `components/calendar/` | Calendar/appointment components |
| `components/modals/` | Modal components |
| `components/ui/` | shadcn/ui primitives |
| `contexts/` | React contexts (Auth, App, Theme) |
| `hooks/` | Custom React hooks |
| `lib/` | Utility functions |
