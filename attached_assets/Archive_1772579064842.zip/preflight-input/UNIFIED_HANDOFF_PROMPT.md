# Unified Handoff Prompt — Nexxus Connect V2.1 Frontend Rebuild

**Date:** 2026-02-22
**Purpose:** Single entry point for a fresh Claude session starting the V2.1 frontend rebuild.
**Sources:** Merged from `CLAUDE_CODE_HANDOFF_PROMPT.md` (technical inventory) and `SESSION_INSTRUCTIONS.md` (execution instructions, interview answers, sprint structure, critical rules).

Copy this entire prompt and give it to Claude Code when starting the frontend rebuild.

---

## START OF PROMPT

---

## 0. THE MOST IMPORTANT THING

**The backend already exists and is running in production.** This is a **frontend rebuild**, not a greenfield project.

| Layer | Status | What to Do |
|-------|--------|------------|
| Database | COMPLETE (53 tables, 33 migrations, ~100 RLS policies, 160+ indexes) | **DO NOT TOUCH** |
| Server/API | COMPLETE (~237 endpoints, 34 route files, 40+ services, 8 scheduled jobs) | **DO NOT TOUCH** |
| Integrations | COMPLETE (VIN Solutions, VAPI, Tavus, Resend, TextMagic, Claude API, Google Calendar) | **DO NOT TOUCH** |
| Webhooks | LIVE (VAPI + Tavus chains with idempotency guards) | **DO NOT TOUCH** |
| Authentication | COMPLETE (JWT access/refresh tokens, 4-tier RBAC) | **DO NOT TOUCH** |
| Frontend Integration | 32 carry-forward files (API client, auth context, 25 TanStack Query hooks, SSE streaming) | **PRESERVE** |
| Frontend Visual Layer | Pages, layout, components | **REBUILD from new designer specs** |

Two customers are live: **Serra Automotive** and **Hyundai of Columbia**. Do not break webhook processing, VIN sync, or notification delivery.

---

## 1. Production Environment Rules (Non-Negotiable)

1. **The backend is LIVE and working** — ~237 API endpoints, 53 database tables, 100+ RLS policies, 7 third-party integrations, 8 scheduled jobs, 747 E2E tests. **Do not modify server code** unless explicitly required by the new UI.
2. **VAPI webhooks are LIVE** — actively processing voice call data for real dealership customers. Do not modify `server/webhooks/vapi.ts`.
3. **Tavus webhooks are LIVE** — actively processing video session data. Do not modify `server/webhooks/tavus.ts`.
4. **Existing users and data MUST be preserved** — never drop, truncate, or destructively migrate. All database migrations must be additive only.
5. **The new UI design is the source of truth** — if any document contradicts the designer's handoff, the design wins.
6. **The backend uses JWT authentication** (NOT express-session). Access/refresh tokens stored in `localStorage`. If the NEW_SRS says "express-session," ignore it — the production backend uses JWT.

---

## 2. Document Reading Order

Read these documents **in this order** before writing any code:

### Tier 1: Forensic Audit Files (What Actually Exists)

1. **`replit_reference/App Audit/server-audit.md`** — The actual API contract. ~237 endpoints with auth requirements, RBAC gates, and response details.
2. **`replit_reference/App Audit/database-audit.md`** — 53 tables, RLS policies, JSONB column schemas, migration history.
3. **`replit_reference/App Audit/client-audit.md`** — 26 hooks, 4 contexts, 59 custom components. Shows what integration plumbing exists.
4. **`replit_reference/App Audit/health-audit.md`** — Build system, dependencies, 117K LOC, 747 E2E tests.
5. **`replit_reference/App Audit/DATA_ACCURACY_REPORT.md`** — VAPI/Tavus/VIN data integrity findings.

### Tier 2: Carry-Forward and Freeze Lists

6. **`plan_docs/v2.1/CARRY_FORWARD_MANIFEST.md`** — 32 files to preserve, 8 to reference, 11 replaceable mocks. The definitive list of what crosses into the new UI.
7. **`plan_docs/v2.1/DO_NOT_TOUCH.md`** — 345+ backend files that are frozen. If a file is listed here, do not modify it.
8. **`plan_docs/v2.1/REVERSE_SRS.md`** — Documents actual vs. planned implementation (237 endpoints vs 63 planned, 53 tables vs 17 planned, 91 metrics).

### Tier 3: Lessons and Operational Knowledge

9. **`plan_docs/v2.1/DEVELOPMENT_TEAM_BRIEFING.md`** — Hard-won lessons, critical gotchas, and guidance from the original development team. Read this to avoid repeating known mistakes.
10. **`plan_docs/dev_handoff/DEALERBRAIN_STREAMING_SPEC.md`** — DealerBrain SSE streaming protocol: 6 event types, visual states, chart integration.

### Tier 4: Design Specifications

11. **`plan_docs/ACCEPTANCE_CRITERIA.md`** — Pixel-level UI behavior spec for the new design.
12. **`plan_docs/dev_handoff/`** — 14 designer handoff documents (Theme Contract, Component Sheet, Sitemap, UI Rules, etc.)

### Tier 5: Governance Documents

13. **`plan_docs/v2.1/NEW_CLAUDE.md`** — Implementation patterns, RBAC matrix, testing requirements.
14. **`plan_docs/v2.1/NEW_CONSTITUTION.md`** — Platform principles, naming rules, metric formulas (Section 5 is immutable).
15. **`plan_docs/v2.1/NEW_SRS.md`** — Requirements spec. Note Section 3.6 Known Constraints and Section 4 preamble.
16. **`plan_docs/v2.1/NEW_IMPLEMENTATION_PLAN.md`** — Sprint structure. Note Section 0 "What Already Exists."

### Tier 6: Reference Material

17. **`replit_reference/new_instructions/Agent Instructions.md`** — Agent team development protocol.
18. **`replit_reference/new_instructions/Hunch Instructions.md`** — AI prompt for Hunch Engine pattern detection.
19. **`replit_reference/Metrics/`** — Exact metric formulas for Org Admin, Staff, Reports, Library (91 total).

### Conflict Resolution Rule

When documents conflict: **New UI Design > ACCEPTANCE_CRITERIA > UNIFIED_HANDOFF_PROMPT > Constitution > Audit Files > NEW_SRS > Implementation Plan**

Specifically: If the NEW_SRS or NEW_IMPLEMENTATION_PLAN describe backend tasks (creating tables, building endpoints, setting up auth), check the audit files first — those tasks are already complete. The NEW_SRS Section 4 preamble and NEW_IMPLEMENTATION_PLAN Section 0 explicitly document this.

---

## 3. What Already Exists (DO NOT REBUILD)

### 3.1 Backend Infrastructure

| Component | Count | Details |
|-----------|-------|---------|
| Route files | 34 | Registered in `server/routes.ts` in specific order |
| API endpoints | ~237 | Full CRUD across 34 resource groups |
| Service files | 40+ | Business logic layer (DealerBrainService is 3,047 lines) |
| Middleware | 3 | `auth` (JWT), `enforceOrganizationContext` (RLS), `validateResourceOwnership` |
| Webhook handlers | 2 | VAPI (`server/webhooks/vapi.ts`), Tavus (`server/webhooks/tavus.ts`) |
| Scheduled jobs | 8 | VIN lead polling, token refresh, cache cleanup, dealer pulse, hunch generation, etc. |
| Database tables | 53 | With ~100 RLS policies across 33 migration files |
| Third-party integrations | 7 | VIN Solutions, VAPI, Tavus, Resend, TextMagic, Claude API, Google Calendar |
| E2E tests | 747 | Playwright specs across 46 files |

### 3.2 API Route Groups (Complete Endpoint Catalog)

```
/api/webhooks/vapi          (before body parsers — DO NOT MOVE)
/api/webhooks/tavus         (raw body capture for HMAC — DO NOT MOVE)
/api/auth                   9 endpoints  (login, logout, refresh, register, me, forgot/reset password)
/api/vin                    10 endpoints (VIN Solutions OAuth, lead sync, token management)
/api/integrations           6 endpoints  (CRUD + test connection)
/api/insights               15 endpoints (voice calls, video sessions, leads, dashboard, dealer pulse)
/api/agents                 9 endpoints  (CRUD, seed, duplicate, status toggle)
/api/credits                5 endpoints  (balance, usage, policies)
/api/tasks                  9 endpoints  (CRUD, calendar format, status updates)
/api/appointments           10 endpoints (CRUD, calendar, confirmation tokens, Google Calendar sync)
/api/conversations          11 endpoints (CRUD, messages, SSE streaming, file upload)
/api/admin                  14 endpoints (user/org CRUD, partner links, roles, locations)
/api/admin/knowledge        4 endpoints  (CSV/XLSX upload, undo, templates)
/api/settings               4 endpoints  (application settings, report upload)
/api/email                  7 endpoints  (IMAP sync, send, folders, star/read)
/api/user/integrations      (user-level integration settings)
/api/dealerbrain            3 endpoints  (AI config get/set/reset)
/api/notifications          8 endpoints  (CRUD, preferences, unread count)
/api/sms                    7 endpoints  (TextMagic config, send, messages, opt-outs, webhook)
/api/widgets/public         8 endpoints  (session, chat, video, callback — public, rate-limited)
/api/widgets                9 endpoints  (CRUD, embed code, domain whitelist)
/api/inbox                  8 endpoints  (unified inbox threads, messages, assignment)
/api/tracking               6 endpoints  (pixel events, attribution, funnel, sources)
/api/triggers               10 endpoints (automation rules CRUD, templates, executions)
/api/activity               6 endpoints  (AI usage events, stats, artifacts, CSV export)
/api/goals                  7 endpoints  (CRUD, progress tracking)
/api/reports                5 endpoints  (catalog, preview, generate, download)
/api/drive                  8 endpoints  (files, folders, upload/download, storage usage)
/api/hunches                4 endpoints  (list, stats, review accept/dismiss)
/api/approvals              5 endpoints  (CRUD, resolve approve/reject)
/api/leads                  6 endpoints  (list, stats, mark-contacted, status, assign)
/api/dashboard              1 endpoint   (Command Center data)
/api/metrics                3 endpoints  (registry, summary, by category)
/api/hosted-pages           5 endpoints  (CRUD for hosted widget pages)
/api/pages                  1 endpoint   (public page by slug)
/api/health                 1 endpoint   (health check)
/api (google-calendar)      7 endpoints  (OAuth flow, sync, push appointment)
```

### 3.3 Authentication Architecture

- **JWT-based** — access token + refresh token stored in `localStorage`
- Access token keys: `nexxus_access_token`, `nexxus_refresh_token`, `nexxus_token_expiry`
- Auto-refresh: checks every 60 seconds, refreshes when < 5 minutes to expiry
- On refresh failure: automatic logout
- Login: `POST /api/auth/login` returns `{ accessToken, refreshToken, expiresAt, user }`
- Refresh: `POST /api/auth/refresh` with `{ refreshToken }` body
- Protected routes: `Authorization: Bearer <accessToken>` header
- Org switching (Partner Admin): `POST /api/auth/switch-org` — invalidates all cached queries

### 3.4 RBAC Structure

| Role | Level | Key Permissions |
|------|-------|-----------------|
| Super Admin | 1 | Full platform access, user/org CRUD, all settings |
| Partner Admin | 2 | Multi-org access, manages assigned orgs |
| Org Admin | 3 | Single org, manages users/settings within org |
| Staff | 4 | Single org, own data only (leads, conversations, tasks) |

Role mapping (numeric to string): Level 1 = `super_admin`, Level 2 = `partner_admin`, Level 3 = `org_admin`, Level 4 = `org_staff`

### 3.5 Real-Time Features

- **SSE streaming**: `POST /api/conversations/:id/stream` — DealerBrain AI responses via Server-Sent Events (6 event types: thinking, tool_start, tool_end, token, done, error)
- **No active WebSocket**: Socket.io is installed but not actively used for production features
- **Polling**: Notifications poll on interval, VIN leads poll every 60 minutes

---

## 4. Operational Lessons (Hard-Won — Do Not Repeat These Mistakes)

### Lesson 1: VIN Solutions API Has Hard Limits

VIN Solutions blocks 17 of 30 endpoints with 403 errors. Nexxus can access leads, contacts, lead sources, lead types, lead statuses, lead groups, and CRM users. It CANNOT access deals, desking, appointments (VIN side), inventory, trade-ins, tasks (VIN side), phone calls (VIN side), or email history (VIN side). Do not build UI for data that doesn't exist.

### Lesson 2: Lead Sync Payload Format

VIN lead creation is two-step: (1) create contact via gateway POST, (2) create lead with contact as a URL reference. `leadSource`, `leadType`, and `contact` are ALL href references (`/contacts/id/12345?dealerid=67890`), NOT string names or flat IDs. This is already fixed in the backend.

### Lesson 3: VIN API Header Casing

The OAS docs say `application/vnd.coxauto.V3+json` (uppercase V3). The production API rejects uppercase. Use lowercase: `application/vnd.coxauto.v3+json`. Every endpoint must be tested with v1, v3, and gateway headers before declaring it blocked. Already handled in the backend.

### Lesson 4: RLS Variable Name Mismatch

`SecureQueryBuilder` sets `app.current_organization_id` but all RLS policies check `app.current_org_id`. System works because routes bypass SecureQueryBuilder. Known bug, not yet fixed. Do not add new routes that depend on SecureQueryBuilder for org isolation.

### Lesson 5: Excel Upload Record Pollution

Records imported via excel upload appeared in lead counts, metrics, and dashboards. Filter `source != 'excel_upload'` is required on ALL lead queries. Already fixed in 32+ queries across 11 files.

### Lesson 6: Context Router Was Inverted

The Context Router was initially configured backwards (local DB primary, VIN API fallback). Corrected to: VIN API primary, local DB fallback. `CONTEXT_ROUTER_ENABLED=true` in env.

---

## 5. Integration Plumbing — MUST Carry Forward

These files contain the wiring between the frontend and backend. They are **not visual components** — they are infrastructure. The new UI must use them (or equivalents that do the same thing).

### 5.1 Authentication Context

**File:** `client/src/contexts/AuthContext.tsx`

Provides: `user`, `accessToken`, `refreshToken`, `isAuthenticated`, `loading`, `isPartnerAdmin`, `accessibleOrganizations`, `login()`, `logout()`, `refreshToken()`, `switchOrganization()`, `clearError()`

### 5.2 API Client

**File:** `client/src/lib/api.ts` (or `queryClient.ts`)

Provides: `fetchApi()` wrapper that:
- Adds `Authorization: Bearer` header automatically
- Handles 401 responses by attempting token refresh
- Falls back to logout on refresh failure
- Custom `getQueryFn` factory for TanStack Query

### 5.3 TanStack Query Hooks (26 hooks)

**Directory:** `client/src/hooks/`

| Hook | Queries | Mutations | Purpose |
|------|---------|-----------|---------|
| `useActivity` | 2 | 0 | Activity feed + governance data |
| `useAdmin` | 2+ | 3+ | Admin user/org management |
| `useAgents` | 3 | 4 | Agent CRUD |
| `useAppointments` | 2 | 3 | Calendar appointments |
| `useApprovals` | 2 | 3 | Approval workflow |
| `useConversations` | 3 | 2 | Chat conversations |
| `useCredits` | 1 | 0 | Credit usage tracking |
| `useDealerBrainConfig` | 1 | 0 | DealerBrain AI configuration |
| `useDealerBrainStreaming` | 0 | 0 | SSE streaming for AI chat |
| `useDrive` | 2+ | 4+ | File management |
| `useGoals` | 2 | 3 | Goal CRUD + progress |
| `useHunches` | 2 | 1 | Hunch list + accept/dismiss |
| `useInbox` | 2+ | 2+ | Unified inbox threads |
| `useInsights` | 3+ | 0 | Voice/video/lead insights |
| `useIntegrations` | 1+ | 3+ | Integration management |
| `useLeads` | 2 | 2 | Lead management |
| `useMetrics` | 1+ | 0 | Certified metrics |
| `useNotifications` | 2+ | 2+ | Notification CRUD |
| `useProfile` | 1 | 1 | User profile |
| `useReports` | 2 | 1 | Report catalog + generate |
| `useSettings` | 1 | 1 | Application settings |
| `useSMS` | 2+ | 2+ | SMS management |
| `useTasks` | 2 | 3 | Task CRUD |
| `useTriggers` | 2+ | 3+ | Trigger rules CRUD |
| `useVIN` | 2+ | 2+ | VIN Solutions management |
| `useWidgets` | 2+ | 3+ | Widget CRUD |

### 5.4 Chat Streaming Components

| File | Purpose |
|------|---------|
| `client/src/hooks/useStreamingMessage.ts` | SSE connection, parsing, state management |
| `client/src/components/chat/StreamingMessage.tsx` | Renders streaming AI responses (thinking, tool cards, progressive tokens) |
| `client/src/components/chat/ChatChart.tsx` | Inline charts in chat messages (bar/line/pie via Recharts) |
| `client/src/components/chat/ChatPanel.tsx` | Reusable chat panel |
| `client/src/components/chat/SuggestedPrompts.tsx` | Clickable suggested prompts |

See `plan_docs/dev_handoff/DEALERBRAIN_STREAMING_SPEC.md` for the full streaming protocol specification.

### 5.5 Context Providers

**Provider hierarchy** (preserve this order in `App.tsx`):
```
QueryClientProvider
  TooltipProvider
    ThemeProvider
      AuthProvider
        AppProvider
          ChatProvider
            <Router />
            <FloatingChat />
            <ProductTour />
            <Toaster />
```

### 5.6 Protected Route Guard

**File:** `client/src/components/auth/ProtectedRoute.tsx`

Shows spinner while auth loads, redirects to `/login` if unauthenticated.

---

## 6. Setup — Archive & Install

### 6.1 Backup the existing frontend

```bash
mkdir -p _archive/old_client
cp -r client/ _archive/old_client/
```

### 6.2 Install the new UI

The new UI code is in the uploaded folder. Replace the `client/` directory contents with the new designer UI, **except** for the integration plumbing files listed in Section 5 above — those must be carried forward from the old client.

### 6.3 Verify the backend still works

```bash
curl -s http://localhost:5000/api/health
curl -s http://localhost:5000/api/auth/me -H "Authorization: Bearer test" | head -c 200
```

---

## 7. /init-project Interview Answers

When running `/init-project`, use these answers:

| Question | Answer |
|----------|--------|
| **Project Name** | Nexxus V2.1 — Frontend Rebuild |
| **Purpose** | AI-powered automotive dealership platform. Backend complete and in production. This cycle rebuilds the frontend against new designer specs. Backend (237 endpoints, 53 tables, 40 services, 7 integrations) is frozen. |
| **Target Users** | 4-tier RBAC: Super Admin, Partner Admin, Org Admin, Staff. Primary customers: automotive dealerships. |
| **MVP Features** | Dashboard (wire to /api/insights/* and /api/leads/*), DealerBrain Chat (wire to SSE streaming), AI Agents Management (wire to /api/agents/*), Work Center (wire to /api/messages/*, /api/calendar/*, /api/tasks/*), Settings (wire to /api/settings/* and /api/organizations/*) |
| **Tech Stack** | Frontend ONLY: Vite + React 18 + TypeScript strict + Tailwind CSS v4 + shadcn/ui + Wouter + TanStack Query. Backend already exists. |
| **Dev Mode** | Agent Team (multi-agent parallel execution with quality gates) |
| **Timeline** | Flexible — quality over speed |
| **Business Model** | B2B SaaS — per-minute AI usage (voice $0.25/min, video $0.32/min, SMS $0.05/msg) plus platform subscription |
| **Constraints** | Do NOT modify server/, database/, or scripts/. Preserve 32 integration files. Wire to EXISTING endpoints. VIN has hard limits (17 of 30 endpoints return 403). Owner's designs are visual source of truth. |
| **Design Direction** | Dashboard with top nav + sidebar. Use owner's navigation designs, not defaults. |
| **Testing** | Balanced — unit tests for core logic, E2E for critical paths. 747 existing tests cover backend. |
| **Git Strategy** | Feature branches, merge to master, deploy via ./deploy.sh |

---

## 8. Sprint Structure (Frontend Rebuild)

Replace any generated greenfield sprints with this frontend-rebuild structure:

### Sprint 0: Carry-Forward Verification
- Verify all 32 PRESERVE files from CARRY_FORWARD_MANIFEST.md are intact
- Verify API client (`fetchApi()`) connects to existing backend
- Verify auth flow (login, JWT refresh, org switching) works
- Run existing E2E tests to confirm backend is untouched
- **Gate:** Existing integration plumbing verified working

### Sprint 1: Shell and Navigation
- Build new layout shell from designer specs (sidebar, top nav, responsive behavior)
- Implement route-level RBAC (not component-level)
- Wire navigation to existing page routes
- **Gate:** Users see new layout, navigation works, role-based access enforced at route level

### Sprint 2: Dashboard and Insights
- Build dashboard page from new designs
- Wire health gauges, lead feed, team leaderboard to existing hooks
- Preserve data transformation utilities from existing hooks
- **Gate:** Dashboard displays real data with new visual design

### Sprint 3: DealerBrain Chat
- Build chat interface from new designs
- Wire to existing SSE streaming hook (`useStreamingMessage` — PRESERVE)
- Preserve tool calling visibility, thinking indicators
- **Gate:** DealerBrain chat works with new UI, streaming functional

### Sprint 4: AI Agents
- Build agent management pages from new designs
- Wire to existing agent CRUD hooks
- Display agent types, skills, trigger types
- **Gate:** Users can view and configure AI agents with new UI

### Sprint 5: Work Center
- Build messages inbox, calendar, tasks, hunches, approvals tabs
- Wire each tab to existing hooks
- **Gate:** Full Work Center operational with new UI

### Sprint 6: Settings and Administration
- Build settings tabs from new designs
- Wire to existing settings/org hooks
- **Gate:** Full settings interface with new UI

### Sprint 7: Polish and Testing
- Cross-browser testing
- Responsive design verification
- Accessibility audit
- New E2E tests for frontend flows
- **Gate:** Production-ready frontend

---

## 9. Project Structure

```
nexxus-v2/
├── client/                          # YOUR WORKSPACE — Replace visual layer
│   ├── src/
│   │   ├── App.tsx                  # Route definitions (wouter) — REBUILD with new routes
│   │   ├── main.tsx                 # React entry point
│   │   ├── index.css                # Design tokens — UPDATE for new design
│   │   ├── components/
│   │   │   ├── auth/
│   │   │   │   └── ProtectedRoute.tsx  # CARRY FORWARD — auth guard
│   │   │   ├── chat/                   # CARRY FORWARD — streaming, charts, panels
│   │   │   ├── layout/                 # REBUILD — new design's layout system
│   │   │   └── ui/                     # Shadcn/Radix primitives (keep or replace per design)
│   │   ├── contexts/
│   │   │   ├── AuthContext.tsx         # CARRY FORWARD — JWT auth + org switching
│   │   │   ├── AppContext.tsx          # ADAPT — keep role/org/panel logic, update for new layout
│   │   │   ├── ChatContext.tsx         # CARRY FORWARD — floating chat state
│   │   │   └── ThemeContext.tsx        # CARRY FORWARD — light/dark theme
│   │   ├── hooks/                      # CARRY FORWARD — all 26 TanStack Query hooks
│   │   ├── lib/
│   │   │   ├── queryClient.ts         # CARRY FORWARD — fetch wrapper + query client config
│   │   │   ├── api.ts                 # CARRY FORWARD — fetchApi() with JWT refresh
│   │   │   └── utils.ts              # CARRY FORWARD — cn() utility
│   │   ├── mocks/                     # DELETE — no longer needed (real API exists)
│   │   └── pages/                     # REBUILD — new page components from design
│   └── public/
├── server/                          # DO NOT MODIFY (unless new endpoint needed for new UI)
├── database/                        # DO NOT MODIFY
├── tests/                           # 747 existing E2E tests — add new frontend tests alongside
├── plan_docs/                       # Governing documentation
│   ├── ACCEPTANCE_CRITERIA.md       # Pixel-level UI behavior spec
│   ├── v2.1/                        # Governance + handoff docs
│   └── dev_handoff/                 # 15 designer handoff documents
├── replit_reference/                # Forensic audit files (read-only reference)
│   ├── App Audit/                   # 5 forensic audit files
│   ├── Metrics/                     # Exact metric formulas (91 total)
│   └── new_instructions/            # Agent and Hunch prompt templates
└── widget/                          # Embeddable Preact widget (separate build)
```

---

## 10. Testing Protocol

- **Voice**: Use the "Elliot" test-only VAPI agent for all voice testing
- **SMS**: Loopback to self via TextMagic API — never to real customers
- **Email**: Use `neoweaver@gmail.com` for all outbound email tests
- **Video**: Test sessions only — never production Tavus sessions
- **Per sprint**: At least 3 deltas of proof with screenshots, then full E2E at sprint completion
- **Existing tests**: Run `npx playwright test` after each sprint to catch regressions

---

## 11. Customer Acceptance Criteria (Non-Negotiable)

These 5 use cases are the acceptance bar. Every sprint should advance at least one.

| # | Use Case | Current Status | Risk |
|---|----------|---------------|------|
| AC-1 | Automatic Outbound Call Triggering | Implemented but D-FLAG-001 (trigger consolidation) unresolved — triggers deactivated | **HIGH** |
| AC-2 | Intelligent VIN Data Analysis | Working via Context Router + DealerBrain | Low |
| AC-3 | Lead Insertion to VIN Solutions | Sync pipeline fixed 2026-02-15 | Medium |
| AC-4 | Accurate Dashboard Metrics | Working with excel exclusions + source badges | Low |
| AC-5 | Widget Deployment | Fully implemented (Master Widget + hosted pages) | Low |

---

## 12. Quick Reference: What To Do vs What Files

| What to do | Files to touch |
|---|---|
| Replace a page's visual layout | `client/src/pages/*.tsx` — new component, same hooks |
| Replace the layout shell | `client/src/components/layout/*.tsx` — new design components |
| Wire data to a page | Import the existing hook from `client/src/hooks/use*.ts` |
| Add a new API call | Add to existing hook file, or create new hook in `client/src/hooks/` |
| Modify auth behavior | `client/src/contexts/AuthContext.tsx` |
| Change theme tokens | `client/src/index.css` |
| Add a new route | `client/src/App.tsx` — add `<Route>` inside `<Switch>` |
| Need a new backend endpoint | `server/routes/*.ts` + `server/services/*.ts` (RARE — most endpoints exist) |

---

## 13. Environment Variables

The backend requires 33 environment variables (configured in `.env`, not committed to git). Key categories:

| Category | Variables |
|----------|-----------|
| Database | `DATABASE_URL`, `SUPABASE_*` |
| Auth | `JWT_SECRET`, `JWT_REFRESH_SECRET` |
| AI | `ANTHROPIC_API_KEY` |
| VIN Solutions | `VIN_CLIENT_ID`, `VIN_CLIENT_SECRET`, `VIN_API_KEY` |
| VAPI | `VAPI_API_KEY`, `VAPI_WEBHOOK_SECRET` |
| Tavus | `TAVUS_API_KEY` |
| Email | `RESEND_API_KEY`, `IMAP_*` |
| SMS | `TEXTMAGIC_USERNAME`, `TEXTMAGIC_API_KEY` |
| Google Calendar | `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET` |
| General | `SESSION_SECRET`, `ENCRYPTION_KEY`, `PUBLIC_API_URL` |

No `.env.example` file exists. Ask the project owner for the values.

---

## 14. Critical Rules for the Entire Session

1. **The owner's designs are source of truth.** Not the existing frontend. Not your assumptions.
2. **The backend is frozen.** If a UI feature needs a new endpoint, STOP and ask the owner.
3. **VIN Solutions has hard limits.** 17 of 30 endpoints return 403. Check `server-audit.md` before building any VIN data display.
4. **Preserve integration plumbing.** The 32 files in CARRY_FORWARD_MANIFEST.md are load-bearing. Don't rewrite them.
5. **Cross-contamination kills this project.** Don't copy patterns from the existing frontend visual components. Build fresh from the designs.
6. **Metrics display was hard-won.** The owner iterated many times to get data/metrics displaying correctly. If the new designs reference the same metrics, use the existing data pipelines (TanStack Query hooks) — just replace the visual components.
7. **When in doubt, STOP and ask.** Don't assume. Don't improvise. Present options with tradeoffs.
8. **JWT, not sessions.** The production auth is JWT-based. Ignore any document that says express-session.

---

## Your First Actions

1. Read the audit files (Section 2, Tier 1) — understand the API surface and database
2. Read the carry-forward and freeze lists (Section 2, Tier 2) — know what to preserve and what not to touch
3. Read the development team briefing (Section 2, Tier 3) — learn from past mistakes
4. Read the streaming spec (Section 2, Tier 3) — understand DealerBrain protocol
5. Archive the old `client/` directory
6. Install the new UI files
7. Carry forward all files listed in CARRY_FORWARD_MANIFEST.md (Section 1: MUST Preserve)
8. Begin Sprint 0: Verify carry-forward integration plumbing works
9. After Sprint 0, submit 3 deltas of proof with screenshots

---

## END OF PROMPT
