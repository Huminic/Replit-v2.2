# opinions_facts.md  
  
======Facts=====  
  
I created a UI to act as the highest level of truth so that the functions could be wired in. And for the most part that went pretty good.   
Rules have not been enforced because of conflicting information and non-standard file designations.   
I've done this four times and each time Time we end up with drift.   
Claw.md has not been followed and in some cases it actually changed without telling me.   
Plan files have been reversioned and modified without my input.   
  
These can be confirmed by inspecting files, code, or directory structure.  
	1.	.agent_docs/acceptance_criteria.md contains “PLACEHOLDER.”  
	2.	.agent_docs/work_tree.md marks AC reconciliation as COMPLETED.  
	3.	enforcer_context.md flags a mismatch between the system prompt and on-disk CLAUDE.md.  
	4.	Client and server route paths differ for hosted pages (requires file line references to confirm exact strings).  
	5.	Multiple acceptance-criteria-related files exist in the repository.  
	6.	More than one testing evidence directory exists (Run 1 and Run 2).  
	7.	Different documents report different P0 counts.  
	8.	Only one of the defined agent definition files currently exists (others referenced but not present).  
  
These are structural conditions. They do not imply fault.  
  
  
======Suspicions======  
  
Because we haven't used the right files for the right purpose, there have been holes in the specification.   
  
	1.	AC reconciliation was not actually completed (needs confirmation no alternate reconciled file exists).  
	2.	Tier 2 truth source is incomplete (needs confirmation of actual runtime truth hierarchy).  
	3.	Enforcer scope does not cover read-only runs (needs confirmation of enforcer implementation boundaries).  
	4.	Conflicting P0 counts represent reporting error (needs timestamp + scope comparison).  
	5.	Architecture explanations were not persisted after being verbally explained (needs repo-wide search + transcript evidence).  
	6.	Certain modifications were “unauthorized” (requires policy boundary + instruction log + commit history).  
	7.	Status was “misrepresented” (requires proof of knowledge at time of statement).  
  
Until verified, these remain hypotheses.  
  
  
  
=====Suggestions=====  
  
Backup the current version and make a branch  
Audit the information in the system right now. Get the right files in the right place, and then evaluate them to see where things are missing.   
Take   
Rewrite   
  
	1.	Evidence-First Rule:  
No finding listed without file citation (path + line or hash).  
	2.	Single Source of Truth Freeze:  
	•	Declare one AC file authoritative.  
	•	Archive or clearly deprecate others.  
	3.	Truth Hierarchy Verification Step:  
Before each run, explicitly confirm which file is Tier 1 / Tier 2 in effect.  
	4.	Status Declaration Standard:  
Any “COMPLETED” label requires:  
	•	Link to artefact,  
	•	Timestamp,  
	•	Verifiable reference.  
	5.	Change Consent Boundary Definition:  
Write down which files agents may modify without approval and which require explicit consent.  
	6.	Gap Tracker Consolidation:  
One canonical file for P0/P1 counts. All reports must reference that file.  
	7.	Run-Level Scope Declaration:  
Each testing run must declare:  
	•	Truth sources used,  
	•	Scope definition of P0,  
	•	Evidence directory.  
