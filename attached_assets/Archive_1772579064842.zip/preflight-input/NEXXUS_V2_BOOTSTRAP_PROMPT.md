# NEXXUS V2 - CLEAN REBUILD BOOTSTRAP PROMPT

**Purpose**: Initialize new Claude Code session for complete rebuild of Nexxus platform
**Strategy**: Complete isolation from production (zero risk approach)
**Target**: 6-week MVP delivery

---

## 📋 COPY-PASTE PROMPT (START BELOW THIS LINE)

---

# Nexxus V2 - Clean Rebuild Project Initialization

I need you to help me build Nexxus V2, a complete clean rebuild of an AI-powered automotive dealership platform. This is a **complete isolation project** - we are building from scratch in a new directory while production continues untouched.

## Critical Context

### What is Nexxus?

Nexxus is an **intelligent execution layer** for automotive dealerships that solves response gaps and follow-up inconsistencies through AI-powered voice, video, and chat interactions. It's the system that ensures existing leads are properly handled, not a lead generation tool.

**Core Value Proposition**: Dealerships don't lose because of lead volume—they lose because of response gaps and execution failures. Nexxus fixes this.

### Why Complete Rebuild (Not Refactoring)?

**Production System (nexxus v1):**
- Location: `/home/ubuntu/Claude-store/nexxus/`
- Status: **IN PRODUCTION** with paying customers
- Issues: Comprehensive audit found 8,750+ issues across 190/384 files (49.5% complete)
  - 379 CRITICAL security issues (authorization bypass, SQL injection, multi-tenant leaks)
  - 872 HIGH severity issues
  - 2,247 code quality issues
  - 1,640 refactoring opportunities
- Architecture: "Pieced together" over time, technical debt accumulated
- **Critical Constraint**: Has live customer deployments that CANNOT be disrupted

**Live Customer Deployments (MUST NOT BREAK):**
- Serra Automotive: 3 AI video assistants (Caroline, Magnolia, Georgia)
- Hyundai of Columbia: 2 AI video assistants (Elizabeth, Savannah)
- These use backend API endpoints via embed codes on customer websites
- Backend services (VAPI, Tavus integrations) are WORKING and STABLE

**Strategic Decision:**
Rather than fix 8,750+ issues in production code, build clean v2 in complete isolation:
- New directory: `/home/ubuntu/Claude-store/nexxus-v2/`
- New database instance (Supabase)
- New API accounts (Tavus dev, VAPI dev)
- New domain (nexxus-v2.huminicdev.com)
- **ZERO risk to production customers**

### Complete Isolation Strategy

```
Production (nexxus/)                 Development (nexxus-v2/)
├── Live customers (DO NOT TOUCH)    ├── Clean build from SRS
├── Production database               ├── New Supabase project
├── Production Tavus account          ├── New Tavus dev account
├── Production VAPI account           ├── New VAPI dev account
├── Port 5010                         ├── Port 5020 (or different)
├── nexxusdev.huminicdev.com         ├── nexxus-v2.huminicdev.com
└── FREEZE - maintenance only         └── Full rebuild freedom
```

**Benefits of Isolation:**
- ✅ Zero risk to production customers
- ✅ Freedom to experiment and iterate
- ✅ Clean architecture from day 1
- ✅ No legacy constraints
- ✅ Easy rollback (production never knew)
- ✅ Planned cutover when ready

## 🚨 CRITICAL CONSTRAINTS (NEVER VIOLATE)

### 1. Production Protection

**NEVER touch `/home/ubuntu/Claude-store/nexxus/` directory**

This directory contains:
- Live customer deployments (Serra + Hyundai)
- Production API endpoints serving customer embed codes
- Working backend integrations (VAPI, Tavus, VIN Solutions)

**If you need to reference v1 code:**
- Read files from v1 for context/inspiration only
- NEVER modify v1 files
- NEVER copy-paste v1 code without security review
- Use as "what NOT to do" reference (audit found 8,750 issues)

**Production Protection Documents:**
- `/home/ubuntu/Claude-store/nexxus/PRODUCTION_CUSTOMER_DEPLOYMENTS.md`
- `/home/ubuntu/Claude-store/nexxus/⚠️_READ_BEFORE_DEPLOYMENT.md`
- Read these to understand what NOT to break

### 2. No Shared Credentials

**Use ONLY new credentials for nexxus-v2:**
- New Supabase project (do NOT reuse v1 database)
- New Tavus account (dev tier)
- New VAPI account (dev tier)
- New API keys for all services
- Different port number (v1 uses 5010)

**Environment Variables:**
- Create new `.env` file
- NO copying from v1 `.env`
- All credentials must be new/separate

### 3. Implement SRS v3.0 Specification Exactly

**Primary Specification Document:**
`/home/ubuntu/Claude-store/nexxus-v2/docs/SYSTEM_REQUIREMENTS_SPECIFICATION_v3.0.md`

This is the authoritative source. Build exactly what it specifies:
- Data model (20 tables with full schemas)
- API endpoints (VIN, VAPI, Tavus, Nexxus)
- UI requirements (ClickUp-inspired interface)
- Security requirements (encryption, RBAC, audit logging)
- Integration requirements
- Operational requirements

**Do NOT deviate** without explicit user approval.

### 4. Security-First Approach

**Learn from v1 audit findings (what NOT to do):**
- ❌ Authorization bypass (SEC-063 CVSS 9.8)
- ❌ SQL injection (SEC-1300 CVSS 9.1)
- ❌ Multi-tenant data leaks (SEC-2454 CVSS 8.2)
- ❌ Unvalidated inputs
- ❌ Missing authentication checks

**Implement from day 1:**
- ✅ Row-level security (RLS) in PostgreSQL
- ✅ Parameterized queries (NO string concatenation)
- ✅ Input validation on all endpoints
- ✅ JWT authentication with proper expiry
- ✅ Multi-tenant isolation at database level
- ✅ Audit logging for all sensitive operations

### 5. Evidence-Based Development

**3-Proof Validation** for all features:

1. **Configuration Test**: Verify configs, env vars, settings work
2. **Functional Test**: Verify feature works (unit/integration test)
3. **Visual/E2E Test**: Verify UI/API produces expected results

**No commits without 3 passing tests.**

## 📁 Project Structure

### Current Directory Layout

```
/home/ubuntu/Claude-store/nexxus-v2/
├── docs/
│   ├── SYSTEM_REQUIREMENTS_SPECIFICATION_v3.0.md  (PRIMARY SPEC)
│   ├── NEXXUS_V2_BOOTSTRAP_PROMPT.md              (THIS FILE)
│   ├── SRS_EXECUTIVE_SUMMARY.md                   (Business overview)
│   ├── analysis/
│   │   ├── SRS_STRATEGIC_ALIGNMENT.md
│   │   ├── SRS_GAP_ANALYSIS.md
│   │   ├── SRS_AUDIT_RECONCILIATION.md
│   │   ├── SRS_REQUIREMENTS_PRIORITIZATION.md
│   │   └── SRS_RISK_ASSESSMENT.md
│   └── reference/
│       ├── PRODUCTION_CUSTOMER_DEPLOYMENTS.md     (What NOT to break)
│       ├── STRATEGIC_PIVOT_ANALYSIS.md            (Strategic context)
│       └── AUDIT_CHECKPOINT_150_FILES.md          (What NOT to repeat)
└── [TO BE CREATED BY YOU]
    ├── frontend/                                   (Next.js 14 app)
    ├── backend/                                    (Node.js/Express)
    ├── database/                                   (Supabase migrations)
    ├── tests/                                      (Jest, Playwright)
    ├── .env                                        (NEW credentials)
    ├── package.json
    ├── tsconfig.json
    └── README.md
```

## 🎯 Your Initial Tasks

### Phase 1: Environment Setup (Week 1)

**Task 1.1: Initialize Next.js 14 + TypeScript Project**

```bash
cd /home/ubuntu/Claude-store/nexxus-v2
npx create-next-app@latest frontend --typescript --tailwind --app --no-src-dir
```

Configuration:
- Next.js 14 with App Router
- TypeScript (strict mode)
- Tailwind CSS
- ESLint
- NO `src` directory (use `app` directly)

**Task 1.2: Set Up Supabase Project**

1. Create new Supabase project (web console)
   - Project name: `nexxus-v2-dev`
   - Database password: Strong, unique
   - Region: Closest to users
2. Get connection string and API keys
3. Initialize database schema from SRS section 7.2

**Task 1.3: Configure Development Environment**

Create `.env` file with NEW credentials:

```bash
# Database (Supabase)
DATABASE_URL="postgresql://[NEW_CREDENTIALS]"
NEXT_PUBLIC_SUPABASE_URL="https://[PROJECT_ID].supabase.co"
NEXT_PUBLIC_SUPABASE_ANON_KEY="[NEW_KEY]"
SUPABASE_SERVICE_ROLE_KEY="[NEW_KEY]"

# API Configuration
API_PORT=5020
API_URL="http://localhost:5020"
NODE_ENV="development"

# Tavus (NEW dev account)
TAVUS_API_KEY="[NEW_DEV_KEY]"
TAVUS_WEBHOOK_SECRET="[NEW_SECRET]"

# VAPI (NEW dev account)
VAPI_API_KEY="[NEW_DEV_KEY]"
VAPI_WEBHOOK_SECRET="[NEW_SECRET]"

# VIN Solutions (sandbox credentials)
VIN_CLIENT_ID="[SANDBOX_ID]"
VIN_CLIENT_SECRET="[SANDBOX_SECRET]"
VIN_API_URL="https://sandbox.api.vinsolutions.com"

# JWT (generate new secrets)
JWT_SECRET="[GENERATE_NEW_SECRET]"
JWT_REFRESH_SECRET="[GENERATE_NEW_SECRET]"

# Security
ALLOWED_ORIGINS="http://localhost:3000,http://localhost:5020"
RATE_LIMIT_MAX=1000
RATE_LIMIT_WINDOW_MS=60000
```

**Task 1.4: Implement Database Schema**

Reference: SRS Section 7.2 (20 tables)

Create migration files in order:
1. `001_create_organizations.sql`
2. `002_create_locations.sql`
3. `003_create_roles.sql`
4. `004_create_users.sql`
5. `005_create_integrations.sql`
6. ... (continue through all 20 tables)

**Enable Row-Level Security (RLS) for all tables.**

**Task 1.5: Set Up Testing Framework**

```bash
npm install --save-dev jest @testing-library/react @testing-library/jest-dom
npm install --save-dev playwright @playwright/test
```

Configure:
- Unit tests: Jest + React Testing Library
- E2E tests: Playwright
- Test coverage target: 80% backend, 70% frontend

### Phase 2: Core Features (Weeks 2-4)

**Priority: P0 Requirements (MVP)**

1. **Authentication & RBAC** (REQ-AUTH-001 to REQ-AUTH-005)
   - JWT authentication with 15min expiry
   - Four-tier RBAC (System Admin, Partner Admin, Customer Admin, Staff)
   - MFA for admin roles
   - Session management
   - Organization-level RLS

2. **VIN Solutions Integration** (REQ-INT-001)
   - OAuth 2.0 client credentials
   - Create customer/lead endpoint
   - Schedule appointment endpoint
   - Token caching and refresh

3. **VAPI Integration** (REQ-INT-002)
   - Create voice assistants
   - Manage phone numbers
   - Webhook handling
   - Call initiation

4. **Tavus Integration** (REQ-INT-003)
   - Create video replicas
   - Manage personas
   - Create conversations
   - Callback handling

5. **Credit Management** (REQ-CRED-001, REQ-CRED-004)
   - Track usage by service type
   - Calculate costs accurately
   - Voice: $0.25/min (customer) $0.15/min (cost) = 40% margin
   - Video: $0.32/min (customer) $0.20/min (cost) = 37.5% margin
   - SMS: $0.05/msg (customer) $0.02/msg (cost) = 60% margin

6. **Basic UI** (REQ-AI-001, REQ-PERF-001)
   - ClickUp-inspired layout (left nav, top bar)
   - DealerBrain command palette (⌘K)
   - Chat interface
   - Dashboard
   - Settings

### Phase 3: Enhanced Features (Weeks 5-6)

**Priority: P1 Requirements**

1. Conversation history (REQ-CONV-002)
2. Task management (REQ-TASK-001, REQ-TASK-002)
3. Reporting dashboards (REQ-RPT-001, REQ-RPT-004)
4. Advanced DealerBrain features (REQ-AI-002 to REQ-AI-005)

## 🛠️ Development Approach

### 1. MVP-First Philosophy

**6-Week Timeline (Aggressive but Achievable):**
- Week 1: Environment setup, database schema, authentication
- Week 2: VIN Solutions + VAPI + Tavus integrations
- Week 3: Basic UI (Chat, Dashboard, Settings)
- Week 4: Credit management, agent management
- Week 5: Reporting, task management
- Week 6: Testing, polish, documentation

**Deliver working software every week.**

### 2. Configuration Over Code

**Prefer database configurations and environment variables:**
- Agent configurations in database, not hardcoded
- Credit policies in `credit_policies` table
- Business rules configurable
- Feature flags for gradual rollout

**Example:**
```typescript
// ❌ BAD: Hardcoded
const VOICE_RATE = 0.25;

// ✅ GOOD: Database-driven
const voicePolicy = await db.credit_policies.findFirst({
  where: { service_type: 'voice', organization_id }
});
const rate = voicePolicy.rate_per_unit;
```

### 3. Stop-and-Resolve on Blockers

**Never work around issues silently:**
1. STOP immediately when blocked
2. Document exactly what's wrong
3. Present 2-3 clear options with tradeoffs
4. Wait for user decision
5. Resume only after guidance received

**Example Blocker Format:**
```
🚨 BLOCKER: [Short description]

Context: [What I was doing]
Issue: [Exactly what's wrong]
Attempted: [What I tried]

Options:
1. [Option 1 - pros/cons]
2. [Option 2 - pros/cons]
3. [Option 3 - pros/cons]

Recommendation: [If applicable]

Awaiting decision before proceeding.
```

### 4. Clean Architecture (No Technical Debt)

**Folder Structure Best Practices:**

```
backend/
├── src/
│   ├── api/
│   │   ├── routes/           # API route handlers
│   │   ├── middleware/       # Auth, validation, rate limiting
│   │   └── controllers/      # HTTP request handling
│   ├── services/             # Business logic
│   │   ├── auth.service.ts
│   │   ├── vin.service.ts
│   │   ├── vapi.service.ts
│   │   ├── tavus.service.ts
│   │   └── credit.service.ts
│   ├── db/
│   │   ├── client.ts         # Supabase client
│   │   ├── migrations/       # SQL migrations
│   │   └── repositories/     # Data access layer
│   ├── types/                # TypeScript types
│   ├── utils/                # Utilities
│   └── config/               # Configuration
└── tests/                    # Tests mirror src structure
```

**TypeScript Strict Mode:**
```json
{
  "compilerOptions": {
    "strict": true,
    "noImplicitAny": true,
    "strictNullChecks": true,
    "strictFunctionTypes": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true
  }
}
```

### 5. UI Prototyping Flexibility

**Option 1: Code from scratch** (Next.js + Tailwind)
- Full control
- Clean code
- Follows SRS exactly

**Option 2: Use prototyping tools** (v0.dev, Figma with code export, etc.)
- Faster UI development
- Import generated code
- Refine and integrate with backend

**Either approach is acceptable** - focus is on:
- Implementing SRS UI requirements (Section 9)
- ClickUp-inspired design
- Responsive and accessible
- Integration with backend APIs

## 📚 Reference Documents

### Primary Specification

**`/home/ubuntu/Claude-store/nexxus-v2/docs/SYSTEM_REQUIREMENTS_SPECIFICATION_v3.0.md`**
- THE authoritative source
- Read sections as needed:
  - Section 4: Functional Requirements
  - Section 6: System Architecture
  - Section 7: Data Model (20 tables)
  - Section 8: API Specifications
  - Section 9: UI Requirements
  - Section 10: Security Requirements
  - Section 12: Requirements Catalog (with priorities)

### Analysis Documents

**Strategic Context:**
- `SRS_EXECUTIVE_SUMMARY.md` - Business overview, economic model
- `SRS_STRATEGIC_ALIGNMENT.md` - Why this approach was chosen
- `SRS_REQUIREMENTS_PRIORITIZATION.md` - MVP vs Phase 2 vs Phase 3

**What NOT to Do:**
- `SRS_AUDIT_RECONCILIATION.md` - Security issues from v1 audit
- `reference/AUDIT_CHECKPOINT_150_FILES.md` - Detailed audit findings
- Learn from v1's mistakes, don't repeat them

**Implementation Guidance:**
- `SRS_GAP_ANALYSIS.md` - Differences between SRS and v1
- `SRS_RISK_ASSESSMENT.md` - Risks and mitigation strategies

### Production Protection

**`reference/PRODUCTION_CUSTOMER_DEPLOYMENTS.md`**
- Live customer information
- API endpoints in production use
- What will need migration later

**Read this to understand:**
- Which v1 endpoints must be preserved during migration
- Customer embed code dependencies
- Production API contracts to maintain compatibility with

## ✅ Pre-Flight Safeguards Checklist

Before starting ANY work, verify:

### Environment Isolation
- [ ] Working directory is `/home/ubuntu/Claude-store/nexxus-v2/`
- [ ] NOT in `/home/ubuntu/Claude-store/nexxus/` (production)
- [ ] Git repository initialized in nexxus-v2 (not nexxus)
- [ ] Separate .env file with NEW credentials
- [ ] Different port number (NOT 5010)

### Credential Separation
- [ ] Created NEW Supabase project (not reusing v1)
- [ ] NEW Tavus dev account API keys
- [ ] NEW VAPI dev account API keys
- [ ] NEW JWT secrets (not copied from v1)
- [ ] All env vars are NEW, not copied from v1

### Production Protection
- [ ] Read `/home/ubuntu/Claude-store/nexxus/PRODUCTION_CUSTOMER_DEPLOYMENTS.md`
- [ ] Read `/home/ubuntu/Claude-store/nexxus/⚠️_READ_BEFORE_DEPLOYMENT.md`
- [ ] Understand which v1 API endpoints serve live customers
- [ ] Confirmed NO changes will be made to v1 directory

### Specification Alignment
- [ ] Read SRS Executive Summary (Section 1)
- [ ] Read System Architecture (Section 6)
- [ ] Read Data Model (Section 7.2)
- [ ] Read Security Requirements (Section 10)
- [ ] Understand P0 requirements from Requirements Catalog

### Development Setup
- [ ] Node.js v20+ installed
- [ ] TypeScript configured with strict mode
- [ ] Testing framework installed (Jest, Playwright)
- [ ] Git configured for commits
- [ ] Code editor configured with ESLint

## 🎯 Success Criteria

### Technical Success
- ✅ All P0 requirements implemented (REQ-AUTH, REQ-INT, REQ-CRED, REQ-PERF, REQ-SEC)
- ✅ Zero security issues from v1 audit repeated
- ✅ Database schema matches SRS Section 7.2 exactly
- ✅ API endpoints match SRS Section 8 specifications
- ✅ 99.5% uptime SLO achievable
- ✅ <2s response time for 95% of requests
- ✅ Row-level security (RLS) implemented for all tables
- ✅ 80%+ test coverage (backend), 70%+ (frontend)

### Business Success
- ✅ Economic model implemented correctly:
  - Voice: 40% margin ($0.25 customer / $0.15 cost)
  - Video: 37.5% margin ($0.32 customer / $0.20 cost)
  - SMS: 60% margin ($0.05 customer / $0.02 cost)
- ✅ VIN Solutions integration production-ready
- ✅ VAPI voice assistants functional
- ✅ Tavus video conversations working
- ✅ Credit tracking accurate and real-time

### Migration Readiness
- ✅ Zero impact on production customers during development
- ✅ Data migration plan defined
- ✅ API compatibility maintained for customer embed codes
- ✅ Rollback plan documented
- ✅ Cutover checklist prepared

## 🚀 Getting Started

1. **Verify Pre-Flight Checklist** (above)
2. **Read SRS Executive Summary** (Section 1)
3. **Initialize Next.js 14 project** in `/home/ubuntu/Claude-store/nexxus-v2/`
4. **Create NEW Supabase project**
5. **Set up .env with NEW credentials**
6. **Begin Phase 1: Environment Setup**

Remember:
- **Ask questions** when requirements are unclear
- **Stop and present options** when blocked
- **Validate with user** before major architectural decisions
- **3-proof validation** for all features
- **Zero production impact** - this is the golden rule

---

## Communication Style

**Spock Mode** (Evidence-based, logical, non-assumptive):
- No assumptions - state "I don't know" and present options
- Evidence-first - support claims with proof
- Logical structure - clear, organized communication
- Avoid emotional language - no "exciting" or unnecessary superlatives
- Precision over verbosity

**When uncertain:** STOP, read relevant files, ask for clarification.

---

## Questions to Ask Before Starting

If unclear on anything, ask:

1. **Infrastructure Access:** Do I have credentials for Supabase, Tavus dev, VAPI dev?
2. **Timeline Pressure:** Is 6-week MVP realistic, or should we adjust scope?
3. **Technology Constraints:** Must we use Supabase, or is PostgreSQL + custom auth acceptable?
4. **Team Capacity:** How many developers? Solo or team?
5. **UI Approach:** Build from scratch or use prototyping tools?

---

**Ready to build Nexxus V2.**

**Current working directory:** `/home/ubuntu/Claude-store/nexxus-v2/`
**Primary specification:** `docs/SYSTEM_REQUIREMENTS_SPECIFICATION_v3.0.md`
**Approach:** MVP-first, clean architecture, security by default

Let's build something great. 🚀

---

## 📋 END OF BOOTSTRAP PROMPT

**How to Use This Prompt:**

1. Copy everything between "COPY-PASTE PROMPT (START BELOW THIS LINE)" and "END OF BOOTSTRAP PROMPT"
2. Start new Claude Code session in `/home/ubuntu/Claude-store/nexxus-v2/` directory
3. Paste the prompt
4. Claude will initialize with full context and start building

**Additional Context Files** (Claude will read these as needed):
- `SYSTEM_REQUIREMENTS_SPECIFICATION_v3.0.md` - Complete specification
- `SRS_EXECUTIVE_SUMMARY.md` - Business context
- `SRS_REQUIREMENTS_PRIORITIZATION.md` - What to build first
- `SRS_AUDIT_RECONCILIATION.md` - What NOT to repeat from v1
- `SRS_RISK_ASSESSMENT.md` - Known risks and mitigation

**User Note:** All reference documents from nexxus v1 will be copied to `nexxus-v2/docs/reference/` for context without risk of accidental modification.
