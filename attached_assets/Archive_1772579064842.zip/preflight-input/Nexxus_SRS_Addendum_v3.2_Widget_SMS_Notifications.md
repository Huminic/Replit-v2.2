# Nexxus SRS Addendum v3.2: Embedded Widget, SMS Integration & Notifications

**Document Version:** 3.2-ADD2
**Date:** February 3, 2026
**Status:** Active Addendum
**Classification:** Confidential
**Addendum Type:** Requirements Extension & Feature Addition

---

## Document Addendum Strategy

### Purpose of Addendum Approach

This is the **second addendum** in the Nexxus SRS chain, building upon the foundational requirements established in the base SRS v3.0 and the critical MVP features defined in Addendum v3.1. This addendum focuses on customer-facing communication channels and staff productivity tools.

### Addendum Chain Structure

```
Nexxus_SRS_v3.0_MASTER.md (January 30, 2026)
    ↓ [References]
Nexxus_SRS_Addendum_v3.1_MVP_Critical.md (February 3, 2026)
    ↓ [References]
Nexxus_SRS_Addendum_v3.2_Widget_SMS_Notifications.md (February 3, 2026) ← YOU ARE HERE
    ↓ [References]
Nexxus_SRS_Addendum_v3.3_[Future Topic].md (TBD)
```

### How to Use This Addendum

1. **Read Previous Documents**: Review base SRS v3.0 and Addendum v3.1 for foundational context
2. **Sequential Implementation**: This addendum assumes completion of Addendum v3.1 critical features
3. **Integrated Architecture**: All features integrate with existing DealerBrain, VAPI, and Tavus systems
4. **Code Implementation Caveat**: Examples are illustrative - adapt to existing codebase patterns

### Document References

- **Base Document**: `Nexxus_SRS_v3.0_MASTER.md` (January 30, 2026)
- **Previous Addendum**: `Nexxus_SRS_Addendum_v3.1_MVP_Critical.md` (February 3, 2026)
- **Next Addendum**: TBD (will be created as new requirements emerge)

---

## Table of Contents

1. [Architecture Decision: Build vs. Integrate](#1-architecture-decision-build-vs-integrate)
2. [Phase 1: Embedded Master Widget](#2-phase-1-embedded-master-widget)
3. [Phase 2: TextMagic SMS Integration](#3-phase-2-textmagic-sms-integration)
4. [Phase 3: Tracking & Attribution Pixel](#4-phase-3-tracking--attribution-pixel)
5. [Phase 4: Hosted Widget Pages](#5-phase-4-hosted-widget-pages)
6. [Phase 5: Internal Staff Messaging UI](#6-phase-5-internal-staff-messaging-ui)
7. [Phase 6: Agent Creation & Triggers](#7-phase-6-agent-creation--triggers)
8. [Implementation Roadmap](#8-implementation-roadmap)
9. [Database Schema Additions](#9-database-schema-additions)
10. [Security & Compliance](#10-security--compliance)

---

## 1. Architecture Decision: Build vs. Integrate

### 1.1 Evaluation of Chatwoot Integration

**Chatwoot Overview:**
- Open-source omnichannel customer support platform (MIT license)
- Features: Live chat widget, email, social media, WhatsApp integration, help center
- Self-hosted or cloud options

**Chatwoot Pros:**
- ✓ Battle-tested embeddable widget
- ✓ Multi-channel inbox
- ✓ Built-in help center/knowledge base
- ✓ MIT license (fully open source)

**Chatwoot Cons:**
- ✗ Adds complexity (separate database, Redis, additional infrastructure)
- ✗ Overkill for current needs
- ✗ Requires significant integration work
- ✗ Duplicate functionality (we already have chat, VAPI, Tavus)
- ✗ Another system to maintain

### 1.2 REQ-ARCH-WIDGET-001 [ARCHITECTURE]: Build Custom Widget

**RECOMMENDATION**: Build custom embedded widget rather than integrating Chatwoot.

**Rationale:**
1. **Simplicity**: We already have all the backend pieces (DealerBrain chat, VAPI, Tavus, TextMagic)
2. **Control**: Full control over UX, branding, and feature set
3. **Integration**: Direct integration with existing Nexxus architecture
4. **Lightweight**: Simple JavaScript widget + API endpoints
5. **Unified Data**: All conversations in single Nexxus database

**What We Build:**
- Embeddable JavaScript widget (master button with 6 options)
- Hosted widget pages (chat, video, callback forms)
- Widget configuration UI in Nexxus Settings
- Backend API endpoints for widget interactions
- Tracking pixel for attribution
- Internal staff messaging UI

**What We Leverage:**
- Existing DealerBrain chat orchestration
- Existing VAPI integration (voice/audio)
- Existing Tavus integration (video)
- TextMagic SDK (new integration)
- Existing RBAC and organizational isolation

---

## 2. Phase 1: Embedded Master Widget

**Priority**: P0 - Critical for customer-facing value
**Timeline**: Days 1-10

### 2.1 REQ-WIDGET-CONFIG-UI-001 [P0]: Widget Configuration Interface

The system SHALL provide a comprehensive widget configuration UI in Nexxus Settings.

**Configuration Interface Layout:**

```
┌────────────────────────────────────────────────────────────────┐
│  Widget Configuration - Serra                                  │
├─────────────────────┬──────────────────────────────────────────┤
│  Configuration      │  Widget Preview                          │
│  Sections:          │                                          │
│                     │  [Live preview of widget                 │
│  🎨 Appearance ▼    │   as configured]                         │
│    - Color theme    │                                          │
│    - Branding       │  Updates in real-time                    │
│    - Minimized state│  as settings change                      │
│    - Welcome screen │                                          │
│                     │                                          │
│  📱 Channels ▼      │                                          │
│                     │                                          │
│  🎯 Targeting ▼     │                                          │
│                     │                                          │
│  <> Embed code ▼    │  [Copy embed code]  [More ▼]            │
└─────────────────────┴──────────────────────────────────────────┘
```

**Configuration Sections:**

#### A. Appearance Section
- Color theme (primary, secondary, text colors)
- Branding (logo, organization name)
- Minimized state (position, button icon, animation)
- Welcome screen (greeting, message, avatar, CTA)

#### B. Channels Section
Toggle and configure each communication channel:
- ✓ Text Chat (always enabled)
- ☐ Web Video Agent (Tavus persona selection)
- ☐ Call Us (phone number, business hours)
- ☐ Call You (callback - VAPI assistant selection)
- ☐ Web Audio (VAPI assistant selection)
- ☐ Send a Text (TextMagic number)

#### C. Targeting Section
- Audience rules (all visitors, new, returning)
- Page rules (include/exclude URLs)
- Device targeting
- Time-based rules (business hours only)
- Behavior triggers (delay, scroll, exit intent)

#### D. Embed Code Section
- Auto-generated embed snippet
- Copy to clipboard
- Domain whitelist configuration
- Test mode toggle

---

### 2.2 REQ-WIDGET-001 [P0]: Master Widget Button

The system SHALL provide an embeddable JavaScript widget with 6 communication options.

**6 Communication Options:**
1. **Text Chat** - Opens chat interface (powered by DealerBrain)
2. **Web Video Agent** - Launches Tavus video session
3. **Call Us** - Shows phone number with click-to-call
4. **Call You** - Callback form (VAPI will call customer)
5. **Web Audio** - Instant web audio call with VAPI
6. **Send a Text** - SMS form (TextMagic delivery)

**Embed Code:**

```html
<!-- ILLUSTRATIVE ONLY -->
<script>
  window.nexxusConfig = {
    orgId: 'org_abc123',
    widgetId: 'widget_xyz789',
    position: 'bottom-right',
    primaryColor: '#0070f3',
    greeting: 'Hi there 👋'
  };
</script>
<script src="https://cdn.nexxusai.com/widget/v1/nexxus-widget.js" async></script>
```

**Database Schema:**

```sql
CREATE TABLE widget_configs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,

    -- Widget identity
    widget_code VARCHAR(50) NOT NULL UNIQUE,
    widget_name VARCHAR(255) NOT NULL,

    -- Appearance
    config_appearance JSONB DEFAULT '{
      "colorTheme": {"primaryColor": "#0070f3", "secondaryColor": "#0051a8"},
      "branding": {"logoUrl": null, "showLogo": true},
      "minimizedState": {"position": "bottom-right", "animation": "pulse"},
      "welcomeScreen": {"heading": "Hi there 👋", "message": "How can we help?"}
    }',

    -- Channels
    config_channels JSONB DEFAULT '{
      "textChat": {"enabled": true, "displayName": "Text Chat"},
      "videoAgent": {"enabled": false, "personaId": null},
      "callUs": {"enabled": true, "phoneNumber": null},
      "callYou": {"enabled": false, "assistantId": null},
      "webAudio": {"enabled": false, "assistantId": null},
      "sendText": {"enabled": false}
    }',

    -- Targeting
    config_targeting JSONB DEFAULT '{
      "audience": "all",
      "pageRules": {"includePages": [], "excludePages": []},
      "businessHoursOnly": false
    }',

    -- Domain restrictions
    allowed_domains JSONB DEFAULT '[]',

    -- Hosted pages
    hosted_pages_enabled BOOLEAN DEFAULT true,

    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_widget_configs_org ON widget_configs(organization_id);
CREATE INDEX idx_widget_configs_code ON widget_configs(widget_code);
```

---

### 2.3 REQ-WIDGET-002 [P0]: Text Chat Option

When user clicks "Text Chat", widget expands to chat interface powered by DealerBrain.

**Implementation:**
- Reuse existing DealerBrain chat orchestration
- Migrate text chat code from `../nexxus` folder
- Update for new orchestration agent
- Widget stores `visitor_id` in localStorage

**Code Migration Note:**
The text chat code exists in the v1 nexxus folder and needs to be:
1. Migrated to v2 codebase
2. Updated for DealerBrain orchestration
3. Connected to widget infrastructure

---

### 2.4 REQ-WIDGET-003 [P0]: Web Video Agent Option

Launches Tavus video session with configured persona.

---

### 2.5 REQ-WIDGET-004 [P0]: Call Us Option

Displays phone number with click-to-call functionality.

---

### 2.6 REQ-WIDGET-005 [P1]: Call You (Callback) Option

Shows callback form, triggers VAPI outbound call.

**Database Schema:**

```sql
CREATE TABLE widget_callback_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    widget_config_id UUID NOT NULL REFERENCES widget_configs(id),
    organization_id UUID NOT NULL REFERENCES organizations(id),

    customer_name VARCHAR(255) NOT NULL,
    customer_phone VARCHAR(50) NOT NULL,
    preferred_time VARCHAR(50),

    visitor_id VARCHAR(255),
    page_url TEXT,

    status VARCHAR(20) DEFAULT 'pending',
    scheduled_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    vapi_call_id VARCHAR(255),

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

---

### 2.7 REQ-WIDGET-006 [P1]: Web Audio Option

Instant web-based audio call via VAPI Web SDK.

---

### 2.8 REQ-WIDGET-007 [P1]: Send a Text Option

SMS form with TextMagic delivery.

---

## 3. Phase 2: TextMagic SMS Integration

**Priority**: P0 - Critical for SMS functionality
**Timeline**: Days 6-12

### 3.1 REQ-SMS-001 [P0]: TextMagic Integration

**TextMagic SDK:** https://github.com/textmagic/textmagic-rest-nodejs-v2
**Documentation:** https://docs.textmagic.com/

**Current Credentials (Serra):**
- Username: `oauthdurran`
- API Key: `kuO5rDPMfLFbgSG6j9ETiZvWRsBsW8`
- Shared phone number across all Serra agents

**Use Cases:**
1. Widget "Send a Text" form delivery
2. Appointment confirmations
3. New lead outreach triggers
4. Internal staff sending texts from Nexxus UI
5. Server alerts and notifications
6. Automa commands ("Send a text to all leads I haven't called back today")

**Compliance:**
- ✓ Only message customers who have initiated contact
- ✓ Opt-out support ("Reply STOP to unsubscribe")
- ✓ No spam or unsolicited messages

**Database Schema:**

```sql
CREATE TABLE textmagic_config (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,

    api_username VARCHAR(255) NOT NULL,
    api_key_encrypted TEXT NOT NULL,
    phone_number VARCHAR(50) NOT NULL,

    enabled BOOLEAN DEFAULT true,
    opt_out_keyword VARCHAR(50) DEFAULT 'STOP',

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(organization_id)
);

CREATE TABLE textmagic_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id),

    textmagic_message_id VARCHAR(255),
    direction VARCHAR(20) NOT NULL, -- 'inbound', 'outbound'
    from_number VARCHAR(50) NOT NULL,
    to_number VARCHAR(50) NOT NULL,
    message_text TEXT NOT NULL,

    status VARCHAR(50),
    customer_phone VARCHAR(50),
    linked_lead_id UUID,
    sent_by_user_id UUID REFERENCES users(id),

    is_opt_out BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE textmagic_opt_outs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id),
    phone_number VARCHAR(50) NOT NULL,
    opted_out_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    status VARCHAR(20) DEFAULT 'opted_out',

    UNIQUE(organization_id, phone_number)
);
```

---

### 3.2 REQ-SMS-002 [P0]: Appointment Confirmation SMS

Automatic SMS when appointment booked.

**Template:**
```
Hi [Customer Name]! Your appointment at [Dealership] is confirmed for [Date] at [Time].
Reply CONFIRM or call us at [Phone]. Reply STOP to unsubscribe.
```

---

### 3.3 REQ-SMS-003 [P1]: New Lead Outreach SMS

Automated SMS to new leads (via VIN triggers).

---

### 3.4 REQ-SMS-004 [P1]: Automa SMS Commands

Staff can use Automa to send SMS:
- "Send a text to all leads I haven't called back today"
- "Text all customers who missed appointments this week"

Automa generates SMS, presents for approval, then sends via TextMagic.

---

## 4. Phase 3: Tracking & Attribution Pixel

**Priority**: P1 - Important for analytics
**Timeline**: Days 13-18

### 4.1 REQ-TRACK-001 [P1]: Attribution Tracking Pixel

Tracking pixel to monitor visitor behavior and attribute conversions.

**Tracked Events:**
- Page views
- Widget interactions
- Form submissions
- Conversions (appointment booked, call completed)
- UTM parameters

**Database Schema:**

```sql
CREATE TABLE widget_visitors (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id),

    visitor_id VARCHAR(255) NOT NULL UNIQUE,
    first_seen_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    first_page_url TEXT,
    referrer_url TEXT,
    utm_source VARCHAR(255),
    utm_medium VARCHAR(255),
    utm_campaign VARCHAR(255),

    user_agent TEXT,
    total_pageviews INTEGER DEFAULT 1,
    last_seen_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE widget_interactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    widget_config_id UUID NOT NULL REFERENCES widget_configs(id),
    visitor_id VARCHAR(255) NOT NULL,
    organization_id UUID NOT NULL REFERENCES organizations(id),

    interaction_type VARCHAR(50) NOT NULL,
    page_url TEXT,

    converted BOOLEAN DEFAULT false,
    conversion_type VARCHAR(50),

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

---

## 5. Phase 4: Hosted Widget Pages

**Priority**: P1 - Important for standalone use cases
**Timeline**: Days 19-25

### 5.1 REQ-HOSTED-001 [P1]: Hosted Chat Page

Standalone pages for each widget feature:

**URL Structure:**
```
https://chat.nexxusai.com/org_abc123/widget_xyz789
https://chat.nexxusai.com/org_abc123/widget_xyz789/video
https://chat.nexxusai.com/org_abc123/widget_xyz789/callback
```

**Use Case:** Customer shares link in email signature, social media.

---

## 6. Phase 5: Internal Staff Messaging UI

**Priority**: P0 - Critical for two-way communication
**Timeline**: Days 26-35

### 6.1 REQ-STAFF-MSG-001 [P0]: Unified Messaging Inbox

Unified inbox for widget chats, SMS threads, and callbacks.

**Inbox Layout:**

```
┌─────────────────────────────────────────────────────────────────┐
│  Inbox                                    [All] [Unread] [Mine] │
├──────────────────────┬──────────────────────────────────────────┤
│  Conversations (23)  │  John Smith - Text Chat                  │
│                      │  ────────────────────────────────────────│
│  📧 Widget Chat (12) │  John: Looking for an SUV with AWD       │
│  💬 SMS (8)          │                                          │
│  📞 Callbacks (3)    │  You: We have several great options...   │
│                      │                                          │
│  [+ New Message]     │  [Type your reply here...] [Send]       │
└──────────────────────┴──────────────────────────────────────────┘
```

**Features:**
- Unified inbox (widget chats, SMS, callbacks)
- Assignment to staff members
- Canned responses
- Conversation status tracking
- Real-time updates (SSE)

**Database Schema:**

```sql
CREATE TABLE inbox_conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id),

    conversation_type VARCHAR(50) NOT NULL, -- 'widget_chat', 'sms', 'callback'
    customer_name VARCHAR(255),
    customer_phone VARCHAR(50),

    assigned_to_user_id UUID REFERENCES users(id),
    status VARCHAR(20) DEFAULT 'open',
    priority VARCHAR(20) DEFAULT 'normal',

    last_message_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE inbox_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id UUID NOT NULL REFERENCES inbox_conversations(id),

    sender_type VARCHAR(20) NOT NULL, -- 'customer', 'staff', 'system'
    sender_user_id UUID REFERENCES users(id),
    message_type VARCHAR(20) DEFAULT 'text',
    message_content TEXT NOT NULL,

    textmagic_message_id VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

---

### 6.2 REQ-STAFF-MSG-002 [P0]: Send SMS from Nexxus

Staff can send SMS from Nexxus UI and via Automa commands.

---

## 7. Phase 6: Agent Creation & Triggers

**Priority**: P1 - Important for automation
**Timeline**: Days 36-45

### 7.1 REQ-AGENT-CREATE-001 [P1]: Automa Agent Creation

Users SHALL be able to create custom agents via Automa using natural language.

**Example:**
> "Create an agent that calls new leads during business hours if they haven't been contacted in 2 hours"

Automa generates:
- Agent configuration
- Trigger rules
- Action definitions
- VAPI assistant binding (if voice)

---

### 7.2 REQ-TRIGGER-001 [P1]: VIN Lead Triggers for Outbound Calls

Automated outbound calls when new leads detected in VIN reports.

**Global Enable/Disable:**
- System-wide flag to enable/disable VIN triggers
- Built as custom agent (not hard-coded)
- Controllable from Super Admin settings

**Trigger Configuration:**

```sql
CREATE TABLE agent_triggers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id),
    agent_id UUID NOT NULL REFERENCES agents(id),

    trigger_type VARCHAR(100) NOT NULL, -- 'vin_new_lead', 'time_based', 'event'
    trigger_name VARCHAR(255) NOT NULL,

    conditions JSONB NOT NULL, -- { "leadAge": "> 2h", "noContact": true }
    actions JSONB NOT NULL, -- [{ "type": "vapi_call", "assistantId": "..." }]

    enabled BOOLEAN DEFAULT true,
    global_enabled BOOLEAN DEFAULT false, -- Super Admin override
    business_hours_only BOOLEAN DEFAULT true,

    last_triggered_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE agent_trigger_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    trigger_id UUID NOT NULL REFERENCES agent_triggers(id),

    triggered_by JSONB NOT NULL,
    actions_taken JSONB NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

---

### 7.3 REQ-VIN-POLL-001 [P1]: Hourly VIN New Lead Polling

Poll VIN Solutions hourly for new leads and import to Nexxus database.

**Implementation:**
- Cron job runs hourly
- Query VIN API for leads created since last poll
- Import new leads to `leads` table
- Trigger any configured agents/actions

---

## 8. Implementation Roadmap

### Timeline Overview

| Phase | Priority | Timeline | Focus Areas |
|-------|----------|----------|-------------|
| Phase 1: Master Widget | P0 | Days 1-10 | Widget button, 6 options, config UI |
| Phase 2: TextMagic | P0 | Days 6-12 | SMS integration, appointment confirmations |
| Phase 3: Tracking Pixel | P1 | Days 13-18 | Visitor tracking, attribution |
| Phase 4: Hosted Pages | P1 | Days 19-25 | Standalone chat/video pages |
| Phase 5: Staff Inbox | P0 | Days 26-35 | Unified inbox, SMS sending |
| Phase 6: Triggers | P1 | Days 36-45 | Agent creation, VIN triggers |

---

## 9. Database Schema Additions

### Summary of New Tables

| Table Name | Section | Purpose |
|------------|---------|---------|
| `widget_configs` | 2.1 | Widget configuration and branding |
| `widget_callback_requests` | 2.6 | Callback form submissions |
| `textmagic_config` | 3.1 | TextMagic API credentials |
| `textmagic_messages` | 3.1 | SMS message log |
| `textmagic_opt_outs` | 3.1 | SMS opt-out tracking |
| `widget_visitors` | 4.1 | Visitor tracking |
| `widget_interactions` | 4.1 | Widget interaction events |
| `inbox_conversations` | 6.1 | Unified inbox threads |
| `inbox_messages` | 6.1 | Messages within inbox |
| `agent_triggers` | 7.2 | Agent trigger rules |
| `agent_trigger_executions` | 7.2 | Trigger execution log |

---

## 10. Security & Compliance

### 10.1 Widget Security
- Domain restrictions (whitelist)
- CORS enforcement
- Rate limiting (100 interactions/hour/visitor)
- API key encryption (AES-256)

### 10.2 SMS Compliance
- Automatic "STOP" keyword detection
- Opt-out confirmation message
- "START" for opt-back-in
- Only transactional/relationship messages
- Clear identification in every message
- Consent tracking

---

## Document Chain

- **Previous**: `Nexxus_SRS_Addendum_v3.1_MVP_Critical.md` (February 3, 2026)
- **Current**: `Nexxus_SRS_Addendum_v3.2_Widget_SMS_Notifications.md` (February 3, 2026)
- **Next**: TBD

---

## Code Implementation Caveat

> **IMPORTANT**: All code examples are **illustrative only**. Adapt to existing codebase patterns.

**Implementation Guidelines:**
1. **Leverage Existing Code**: Text chat code in `../nexxus` - migrate and update
2. **Integrate with Existing Systems**: Use DealerBrain, VAPI, Tavus integrations
3. **Follow Addendum Chain**: Builds on Addendum v3.1
4. **Incremental Development**: Build and test each phase independently

---

**Document Version:** 3.2-ADD2
**Last Updated:** February 3, 2026
**Status:** Draft - Awaiting Review
