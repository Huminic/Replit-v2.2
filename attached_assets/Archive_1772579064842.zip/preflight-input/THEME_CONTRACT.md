# Theme Contract

**Version:** 1.0.0
**Last Updated:** 2026-01-21
**Status:** Draft

## 1. Introduction

### Purpose

This document defines the design token system and theming constraints for Nexxus v2. It establishes a clear contract between the design system and the application code, ensuring:

- Consistent visual design across the entire application
- Maintainable styling through centralized token definitions
- Support for light/dark mode switching
- Future-proof architecture for UI redesigns
- Clear separation between system theming and organization branding

### Simplified Theming Model

Nexxus v2 uses a **system-wide theming approach** with limited organization branding:

- **System Themes:** Control the entire UI appearance (colors, typography, spacing, etc.)
- **Organization Branding:** Limited to logo and two brand colors only
- **No Per-Organization Themes:** All users see the same core UI design
- **Future-Proof:** Architecture supports future theme variations without code changes

### System Theming vs. Organization Branding

| Aspect | System Theming | Organization Branding |
|--------|----------------|----------------------|
| **Scope** | Entire UI (all components, pages) | Logo + 2 colors only |
| **Control** | Super Admin / Platform level | Organization Admin |
| **Variants** | Light mode, Dark mode | N/A |
| **Customization** | Complete design token control | `primaryColor`, `secondaryColor` |
| **Use Case** | UI redesigns, accessibility improvements | White-label appearance |

## 2. Theme Contract (What Themes CAN Change)

### Color Tokens

```typescript
interface ColorTokens {
  brand: {
    primary: string;      // Main brand color (CTA buttons, links)
    secondary: string;    // Secondary brand color (accents)
    tertiary: string;     // Accent color (highlights, badges)
  };

  semantic: {
    success: string;      // Green tones (confirmations, success states)
    warning: string;      // Yellow/orange tones (warnings, cautions)
    error: string;        // Red tones (errors, destructive actions)
    info: string;         // Blue tones (informational messages)
  };

  neutral: {
    50: string;   // Lightest neutral (near white)
    100: string;  // Very light gray
    200: string;  // Light gray
    300: string;  // Medium-light gray
    400: string;  // Medium gray
    500: string;  // True middle gray
    600: string;  // Medium-dark gray
    700: string;  // Dark gray
    800: string;  // Very dark gray
    900: string;  // Darkest neutral (near black)
  };

  background: {
    base: string;         // Main page background
    surface: string;      // Card/panel backgrounds
    overlay: string;      // Modal/drawer backgrounds
    elevated: string;     // Elevated surfaces (tooltips, dropdowns)
  };

  foreground: {
    primary: string;      // Main text color
    secondary: string;    // Secondary text (less emphasis)
    tertiary: string;     // Muted text (hints, placeholders)
    disabled: string;     // Disabled text
    inverse: string;      // Text on dark backgrounds
  };

  border: {
    base: string;         // Default border color
    muted: string;        // Subtle borders (dividers)
    emphasis: string;     // Emphasized borders (focus states)
  };
}
```

**Example Usage:**
```css
.button-primary {
  background-color: var(--color-brand-primary);
  color: var(--color-foreground-inverse);
}

.card {
  background-color: var(--color-background-surface);
  border: 1px solid var(--color-border-base);
}
```

### Typography Tokens

```typescript
interface TypographyTokens {
  fontFamily: {
    sans: string;   // Body font (default: 'Inter', system-ui, sans-serif)
    serif: string;  // Headings (optional: 'Merriweather', Georgia, serif)
    mono: string;   // Code (default: 'Fira Code', 'Monaco', monospace)
  };

  fontSize: {
    xs: string;     // 0.75rem (12px) - Small labels
    sm: string;     // 0.875rem (14px) - Captions
    base: string;   // 1rem (16px) - Body text
    lg: string;     // 1.125rem (18px) - Large body text
    xl: string;     // 1.25rem (20px) - Small headings
    '2xl': string;  // 1.5rem (24px) - H4
    '3xl': string;  // 1.875rem (30px) - H3
    '4xl': string;  // 2.25rem (36px) - H2
    '5xl': string;  // 3rem (48px) - H1
  };

  fontWeight: {
    light: number;     // 300 - Light emphasis
    normal: number;    // 400 - Body text
    medium: number;    // 500 - Medium emphasis
    semibold: number;  // 600 - Strong emphasis
    bold: number;      // 700 - Headings
  };

  lineHeight: {
    tight: number;   // 1.25 - Headings
    normal: number;  // 1.5 - Body text
    relaxed: number; // 1.75 - Long-form content
    loose: number;   // 2 - Airy layouts
  };

  letterSpacing: {
    tight: string;   // -0.025em - Large headings
    normal: string;  // 0 - Body text
    wide: string;    // 0.025em - Small caps, labels
  };
}
```

**Example Usage:**
```css
.heading-1 {
  font-family: var(--font-sans);
  font-size: var(--font-size-5xl);
  font-weight: var(--font-weight-bold);
  line-height: var(--line-height-tight);
}

.body-text {
  font-family: var(--font-sans);
  font-size: var(--font-size-base);
  font-weight: var(--font-weight-normal);
  line-height: var(--line-height-normal);
}
```

### Spacing Tokens

```typescript
interface SpacingTokens {
  0: string;   // 0 - No space
  1: string;   // 0.25rem (4px) - Minimal spacing
  2: string;   // 0.5rem (8px) - Small spacing
  4: string;   // 1rem (16px) - Base spacing
  6: string;   // 1.5rem (24px) - Medium spacing
  8: string;   // 2rem (32px) - Large spacing
  12: string;  // 3rem (48px) - Extra large spacing
  16: string;  // 4rem (64px) - Section spacing
  20: string;  // 5rem (80px) - Page-level spacing
  24: string;  // 6rem (96px) - Hero spacing
  32: string;  // 8rem (128px) - Dramatic spacing
  40: string;  // 10rem (160px) - Maximum spacing
  48: string;  // 12rem (192px) - Extreme spacing
  64: string;  // 16rem (256px) - Ultra spacing
}
```

**Example Usage:**
```css
.card {
  padding: var(--space-6);
  margin-bottom: var(--space-4);
}

.section {
  margin-top: var(--space-16);
  margin-bottom: var(--space-16);
}
```

### Radius Tokens

```typescript
interface RadiusTokens {
  none: string;   // 0 - Sharp corners
  sm: string;     // 0.125rem (2px) - Subtle rounding
  base: string;   // 0.25rem (4px) - Standard rounding
  md: string;     // 0.375rem (6px) - Medium rounding
  lg: string;     // 0.5rem (8px) - Large rounding
  xl: string;     // 0.75rem (12px) - Extra large rounding
  '2xl': string;  // 1rem (16px) - Very round
  full: string;   // 9999px - Pill shape
}
```

**Example Usage:**
```css
.button {
  border-radius: var(--radius-base);
}

.avatar {
  border-radius: var(--radius-full);
}

.card {
  border-radius: var(--radius-lg);
}
```

### Shadow Tokens

```typescript
interface ShadowTokens {
  none: string;   // No shadow
  sm: string;     // Subtle elevation (hover states)
  base: string;   // Standard card shadow
  md: string;     // Elevated panels (dropdowns)
  lg: string;     // Modals/drawers
  xl: string;     // Maximum elevation (popovers)
  '2xl': string;  // Extreme depth (notifications)
}
```

**Example Values:**
```css
:root {
  --shadow-none: none;
  --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --shadow-base: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
  --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
  --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
  --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
  --shadow-2xl: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
}
```

**Example Usage:**
```css
.card {
  box-shadow: var(--shadow-base);
}

.modal {
  box-shadow: var(--shadow-lg);
}
```

### Motion Tokens

```typescript
interface MotionTokens {
  duration: {
    instant: string;  // 100ms - Immediate feedback
    fast: string;     // 200ms - Quick transitions
    base: string;     // 300ms - Standard transitions
    slow: string;     // 500ms - Deliberate transitions
  };

  easing: {
    linear: string;       // linear - Constant speed
    easeIn: string;       // cubic-bezier(0.4, 0, 1, 1) - Accelerate
    easeOut: string;      // cubic-bezier(0, 0, 0.2, 1) - Decelerate
    easeInOut: string;    // cubic-bezier(0.4, 0, 0.2, 1) - Smooth
  };
}
```

**Example Usage:**
```css
.button {
  transition: background-color var(--duration-fast) var(--easing-ease-out);
}

.modal {
  transition:
    opacity var(--duration-base) var(--easing-ease-in-out),
    transform var(--duration-base) var(--easing-ease-in-out);
}
```

## 3. Theme Contract (What Themes CANNOT Change)

### Forbidden Changes

Themes MUST NOT modify the following aspects:

#### Information Architecture
- **Route Structure:** URL paths, navigation hierarchy
- **Page Layouts:** Grid structures, column arrangements (can style, not restructure)
- **Content Organization:** Order of sections, sidebar placement logic

#### User Flows and Logic
- **Authentication:** Login/logout behavior, session management
- **Permissions:** Role-based access control logic
- **Form Validation:** Validation rules, error messages
- **Business Logic:** Calculations, data processing, workflows

#### Data Model and API Behavior
- **Database Schema:** Table structures, relationships
- **API Endpoints:** Routes, request/response formats
- **Data Transformations:** Formatting logic, computations
- **State Management:** Redux/Context logic

#### Core UX Patterns
- **Interaction Models:** Click vs. hover behaviors (unless part of intentional redesign)
- **Keyboard Navigation:** Tab order, shortcuts
- **Drag-and-Drop:** Behavior and mechanics
- **Multi-step Flows:** Wizard logic, step progression

#### Component Functionality
- **Props Interface:** Component APIs remain stable
- **Event Handlers:** onClick, onChange behavior
- **Data Fetching:** API integration logic
- **State Updates:** Internal component state management

**Example - What CAN Change:**
```tsx
// ✅ Allowed - Styling the button
const Button = styled.button`
  background-color: var(--color-brand-primary);
  border-radius: var(--radius-base);
  padding: var(--space-2) var(--space-4);
`;
```

**Example - What CANNOT Change:**
```tsx
// ❌ Forbidden - Changing button behavior
<Button onClick={doSomethingDifferent}> {/* Can't change onClick logic */}
<Button type="submit"> {/* Can't change form behavior */}
```

#### Accessibility Requirements

Themes MUST maintain **WCAG 2.1 AA compliance** at minimum:

- **Color Contrast:** 4.5:1 ratio for normal text, 3:1 for large text
- **Focus Indicators:** 3:1 contrast ratio, clearly visible
- **Interactive Elements:** 44x44px minimum touch target size
- **Text Readability:** Line length, spacing, font size minimums
- **Keyboard Navigation:** Focus order, visible focus states
- **Screen Reader Support:** ARIA labels, semantic HTML

## 4. Organization Branding (Simplified Model)

### Database Schema

```sql
CREATE TABLE organization_branding (
  organization_id UUID PRIMARY KEY REFERENCES organizations(id),
  logo_url VARCHAR(500),           -- Organization logo (displayed in header)
  favicon_url VARCHAR(500),        -- Browser favicon
  primary_color VARCHAR(7),        -- Hex color #RRGGBB (maps to brand.primary)
  secondary_color VARCHAR(7),      -- Hex color #RRGGBB (maps to brand.secondary)
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_org_branding_org_id ON organization_branding(organization_id);
```

### Usage

Organization branding provides **minimal customization**:

| Field | Maps To Token | Usage | Example |
|-------|---------------|-------|---------|
| `logo_url` | N/A | Header logo, login page | `https://cdn.example.com/logo.png` |
| `favicon_url` | N/A | Browser tab icon | `https://cdn.example.com/favicon.ico` |
| `primary_color` | `--color-brand-primary` | CTA buttons, links, primary actions | `#3b82f6` |
| `secondary_color` | `--color-brand-secondary` | Accents, secondary buttons | `#8b5cf6` |

**All other design tokens** use system default theme (light or dark mode).

### Color Validation

```typescript
// Server-side validation
const validateBrandingColors = (primaryColor: string, secondaryColor: string) => {
  // Must be valid hex colors
  const hexRegex = /^#[0-9A-F]{6}$/i;
  if (!hexRegex.test(primaryColor) || !hexRegex.test(secondaryColor)) {
    throw new Error('Colors must be valid hex format (#RRGGBB)');
  }

  // Must meet WCAG AA contrast requirements against white and dark backgrounds
  const contrastWhite = calculateContrast(primaryColor, '#FFFFFF');
  const contrastDark = calculateContrast(primaryColor, '#0F172A');

  if (contrastWhite < 4.5 && contrastDark < 4.5) {
    throw new Error('Primary color must have 4.5:1 contrast against light or dark background');
  }
};
```

### API Endpoints

```typescript
// GET /api/organizations/:id/branding
// Returns organization branding settings
interface BrandingResponse {
  organizationId: string;
  logoUrl: string | null;
  faviconUrl: string | null;
  primaryColor: string;
  secondaryColor: string;
}

// PUT /api/organizations/:id/branding
// Updates organization branding (Organization Admin only)
interface BrandingUpdateRequest {
  logoUrl?: string;
  faviconUrl?: string;
  primaryColor?: string;   // Validated hex color
  secondaryColor?: string; // Validated hex color
}
```

### Frontend Integration

```tsx
// Context provider for organization branding
const BrandingContext = createContext<BrandingResponse | null>(null);

export const BrandingProvider = ({ children }: { children: ReactNode }) => {
  const { organizationId } = useCurrentUser();
  const { data: branding } = useQuery(['branding', organizationId], () =>
    api.get(`/organizations/${organizationId}/branding`)
  );

  // Apply branding colors to CSS custom properties
  useEffect(() => {
    if (branding) {
      document.documentElement.style.setProperty(
        '--color-brand-primary',
        branding.primaryColor
      );
      document.documentElement.style.setProperty(
        '--color-brand-secondary',
        branding.secondaryColor
      );
    }
  }, [branding]);

  return (
    <BrandingContext.Provider value={branding}>
      {children}
    </BrandingContext.Provider>
  );
};
```

## 5. CSS Custom Properties Implementation

### File Structure

```
/styles
  /themes
    - default-light.css       # Light mode theme
    - default-dark.css        # Dark mode theme
    - future-themes.css       # Future theme variations
  - tokens.css                # Base token definitions
  - globals.css               # Global styles
  - reset.css                 # CSS reset
```

### Base Tokens (tokens.css)

```css
/**
 * Design Token Definitions
 * These tokens define the design system's visual language.
 * All components MUST use these tokens instead of hard-coded values.
 */

:root {
  /* ========================================
     COLOR TOKENS - BRAND
     ======================================== */
  --color-brand-primary: #3b82f6;      /* Blue 500 */
  --color-brand-secondary: #8b5cf6;    /* Purple 500 */
  --color-brand-tertiary: #06b6d4;     /* Cyan 500 */

  /* ========================================
     COLOR TOKENS - SEMANTIC
     ======================================== */
  --color-success: #10b981;            /* Green 500 */
  --color-warning: #f59e0b;            /* Amber 500 */
  --color-error: #ef4444;              /* Red 500 */
  --color-info: #3b82f6;               /* Blue 500 */

  /* ========================================
     COLOR TOKENS - NEUTRAL
     ======================================== */
  --color-neutral-50: #f8fafc;         /* Slate 50 */
  --color-neutral-100: #f1f5f9;        /* Slate 100 */
  --color-neutral-200: #e2e8f0;        /* Slate 200 */
  --color-neutral-300: #cbd5e1;        /* Slate 300 */
  --color-neutral-400: #94a3b8;        /* Slate 400 */
  --color-neutral-500: #64748b;        /* Slate 500 */
  --color-neutral-600: #475569;        /* Slate 600 */
  --color-neutral-700: #334155;        /* Slate 700 */
  --color-neutral-800: #1e293b;        /* Slate 800 */
  --color-neutral-900: #0f172a;        /* Slate 900 */

  /* ========================================
     COLOR TOKENS - BACKGROUNDS
     ======================================== */
  --color-background-base: #ffffff;
  --color-background-surface: #f8fafc;
  --color-background-overlay: rgba(0, 0, 0, 0.5);
  --color-background-elevated: #ffffff;

  /* ========================================
     COLOR TOKENS - FOREGROUND
     ======================================== */
  --color-foreground-primary: #0f172a;
  --color-foreground-secondary: #475569;
  --color-foreground-tertiary: #94a3b8;
  --color-foreground-disabled: #cbd5e1;
  --color-foreground-inverse: #ffffff;

  /* ========================================
     COLOR TOKENS - BORDERS
     ======================================== */
  --color-border-base: #e2e8f0;
  --color-border-muted: #f1f5f9;
  --color-border-emphasis: #3b82f6;

  /* ========================================
     TYPOGRAPHY TOKENS - FONT FAMILY
     ======================================== */
  --font-sans: 'Inter', system-ui, -apple-system, 'Segoe UI', sans-serif;
  --font-serif: 'Merriweather', Georgia, serif;
  --font-mono: 'Fira Code', 'Monaco', 'Courier New', monospace;

  /* ========================================
     TYPOGRAPHY TOKENS - FONT SIZE
     ======================================== */
  --font-size-xs: 0.75rem;      /* 12px */
  --font-size-sm: 0.875rem;     /* 14px */
  --font-size-base: 1rem;       /* 16px */
  --font-size-lg: 1.125rem;     /* 18px */
  --font-size-xl: 1.25rem;      /* 20px */
  --font-size-2xl: 1.5rem;      /* 24px */
  --font-size-3xl: 1.875rem;    /* 30px */
  --font-size-4xl: 2.25rem;     /* 36px */
  --font-size-5xl: 3rem;        /* 48px */

  /* ========================================
     TYPOGRAPHY TOKENS - FONT WEIGHT
     ======================================== */
  --font-weight-light: 300;
  --font-weight-normal: 400;
  --font-weight-medium: 500;
  --font-weight-semibold: 600;
  --font-weight-bold: 700;

  /* ========================================
     TYPOGRAPHY TOKENS - LINE HEIGHT
     ======================================== */
  --line-height-tight: 1.25;
  --line-height-normal: 1.5;
  --line-height-relaxed: 1.75;
  --line-height-loose: 2;

  /* ========================================
     TYPOGRAPHY TOKENS - LETTER SPACING
     ======================================== */
  --letter-spacing-tight: -0.025em;
  --letter-spacing-normal: 0;
  --letter-spacing-wide: 0.025em;

  /* ========================================
     SPACING TOKENS
     ======================================== */
  --space-0: 0;
  --space-1: 0.25rem;    /* 4px */
  --space-2: 0.5rem;     /* 8px */
  --space-4: 1rem;       /* 16px */
  --space-6: 1.5rem;     /* 24px */
  --space-8: 2rem;       /* 32px */
  --space-12: 3rem;      /* 48px */
  --space-16: 4rem;      /* 64px */
  --space-20: 5rem;      /* 80px */
  --space-24: 6rem;      /* 96px */
  --space-32: 8rem;      /* 128px */
  --space-40: 10rem;     /* 160px */
  --space-48: 12rem;     /* 192px */
  --space-64: 16rem;     /* 256px */

  /* ========================================
     RADIUS TOKENS
     ======================================== */
  --radius-none: 0;
  --radius-sm: 0.125rem;   /* 2px */
  --radius-base: 0.25rem;  /* 4px */
  --radius-md: 0.375rem;   /* 6px */
  --radius-lg: 0.5rem;     /* 8px */
  --radius-xl: 0.75rem;    /* 12px */
  --radius-2xl: 1rem;      /* 16px */
  --radius-full: 9999px;

  /* ========================================
     SHADOW TOKENS
     ======================================== */
  --shadow-none: none;
  --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --shadow-base: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
  --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
  --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
  --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
  --shadow-2xl: 0 25px 50px -12px rgba(0, 0, 0, 0.25);

  /* ========================================
     MOTION TOKENS - DURATION
     ======================================== */
  --duration-instant: 100ms;
  --duration-fast: 200ms;
  --duration-base: 300ms;
  --duration-slow: 500ms;

  /* ========================================
     MOTION TOKENS - EASING
     ======================================== */
  --easing-linear: linear;
  --easing-ease-in: cubic-bezier(0.4, 0, 1, 1);
  --easing-ease-out: cubic-bezier(0, 0, 0.2, 1);
  --easing-ease-in-out: cubic-bezier(0.4, 0, 0.2, 1);
}
```

### Dark Mode Theme (default-dark.css)

```css
/**
 * Dark Mode Theme
 * Overrides base tokens for dark mode appearance.
 */

[data-theme="dark"] {
  /* ========================================
     COLOR OVERRIDES - BACKGROUNDS
     ======================================== */
  --color-background-base: #0f172a;      /* Slate 900 */
  --color-background-surface: #1e293b;   /* Slate 800 */
  --color-background-overlay: rgba(0, 0, 0, 0.7);
  --color-background-elevated: #334155;  /* Slate 700 */

  /* ========================================
     COLOR OVERRIDES - FOREGROUND
     ======================================== */
  --color-foreground-primary: #f8fafc;   /* Slate 50 */
  --color-foreground-secondary: #cbd5e1; /* Slate 300 */
  --color-foreground-tertiary: #94a3b8;  /* Slate 400 */
  --color-foreground-disabled: #475569;  /* Slate 600 */
  --color-foreground-inverse: #0f172a;   /* Slate 900 */

  /* ========================================
     COLOR OVERRIDES - BORDERS
     ======================================== */
  --color-border-base: #334155;          /* Slate 700 */
  --color-border-muted: #1e293b;         /* Slate 800 */
  --color-border-emphasis: #60a5fa;      /* Blue 400 */

  /* ========================================
     COLOR OVERRIDES - BRAND (lighter for dark mode)
     ======================================== */
  --color-brand-primary: #60a5fa;        /* Blue 400 */
  --color-brand-secondary: #a78bfa;      /* Purple 400 */
  --color-brand-tertiary: #22d3ee;       /* Cyan 400 */

  /* ========================================
     COLOR OVERRIDES - SEMANTIC (lighter for dark mode)
     ======================================== */
  --color-success: #34d399;              /* Green 400 */
  --color-warning: #fbbf24;              /* Amber 400 */
  --color-error: #f87171;                /* Red 400 */
  --color-info: #60a5fa;                 /* Blue 400 */

  /* ========================================
     SHADOW OVERRIDES (softer in dark mode)
     ======================================== */
  --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.3);
  --shadow-base: 0 1px 3px 0 rgba(0, 0, 0, 0.4), 0 1px 2px 0 rgba(0, 0, 0, 0.3);
  --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.4), 0 2px 4px -1px rgba(0, 0, 0, 0.3);
  --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.5), 0 4px 6px -2px rgba(0, 0, 0, 0.3);
  --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.6), 0 10px 10px -5px rgba(0, 0, 0, 0.4);
  --shadow-2xl: 0 25px 50px -12px rgba(0, 0, 0, 0.7);
}
```

## 6. Component Token Usage

### Example: Button Component

```tsx
import styled from 'styled-components';

/**
 * Primary Button
 * Uses design tokens for all styling properties.
 */
const ButtonPrimary = styled.button`
  /* Spacing */
  padding: var(--space-2) var(--space-4);

  /* Typography */
  font-family: var(--font-sans);
  font-size: var(--font-size-base);
  font-weight: var(--font-weight-medium);

  /* Colors */
  background-color: var(--color-brand-primary);
  color: var(--color-foreground-inverse);
  border: 1px solid transparent;

  /* Borders */
  border-radius: var(--radius-base);

  /* Shadows */
  box-shadow: var(--shadow-sm);

  /* Motion */
  transition:
    background-color var(--duration-fast) var(--easing-ease-out),
    box-shadow var(--duration-fast) var(--easing-ease-out);

  /* States */
  &:hover:not(:disabled) {
    opacity: 0.9;
    box-shadow: var(--shadow-base);
  }

  &:active:not(:disabled) {
    transform: translateY(1px);
  }

  &:disabled {
    background-color: var(--color-neutral-300);
    color: var(--color-foreground-disabled);
    cursor: not-allowed;
    box-shadow: none;
  }

  &:focus-visible {
    outline: 2px solid var(--color-border-emphasis);
    outline-offset: 2px;
  }
`;

/**
 * Secondary Button
 */
const ButtonSecondary = styled.button`
  padding: var(--space-2) var(--space-4);
  font-family: var(--font-sans);
  font-size: var(--font-size-base);
  font-weight: var(--font-weight-medium);

  background-color: transparent;
  color: var(--color-brand-primary);
  border: 1px solid var(--color-brand-primary);
  border-radius: var(--radius-base);

  transition:
    background-color var(--duration-fast) var(--easing-ease-out),
    border-color var(--duration-fast) var(--easing-ease-out);

  &:hover:not(:disabled) {
    background-color: var(--color-brand-primary);
    color: var(--color-foreground-inverse);
  }

  &:focus-visible {
    outline: 2px solid var(--color-border-emphasis);
    outline-offset: 2px;
  }
`;

export { ButtonPrimary, ButtonSecondary };
```

### Example: Card Component

```tsx
import styled from 'styled-components';

const Card = styled.div`
  /* Background */
  background-color: var(--color-background-surface);

  /* Borders */
  border: 1px solid var(--color-border-base);
  border-radius: var(--radius-lg);

  /* Spacing */
  padding: var(--space-6);

  /* Shadow */
  box-shadow: var(--shadow-base);

  /* Motion */
  transition: box-shadow var(--duration-fast) var(--easing-ease-out);

  &:hover {
    box-shadow: var(--shadow-md);
  }
`;

const CardHeader = styled.div`
  margin-bottom: var(--space-4);
  padding-bottom: var(--space-4);
  border-bottom: 1px solid var(--color-border-muted);
`;

const CardTitle = styled.h3`
  font-family: var(--font-sans);
  font-size: var(--font-size-xl);
  font-weight: var(--font-weight-semibold);
  color: var(--color-foreground-primary);
  margin: 0;
`;

const CardContent = styled.div`
  font-family: var(--font-sans);
  font-size: var(--font-size-base);
  line-height: var(--line-height-normal);
  color: var(--color-foreground-secondary);
`;

export { Card, CardHeader, CardTitle, CardContent };
```

## 7. Light/Dark Mode Toggle

### Implementation

```tsx
import { createContext, useContext, useEffect, useState, ReactNode } from 'react';

type Theme = 'light' | 'dark';

interface ThemeContextValue {
  theme: Theme;
  toggleTheme: () => void;
  setTheme: (theme: Theme) => void;
}

const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

export const ThemeProvider = ({ children }: { children: ReactNode }) => {
  // Initialize from localStorage or system preference
  const [theme, setThemeState] = useState<Theme>(() => {
    const stored = localStorage.getItem('theme') as Theme | null;
    if (stored) return stored;

    // Detect system preference
    if (window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
    return 'light';
  });

  // Apply theme to document
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
  }, [theme]);

  // Listen for system preference changes
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = (e: MediaQueryListEvent) => {
      // Only auto-switch if user hasn't manually set a preference
      if (!localStorage.getItem('theme')) {
        setThemeState(e.matches ? 'dark' : 'light');
      }
    };

    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, []);

  const toggleTheme = () => {
    setThemeState((prev) => (prev === 'light' ? 'dark' : 'light'));
  };

  const setTheme = (newTheme: Theme) => {
    setThemeState(newTheme);
  };

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider');
  }
  return context;
};
```

### Theme Toggle Component

```tsx
import { Moon, Sun } from 'lucide-react';
import { useTheme } from '@/contexts/ThemeContext';
import styled from 'styled-components';

const ToggleButton = styled.button`
  padding: var(--space-2);
  background-color: var(--color-background-surface);
  border: 1px solid var(--color-border-base);
  border-radius: var(--radius-base);
  color: var(--color-foreground-primary);
  cursor: pointer;

  display: flex;
  align-items: center;
  justify-content: center;

  transition:
    background-color var(--duration-fast) var(--easing-ease-out),
    border-color var(--duration-fast) var(--easing-ease-out);

  &:hover {
    background-color: var(--color-background-elevated);
    border-color: var(--color-border-emphasis);
  }

  &:focus-visible {
    outline: 2px solid var(--color-border-emphasis);
    outline-offset: 2px;
  }
`;

export const ThemeToggle = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <ToggleButton
      onClick={toggleTheme}
      aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
      title={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
    >
      {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
    </ToggleButton>
  );
};
```

## 8. Accessibility Requirements

### Color Contrast Standards

All color combinations MUST meet **WCAG 2.1 AA** requirements:

| Element Type | Contrast Ratio | Example |
|--------------|----------------|---------|
| Normal text | 4.5:1 | Body text on background |
| Large text (18px+) | 3:1 | Headings, large UI text |
| UI components | 3:1 | Buttons, form inputs, icons |
| Focus indicators | 3:1 | Outline/border on focused elements |

### Validation Process

```typescript
/**
 * Validate color contrast ratio
 * Returns true if contrast meets WCAG AA standards
 */
const validateContrast = (
  foreground: string,
  background: string,
  fontSize: number,
  fontWeight: number
) => {
  const ratio = calculateContrastRatio(foreground, background);

  // Large text: 18px+ or 14px+ bold
  const isLargeText = fontSize >= 18 || (fontSize >= 14 && fontWeight >= 700);

  const requiredRatio = isLargeText ? 3 : 4.5;

  return ratio >= requiredRatio;
};
```

### Focus States

All interactive elements MUST have visible focus indicators:

```css
/* ❌ Wrong - No focus indicator */
button:focus {
  outline: none;
}

/* ✅ Correct - Clear focus indicator */
button:focus-visible {
  outline: 2px solid var(--color-border-emphasis);
  outline-offset: 2px;
}
```

### Touch Target Size

All interactive elements MUST meet minimum size requirements:

- **Minimum:** 44x44px (iOS guidelines)
- **Recommended:** 48x48px (Material Design)

```tsx
const IconButton = styled.button`
  /* Minimum touch target size */
  min-width: 44px;
  min-height: 44px;

  /* Center icon within touch target */
  display: flex;
  align-items: center;
  justify-content: center;
`;
```

### Keyboard Navigation

All interactive elements MUST be keyboard accessible:

- **Tab order:** Logical and sequential
- **Focus management:** Proper focus trapping in modals
- **Keyboard shortcuts:** Optional, but documented
- **Skip links:** "Skip to main content" for complex layouts

### Screen Reader Support

All UI elements MUST be properly labeled:

```tsx
// ❌ Wrong - No context for screen readers
<button onClick={handleDelete}>
  <TrashIcon />
</button>

// ✅ Correct - Descriptive aria-label
<button onClick={handleDelete} aria-label="Delete user">
  <TrashIcon aria-hidden="true" />
</button>
```

## 9. Example Themes

### Default Light Theme

```json
{
  "name": "Nexxus Light",
  "version": "1.0.0",
  "color": {
    "brand": {
      "primary": "#3b82f6",
      "secondary": "#8b5cf6",
      "tertiary": "#06b6d4"
    },
    "semantic": {
      "success": "#10b981",
      "warning": "#f59e0b",
      "error": "#ef4444",
      "info": "#3b82f6"
    },
    "background": {
      "base": "#ffffff",
      "surface": "#f8fafc",
      "overlay": "rgba(0, 0, 0, 0.5)",
      "elevated": "#ffffff"
    },
    "foreground": {
      "primary": "#0f172a",
      "secondary": "#475569",
      "tertiary": "#94a3b8",
      "disabled": "#cbd5e1",
      "inverse": "#ffffff"
    },
    "border": {
      "base": "#e2e8f0",
      "muted": "#f1f5f9",
      "emphasis": "#3b82f6"
    }
  },
  "typography": {
    "fontFamily": {
      "sans": "'Inter', system-ui, sans-serif",
      "serif": "'Merriweather', Georgia, serif",
      "mono": "'Fira Code', Monaco, monospace"
    }
  }
}
```

### Default Dark Theme

```json
{
  "name": "Nexxus Dark",
  "version": "1.0.0",
  "color": {
    "brand": {
      "primary": "#60a5fa",
      "secondary": "#a78bfa",
      "tertiary": "#22d3ee"
    },
    "semantic": {
      "success": "#34d399",
      "warning": "#fbbf24",
      "error": "#f87171",
      "info": "#60a5fa"
    },
    "background": {
      "base": "#0f172a",
      "surface": "#1e293b",
      "overlay": "rgba(0, 0, 0, 0.7)",
      "elevated": "#334155"
    },
    "foreground": {
      "primary": "#f8fafc",
      "secondary": "#cbd5e1",
      "tertiary": "#94a3b8",
      "disabled": "#475569",
      "inverse": "#0f172a"
    },
    "border": {
      "base": "#334155",
      "muted": "#1e293b",
      "emphasis": "#60a5fa"
    }
  },
  "typography": {
    "fontFamily": {
      "sans": "'Inter', system-ui, sans-serif",
      "serif": "'Merriweather', Georgia, serif",
      "mono": "'Fira Code', Monaco, monospace"
    }
  }
}
```

## 10. Theme Showcase Page

### Route: `/theme-lab`

**Access:** Super Admin only

**Purpose:**
- Quality assurance for theme changes
- Visual regression testing
- Future theme development and comparison
- Design system documentation

### Page Sections

#### 1. Theme Controls
- **Theme Switcher:** Light / Dark toggle
- **Density Switcher:** Compact / Comfortable / Spacious (future)
- **Color Contrast Checker:** Real-time WCAG validation

#### 2. Component Showcase

**Buttons:**
- Primary, Secondary, Tertiary variants
- All states: Default, Hover, Active, Disabled, Focus
- All sizes: Small, Medium, Large

**Form Inputs:**
- Text input, Textarea, Select, Checkbox, Radio
- All states: Default, Focus, Error, Disabled, Success

**Cards:**
- Basic card, Image card, Action card
- With and without shadows, borders

**Typography:**
- All heading levels (H1-H6)
- Body text variants (large, normal, small)
- Code blocks, inline code
- Lists (ordered, unordered)

**Feedback:**
- Alerts (success, warning, error, info)
- Toasts
- Loading spinners
- Progress bars

**Navigation:**
- Sidebar navigation
- Tabs
- Breadcrumbs
- Pagination

**Overlays:**
- Modals
- Drawers
- Tooltips
- Popovers

#### 3. Common Page Templates

**Settings Page:**
- Form layout
- Section organization
- Save/Cancel actions

**Table Page:**
- Data table with pagination
- Filters and search
- Row actions

**Dashboard:**
- Grid layout
- Metric cards
- Charts and graphs

**Form Page:**
- Multi-step wizard
- Validation states
- Error handling

### Implementation

```tsx
import { Card, CardHeader, CardTitle, CardContent } from '@/components/Card';
import { ButtonPrimary, ButtonSecondary } from '@/components/Button';
import { ThemeToggle } from '@/components/ThemeToggle';

export const ThemeLabPage = () => {
  return (
    <div style={{ padding: 'var(--space-8)' }}>
      {/* Header */}
      <header style={{ marginBottom: 'var(--space-8)' }}>
        <h1>Theme Lab</h1>
        <p>Component showcase and theme testing environment</p>
        <ThemeToggle />
      </header>

      {/* Buttons Section */}
      <section style={{ marginBottom: 'var(--space-12)' }}>
        <h2>Buttons</h2>
        <div style={{ display: 'flex', gap: 'var(--space-4)' }}>
          <ButtonPrimary>Primary</ButtonPrimary>
          <ButtonSecondary>Secondary</ButtonSecondary>
          <ButtonPrimary disabled>Disabled</ButtonPrimary>
        </div>
      </section>

      {/* Cards Section */}
      <section style={{ marginBottom: 'var(--space-12)' }}>
        <h2>Cards</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 'var(--space-4)' }}>
          <Card>
            <CardHeader>
              <CardTitle>Card Title</CardTitle>
            </CardHeader>
            <CardContent>
              This is a basic card component demonstrating theme tokens.
            </CardContent>
          </Card>
        </div>
      </section>

      {/* More sections... */}
    </div>
  );
};
```

---

## Summary

This theme contract establishes a **clear separation** between:

1. **System-wide theming** (complete design control, Super Admin managed)
2. **Organization branding** (limited to logo + 2 colors, Org Admin managed)

All components MUST:
- Use design tokens exclusively (no hard-coded values)
- Maintain WCAG 2.1 AA accessibility standards
- Support light/dark mode switching
- Preserve functionality across theme changes

This architecture ensures:
- Consistent user experience across all organizations
- Maintainable codebase with centralized styling
- Future-proof design system evolution
- Accessibility compliance by default
