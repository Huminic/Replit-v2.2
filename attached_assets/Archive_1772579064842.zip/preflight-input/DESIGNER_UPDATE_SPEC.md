# Designer Update Spec — Nexxus V2.1
# For: UI Designer (Replit Reference Update)
# From: Development Team
# Date: 2026-02-22
# Version: 1.1 (Designer Feedback Incorporated)

---

## CRITICAL CLARIFICATION — HUB TABS

**Hub has exactly 3 tabs: Calendar, Leads, Inbox.**

Any older document (including previous `replit.md` drafts) that mentions 4 Hub tabs (Calendar, Approvals, Communication, Open Leads) is **WRONG and contaminated**. The owner confirmed on 2026-02-22 that features were intentionally removed/moved during the Replit redesign. The current Replit source code (`work-center.tsx`) renders 3 tabs. This is final.

---

## PURPOSE

This document specifies every new UI element, tab structure, page layout, and component needed in the Replit reference design. The designer should use this to update the reference app. Once updated, development implements from the new reference.

**Rule: "The UI design is the truth."** After the designer updates the reference, that updated design becomes the definitive spec.

**What NOT to change:** Everything already in the current Replit reference that is not mentioned in this document should remain exactly as-is. This document only adds or modifies — it does not remove.

---

## TABLE OF CONTENTS

1. [Settings Page — Tile Grid](#1-settings-page--tile-grid)
2. [Tile 1: User Management + Org Creation Wizard](#2-tile-1-user-management)
3. [Tile 2: Organization](#3-tile-2-organization)
4. [Tile 3: Tools & Integrations (MAJOR REWORK)](#4-tile-3-tools--integrations)
5. [Tile 4: Knowledge Base](#5-tile-4-knowledge-base)
6. [Tile 5: AI Configuration (NEW TABS)](#6-tile-5-ai-configuration)
7. [Tile 6: Security & Privacy](#7-tile-6-security--privacy)
8. [Tile 7: Notifications](#8-tile-7-notifications)
9. [Tile 8: Data Management (MAJOR REWORK)](#9-tile-8-data-management)
10. [Tile 9: Appearance](#10-tile-9-appearance)
11. [Billing Page (NEW)](#11-billing-page)
12. [Agents Page Updates](#12-agents-page-updates)
13. [Hub Page — Dialer](#13-hub-page--dialer)
14. [Drive Page — Sharing](#14-drive-page--sharing)
15. [Org Creation Wizard (NEW)](#15-org-creation-wizard)
16. [Skills Catalog (NEW)](#16-skills-catalog)
17. [Hunch Configuration Popout (NEW)](#17-hunch-configuration-popout)
18. [Grayed Out Items Reference](#18-grayed-out-items-reference)
19. [RBAC Visibility Matrix](#19-rbac-visibility-matrix)

---

## 1. Settings Page — Tile Grid

### Current State (Preserve)
The settings page shows a grid of tiles. Each tile opens a detail view. The left sub-menu mirrors the tile list.

### Changes Needed

**Sub-menu items MUST match settings tiles 1:1.** Every sub-menu entry has a tile on the grid, and vice versa.

**Tile count changes:**
- **REMOVE** standalone "API & Webhooks" tile — this moves INSIDE Tools & Integrations (see Tile 3)
- Settings page now has **9 tiles** (was 10), but the sub-menu for Tools gets additional sub-items

**Updated sub-menu (left panel for `/settings/system`):**

```
Users
Organization
Tools & Integrations
Knowledge Base
AI Configuration
Security & Privacy
Notifications
Data Management
Appearance
```

### RBAC Visibility (Updated)

| Tile | Super Admin | Partner Admin | Org Admin | Staff |
|------|:-----------:|:------------:|:---------:|:-----:|
| User Management | Yes | Yes | Yes | -- |
| Organization | Yes | Yes | Yes | -- |
| Tools & Integrations | Yes | Yes | Yes | -- |
| Knowledge Base | Yes | Yes | Yes | -- |
| AI Configuration | Yes | Yes* | -- | -- |
| Security & Privacy | Yes | Yes | -- | -- |
| Notifications | Yes | Yes | Yes | -- |
| Data Management | Yes | -- | -- | -- |
| Appearance | Yes | Yes | Yes | -- |

*Partner Admin AI Config access details:
- **System Prompt tab:** READ-ONLY view. Partner Admin can see the system prompt configured for their assigned orgs but cannot edit it. This is useful for understanding agent behavior without being able to alter it.
- **Agent Behavior tab:** READ-ONLY view. Same rationale.
- **Skills tab:** HIDDEN. Not visible to Partner Admin at all. Super Admin only.
- **Hunches tab:** READ-ONLY view. Can see hunch settings but not modify them.
- **Emergency kill switch:** NOT visible. Super Admin only.

---

## 2. Tile 1: User Management

### Current State (Preserve)
User list with search, Add User, Edit User, Remove User, role badges.

### Changes Needed

**Two distinct views based on role:**

#### View A: Account Management (All Admin Roles)
- User list for the current org
- Add/edit/remove users within org
- Role assignment within org (Org Admin, Staff)
- This is the DEFAULT view when clicking User Management

#### View B: Organization Account Creation (Super Admin Only)
- Button: **"+ New Organization"** — launches the Org Creation Wizard (see Section 15)
- Visible ONLY to Super Admin
- Located above the user list OR as a separate sub-tab

**Layout suggestion:**
```
┌─────────────────────────────────────────┐
│ User Management                         │
│                                         │
│ [+ Add User]  [+ New Organization]*     │
│                                         │
│ ┌─────────────────────────────────────┐ │
│ │ Search users...                     │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ ┌─────────────────────────────────────┐ │
│ │ Name  │ Email │ Role │ Status │ ... │ │
│ │───────│───────│──────│────────│─────│ │
│ │ ...   │ ...   │ ...  │ ...    │     │ │
│ └─────────────────────────────────────┘ │
└─────────────────────────────────────────┘
* "+ New Organization" visible to Super Admin only
```

---

## 3. Tile 2: Organization

### Current State (Preserve)
Organization name field, Save button.

### Fields Needed (Add)
- **Organization Name** (text input) — existing
- **Business Phone** (text input) — NEW
- **Business Email** (email input) — NEW
- **Public Listing** (toggle) — NEW
- **Multi-Location** (toggle) — NEW
- **Save** button

No tab structure needed. Single form layout.

---

## 4. Tile 3: Tools & Integrations (MAJOR REWORK)

### Current State
Three sub-tabs: Tools, Widgets, Landing Pages.

### New Tab Structure

**5 tabs total (was 3):**

```
┌──────┬──────┬──────┬──────────┬───────────────┐
│ MCP  │ API  │Other │ Widgets  │ Landing Pages │
└──────┴──────┴──────┴──────────┴───────────────┘
```

**Super Admin ONLY sees 2 additional tabs:**

```
┌──────┬──────┬──────┬──────────┬───────────────┬──────────┬──────────┐
│ MCP  │ API  │Other │ Widgets  │ Landing Pages │ API Keys │ Webhooks │
└──────┴──────┴──────┴──────────┴───────────────┴──────────┴──────────┘
```

(API Keys and Webhooks tabs are the former "API & Webhooks" settings tile, now relocated here.)

---

### Tab 1: MCP (Model Context Protocol Tools)

**Layout: Tool card grid**

Each card shows:
```
┌────────────────────────────────┐
│ [Icon]                         │
│ Friendly Name                  │
│ Brief description              │
│                                │
│ Technical: {name}*  [Toggle]   │
│                                │
│ Status: Enabled / Disabled     │
│ [ Economy ✓ ]**                │
└────────────────────────────────┘
* Technical name line visible to Super Admin ONLY
** Economy checkbox visible to Super Admin ONLY (see Billing)
```

**Toggle behavior:**
- Toggle ON/OFF pauses the tool (waits for pending tasks before stopping)
- Toggle available to: Super Admin, Partner Admin, Org Admin
- Grayed-out tools have toggle LOCKED in OFF position (cannot be toggled by anyone)

**Current MCP tools to display:**
None currently — this tab is a placeholder. Show empty state: "No MCP tools configured. MCP tools are added via backend configuration."

---

### Tab 2: API (API-Based Integrations)

Same card layout as MCP tab.

**Current API tools:**

| Card | Friendly Name | Technical Name* | Status |
|------|--------------|-----------------|--------|
| 1 | CRM Integration | VIN Solutions | Grayed out, OFF, locked |
| 2 | Voice Calling | VAPI | Grayed out, OFF, locked |
| 3 | Video Calling | Tavus | Grayed out, OFF, locked |
| 4 | Authentication | Google Auth | Grayed out, OFF, locked |
| 5 | SMS & Text Sending | TextMagic | **ENABLED, ON** |

*Technical name only visible to Super Admin

---

### Tab 3: Other (Non-MCP, Non-API Tools)

Same card layout.

**Current "Other" tools:**

| Card | Friendly Name | Technical Name* | Status |
|------|--------------|-----------------|--------|
| 1 | Document Generator | Document Generator | **ENABLED, ON** |

---

### Tab 4: Widgets (PRESERVE existing)
Keep current widget CRUD with 4 types and 5 config tabs. No changes.
Add: Preview functionality for each widget type.

### Tab 5: Landing Pages (PRESERVE existing)
Keep current landing page CRUD. No changes.

### Tab 6: API Keys (Super Admin Only)
```
┌─────────────────────────────────────────┐
│ API Keys                                │
│                                         │
│ API Access: [Toggle ON/OFF]             │
│                                         │
│ API Key: ••••••••••••••4a2f  [Rotate]   │
│                                         │
│ Rate Limit: [____] requests/hour        │
│                                         │
│ [Save]                                  │
└─────────────────────────────────────────┘
```

### Tab 7: Webhooks (Super Admin Only)
```
┌─────────────────────────────────────────┐
│ Webhooks                                │
│                                         │
│ Webhook URL: [________________________] │
│                                         │
│ Events:                                 │
│ ☑ Lead Created                          │
│ ☑ Call Completed                        │
│ ☑ Appointment Booked                    │
│ ☑ Agent Status Change                   │
│                                         │
│ Status: Active / Inactive               │
│                                         │
│ [Save]                                  │
└─────────────────────────────────────────┘
```

---

### Tool Economy Section (Super Admin Only)

When Super Admin views a tool card, there should be an expandable "Economy" section:

```
┌────────────────────────────────┐
│ [Icon]  SMS & Text Sending     │
│ TextMagic                      │
│                        [ON]    │
│                                │
│ ▼ Economy Settings             │
│ ┌────────────────────────────┐ │
│ │ ☑ Add to billing economy   │ │
│ │ Base Rate: $[0.02]/msg     │ │
│ │ Markup Rate: $[0.05]/msg   │ │
│ │ Note: Rate changes apply   │ │
│ │ next billing period only   │ │
│ └────────────────────────────┘ │
│                                │
│ ▼ Tool Instructions            │
│ ┌────────────────────────────┐ │
│ │ (placeholder - grayed out) │ │
│ │ Future: instructions for   │ │
│ │ tool-database connections  │ │
│ └────────────────────────────┘ │
└────────────────────────────────┘
```

### Economy-to-Invoice Data Flow

The Economy section on tool cards (above) feeds directly into the Billing page (Section 11). Here is the complete data flow so the designer understands how these screens connect:

```
Tool Card Economy Settings          →  Invoice Line Items
─────────────────────────            ──────────────────────
SMS: Base $0.02, Markup $0.05/msg   →  "SMS Usage (2,340 msgs): $117.00"
Voice: Base $0.15, Markup $0.25/min →  "Voice Usage (47 overage min): $11.75"
Video: Base $0.20, Markup $0.32/min →  "Video Usage (0 overage): $0.00"
```

**The connection points in the UI:**
1. **Super Admin sets rates** on each tool card's Economy section (Tools & Integrations page)
2. **System tracks usage** per org per billing period (shown on org's Billing page as progress bars)
3. **Invoice Builder** (Billing Management page, Super Admin) auto-populates line items using: `(usage - default_minutes) * markup_rate` for each tool in the economy
4. Rate changes set on tool cards take effect only in the NEXT billing period — the Invoice Builder always uses the rate that was active during the billing period being invoiced

---

## 5. Tile 4: Knowledge Base

### Current State
Simple toggles only.

### Changes Needed

**Add tab structure for knowledge types:**

```
┌────────────┬────────────┬────────────┬────────────┐
│ Documents  │ Web Pages  │ Databases  │ Settings   │
└────────────┴────────────┴────────────┴────────────┘
```

### Tab 1: Documents
```
┌─────────────────────────────────────────┐
│ Documents                               │
│                                         │
│ [+ Upload Document]  [Search...]        │
│                                         │
│ ┌─────────────────────────────────────┐ │
│ │ Name      │ Type │ Size │ Date │ 🗑 │ │
│ │───────────│──────│──────│──────│───│ │
│ │ Inventory │ CSV  │ 2MB  │ 2/20 │ 🗑 │ │
│ │ Pricing   │ PDF  │ 500K │ 2/18 │ 🗑 │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ Source label: "Knowledge Store"         │
│ (Automa labels this data separately     │
│  from CRM data)                         │
└─────────────────────────────────────────┘
```

### Tab 2: Web Pages
```
┌─────────────────────────────────────────┐
│ Web Pages                               │
│                                         │
│ [+ Add URL]                             │
│                                         │
│ ┌─────────────────────────────────────┐ │
│ │ URL            │ Status  │ Last │ 🗑 │ │
│ │────────────────│─────────│──────│───│ │
│ │ dealer.com/inv │ Indexed │ 2/20 │ 🗑 │ │
│ └─────────────────────────────────────┘ │
└─────────────────────────────────────────┘
```

### Tab 3: Databases
```
┌─────────────────────────────────────────┐
│ Database Connections                    │
│                                         │
│ (Placeholder — grayed out)              │
│ Future: connect external databases      │
└─────────────────────────────────────────┘
```

### Tab 4: Settings
```
┌─────────────────────────────────────────┐
│ Knowledge Settings                      │
│                                         │
│ Auto-Index Files:     [ON/OFF]          │
│ Enable Web Scraping:  [ON/OFF]          │
│ Document Retention:   [90] days         │
│ Smart Summarization:  [ON/OFF]          │
│ Learning Mode:        [ON] (grayed out) │
│                                         │
│ [Save]                                  │
└─────────────────────────────────────────┘
```

**Important:** Data in the knowledge store has **lower priority** than CRM data. When Automa uses knowledge store data, it must display a source badge: "Source: Knowledge Store" (vs "Source: CRM").

---

## 6. Tile 5: AI Configuration (NEW TABS)

### Current State
Simple toggles (Enable Hunches, Auto-Scoring, Confidence Threshold, Learning Mode, Daily Digest).

### New Tab Structure

**4 tabs:**

```
┌───────────────┬─────────────────┬──────────┬──────────┐
│ System Prompt │ Agent Behavior  │ Skills   │ Hunches  │
└───────────────┴─────────────────┴──────────┴──────────┘
```

**RBAC:** Only Super Admin and Partner Admin see this tile. Skills tab and emergency button are **Super Admin only**.

---

### Tab 1: System Prompt

```
┌─────────────────────────────────────────┐
│ System Prompt                           │
│                                         │
│ ┌─────────────────────────────────────┐ │
│ │ System Prompt:                      │ │
│ │ ┌─────────────────────────────────┐ │ │
│ │ │ (large textarea)                │ │ │
│ │ │ You are Automa, an AI assis...  │ │ │
│ │ │                                 │ │ │
│ │ └─────────────────────────────────┘ │ │
│ │                                     │ │
│ │ System Information:                 │ │
│ │ ┌─────────────────────────────────┐ │ │
│ │ │ (textarea)                      │ │ │
│ │ └─────────────────────────────────┘ │ │
│ │                                     │ │
│ │ Rules & Exclusions:                 │ │
│ │ ┌─────────────────────────────────┐ │ │
│ │ │ (textarea)                      │ │ │
│ │ └─────────────────────────────────┘ │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ [Save]                                  │
└─────────────────────────────────────────┘
```

---

### Tab 2: Agent Behavior

```
┌─────────────────────────────────────────┐
│ Agent Behavior                          │
│                                         │
│ Overall Behavior Context:               │
│ ┌─────────────────────────────────────┐ │
│ │ (large textarea)                    │ │
│ │ Instructions for what agents are    │ │
│ │ allowed to do and how they behave   │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ Allowed Actions:                        │
│ ☑ Initiate outbound calls              │
│ ☑ Send SMS messages                    │
│ ☑ Create leads in CRM                  │
│ ☑ Schedule appointments                │
│ ☐ Access financial data                │
│ ☐ Modify customer records              │
│                                         │
│ [Save]                                  │
└─────────────────────────────────────────┘
```

---

### Tab 3: Skills (Super Admin Only)

This is the skill management interface. Skills are the 74 pre-built agent prompts from V1 that can be assigned to agents.

```
┌─────────────────────────────────────────┐
│ Skills                      [+ New Skill]│
│                                         │
│ ┌─────────────────────────────────────┐ │
│ │ Search skills...                    │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ [All] [Sales] [Finance] [Operations]    │
│ [General]                               │
│                                         │
│ ┌─────────────────────────────────────┐ │
│ │ ☑ Lead Qualifier           Sales    │ │
│ │   Qualify leads by budget/timeline  │ │
│ │──────────────────────────────────── │ │
│ │ ☑ Payment Calculator       Sales    │ │
│ │   Calculate monthly payments        │ │
│ │──────────────────────────────────── │ │
│ │ ☑ Deal Structurer          Finance  │ │
│ │   Structure optimal financing       │ │
│ │──────────────────────────────────── │ │
│ │ ... (scrollable list, 74 total)     │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ ┌─────────────────────────────────────┐ │
│ │ ⚠ EMERGENCY: DISABLE ALL AGENTS    │ │
│ │ [🔴 KILL SWITCH]                    │ │
│ │ Turns off ALL agent activity for    │ │
│ │ ALL users in ALL organizations.     │ │
│ │ Requires confirmation dialog.       │ │
│ └─────────────────────────────────────┘ │
└─────────────────────────────────────────┘
```

**Clicking a skill opens an edit panel:**

```
┌─────────────────────────────────────────┐
│ Edit Skill: Lead Qualifier              │
│                                         │
│ Name: [Lead Qualifier        ]          │
│ Category: [Sales ▼]                     │
│ Description:                            │
│ [Qualify incoming leads based on...]    │
│                                         │
│ Skill Prompt:                           │
│ ┌─────────────────────────────────────┐ │
│ │ You are a lead qualification expert │ │
│ │ for an auto dealership. Analyze...  │ │
│ │                                     │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ Tools: [CRM Lookup ▼] [+ Add Tool]     │
│ Temperature: [0.7]                      │
│                                         │
│ System-Wide Status: [Enabled/Disabled]  │
│                                         │
│ [Save] [Cancel] [Delete]                │
└─────────────────────────────────────────┘
```

**"+ New Skill" button** opens same form but blank.

**The full list of 74 pre-built skills is in Section 16 of this document.**

---

### Tab 4: Hunches

```
┌─────────────────────────────────────────┐
│ Hunch Configuration                     │
│                                         │
│ Enable Hunches:        [ON/OFF]         │
│                                         │
│ Auto-Scoring:          [ON] (grayed)    │
│ Confidence Threshold:  [70%] (grayed)   │
│ Temperature per Org:   [0.5] (grayed)   │
│                                         │
│ Daily Digest:          [ON/OFF]         │
│ Recipients: Org Admin, Partner Admin,   │
│             Super Admin                 │
│ Content: Daily accomplishments,         │
│          activities, new hunches        │
│                                         │
│ [Save]                                  │
└─────────────────────────────────────────┘
```

---

## 7. Tile 6: Security & Privacy

### Changes Needed

**ALL items grayed out with toggles in ON position (non-interactive).**

```
┌─────────────────────────────────────────┐
│ Security & Privacy                      │
│                                         │
│ Two-Factor Auth:   [ON]  ░░░ grayed ░░░ │
│ SSO Provider:      [ON]  ░░░ grayed ░░░ │
│ Session Timeout:   [60m] ░░░ grayed ░░░ │
│ IP Allowlist:      [ON]  ░░░ grayed ░░░ │
│ Audit Logging:     [ON]  ░░░ grayed ░░░ │
│                                         │
│ ─────────────────────────────────────── │
│ Password Management                     │
│ [Reset Password]  (functional button)   │
│                                         │
└─────────────────────────────────────────┘
```

**ADD:** Password reset function (button). This is functional, not grayed out.

---

## 8. Tile 7: Notifications

### Current State (Preserve)
Per-event notification preferences.

### Add

- **Global toggles** at top: Email ON/OFF, SMS ON/OFF, Push ON/OFF
- **Quiet Hours:** Start time [HH:MM] — End time [HH:MM]
- Existing per-event preferences below

```
┌─────────────────────────────────────────┐
│ Notifications                           │
│                                         │
│ Global Settings:                        │
│ Email Notifications:  [ON/OFF]          │
│ SMS Notifications:    [ON/OFF]          │
│ Push Notifications:   [ON/OFF]          │
│                                         │
│ Quiet Hours:                            │
│ Start: [22:00]  End: [07:00]            │
│                                         │
│ ─────────────────────────────────────── │
│ Per-Event Preferences:                  │
│ (existing event-type channel toggles)   │
│                                         │
│ [Save]                                  │
└─────────────────────────────────────────┘
```

---

## 9. Tile 8: Data Management (MAJOR REWORK)

### Current State
Simple toggles (Auto-Backup, Retention, Export Format, GDPR).

### New Tab Structure

**2 tabs:**

```
┌───────────────────┬──────────────┐
│ Database Uploads  │ Data Health  │
└───────────────────┴──────────────┘
```

---

### Tab 1: Database Uploads

**Sub-tabs for upload categories:**

```
┌──────────────────────────────────────────────┐
│ Database Uploads                             │
│                                              │
│ Categories:                                  │
│ [All] [Inventory] [Leads] [Contacts] [Other] │
│                                              │
│ [+ Upload Data]  [+ Scrape URL]              │
│                                              │
│ ┌──────────────────────────────────────────┐ │
│ │ Name      │ Type   │ Records │ Date │ 🗑  │ │
│ │───────────│────────│─────────│──────│──── │ │
│ │ Jan Inv.  │ CSV    │ 1,247   │ 1/15 │ 🗑  │ │
│ │ Website   │ Scrape │ 342     │ 2/01 │ 🗑  │ │
│ └──────────────────────────────────────────┘ │
│                                              │
│ Click row to expand:                         │
│ ┌──────────────────────────────────────────┐ │
│ │ Field Mapping:                           │ │
│ │ Source Column → System Field             │ │
│ │ "VIN_Number" → Vehicle.VIN              │ │
│ │ "Sale_Price" → Vehicle.Price            │ │
│ │                                          │ │
│ │ Interpretation Summary:                  │ │
│ │ "1,247 records: 890 new vehicles,       │ │
│ │  357 used. 12 records skipped (missing  │ │
│ │  required fields)."                      │ │
│ │                                          │ │
│ │ Processing Prompt:                       │ │
│ │ ┌──────────────────────────────────────┐ │ │
│ │ │ "Import this as inventory data.      │ │ │
│ │ │  Match VIN numbers to existing..."   │ │ │
│ │ └──────────────────────────────────────┘ │ │
│ └──────────────────────────────────────────┘ │
│                                              │
│ ─────────────────────────────────────────── │
│ SOC2 / Compliance: [ON] ░░░ grayed ░░░      │
│                                              │
└──────────────────────────────────────────────┘
```

**Upload dialog (on "+ Upload Data"):**
```
┌─────────────────────────────────────────┐
│ Upload Data                             │
│                                         │
│ Category: [Inventory ▼]                 │
│                                         │
│ ┌─────────────────────────────────────┐ │
│ │       Drag & drop file here         │ │
│ │    or [Browse Files]                │ │
│ │    CSV, JSON, Excel, PDF            │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ Processing Instructions:                │
│ ┌─────────────────────────────────────┐ │
│ │ Tell the system what to do with     │ │
│ │ this data...                        │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ Data Type:                              │
│ ○ Structured (CSV, JSON, Excel)        │
│ ○ Unstructured (PDF, documents)        │
│                                         │
│ [Upload & Process] [Cancel]             │
└─────────────────────────────────────────┘
```

**Field mapping step (shown after upload for structured data):**
```
┌─────────────────────────────────────────┐
│ Map Fields                              │
│                                         │
│ Source Column      →  System Field      │
│ ─────────────────────────────────────── │
│ "VIN_Number"       →  [Vehicle.VIN ▼]  │
│ "Stock_Number"     →  [Vehicle.Stock ▼]│
│ "Year"             →  [Vehicle.Year ▼] │
│ "Make"             →  [Vehicle.Make ▼] │
│ "Sale_Price"       →  [Vehicle.Price▼] │
│ "unknown_col"      →  [Skip ▼]        │
│                                         │
│ Preview (first 5 rows):                 │
│ ┌─────────────────────────────────────┐ │
│ │ VIN_Number │ Stock │ Year │ Make    │ │
│ │ 1HGCV1... │ A1234 │ 2024 │ Honda   │ │
│ │ ...        │ ...   │ ...  │ ...     │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ [Confirm Mapping] [Back]                │
└─────────────────────────────────────────┘
```

---

### Tab 2: Data Health

```
┌─────────────────────────────────────────┐
│ Data Health                             │
│                                         │
│ ┌───────────┐ ┌───────────┐             │
│ │ Total     │ │ Storage   │             │
│ │ Records   │ │ Used      │             │
│ │ 14,892    │ │ 2.3 GB    │             │
│ └───────────┘ └───────────┘             │
│                                         │
│ ┌───────────┐ ┌───────────┐             │
│ │ Active    │ │ Last      │             │
│ │ Uploads   │ │ Updated   │             │
│ │ 8         │ │ 2 hrs ago │             │
│ └───────────┘ └───────────┘             │
│                                         │
│ Data Breakdown:                         │
│ ┌─────────────────────────────────────┐ │
│ │ Category    │ Records │ Size │ Last  │ │
│ │─────────────│─────────│──────│──────│ │
│ │ Inventory   │ 5,230   │ 800M │ 2/20 │ │
│ │ Leads       │ 8,412   │ 1.2G │ 2/22 │ │
│ │ Contacts    │ 1,250   │ 300M │ 2/15 │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ ─────────────────────────────────────── │
│ Auto-Backup:      [ON] ░░░ grayed ░░░  │
│ Data Retention:   [12] months (grayed)  │
│ Export Format:    [CSV] (grayed)        │
│ GDPR Compliance:  [ON] ░░░ grayed ░░░  │
└─────────────────────────────────────────┘
```

---

## 10. Tile 9: Appearance

### Changes Needed

**Per-org setting** (not per-user). Org Admin has access.

```
┌─────────────────────────────────────────┐
│ Appearance                              │
│                                         │
│ These settings apply to all users       │
│ in this organization.                   │
│                                         │
│ Compact Mode:      [ON/OFF]             │
│ Animations:        [ON/OFF]             │
│ Default View:      [Dashboard ▼]        │
│ Show Metric Tiles: [ON/OFF]             │
│                                         │
│ [Save]                                  │
└─────────────────────────────────────────┘
```

---

## 11. Billing Page (NEW)

### Navigation Location (IMPORTANT)

Billing has **two access points** depending on role:

| Role | Where They Access Billing | Route | Navigation Path |
|------|--------------------------|-------|-----------------|
| **Org Admin / Staff** | Profile > Billing | `/profile/billing` | Profile sub-menu (left panel) > "Billing" |
| **Super Admin** | Settings > Billing Management | `/settings/billing` | Settings sub-menu > "Billing" (NEW sub-menu item) |
| **Partner Admin** | Settings > Billing Management | `/settings/billing` | Settings sub-menu > "Billing" (NEW sub-menu item) |

**This means:**
- The **Settings sub-menu** needs a new entry: **"Billing"** (visible to Super Admin and Partner Admin only)
- The **Profile sub-menu** already has "Billing" — this stays as-is for org-level users
- Super Admin and Partner Admin see the revenue dashboard and org management views
- Org Admin and Staff see their own org's billing summary (read-only)

**Updated Settings sub-menu (Super Admin):**
```
Users
Organization
Tools & Integrations
Knowledge Base
AI Configuration
Security & Privacy
Notifications
Data Management
Appearance
Billing              ← NEW (Super Admin + Partner Admin only)
```

**CRITICAL RULES:**
- Billing is **enable/disable per organization** with **default OFF**
- **No payment processing** — this is superficial and data-oriented only
- When enabled, the anniversary date must be specified
- Prorated billing calculations for mid-cycle changes
- Partners can see their accounts and add new accounts but do NOT process payments

---

### View A: Org Admin / Staff View (when billing ENABLED for their org)

```
┌─────────────────────────────────────────────────┐
│ Billing                                         │
│                                                 │
│ Plan: Pro Plan                                  │
│ Base Monthly Fee: $99/month                     │
│ Anniversary Date: March 15                      │
│ Next Invoice: March 15, 2026                    │
│                                                 │
│ ─────────────────────────────────────────────── │
│ Usage This Period                               │
│ ┌─────────────┐ ┌─────────────┐                 │
│ │ Voice       │ │ Video       │                 │
│ │ 847 / 1000  │ │ 123 / 500   │                 │
│ │ minutes     │ │ minutes     │                 │
│ │ [████████░] │ │ [███░░░░░░] │                 │
│ └─────────────┘ └─────────────┘                 │
│                                                 │
│ ┌─────────────┐ ┌─────────────┐                 │
│ │ SMS         │ │ Documents   │                 │
│ │ 2,340 msgs  │ │ 89 docs     │                 │
│ │ [██████░░░] │ │ [█░░░░░░░░] │                 │
│ └─────────────┘ └─────────────┘                 │
│                                                 │
│ Overage: $12.50 (voice: 47 min x $0.25 +       │
│          markup)                                 │
│                                                 │
│ ─────────────────────────────────────────────── │
│ Add-Ons This Period                             │
│ ┌─────────────────────────────────────────────┐ │
│ │ Description          │ Amount │ Recurring   │ │
│ │──────────────────────│────────│─────────────│ │
│ │ Extra SMS bundle     │ $25    │ Monthly     │ │
│ │ Setup fee            │ $150   │ One-time    │ │
│ └─────────────────────────────────────────────┘ │
│                                                 │
│ ─────────────────────────────────────────────── │
│ Invoice History                                 │
│ ┌─────────────────────────────────────────────┐ │
│ │ Date     │ Amount  │ Status  │ [View]       │ │
│ │──────────│─────────│─────────│──────────────│ │
│ │ Feb 15   │ $136.50 │ Sent    │ [View]       │ │
│ │ Jan 15   │ $124.00 │ Paid    │ [View]       │ │
│ └─────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────┘
```

### View B: Org Admin View (when billing DISABLED for their org)

```
┌─────────────────────────────────────────┐
│ Billing                                 │
│                                         │
│ Billing is not enabled for this         │
│ organization. Contact your              │
│ administrator for more information.     │
└─────────────────────────────────────────┘
```

---

### View C: Super Admin / Partner Admin — Revenue Dashboard

**This is the admin billing management view, NOT the org-facing view.**

```
┌──────────────────────────────────────────────────────┐
│ Billing Management                                   │
│                                                      │
│ Revenue Overview                                     │
│ ┌────────────┐ ┌────────────┐ ┌────────────┐        │
│ │ MRR        │ │ Active     │ │ Avg Rev/   │        │
│ │ $12,450    │ │ Accounts   │ │ Account    │        │
│ │ ▲ 8%       │ │ 24         │ │ $518.75    │        │
│ └────────────┘ └────────────┘ └────────────┘        │
│                                                      │
│ ┌────────────┐ ┌────────────┐ ┌────────────┐        │
│ │ Overage    │ │ Outstanding│ │ Collected   │        │
│ │ Revenue    │ │ Invoices   │ │ This Month  │        │
│ │ $1,847     │ │ 3 ($890)   │ │ $11,560     │        │
│ └────────────┘ └────────────┘ └────────────┘        │
│                                                      │
│ ─────────────────────────────────────────────────── │
│ Organization Billing Status                          │
│ ┌──────────────────────────────────────────────────┐ │
│ │ Org Name    │Billing│Anniv.│Base Fee│Usage│Status│ │
│ │─────────────│───────│──────│───────│─────│──────│ │
│ │ Serra Honda │ ON    │ 3/15 │ $99   │ $37 │ Paid │ │
│ │ Hyundai Col │ ON    │ 4/01 │ $149  │ $52 │ Due  │ │
│ │ Demo Org    │ OFF   │ --   │ --    │ --  │ --   │ │
│ └──────────────────────────────────────────────────┘ │
│                                                      │
│ [+ Send Invoice]  [+ Add Manual Add-On]              │
│                                                      │
│ ─────────────────────────────────────────────────── │
│ Billing Configuration (per-org, click row to edit)   │
│ ┌──────────────────────────────────────────────────┐ │
│ │ Organization: Serra Honda                        │ │
│ │ Billing Enabled: [ON/OFF]                        │ │
│ │ Anniversary Date: [2026-03-15]                   │ │
│ │ Base Monthly Fee: [$99.00]                       │ │
│ │ Setup Fee: [$0.00] (one-time, on sign-up)        │ │
│ │                                                  │ │
│ │ Default Minutes:                                 │ │
│ │   Voice: [1000] min  @ $[0.15]/min              │ │
│ │   Video: [500] min   @ $[0.20]/min              │ │
│ │                                                  │ │
│ │ Overage Rates:                                   │ │
│ │   Voice: $[0.25]/min (markup: $0.10)             │ │
│ │   Video: $[0.32]/min (markup: $0.12)             │ │
│ │                                                  │ │
│ │ Proration: Calculated automatically when         │ │
│ │ billing is enabled mid-cycle.                    │ │
│ │                                                  │ │
│ │ Payment Reminders: [OFF]                         │ │
│ │                                                  │ │
│ │ [Save Configuration]                             │ │
│ └──────────────────────────────────────────────────┘ │
│                                                      │
│ ─────────────────────────────────────────────────── │
│ Invoice Builder                                      │
│ ┌──────────────────────────────────────────────────┐ │
│ │ To: [Serra Honda ▼]                              │ │
│ │ Period: [Feb 15 - Mar 14, 2026]                  │ │
│ │                                                  │ │
│ │ Line Items:                                      │ │
│ │ 1. Monthly Base Charge        $99.00             │ │
│ │ 2. Voice Usage (1,047 min)    $11.75             │ │
│ │    (47 overage x $0.25)                          │ │
│ │ 3. Video Usage (423 min)      $0.00              │ │
│ │    (within 500 min default)                      │ │
│ │ 4. Extra SMS Bundle (add-on)  $25.00             │ │
│ │                         ──────────               │ │
│ │ Total:                        $135.75            │ │
│ │                                                  │ │
│ │ [+ Add Line Item] [Preview] [Send Invoice]       │ │
│ └──────────────────────────────────────────────────┘ │
└──────────────────────────────────────────────────────┘
```

### View D: Partner Admin — Account View

Partners see a simplified version:
- List of their assigned organizations with billing status
- Can add new organization accounts (launches Org Creation Wizard)
- Can view invoices for their orgs
- CANNOT configure billing rates (Super Admin only)
- CANNOT process payments

```
┌─────────────────────────────────────────────────┐
│ Partner Billing                                 │
│                                                 │
│ My Organizations                                │
│ ┌─────────────────────────────────────────────┐ │
│ │ Org Name     │ Status │ MRR   │ Last Invoice│ │
│ │──────────────│────────│───────│─────────────│ │
│ │ Serra Honda  │ Active │ $136  │ Feb 15      │ │
│ │ Hyundai Col. │ Active │ $201  │ Feb 01      │ │
│ └─────────────────────────────────────────────┘ │
│                                                 │
│ [+ Add Organization]  (launches wizard)         │
│                                                 │
│ Total MRR: $337  │  Active Accounts: 2          │
└─────────────────────────────────────────────────┘
```

---

## 12. Agents Page Updates

### Agent Config Pane — Complete Section Order (All 6 Sections)

The right-side Agent Config Pane has **6 sections** in this order. Sections 1-2 are UNCHANGED. Sections 3-6 have modifications noted below.

| # | Section | Status |
|---|---------|--------|
| 1 | **Performance** | UNCHANGED — channel badge, agent info (customerLink, assignedPhone, chatLink), 3 metrics (Interactions, Resolution Rate, Avg Response) |
| 2 | **Instructions** | UNCHANGED — System Prompt read-only + Edit modal |
| 3 | **Triggers** | MODIFIED — now per-agent with cron scheduling (see below) |
| 4 | **Tools & Skills** | MODIFIED — skills now selectable from 74-skill catalog (see below) |
| 5 | **Knowledge** | MODIFIED — clarified as reference storage only (see below) |
| 6 | **Activity** | UNCHANGED — recent activity items for this agent |

---

### Agent Config Pane — Section 5: Knowledge

**Current:** Upload area + source list.
**Change:** Clarify this is reference storage only (not RAG-indexed yet).

```
┌─────────────────────────────────────────┐
│ Knowledge                               │
│                                         │
│ [+ Upload Reference]                    │
│                                         │
│ ┌─────────────────────────────────────┐ │
│ │ Source Name    │ Items │ Status │ 🗑 │ │
│ │────────────────│───────│────────│───│ │
│ │ Product FAQ    │ 45    │ Stored │ 🗑 │ │
│ │ Pricing Guide  │ 12    │ Stored │ 🗑 │ │
│ │ Inventory CSV  │ 1,200 │ Stored │ 🗑 │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ ℹ References stored for agent context.  │
│   Auto-indexing controlled by Knowledge │
│   Base settings.                        │
└─────────────────────────────────────────┘
```

### Agent Config Pane — Triggers Section

**Change:** Triggers are **per-agent** (confirmed by owner). Show only triggers for this agent.

```
┌─────────────────────────────────────────┐
│ Triggers                                │
│                                         │
│ [+ Add Trigger]                         │
│                                         │
│ ┌─────────────────────────────────────┐ │
│ │ Trigger Name      │ Schedule │ [On] │ │
│ │───────────────────│──────────│──────│ │
│ │ New lead 5min     │ Event    │ [On] │ │
│ │ Daily follow-up   │ 9:00 AM  │ [On] │ │
│ │ Stale lead check  │ */4h     │ [Off]│ │
│ └─────────────────────────────────────┘ │
│                                         │
│ [Configure] opens trigger editor with:  │
│ - Trigger type (Event / Schedule)       │
│ - Condition (e.g., lead.age > 5min)     │
│ - Schedule (cron expression or simple)  │
│ - Action (what this agent should do)    │
└─────────────────────────────────────────┘
```

### Agent Config Pane — Tools & Skills Section

**Change:** Skills are now selectable from the catalog of 74 pre-built skills.

```
┌─────────────────────────────────────────┐
│ Tools & Skills                          │
│                                         │
│ Tools:                                  │
│ ┌─────────────────────────────────────┐ │
│ │ VIN Decoder          [Active]       │ │
│ │ CRM Lookup           [Active]       │ │
│ │ Appointment Scheduler[Inactive]     │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ Skills:                                 │
│ ┌─────────────────────────────────────┐ │
│ │ Lead Qualifier       [Active]       │ │
│ │ Follow-Up Sequencer  [Active]       │ │
│ │ Email Responder      [Active]       │ │
│ └─────────────────────────────────────┘ │
│                                         │
│ [Manage] opens modal to toggle tools    │
│ and skills from the available catalog   │
└─────────────────────────────────────────┘
```

---

## 13. Hub Page — Dialer

### Confirmation
- Dialer is **browser-based only**
- Calls route through **VAPI** (no WebRTC, no telephony hardware)
- The existing numpad UI in the Leads tab is correct
- When user dials, the call is initiated via VAPI outbound API

No design changes needed. This is a backend-only implementation note.

---

## 14. Drive Page — Sharing

### Changes Needed

**Share links are PUBLIC** — no authentication required.

When clicking "Share" on a file:
```
┌─────────────────────────────────────────┐
│ Share File                              │
│                                         │
│ Public Link:                            │
│ ┌─────────────────────────────────────┐ │
│ │ https://nexxusv2.../share/abc123    │ │
│ └─────────────────────────────────────┘ │
│ [Copy Link]                             │
│                                         │
│ Send via:                               │
│ [Email]  [SMS]                          │
│                                         │
│ ─────────────────────────────────────── │
│ [Download]         [Download as PDF]     │
└─────────────────────────────────────────┘
```

**Two download buttons:**
- **[Download]** — Always visible. Downloads the file in its original format. Works for all file types.
- **[Download as PDF]** — Visible only for file types that support PDF conversion:
  - Documents: `.doc`, `.docx`, `.txt`, `.rtf`, `.odt`
  - Spreadsheets: `.xls`, `.xlsx`, `.csv`
  - Presentations: `.ppt`, `.pptx`
  - Images: `.png`, `.jpg`, `.jpeg`, `.gif`, `.webp`
  - Already PDF: `.pdf` (button hidden — use [Download] instead)
  - NOT supported: video, audio, zip, executable files (button hidden for these)

---

## 15. Org Creation Wizard (NEW)

**Triggered by:** "+ New Organization" button in User Management (Super Admin) or "+ Add Organization" in Partner Billing.

**V1 had no wizard** — org creation was scattered across 3 disconnected flows. This is a brand new multi-step guided flow.

### Wizard Steps

**Step indicator at top:**
```
┌─────────────────────────────────────────────┐
│ ① ─── ② ─── ③ ─── ④ ─── ⑤ ─── ⑥ ─── ⑦    │
│ Org   Contact Admin  Config  Tools  Agent  Review│
└─────────────────────────────────────────────┘
```

---

### Step 1: Organization Details

```
┌─────────────────────────────────────────┐
│ Step 1 of 7: Organization Details       │
│                                         │
│ Organization Name: [________________]   │
│ Organization Type: [Dealership ▼]       │
│   Options: Dealership, Dealer Group,    │
│            Service Center, Other        │
│                                         │
│ Business Phone:    [________________]   │
│ Business Email:    [________________]   │
│ Website:           [________________]   │
│                                         │
│ ── OR ──                                │
│ [Apply Template ▼]                      │
│   Options: Standard Dealership,         │
│            Multi-Location Group,        │
│            Service Center,              │
│            Custom (blank)               │
│                                         │
│ [Cancel]                    [Next →]    │
└─────────────────────────────────────────┘
```

---

### Step 2: Primary Contact

```
┌─────────────────────────────────────────┐
│ Step 2 of 7: Primary Contact            │
│                                         │
│ First Name:  [________________]         │
│ Last Name:   [________________]         │
│ Email:       [________________]         │
│ Phone:       [________________]         │
│                                         │
│ Role: Org Admin (auto-assigned)         │
│                                         │
│ [← Back]                    [Next →]    │
└─────────────────────────────────────────┘
```

---

### Step 3: Admin Account Setup

```
┌─────────────────────────────────────────┐
│ Step 3 of 7: Admin Account              │
│                                         │
│ Username:    [________________]         │
│ Temp Password: [auto-generated]         │
│ ☑ Send welcome email with credentials  │
│                                         │
│ Additional Users (optional):            │
│ [+ Add Staff User]                      │
│                                         │
│ [← Back]                    [Next →]    │
└─────────────────────────────────────────┘
```

---

### Step 4: Configuration

```
┌─────────────────────────────────────────┐
│ Step 4 of 7: Configuration              │
│                                         │
│ Timezone:     [America/New_York ▼]      │
│ Currency:     [USD ▼]                   │
│ Language:     [English ▼]               │
│                                         │
│ Business Hours:                         │
│ Mon-Fri: [9:00 AM] to [6:00 PM]        │
│ Sat:     [9:00 AM] to [3:00 PM]        │
│ Sun:     [Closed]                       │
│                                         │
│ [← Back]                    [Next →]    │
└─────────────────────────────────────────┘
```

---

### Step 5: Tools & Integrations

```
┌─────────────────────────────────────────┐
│ Step 5 of 7: Tools                      │
│                                         │
│ Enable tools for this organization:     │
│                                         │
│ ☑ SMS & Text Sending (TextMagic)       │
│ ☑ Document Generator                   │
│ ☐ CRM Integration (coming soon)        │
│ ☐ Voice Calling (coming soon)          │
│ ☐ Video Calling (coming soon)          │
│                                         │
│ Only enabled tools are shown. Others    │
│ will be available as they are activated │
│ at the system level.                    │
│                                         │
│ [← Back]                    [Next →]    │
└─────────────────────────────────────────┘
```

---

### Step 6: Default Agent

```
┌─────────────────────────────────────────┐
│ Step 6 of 7: Default Agent              │
│                                         │
│ Create a default communications agent:  │
│                                         │
│ Agent Name:    [________________]       │
│ (This name appears on all channels:     │
│  chat widget, SMS, voice, video)        │
│                                         │
│ Default Skills:                         │
│ ☑ Lead Qualifier                       │
│ ☑ Email Responder                      │
│ ☑ Follow-Up Sequencer                  │
│ ☐ Payment Calculator                   │
│ ☐ ... (scrollable skill list)          │
│                                         │
│ [← Back]                    [Next →]    │
└─────────────────────────────────────────┘
```

---

### Step 7: Review & Create

```
┌─────────────────────────────────────────┐
│ Step 7 of 7: Review                     │
│                                         │
│ Organization: Serra Honda of Columbia   │
│ Type: Dealership                        │
│ Contact: John Smith (john@serra.com)    │
│ Admin: john@serra.com (Org Admin)       │
│ Timezone: America/New_York              │
│ Tools: SMS, Document Generator          │
│ Agent: "Sarah" (3 skills assigned)      │
│                                         │
│ ─────────────────────────────────────── │
│ Billing (optional):                     │
│ ☐ Enable billing for this org          │
│   Anniversary Date: [________________] │
│   Base Monthly Fee: [$________]        │
│   Setup Fee: [$________]               │
│                                         │
│ [← Back]           [Create Organization]│
└─────────────────────────────────────────┘
```

---

## 16. Skills Catalog

These are the 74 pre-built skills from V1. They appear in:
- **AI Configuration > Skills tab** (system-wide management)
- **Agent Config Pane > Tools & Skills** (per-agent assignment)
- **Org Creation Wizard > Step 6** (default agent setup)
- **Agent Create page** (skill selection during creation)

### Sales Skills (20)

| # | ID | Name | Description |
|---|-----|------|-------------|
| 1 | lead-qualifier | Lead Qualifier | Qualify incoming leads based on budget, timeline, and vehicle preferences |
| 2 | payment-calculator | Payment Calculator | Calculate monthly payments with various down payment and term options |
| 3 | inventory-optimizer | Inventory Optimizer | Match customer preferences with available inventory |
| 4 | trade-in-valuator | Trade-In Valuator | Estimate trade-in values based on vehicle details and market conditions |
| 5 | competitor-analyzer | Competitor Analyzer | Analyze competitor pricing and market positioning |
| 6 | objection-handler | Objection Handler | Provide strategies for handling common customer objections |
| 7 | test-drive-scheduler | Test Drive Scheduler | Optimize test drive scheduling and preparation |
| 8 | email-responder | Email Responder | Generate personalized email responses to customer inquiries |
| 9 | upsell-recommender | Upsell Recommender | Identify upsell opportunities for vehicle upgrades and add-ons |
| 10 | lease-vs-buy-advisor | Lease vs Buy Advisor | Compare leasing and buying options for customer situations |
| 11 | referral-generator | Referral Generator | Create referral programs and customer advocacy strategies |
| 12 | follow-up-sequencer | Follow-Up Sequencer | Design optimal follow-up sequences for different lead types |
| 13 | sales-script-writer | Sales Script Writer | Generate effective sales scripts and talk tracks |
| 14 | vehicle-presenter | Vehicle Presenter | Create compelling vehicle presentations highlighting key features |
| 15 | closing-strategist | Closing Strategist | Develop closing strategies based on customer buying signals |
| 16 | demo-route-planner | Demo Route Planner | Plan optimal test drive routes to showcase vehicle capabilities |
| 17 | incentive-tracker | Incentive Tracker | Track and communicate manufacturer incentives and rebates |
| 18 | social-media-generator | Social Media Generator | Create social media content to showcase inventory and promotions |
| 19 | sales-forecaster | Sales Forecaster | Forecast sales based on pipeline and historical trends |
| 20 | pipeline-optimizer | Pipeline Optimizer | Optimize sales pipeline and identify bottlenecks |

### Finance Skills (20)

| # | ID | Name | Description |
|---|-----|------|-------------|
| 1 | deal-structurer | Deal Structurer | Structure optimal financing deals based on customer credit and preferences |
| 2 | credit-analyzer | Credit Analyzer | Analyze credit reports and predict financing approval odds |
| 3 | lender-matcher | Lender Matcher | Match customers with optimal lenders based on credit profile |
| 4 | fi-product-recommender | F&I Product Recommender | Recommend finance and insurance products based on customer needs |
| 5 | rate-optimizer | Rate Optimizer | Find best interest rates across lender network |
| 6 | compliance-checker | Compliance Checker | Ensure financing deals meet regulatory compliance requirements |
| 7 | lease-structurer | Lease Structurer | Structure lease deals with optimal terms and residuals |
| 8 | payment-optimizer | Payment Optimizer | Optimize payment structures to meet customer budget constraints |
| 9 | warranty-calculator | Warranty Calculator | Calculate warranty costs and coverage comparisons |
| 10 | stipulation-manager | Stipulation Manager | Track and manage financing stipulations and document requirements |
| 11 | gap-calculator | GAP Calculator | Calculate GAP insurance value based on depreciation and loan terms |
| 12 | balloon-payment-planner | Balloon Payment Planner | Structure and explain balloon payment financing options |
| 13 | rebate-maximizer | Rebate Maximizer | Maximize customer rebates and incentive stacking |
| 14 | insurance-estimator | Insurance Estimator | Estimate insurance costs for financing qualification |
| 15 | fi-menu-builder | F&I Menu Builder | Build compliant F&I product menus with tiered options |
| 16 | early-payoff-calculator | Early Payoff Calculator | Calculate early payoff amounts and savings |
| 17 | tax-advisor | Tax Advisor | Provide guidance on tax implications of vehicle purchases |
| 18 | funding-tracker | Funding Tracker | Track deal funding status and identify delays |
| 19 | reserve-calculator | Reserve Calculator | Calculate dealership finance reserves and profitability |
| 20 | chargeback-preventer | Chargeback Preventer | Identify and prevent potential finance chargebacks |

### Operations Skills (20)

| # | ID | Name | Description |
|---|-----|------|-------------|
| 1 | service-scheduler | Service Scheduler | Optimize service department scheduling and capacity planning |
| 2 | parts-inventory-manager | Parts Inventory Manager | Manage parts inventory levels and ordering |
| 3 | workflow-optimizer | Workflow Optimizer | Optimize dealership workflows and reduce bottlenecks |
| 4 | technician-dispatcher | Technician Dispatcher | Dispatch service work to technicians based on skills and availability |
| 5 | recall-manager | Recall Manager | Track and manage vehicle recalls and safety campaigns |
| 6 | warranty-claim-processor | Warranty Claim Processor | Process warranty claims and maximize approval rates |
| 7 | reconditioning-planner | Reconditioning Planner | Plan vehicle reconditioning to optimize time and cost |
| 8 | loaner-fleet-manager | Loaner Fleet Manager | Manage loaner vehicle fleet availability and assignments |
| 9 | delivery-coordinator | Delivery Coordinator | Coordinate vehicle deliveries and customer handoffs |
| 10 | transport-scheduler | Transport Scheduler | Schedule vehicle transport and logistics |
| 11 | detail-queue-manager | Detail Queue Manager | Manage vehicle detailing queue and priorities |
| 12 | safety-auditor | Safety Auditor | Audit dealership safety procedures and compliance |
| 13 | equipment-maintenance | Equipment Maintenance Tracker | Track and schedule equipment maintenance and calibration |
| 14 | vendor-manager | Vendor Manager | Manage vendor relationships and service quality |
| 15 | title-clerk-assistant | Title Clerk Assistant | Assist with title processing and DMV documentation |
| 16 | customer-pickup-coordinator | Customer Pickup Coordinator | Coordinate customer vehicle pickups and readiness checks |
| 17 | facility-manager | Facility Manager | Manage facility maintenance and space utilization |
| 18 | csi-analyzer | CSI Analyzer | Analyze customer satisfaction scores and identify improvements |
| 19 | kpi-dashboard | KPI Dashboard Generator | Generate operational KPI reports and dashboards |
| 20 | policy-generator | Policy Generator | Generate dealership policies and procedure documentation |

### General Skills (14)

| # | ID | Name | Description |
|---|-----|------|-------------|
| 1 | data-intelligence | Data Intelligence | Analyze dealership data with visualizations and insights from multiple sources |
| 2 | ai-chat | AI Chat | General purpose AI assistant for dealership questions and tasks |
| 3 | doc-generator | Document Generator | Generate professional documents, letters, and forms |
| 4 | communication-assistant | Communication Assistant | Draft professional communications and customer messages |
| 5 | research-assistant | Research Assistant | Conduct research and compile information on any topic |
| 6 | meeting-note-taker | Meeting Note Taker | Summarize meetings and create action items |
| 7 | training-creator | Training Creator | Create training materials and onboarding content |
| 8 | calculator-pro | Calculator Pro | Perform complex calculations and financial modeling |
| 9 | translator | Translator | Translate text between languages for customer communications |
| 10 | summarizer | Summarizer | Summarize long documents and extract key points |
| 11 | code-helper | Code Helper | Help with code, scripts, and technical automation |
| 12 | content-writer | Content Writer | Write marketing content, blog posts, and web copy |
| 13 | proofreader | Proofreader | Proofread and improve writing quality |
| 14 | brainstorm-partner | Brainstorm Partner | Facilitate brainstorming and creative problem solving |

**Total: 74 skills (20 Sales + 20 Finance + 20 Operations + 14 General)**

---

## 17. Hunch Configuration Popout (NEW)

### Scope Clarification — Two Hunch Settings, Two Scopes

There are **two separate** hunch configuration UIs. They are NOT duplicates — they control different scopes:

| UI Location | Scope | Who Can Access | What It Controls |
|-------------|-------|----------------|------------------|
| **Settings > AI Configuration > Hunches tab** (Section 6, Tab 4) | **System-wide** | Super Admin (edit), Partner Admin (read-only) | Enable/disable hunches globally, daily digest, auto-scoring defaults, confidence threshold defaults |
| **Insights > Hunches page > Right-side popout** (this section) | **Per-user** | All roles that can see Hunches | Personal hunch preferences: which categories to show, notification preferences, personal confidence filter |

The system-wide settings (AI Config) set the global defaults and boundaries. The per-user settings (this popout) let individual users customize their hunch experience within those boundaries.

**Location:** On the Hunches page (Insights > Hunches tab), the right-side popout (same pattern as Agent Config Pane) should have a configuration section.

```
┌─────────────────────────────────────────┐
│ Hunch Settings                          │
│ (right-side popout on Hunches page)     │
│                                         │
│ User-Level Configuration:               │
│                                         │
│ Show Hunches:      [ON/OFF]             │
│ Notification:      [ON/OFF]             │
│ Categories:                             │
│   ☑ Opportunities (green)              │
│   ☑ Threats (red)                      │
│   ☑ Insights (blue)                    │
│                                         │
│ Min Confidence:    [50%]                │
│                                         │
│ ─────────────────────────────────────── │
│ Hunch Types Legend:                      │
│ 🟢 Opportunity — Revenue potential      │
│ 🔴 Threat — Risk that needs attention   │
│ 🔵 Insight — Pattern worth knowing      │
└─────────────────────────────────────────┘
```

---

## 18. Grayed Out Items Reference

Complete list of all items that should appear grayed out (visible but non-interactive, showing default values):

| Location | Item | Default Value |
|----------|------|---------------|
| Knowledge > Settings | Learning Mode | ON |
| AI Config > Hunches | Auto-Scoring | ON |
| AI Config > Hunches | Confidence Threshold | 70% |
| AI Config > Hunches | Temperature per Org | 0.5 |
| Security & Privacy | Two-Factor Auth | ON |
| Security & Privacy | SSO Provider | ON |
| Security & Privacy | Session Timeout | 60 min |
| Security & Privacy | IP Allowlist | ON |
| Security & Privacy | Audit Logging | ON |
| Data Management > Health | Auto-Backup | ON |
| Data Management > Health | Data Retention | 12 months |
| Data Management > Health | Export Format | CSV |
| Data Management > Health | GDPR Compliance | ON |
| Data Management > Uploads | SOC2 / Compliance | ON |
| Tools > MCP | All MCP tools | OFF (no tools yet) |
| Tools > API | VIN Solutions toggle | OFF, locked |
| Tools > API | VAPI toggle | OFF, locked |
| Tools > API | Tavus toggle | OFF, locked |
| Tools > API | Google Auth toggle | OFF, locked |
| Tools > Other | Tool Instructions | placeholder |
| Knowledge > Databases | Database connections | placeholder |

**Grayed out means:** The element is visible, shows its default value, but the toggle/input cannot be interacted with. The visual treatment should make it obvious the item is not yet active (reduced opacity, no hover effects, tooltip: "Coming soon" or similar).

---

## 19. RBAC Visibility Matrix

### Settings Tiles

| Tile | Super Admin | Partner Admin | Org Admin | Staff |
|------|:-----------:|:------------:|:---------:|:-----:|
| User Management | Full + Org Wizard | Users in assigned orgs | Users in own org | -- |
| Organization | All orgs | Assigned orgs | Own org | -- |
| Tools (MCP/API/Other) | Full + Economy + Technical names | Toggle only + Friendly names | Toggle only + Friendly names | -- |
| Tools (Widgets) | Full CRUD | Full CRUD | Full CRUD | -- |
| Tools (Landing Pages) | Full CRUD | Full CRUD | Full CRUD | -- |
| Tools (API Keys) | Full | -- | -- | -- |
| Tools (Webhooks) | Full | -- | -- | -- |
| Knowledge Base | Full | Full | Full | -- |
| AI Config (System Prompt) | Edit | View | -- | -- |
| AI Config (Agent Behavior) | Edit | View | -- | -- |
| AI Config (Skills) | Full + Kill Switch | -- | -- | -- |
| AI Config (Hunches) | Edit | View | -- | -- |
| Security & Privacy | View (grayed) | View (grayed) | -- | -- |
| Notifications | Full | Full | Full | -- |
| Data Management | Full | -- | -- | -- |
| Appearance | Full | Full | Full | -- |

### Billing

| View | Super Admin | Partner Admin | Org Admin | Staff |
|------|:-----------:|:------------:|:---------:|:-----:|
| Revenue Dashboard | Full | Assigned orgs only | -- | -- |
| Billing Config | Edit all orgs | View assigned orgs | -- | -- |
| Invoice Builder | Send to any org | Send to assigned orgs | -- | -- |
| Org Billing Page | View all | View assigned | View own (read-only) | View own (read-only) |

### Tool Names

| Role | Sees Technical Name? | Sees Friendly Name? |
|------|:-------------------:|:-------------------:|
| Super Admin | Yes | Yes |
| Partner Admin | No | Yes |
| Org Admin | No | Yes |
| Staff | No | Yes |

---

## APPENDIX A: What Stays The Same

These elements are UNCHANGED and should NOT be modified:

1. **Sidebar** — 7 items (Main, Insights, Agents, Hub, Drive, System, Logout)
2. **Top Bar** — Logo, org switcher, notifications, activity, theme, profile
3. **Hub tabs** — Calendar, Leads, Inbox (3 tabs — confirmed)
4. **Insights tabs** — Dashboard, Reports, Library, Hunches (4 tabs)
5. **Metric tiles** — 2x2 grid per role, collapsible
6. **Agent Config Pane** — 6 sections (with modifications noted in Section 12)
7. **Chat interface** — No avatars, rounded-2xl bubbles, ThinkingCard, wave-dots
8. **Right Pane (Automa)** — "Ask Automa anything..." with gradient input
9. **Drive** — File/folder CRUD, grid/list view (with sharing additions in Section 14)
10. **Widget system** — All 6 channels, widget CRUD
11. **Color scheme** — HSL-based theme contract
12. **Typography** — System font stack
13. **Icons** — Lucide icon set

---

## APPENDIX B: Mock Data Values for Designer

Use these values when creating mock UI states:

**Billing:**
- Org name: "Serra Honda of Columbia"
- Base fee: $99/month
- Voice usage: 847 / 1,000 minutes
- Video usage: 123 / 500 minutes
- SMS: 2,340 messages
- Overage: $12.50
- MRR (admin view): $12,450
- Active accounts: 24

**Tools:**
- TextMagic: Enabled, friendly name "SMS & Text Sending"
- Document Generator: Enabled
- All others: Grayed out, disabled

**Skills:**
- 74 total across 4 categories
- Show 5-8 in any list view, with scroll for more

**Data Health:**
- Total records: 14,892
- Storage: 2.3 GB
- Active uploads: 8

**Knowledge:**
- 3 document sources shown
- 1 web page source shown

---

## APPENDIX C: Implementation Notes for Development

These notes are for the development team, not the designer, but are included for completeness:

1. **Billing has NO payment processing.** No Stripe, no credit cards. It is data tracking and invoice generation only.
2. **Grayed out items store their default values** in the database but do not trigger any backend behavior.
3. **Skills are prompts.** Each skill is stored as: id, name, category, description, systemPrompt, tools[], temperature. The "+ New Skill" flow creates a new entry in the same structure.
4. **Tool economy** rate changes only apply in the next billing period — the backend must track effective dates.
5. **Anniversary billing** means each org's billing cycle starts on their sign-up date, not calendar month boundaries.
6. **Proration** is calculated when billing is enabled mid-cycle: `(remaining_days / total_days) * monthly_fee`.

---

**END OF DESIGNER UPDATE SPEC**

**Next step:** Owner gives this to the designer. Designer updates the Replit reference app. Development implements from the updated reference.
