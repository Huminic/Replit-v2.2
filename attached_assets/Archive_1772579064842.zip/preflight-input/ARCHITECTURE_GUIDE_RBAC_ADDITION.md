# RBAC Addition for ARCHITECTURE_GUIDE.md

Add this section after the Partner Admin Constraints section (around line 1943):

---

## Partner Entity Model

Partners are organizations that manage multiple dealership locations.

### Database Schema

```sql
CREATE TABLE partners (
  id UUID PRIMARY KEY,
  name VARCHAR(255) UNIQUE,
  contact_email VARCHAR(255),
  settings JSONB,
  credit_pool DECIMAL, -- Partner-level credit allocation
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Users belong to partners
ALTER TABLE users ADD COLUMN partner_id UUID REFERENCES partners(id);

-- Partner to org assignments
CREATE TABLE partner_org_assignments (
  partner_id UUID REFERENCES partners(id),
  organization_id UUID REFERENCES organizations(id),
  assigned_by UUID REFERENCES users(id), -- Super Admin who assigned
  assigned_at TIMESTAMPTZ DEFAULT now(),
  PRIMARY KEY (partner_id, organization_id)
);

-- Multi-org user assignments
CREATE TABLE user_org_assignments (
  user_id UUID REFERENCES users(id),
  organization_id UUID REFERENCES organizations(id),
  role VARCHAR(50), -- Can vary per org
  assigned_at TIMESTAMPTZ DEFAULT now(),
  PRIMARY KEY (user_id, organization_id)
);
```

### RLS Policies

```sql
-- Partner isolation
CREATE POLICY "partner_admin_org_access" ON organizations
  FOR SELECT USING (
    (auth.jwt() ->> 'role') = 'super_admin'
    OR
    (
      (auth.jwt() ->> 'role') = 'partner_admin'
      AND id IN (
        SELECT organization_id FROM partner_org_assignments
        WHERE partner_id = (auth.jwt() ->> 'partner_id')::uuid
      )
    )
    OR
    (auth.jwt() ->> 'organization_id')::uuid = id
  );
```

### Tool Provisioning Flow

```
Super Admin → Provisions tools → Partner Admin → Manages orgs → Org Admin → Uses tools
```

**Rationale:**
- Super Admin controls all tool provisioning (VIN Solutions, VAPI, Tavus)
- Tools are "pushed down" to organizations by Super Admin
- Partner Admin can view tool usage but cannot configure tools
- Org Admin uses pre-provisioned tools (credentials encrypted)
- Centralized control ensures security, billing compliance, and quality

