# Nexxus Agentic Architecture - Visual Map

**Document Version:** 1.0
**Date:** January 20, 2026
**Status:** Reference Guide
**Classification:** Internal

---

## Table of Contents

1. [System Overview (7-Layer Architecture)](#1-system-overview-7-layer-architecture)
2. [Data Flow Architecture](#2-data-flow-architecture)
3. [Agent Interaction Patterns](#3-agent-interaction-patterns)
4. [Memory Tier Architecture](#4-memory-tier-architecture)
5. [Integration Architecture](#5-integration-architecture)
6. [Coordination Layer Detail](#6-coordination-layer-detail)
7. [User Journey Maps](#7-user-journey-maps)
8. [Deployment Architecture](#8-deployment-architecture)

---

## 1. System Overview (7-Layer Architecture)

### Complete Stack Visualization

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        LAYER 1: USER INTERFACE                          │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │  Next.js 14 App Router + TypeScript + Tailwind CSS               │  │
│  │                                                                   │  │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐           │  │
│  │  │   Top Bar    │  │ Left Sidebar │  │Right Sidebar │           │  │
│  │  │ ─────────────│  │ ────────────│  │ ────────────│           │  │
│  │  │ Org Switcher │  │  Dashboard   │  │  DealerBrain │           │  │
│  │  │   Search     │  │  Agents      │  │   (⌘K Chat)  │           │  │
│  │  │   Alerts     │  │  Customers   │  │              │           │  │
│  │  │   Profile    │  │  Reports     │  │              │           │  │
│  │  └──────────────┘  └──────────────┘  └──────────────┘           │  │
│  │                                                                   │  │
│  │  State: Zustand + React Query                                    │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                   LAYER 2: SYSTEM ASSISTANT (Tier 0)                    │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │                      Daria (System Agent)                         │  │
│  │  ┌─────────────────────────────────────────────────────────────┐ │  │
│  │  │  Role: Omniscient Observer & Configuration Manager          │ │  │
│  │  │                                                              │ │  │
│  │  │  Capabilities:                                               │ │  │
│  │  │  ✓ Parse NLP intents from users                             │ │  │
│  │  │  ✓ Monitor all activity streams (WebSocket)                 │ │  │
│  │  │  ✓ Manage system configuration (agents, settings)           │ │  │
│  │  │  ✓ Generate hunches (pattern recognition)                   │ │  │
│  │  │  ✓ Summarize dealership activity                            │ │  │
│  │  │                                                              │ │  │
│  │  │  Memory Access: READ all tiers, WRITE long-term             │ │  │
│  │  │  Tools: */read*, supabase/*, system/*                       │ │  │
│  │  └─────────────────────────────────────────────────────────────┘ │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                   LAYER 3: COORDINATION (Tier 1)                        │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │  ┌──────────────────┐  ┌──────────────────┐  ┌────────────────┐ │  │
│  │  │ Context Router   │  │  Orchestrator    │  │   Operator     │ │  │
│  │  │ ────────────────│  │ ────────────────│  │ ──────────────│ │  │
│  │  │ • Intent         │  │ • Multi-step     │  │ • Write        │ │  │
│  │  │   classification │  │   workflows      │  │   approval     │ │  │
│  │  │ • Entity         │  │ • Task           │  │ • Risk         │ │  │
│  │  │   resolution     │  │   decomposition  │  │   assessment   │ │  │
│  │  │ • Agent          │  │ • Parallel       │  │ • Approval     │ │  │
│  │  │   selection      │  │   execution      │  │   queue        │ │  │
│  │  │ • Context        │  │ • Result         │  │ • Policy       │ │  │
│  │  │   loading        │  │   synthesis      │  │   enforcement  │ │  │
│  │  └──────────────────┘  └──────────────────┘  └────────────────┘ │  │
│  │                                                                   │  │
│  │  Memory Access: READ short-term + long-term, WRITE working       │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌─────────────────────────────────────────────────────────────────────────┐
│               LAYER 4: SPECIALIZED AGENTS (Tier 2)                      │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐            │  │
│  │  │ AutoDealer   │  │ ConvoAgent   │  │ InsightAgent │            │  │
│  │  │ (Automotive) │  │ (Comms)      │  │ (Analytics)  │            │  │
│  │  │──────────────│  │──────────────│  │──────────────│            │  │
│  │  │              │  │              │  │              │            │  │
│  │  │ Tools:       │  │ Tools:       │  │ Tools:       │            │  │
│  │  │ • vin/*      │  │ • vapi/*     │  │ • clickhouse │            │  │
│  │  │              │  │ • tavus/*    │  │   /query     │            │  │
│  │  │              │  │ • twilio/*   │  │ • cubejs/*   │            │  │
│  │  │              │  │ • sendgrid/* │  │ • dashboard/*│            │  │
│  │  │              │  │              │  │              │            │  │
│  │  │ Domain:      │  │ Domain:      │  │ Domain:      │            │  │
│  │  │ VIN CRM      │  │ Voice/Video  │  │ Reporting &  │            │  │
│  │  │ operations   │  │ customer     │  │ business     │            │  │
│  │  │              │  │ communication│  │ intelligence │            │  │
│  │  │              │  │              │  │              │            │  │
│  │  │ Skills:      │  │ Skills:      │  │ Skills:      │            │  │
│  │  │ • Schedule   │  │ • Make call  │  │ • Generate   │            │  │
│  │  │   test drive │  │ • Start video│  │   report     │            │  │
│  │  │ • Update     │  │ • Send SMS   │  │ • Analyze    │            │  │
│  │  │   customer   │  │ • Email      │  │   metrics    │            │  │
│  │  │ • Sync data  │  │   reminder   │  │ • Predict    │            │  │
│  │  │              │  │              │  │   lead quality│           │  │
│  │  └──────────────┘  └──────────────┘  └──────────────┘            │  │
│  │                                                                   │  │
│  │  Memory Access: READ short-term + working (scoped), READ long-term│ │
│  └───────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                      LAYER 5: MCP GATEWAY                               │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │                     MCP Proxy Server (Port 3010)                  │  │
│  │  ┌─────────────────────────────────────────────────────────────┐ │  │
│  │  │                                                              │ │  │
│  │  │  Request Flow:                                               │ │  │
│  │  │  Agent → MCP Proxy → Permission Check → Tool Execution      │ │  │
│  │  │                                                              │ │  │
│  │  │  Permission Enforcement:                                     │ │  │
│  │  │  ✓ Agent authentication (X-Agent-Id header)                 │ │  │
│  │  │  ✓ Tool authorization (agent-permissions.yaml)              │ │  │
│  │  │  ✓ Data filtering (entity-scoped, domain-scoped)            │ │  │
│  │  │  ✓ Rate limiting (200-1000 req/hour per agent)              │ │  │
│  │  │  ✓ Activity logging (audit trail)                           │ │  │
│  │  │                                                              │ │  │
│  │  │  Tool Registry (mcp_tools table):                           │ │  │
│  │  │  • Tool name (vin/get_customer)                             │ │  │
│  │  │  • Risk tier (low/medium/high)                              │ │  │
│  │  │  • Tier access permissions ([0, 1, 2])                      │ │  │
│  │  │  • Approval requirement flag                                │ │  │
│  │  └─────────────────────────────────────────────────────────────┘ │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                   LAYER 6: MEMORY & STORAGE                             │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐         │  │
│  │  │  Tier 0  │  │  Tier 1  │  │  Tier 2  │  │  Tier 3  │         │  │
│  │  │  System  │  │  Short   │  │  Working │  │   Long   │         │  │
│  │  │  State   │  │   Term   │  │          │  │   Term   │         │  │
│  │  │──────────│  │──────────│  │──────────│  │──────────│         │  │
│  │  │          │  │          │  │          │  │          │         │  │
│  │  │ Postgres │  │  Redis   │  │ Postgres │  │ pgvector │         │  │
│  │  │          │  │          │  │          │  │          │         │  │
│  │  │ Orgs     │  │ Sessions │  │ Execution│  │ Customer │         │  │
│  │  │ Locations│  │ Conv ctx │  │   state  │  │   prefs  │         │  │
│  │  │ Users    │  │ Hot data │  │ Tasks    │  │ Patterns │         │  │
│  │  │ Roles    │  │          │  │          │  │ Insights │         │  │
│  │  │          │  │          │  │          │  │          │         │  │
│  │  │ Permanent│  │ 1-24h TTL│  │ 7-30d TTL│  │ Permanent│         │  │
│  │  │          │  │          │  │          │  │          │         │  │
│  │  │ RLS      │  │ Fast     │  │ Auto     │  │ Semantic │         │  │
│  │  │ enforced │  │ access   │  │ cleanup  │  │  search  │         │  │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘         │  │
│  │                                                                   │  │
│  │  Activity Events: Causal chains, reversibility, agent tracking   │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                    LAYER 7: DATA WAREHOUSE                              │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │  ┌──────────────────────────┐  ┌──────────────────────────────┐  │  │
│  │  │   OLTP (Operational)     │  │   OLAP (Analytics)           │  │  │
│  │  │   Supabase PostgreSQL    │  │   ClickHouse                 │  │  │
│  │  │──────────────────────────│  │──────────────────────────────│  │  │
│  │  │                          │  │                              │  │  │
│  │  │ Purpose:                 │  │ Purpose:                     │  │  │
│  │  │ • Real-time transactions │  │ • Historical analytics       │  │  │
│  │  │ • User-facing queries    │  │ • Reporting dashboards       │  │  │
│  │  │ • Hot data (90 days)     │  │ • All-time data              │  │  │
│  │  │                          │  │                              │  │  │
│  │  │ Optimization:            │  │ Optimization:                │  │  │
│  │  │ • Write-optimized        │  │ • Read-optimized             │  │  │
│  │  │ • ACID transactions      │  │ • Columnar storage           │  │  │
│  │  │ • Row-based storage      │  │ • Materialized views         │  │  │
│  │  │ • Real-time subscriptions│  │ • Time-series partitioning   │  │  │
│  │  │                          │  │                              │  │  │
│  │  │ Examples:                │  │ Examples:                    │  │  │
│  │  │ • Active conversations   │  │ • 90-day sales reports       │  │  │
│  │  │ • Upcoming appointments  │  │ • 1-year trend analysis      │  │  │
│  │  │ • Current credit balance │  │ • Cross-source aggregation   │  │  │
│  │  └──────────────────────────┘  └──────────────────────────────┘  │  │
│  │                                                                   │  │
│  │  ETL Pipeline: Airbyte → dbt → ClickHouse (every 15 minutes)     │  │
│  │  Semantic Layer: Cube.js (business metrics API)                  │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                      EXTERNAL INTEGRATIONS                              │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐            │  │
│  │  │VIN Solutions │  │    VAPI      │  │    Tavus     │            │  │
│  │  │    (CRM)     │  │   (Voice)    │  │   (Video)    │            │  │
│  │  │──────────────│  │──────────────│  │──────────────│            │  │
│  │  │ OAuth 2.0    │  │ Bearer Token │  │ API Key      │            │  │
│  │  │ Webhooks     │  │ Webhooks     │  │ Callbacks    │            │  │
│  │  │ Production   │  │ Real-time    │  │ Interactive  │            │  │
│  │  │ Certified    │  │ Voice AI     │  │ Video AI     │            │  │
│  │  └──────────────┘  └──────────────┘  └──────────────┘            │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Data Flow Architecture

### Request Flow: User → Agent → Tool → Response

```
┌──────────────────────────────────────────────────────────────────────────┐
│                          USER INTERACTION                                │
└──────────────────────────────────────────────────────────────────────────┘
                                    ↓
                    User types in DealerBrain (⌘K):
                    "Schedule test drive for John Doe tomorrow at 2pm"
                                    ↓
┌──────────────────────────────────────────────────────────────────────────┐
│                         LAYER 2: SYSTEM ASSISTANT                        │
│  ┌────────────────────────────────────────────────────────────────────┐  │
│  │  Daria receives intent, parses NLP:                                │  │
│  │  • Entity: Customer "John Doe"                                     │  │
│  │  • Action: "Schedule test drive"                                   │  │
│  │  • Time: "tomorrow at 2pm"                                         │  │
│  │                                                                    │  │
│  │  Routes to Context Router ──────────────────────────────────────► │  │
│  └────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌──────────────────────────────────────────────────────────────────────────┐
│                      LAYER 3: COORDINATION LAYER                         │
│  ┌────────────────────────────────────────────────────────────────────┐  │
│  │  CONTEXT ROUTER:                                                   │  │
│  │  ┌──────────────────────────────────────────────────────────────┐ │  │
│  │  │ 1. Classify Domain: "automotive" (VIN operation)             │ │  │
│  │  │ 2. Extract Entities: customer_name="John Doe", time="2pm"   │ │  │
│  │  │ 3. Load Context:                                             │ │  │
│  │  │    • Short-term: Current conversation session                │ │  │
│  │  │    • Working: Recent customer interactions                   │ │  │
│  │  │    • Long-term: Customer preferences, dealership rules       │ │  │
│  │  │ 4. Select Agent: AutoDealer (domain: automotive)             │ │  │
│  │  │ 5. Decision: DIRECT (single-step task)                       │ │  │
│  │  └──────────────────────────────────────────────────────────────┘ │  │
│  │                                                                    │  │
│  │  Routing Decision: { type: 'direct', agent: 'auto_dealer' }       │  │
│  └────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌──────────────────────────────────────────────────────────────────────────┐
│                    LAYER 4: SPECIALIZED AGENT                            │
│  ┌────────────────────────────────────────────────────────────────────┐  │
│  │  AUTODEALER AGENT:                                                 │  │
│  │  ┌──────────────────────────────────────────────────────────────┐ │  │
│  │  │ Task: scheduleTestDrive()                                    │ │  │
│  │  │                                                              │ │  │
│  │  │ Step 1: Load customer from context                          │ │  │
│  │  │   → customer = { id: "c123", name: "John Doe", ... }        │ │  │
│  │  │                                                              │ │  │
│  │  │ Step 2: Call MCP tool: vin/get_inventory                    │ │  │
│  │  │   → Check vehicle availability                              │ │  │
│  │  │                                                              │ │  │
│  │  │ Step 3: Call MCP tool: vin/create_appointment               │ │  │
│  │  │   → Create appointment in VIN Solutions                     │ │  │
│  │  │                                                              │ │  │
│  │  │ Step 4: Store in working memory                             │ │  │
│  │  │   → { appointment_id, follow_up_needed: true }              │ │  │
│  │  └──────────────────────────────────────────────────────────────┘ │  │
│  └────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌──────────────────────────────────────────────────────────────────────────┐
│                        LAYER 5: MCP GATEWAY                              │
│  ┌────────────────────────────────────────────────────────────────────┐  │
│  │  MCP PROXY (for each tool call):                                   │  │
│  │  ┌──────────────────────────────────────────────────────────────┐ │  │
│  │  │ Tool Call: vin/create_appointment                            │ │  │
│  │  │                                                              │ │  │
│  │  │ 1. Authentication Check:                                     │ │  │
│  │  │    ✓ X-Agent-Id: auto_dealer (valid)                        │ │  │
│  │  │                                                              │ │  │
│  │  │ 2. Permission Check:                                         │ │  │
│  │  │    ✓ auto_dealer.allowed_tools includes "vin/*"             │ │  │
│  │  │    ✓ Permission GRANTED                                     │ │  │
│  │  │                                                              │ │  │
│  │  │ 3. Data Filtering:                                           │ │  │
│  │  │    ✓ Add organization_id filter (entity-scoped)             │ │  │
│  │  │                                                              │ │  │
│  │  │ 4. Rate Limit Check:                                         │ │  │
│  │  │    ✓ auto_dealer: 150/200 requests used (OK)                │ │  │
│  │  │                                                              │ │  │
│  │  │ 5. Forward to VIN MCP Server:                                │ │  │
│  │  │    → POST http://localhost:3011/vin/create_appointment      │ │  │
│  │  │                                                              │ │  │
│  │  │ 6. Log Activity:                                             │ │  │
│  │  │    → activity_events table (agent_id, tool, params, result) │ │  │
│  │  └──────────────────────────────────────────────────────────────┘ │  │
│  └────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌──────────────────────────────────────────────────────────────────────────┐
│                      EXTERNAL INTEGRATION                                │
│  ┌────────────────────────────────────────────────────────────────────┐  │
│  │  VIN SOLUTIONS API:                                                │  │
│  │  ┌──────────────────────────────────────────────────────────────┐ │  │
│  │  │ POST /api/appointments                                       │ │  │
│  │  │                                                              │ │  │
│  │  │ Request:                                                     │ │  │
│  │  │ {                                                            │ │  │
│  │  │   "customer_id": "c123",                                     │ │  │
│  │  │   "appointment_type": "test_drive",                          │ │  │
│  │  │   "scheduled_time": "2026-01-21T14:00:00Z"                   │ │  │
│  │  │ }                                                            │ │  │
│  │  │                                                              │ │  │
│  │  │ Response:                                                    │ │  │
│  │  │ {                                                            │ │  │
│  │  │   "appointment_id": "appt-789",                              │ │  │
│  │  │   "status": "scheduled",                                     │ │  │
│  │  │   "confirmation_sent": true                                  │ │  │
│  │  │ }                                                            │ │  │
│  │  └──────────────────────────────────────────────────────────────┘ │  │
│  └────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌──────────────────────────────────────────────────────────────────────────┐
│                      LAYER 6: MEMORY STORAGE                             │
│  ┌────────────────────────────────────────────────────────────────────┐  │
│  │  WORKING MEMORY (PostgreSQL):                                      │  │
│  │  ┌──────────────────────────────────────────────────────────────┐ │  │
│  │  │ INSERT INTO working_memory:                                  │ │  │
│  │  │ {                                                            │ │  │
│  │  │   user_id: "user-123",                                       │ │  │
│  │  │   session_id: "session-456",                                 │ │  │
│  │  │   agent_id: "auto_dealer",                                   │ │  │
│  │  │   memory_type: "execution_state",                            │ │  │
│  │  │   data: {                                                    │ │  │
│  │  │     appointment_id: "appt-789",                              │ │  │
│  │  │     customer_id: "c123",                                     │ │  │
│  │  │     follow_up_needed: true                                   │ │  │
│  │  │   },                                                         │ │  │
│  │  │   expires_at: "2026-01-27T14:00:00Z" (7 days)                │ │  │
│  │  │ }                                                            │ │  │
│  │  └──────────────────────────────────────────────────────────────┘ │  │
│  │                                                                    │  │
│  │  ACTIVITY EVENTS:                                                  │  │
│  │  ┌──────────────────────────────────────────────────────────────┐ │  │
│  │  │ {                                                            │ │  │
│  │  │   event_type: "agent_execution",                             │ │  │
│  │  │   agent_id: "auto_dealer",                                   │ │  │
│  │  │   user_id: "user-123",                                       │ │  │
│  │  │   data: { tool: "vin/create_appointment", ... },             │ │  │
│  │  │   causal_chain: [] (root event)                              │ │  │
│  │  │ }                                                            │ │  │
│  │  └──────────────────────────────────────────────────────────────┘ │  │
│  └────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌──────────────────────────────────────────────────────────────────────────┐
│                         RESPONSE TO USER                                 │
│  ┌────────────────────────────────────────────────────────────────────┐  │
│  │  DealerBrain shows in right sidebar:                               │  │
│  │                                                                    │  │
│  │  ✓ Test drive scheduled for John Doe                              │  │
│  │  📅 Tomorrow at 2:00 PM                                            │  │
│  │  🚗 Appointment ID: appt-789                                       │  │
│  │  ✉️ Confirmation sent to john.doe@email.com                       │  │
│  │                                                                    │  │
│  │  [Follow-up reminder scheduled]                                    │  │
│  └────────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────────┘
```

**Timeline:** Total request-to-response: **~2 seconds**

- NLP parsing: 200ms
- Context loading: 100ms
- Agent selection: 50ms
- Tool execution: 800ms (VIN API call)
- Memory storage: 100ms
- Response rendering: 50ms

---

## 3. Agent Interaction Patterns

### Pattern 1: Single-Agent Direct Execution

```
User Request: "What's the balance for customer John Doe?"

┌──────────┐
│   User   │
└────┬─────┘
     │
     ↓
┌────────────────┐
│  DealerBrain   │  (User-facing)
│   (⌘K Chat)    │
└────┬───────────┘
     │
     ↓
┌────────────────┐
│ Context Router │  "Simple query, automotive domain"
└────┬───────────┘
     │
     │ Decision: DIRECT
     ↓
┌────────────────┐
│  AutoDealer    │  "Calls vin/get_customer"
│     Agent      │
└────┬───────────┘
     │
     ↓
┌────────────────┐
│   MCP Proxy    │  Permission check → GRANTED
└────┬───────────┘
     │
     ↓
┌────────────────┐
│ VIN Solutions  │  Returns customer balance
│      API       │
└────┬───────────┘
     │
     ↓
┌────────────────┐
│  Response to   │  "John Doe's balance: $0"
│      User      │
└────────────────┘

Total Time: ~1 second
```

### Pattern 2: Multi-Agent Orchestrated Workflow

```
User Request: "Schedule appointment for Jane Smith and send her a confirmation email"

┌──────────┐
│   User   │
└────┬─────┘
     │
     ↓
┌────────────────┐
│  DealerBrain   │
└────┬───────────┘
     │
     ↓
┌────────────────────────────────────────────────────────────┐
│              Context Router                                │
│  "Multi-domain task: automotive (appointment) +           │
│   communication (email)"                                   │
│                                                            │
│  Decision: ORCHESTRATE                                     │
│  Agents: [auto_dealer, convo_agent]                        │
└────┬───────────────────────────────────────────────────────┘
     │
     ↓
┌──────────────────────────────────────────────────────────────┐
│                     Orchestrator                             │
│  ┌────────────────────────────────────────────────────────┐  │
│  │ Workflow Decomposition:                                │  │
│  │                                                        │  │
│  │ Step 1 (Sequential):                                   │  │
│  │   Agent: auto_dealer                                   │  │
│  │   Task: Create appointment                             │  │
│  │                                                        │  │
│  │ Step 2 (Sequential, depends on Step 1):                │  │
│  │   Agent: convo_agent                                   │  │
│  │   Task: Send confirmation email                        │  │
│  │   Input: appointment_id from Step 1                    │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
     │
     ├────────────────────────────────────────────────────────┐
     │                                                        │
     ↓ STEP 1                                          STEP 2 ↓
┌────────────────┐                                 ┌────────────────┐
│  AutoDealer    │  "Create appointment"           │  ConvoAgent    │
│     Agent      │  in VIN Solutions                │     Agent      │
└────┬───────────┘                                 └────┬───────────┘
     │                                                   │
     ↓                                                   ↓
┌────────────────┐                                 ┌────────────────┐
│   VIN API      │  Returns: appt-123              │  SendGrid API  │
└────┬───────────┘                                 └────┬───────────┘
     │                                                   │
     │  Result: { appointment_id: "appt-123" }          │
     │              ─────────────────────────────────────┤
     │                                                   │
     │                                            Email sent
     │                                                   │
     └────────────────────┬──────────────────────────────┘
                          │
                          ↓
                   ┌────────────────┐
                   │  Orchestrator  │  Synthesizes results
                   │   Synthesis    │
                   └────┬───────────┘
                        │
                        ↓
                   ┌────────────────┐
                   │  Response to   │  ✓ Appointment created
                   │      User      │  ✓ Email sent to jane@email.com
                   └────────────────┘

Total Time: ~3 seconds (sequential execution)
```

### Pattern 3: Write Approval Workflow (High-Risk Operation)

```
User Request: "Delete customer record for ID c-456"

┌──────────┐
│   User   │
└────┬─────┘
     │
     ↓
┌────────────────┐
│  DealerBrain   │
└────┬───────────┘
     │
     ↓
┌────────────────┐
│ Context Router │  Selects: AutoDealer
└────┬───────────┘
     │
     ↓
┌────────────────┐
│  AutoDealer    │  Attempts: vin/delete_customer
│     Agent      │
└────┬───────────┘
     │
     ↓
┌──────────────────────────────────────────────────────────────┐
│                       Operator                               │
│  ┌────────────────────────────────────────────────────────┐  │
│  │ Intercepts Write Operation                             │  │
│  │                                                        │  │
│  │ Risk Assessment:                                        │  │
│  │ • Operation: delete_customer                           │  │
│  │ • Tool pattern: "*delete*" → HIGH RISK                 │  │
│  │ • Requires approval: YES                               │  │
│  │                                                        │  │
│  │ Decision: QUEUE FOR APPROVAL                           │  │
│  └────────────────────────────────────────────────────────┘  │
└────┬───────────────────────────────────────────────────────────┘
     │
     ↓
┌──────────────────────────────────────────────────────────────┐
│              pending_approvals table                         │
│  {                                                           │
│    id: "approval-789",                                       │
│    operation: { tool: "vin/delete_customer", ... },          │
│    risk_tier: "high",                                        │
│    status: "PENDING",                                        │
│    explanation: "Deletion operations are irreversible"       │
│  }                                                           │
└────┬───────────────────────────────────────────────────────────┘
     │
     │ WebSocket notification
     ↓
┌──────────────────────────────────────────────────────────────┐
│              Manager Dashboard                               │
│  ┌────────────────────────────────────────────────────────┐  │
│  │ 🔔 APPROVAL REQUIRED                                   │  │
│  │                                                        │  │
│  │ Operation: Delete customer record c-456                │  │
│  │ Requested by: sales@dealership.com                     │  │
│  │ Risk: HIGH (irreversible)                              │  │
│  │                                                        │  │
│  │ [APPROVE]  [REJECT]                                    │  │
│  └────────────────────────────────────────────────────────┘  │
└────┬───────────────────────────────────────────────────────────┘
     │
     │ Manager clicks APPROVE
     ↓
┌──────────────────────────────────────────────────────────────┐
│              pending_approvals UPDATE                        │
│  {                                                           │
│    status: "APPROVED",                                       │
│    approved_by: "manager-123",                               │
│    approved_at: "2026-01-20T15:30:00Z"                       │
│  }                                                           │
└────┬───────────────────────────────────────────────────────────┘
     │
     ↓
┌────────────────┐
│    Operator    │  Executes approved operation
└────┬───────────┘
     │
     ↓
┌────────────────┐
│   VIN API      │  Customer record deleted
└────┬───────────┘
     │
     ↓
┌────────────────┐
│  Response to   │  ✓ Customer record c-456 deleted
│      User      │  ✓ Approved by: manager@dealership.com
└────────────────┘

Total Time: Variable (depends on manager response time)
Typical: 2-10 minutes
```

---

## 4. Memory Tier Architecture

### Memory Lifecycle and Access Patterns

```
┌─────────────────────────────────────────────────────────────────────────┐
│                        MEMORY TIER HIERARCHY                            │
└─────────────────────────────────────────────────────────────────────────┘

TIER 0: SYSTEM STATE (Permanent - Config-Driven)
┌─────────────────────────────────────────────────────────────────────────┐
│  PostgreSQL (Supabase)                                                  │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │  Tables: organizations, locations, users, roles, integrations     │  │
│  │                                                                   │  │
│  │  Characteristics:                                                 │  │
│  │  • Permanent (never expires)                                      │  │
│  │  • Row-level security (RLS) enforced                              │  │
│  │  • Multi-tenant isolation                                         │  │
│  │  • ACID transactions                                              │  │
│  │                                                                   │  │
│  │  Access:                                                          │  │
│  │  • All agents: READ (with RLS filtering)                          │  │
│  │  • System Assistant (Daria): READ + WRITE                         │  │
│  │  • Coordination layer: READ only                                  │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↓
TIER 1: SHORT-TERM MEMORY (Hot Data - 1-24 hour TTL)
┌─────────────────────────────────────────────────────────────────────────┐
│  Redis (In-Memory)                                                      │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │  Key Patterns:                                                    │  │
│  │  • session:{session_id}:messages → Conversation context          │  │
│  │  • user:{user_id}:active_tasks → Current tasks                   │  │
│  │  • dealership:{org_id}:hot_leads → Today's active leads          │  │
│  │                                                                   │  │
│  │  Characteristics:                                                 │  │
│  │  • Ultra-fast access (<5ms)                                       │  │
│  │  • Automatic TTL expiration                                       │  │
│  │  • Lost on restart (not persistent)                               │  │
│  │                                                                   │  │
│  │  TTL Strategy:                                                    │  │
│  │  • Active conversation: 1 hour                                    │  │
│  │  • Idle conversation: 6 hours                                     │  │
│  │  • Completed conversation: 24 hours                               │  │
│  │                                                                   │  │
│  │  Example Data:                                                    │  │
│  │  {                                                                │  │
│  │    session_id: "sess-123",                                        │  │
│  │    messages: [                                                    │  │
│  │      { role: "user", content: "Schedule test drive" },            │  │
│  │      { role: "assistant", content: "For which customer?" }        │  │
│  │    ],                                                             │  │
│  │    context: {                                                     │  │
│  │      current_customer: "John Doe",                                │  │
│  │      pending_action: "test_drive_scheduling"                      │  │
│  │    }                                                              │  │
│  │  }                                                                │  │
│  │                                                                   │  │
│  │  Access:                                                          │  │
│  │  • All agents: READ + WRITE (session-scoped)                      │  │
│  │  • Automatic cleanup via TTL                                      │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↓
TIER 2: WORKING MEMORY (Execution State - 7-30 day TTL)
┌─────────────────────────────────────────────────────────────────────────┐
│  PostgreSQL (Supabase)                                                  │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │  Table: working_memory                                            │  │
│  │                                                                   │  │
│  │  Characteristics:                                                 │  │
│  │  • Session-scoped persistence                                     │  │
│  │  • Automatic expiration (expires_at column)                       │  │
│  │  • Agent-specific state tracking                                  │  │
│  │  • Survives server restarts                                       │  │
│  │                                                                   │  │
│  │  Memory Types:                                                    │  │
│  │  • dealership_context: Current dealership operations             │  │
│  │  • customer_context: Active customer interactions                │  │
│  │  • execution_state: Agent workflow state                          │  │
│  │  • intermediate_result: Multi-step task results                  │  │
│  │                                                                   │  │
│  │  TTL Strategy:                                                    │  │
│  │  • Active tasks: 7 days                                           │  │
│  │  • Completed tasks: 30 days (for reference)                       │  │
│  │  • Failed tasks: 7 days (for debugging)                           │  │
│  │                                                                   │  │
│  │  Example Data:                                                    │  │
│  │  {                                                                │  │
│  │    user_id: "user-123",                                           │  │
│  │    session_id: "session-456",                                     │  │
│  │    agent_id: "auto_dealer",                                       │  │
│  │    memory_type: "execution_state",                                │  │
│  │    data: {                                                        │  │
│  │      appointment_id: "appt-789",                                  │  │
│  │      customer_id: "c-123",                                        │  │
│  │      follow_up_needed: true,                                      │  │
│  │      follow_up_at: "2026-01-22T10:00:00Z"                         │  │
│  │    },                                                             │  │
│  │    created_at: "2026-01-20T14:00:00Z",                            │  │
│  │    expires_at: "2026-01-27T14:00:00Z" (7 days)                    │  │
│  │  }                                                                │  │
│  │                                                                   │  │
│  │  Cleanup:                                                         │  │
│  │  • Cron job runs hourly: DELETE WHERE expires_at < NOW()         │  │
│  │                                                                   │  │
│  │  Access:                                                          │  │
│  │  • Coordination layer: READ + WRITE                               │  │
│  │  • Specialized agents: READ (scoped to agent_id) + WRITE          │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↓
TIER 3: LONG-TERM MEMORY (Knowledge Base - Permanent)
┌─────────────────────────────────────────────────────────────────────────┐
│  PostgreSQL + pgvector (Supabase)                                       │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │  Table: long_term_memory                                          │  │
│  │                                                                   │  │
│  │  Characteristics:                                                 │  │
│  │  • Permanent storage (no TTL)                                     │  │
│  │  • Semantic search via embeddings                                 │  │
│  │  • Confidence scoring                                             │  │
│  │  • Access tracking (for relevance ranking)                        │  │
│  │                                                                   │  │
│  │  Memory Types (Automotive Domain):                                │  │
│  │  • customer_preference: "Customer prefers trucks over sedans"    │  │
│  │  • dealership_rule: "Always offer financing on vehicles >$30k"   │  │
│  │  • sales_pattern: "Saturday test drives convert at 80%"          │  │
│  │  • service_insight: "Customer returns every 3 months for oil"    │  │
│  │                                                                   │  │
│  │  Example Data:                                                    │  │
│  │  {                                                                │  │
│  │    user_id: null, (organization-level fact)                       │  │
│  │    organization_id: "org-123",                                    │  │
│  │    memory_type: "customer_preference",                            │  │
│  │    content: "Customer c-456 prefers electric vehicles and has    │  │
│  │              expressed interest in Tesla Model Y equivalents",    │  │
│  │    embedding: [0.123, -0.456, ...], (1536 dimensions)             │  │
│  │    source: "agent_observation",                                   │  │
│  │    confidence: 0.85,                                              │  │
│  │    access_count: 12,                                              │  │
│  │    last_accessed: "2026-01-20T14:00:00Z",                         │  │
│  │    created_at: "2025-12-15T10:00:00Z"                             │  │
│  │  }                                                                │  │
│  │                                                                   │  │
│  │  Semantic Search:                                                 │  │
│  │  Query: "What does customer c-456 prefer?"                        │  │
│  │  → Generate embedding for query                                   │  │
│  │  → Vector similarity search (cosine distance)                     │  │
│  │  → Returns: "Electric vehicles, Tesla equivalents" (similarity: 0.92) │
│  │                                                                   │  │
│  │  Access:                                                          │  │
│  │  • System Assistant (Daria): READ + WRITE                         │  │
│  │  • Specialized agents: READ (domain-scoped)                       │  │
│  │  • Search query: All agents via MemoryService.searchMemory()     │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↓
TIER 4: EXTERNAL MEMORY (On-Demand References - Read-Only)
┌─────────────────────────────────────────────────────────────────────────┐
│  MCP Tools (External APIs)                                              │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │  Sources:                                                         │  │
│  │  • VIN Solutions CRM (customer records, appointments, inventory)  │  │
│  │  • VAPI (call transcripts, voice analytics)                       │  │
│  │  • Tavus (video session recordings, engagement metrics)           │  │
│  │  • Google Calendar (appointment availability)                     │  │
│  │  • External databases (third-party lead sources)                  │  │
│  │                                                                   │  │
│  │  Characteristics:                                                 │  │
│  │  • Not stored in Nexxus (reference-only)                          │  │
│  │  • Fetched on-demand via MCP proxy                                │  │
│  │  • Agent permission enforcement                                   │  │
│  │  • Rate-limited access                                            │  │
│  │                                                                   │  │
│  │  Example Access:                                                  │  │
│  │  Agent needs customer appointment history                         │  │
│  │  → Calls vin/get_customer_appointments via MCP                    │  │
│  │  → VIN Solutions returns last 90 days of appointments             │  │
│  │  → Data used for context, not stored permanently                  │  │
│  │                                                                   │  │
│  │  Cache Strategy (Optional):                                       │  │
│  │  • High-frequency data: Cache in Tier 1 (Redis) for 1 hour       │  │
│  │  • Medium-frequency: Cache in Tier 2 (working memory) for 24h    │  │
│  │  • Low-frequency: No cache, fetch on-demand                       │  │
│  │                                                                   │  │
│  │  Access:                                                          │  │
│  │  • Specialized agents only (via MCP proxy)                        │  │
│  │  • Subject to permission enforcement                              │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────────────┘
```

### Memory Access Matrix

```
┌─────────────────────────────────────────────────────────────────────────┐
│                     AGENT MEMORY ACCESS PERMISSIONS                     │
└─────────────────────────────────────────────────────────────────────────┘

Agent Type          │ Tier 0  │ Tier 1  │ Tier 2  │ Tier 3  │ Tier 4
                    │ System  │ Short   │ Working │ Long    │ External
                    │ State   │ Term    │ Memory  │ Term    │ Memory
────────────────────┼─────────┼─────────┼─────────┼─────────┼─────────
System Assistant    │ READ +  │ READ +  │ READ +  │ READ +  │ READ
(Daria - Tier 0)    │ WRITE   │ WRITE   │ WRITE   │ WRITE   │ (via MCP)
────────────────────┼─────────┼─────────┼─────────┼─────────┼─────────
Context Router      │ READ    │ READ    │ READ +  │ READ    │ N/A
(Coordination)      │ (all)   │ (all)   │ WRITE   │ (all)   │
────────────────────┼─────────┼─────────┼─────────┼─────────┼─────────
Orchestrator        │ READ    │ READ    │ READ +  │ READ    │ N/A
(Coordination)      │ (all)   │ (all)   │ WRITE   │ (all)   │
────────────────────┼─────────┼─────────┼─────────┼─────────┼─────────
Operator            │ READ    │ N/A     │ READ    │ READ    │ N/A
(Coordination)      │ (policy)│         │ (operat.│ (policy)│
                    │         │         │  data)  │         │
────────────────────┼─────────┼─────────┼─────────┼─────────┼─────────
AutoDealer          │ READ    │ READ +  │ READ +  │ READ    │ READ +
(Tier 2)            │ (scoped)│ WRITE   │ WRITE   │ (domain)│ WRITE
                    │         │ (scoped)│ (scoped)│         │ (vin/*)
────────────────────┼─────────┼─────────┼─────────┼─────────┼─────────
ConvoAgent          │ READ    │ READ +  │ READ +  │ READ    │ READ +
(Tier 2)            │ (scoped)│ WRITE   │ WRITE   │ (domain)│ WRITE
                    │         │ (scoped)│ (scoped)│         │(vapi/*,
                    │         │         │         │         │tavus/*)
────────────────────┼─────────┼─────────┼─────────┼─────────┼─────────
InsightAgent        │ READ    │ READ    │ READ    │ READ    │ READ
(Tier 2)            │ (scoped)│ (scoped)│ (scoped)│ (domain)│(clickhouse
                    │         │         │         │         │ /query)

Legend:
• READ (all) = Can read all records (subject to RLS)
• READ (scoped) = Can read only organization-scoped records
• READ (domain) = Can read only domain-specific memories
• WRITE (scoped) = Can write only to own agent_id records
• N/A = No access
```

---

## 5. Integration Architecture

### VIN Solutions CRM Integration

```
┌─────────────────────────────────────────────────────────────────────────┐
│                      VIN SOLUTIONS INTEGRATION                          │
└─────────────────────────────────────────────────────────────────────────┘

NEXXUS SIDE:
┌────────────────────────────────────────────────────────────────────────┐
│  AutoDealer Agent                                                      │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │  Tools Available:                                                │  │
│  │  • vin/get_customer                                              │  │
│  │  • vin/update_customer                                           │  │
│  │  • vin/get_appointments                                          │  │
│  │  • vin/create_appointment                                        │  │
│  │  • vin/update_appointment                                        │  │
│  │  • vin/get_inventory                                             │  │
│  │  • vin/create_lead                                               │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└───────────────────────────┬────────────────────────────────────────────┘
                            │ Call via MCP Proxy
                            ↓
┌────────────────────────────────────────────────────────────────────────┐
│  MCP Proxy                                                             │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │  1. Authentication: X-Agent-Id: auto_dealer                      │  │
│  │  2. Permission Check: auto_dealer.allowed_tools includes vin/*   │  │
│  │  3. Data Filtering: Add organization_id filter                   │  │
│  │  4. Rate Limiting: 200 req/hour                                  │  │
│  │  5. Forward to VIN MCP Server                                    │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└───────────────────────────┬────────────────────────────────────────────┘
                            │
                            ↓
┌────────────────────────────────────────────────────────────────────────┐
│  VIN MCP Server (Port 3011)                                            │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │  Tool: vin/get_customer                                          │  │
│  │  ┌────────────────────────────────────────────────────────────┐  │  │
│  │  │ async function getCustomer(params) {                       │  │  │
│  │  │   const response = await vinApi.get(                       │  │  │
│  │  │     `/customers/${params.customer_id}`,                    │  │  │
│  │  │     { headers: { Authorization: `Bearer ${VIN_TOKEN}` } }  │  │  │
│  │  │   );                                                        │  │  │
│  │  │   return response.data;                                    │  │  │
│  │  │ }                                                           │  │  │
│  │  └────────────────────────────────────────────────────────────┘  │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└───────────────────────────┬────────────────────────────────────────────┘
                            │ HTTPS
                            ↓
┌────────────────────────────────────────────────────────────────────────┐
│  VIN SOLUTIONS API                                                     │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │  Endpoint: GET /api/customers/{customer_id}                      │  │
│  │                                                                  │  │
│  │  Authentication: OAuth 2.0 (Production Certified)                │  │
│  │  Authorization: Bearer {access_token}                            │  │
│  │                                                                  │  │
│  │  Response:                                                       │  │
│  │  {                                                               │  │
│  │    "customer_id": "c-123",                                       │  │
│  │    "first_name": "John",                                         │  │
│  │    "last_name": "Doe",                                           │  │
│  │    "email": "john.doe@email.com",                                │  │
│  │    "phone": "+1-555-1234",                                       │  │
│  │    "status": "active",                                           │  │
│  │    "preferences": {                                              │  │
│  │      "vehicle_type": "truck",                                    │  │
│  │      "price_range": "$30k-$50k"                                  │  │
│  │    },                                                            │  │
│  │    "appointments": [...]                                         │  │
│  │  }                                                               │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────┘
                            │
                            │ Webhook (Event-Driven)
                            ↓
┌────────────────────────────────────────────────────────────────────────┐
│  NEXXUS WEBHOOK HANDLER                                                │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │  Endpoint: POST /api/webhooks/vin                                │  │
│  │                                                                  │  │
│  │  Events Handled:                                                 │  │
│  │  • customer.created → Sync new customer to Nexxus DB            │  │
│  │  • customer.updated → Update customer record                    │  │
│  │  • appointment.created → Create local appointment record        │  │
│  │  • appointment.cancelled → Update appointment status            │  │
│  │  • inventory.updated → Refresh inventory cache                  │  │
│  │                                                                  │  │
│  │  Security:                                                       │  │
│  │  • Webhook secret verification (HMAC signature)                  │  │
│  │  • IP whitelist (VIN Solutions IPs only)                         │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────┘

Data Flow:
1. Agent requests customer data via MCP tool
2. MCP Proxy enforces permissions
3. VIN MCP Server calls VIN Solutions API
4. Customer data returned to agent
5. Agent uses data in workflow
6. Webhooks keep data in sync real-time
```

### VAPI Voice AI Integration

```
┌─────────────────────────────────────────────────────────────────────────┐
│                          VAPI INTEGRATION                               │
└─────────────────────────────────────────────────────────────────────────┘

NEXXUS SIDE:
┌────────────────────────────────────────────────────────────────────────┐
│  ConvoAgent                                                            │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │  Tools Available:                                                │  │
│  │  • vapi/make_call (outbound)                                     │  │
│  │  • vapi/get_transcript                                           │  │
│  │  • vapi/get_analytics                                            │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└───────────────────────────┬────────────────────────────────────────────┘
                            ↓
┌────────────────────────────────────────────────────────────────────────┐
│  VAPI MCP Server (Port 3012)                                           │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │  Tool: vapi/make_call                                            │  │
│  │  ┌────────────────────────────────────────────────────────────┐  │  │
│  │  │ async function makeCall(params) {                          │  │  │
│  │  │   const response = await vapiApi.post('/calls', {          │  │  │
│  │  │     phone_number: params.phone_number,                     │  │  │
│  │  │     assistant_id: params.assistant_id,                     │  │  │
│  │  │     context: params.context                                │  │  │
│  │  │   }, {                                                      │  │  │
│  │  │     headers: { Authorization: `Bearer ${VAPI_TOKEN}` }     │  │  │
│  │  │   });                                                       │  │  │
│  │  │   return response.data;                                    │  │  │
│  │  │ }                                                           │  │  │
│  │  └────────────────────────────────────────────────────────────┘  │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└───────────────────────────┬────────────────────────────────────────────┘
                            ↓
┌────────────────────────────────────────────────────────────────────────┐
│  VAPI API                                                              │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │  POST /calls                                                     │  │
│  │                                                                  │  │
│  │  Request:                                                        │  │
│  │  {                                                               │  │
│  │    "phone_number": "+1-555-1234",                                │  │
│  │    "assistant_id": "asst-456",                                   │  │
│  │    "context": {                                                  │  │
│  │      "customer_name": "John Doe",                                │  │
│  │      "reason": "Appointment reminder",                           │  │
│  │      "dealership_name": "ABC Motors"                             │  │
│  │    }                                                             │  │
│  │  }                                                               │  │
│  │                                                                  │  │
│  │  Response:                                                       │  │
│  │  {                                                               │  │
│  │    "call_id": "call-789",                                        │  │
│  │    "status": "in_progress",                                      │  │
│  │    "started_at": "2026-01-20T14:00:00Z"                          │  │
│  │  }                                                               │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────┘
                            │
                            │ Webhook (Real-time Events)
                            ↓
┌────────────────────────────────────────────────────────────────────────┐
│  NEXXUS WEBHOOK HANDLER                                                │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │  Endpoint: POST /api/webhooks/vapi                               │  │
│  │                                                                  │  │
│  │  Events:                                                         │  │
│  │  • call.started → Update call status, notify UI                 │  │
│  │  • call.ended → Save transcript, calculate cost, update credits │  │
│  │  • call.failed → Log error, notify manager                      │  │
│  │  • transcript.ready → Store transcript in long-term memory      │  │
│  │                                                                  │  │
│  │  Real-time Updates:                                              │  │
│  │  • Publish to Supabase Realtime channel                          │  │
│  │  • UI updates via WebSocket subscription                         │  │
│  │  • Activity logged to activity_events table                      │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────┘

Cost Tracking:
• Call duration: 5 minutes
• VAPI cost: $0.15/min × 5 = $0.75
• Customer charge: $0.25/min × 5 = $1.25
• Nexxus profit: $1.25 - $0.75 = $0.50 (40% margin)
• Deducted from organization's credit balance
```

### Tavus Video AI Integration

```
┌─────────────────────────────────────────────────────────────────────────┐
│                         TAVUS INTEGRATION                               │
└─────────────────────────────────────────────────────────────────────────┘

NEXXUS SIDE:
┌────────────────────────────────────────────────────────────────────────┐
│  ConvoAgent                                                            │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │  Tools Available:                                                │  │
│  │  • tavus/create_session                                          │  │
│  │  • tavus/get_recording                                           │  │
│  │  • tavus/get_engagement_metrics                                  │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└───────────────────────────┬────────────────────────────────────────────┘
                            ↓
┌────────────────────────────────────────────────────────────────────────┐
│  Tavus MCP Server (Port 3013)                                          │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │  Tool: tavus/create_session                                      │  │
│  │  ┌────────────────────────────────────────────────────────────┐  │  │
│  │  │ async function createSession(params) {                     │  │  │
│  │  │   const response = await tavusApi.post('/conversations', { │  │  │
│  │  │     persona_id: params.persona_id,                         │  │  │
│  │  │     conversation_name: params.name,                        │  │  │
│  │  │     custom_fields: params.context                          │  │  │
│  │  │   }, {                                                      │  │  │
│  │  │     headers: { 'x-api-key': TAVUS_API_KEY }                │  │  │
│  │  │   });                                                       │  │  │
│  │  │   return response.data;                                    │  │  │
│  │  │ }                                                           │  │  │
│  │  └────────────────────────────────────────────────────────────┘  │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└───────────────────────────┬────────────────────────────────────────────┘
                            ↓
┌────────────────────────────────────────────────────────────────────────┐
│  TAVUS API                                                             │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │  POST /conversations                                             │  │
│  │                                                                  │  │
│  │  Request:                                                        │  │
│  │  {                                                               │  │
│  │    "persona_id": "persona-123",                                  │  │
│  │    "conversation_name": "John Doe - Vehicle Tour",               │  │
│  │    "custom_fields": {                                            │  │
│  │      "customer_name": "John Doe",                                │  │
│  │      "vehicle_of_interest": "VIN-1234567890"                     │  │
│  │    }                                                             │  │
│  │  }                                                               │  │
│  │                                                                  │  │
│  │  Response:                                                       │  │
│  │  {                                                               │  │
│  │    "conversation_id": "conv-789",                                │  │
│  │    "session_url": "https://tavus.io/session/conv-789",           │  │
│  │    "status": "active"                                            │  │
│  │  }                                                               │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────┘
                            │
                            │ Callback (Session Ended)
                            ↓
┌────────────────────────────────────────────────────────────────────────┐
│  NEXXUS WEBHOOK HANDLER                                                │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │  Endpoint: POST /api/webhooks/tavus                              │  │
│  │                                                                  │  │
│  │  Events:                                                         │  │
│  │  • session.started → Update status, notify UI                   │  │
│  │  • session.ended → Calculate duration, cost, save recording URL │  │
│  │  • recording.ready → Store recording link                       │  │
│  │                                                                  │  │
│  │  Cost Tracking:                                                  │  │
│  │  • Duration: 8 minutes                                           │  │
│  │  • Tavus cost: $0.20/min × 8 = $1.60                            │  │
│  │  • Customer charge: $0.32/min × 8 = $2.56                       │  │
│  │  • Nexxus profit: $0.96 (37.5% margin)                          │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────┘

Embed Code (Customer-Facing):
┌────────────────────────────────────────────────────────────────────────┐
│  DEALERSHIP WEBSITE                                                    │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │  <script src="https://nexxus.huminicdev.com/embed/video.js">    │  │
│  │  </script>                                                       │  │
│  │  <div id="nexxus-video-chat"                                     │  │
│  │       data-org-id="org-123"                                      │  │
│  │       data-persona-id="persona-456"></div>                       │  │
│  │                                                                  │  │
│  │  → Customer clicks "Chat with AI Assistant"                     │  │
│  │  → Nexxus creates Tavus session                                 │  │
│  │  → Interactive video conversation starts                        │  │
│  │  → All events tracked, costs calculated                         │  │
│  └──────────────────────────────────────────────────────────────────┘  │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 6. Coordination Layer Detail

### Context Router Decision Tree

```
┌─────────────────────────────────────────────────────────────────────────┐
│                     CONTEXT ROUTER DECISION FLOW                        │
└─────────────────────────────────────────────────────────────────────────┘

User Intent: "Schedule test drive and send confirmation"
                                    ↓
┌───────────────────────────────────────────────────────────────────────────┐
│ STEP 1: NLP PARSING                                                       │
│ ┌───────────────────────────────────────────────────────────────────────┐ │
│ │ Claude API:                                                           │ │
│ │ "Extract action and entities from: {intent}"                          │ │
│ │                                                                       │ │
│ │ Result:                                                               │ │
│ │ {                                                                     │ │
│ │   action: "schedule_and_notify",                                     │ │
│ │   entities: {                                                         │ │
│ │     appointment_type: "test_drive",                                   │ │
│ │     customer: null,  // Not specified                                 │ │
│ │     notification_channel: "default"                                   │ │
│ │   },                                                                  │ │
│ │   complexity: 0.7  // Multi-step task                                 │ │
│ │ }                                                                     │ │
│ └───────────────────────────────────────────────────────────────────────┘ │
└───────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌───────────────────────────────────────────────────────────────────────────┐
│ STEP 2: DOMAIN CLASSIFICATION                                             │
│ ┌───────────────────────────────────────────────────────────────────────┐ │
│ │ Domains: automotive, communication, analytics, system                 │ │
│ │                                                                       │ │
│ │ Action "schedule_and_notify" matches:                                 │ │
│ │ • "schedule" → automotive domain (VIN operation)                      │ │
│ │ • "notify" → communication domain (send confirmation)                 │ │
│ │                                                                       │ │
│ │ Result: multi_domain                                                  │ │
│ └───────────────────────────────────────────────────────────────────────┘ │
└───────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌───────────────────────────────────────────────────────────────────────────┐
│ STEP 3: ENTITY VALIDATION                                                 │
│ ┌───────────────────────────────────────────────────────────────────────┐ │
│ │ Entity Gate validates required entities:                             │ │
│ │                                                                       │ │
│ │ Required for test drive:                                              │ │
│ │ • customer_id ❌ Missing                                              │ │
│ │ • vehicle_vin ❌ Missing                                              │ │
│ │ • scheduled_time ❌ Missing                                           │ │
│ │                                                                       │ │
│ │ Action: Request missing entities from user                            │ │
│ │                                                                       │ │
│ │ DealerBrain Response: "For which customer? Please provide name or ID" │ │
│ │                                                                       │ │
│ │ User: "John Doe for 2026 Honda CR-V tomorrow at 2pm"                  │ │
│ │                                                                       │ │
│ │ Validated Entities:                                                   │ │
│ │ {                                                                     │ │
│ │   customer: { name: "John Doe", id: "c-123" },                        │ │
│ │   vehicle: { make: "Honda", model: "CR-V", vin: "VIN-789" },          │ │
│ │   time: "2026-01-21T14:00:00Z"                                        │ │
│ │ }                                                                     │ │
│ └───────────────────────────────────────────────────────────────────────┘ │
└───────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌───────────────────────────────────────────────────────────────────────────┐
│ STEP 4: CONTEXT LOADING                                                   │
│ ┌───────────────────────────────────────────────────────────────────────┐ │
│ │ Load context from memory tiers:                                      │ │
│ │                                                                       │ │
│ │ Tier 1 (Short-term - Redis):                                          │ │
│ │ • Current conversation: session-456                                   │ │
│ │ • User preferences: { preferred_channel: "sms" }                      │ │
│ │                                                                       │ │
│ │ Tier 2 (Working - PostgreSQL):                                        │ │
│ │ • Recent customer interactions (last 7 days): 2 calls, 1 email        │ │
│ │ • Pending follow-ups: None                                            │ │
│ │                                                                       │ │
│ │ Tier 3 (Long-term - pgvector):                                        │ │
│ │ Query: "customer c-123 preferences and patterns"                      │ │
│ │ Results:                                                              │ │
│ │ • "Customer prefers test drives on weekends" (confidence: 0.85)       │ │
│ │ • "Customer interested in SUVs" (confidence: 0.92)                    │ │
│ │ • "Customer no-showed once, send multiple reminders" (conf: 0.78)     │ │
│ │                                                                       │ │
│ │ Tier 4 (External - VIN API):                                          │ │
│ │ • Customer appointment history: 3 previous appointments               │ │
│ │ • Vehicle availability: VIN-789 available tomorrow                    │ │
│ └───────────────────────────────────────────────────────────────────────┘ │
└───────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌───────────────────────────────────────────────────────────────────────────┐
│ STEP 5: AGENT SELECTION                                                   │
│ ┌───────────────────────────────────────────────────────────────────────┐ │
│ │ Domain: multi_domain                                                  │ │
│ │ Complexity: 0.7 (multi-step)                                          │ │
│ │                                                                       │ │
│ │ Agent Map:                                                            │ │
│ │ • automotive → auto_dealer                                            │ │
│ │ • communication → convo_agent                                         │ │
│ │ • complexity > 0.5 → orchestrator                                     │ │
│ │                                                                       │ │
│ │ Selected Agents: [auto_dealer, convo_agent, orchestrator]             │ │
│ └───────────────────────────────────────────────────────────────────────┘ │
└───────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌───────────────────────────────────────────────────────────────────────────┐
│ STEP 6: ROUTING DECISION                                                  │
│ ┌───────────────────────────────────────────────────────────────────────┐ │
│ │ Multiple agents + Multi-step task = ORCHESTRATE                       │ │
│ │                                                                       │ │
│ │ Routing Decision:                                                     │ │
│ │ {                                                                     │ │
│ │   type: "orchestrate",                                                │ │
│ │   agents: ["auto_dealer", "convo_agent"],                             │ │
│ │   orchestrator: "orchestrator",                                       │ │
│ │   context: {                                                          │ │
│ │     user_id: "user-123",                                              │ │
│ │     entities: {...},                                                  │ │
│ │     memory: {                                                         │ │
│ │       short_term: {...},                                              │ │
│ │       working: {...},                                                 │ │
│ │       long_term: [...]                                                │ │
│ │     }                                                                 │ │
│ │   }                                                                   │ │
│ │ }                                                                     │ │
│ └───────────────────────────────────────────────────────────────────────┘ │
└───────────────────────────────────────────────────────────────────────────┘
                                    ↓
                             PASS TO ORCHESTRATOR
```

### Orchestrator Workflow Execution

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    ORCHESTRATOR WORKFLOW ENGINE                         │
└─────────────────────────────────────────────────────────────────────────┘

Input: Routing Decision from Context Router
                                    ↓
┌───────────────────────────────────────────────────────────────────────────┐
│ STEP 1: WORKFLOW DECOMPOSITION                                            │
│ ┌───────────────────────────────────────────────────────────────────────┐ │
│ │ Claude API (LLM):                                                     │ │
│ │ "Decompose task into sequential and parallel steps"                  │ │
│ │                                                                       │ │
│ │ Task: Schedule test drive + Send confirmation                         │ │
│ │ Available Agents: auto_dealer, convo_agent                            │ │
│ │                                                                       │ │
│ │ Generated Workflow:                                                   │ │
│ │ {                                                                     │ │
│ │   steps: [                                                            │ │
│ │     {                                                                 │ │
│ │       type: "sequential",                                             │ │
│ │       agent: "auto_dealer",                                           │ │
│ │       task: "Create test drive appointment in VIN Solutions",         │ │
│ │       params: {                                                       │ │
│ │         customer_id: "c-123",                                         │ │
│ │         vehicle_vin: "VIN-789",                                       │ │
│ │         scheduled_time: "2026-01-21T14:00:00Z"                        │ │
│ │       }                                                               │ │
│ │     },                                                                │ │
│ │     {                                                                 │ │
│ │       type: "sequential",  // Depends on step 1                       │ │
│ │       agent: "convo_agent",                                           │ │
│ │       task: "Send confirmation via preferred channel",                │ │
│ │       params: {                                                       │ │
│ │         customer_id: "c-123",                                         │ │
│ │         appointment_id: "${step1.appointment_id}",  // Reference     │ │
│ │         channel: "sms"                                                │ │
│ │       }                                                               │ │
│ │     }                                                                 │ │
│ │   ]                                                                   │ │
│ │ }                                                                     │ │
│ └───────────────────────────────────────────────────────────────────────┘ │
└───────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌───────────────────────────────────────────────────────────────────────────┐
│ STEP 2: EXECUTE STEP 1 (Sequential)                                       │
│ ┌───────────────────────────────────────────────────────────────────────┐ │
│ │ Execute: auto_dealer.scheduleTestDrive()                              │ │
│ │                                                                       │ │
│ │ Result:                                                               │ │
│ │ {                                                                     │ │
│ │   success: true,                                                      │ │
│ │   appointment_id: "appt-456",                                         │ │
│ │   confirmation_number: "TD-2024-456",                                 │ │
│ │   scheduled_time: "2026-01-21T14:00:00Z"                              │ │
│ │ }                                                                     │ │
│ │                                                                       │ │
│ │ Update Context:                                                       │ │
│ │ context.step1_result = result                                         │ │
│ └───────────────────────────────────────────────────────────────────────┘ │
└───────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌───────────────────────────────────────────────────────────────────────────┐
│ STEP 3: EXECUTE STEP 2 (Sequential, using Step 1 result)                  │
│ ┌───────────────────────────────────────────────────────────────────────┐ │
│ │ Execute: convo_agent.sendConfirmation()                               │ │
│ │                                                                       │ │
│ │ Params (with substitution):                                           │ │
│ │ {                                                                     │ │
│ │   customer_id: "c-123",                                               │ │
│ │   appointment_id: "appt-456",  // From step 1                         │ │
│ │   channel: "sms"                                                      │ │
│ │ }                                                                     │ │
│ │                                                                       │ │
│ │ Result:                                                               │ │
│ │ {                                                                     │ │
│ │   success: true,                                                      │ │
│ │   message_id: "sms-789",                                              │ │
│ │   sent_to: "+1-555-1234"                                              │ │
│ │ }                                                                     │ │
│ └───────────────────────────────────────────────────────────────────────┘ │
└───────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌───────────────────────────────────────────────────────────────────────────┐
│ STEP 4: SYNTHESIZE RESULTS                                                │
│ ┌───────────────────────────────────────────────────────────────────────┐ │
│ │ Combine all step results into coherent response:                     │ │
│ │                                                                       │ │
│ │ Final Result:                                                         │ │
│ │ {                                                                     │ │
│ │   success: true,                                                      │ │
│ │   summary: "Test drive scheduled and confirmation sent",              │ │
│ │   details: {                                                          │ │
│ │     appointment: {                                                    │ │
│ │       id: "appt-456",                                                 │ │
│ │       confirmation_number: "TD-2024-456",                             │ │
│ │       customer: "John Doe",                                           │ │
│ │       vehicle: "2026 Honda CR-V",                                     │ │
│ │       time: "Tomorrow at 2:00 PM"                                     │ │
│ │     },                                                                │ │
│ │     notification: {                                                   │ │
│ │       sent_via: "SMS",                                                │ │
│ │       sent_to: "+1-555-1234",                                         │ │
│ │       message_id: "sms-789"                                           │ │
│ │     }                                                                 │ │
│ │   }                                                                   │ │
│ │ }                                                                     │ │
│ └───────────────────────────────────────────────────────────────────────┘ │
└───────────────────────────────────────────────────────────────────────────┘
                                    ↓
                         RETURN TO DEALERBRAIN (UI)
```

---

## 7. User Journey Maps

### Journey 1: Dealership Manager - Scheduling Test Drive

```
┌─────────────────────────────────────────────────────────────────────────┐
│        USER: Sarah (Dealership Manager at ABC Motors)                  │
│        GOAL: Schedule test drive for customer John Doe                 │
└─────────────────────────────────────────────────────────────────────────┘

1. OPENS NEXXUS DASHBOARD
   ┌──────────────────────────────────────────────────────────────────┐
   │  Browser: https://nexxus.huminicdev.com                         │
   │                                                                  │
   │  ┌──────────────────────────────────────────────────────────┐   │
   │  │ TOP BAR                                                  │   │
   │  │ ABC Motors (Org Switcher) | 🔍 Search | 🔔 Alerts | 👤  │   │
   │  └──────────────────────────────────────────────────────────┘   │
   │  ┌────────┐  ┌─────────────────────────────────────────────┐   │
   │  │ LEFT   │  │ MAIN CONTENT                                │   │
   │  │ SIDEBAR│  │                                             │   │
   │  │        │  │ Dashboard Overview                          │   │
   │  │ 📊 Dash│  │ • 5 active conversations                    │   │
   │  │ 🤖 Agnt│  │ • 12 appointments today                     │   │
   │  │ 👥 Cust│  │ • $2,450 in credits remaining               │   │
   │  │ 📈 Rpts│  │                                             │   │
   │  └────────┘  └─────────────────────────────────────────────┘   │
   │                                                                  │
   └──────────────────────────────────────────────────────────────────┘
                                    ↓
2. OPENS DEALERBRAIN (⌘K Command Palette)
   ┌──────────────────────────────────────────────────────────────────┐
   │  Sarah presses: ⌘K                                               │
   │                                                                  │
   │  ┌──────────────────────────────────────────────────────────┐   │
   │  │ RIGHT SIDEBAR (expands)                                  │   │
   │  │                                                          │   │
   │  │ 🤖 DealerBrain AI Assistant                             │   │
   │  │ ────────────────────────────────────                    │   │
   │  │                                                          │   │
   │  │ How can I help you today?                               │   │
   │  │                                                          │   │
   │  │ [Type your command...]                                  │   │
   │  │                                                          │   │
   │  └──────────────────────────────────────────────────────────┘   │
   └──────────────────────────────────────────────────────────────────┘
                                    ↓
3. TYPES COMMAND
   ┌──────────────────────────────────────────────────────────────────┐
   │  Sarah types: "Schedule test drive for John Doe"                 │
   │                                                                  │
   │  ┌──────────────────────────────────────────────────────────┐   │
   │  │ 🤖 DealerBrain                                           │   │
   │  │                                                          │   │
   │  │ User: Schedule test drive for John Doe                  │   │
   │  │                                                          │   │
   │  │ DealerBrain: Looking up customer John Doe...            │   │
   │  │              (typing indicator...)                       │   │
   │  └──────────────────────────────────────────────────────────┘   │
   └──────────────────────────────────────────────────────────────────┘
                                    ↓
   [SYSTEM: Context Router selects AutoDealer agent]
   [SYSTEM: AutoDealer queries VIN Solutions for customer "John Doe"]
                                    ↓
4. AGENT REQUESTS CLARIFICATION
   ┌──────────────────────────────────────────────────────────────────┐
   │  ┌──────────────────────────────────────────────────────────┐   │
   │  │ 🤖 DealerBrain                                           │   │
   │  │                                                          │   │
   │  │ I found customer John Doe (ID: c-123).                  │   │
   │  │                                                          │   │
   │  │ Which vehicle for the test drive?                       │   │
   │  │ Available inventory:                                     │   │
   │  │ • 2026 Honda CR-V (VIN-789)                             │   │
   │  │ • 2025 Toyota RAV4 (VIN-456)                            │   │
   │  │                                                          │   │
   │  │ [Type vehicle or click...]                              │   │
   │  └──────────────────────────────────────────────────────────┘   │
   └──────────────────────────────────────────────────────────────────┘
                                    ↓
5. PROVIDES DETAILS
   ┌──────────────────────────────────────────────────────────────────┐
   │  Sarah types: "Honda CR-V tomorrow at 2pm"                       │
   │                                                                  │
   │  ┌──────────────────────────────────────────────────────────┐   │
   │  │ User: Honda CR-V tomorrow at 2pm                         │   │
   │  │                                                          │   │
   │  │ DealerBrain: Creating appointment...                     │   │
   │  │              (progress indicator)                        │   │
   │  └──────────────────────────────────────────────────────────┘   │
   └──────────────────────────────────────────────────────────────────┘
                                    ↓
   [SYSTEM: Orchestrator executes workflow]
   [SYSTEM: AutoDealer creates appointment in VIN (800ms)]
   [SYSTEM: ConvoAgent sends SMS confirmation (400ms)]
                                    ↓
6. RECEIVES CONFIRMATION
   ┌──────────────────────────────────────────────────────────────────┐
   │  ┌──────────────────────────────────────────────────────────┐   │
   │  │ 🤖 DealerBrain                                           │   │
   │  │                                                          │   │
   │  │ ✓ Test drive scheduled successfully!                    │   │
   │  │                                                          │   │
   │  │ 📅 Appointment Details:                                 │   │
   │  │ • Customer: John Doe                                     │   │
   │  │ • Vehicle: 2026 Honda CR-V                              │   │
   │  │ • Time: Tomorrow (Jan 21) at 2:00 PM                    │   │
   │  │ • Confirmation: TD-2024-456                             │   │
   │  │                                                          │   │
   │  │ ✉️ SMS confirmation sent to +1-555-1234                 │   │
   │  │                                                          │   │
   │  │ [View Appointment] [Send Reminder]                      │   │
   │  └──────────────────────────────────────────────────────────┘   │
   └──────────────────────────────────────────────────────────────────┘
                                    ↓
7. VIEWS CONFIRMATION IN DASHBOARD
   ┌──────────────────────────────────────────────────────────────────┐
   │  Dashboard automatically updates (via Supabase Realtime)         │
   │                                                                  │
   │  ┌─────────────────────────────────────────────────────────┐    │
   │  │ Upcoming Appointments                                   │    │
   │  │                                                         │    │
   │  │ Tomorrow, Jan 21                                        │    │
   │  │ ┌─────────────────────────────────────────────────────┐ │    │
   │  │ │ 2:00 PM - Test Drive                              │ │    │
   │  │ │ John Doe • 2026 Honda CR-V                        │ │    │
   │  │ │ Confirmed via SMS ✓                               │ │    │
   │  │ └─────────────────────────────────────────────────────┘ │    │
   │  └─────────────────────────────────────────────────────────┘    │
   └──────────────────────────────────────────────────────────────────┘

TOTAL TIME: ~3 seconds from command to confirmation
AGENT PATH: DealerBrain → Context Router → Orchestrator → AutoDealer + ConvoAgent
SYSTEMS TOUCHED: Nexxus DB, VIN Solutions, Twilio (SMS)
USER EXPERIENCE: Seamless, conversational, fast
```

---

## 8. Deployment Architecture

### Production Environment

```
┌─────────────────────────────────────────────────────────────────────────┐
│                      PRODUCTION DEPLOYMENT                              │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│  CLOUDFLARE CDN                                                         │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │  Domain: nexxus.huminicdev.com                                    │  │
│  │  SSL: Automatic (Cloudflare)                                      │  │
│  │  DDoS Protection: Enabled                                         │  │
│  │  Cache: Static assets (JS, CSS, images)                           │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└───────────────────────────┬─────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────────────────┐
│  VERCEL (Frontend)                                                      │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │  Next.js 14 App                                                   │  │
│  │  ┌─────────────────────────────────────────────────────────────┐  │  │
│  │  │ Edge Functions:                                             │  │  │
│  │  │ • /api/auth/* → Authentication                              │  │  │
│  │  │ • /api/webhooks/* → Webhook handlers                        │  │  │
│  │  │                                                             │  │  │
│  │  │ Static Generation:                                          │  │  │
│  │  │ • Public pages (landing, docs)                              │  │  │
│  │  │                                                             │  │  │
│  │  │ Server-Side Rendering:                                      │  │  │
│  │  │ • Dashboard (dynamic, auth-protected)                       │  │  │
│  │  │ • Settings pages                                            │  │  │
│  │  └─────────────────────────────────────────────────────────────┘  │  │
│  │                                                                   │  │
│  │  Environment Variables:                                           │  │
│  │  • NEXT_PUBLIC_SUPABASE_URL                                       │  │
│  │  • NEXT_PUBLIC_SUPABASE_ANON_KEY                                  │  │
│  │  • MCP_PROXY_URL                                                  │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└───────────────────────────┬─────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────────────────┐
│  SUPABASE CLOUD (Backend + Database)                                    │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │  PostgreSQL Database                                              │  │
│  │  ┌─────────────────────────────────────────────────────────────┐  │  │
│  │  │ Tables:                                                     │  │  │
│  │  │ • organizations, locations, users, roles                    │  │  │
│  │  │ • working_memory, long_term_memory, activity_events         │  │  │
│  │  │ • agents, skills, conversations, messages                   │  │  │
│  │  │ • pending_approvals, hunch_suggestions                      │  │  │
│  │  │                                                             │  │  │
│  │  │ Extensions:                                                 │  │  │
│  │  │ • pgvector (embeddings)                                     │  │  │
│  │  │ • pg_cron (TTL cleanup)                                     │  │  │
│  │  │                                                             │  │  │
│  │  │ Row-Level Security: ENABLED on all tables                  │  │  │
│  │  └─────────────────────────────────────────────────────────────┘  │  │
│  │                                                                   │  │
│  │  Auth Service (Supabase Auth)                                     │  │
│  │  ┌─────────────────────────────────────────────────────────────┐  │  │
│  │  │ • JWT-based authentication                                  │  │  │
│  │  │ • Refresh token rotation                                    │  │  │
│  │  │ • Email/password + OAuth (Google, Microsoft)                │  │  │
│  │  └─────────────────────────────────────────────────────────────┘  │  │
│  │                                                                   │  │
│  │  Realtime Service (Supabase Realtime)                             │  │
│  │  ┌─────────────────────────────────────────────────────────────┐  │  │
│  │  │ • WebSocket subscriptions                                   │  │  │
│  │  │ • Channels: activity_events, conversations, pending_approvals│ │  │
│  │  │ • Presence tracking (online users)                          │  │  │
│  │  └─────────────────────────────────────────────────────────────┘  │  │
│  │                                                                   │  │
│  │  Edge Functions (Supabase Functions)                              │  │
│  │  ┌─────────────────────────────────────────────────────────────┐  │  │
│  │  │ • /context-router → Deno function                           │  │  │
│  │  │ • /orchestrator → Deno function                             │  │  │
│  │  │ • /operator → Deno function                                 │  │  │
│  │  └─────────────────────────────────────────────────────────────┘  │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└───────────────────────────┬─────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────────────────┐
│  REDIS CLOUD (Upstash)                                                  │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │  Short-Term Memory                                                │  │
│  │  • Global replication (multi-region)                              │  │
│  │  • Automatic TTL expiration                                       │  │
│  │  • 1GB storage (estimated usage)                                  │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└───────────────────────────┬─────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────────────────┐
│  MCP PROXY SERVER (Railway/Oracle Cloud)                                │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │  Port: 3010                                                       │  │
│  │  Node.js Express Server                                           │  │
│  │                                                                   │  │
│  │  Endpoints:                                                       │  │
│  │  • POST /mcp/:server/:tool                                        │  │
│  │                                                                   │  │
│  │  Permission Enforcement:                                          │  │
│  │  • agent-permissions.yaml loaded at startup                       │  │
│  │  • In-memory cache for fast lookups                               │  │
│  │  • Rate limiting via rate-limiter-flexible                        │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└───────────┬──────────────────────┬──────────────────────┬───────────────┘
            ↓                      ↓                      ↓
┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
│ VIN MCP Server   │  │ VAPI MCP Server  │  │ Tavus MCP Server │
│ (Port 3011)      │  │ (Port 3012)      │  │ (Port 3013)      │
│                  │  │                  │  │                  │
│ Tools:           │  │ Tools:           │  │ Tools:           │
│ • vin/*          │  │ • vapi/*         │  │ • tavus/*        │
└────────┬─────────┘  └────────┬─────────┘  └────────┬─────────┘
         ↓                     ↓                      ↓
┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐
│ VIN Solutions    │  │ VAPI API         │  │ Tavus API        │
│ API              │  │                  │  │                  │
└──────────────────┘  └──────────────────┘  └──────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│  CLICKHOUSE CLOUD (Analytics)                                           │
│  ┌───────────────────────────────────────────────────────────────────┐  │
│  │  OLAP Database                                                    │  │
│  │  • dealership_appointments_hist                                   │  │
│  │  • customer_interactions_hist                                     │  │
│  │  • Materialized views (daily metrics)                             │  │
│  └───────────────────────────────────────────────────────────────────┘  │
└───────────────────────────┬─────────────────────────────────────────────┘
                            ↑
                    ┌───────┴────────┐
                    │ ETL: Airbyte   │
                    │ (every 15 min) │
                    └────────────────┘

MONITORING & OBSERVABILITY:
┌─────────────────────────────────────────────────────────────────────────┐
│  Sentry (Error Tracking)                                                │
│  • Frontend errors                                                      │
│  • Backend errors                                                       │
│  • Performance monitoring                                               │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│  Vercel Analytics                                                       │
│  • Page views                                                           │
│  • Web Vitals                                                           │
│  • Real User Monitoring (RUM)                                           │
└─────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────┐
│  Supabase Dashboard                                                     │
│  • Database metrics (connections, query performance)                    │
│  • Auth metrics (logins, signups)                                       │
│  • Realtime connections                                                 │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## Document Control

| Field | Value |
|-------|-------|
| Version | 1.0 |
| Created By | System Architect |
| Created Date | January 20, 2026 |
| Last Updated | January 20, 2026 |
| Status | Reference Guide |
| Classification | Internal |

---

**End of Document**
