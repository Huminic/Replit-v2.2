# Nexxus System Requirements Specification v3.0 - MASTER

**Document Version:** 3.0
**Date:** January 30, 2026
**Status:** Final Draft
**Classification:** Confidential

## Document Control

| Field | Value |
|-------|--------|
| Document Title | Nexxus System Requirements Specification v3.0 - MASTER |
| Version | 3.0 |
| Date | January 30, 2026 |
| Prepared By | Development Team |
| Approved By | [Pending] |
| Document Type | System Requirements Specification |
| Classification | Confidential |

## Table of Contents

1. **Executive Summary**
   - 1.1 Business Context
   - 1.2 Jumpstart Program Scope
   - 1.3 Success Metrics & Business Impact
   - 1.4 Economic Model
   - 1.5 Competitive Differentiation

2. **Introduction**
   - 2.1 Purpose
   - 2.2 Scope
   - 2.3 Intended Audience
   - 2.4 Document Conventions

3. **System Overview**
   - 3.1 System Purpose
   - 3.2 System Architecture Overview
   - 3.3 Key System Components
   - 3.4 Supported User Roles

4. **Agent & Tool Architecture**
   - 4.1 Agent Hierarchy Architecture
   - 4.2 Tool Hierarchy Architecture
   - 4.3 Agent Provisioning and Quota Management
   - 4.4 Agent Delegation and Sharing Model
   - 4.5 Template Duplication Strategy

5. **Functional Requirements**
   - 5.1 Main Chat / DealerBrain
   - 5.2 Drive / Artifacts
   - 5.3 Hunches
   - 5.4 Approvals
   - 5.5 Communication / Inbox
   - 5.6 Billing
   - 5.7 Users Management
   - 5.8 Notifications
   - 5.9 Service Integrations

6. **Non-Functional Requirements**
   - 6.1 Performance Requirements
   - 6.2 Scalability Requirements
   - 6.3 Availability Requirements
   - 6.4 Security Requirements

7. **System Architecture**
   - 7.1 Technical Stack
   - 7.2 Data Flow Architecture
   - 7.3 Security Architecture
   - 7.4 Context Router Architecture

8. **Data Model & Entity Relationship Diagram**
   - 8.1 Entity Relationship Diagram
   - 8.2 Table Definitions
     - 8.2.1 Organizations
     - 8.2.2 Locations
     - 8.2.3 Users
     - 8.2.4 Roles
     - 8.2.5 Integrations
     - 8.2.6 Conversations
     - 8.2.7 Messages
     - 8.2.8 Chat_Conversations
     - 8.2.9 Chat_Messages
     - 8.2.10 Agents
     - 8.2.11 Skills
     - 8.2.12 Agent_Runs
     - 8.2.13 Tasks
     - 8.2.14 Dashboards
     - 8.2.15 Widgets
     - 8.2.16 Goals
     - 8.2.17 Artifacts
     - 8.2.18 Drive_Folders
     - 8.2.19 Drive_Artifacts
     - 8.2.20 Credit_Policies
     - 8.2.21 Credit_Allocations
     - 8.2.22 Credit_Usage
     - 8.2.23 Hunches
     - 8.2.24 Hunch_Configs
     - 8.2.25 Hunch_Approvals
     - 8.2.26 Approval_Workflows
     - 8.2.27 Approval_Requests
     - 8.2.28 Approval_Actions
     - 8.2.29 Service_Quotas
     - 8.2.30 Service_Allocations
     - 8.2.31 Leads
     - 8.2.32 VIN_Reports_Cache
     - 8.2.33 Audit_Log

9. **API Specifications**
   - 9.1 VIN Solutions Integration API
   - 9.2 Internal API Endpoints
   - 9.3 Webhook Specifications

10. **User Interface Requirements**
    - 10.1 Frontend Architecture
    - 10.2 User Experience Requirements
    - 10.3 Responsive Design Requirements

11. **Security Requirements**
    - 11.1 Authentication and Authorization
    - 11.2 Data Protection
    - 11.3 Audit and Compliance
    - 11.4 Privacy Requirements

12. **Integration Requirements**
    - 12.1 VAPI Integration
    - 12.2 Tavus Integration
    - 12.3 VIN Solutions Integration
    - 12.4 Third-Party Integrations

13. **Requirements Catalog**
    - 13.1 Functional Requirements Summary
    - 13.2 Non-Functional Requirements Summary
    - 13.3 Traceability Matrix

14. **Operational Requirements**
    - 14.1 Deployment Requirements
    - 14.2 Monitoring and Logging
    - 14.3 Backup and Recovery

15. **Appendices**
    - Appendix A: Operations Runbook
    - Appendix B: Sources and Traceability

## 1. Executive Summary

### 1.1 Business Context

Nexxus represents a paradigm shift in automotive dealership operations, positioning itself as the execution layer that solves the fundamental problem of response gaps, follow-up inconsistency, and lack of execution that plague modern dealerships. Rather than generating more leads, Nexxus ensures that existing leads are properly handled through AI-powered voice, video, and chat interactions.

The platform addresses the core strategic thesis: **dealerships don't lose because of lead volume—they lose because of response gaps and execution failures**. By becoming the intelligent execution layer between CRM systems and customer touchpoints, Nexxus transforms how dealerships handle customer interactions across all channels.

### 1.2 Jumpstart Program Scope

The initial deployment (Jumpstart Phase) delivers a comprehensive AI workforce automation platform including:

- **AI Voice Assist**: Inbound and outbound voice capabilities via VAPI integration
- **AI Video Assist**: Interactive, two-way conversational video via Tavus
- **Super Chat AI**: 24/7 team AI coverage across all digital channels
- **VIN CRM Integration**: Production-ready, certified integration with VinSolutions
- **Manager Workflows**: Accountability tools and performance monitoring
- **Daily Insights & Alerts**: Real-time operational visibility and proactive notifications

### 1.3 Success Metrics & Business Impact

The platform is designed to deliver measurable business outcomes:

- **Response Time**: <30 seconds for all inbound communications
- **Lead Conversion**: 50% improvement over pre-AI baseline
- **System Uptime**: 99.5% availability guarantee
- **Call Coverage**: 95% of calls handled without human intervention
- **Appointment Rate**: 80% of qualified leads resulting in scheduled appointments
- **Operational Efficiency**: 40% reduction in routine task time for dealership staff

### 1.4 Economic Model

The platform operates on a transparent, usage-based economic model with modular credit allocation:

- **Voice AI**: $0.25/minute customer rate ($0.15/minute cost = 40% margin)
- **Interactive Video**: $0.32/minute customer rate ($0.20/minute cost = 37.5% margin)
- **SMS/Email**: $0.05/message customer rate ($0.02/message cost = 60% margin)
- **AI Chat Tokens**: $5 per million tokens (3M tokens/customer/month average)

This economic structure ensures sustainable unit economics while providing dealerships with predictable, performance-based pricing.

### 1.5 Competitive Differentiation

Nexxus differentiates through its unique positioning as a complete AI workforce platform rather than a point solution:

- **Unified Platform**: Voice, video, and chat in one integrated system
- **Execution Focus**: Does the work rather than just generating insights
- **VIN Certification**: Production-ready CRM integration with VinSolutions
- **Manager Enablement**: Built-in accountability and performance tools
- **Rapid Deployment**: 5-day implementation path vs. traditional enterprise software
- **Flexible Economics**: Month-to-month, usage-based model

---

## 2. Introduction

### 2.1 Purpose

This System Requirements Specification (SRS) defines the functional and non-functional requirements for the Nexxus Platform, an AI-powered dealership workforce automation system. This document serves as the authoritative specification for development, testing, and deployment activities.

### 2.2 Scope

The Nexxus Platform encompasses:

- **Frontend Application**: ClickUp-inspired interface with left navigation and context-aware AI
- **Backend Services**: Microservices architecture supporting multi-tenant operations
- **AI Orchestration**: DealerBrain (Automa) for intelligent task routing and execution
- **Integration Layer**: APIs for VIN Solutions, VAPI, Tavus, and third-party systems
- **Data Platform**: Supabase-based data warehouse with real-time capabilities
- **Credit Management**: Usage-based billing and resource allocation system
- **Administrative Tools**: Multi-level RBAC with partner, organization, and user management

### 2.3 Intended Audience

This document is intended for:

- Development and engineering teams
- Quality assurance and testing teams
- Product management and stakeholders
- Technical operations and support teams
- Integration partners and third-party vendors

### 2.4 Document Conventions

- Requirements are numbered using the format REQ-[AREA]-[NUMBER]
- Priority levels: P0 (Critical), P1 (High), P2 (Medium), P3 (Low)
- The key words "SHALL", "SHOULD", "MAY", and "MUST" are used per RFC 2119
- All monetary values are in USD unless otherwise specified

---

## 3. System Overview

### 3.1 System Purpose

The Nexxus Platform is designed to serve as an intelligent execution layer for automotive dealerships, automating customer interactions across voice, video, and digital channels while maintaining seamless integration with existing CRM systems.

### 3.2 System Architecture Overview

The platform employs a four-tier architecture:

1. **Presentation Layer**: Next.js 14 frontend with ClickUp-inspired interface
2. **DealerBrain Orchestration Layer**: AI-powered task routing and execution
3. **Service Layer**: Microservices for core business functions
4. **Data Layer**: Supabase PostgreSQL with real-time subscriptions

### 3.3 Key System Components

- **Chat Interface**: Unified conversation management across all channels using Claude 3.5 Sonnet
- **Calendar System**: Integrated scheduling with Google OAuth and manual entry
- **Agent Management**: Skill-based AI agents with template library
- **Activity Monitoring**: Comprehensive audit trail and performance analytics
- **Drive System**: Artifact creation, storage (local filesystem v1), and governance
- **Hunches Dashboard**: AI-powered insights with RLHF approval workflow
- **Approvals System**: Workflow management for hunches and external communications
- **Inbox**: Email (via Resend), SMS (future), and notifications (SSE delivery)
- **Reporting Engine**: Query builder with export and scheduling capabilities
- **Credit Management**: Usage tracking and billing integration

### 3.4 Supported User Roles

- **Super Admin (Level 1)**: Platform-wide administration and configuration
- **Partner Admin (Level 2)**: Multi-organization management and provisioning
- **Org Admin (Level 3)**: Organization-level configuration and team management
- **Staff (Level 4)**: Day-to-day operational access and AI interaction

### 3.5 Technology Stack

> **Implementation Note (D-003):** v2 uses Vite + React instead of Next.js 14 per architecture decision. Internal dashboard does not require SSR/SEO. See `/docs/specifications/DECISIONS_LOG.md`.

**Frontend:**
- ~~Next.js 14 with App Router~~ **Vite + React 18** (implementation decision)
- TypeScript for type safety
- Tailwind CSS for styling
- ~~Zustand~~ **React Query + Context** for state management (D-009)
- React Query for data fetching
- Tremor for data visualization

**Backend:**
- Supabase (PostgreSQL + Real-time + Auth)
- Node.js/Express for API services
- pgvector for vector search capabilities
- Redis for caching and session management

**AI & Integration:**
- ~~Claude 3.5 Sonnet~~ **claude-sonnet-4-20250514** for primary language model (D-001 - newer model)
- GPT-4 for specialized tasks
- VAPI for voice processing (client's existing API key)
- Tavus for video generation (client's existing API key)
- Resend for email delivery
- Custom MCP server integration

**Infrastructure:**
- Vercel for frontend deployment
- Supabase Cloud for backend services
- CloudFlare for CDN and DDoS protection
- Local filesystem for Drive storage (v1)

---

## 4. Agent & Tool Architecture

### 4.1 Agent Hierarchy Architecture

The Nexxus platform implements a four-tier agent architecture designed to provide scalable AI capabilities while maintaining strict organizational boundaries and operational control.

```
┌─────────────────────────────────────────────────────────────────┐
│                    SYSTEM LEVEL AGENTS                          │
│  • Automa (DealerBrain) - Primary orchestration AI              │
│  • Specialized System Agents (Future) - Domain experts         │
│  • Managed by: Super Admin only                                │
│  • Lives in: Nexxus infrastructure                             │
│  • Scope: Platform-wide, delegated to accounts                 │
└─────────────────────────────────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│                   SERVICE LEVEL AGENTS                          │
│  • VAPI Assistants (voice interactions)                        │
│  • Tavus Personas (video interactions)                         │
│  • Managed by: Super Admin only (v1)                          │
│  • Lives in: External infrastructure                           │
│  • Constraint: One master account shared across orgs           │
│  • Isolation: Via metadata tagging + quota management          │
└─────────────────────────────────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│                   ACCOUNT LEVEL AGENTS                          │
│  • Custom agents created by Org/Partner Admins                 │
│  • Can utilize: Tools, data, workflows, triggers               │
│  • Similar to: ClickUp Agents architecture                     │
│  • Created via: Automa (natural language) or manual UI         │
│  • CRUD access: Org Admin + Automa                             │
│  • Shareable: Can be shared down to users                      │
└─────────────────────────────────────────────────────────────────┘
                            ▼
┌─────────────────────────────────────────────────────────────────┐
│                    USER LEVEL AGENTS                            │
│  • Account Level Agents shared to specific users               │
│  • Access: Read/execute only (no modification rights)          │
│  • Inherit: Permissions from parent Account Level Agent        │
└─────────────────────────────────────────────────────────────────┘
```

**Key Implementation Points:**

- **System Agents**: Created and managed exclusively by Super Admins
- **Service Agents**: Provisioned via quota-based model using client's existing VAPI_MASTER_API_KEY and TAVUS_MASTER_API_KEY
- **Account Agents**: Created by Org/Partner Admins or Automa via natural language
- **User Agents**: Shared Account Agents with execute-only permissions

### 4.2 Tool Hierarchy Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      SYSTEM TOOLS                               │
│  • Background services (Resend, job queues, monitoring)        │
│  • Infrastructure tools not exposed to users                   │
│  • Managed by: Development team                                │
│  • Examples: Email service, background processors              │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                      SERVICE TOOLS                              │
│  • 3rd party connections for system operation                  │
│  • Examples: VIN Solutions API, VAPI SDK, Tavus SDK, Twilio   │
│  • Managed by: Super Admin (credentials, configurations)       │
│  • Delegated to: Accounts via quota allocation                 │
└─────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────┐
│                     ACCOUNT TOOLS                               │
│  • What v1 called "agents" - now reclassified as tools         │
│  • Two types:                                                  │
│    - Prompt Templates (Lead Qualifier, Payment Calculator)     │
│    - Function Tools (CRM Lookup, VIN Decoder)                 │
│  • Announced by: Automa as available capabilities              │
│  • Managed by: Org Admins (enable/disable, configure)         │
└─────────────────────────────────────────────────────────────────┘
```

### 4.3 Agent Provisioning and Quota Management

**Provisioning Model:**

The system uses a quota-based provisioning approach rather than per-organization accounts. This enables cost-effective resource sharing while maintaining strict organizational isolation through metadata tagging.

**Key Implementation Decisions:**

1. **Master Account Approach**: Use client's existing VAPI and Tavus master accounts
2. **Resource Tagging**: All provisioned resources tagged with `nexxus_org_id` for isolation
3. **1:1 Mappings**:
   - Voice Agent → VAPI Assistant
   - Video Agent → Tavus Persona
4. **Template Duplication**: Pre-defined templates duplicated for faster org onboarding
5. **Automatic Provisioning**: Phone numbers provisioned automatically with quota checks

**Quota Management Schema:**

```sql
-- Service quotas per organization
CREATE TABLE service_quotas (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    service_type VARCHAR(50) NOT NULL, -- 'vapi', 'tavus'

    -- Quota definition
    quota JSONB NOT NULL, -- { phone_numbers: 5, assistants: 10, monthly_minutes: 5000 }
    used JSONB DEFAULT '{}', -- { phone_numbers: 2, assistants: 7, monthly_minutes: 1200 }

    -- Quota period
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    UNIQUE(organization_id, service_type, period_start)
);

-- Service resource allocations (track individual resources)
CREATE TABLE service_allocations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    service_type VARCHAR(50) NOT NULL,
    resource_type VARCHAR(50) NOT NULL, -- 'phone_number', 'assistant', 'replica', 'persona'

    -- External resource identification
    external_resource_id VARCHAR(255) NOT NULL, -- VAPI phone ID, Tavus replica ID
    external_metadata JSONB DEFAULT '{}',

    -- Nexxus mapping
    account_agent_id UUID REFERENCES account_agents(id),

    -- Status tracking
    status VARCHAR(20) DEFAULT 'active', -- 'active', 'suspended', 'deleted'
    allocated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    deallocated_at TIMESTAMP WITH TIME ZONE,

    UNIQUE(service_type, external_resource_id)
);

-- Indexes
CREATE INDEX idx_service_quotas_org_type ON service_quotas(organization_id, service_type);
CREATE INDEX idx_service_allocations_org ON service_allocations(organization_id, service_type);
```

**Provisioning Workflow:**

1. Check quota availability
2. Provision resource with organization metadata (`nexxus_org_id`)
3. Store allocation in `service_allocations` table
4. Update quota usage in `service_quotas`
5. Alert at 80% usage threshold

### 4.4 Agent Delegation and Sharing Model

**Account Agent Schema:**

```sql
CREATE TABLE account_agents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(100) NOT NULL, -- 'workflow', 'monitor', 'responder'

    -- Agent configuration
    triggers JSONB NOT NULL DEFAULT '[]',
    queries JSONB NOT NULL DEFAULT '[]',
    actions JSONB NOT NULL DEFAULT '[]',
    tools JSONB NOT NULL DEFAULT '[]',

    -- Service agent mappings
    vapi_assistant_id VARCHAR(255),
    tavus_persona_id VARCHAR(255),

    -- Management
    created_by_automa BOOLEAN DEFAULT false,
    is_shared BOOLEAN DEFAULT false,
    shared_users UUID[] DEFAULT '{}',

    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES users(id)
);

-- Agent sharing
CREATE TABLE account_agent_shares (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id UUID NOT NULL REFERENCES account_agents(id) ON DELETE CASCADE,
    shared_with_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    permission_level VARCHAR(20) DEFAULT 'execute', -- 'view', 'execute', 'modify'
    shared_by UUID NOT NULL REFERENCES users(id),
    shared_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

    UNIQUE(agent_id, shared_with_user_id)
);
```

**Permission Matrix:**

| Role | Create Account Agent | Modify Account Agent | Share to Users | Execute Agent |
|------|---------------------|---------------------|----------------|---------------|
| Super Admin | ✓ | ✓ | ✓ | ✓ |
| Partner Admin | ✓ | ✓ (own orgs) | ✓ | ✓ |
| Org Admin | ✓ | ✓ (own org) | ✓ | ✓ |
| Staff | ✗ | ✗ | ✗ | ✓ (if shared) |

### 4.5 Template Duplication Strategy

**VAPI Template Strategy:**

- Pre-defined VAPI assistants stored in `service_agent_templates` table
- On org onboarding: duplicate template → provision with org metadata
- Faster than per-org creation from scratch
- Each org gets isolated copy tagged with `nexxus_org_id`

**Tavus Template Strategy:**

- Pre-defined Tavus personas stored in `tavus_persona_templates` table
- Stock replicas reused across organizations
- Custom replicas created only when needed (quota-limited)
- Template duplication for consistent baseline configurations

**Template Schema:**

```sql
CREATE TABLE service_agent_templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    service_type VARCHAR(50) NOT NULL, -- 'vapi', 'tavus'
    name VARCHAR(255) NOT NULL,
    description TEXT,
    config_template JSONB NOT NULL,
    is_system_managed BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE tavus_persona_templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    system_prompt TEXT NOT NULL,
    context JSONB DEFAULT '{}',
    default_replica_id VARCHAR(255), -- Stock replica
    is_system_managed BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);
```

**Implementation Notes:**

- **Webhooks**: ENABLE_WEBHOOKS=false until go-live for both VAPI and Tavus
- **Retention**: 30-day recording retention with auto-reaper cron at 2:00 AM daily
- **Keys**: Use client's existing VAPI_MASTER_API_KEY and TAVUS_MASTER_API_KEY
- **Isolation**: All resources tagged with organization metadata for strict isolation

---


## 5. Functional Requirements

### 5.1 Main Chat / DealerBrain

> **Implementation Note (D-001):** v2 uses `claude-sonnet-4-20250514` (newer model with improved capabilities).

**REQ-CHAT-001** [P0]: The system SHALL integrate with ~~Claude 3.5 Sonnet (model: `claude-3-5-sonnet-20241022`)~~ **claude-sonnet-4-20250514** for real AI-powered chat responses.

**REQ-CHAT-002** [P0]: The chat interface SHALL include a "+" button that creates a new chat conversation thread.

**REQ-CHAT-003** [P0]: The system SHALL serve as the DealerBrain orchestration layer from SRS Section 4.2, handling context routing and tool definitions.

**Architecture:**

- **AI Model**: ~~Claude 3.5 Sonnet (`claude-3-5-sonnet-20241022`)~~ **claude-sonnet-4-20250514**
- **Orchestration**: DealerBrain layer coordinates tool calls, context routing, and multi-step workflows
- **Tool Integration**: Dynamic tool announcement based on organization configuration
- **Context Awareness**: Maintains conversation history and page context

**Database Schema:**

```sql
CREATE TABLE chat_conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(500),
    page_context JSONB DEFAULT '{}', -- Track where chat was initiated
    status VARCHAR(20) DEFAULT 'active', -- 'active', 'archived', 'deleted'
    last_message_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE chat_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id UUID NOT NULL REFERENCES chat_conversations(id) ON DELETE CASCADE,
    role VARCHAR(20) NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
    content TEXT NOT NULL,
    model VARCHAR(100), -- Track AI model used
    tokens_used INTEGER DEFAULT 0,
    tool_calls JSONB DEFAULT '[]', -- Track tool invocations
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_chat_conversations_user ON chat_conversations(user_id, status);
CREATE INDEX idx_chat_messages_conversation ON chat_messages(conversation_id, created_at);
```

**Acceptance Criteria:**

- User clicks "+" button → new chat conversation created
- Messages sent to Claude 3.5 Sonnet → real AI responses returned
- Tool calls properly logged in `tool_calls` JSONB field
- Token usage tracked per message
- Conversation history maintained across sessions

---

### 5.2 Drive / Artifacts

**REQ-DRIVE-001** [P0]: The system SHALL use local filesystem storage (`./storage/drive`) for artifact storage in v1.

**REQ-DRIVE-002** [P0]: The system SHALL enforce a 50MB maximum file size limit per file.

**REQ-DRIVE-003** [P0]: The system SHALL enforce a 1GB total storage quota per organization.

**REQ-DRIVE-004** [P1]: The system SHALL support the following file types: PDF, DOCX, XLSX, CSV, TXT, JPEG, PNG, GIF, WEBP, MP4, WEBM, ZIP.

**REQ-DRIVE-005** [P2]: The system SHALL NOT implement versioning in v1.

**Storage Architecture:**

- **Backend**: Local filesystem (`./storage/drive`)
- **Organization Isolation**: Files stored in org-specific directories
- **Quotas**: 50MB per file, 1GB per organization
- **AI Generation**: Support for AI-generated artifacts (PDF, Excel, CSV)
- **Security**: Safe file type whitelist, virus scanning (future)

**Database Schema:**

```sql
CREATE TABLE drive_folders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    parent_folder_id UUID REFERENCES drive_folders(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    path TEXT NOT NULL, -- Full path for quick lookups
    permissions JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES users(id)
);

CREATE TABLE drive_artifacts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    folder_id UUID REFERENCES drive_folders(id),
    conversation_id UUID REFERENCES conversations(id), -- If generated from conversation

    name VARCHAR(500) NOT NULL,
    file_type VARCHAR(100) NOT NULL,
    mime_type VARCHAR(100),
    file_size INTEGER NOT NULL, -- In bytes
    file_path TEXT NOT NULL, -- Relative to storage root
    storage_type VARCHAR(20) DEFAULT 'local', -- 'local', 's3', 'supabase' (future)

    -- AI generation metadata
    generated_by_ai BOOLEAN DEFAULT false,
    generation_prompt TEXT,
    generation_model VARCHAR(100),

    -- Access control
    is_shared BOOLEAN DEFAULT false,
    shared_with UUID[] DEFAULT '{}',

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES users(id)
);

-- Indexes
CREATE INDEX idx_drive_folders_org ON drive_folders(organization_id, parent_folder_id);
CREATE INDEX idx_drive_artifacts_org ON drive_artifacts(organization_id, folder_id);
CREATE INDEX idx_drive_artifacts_size ON drive_artifacts(organization_id, file_size);
```

**Acceptance Criteria:**

- Files uploaded to local filesystem successfully
- 50MB file size limit enforced with clear error message
- Organization storage quota tracked and enforced
- Unsupported file types rejected
- AI-generated artifacts saved with metadata

---

### 5.3 Hunches

**REQ-HUNCH-001** [P1]: The system SHALL generate hunches via AI-powered analysis using Claude 3.5 Sonnet.

**REQ-HUNCH-002** [P1]: The system SHALL support both scheduled (hourly, daily) and real-time hunch generation triggers.

**REQ-HUNCH-003** [P1]: The system SHALL allow users to configure custom analysis instructions per hunch type.

**REQ-HUNCH-004** [P0]: The system SHALL implement an RLHF-style approval workflow for hunch acceptance.

**REQ-HUNCH-005** [P1]: The system SHALL integrate with Context Router to pull data from conversations, leads, goals, and VIN Solutions.

**Generation Architecture:**

- **AI Engine**: Claude 3.5 Sonnet for analysis
- **Data Sources**: Context Router queries across conversations, leads, metrics, VIN reports
- **Triggers**:
  - Scheduled: Cron jobs (hourly, daily deep analysis)
  - Real-time: Event-driven (new lead, conversation end, goal milestone)
- **Approval**: RLHF workflow with approve/reject/dismiss actions
- **Feedback Loop**: Rejection feedback stored for future ML training

**Database Schema:**

```sql
CREATE TABLE hunch_configs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    instructions TEXT NOT NULL, -- User-configured analysis instructions
    schedule VARCHAR(50), -- 'hourly', 'daily', 'real_time', 'manual'
    data_sources JSONB NOT NULL, -- Which data to analyze
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES users(id)
);

CREATE TABLE hunches (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    config_id UUID REFERENCES hunch_configs(id),

    title VARCHAR(500) NOT NULL,
    summary TEXT NOT NULL,
    confidence DECIMAL(3,2) CHECK (confidence BETWEEN 0 AND 1),
    reasoning TEXT NOT NULL, -- AI's explanation
    suggested_actions JSONB DEFAULT '[]',
    data_snapshot JSONB DEFAULT '{}', -- Raw data used for analysis

    status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'approved', 'rejected', 'dismissed', 'acted'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE hunch_approvals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hunch_id UUID NOT NULL REFERENCES hunches(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id),
    action VARCHAR(20) NOT NULL CHECK (action IN ('approved', 'rejected', 'dismissed', 'acted')),
    feedback TEXT, -- User feedback for RLHF
    approved_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_hunch_configs_org ON hunch_configs(organization_id, status);
CREATE INDEX idx_hunches_org_status ON hunches(organization_id, status);
CREATE INDEX idx_hunch_approvals_hunch ON hunch_approvals(hunch_id);
```

**Acceptance Criteria:**

- Hourly cron job generates hunches based on active configs
- Real-time triggers create hunches on qualifying events
- Hunches display with confidence score and reasoning
- Users can approve, reject, dismiss, or act on hunches
- Rejection feedback stored for future training

---

### 5.4 Approvals

**REQ-APPR-001** [P0]: The system SHALL require approval for all AI-generated hunches (RLHF workflow).

**REQ-APPR-002** [P0]: The system SHALL require approval for all external customer communications (emails, SMS, calls).

**REQ-APPR-003** [P1]: The system SHALL implement simple approve/reject workflow (not complex multi-step).

**REQ-APPR-004** [P1]: The system SHALL support role-based approval routing.

**Approval Types:**

1. **Hunch Acceptance**: RLHF-style approval before acting on AI recommendations
2. **External Communications**: Safety check before sending customer-facing content
3. **Future**: Agent actions, budget approvals, data access requests

**Database Schema:**

```sql
CREATE TABLE approval_workflows (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    workflow_type VARCHAR(100) NOT NULL, -- 'hunch', 'external_communication', 'agent_action'
    name VARCHAR(255) NOT NULL,
    config JSONB NOT NULL, -- Workflow rules
    required_approvers JSONB DEFAULT '[]', -- Role IDs or user IDs
    timeout_hours INTEGER DEFAULT 24,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE approval_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    workflow_id UUID NOT NULL REFERENCES approval_workflows(id),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,

    request_type VARCHAR(100) NOT NULL,
    target_id UUID NOT NULL, -- ID of thing being approved (hunch_id, message_id, etc.)
    target_data JSONB DEFAULT '{}', -- Snapshot of data for review

    requested_by UUID NOT NULL REFERENCES users(id),
    status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'approved', 'rejected', 'timeout'

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    resolved_at TIMESTAMP WITH TIME ZONE
);

CREATE TABLE approval_actions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    request_id UUID NOT NULL REFERENCES approval_requests(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id),
    action VARCHAR(20) NOT NULL CHECK (action IN ('approved', 'rejected')),
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_approval_requests_status ON approval_requests(status, created_at);
CREATE INDEX idx_approval_requests_org ON approval_requests(organization_id, status);
CREATE INDEX idx_approval_actions_request ON approval_actions(request_id);
```

**Acceptance Criteria:**

- Hunches create approval requests before action
- External communications routed to appropriate approver
- Approvers receive notifications
- Approval/rejection updates target entity status
- Timeout mechanism for stale requests

---

### 5.5 Communication / Inbox

**REQ-INBOX-001** [P0]: The system SHALL use Resend for email delivery (NOT SendGrid).

**REQ-INBOX-002** [P1]: The system SHALL support SMS delivery (future phase).

**REQ-INBOX-003** [P0]: The system SHALL deliver real-time notifications via SSE (Server-Sent Events).

**REQ-INBOX-004** [P2]: The system SHALL support mobile push notifications (future phase).

**Communication Channels:**

- **Email**: Resend integration for transactional and notification emails
- **SMS**: Planned for future phase (Twilio integration)
- **In-App Notifications**: SSE delivery for real-time updates
- **Mobile Push**: Planned for Phase 2

**Notification Events:**

- New hunch generated
- Approval request assigned
- Task assigned or due
- Lead status change
- System alerts and errors

**Acceptance Criteria:**

- Emails sent via Resend API successfully
- SSE connection established for real-time notifications
- Users receive notifications for relevant events
- Notification preferences configurable per user

---

### 5.6 Billing

**REQ-BILL-001** [P1]: The system SHALL generate PDF invoices for billing periods.

**REQ-BILL-002** [P1]: The system SHALL support manual billing by Super Admins only.

**REQ-BILL-003** [P2]: The system SHALL NOT integrate with Stripe in v1.

**REQ-BILL-004** [P0]: The system SHALL track credit usage per organization for all services.

**Billing Model:**

- **v1 Approach**: PDF invoice generation, manual super admin billing
- **No Stripe**: Payment processing handled outside platform in v1
- **Credit Tracking**: Full tracking of usage across voice, video, SMS, tokens
- **Future**: Stripe integration, automated billing, self-service

**Credit Usage Tracking:**

- Voice minutes via VAPI
- Video sessions via Tavus
- SMS messages
- AI tokens (Claude usage)

**Acceptance Criteria:**

- PDF invoices generated with usage breakdown
- Super Admins can view all organization billing
- Credit usage tracked accurately per service type
- Usage reports exportable for accounting

---

### 5.7 Users Management

**REQ-USER-001** [P0]: Super Admins and Partner Admins SHALL be able to create users across organizations.

**REQ-USER-002** [P0]: Org Admins SHALL be able to create users within their organization only.

**REQ-USER-003** [P0]: The system SHALL implement RBAC with four role levels (Super/Partner/Org Admin/Staff).

**REQ-USER-004** [P1]: The system SHALL support user invitation via email.

**User Creation Matrix:**

| Creator Role | Can Create | Scope |
|--------------|-----------|-------|
| Super Admin | All roles | All organizations |
| Partner Admin | Org Admin, Staff | Partner's organizations |
| Org Admin | Staff | Own organization only |
| Staff | None | N/A |

**Acceptance Criteria:**

- Users created with appropriate role and organization assignment
- Email invitations sent with secure signup links
- RBAC enforced across all platform features
- User profiles editable by admins and self

---

### 5.8 Notifications

> **Implementation Note (D-002):** v2 uses WebSocket (Socket.IO) instead of SSE. WebSocket provides bidirectional communication, better suited for multiple event types. See `/docs/specifications/DECISIONS_LOG.md`.

**REQ-NOTIF-001** [P0]: The system SHALL deliver real-time notifications via ~~SSE (Server-Sent Events)~~ **WebSocket (Socket.IO)** in v1.

**REQ-NOTIF-002** [P1]: The system SHALL support event-driven notification triggers.

**REQ-NOTIF-003** [P2]: The system SHALL support mobile push notifications in Phase 2.

**Notification Delivery:**

- **v1**: ~~SSE (Server-Sent Events)~~ **WebSocket (Socket.IO)** for web-based real-time updates
- **Future**: Mobile push via Firebase/APNs
- **Event Triggers**: Task assignments, approvals, hunches, lead changes

**Acceptance Criteria:**

- SSE connection established on login
- Notifications appear in real-time without page refresh
- Notification history accessible in Inbox
- Users can mark notifications as read/unread

---

### 5.9 Service Integrations

#### 5.9.1 VAPI Integration

**REQ-VAPI-001** [P0]: The system SHALL use client's existing VAPI_MASTER_API_KEY.

**REQ-VAPI-002** [P0]: The system SHALL set ENABLE_WEBHOOKS=false until go-live.

**REQ-VAPI-003** [P0]: The system SHALL implement 30-day recording retention.

**REQ-VAPI-004** [P0]: The system SHALL run auto-reaper cron at 2:00 AM daily to delete old recordings.

**REQ-VAPI-005** [P1]: The system SHALL use template duplication strategy for faster org onboarding.

**Implementation Details:**

- **API Key**: Client's existing VAPI master account key
- **Webhooks**: Disabled pre-launch for safety (`ENABLE_WEBHOOKS=false`)
- **Retention**: 30-day automatic cleanup via cron job at 2:00 AM
- **Provisioning**: Automatic phone number provisioning with quota checks
- **Templates**: Pre-defined assistants duplicated per organization

---

#### 5.9.2 Tavus Integration

**REQ-TAVUS-001** [P0]: The system SHALL use client's existing TAVUS_MASTER_API_KEY.

**REQ-TAVUS-002** [P1]: The system SHALL use template duplication strategy for personas.

**REQ-TAVUS-003** [P0]: The system SHALL implement 30-day recording retention.

**Implementation Details:**

- **API Key**: Client's existing Tavus master account key
- **Templates**: Pre-defined personas duplicated per organization
- **Retention**: 30-day automatic cleanup
- **Stock Replicas**: Reused across organizations (custom replicas quota-limited)

---

#### 5.9.3 VIN Solutions Integration

**REQ-VIN-001** [P0]: The system SHALL use OAuth 2.0 Client Credentials for VIN Solutions authentication.


## 6. Non-Functional Requirements

### 6.1 Performance Requirements

**REQ-PERF-001** [P0]: The system SHALL respond to user interactions within 2 seconds.

**REQ-PERF-002** [P0]: DealerBrain SHALL provide AI responses within 3 seconds for standard queries.

**REQ-PERF-003** [P0]: All pages SHALL load within 2 seconds on standard broadband connections.

**REQ-PERF-004** [P0]: The system SHALL support 1,000+ concurrent users per organization without degradation.

**Performance Targets:**

| Metric | Target | Measurement |
|--------|--------|-------------|
| Page Response Time | < 2s | P95 percentile |
| AI Response Time | < 3s | P95 percentile |
| Page Load Time | < 2s | P95 percentile |
| API Response Time | < 500ms | P95 percentile |
| Database Query Time | < 100ms | P95 percentile |

---

### 6.2 Scalability Requirements

**REQ-SCALE-001** [P0]: The system SHALL horizontally scale to support 10,000+ organizations.

**REQ-SCALE-002** [P0]: The system SHALL handle 100TB+ of conversation and artifact data.

**REQ-SCALE-003** [P0]: The system SHALL process 10,000+ API requests per minute.

**REQ-SCALE-004** [P1]: The system SHALL support auto-scaling based on load metrics.

**Scalability Targets:**

- **Organizations**: 10,000+ with isolated data
- **Data Volume**: 100TB+ with efficient indexing
- **API Throughput**: 10,000+ requests/minute
- **Concurrent Users**: 100,000+ across all organizations
- **Database Connections**: Pool management for optimal performance

---

### 6.3 Availability Requirements

**REQ-AVAIL-001** [P0]: The system SHALL maintain 99.5% uptime (excluding planned maintenance).

**REQ-AVAIL-002** [P0]: Planned maintenance windows SHALL be scheduled during off-peak hours with 48-hour notice.

**REQ-AVAIL-003** [P0]: The system SHALL implement automated backups with 15-minute Recovery Point Objective (RPO).

**REQ-AVAIL-004** [P0]: The system SHALL achieve 4-hour Recovery Time Objective (RTO) for critical systems.

**Availability Targets:**

- **Uptime**: 99.5% (43.8 hours downtime/year maximum)
- **RPO**: 15 minutes (maximum data loss)
- **RTO**: 4 hours (maximum recovery time)
- **Backup Frequency**: Continuous with 15-minute snapshots
- **Disaster Recovery**: Multi-region failover capability

---

### 6.4 Security Requirements

**REQ-SEC-001** [P0]: All data SHALL be encrypted at rest using AES-256 encryption.

**REQ-SEC-002** [P0]: All data in transit SHALL be encrypted using TLS 1.3.

**REQ-SEC-003** [P0]: Multi-factor authentication (MFA) SHALL be required for administrative users.

**REQ-SEC-004** [P0]: The system SHALL implement comprehensive audit logging for all sensitive operations.

**REQ-SEC-005** [P0]: The system SHALL comply with GDPR, CCPA, and HIPAA requirements.

**Security Controls:**

- **Encryption**: AES-256 at rest, TLS 1.3 in transit
- **Authentication**: JWT-based with MFA for admins
- **Authorization**: Row-Level Security (RLS) in PostgreSQL
- **Audit Logging**: All data access and modifications logged
- **Compliance**: GDPR, CCPA, HIPAA readiness
- **Vulnerability Management**: Regular security scans and penetration testing

---

## 7. System Architecture

### 7.1 Technical Stack

**Frontend:**
- Next.js 14 with App Router
- TypeScript for type safety
- Tailwind CSS for styling
- Zustand for state management
- React Query for data fetching
- Tremor for data visualization
- Shadcn/ui for component library

**Backend:**
- Supabase (PostgreSQL + Real-time + Auth)
- Node.js/Express for API services
- pgvector for vector search capabilities
- Redis for caching and session management
- Bull for job queue management

**AI & Integration:**
- Claude 3.5 Sonnet (`claude-3-5-sonnet-20241022`) for primary language model
- GPT-4 for specialized tasks
- VAPI for voice processing (client's existing VAPI_MASTER_API_KEY)
- Tavus for video generation (client's existing TAVUS_MASTER_API_KEY)
- Resend for email delivery
- Custom MCP server integration

**Infrastructure:**
- Vercel for frontend deployment
- Supabase Cloud for backend services
- CloudFlare for CDN and DDoS protection
- Local filesystem for Drive storage (v1, migrate to S3/Supabase in v2)
- Redis Cloud for caching
- GitHub Actions for CI/CD

---

### 7.2 Data Flow Architecture

```
User Interface → DealerBrain → Service Layer → Integration APIs
      ↓              ↓              ↓                ↓
State Management → Context Router → Data Warehouse → External Systems
      ↓              ↓              ↓                ↓
Local Cache → Memory Layer → Supabase PostgreSQL → VIN/VAPI/Tavus
```

**Data Flow Patterns:**

1. **User Request**: Frontend → API Gateway → Service Layer
2. **AI Processing**: DealerBrain → Claude API → Response Processing
3. **Data Persistence**: Service Layer → Supabase → PostgreSQL
4. **External Sync**: Context Router → VIN/VAPI/Tavus APIs
5. **Real-time Updates**: Supabase Real-time → SSE → Frontend

---

### 7.3 Security Architecture

**Defense-in-Depth Layers:**

1. **Network Security**: CloudFlare DDoS protection, WAF rules
2. **Application Security**: JWT authentication, API rate limiting
3. **Data Security**: Encryption at rest (AES-256), in transit (TLS 1.3)
4. **Database Security**: Row-Level Security (RLS), prepared statements
5. **Audit Security**: Comprehensive logging, intrusion detection

**JWT-Based Authentication:**

```typescript
interface JWTPayload {
  user_id: UUID;
  organization_id: UUID; // CRITICAL for data isolation
  role_id: UUID;
  permissions: string[];
  exp: number;
  iat: number;
}
```

**Row-Level Security (RLS) Implementation:**

```sql
-- Example RLS policy for conversations
CREATE POLICY org_isolation ON conversations
  USING (organization_id = current_setting('app.current_organization_id')::uuid);

-- Application sets session variable from JWT
SET LOCAL app.current_organization_id = '<org_id_from_jwt>';
```

---

### 7.4 Context Router Architecture

**Context Router: Bidirectional Data Flow & Isolation**

The Context Router is the intelligent data orchestration layer that manages data flows between Nexxus, VIN Solutions, VAPI, Tavus, and other external systems while enforcing strict organizational isolation.

**Core Responsibilities:**

1. **Data Isolation**: Zero cross-contamination between customer accounts
2. **Intelligent Routing**: Direct queries to optimal data source based on context
3. **Data Labeling**: All data tagged with organization/location for strict isolation
4. **Audit Trail**: Complete visibility into data flows for security and compliance

**Bidirectional Data Flow Model:**

```
┌────────────────────────────────────────────────────────────────┐
│                      CONTEXT ROUTER                             │
│            (Intelligent Data Orchestrator)                      │
└───┬────────────────────────────────────────────────────────────┬───┘
    │                                                        │
    │ OUTBOUND FLOW                          INBOUND FLOW   │
    │ (Nexxus → External)              (External → Nexxus)  │
    ▼                                                        ▼
┌─────────────────────┐                    ┌─────────────────────┐
│  Nexxus Database    │◄───────────────────┤  External Systems   │
│  (Source of Truth)  │    Sync Back       │  (VIN, VAPI, Tavus) │
└─────────────────────┘                    └─────────────────────┘
    │                                                        │
    │ Query for context                    Webhook events   │
    ▼                                                        ▼
┌─────────────────────────────────────────────────────────────────┐
│            DATA ISOLATION ENFORCEMENT LAYER                      │
│  • organization_id validation on ALL queries                    │
│  • Row-Level Security (RLS) in PostgreSQL                       │
│  • API request scoping via JWT claims                           │
│  • Audit logging for cross-org access attempts                  │
└─────────────────────────────────────────────────────────────────┘
```

**Outbound Data Flow (Nexxus → External):**

Use Case: AI conversation ends → Sync lead to VIN Solutions

1. Extract organization_id from authenticated user context (JWT)
2. Validate user has permission to access conversation
3. Create lead with organization_id LOCKED IN (immutable)
4. Enqueue sync job with organization context propagated
5. Retrieve organization-specific VIN credentials
6. Push to VIN Solutions with org-specific client
7. Update lead with external_id
8. Log success with full audit context

**Inbound Data Flow (External → Nexxus):**

Use Case: VAPI webhook receives call completion → Store conversation

1. Extract organization from VAPI phone number or assistant ID
2. Validate organization exists and is active
3. Create conversation WITH organization context locked in
4. Create messages (organization_id inherited via FK)
5. Track credit usage with organization context
6. Return webhook acknowledgment

**Data Isolation Enforcement:**

1. **Row-Level Security (RLS)**: PostgreSQL policies enforce organization_id filtering
2. **API Request Scoping**: JWT claims provide organization context to all requests
3. **Secure Query Builder**: All queries require organization_id, never optional
4. **Audit Logging**: Cross-org access attempts logged as security events

---

**REQ-VIN-002** [P0]: The system SHALL be production-ready and certified with VinSolutions.

**REQ-VIN-003** [P1]: The system SHALL support bidirectional sync (Nexxus → VIN outbound Phase 1, VIN → Nexxus inbound Phase 2).


## 8. Data Model & Entity Relationship Diagram

### 8.1 Entity Relationship Diagram (Text Format)

```
Organizations ||--o{ Locations : contains
Organizations ||--o{ Users : employs
Organizations ||--o{ Integrations : configures
Organizations ||--o{ Credit_Policies : defines
Organizations ||--o{ Service_Quotas : allocates

Locations ||--o{ Users : assigns
Locations ||--o{ Conversations : hosts
Locations ||--o{ Agents : deploys

Users }o--|| Roles : has
Users ||--o{ Chat_Conversations : initiates
Users ||--o{ Conversations : participates
Users ||--o{ Tasks : owns
Users ||--o{ Audit_Log : generates

Agents ||--o{ Skills : uses
Agents ||--o{ Agent_Runs : executes
Agents ||--o{ Conversations : handles

Account_Agents ||--o{ Service_Allocations : uses
Account_Agents ||--o{ Account_Agent_Shares : shared_via

Conversations ||--o{ Messages : contains
Conversations ||--o{ Tasks : generates
Conversations ||--o{ Artifacts : produces

Chat_Conversations ||--o{ Chat_Messages : contains

Drive_Folders ||--o{ Drive_Artifacts : contains
Drive_Folders ||--o{ Drive_Folders : nests

Hunch_Configs ||--o{ Hunches : generates
Hunches ||--o{ Hunch_Approvals : requires

Approval_Workflows ||--o{ Approval_Requests : defines
Approval_Requests ||--o{ Approval_Actions : receives

Credit_Policies ||--o{ Credit_Allocations : defines
Credit_Allocations ||--o{ Credit_Usage : tracks

Service_Quotas ||--o{ Service_Allocations : manages

Dashboards ||--o{ Widgets : contains
Goals ||--o{ Tasks : tracked_by
Leads ||--o{ Conversations : sources
```

### 8.2 Table Definitions

*Note: The following sections provide complete SQL DDL for all database tables. Tables marked with [NEW] are additions for v3.0.*

#### 8.2.1 Organizations

```sql
CREATE TABLE organizations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    type VARCHAR(50) NOT NULL CHECK (type IN ('dealership', 'dealer_group', 'vendor')),
    settings JSONB DEFAULT '{}',
    billing_info JSONB,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES users(id),
    updated_by UUID REFERENCES users(id)
);

CREATE INDEX idx_organizations_status ON organizations(status);
CREATE INDEX idx_organizations_slug ON organizations(slug);

-- Enable RLS
ALTER TABLE organizations ENABLE ROW LEVEL SECURITY;
```

#### 8.2.2 Locations

```sql
CREATE TABLE locations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    address JSONB,
    timezone VARCHAR(50) DEFAULT 'America/New_York',
    business_hours JSONB,
    contact_info JSONB,
    settings JSONB DEFAULT '{}',
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_locations_org ON locations(organization_id);
CREATE INDEX idx_locations_status ON locations(status);

ALTER TABLE locations ENABLE ROW LEVEL SECURITY;
```

#### 8.2.3 Users

```sql
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    location_id UUID REFERENCES locations(id),
    email VARCHAR(320) UNIQUE NOT NULL,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    role_id UUID NOT NULL REFERENCES roles(id),
    settings JSONB DEFAULT '{}',
    last_login TIMESTAMP WITH TIME ZONE,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_users_org ON users(organization_id);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role_id);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;
```

#### 8.2.4 Roles

```sql
CREATE TABLE roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL,
    level INTEGER NOT NULL CHECK (level IN (1,2,3,4)), -- 1=System, 2=Partner, 3=Customer, 4=Staff
    permissions JSONB NOT NULL DEFAULT '{}',
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_roles_level ON roles(level);
```

#### 8.2.5 Integrations

```sql
CREATE TABLE integrations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    type VARCHAR(50) NOT NULL, -- 'vin_solutions', 'vapi', 'tavus', 'google_calendar', 'resend'
    config JSONB NOT NULL,
    credentials JSONB, -- Encrypted
    status VARCHAR(20) DEFAULT 'inactive',
    last_sync TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_integrations_org_type ON integrations(organization_id, type);

ALTER TABLE integrations ENABLE ROW LEVEL SECURITY;
```

#### 8.2.6 Conversations

```sql
CREATE TABLE conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    location_id UUID REFERENCES locations(id),
    type VARCHAR(50) NOT NULL, -- 'voice', 'video', 'chat', 'sms', 'email'
    channel VARCHAR(100), -- Source channel identifier
    customer_info JSONB,
    agent_id UUID REFERENCES agents(id),
    user_id UUID REFERENCES users(id),
    status VARCHAR(20) DEFAULT 'active',
    metadata JSONB DEFAULT '{}',
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    ended_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_conversations_org ON conversations(organization_id);
CREATE INDEX idx_conversations_type ON conversations(type);
CREATE INDEX idx_conversations_dates ON conversations(started_at, ended_at);

ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
```

#### 8.2.7 Messages

```sql
CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
    sender_type VARCHAR(20) NOT NULL CHECK (sender_type IN ('user', 'agent', 'system')),
    sender_id UUID,
    content TEXT NOT NULL,
    content_type VARCHAR(50) DEFAULT 'text',
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_messages_conversation ON messages(conversation_id, created_at);
```

#### 8.2.8 Chat_Conversations [NEW]

```sql
CREATE TABLE chat_conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(500),
    page_context JSONB DEFAULT '{}', -- Track where chat was initiated
    status VARCHAR(20) DEFAULT 'active', -- 'active', 'archived', 'deleted'
    last_message_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_chat_conversations_user ON chat_conversations(user_id, status);
CREATE INDEX idx_chat_conversations_org ON chat_conversations(organization_id);

ALTER TABLE chat_conversations ENABLE ROW LEVEL SECURITY;
```

#### 8.2.9 Chat_Messages [NEW]

```sql
CREATE TABLE chat_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    conversation_id UUID NOT NULL REFERENCES chat_conversations(id) ON DELETE CASCADE,
    role VARCHAR(20) NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
    content TEXT NOT NULL,
    model VARCHAR(100), -- Track AI model used (e.g., 'claude-3-5-sonnet-20241022')
    tokens_used INTEGER DEFAULT 0,
    tool_calls JSONB DEFAULT '[]', -- Track tool invocations
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_chat_messages_conversation ON chat_messages(conversation_id, created_at);
```

#### 8.2.10 Agents

```sql
CREATE TABLE agents (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    organization_id UUID NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    type VARCHAR(50) NOT NULL, -- 'voice', 'video', 'chat', 'task'
    config JSONB NOT NULL DEFAULT '{}',
    status VARCHAR(20) DEFAULT 'active',
    performance_metrics JSONB DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_by UUID REFERENCES users(id)
);

CREATE INDEX idx_agents_org ON agents(organization_id);
CREATE INDEX idx_agents_type ON agents(type);

ALTER TABLE agents ENABLE ROW LEVEL SECURITY;
```

*[Continuing with remaining tables 8.2.11-8.2.33 in next insert...]*

---

**Implementation Details:**

- **Authentication**: OAuth 2.0 Client Credentials Grant
- **Certification**: Production-ready, certified integration
- **Data Flow**: Context Router manages bidirectional sync with organization isolation
- **Caching**: VIN report uploads cached for historical query support beyond 48-hour API window

**Acceptance Criteria:**

- VIN OAuth tokens refreshed automatically
- Lead data synced to VIN Solutions successfully
- VIN report uploads parsed and cached
- Organization isolation enforced on all VIN data

---

## Addendum Chain

> **IMPORTANT**: This SRS v3.0 is the base document. Additional requirements are captured in chained addendums. Always read the full addendum chain for current requirements.

| Document | Version | Date | Focus |
|----------|---------|------|-------|
| This Document | v3.0 MASTER | January 30, 2026 | Base requirements |
| Addendum v3.1 | 3.1-ADD1 | February 3, 2026 | MVP Critical (Chat UX, VAPI/Tavus Insights, Context Router clarifications) |
| Addendum v3.2 | 3.2-ADD2 | February 3, 2026 | Widget, SMS Integration, Staff Inbox, Agent Triggers |

**Critical Clarification (Addendum v3.1):**
- VIN Solutions integration is **QUERY-ONLY** (not bidirectional sync)
- Hourly polling for new leads is permitted
- Context Router aggregates data from queries + report uploads

**See:** `docs/Nexxus_SRS_Addendum_v3.1_MVP_Critical.md` and `docs/Nexxus_SRS_Addendum_v3.2_Widget_SMS_Notifications.md`
