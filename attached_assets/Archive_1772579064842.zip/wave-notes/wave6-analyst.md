# Wave 6 Analyst: Agent Rules Extraction (CLAUDE.md)

**Date:** 2026-03-03
**Analyst:** Claude Opus 4.6
**Input Files Scanned:** 25 of 53 (all files containing CLAUDE.md-relevant rules)
**Purpose:** Extract all agent operating rules for the new consolidated CLAUDE.md

---

## 1. Truth Hierarchy

### 1a. Document Truth Hierarchy (What Agents Read)

**Source:** UNIFIED_HANDOFF_PROMPT.md (Section 2, "Conflict Resolution Rule")
> "When documents conflict: New UI Design > ACCEPTANCE_CRITERIA > UNIFIED_HANDOFF_PROMPT > Constitution > Audit Files > NEW_SRS > Implementation Plan"

**Source:** session-knowledge.md (Section 0, "Platform Mental Model")
> Owner stated: RUI (Replit Reference UI) is Tier 1 truth. Immutable spec -- can be added to, never modified.

**Source:** CLAUDE.md (pre-enforcer, Section 3)
> "4 Governing Documents (in priority order): 1. Constitution, 2. Master SRS, 3. Current-State Assessment, 4. Implementation Plan"

**Source:** opinions_facts.md.md (Rule 3)
> "Before each run, explicitly confirm which file is Tier 1 / Tier 2 in effect."

**Consolidated Document Truth Hierarchy:**
1. RUI Mockup (visual spec, immutable -- can add, never modify)
2. ACCEPTANCE_CRITERIA.md (testable statements)
3. CLAUDE.md (agent operating rules)
4. CONSTITUTION.md / PRD.md (identity, principles)
5. SRS.md (system behavior narrative)
6. SPEC.md (architecture)
7. PLAN.md (marching orders)

### 1b. Data Truth Hierarchy (Runtime Data Conflicts)

**Source:** CONSTITUTION.md (Section 2.1)

| Priority | Source | Authoritative For |
|----------|--------|-------------------|
| 1 | VIN Solutions API | Leads, statuses, sources, types, CRM users |
| 2 | VAPI / Tavus APIs | AI call and video session data |
| 3 | Local Database | Nexxus-only data: tasks, goals, agents, preferences, activity |
| 4 | Derived Metrics | Computed from above; never cached as truth |

**Rule (CONSTITUTION.md 2.1):** "If VIN API returns data that differs from the local database, VIN wins. Update local to match. Derived metrics are recomputed on demand, not stored as authoritative values."

**Source:** MASTER_SRS.md (Section 7.1) -- confirms identical hierarchy.

---

## 2. Document Reading Order

### 2a. Every-Session Reading Order

**Source:** UNIFIED_HANDOFF_PROMPT.md (Section 2, 6-tier reading order)

| Tier | What | Why |
|------|------|-----|
| Tier 1 | Forensic audit files (server-audit, database-audit, client-audit, health-audit) | What actually exists in code |
| Tier 2 | Carry-forward and freeze lists (CARRY_FORWARD_MANIFEST, DO_NOT_TOUCH) | What to preserve and what not to touch |
| Tier 3 | Lessons and operational knowledge (DEVELOPMENT_TEAM_BRIEFING) | Hard-won lessons, avoid past mistakes |
| Tier 4 | Design specifications (ACCEPTANCE_CRITERIA, designer handoffs) | What to build |
| Tier 5 | Governance documents (CLAUDE.md, CONSTITUTION/PRD, SRS, PLAN) | Rules and principles |
| Tier 6 | Reference material (Agent Instructions, metric formulas) | Deep reference |

**Source:** CLAUDE.md (pre-enforcer, "How to Continue Work")
> "1. Read session-state.md, 2. Read the 4 governing documents, 3. Read docs/BRAIN_DUMP.md, 4. Create feature branch"

**Source:** Standards.md (owner's definition)
> CLAUDE.md and PLAN.md are "read every session." PRD, SRS, SPEC, AC are "reference."

**Consolidated for new CLAUDE.md:**
Every session, agents MUST read:
1. CLAUDE.md (this file -- rules and conventions)
2. PLAN.md (current phase, what to do next)
3. Session state from memory directory (what was in progress)

Read when relevant:
4. ACCEPTANCE_CRITERIA.md (when testing or building features)
5. SRS.md (when understanding system behavior)
6. SPEC.md (when understanding architecture)
7. PRD.md (when understanding business context)
8. DO_NOT_TOUCH list (when modifying files)

### 2b. Files That Are NOT Governance (Do Not Treat As Authority)

**Source:** session-knowledge.md (Section 1, "/init Impact")

| Directory | What It Is | Authority Status |
|-----------|-----------|-----------------|
| `.project/` | /plan mode scratch only | NOT authoritative |
| `.agent_docs/` | Enforcer workspace | Operational reference for enforcer only |
| `filestore/` | Historical input files | INPUT, not governance |
| `docs/archive/` | Archived materials | HISTORICAL, not current truth |

---

## 3. Naming Conventions

### 3a. Platform Naming

**Source:** CONSTITUTION.md (Section 4, "Naming Conventions")

| Concept | Internal Name | User-Facing Name |
|---------|--------------|-----------------|
| AI assistant framework | DealerBrain | (not shown -- underlying concept) |
| Master AI agent | Automa | Automa |
| Voice AI calls | VAPI integration | Voice Agent |
| Video AI sessions | Tavus integration | Video Agent |
| AI chat | DealerBrain chat | (context-dependent label) |
| Agent capabilities | Tools | Skills |
| Work management | Hub | Work Center |

**Source:** MASTER_SRS.md (Section 2.4)
> "DealerBrain is not a sidebar link. Automa is always at the top of the agents list."
> "Skills = agent capabilities (renamed from 'Tools' in UI)"

### 3b. Prohibited Vendor Names in UI

**Source:** CONSTITUTION.md (Section 3.1)
> "Never expose vendor names to end users -- no 'Tavus', 'Vapi', or 'VAPI' in any customer-facing UI"
> "Use role-appropriate labels: 'Voice Agent', 'Video Agent', 'AI Assistant'"
> "No source labels in UI -- customers do not need to see 'VIN API', 'Local + VIN'"

**Source:** MASTER_SRS.md (Section 5.2, Locked Decision)
> "REMOVE all source labels from UI (no 'local+vin' or other source attribution visible to users)"

**Source:** IMPLEMENTATION_PLAN.md (Phase 1.1-1.2)
> Specific file/line references for 9 vendor name leaks to fix.

### 3c. Feature Branch Naming

**Source:** CLAUDE.md (pre-enforcer, "Feature Branch Workflow")
> Branch format: `feature/phase-{N}-{name}`

### 3d. RBAC System Values

**Source:** MASTER_SRS.md (Section 3.1)

| Role | System Value | Level |
|------|-------------|-------|
| Super Admin | `super_admin` | 1 |
| Partner Admin | `partner_admin` | 2 |
| Org Admin | `org_admin` | 3 |
| Staff | `org_staff` | 4 |

---

## 4. Backend Freeze Rules

### 4a. Scope of Freeze

**Source:** DO_NOT_TOUCH.md (complete document, 662 lines)

**Summary Statistics:**
| Category | File Count |
|----------|-----------|
| Server core + routes + services + middleware + auth + webhooks + websocket + jobs + utils | 88 files |
| Database migrations + support | 38 files |
| Shared schema | 1 file |
| Widget | 17 files |
| Build system | 2 files |
| Root config files | 15 files |
| Tests | 65 files |
| Scripts | 19 files |
| Documentation | 100+ files |
| **Total DO NOT TOUCH** | **345+ files** |
| **Safe to modify (client/)** | **~130 files** |

### 4b. The Golden Rule

**Source:** DO_NOT_TOUCH.md (opening rule)
> "If a file is not explicitly listed in Section 7 ('SAFE TO MODIFY'), it must not be modified. When in doubt, do not touch it."

### 4c. What IS Safe to Modify

**Source:** DO_NOT_TOUCH.md (Section 20)
- `client/` directory (entire frontend) -- with constraints:
  - API contracts are immutable (request/response shapes defined by server)
  - `shared/schema.ts` is frozen
  - `vite.config.ts` build.outDir must remain `dist/public`
  - `@shared` alias must remain pointing to `./shared`
  - Do NOT add new API routes without server changes
  - Do NOT modify WebSocket protocol
  - Do NOT change JWT token format or storage location
  - Do NOT change `x-organization-id` header behavior

### 4d. Specific Never-Touch Files

**Source:** DO_NOT_TOUCH.md + UNIFIED_HANDOFF_PROMPT.md

Critical never-touch files:
- `server/webhooks/vapi.ts` -- live VAPI webhook processing
- `server/webhooks/tavus.ts` -- live Tavus webhook with HMAC verification
- `server/db/SecureQueryBuilder.ts` -- RLS enforcement
- `server/middleware/enforceOrganizationContext.ts` -- org isolation
- `shared/schema.ts` -- Drizzle ORM schema
- `database/migrations/*` -- all 33 migration files
- `.env` -- production secrets

### 4e. Package.json Rules

**Source:** DO_NOT_TOUCH.md (Section 15)
> "If the frontend rebuild requires NEW client-side dependencies, those may be added to `dependencies` or `devDependencies`. However: do NOT remove, upgrade, or downgrade any existing dependency. Do NOT modify the `scripts` section. Do NOT modify `overrides` or `optionalDependencies`."

---

## 5. Commit & Code Conventions

### 5a. Branch Strategy

**Source:** CLAUDE.md (pre-enforcer), CONSTITUTION.md (Section 2.5)
- Feature branches for all development
- Deploy only from `master`
- Branch naming: `feature/phase-{N}-{name}`
- Never commit to master directly
- Use `./deploy.sh` for deployment (enforces master branch check)

### 5b. Commit Format

**Source:** Global CLAUDE.md (owner's global rules)
```
[P{phase}.F{feature}] {Short Description}

Feature: {Full feature name}
Tests Passed: {3/3}
- Test 1: {description}
- Test 2: {description}
- Test 3: {description}

Files Changed:
- {file1}
- {file2}
```

### 5c. Quality Gates Before Commit

**Source:** CONSTITUTION.md (Section 3.4)
> "Quality gates before every deploy: `npm run check` + `npm run build` + `npx playwright test`"

**Source:** CONSTITUTION.md (Section 2.6, "Certification Over Credit")
> Three proofs required:
> 1. Configuration test -- verify configs, env vars, settings
> 2. Functional test -- verify feature works (unit/integration)
> 3. Visual/E2E test -- verify UI/API produces expected result

**Source:** opinions_facts.md.md (Rule 4)
> "Any 'COMPLETED' label requires: Link to artefact, Timestamp, Verifiable reference."

### 5d. Code Style

**Source:** CLAUDE.md (pre-enforcer, Technology Stack)
- TypeScript strict mode
- Vite + React 18
- Tailwind CSS + shadcn/ui
- Wouter (routing)
- TanStack Query (data fetching)

**Source:** DEVELOPMENT_TEAM_BRIEFING.md (Technical Debt)
- 380 `any` type annotations exist (mostly in server/) -- new code should use proper types
- No linter, formatter, or pre-commit hooks exist
- `console.log` is the only logging mechanism (242 unstructured statements)

### 5e. Deployment Flow

**Source:** CLAUDE.md (pre-enforcer, Deployment Workflow)
```
Working Directory -> TypeScript (.ts files)
                  -> npm run build
               dist/ -> Compiled JavaScript (.cjs)
                  -> PM2 serves
             Webserver -> Users see compiled code
```
> "The webserver runs compiled code from `dist/`. Editing `.ts` files does NOT affect the webserver until you rebuild."

---

## 6. Safety Gates

### 6a. Pre-Change Safety Checks

**Source:** CONSTITUTION.md (Section 6, "Non-Negotiable Constraints")
1. NEVER modify production v1 (`/home/ubuntu/Claude-store/nexxus/`)
2. NEVER share credentials between v1 and v2
3. NEVER deploy from a feature branch
4. NEVER expose vendor names in customer-facing UI
5. NEVER fabricate data or show unverified metrics
6. NEVER hardcode integration-specific values
7. NEVER bypass RLS or multi-tenant isolation
8. NEVER modify VAPI webhook handlers without explicit approval

**Source:** UNIFIED_HANDOFF_PROMPT.md (Section 1, "Production Environment Rules")
1. The backend is LIVE and working -- do not modify server code unless explicitly required
2. VAPI webhooks are LIVE -- do not modify `server/webhooks/vapi.ts`
3. Tavus webhooks are LIVE -- do not modify `server/webhooks/tavus.ts`
4. Existing users and data MUST be preserved -- never drop, truncate, or destructively migrate
5. Database migrations must be additive only
6. JWT authentication (NOT express-session) -- ignore any doc that says express-session

### 6b. RLS Safety

**Source:** DO_NOT_TOUCH.md (Section 4)
> "Every query passes through SecureQueryBuilder which sets `app.current_org_id` on the PostgreSQL connection. Modifying these files could silently break tenant isolation across the entire platform."

**Source:** DEVELOPMENT_TEAM_BRIEFING.md (Lessons 4-5)
- RLS variable name mismatch: `SecureQueryBuilder` sets `app.current_organization_id` but RLS policies check `app.current_org_id`
- SET LOCAL without transaction: potential cross-tenant data leak

### 6c. Data Safety

**Source:** CONSTITUTION.md (Section 2.5)
> "VIN Solutions data is sensitive -- read-only by default, writes require careful validation and correct API formatting"

**Source:** DEVELOPMENT_TEAM_BRIEFING.md (Lesson 7)
> "Records imported via excel upload were showing up in lead counts. Filter `source != 'excel_upload'` is required on ALL lead queries."

---

## 7. Quality Gates

### 7a. Three-Proof Validation (Per Feature)

**Source:** CONSTITUTION.md (Section 2.6), CLAUDE.md (pre-enforcer)

Every feature requires THREE pieces of evidence:
1. **Configuration test** -- verify configs, env vars, settings work
2. **Functional test** -- verify feature works (unit/integration test)
3. **Visual/E2E test** -- verify UI/API produces expected results

> "A feature is CERTIFIED only after all three proofs pass. Until then, it is IN PROGRESS regardless of how much code has been written."

### 7b. Pre-Deploy Quality Gate Sequence

**Source:** CONSTITUTION.md (Section 3.4)
```
npm run check -> npm run build -> npx playwright test
```
All three must pass before any deploy.

### 7c. Metric Certification Requirements

**Source:** MASTER_SRS.md (Section 8.2)
A metric is only certified if:
- It has a defined name, data source(s), computation formula, field dependencies, and fill rate requirement
- Underlying data fields are actually populated (>50% fill rate from 50+ record sample)
- Computed result matches ground truth (direct API query) within 2%
- Data source is accessible (not a blocked 403 endpoint)

### 7d. Evidence Standards

**Source:** opinions_facts.md.md (Rules 1, 4)
- Rule 1: "No finding listed without file citation (path + line or hash)"
- Rule 4: "Any 'COMPLETED' label requires: Link to artefact, Timestamp, Verifiable reference"

**Source:** Agent Instructions.md (Section 4, Phase 3)
- "Results are captured as artifacts -- log files, screenshots, test output. Not 'it passed.'"

---

## 8. Agent Team Structure

### 8a. Owner's Agent (Enforcer)

**Source:** session-knowledge.md (Section 4)
> "Enforcer is owner's personal representative, Claude-native agent, separate from agent team"
> ".agent_docs/ stays because it's the enforcer's operating directory"

**Source:** known_issues.md.md
> "The enforcer gates commits (pre-commit hook). It checks compliance against written documents. It flags conflicts in enforcer_context.md."

### 8b. Agent Team Topology (From Agent Instructions.md)

| Role | Agent Type | Responsibility | Tool Access |
|------|-----------|---------------|-------------|
| Architect | Plan | Decompose specs, define interfaces, resolve ambiguity | Read-only |
| Implementer(s) | General-purpose | Write code within assigned scope | Full |
| Validator | General-purpose | Write/run tests, verify metrics | Full |
| Auditor | Explore | Review for gaps, inconsistencies, security | Read-only |
| Lead | Orchestrator (you) | Assign work, enforce gates, make decisions | Full |

**Scaling Rule (Agent Instructions.md):**
- 1 Architect (always)
- min(N, 3) Implementers (each in a worktree)
- 1 Validator per 2 Implementers
- 1 Auditor (after each phase gate)
- Max 3 parallel Implementers

### 8c. Gatekeeper Gap (Critical Discovery)

**Source:** session-knowledge.md (Section 4, "Gatekeeper vs Enforcer")
> "Gatekeeper: sprint lifecycle quality -- scope criteria, verify builder output, loop until ALL pass, handoff"
> "Enforcer: commit compliance -- check governance, safety gates, quality gates before commit"
> "DIFFERENT JOBS. Gatekeeper was archived, enforcer doesn't fill its role."
> "Gap: nobody currently loops builder output against AC + RUI until criteria pass"

This is a structural gap requiring owner decision on how to restore the quality verification loop function.

---

## 9. Enforcer Rules

### 9a. What the Enforcer Checks

**Source:** known_issues.md.md, session-knowledge.md

The enforcer (`.claude/agents/enforcer.md`):
- Gates commits via pre-commit hook
- Checks compliance against governance documents
- Checks safety gates (RLS, auth, data integrity)
- Checks quality gates (tests passing, evidence captured)
- Flags conflicts in `enforcer_context.md`

### 9b. What the Enforcer Does NOT Do

**Source:** known_issues.md.md (Category C)
- Does NOT gate read-only testing passes (only commits)
- Cannot check comprehension of architecture (only document compliance)
- Cannot force resolution of flagged conflicts (requires owner)

### 9c. Enforcer's Operating Space

**Source:** session-knowledge.md
- Lives at: `.claude/agents/enforcer.md`
- Workspace: `.agent_docs/` directory
- Files the enforcer manages: safety gates, quality gates, conventions, work tree, plan sequence, conflict resolution

---

## 10. RBAC Rules

### 10a. 4-Tier Role Hierarchy

**Source:** MASTER_SRS.md (Section 3, complete permissions matrix)

| Capability | `super_admin` | `partner_admin` | `org_admin` | `org_staff` |
|------------|:---:|:---:|:---:|:---:|
| Create partners | Yes | No | No | No |
| Create organizations | Yes | Yes | No | No |
| Manage billing | Yes | No | No | No |
| System settings | Yes | No | No | No |
| Create Org Admins | Yes | Yes (assigned) | No | No |
| Create Staff | Yes | Yes (assigned) | Yes (own org) | No |
| Configure agents | Yes | Yes (assigned) | Yes (own org) | No |
| Create trigger rules | Yes | Yes (assigned) | Yes (own org) | No |
| Use DealerBrain/Automa | Yes | Yes | Yes | Yes |
| Access Insights | Yes | Yes | Yes | Yes (read-only) |
| Access Activity (oversight) | Yes | Yes | Yes | No |
| Direct VIN query access | Yes | Yes | Yes | No |
| Switch organizations | Yes | Yes | Yes (if multi-org) | No |

### 10b. Dashboard Minimum Certified Metrics Per Role

**Source:** MASTER_SRS.md (Section 8.4)

| Role | Minimum | Focus |
|------|---------|-------|
| `org_admin` | 10 | Pipeline health, team performance, AI activity |
| `org_staff` | 5 | Personal leads, tasks, performance vs team average |
| `partner_admin` | 5 | Org engagement, adoption, credit usage |
| `super_admin` | 5 | System-wide health, cost, usage |

### 10c. Data Access Rules

**Source:** CONSTITUTION.md (Section 2.3)
> "Data access follows RBAC at the database level. No cross-org data leakage. RLS policies enforce tenant isolation on every query."

**Source:** MASTER_SRS.md (Section 3.1)
- `partner_admin`: Aggregate metrics across assigned orgs, no individual PII
- `org_staff`: Own assignments only, no direct VIN query access
- All roles: Functionality delivered through appropriate UI surfaces

### 10d. Tool Provisioning Flow

**Source:** ARCHITECTURE_GUIDE_RBAC_ADDITION.md
```
Super Admin -> Provisions tools -> Partner Admin -> Manages orgs -> Org Admin -> Uses tools
```
- Super Admin controls all tool provisioning (VIN Solutions, VAPI, Tavus)
- Partner Admin can view tool usage but cannot configure tools
- Org Admin uses pre-provisioned tools (credentials encrypted)

---

## 11. Data Accuracy Rules

### 11a. Certification Requirements

**Source:** MASTER_SRS.md (Section 8.2)
- Metric must have: name, data source(s), formula, field dependencies, fill rate requirement
- Underlying data fields must have >50% fill rate from 50+ record sample
- Computed result must match ground truth within 2%
- Metrics depending on blocked endpoints are excluded entirely (not shown, not placeholdered)

### 11b. Blocked Data Handling

**Source:** CONSTITUTION.md (Section 2.4)
> "No metric is displayed without ground truth verification"
> "Metrics that depend on blocked or inaccessible endpoints are excluded entirely -- not shown, not placeholdered"

**Source:** MASTER_SRS.md (Section 7.5)
- 17 VIN gateway endpoints return 403 Forbidden
- Features that depend on blocked data must NOT have UI
- No placeholder data, no "coming soon" indicators, no speculative numbers

### 11c. Excel Upload Exclusion

**Source:** DEVELOPMENT_TEAM_BRIEFING.md (Lesson 7), MASTER_SRS.md (Section 7.2)
> "Filter `source != 'excel_upload'` is required on ALL lead queries. Already fixed in 32+ queries across 11 files."

### 11d. Honest AI Policy

**Source:** CONSTITUTION.md (Section 2.2)
- DealerBrain admits when data is unavailable -- does not fabricate
- When asked about blocked data, explains limitations and offers alternatives
- AI responses cite data sources internally (not for customer display)
- No placeholder data, no "coming soon," no speculative numbers

### 11e. Cache TTL Policy

**Source:** MASTER_SRS.md (Section 7.2)
- 5 minutes for VIN leads
- 1 hour for VAPI/Tavus
- No cache for local-only data
- Fallback: VIN fail -> local cache with staleness warning in LOGS (not UI)

---

## 12. UI Immutability Rules

### 12a. RUI Is Tier 1 Truth

**Source:** session-knowledge.md (MEMORY.md context)
> "Live RUI Mockup: https://nexxusv2sample.replit.app/"
> "Tier 1 in truth hierarchy (immutable spec -- can be added to, never modified)"

### 12b. No Vendor Names in UI

**Source:** CONSTITUTION.md (Section 3.1)
- No "Tavus", "Vapi", "VAPI" in any customer-facing UI
- No "VIN API", "Local + VIN" source attribution visible to users
- No placeholder UI for blocked features
- Agent capabilities are called "Skills" (not "Tools")

### 12c. Design-First Rule

**Source:** UNIFIED_HANDOFF_PROMPT.md (Section 0, Rule 5)
> "The new UI design is the source of truth -- if any document contradicts the designer's handoff, the design wins."

---

## 13. Key Technical Facts

### 13a. Codebase Quick-Reference

**Source:** REVERSE_SRS_old.md (Section 1), health-audit.md

| Metric | Value |
|--------|-------|
| Lines of code | 117,693 TypeScript/TSX |
| Total source files | 402 |
| API endpoints | ~237 |
| Database tables | 53 |
| Database migrations | 33 |
| RLS policies | ~100 |
| Database indexes | 160+ |
| Service modules | 40 |
| Route files | 34 |
| Scheduled jobs | 8 |
| Third-party integrations | 7 |
| E2E tests (Playwright) | 747 |
| Unit tests | 0 |
| npm dependencies | 122 (91 prod + 31 dev) |
| Git commits | 181 |
| TanStack Query hooks | 26 |
| DealerBrain tools | 24 |
| Frontend pages | 21 |
| Frontend components | 59 |

### 13b. Production Customers

**Source:** DEVELOPMENT_TEAM_BRIEFING.md, CONSTITUTION.md

- Serra Automotive (Serra Honda dealer ID 21043, Serra Nissan 21044, Tony Serra Ford 21047)
- Hyundai of Columbia (Hyundai of Columbia, Ford of Columbia)
- Live URL: https://nexxusv2.huminicdev.com
- Platform operator: Huminic (`super_admin`)
- First partner: Duran Cage

### 13c. Economics

**Source:** CLAUDE.md (pre-enforcer)
- Voice AI: $0.25/min (customer) / $0.15/min (cost) = 40% margin
- Video AI: $0.32/min (customer) / $0.20/min (cost) = 37.5% margin
- SMS: $0.05/msg (customer) / $0.02/msg (cost) = 60% margin

### 13d. Authentication Architecture

**Source:** UNIFIED_HANDOFF_PROMPT.md (Section 3.3), CARRY_FORWARD_MANIFEST.md

- JWT-based (NOT express-session)
- Access token + refresh token in localStorage
- Keys: `nexxus_access_token`, `nexxus_refresh_token`, `nexxus_token_expiry`
- Auto-refresh: checks every 60s, refreshes when < 5 min to expiry
- Login: `POST /api/auth/login`
- Refresh: `POST /api/auth/refresh`
- Org switch: `POST /api/auth/switch-org`

### 13e. Environment Variables

**Source:** UNIFIED_HANDOFF_PROMPT.md (Section 13)
- 33 environment variables required
- No `VITE_` env vars in frontend -- all API calls use relative URLs
- Key categories: Database, Auth, AI, VIN Solutions, VAPI, Tavus, Email, SMS, Google Calendar

---

## 14. Known Gotchas

### 14a. VIN API Header Format

**Source:** DEVELOPMENT_TEAM_BRIEFING.md (Lesson 3), MASTER_SRS.md (Section 6.1)
> Documentation says `application/vnd.coxauto.V3+json` (uppercase V3). Production API REJECTS uppercase. Use `application/vnd.coxauto.v3+json` (lowercase v3).
> Reference endpoints require v1 headers. Lead CRUD requires v3 headers. Gateway endpoints require `application/json`.

### 14b. RLS Variable Name Mismatch

**Source:** DEVELOPMENT_TEAM_BRIEFING.md (Lesson 4)
> `SecureQueryBuilder` sets `app.current_organization_id` but RLS policies check `app.current_org_id`. Different variable names. System works because most routes bypass SecureQueryBuilder. Known bug, not yet fixed.

### 14c. SET LOCAL Risk

**Source:** DEVELOPMENT_TEAM_BRIEFING.md (Lesson 5)
> `SecureQueryBuilder.query()` uses `SET LOCAL` (transaction-scoped) but doesn't wrap in a transaction. Without BEGIN/COMMIT, `SET LOCAL` behaves like `SET` and persists on the pool connection. Potential cross-tenant data leak.

### 14d. Excel Upload Pollution

**Source:** DEVELOPMENT_TEAM_BRIEFING.md (Lesson 7)
> Any new lead query MUST exclude `source = 'excel_upload'` or metrics will show inflated numbers.

### 14e. Lead Creation Is Two-Step

**Source:** DEVELOPMENT_TEAM_BRIEFING.md (Lesson 2), MASTER_SRS.md (Section 6.1)
> VIN lead creation: (1) create contact via gateway POST -> get ContactId, (2) create lead with contact as URL reference (`/contacts/id/12345?dealerid=67890`). The `leadSource`, `leadType`, and `contact` fields are ALL href references, NOT string names.

### 14f. VIN API Blocks 17 of 30 Endpoints

**Source:** DEVELOPMENT_TEAM_BRIEFING.md (Lesson 1), MASTER_SRS.md (Section 6.1)
> 17 VIN gateway endpoints return 403 Forbidden. Nexxus sees beginning (lead creation) and end (SOLD/LOST) but NOT middle (deals, appointments, communication logs). Do NOT build UI for data that doesn't exist.

### 14g. Context Router Was Inverted

**Source:** DEVELOPMENT_TEAM_BRIEFING.md (Lesson 6)
> Originally configured backwards (local DB primary, VIN fallback). Corrected to: VIN API primary, local DB fallback. `CONTEXT_ROUTER_ENABLED=true` in env.

### 14h. Webhook Route Order Matters

**Source:** DO_NOT_TOUCH.md (Section 2), UNIFIED_HANDOFF_PROMPT.md (Section 3.2)
> `/api/webhooks/vapi` registered BEFORE body parsers. `/api/webhooks/tavus` uses raw body capture for HMAC. These routes must appear before other routes in `server/routes.ts`.

### 14i. TextMagic Credentials Are Per-Org

**Source:** session-knowledge.md (Category A, known_issues.md.md)
> TextMagic credentials are stored per-organization in the database, NOT in `.env`. Testing with `.env` credentials produces 401 errors for org-level operations.

### 14j. CLAUDE.md Is chmod 444

**Source:** session-knowledge.md, known_issues.md.md
> Owner made CLAUDE.md read-only (chmod 444) because agents kept modifying it without consent. Only owner can edit. This is a defensive measure, not a bug.

---

## 15. Prohibited Actions

### 15a. Production Safety

**Source:** CONSTITUTION.md (Section 6), UNIFIED_HANDOFF_PROMPT.md (Section 1)

1. NEVER modify production v1 (`/home/ubuntu/Claude-store/nexxus/`)
2. NEVER share credentials between v1 and v2
3. NEVER deploy from a feature branch
4. NEVER drop, truncate, or destructively migrate database tables
5. NEVER modify `server/webhooks/vapi.ts` without explicit approval
6. NEVER modify `server/webhooks/tavus.ts` without explicit approval
7. NEVER break webhook processing, VIN sync, or notification delivery

### 15b. Data Integrity

**Source:** CONSTITUTION.md (Sections 2.2, 2.4, 3.2)

8. NEVER fabricate data or show unverified metrics
9. NEVER display metrics depending on blocked endpoints
10. NEVER show placeholder data, "coming soon" indicators, or speculative numbers
11. NEVER serve stale data as truth (respect cache TTLs)
12. NEVER bypass RLS or multi-tenant isolation
13. NEVER hardcode integration-specific values (API keys, phone numbers, lead assignments)

### 15c. UI Rules

**Source:** CONSTITUTION.md (Section 3.1)

14. NEVER expose vendor names ("Tavus", "VAPI") in customer-facing UI
15. NEVER show source attribution labels ("VIN API", "Local + VIN") in UI
16. NEVER show placeholder UI for blocked features

### 15d. Code/File Rules

**Source:** DO_NOT_TOUCH.md, UNIFIED_HANDOFF_PROMPT.md

17. NEVER modify files in `server/`, `database/`, `widget/`, `scripts/` without explicit approval
18. NEVER modify `shared/schema.ts` (both server and client depend on it)
19. NEVER modify existing npm dependencies (versions or removal)
20. NEVER modify the `scripts` section of `package.json`
21. NEVER reorder routes in `server/routes.ts`

### 15e. Process Rules

**Source:** opinions_facts.md.md, session-knowledge.md

22. NEVER mark something COMPLETED without artefact + timestamp + verifiable reference
23. NEVER modify CLAUDE.md (chmod 444 -- only owner edits)
24. NEVER create files without owner awareness (especially in `.agent_docs/` or root)
25. NEVER treat archived materials as current truth
26. NEVER assume -- when in doubt, STOP and ask

---

## Conflicts Found

### CONFLICT 1: Document Truth Hierarchy Ordering

**Source A:** CLAUDE.md (pre-enforcer) says: Constitution > Master SRS > Current-State > Implementation Plan
**Source B:** UNIFIED_HANDOFF_PROMPT.md says: New UI Design > AC > Unified Handoff > Constitution > Audit Files > SRS > Implementation Plan
**Source C:** session-knowledge.md says: RUI > AC > Release Plan

**Resolution:** These three sources represent different eras. The UNIFIED_HANDOFF_PROMPT.md is the most recent governance-style document (2026-02-22). The session-knowledge captures the owner's stated preference (2026-03-02). Both agree the UI/RUI is highest priority and AC ranks above SRS/Constitution. The new CLAUDE.md should use the owner's most recent stated preference from session-knowledge, harmonized with the full file set: RUI > AC > CLAUDE.md rules > PRD/Constitution > SRS > SPEC > PLAN.

### CONFLICT 2: Number of Governing Documents

**Source A:** CLAUDE.md (pre-enforcer) lists 4 governing documents (Constitution, Master SRS, Current-State, Implementation Plan) in `docs/`
**Source B:** Standards.md (owner) defines 6 files at root (CLAUDE.md, PRD.md, SRS.md, SPEC.md, PLAN.md, ACCEPTANCE_CRITERIA.md)
**Source C:** session-knowledge.md confirms the 6-file structure is the resolution

**Resolution:** The new structure is 6 files at project root. This replaces the old 4-in-docs structure. Standards.md is the owner's explicit decision.

### CONFLICT 3: Acceptance Criteria Status Claims

**Source A:** release_criteria.md claims "All 12 P0 Gaps FIXED"
**Source B:** Run 2 FINAL_REPORT.md claims "22 P0 blockers"
**Source C:** verified-findings.md shows actual count is 3-7 (8 tainted, 2 resolved)

**Resolution:** All three are historically accurate for their time but all are stale. The new PLAN.md gap tracker should be the single source of truth going forward. The CLAUDE.md should reference PLAN.md for current gap state.

### CONFLICT 4: Webhook Email (Live Production Feature)

**Source A:** CLAUDE.md (pre-enforcer) mentions VAPI webhook email as production feature
**Source B:** session-knowledge.md confirms: "Webhook (email on call complete) is only live production feature -- verify at every transition"

**Resolution:** No conflict -- both agree. This must be prominently stated in new CLAUDE.md as a "verify at every transition" item.

### CONFLICT 5: VIN Solutions Data Retention

**Source A:** DealerBrainService.ts (line 840): "VIN Solutions has a 48-hour data limit via API"
**Source B:** IMPLEMENTATION_PLAN.md (Phase 1.3): "VIN API has no retention limit (verified 2026-02-13)"
**Source C:** CLARIFICATION_ANSWERS.md (Q6): Owner disproved the 48-hour claim

**Resolution:** The 48-hour claim is FALSE. VIN API has full history access. The DealerBrain system prompt lines are flagged for removal in IMPLEMENTATION_PLAN.md Phase 1.3. New CLAUDE.md should NOT include the 48-hour claim.

---

## Information Not Found

1. **Orchestration Agent specification** -- CLARIFICATION_ANSWERS.md (Q10) says "Not a definite need. Build only if architectural deficiency requires it." No spec exists.

2. **System Agents definition** -- CLARIFICATION_ANSWERS.md (Q11) mentions system agents (background, invisible) vs user agents, but no file defines what system agents currently exist or what they do.

3. **MCP Proxy integration rules** -- CLARIFICATION_ANSWERS.md (Q15) defers this entirely. session-knowledge.md mentions central-mcp at port 4002 but no integration rules are defined.

4. **Collision avoidance protocol** -- MASTER_SRS.md (Section 5.6) mentions conversation state tracking (AI_ACTIVE / HUMAN_ACTIVE / DORMANT) but no implementation rules exist.

5. **Multi-org query rules for org_admin** -- CLARIFICATION_ANSWERS.md (Q14) says "Single-org context only. Run queries per org individually." This is a decision but no implementation rule for agents.

6. **SMS business hours routing rules** -- MASTER_SRS.md mentions after-hours -> AI, business hours -> staff, but no schedule format or configuration rules.

7. **Test battery location and format** -- session-knowledge.md notes prose batteries need conversion to Playwright spec.ts, but no standard for where test files should live or how they should be named.

8. **Skills catalog definition** -- session-knowledge.md explains V1->V2 skills architecture (users create agents, add skills) but no catalog of available skills is documented in any agent-readable file.

---

## Source File Log

| File | Sections Extracted | Wave 6 Relevance |
|------|-------------------|------------------|
| CLAUDE.md (pre-enforcer) | Truth hierarchy, tech stack, deployment, branch strategy, project status, evidence rules, RBAC, economics | HIGH -- existing CLAUDE.md baseline |
| CONSTITUTION.md | Data truth hierarchy, honest AI, RBAC roles, non-destructive ops, certification, UI rules, naming, data rules, integration rules, testing rules, non-negotiables | CRITICAL -- core rules source |
| DO_NOT_TOUCH.md | Backend freeze manifest (345+ files), safe-to-modify rules, package.json constraints, frontend modification rules | CRITICAL -- freeze rules |
| UNIFIED_HANDOFF_PROMPT.md | 6-tier reading order, document conflict resolution, production rules, what exists (complete inventory), auth architecture, RBAC, carry-forward requirements, sprint structure, testing protocol, critical session rules | CRITICAL -- most complete rules doc |
| MASTER_SRS.md | RBAC permissions matrix, naming conventions, data truth hierarchy, VIN API details, metric certification, data field policy, blocked endpoints, cache TTL, Context Router rules | HIGH -- RBAC and data accuracy rules |
| DEVELOPMENT_TEAM_BRIEFING.md | 7 hard-won lessons (VIN headers, RLS mismatch, SET LOCAL, excel pollution, lead sync format, Context Router inversion), technical debt inventory | HIGH -- gotchas and prohibitions |
| Agent Instructions.md | Team topology, development phases, phase gates, communication protocol, task lifecycle, worktree strategy, metrics verification framework | HIGH -- agent team structure |
| opinions_facts.md.md | 7 evidence-first rules, truth hierarchy verification, change consent boundaries, gap tracker consolidation | MEDIUM-HIGH -- owner's governance rules |
| Standards.md | 6-file governance structure, document type definitions, owner's gradient model | MEDIUM-HIGH -- structural decisions |
| CARRY_FORWARD_MANIFEST.md | 32 PRESERVE files, 8 REFERENCE, 11 REPLACEABLE, token management, hook inventory, SSE protocol | MEDIUM -- carry-forward rules |
| IMPLEMENTATION_PLAN.md | VIN header fixes, vendor name removal, DealerBrain prompt corrections, false 48-hour claim | MEDIUM -- specific fix rules |
| session-knowledge.md | Platform mental model, skills architecture, payment-critical features, wave analysis watch list, gatekeeper gap, file structure decisions, CLAUDE.md chmod 444 | CRITICAL -- owner's latest decisions |
| app_identity.md | Platform identity, business model, customer goals, partner structure, known issues | MEDIUM -- identity context |
| CLARIFICATION_ANSWERS.md | VIN write-back, webhook architecture, Context Router, data warehouse model, widget options, SMS, outbound communication, data accuracy mandate | MEDIUM -- owner decisions |
| Current_State.md.md | Three governance layers, /init impact, file sprawl causes | MEDIUM -- context for governance consolidation |
| Forensics.md.md | Evidence standards (verified vs derived vs unverified), structural conditions | MEDIUM -- evidence methodology |
| known_issues.md.md | Enforcer scope limitations, CLAUDE.md chmod 444 reason, gatekeeper removal impact | MEDIUM -- enforcer context |
| REVERSE_SRS_old.md | Codebase statistics, production health, as-built inventory | MEDIUM -- technical facts |
| ARCHITECTURE_GUIDE_RBAC_ADDITION.md | Partner entity model, RLS policies, tool provisioning flow | LOW-MEDIUM -- RBAC detail |
| file-inventory.md | All 53 input files catalogued with dates and descriptions | Reference -- inventory |
