# Wave 6 RECONCILED Output -- Agent Rules for CLAUDE.md

**Date:** 2026-03-03
**Orchestrator:** Claude Opus 4.6
**Inputs:** wave6-analyst.md (815 lines), wave6-reviewer.md (843 lines)
**Method:** Rule-by-rule comparison across 15 categories, conflict flagging, deduplication

---

## Reconciliation Summary

| Metric | Count |
|--------|-------|
| Categories reconciled | 15 of 15 |
| Rules where both agents AGREE | 142 |
| Analyst-only additions merged | 8 |
| Reviewer-only additions merged | 14 |
| DISAGREEMENTS requiring owner resolution | 4 |
| Conflicts found (total unique) | 9 (5 analyst + 6 reviewer, 2 overlap) |
| Missing information items (total unique) | 11 (8 analyst + 7 reviewer, 4 overlap) |
| Prohibited actions (deduplicated) | 28 |

**Overall Assessment:** High agreement between agents. The Reviewer was more thorough on operational details (development phases, communication protocol, task lifecycle, cross-contamination prevention, testing protocol). The Analyst was more thorough on citations and technical reference data (codebase metrics, economics, environment variables). Both identified the same structural gaps (gatekeeper, skills architecture, truth hierarchy ordering).

---

## DISAGREEMENTS REQUIRING OWNER RESOLUTION

### DISAGREE-1: Document Truth Hierarchy Ordering

**What:** The exact ordering of governance documents when they conflict.

**Analyst version (7 levels):**
1. RUI Mockup (visual spec, immutable)
2. ACCEPTANCE_CRITERIA.md (testable statements)
3. CLAUDE.md (agent operating rules)
4. CONSTITUTION.md / PRD.md (identity, principles)
5. SRS.md (system behavior narrative)
6. SPEC.md (architecture)
7. PLAN.md (marching orders)

**Reviewer version (7 levels):**
1. RUI (Replit Reference Design) -- Tier 1, immutable spec
2. Owner's designs / Acceptance Criteria
3. CLAUDE.md / UNIFIED_HANDOFF_PROMPT
4. CONSTITUTION.md
5. Audit files (forensic as-built)
6. MASTER_SRS / SRS.md
7. IMPLEMENTATION_PLAN / PLAN.md

**Source conflict (3 eras):**
- CLAUDE.md (pre-enforcer): Constitution > Master SRS > Current-State > Implementation Plan
- UNIFIED_HANDOFF_PROMPT.md: New UI Design > AC > Unified Handoff > Constitution > Audit Files > SRS > Implementation Plan
- session-knowledge.md: RUI > AC > Release Plan

**Key differences:**
- Analyst places CLAUDE.md at #3; Reviewer groups it with UNIFIED_HANDOFF_PROMPT at #3
- Reviewer includes "Audit files" at #5; Analyst omits audit files from the hierarchy
- Analyst separates PRD from CONSTITUTION; Reviewer does not mention PRD separately
- Neither includes SPEC.md in the same position

**Recommendation:** Both agree on RUI > AC > CLAUDE.md rules at top. The disagreement is in positions 4-7. The new CLAUDE.md should state: (1) RUI, (2) AC, (3) CLAUDE.md rules, and then ask the owner to rank the remaining files (PRD/CONSTITUTION, SRS, SPEC, PLAN, Audit files). The audit files question is material -- should forensic as-built outrank design docs?

**OWNER DECISION NEEDED:** Final ordering of positions 4-7, and whether audit files are included in the hierarchy.

---

### DISAGREE-2: Every-Session Reading List

**What:** What agents must read before starting work each session.

**Analyst version (3 mandatory + 5 as-needed):**
Every session:
1. CLAUDE.md
2. PLAN.md
3. Session state from memory directory

Read when relevant:
4. ACCEPTANCE_CRITERIA.md (when testing/building)
5. SRS.md (when understanding behavior)
6. SPEC.md (when understanding architecture)
7. PRD.md (when understanding business context)
8. DO_NOT_TOUCH list (when modifying files)

**Reviewer version (4 mandatory + 6-tier deep reference):**
Before every session:
1. Session-state.md for context
2. CLAUDE.md and PLAN.md
3. Git status and recent commits
4. Create feature branch before work

Before writing code (6-tier reading order from UNIFIED_HANDOFF_PROMPT):
Tier 1: Forensic audit files (4 files)
Tier 2: Carry-forward and freeze lists (2 files)
Tier 3: Lessons and operational knowledge (2 files)
Tier 4: Design specifications (AC, designer handoffs)
Tier 5: Governance documents (CLAUDE.md, CONSTITUTION, SRS, PLAN)
Tier 6: Reference material

**Key difference:** Reviewer preserves the full 6-tier UNIFIED_HANDOFF_PROMPT reading order as mandatory before writing code. Analyst consolidates to a shorter list. The 6-tier list is comprehensive but may be impractical for every session.

**Recommendation:** Use the Analyst's short list (CLAUDE.md + PLAN.md + session state) for every-session, and the Reviewer's 6-tier list as "Before Starting New Feature Work" reference. This avoids agents reading 16+ files before every routine task.

**OWNER DECISION NEEDED:** Is the 6-tier reading order mandatory before every code session, or only when starting new feature work?

---

### DISAGREE-3: Implementation Plan Sequencing (Strict vs Plan-Defined)

**What:** Whether work must be strictly sequential or can be parallel.

**Analyst position:** Not explicitly addressed (references sequential reading order).

**Reviewer position (CONFLICT C6-3):** CLAUDE.md (pre-enforcer) says "ALWAYS follow the implementation plan step-by-step, sequentially" but IMPLEMENTATION_PLAN.md explicitly states Phases 1, 2, and 5 can run in parallel, and Agent Instructions.md describes parallel implementation in worktrees.

**Recommendation:** The rule should be "follow the plan" (which itself defines where parallelism is allowed), not "strictly sequential." The plan is the authority on execution order, not a blanket sequential rule.

**OWNER DECISION NEEDED:** Confirm: "Follow the plan's defined execution order, including any parallelism the plan specifies" -- is this correct?

---

### DISAGREE-4: Acceptance Criteria Scope

**What:** Which AC set is authoritative.

**Reviewer (CONFLICT C6-1):**
- CLAUDE.md (pre-enforcer): 5 acceptance criteria (AC-1 through AC-5)
- MASTER_SRS.md: 19 acceptance criteria (AC-001 through AC-019)
- session-knowledge.md: 7 "payment-critical" demo items
- Acceptance Criteria.md: 13 demo items

**Analyst:** Did not flag this as a conflict but noted MASTER_SRS.md AC matrix in RBAC section.

**Recommendation:** The new ACCEPTANCE_CRITERIA.md being written in the surgery will consolidate all sources. CLAUDE.md should reference that file, not embed any AC count. The 7-item payment-critical list should be in PLAN.md as the launch filter.

**OWNER DECISION NEEDED:** Which AC set is the launch-critical filter? The 7-item payment-critical list from session-knowledge.md?

---

## RECONCILED CATEGORIES (All 15)

### Category 1: Truth Hierarchy

**1a. Data Truth Hierarchy (When runtime data conflicts)**
BOTH AGREE. Merged with strongest citations.

| Priority | Source | Authoritative For |
|----------|--------|-------------------|
| 1 (highest) | VIN Solutions API | Leads, statuses, sources, types, CRM users |
| 2 | VAPI / Tavus APIs | AI call and video session data |
| 3 | Local Database | Nexxus-only data: tasks, goals, agents, preferences, activity |
| 4 (lowest) | Derived Metrics | Computed from above; never cached as truth |

**Rule:** If VIN API returns data that differs from the local database, VIN wins. Update local to match. Derived metrics are recomputed on demand, not stored as authoritative values.
**Source:** CONSTITUTION.md Section 2.1; MASTER_SRS.md Section 7.1

**1b. Document Truth Hierarchy**
SEE DISAGREE-1 above. Pending owner resolution.

**1c. Owner's Governance File Structure** [REVIEWER addition]
BOTH AGREE on the 6-file structure.

| File | Purpose | Read Frequency |
|------|---------|----------------|
| CLAUDE.md | Agent rules, truth hierarchy, conventions | Every session |
| PRD.md | Plain language: what and why (strategy) | Reference |
| SRS.md | Technical narrative: how it works (precision) | Reference |
| SPEC.md | Architecture: where things live, how they connect | When needed |
| PLAN.md | Marching orders: current phase, next steps, status | Every session |
| ACCEPTANCE_CRITERIA.md | Testable statements (mirrors test battery) | When testing |

**Source:** Standards.md; session-knowledge.md Section 2

**1d. Files That Are NOT Governance**
BOTH AGREE (Analyst explicit, Reviewer covers in Gotchas section).

| Directory | Authority Status |
|-----------|-----------------|
| `.project/` | NOT authoritative -- /plan mode scratch only |
| `.agent_docs/` | Operational reference for enforcer only |
| `filestore/` | Historical INPUT, not governance |
| `docs/archive/` | HISTORICAL, not current truth |

**Source:** session-knowledge.md Section 1

---

### Category 2: Document Reading Order

SEE DISAGREE-2 above for the every-session vs 6-tier question.

**Consolidated (pending owner confirmation):**

**Every session (mandatory):**
1. CLAUDE.md (this file)
2. PLAN.md (current phase, what to do next)
3. Session state from memory directory

**Before starting new feature work (reference):**
- Tier 1: Forensic audit files (what actually exists in code)
- Tier 2: CARRY_FORWARD_MANIFEST.md + DO_NOT_TOUCH.md (what to preserve/avoid)
- Tier 3: DEVELOPMENT_TEAM_BRIEFING.md (hard-won lessons)
- Tier 4: ACCEPTANCE_CRITERIA.md + designer handoffs (what to build)
- Tier 5: Governance documents (rules and principles)
- Tier 6: Agent Instructions, metric formulas (deep reference)

**Source:** UNIFIED_HANDOFF_PROMPT.md Section 2; CLAUDE.md (pre-enforcer); Standards.md

---

### Category 3: Naming Conventions

BOTH AGREE. Merged with Reviewer's additions.

**3a. Platform Naming**

| Internal/Vendor Name | User-Facing Name |
|----------------------|-----------------|
| VAPI | Voice Agent |
| Tavus | Video Agent |
| DealerBrain | (not shown -- underlying concept) |
| Automa | Automa |
| Tools (agent capabilities) | Skills |
| Hub | Work Center |
| TextMagic | (not shown -- SMS is the user concept) [REVIEWER addition] |

**Source:** CONSTITUTION.md Section 3.1, Section 4; MASTER_SRS.md Section 2.4

**3b. Prohibited Vendor Names in UI**
- No "Tavus", "Vapi", "VAPI" in any customer-facing UI
- No "VIN API", "Local + VIN" source attribution visible to users
- No "TextMagic" in UI [REVIEWER addition]
- Use role-appropriate labels: "Voice Agent", "Video Agent", "AI Assistant"
- Source tagging is internal only for traceability, not customer display

**Source:** CONSTITUTION.md Section 3.1; MASTER_SRS.md Section 5.2

**3c. Platform Identity** [REVIEWER addition]
- Nexxus is an AI orchestration layer
- NOT a CRM replacement, NOT a marketing automation tool, NOT a content development platform
- Not automotive-only -- automotive is the first vertical, architecture must not be permanently locked to it
- DealerBrain is not a sidebar link. Automa is always at the top of the agents list.

**Source:** CONSTITUTION.md Section 1; MASTER_SRS.md Section 2; app_identity.md

**3d. Feature Branch Naming**
Branch format: `feature/phase-{N}-{name}` or `feature/{name}`
**Source:** CLAUDE.md (pre-enforcer)

**3e. RBAC System Values**

| Role | System Value | Level |
|------|-------------|-------|
| Super Admin | `super_admin` | 1 |
| Partner Admin | `partner_admin` | 2 |
| Org Admin | `org_admin` | 3 |
| Staff | `org_staff` | 4 |

**Source:** MASTER_SRS.md Section 3.1

**3f. "MVP" Terminology** [REVIEWER addition -- CONFLICT C6-6]
Do NOT call the launch-critical set "MVP." Owner prefers "launch-critical" or "payment-critical."
**Source:** session-knowledge.md Section 0c

---

### Category 4: Backend Freeze Rules

BOTH AGREE. Merged with strongest structure.

**4a. The Golden Rule**
If a file is not explicitly listed in DO_NOT_TOUCH.md Section 20 ("SAFE TO MODIFY"), it must not be modified. When in doubt, do not touch it.
**Source:** DO_NOT_TOUCH.md

**4b. Scope of Freeze (345+ files)**

| Category | File Count |
|----------|-----------|
| Server core + routes + services + middleware + auth + webhooks + websocket + jobs + utils | 88 files |
| Database migrations + support | 38 files |
| Shared schema | 1 file |
| Widget | 17 files |
| Build system | 2 files |
| Root config files | 15 files |
| Tests | 65 files |
| Scripts | 19 files |
| Documentation | 100+ files |

**Source:** DO_NOT_TOUCH.md (complete document, 662 lines)

**4c. What IS Safe to Modify**
- `client/` directory (entire frontend, ~130 files) -- with constraints:
  - API contracts are immutable (request/response shapes defined by server)
  - `shared/schema.ts` is frozen (client imports types from it)
  - `vite.config.ts` build.outDir must remain `dist/public`
  - `@shared` alias must remain pointing to `./shared`
  - Do NOT add new API routes without server changes
  - Do NOT modify WebSocket protocol
  - Do NOT change JWT token format or storage location
  - Do NOT change `x-organization-id` header behavior
  - `client/src/lib/api.ts` request format must remain compatible [REVIEWER addition]

**Source:** DO_NOT_TOUCH.md Section 20

**4d. Specific Never-Touch Files**
- `server/webhooks/vapi.ts` -- live VAPI webhook processing
- `server/webhooks/tavus.ts` -- live Tavus webhook with HMAC verification
- `server/db/SecureQueryBuilder.ts` -- RLS enforcement
- `server/middleware/enforceOrganizationContext.ts` -- org isolation
- `shared/schema.ts` -- Drizzle ORM schema
- `database/migrations/*` -- all 33 migration files
- `.env` -- production secrets

**Source:** DO_NOT_TOUCH.md; UNIFIED_HANDOFF_PROMPT.md

**4e. Package.json Rules**
New client-side dependencies MAY be added. However:
- Do NOT remove, upgrade, or downgrade any existing dependency
- Do NOT modify the `scripts` section
- Do NOT modify `overrides` or `optionalDependencies`

**Source:** DO_NOT_TOUCH.md Section 15

**4f. Database Migrations**
Must be additive only. Never destructive. Never drop, truncate, or destructively migrate existing data.
**Source:** UNIFIED_HANDOFF_PROMPT.md Section 1

---

### Category 5: Commit and Code Conventions

BOTH AGREE. Merged.

**5a. Branch Strategy**
- Feature branches for all development
- Deploy only from `master`
- Never commit to master directly
- Branch naming: `feature/phase-{N}-{name}` or `feature/{name}`

**Source:** CLAUDE.md (pre-enforcer); CONSTITUTION.md Section 2.5

**5b. Feature Branch Workflow** [REVIEWER addition]
```
1. git checkout -b feature/{name}
2. Do work, commit changes
3. git checkout master && git merge feature/{name}
4. ./deploy.sh
5. git branch -d feature/{name}
```
**Source:** CLAUDE.md (pre-enforcer)

**5c. Deployment Flow**
```
Working Directory -> TypeScript (.ts files)
                  -> npm run build
               dist/ -> Compiled JavaScript (.cjs)
                  -> PM2 serves
             Webserver -> Users see compiled code
```
- Deploy only via `./deploy.sh`
- Script enforces: master branch only, warns on uncommitted changes, runs build, restarts PM2
- Editing `.ts` files does NOT affect the webserver until you rebuild

**Source:** CLAUDE.md (pre-enforcer); DO_NOT_TOUCH.md Section 14

**5d. Pre-Deploy Quality Gate Sequence**
```
npm run check -> npm run build -> npx playwright test
```
All three must pass before any deploy.
**Source:** CONSTITUTION.md Section 3.4

**5e. Code Style**
- TypeScript strict mode
- Vite + React 18
- Tailwind CSS + shadcn/ui
- Wouter (routing)
- TanStack Query (data fetching)
- No `any` type annotations in new code (380 existing ones are tech debt)
- No linter, formatter, or pre-commit hooks exist (beyond enforcer)
- Follow the plan -- NEVER ad-lib, skip ahead, or add unplanned features [REVIEWER addition]

**Source:** CLAUDE.md (pre-enforcer); DEVELOPMENT_TEAM_BRIEFING.md; CLAUDE.md Section 4

---

### Category 6: Safety Gates

BOTH AGREE. Reviewer more detailed; merged.

**6a. Pre-Change Safety Checks**
1. Check if the file is in DO_NOT_TOUCH.md -- if listed, do not modify
2. Check audit files first -- verify what already exists before building (many things are already implemented)
3. Check VIN API access -- 17 of 30 endpoints return 403. Do not build UI for data that does not exist
4. Check CARRY_FORWARD_MANIFEST.md -- 32 PRESERVE files must not be rewritten
5. If uncertain, STOP and ask -- present options with tradeoffs, wait for guidance

**Source:** DO_NOT_TOUCH.md; UNIFIED_HANDOFF_PROMPT.md; Agent Instructions.md

**6b. Non-Negotiable Constraints (CONSTITUTION.md Section 6)**
1. NEVER modify production v1 (`/home/ubuntu/Claude-store/nexxus/`)
2. NEVER share credentials between v1 and v2
3. NEVER deploy from a feature branch
4. NEVER expose vendor names in customer-facing UI
5. NEVER fabricate data or show unverified metrics
6. NEVER hardcode integration-specific values
7. NEVER bypass RLS or multi-tenant isolation
8. NEVER modify VAPI webhook handlers without explicit approval

**Source:** CONSTITUTION.md Section 6

**6c. Production Environment Rules (UNIFIED_HANDOFF_PROMPT.md)**
1. The backend is LIVE and working -- do not modify server code unless explicitly required
2. VAPI webhooks are LIVE -- do not modify `server/webhooks/vapi.ts`
3. Tavus webhooks are LIVE -- do not modify `server/webhooks/tavus.ts`
4. Existing users and data MUST be preserved
5. Database migrations must be additive only
6. JWT authentication (NOT express-session) -- ignore any doc that says express-session

**Source:** UNIFIED_HANDOFF_PROMPT.md Section 1

**6d. RLS Safety**
- Every query passes through SecureQueryBuilder which sets RLS context
- WARNING: SecureQueryBuilder uses WRONG variable name (see Gotchas 14b)
- Do NOT add new routes that depend on SecureQueryBuilder for org isolation [REVIEWER addition]

**Source:** DO_NOT_TOUCH.md Section 4; DEVELOPMENT_TEAM_BRIEFING.md Lessons 4-5

**6e. Data Safety**
- VIN Solutions data is sensitive -- read-only by default
- Writes require careful validation and correct API formatting
- Filter `source != 'excel_upload'` on ALL lead queries

**Source:** CONSTITUTION.md Section 2.5; DEVELOPMENT_TEAM_BRIEFING.md Lesson 7

**6f. Before Any VIN API Work** [REVIEWER addition]
1. Consult VIN documentation in filestore/VinDocs/
2. Check which endpoints are accessible vs blocked (17 blocked)
3. Use correct version headers: v1 for reference data, v3 for leads, gateway for user data
4. VIN documentation says uppercase V3 -- production rejects it. Use lowercase v3.

**Source:** DEVELOPMENT_TEAM_BRIEFING.md Lesson 3; MASTER_SRS.md Section 6.1

**6g. Before New Endpoints** [REVIEWER addition]
- If a UI feature needs a new endpoint, STOP and ask the owner
- Check server-audit.md -- most endpoints already exist (~237 total)
- Do NOT add new API routes from the frontend

**Source:** UNIFIED_HANDOFF_PROMPT.md Section 14; DO_NOT_TOUCH.md Section 20

**6h. Live Production Feature**
Webhook (email on call complete) is the only confirmed live production feature. Verify at every transition.
**Source:** CLAUDE.md (pre-enforcer); session-knowledge.md

---

### Category 7: Quality Gates

BOTH AGREE. Merged.

**7a. Three-Proof Validation (Per Feature)**
Every feature requires THREE pieces of evidence:
1. **Configuration test** -- verify configs, env vars, settings work
2. **Functional test** -- verify feature works (unit/integration test)
3. **Visual/E2E test** -- verify UI/API produces expected results

A feature is CERTIFIED only after all three proofs pass. Until then, it is IN PROGRESS regardless of how much code has been written.
**Source:** CONSTITUTION.md Section 2.6; CLAUDE.md (pre-enforcer)

**7b. Pre-Deploy Quality Gate Sequence**
```
npm run check -> npm run build -> npx playwright test
```
All three must pass with zero errors before any deploy.
**Source:** CONSTITUTION.md Section 3.4

**7c. Metric Certification Requirements**
A metric is only certified if:
- It has a defined name, data source(s), computation formula, field dependencies, and fill rate requirement
- Underlying data fields are actually populated (>50% fill rate from 50+ record sample)
- Computed result matches ground truth (direct API query) within 2%
- Data source is accessible (not a blocked 403 endpoint)

**Source:** MASTER_SRS.md Section 8.2

**7d. Evidence Standards**
- No finding listed without file citation (path + line or hash)
- Any "COMPLETED" label requires: link to artifact, timestamp, verifiable reference
- Prove functionality with tests/screenshots/logs -- not "it passed"
- Results are captured as artifacts (log files, screenshots, test output)
- Metrics require automated verification, not manual checks [REVIEWER addition]

**Source:** opinions_facts.md.md Rules 1, 4; Agent Instructions.md Section 4

**7e. Data Accuracy Mandate** [REVIEWER addition]
"We cannot have data that is wrong. We cannot have metrics that are wrong." (owner's words)
A metric showing correct data is worth more than ten metrics showing guesses.
**Source:** CLARIFICATION_ANSWERS.md "Overarching Mandate"

---

### Category 8: Agent Team Structure

BOTH AGREE. Reviewer more detailed; merged.

**8a. Roles**

| Role | Type | Responsibility | Access |
|------|------|---------------|--------|
| Architect | Plan (read-only) | Decompose specs, define interfaces, resolve ambiguity | Read-only |
| Implementer(s) | General-purpose | Write code within assigned scope | Full |
| Validator | General-purpose | Write/run tests, verify metrics | Full |
| Auditor | Explore (read-only) | Review for gaps, inconsistencies, security | Read-only |
| Lead | Orchestrator | Assign work, enforce gates, make decisions | Full |

**Source:** Agent Instructions.md Section 2.1

**8b. Scaling Rule**
- 1 Architect (always)
- min(N, 3) Implementers (each in a worktree, max 3 parallel)
- 1 Validator per 2 Implementers
- 1 Auditor (after each phase gate)

**Source:** Agent Instructions.md Section 2.3

**8c. Development Phases** [REVIEWER addition]
- Phase 0: Decomposition (Architect only -- produces Task Dependency Graph)
- Phase 1: Interface-First Implementation (types, signatures, schemas -- no logic)
- Phase 2: Implementation (parallel, in isolated worktrees)
- Phase 3: Validation (Validator tests merged code, not individual branches)
- Phase 4: Audit (Auditor is read-only, reports findings, does not fix)

**Source:** Agent Instructions.md Section 3

**8d. Communication Protocol** [REVIEWER addition]
- Implementer discovers interface needs to change -> STOP. Message Lead. Do not modify unilaterally.
- Implementer blocked by another task -> Message Lead for reassignment.
- Spec ambiguity -> Message Lead with 2-3 options. Do not guess.
- Status updates: DM to Lead only (not broadcast).

**Source:** Agent Instructions.md Section 5

**8e. Task Lifecycle** [REVIEWER addition]
```
CREATED -> ASSIGNED -> IN_PROGRESS -> REVIEW -> VALIDATED -> DONE
                    |                           ^
                  BLOCKED -----------------------|
```
A task is not DONE until it passes through Validator AND Auditor.
**Source:** Agent Instructions.md Section 7

**8f. Gatekeeper Gap (Critical -- Both Agents Identified)**

**Analyst description:**
> "Gatekeeper: sprint lifecycle quality -- scope criteria, verify builder output, loop until ALL pass, handoff. Enforcer: commit compliance -- check governance, safety gates, quality gates before commit. DIFFERENT JOBS. Gatekeeper was archived, enforcer doesn't fill its role. Gap: nobody currently loops builder output against AC + RUI until criteria pass."

**Reviewer description:**
> "Gatekeeper (archived): sprint lifecycle quality -- scope criteria, verify builder output, loop until ALL pass, handoff. Was the OLD system. Self-certified during incident (31 unauthorized commits). ARCHIVED. Enforcer (active): commit compliance. Does NOT self-certify. Gap: Nobody currently loops builder output against AC + RUI until criteria pass."

**Merged description:** The gatekeeper was archived after it self-certified during an incident (31 unauthorized commits). The enforcer replaced it but serves a different function: the enforcer gates commits for compliance; the gatekeeper looped builder output against AC + RUI until all criteria passed (quality verification). The quality verification loop function has no replacement. This is a structural gap requiring owner decision.

**Source:** session-knowledge.md Section 4; failure-analysis.md Category H; known_issues.md.md

---

### Category 9: Enforcer Rules

BOTH AGREE. Merged.

**9a. What the Enforcer Is**
- Owner's personal representative, Claude-native agent
- Separate from the agent team
- Lives at: `.claude/agents/enforcer.md` (only agent definition file that exists)
- Workspace: `.agent_docs/` directory

**Source:** session-knowledge.md Section 4

**9b. What the Enforcer Checks**
- Commit compliance against governance documents
- Safety gates (RLS, auth, data integrity)
- Quality gates (tests passing, evidence captured)
- Flags conflicts in `enforcer_context.md`

**Source:** known_issues.md.md; session-knowledge.md

**9c. What the Enforcer Does NOT Do**
- Does NOT gate read-only testing passes (only commits)
- Cannot check comprehension of architecture (only document compliance)
- Cannot force resolution of flagged conflicts (requires owner)
- Cannot prevent architectural misunderstanding if knowledge is not in files [REVIEWER addition]
- Cannot compensate for placeholder files used as authoritative truth [REVIEWER addition]

**Source:** known_issues.md.md items 1-6

---

### Category 10: RBAC Rules

BOTH AGREE. Reviewer adds route-level note; merged.

**10a. 4-Tier Role Hierarchy**

| Capability | `super_admin` | `partner_admin` | `org_admin` | `org_staff` |
|------------|:---:|:---:|:---:|:---:|
| Create partners | Yes | No | No | No |
| Create organizations | Yes | Yes | No | No |
| Manage billing | Yes | No | No | No |
| System settings | Yes | No | No | No |
| Create Org Admins | Yes | Yes (assigned) | No | No |
| Create Staff | Yes | Yes (assigned) | Yes (own org) | No |
| Configure agents | Yes | Yes (assigned) | Yes (own org) | No |
| Create trigger rules | Yes | Yes (assigned) | Yes (own org) | No |
| Use DealerBrain/Automa | Yes | Yes | Yes | Yes |
| Access Insights | Yes | Yes | Yes | Yes (read-only) |
| Access Activity (oversight) | Yes | Yes | Yes | No |
| Direct VIN query access | Yes | Yes | Yes | No |
| Switch organizations | Yes | Yes | Yes (if multi-org) | No |

**Source:** CONSTITUTION.md Section 5; MASTER_SRS.md Section 3.1

**10b. Dashboard Minimum Certified Metrics Per Role** [ANALYST addition]

| Role | Minimum | Focus |
|------|---------|-------|
| `org_admin` | 10 | Pipeline health, team performance, AI activity |
| `org_staff` | 5 | Personal leads, tasks, performance vs team average |
| `partner_admin` | 5 | Org engagement, adoption, credit usage |
| `super_admin` | 5 | System-wide health, cost, usage |

**Source:** MASTER_SRS.md Section 8.4

**10c. Data Access Rules**
- Data access follows RBAC at the database level via RLS policies
- No cross-org data leakage
- `partner_admin`: Aggregate metrics across assigned orgs, no individual PII
- `org_staff`: Own assignments only, no direct VIN query access
- All roles: Functionality delivered through appropriate UI surfaces
- Agents are created by `org_admin`+ and shared down to staff [REVIEWER addition]
- Activity feed (oversight) only accessible to `org_admin` and above [REVIEWER addition]
- Lead assignment must be configurable via Settings, never hardcoded [REVIEWER addition]

**Source:** CONSTITUTION.md Section 2.3; MASTER_SRS.md Section 3.1, 3.2, 3.3

**10d. Tool Provisioning Flow** [ANALYST addition]
```
Super Admin -> Provisions tools -> Partner Admin -> Manages orgs -> Org Admin -> Uses tools
```
Super Admin controls all tool provisioning (VIN Solutions, VAPI, Tavus). Partner Admin can view tool usage but cannot configure tools. Org Admin uses pre-provisioned tools (credentials encrypted).
**Source:** ARCHITECTURE_GUIDE_RBAC_ADDITION.md

**10e. Route-Level RBAC** [REVIEWER addition]
RBAC enforcement should be at the route level, not component level. Current code has it scattered across components -- this is a known problem.
**Source:** DEVELOPMENT_TEAM_BRIEFING.md

---

### Category 11: Data Accuracy Rules

BOTH AGREE. Merged with Reviewer's additions.

**11a. Metric Certification Requirements**
A metric is only certified if:
- It has a defined name, data source(s), formula, field dependencies, fill rate requirement
- Underlying data fields are actually populated (>50% fill rate from 50+ record sample)
- Computed result matches ground truth within 2%
- Data source is accessible (not a blocked 403 endpoint)
- Metrics depending on blocked endpoints are excluded entirely (not shown, not placeholdered)

**Source:** MASTER_SRS.md Section 8.2; CONSTITUTION.md Section 2.4

**11b. Blocked Data Handling**
- No metric is displayed without ground truth verification
- Metrics depending on blocked/inaccessible endpoints are excluded entirely
- No placeholder data, no "coming soon" indicators, no speculative numbers
- 17 VIN gateway endpoints return 403 Forbidden
- Features that depend on blocked data must NOT have UI

**Source:** CONSTITUTION.md Section 2.4; MASTER_SRS.md Section 7.5

**11c. Excel Upload Exclusion**
Filter `source != 'excel_upload'` required on ALL lead queries. Already fixed in 32+ queries across 11 files.
**Source:** DEVELOPMENT_TEAM_BRIEFING.md Lesson 7; MASTER_SRS.md Section 7.2

**11d. Honest AI Policy**
- DealerBrain admits when data is unavailable -- does not fabricate
- When asked about blocked data, explains limitations and offers alternatives
- AI responses cite data sources internally (not for customer display)

**Source:** CONSTITUTION.md Section 2.2

**11e. Source Tagging** [REVIEWER addition]
All data responses include source tag (`VIN`, `VAPI`, `TAVUS`, `LOCAL`) -- internal only for traceability. Not displayed to users.
**Source:** CONSTITUTION.md Section 3.2; MASTER_SRS.md Section 7.2

**11f. Cache TTL Policy**

| Data Source | Cache TTL |
|-------------|-----------|
| VIN leads | 5 minutes |
| VAPI/Tavus | 1 hour |
| Local-only data | No cache |

Fallback: VIN fail -> local cache with staleness warning in LOGS (not UI).
**Source:** CONSTITUTION.md Section 3.2; MASTER_SRS.md Section 7.2

---

### Category 12: UI Immutability Rules

BOTH AGREE. Reviewer adds cross-contamination; merged.

**12a. RUI Is Tier 1 Truth**
- Live RUI mockup at https://nexxusv2sample.replit.app/ is the immutable visual spec
- Tier 1 in truth hierarchy -- can be ADDED TO, never MODIFIED
- Use for Playwright visual comparison
- Note: SPA, will not render with simple fetch/curl -- needs Playwright or real browser
- Static RUI files also at: filestore/nexus-v2-1-current/

**Source:** session-knowledge.md; UNIFIED_HANDOFF_PROMPT.md Section 2

**12b. UI Rules**
- No placeholder UI for blocked features
- No "coming soon" indicators, no speculative numbers
- No vendor names in customer-facing UI
- No source labels in UI
- Owner's designs are source of truth, not existing frontend, not agent assumptions

**Source:** CONSTITUTION.md Section 3.1; UNIFIED_HANDOFF_PROMPT.md Section 14

**12c. Cross-Contamination Prevention** [REVIEWER addition]
- Do NOT copy patterns from the existing frontend visual components -- build fresh from designs
- Do NOT inherit assumptions from the old frontend
- The existing codebase is a "parts bin" -- take what works (data hooks), leave what doesn't (visual patterns)

**Source:** DEVELOPMENT_TEAM_BRIEFING.md; UNIFIED_HANDOFF_PROMPT.md Section 14

---

### Category 13: Key Technical Facts

BOTH AGREE on metrics. Merged with Reviewer's additions.

**13a. Codebase Quick-Reference**

| Metric | Value | Source |
|--------|-------|--------|
| Lines of code | ~117-118K TypeScript/TSX | health-audit.md |
| Total source files | 402 | health-audit.md |
| API endpoints | ~237 | server-audit.md |
| Database tables | 53 | database-audit.md |
| Database migrations | 33 | database-audit.md |
| RLS policies | ~100 across 28 tables | database-audit.md |
| Database indexes | 160+ | database-audit.md |
| Service modules | 40+ | server-audit.md |
| Route files | 34 | server-audit.md |
| Scheduled jobs | 8 | DO_NOT_TOUCH.md |
| Third-party integrations | 7 | UNIFIED_HANDOFF_PROMPT.md |
| E2E tests (Playwright) | 747 across 46 files | health-audit.md |
| Unit tests | 0 | health-audit.md |
| `any` type annotations | 380 (325 in server/) | DEVELOPMENT_TEAM_BRIEFING.md |
| npm dependencies | 122 (91 prod + 31 dev) | health-audit.md |
| TanStack Query hooks | 26 hooks, ~38 queries, ~34 mutations | CARRY_FORWARD_MANIFEST.md |
| DealerBrain tools | 24 | [ANALYST addition] |
| Frontend pages | 21 | [ANALYST addition] |
| Frontend components | 59 | [ANALYST addition] |

**13b. Authentication Architecture**
- JWT-based (NOT express-session -- if any doc says express-session, ignore it)
- Access + refresh tokens stored in localStorage
- Keys: `nexxus_access_token`, `nexxus_refresh_token`, `nexxus_token_expiry`, `nexxus_accessible_orgs`
- Auto-refresh: checks every 60s, refreshes when < 5 min to expiry
- On refresh failure: automatic logout [REVIEWER addition]
- Login: `POST /api/auth/login`, Refresh: `POST /api/auth/refresh`, Org switch: `POST /api/auth/switch-org`

**Source:** UNIFIED_HANDOFF_PROMPT.md Section 3.3; CARRY_FORWARD_MANIFEST.md Section 5

**13c. Server Architecture** [REVIEWER addition]
- Express server, PM2-managed, compiled from TypeScript to `dist/index.cjs`
- Supabase (PostgreSQL) database
- Webhooks registered BEFORE body parsers (order matters in `server/routes.ts`)
- No active WebSocket in production -- real-time uses SSE (DealerBrain) + polling

**Source:** DO_NOT_TOUCH.md Sections 1-9; UNIFIED_HANDOFF_PROMPT.md Section 3.5

**13d. Economics**

| Service | Customer Price | Cost | Margin |
|---------|---------------|------|--------|
| Voice AI | $0.25/min | $0.15/min | 40% |
| Video AI | $0.32/min | $0.20/min | 37.5% |
| SMS | $0.05/msg | $0.02/msg | 60% |

**Source:** CLAUDE.md (pre-enforcer)

**13e. Production Customers**
- Serra Automotive (Serra Honda dealer ID 21043, Serra Nissan 21044, Tony Serra Ford 21047)
- Hyundai of Columbia (Hyundai of Columbia, Ford of Columbia)
- Live URL: https://nexxusv2.huminicdev.com
- Platform operator: Huminic (`super_admin`)
- First partner: Duran Cage
- Two customers are live -- do not break webhook processing, VIN sync, or notification delivery

**Source:** DEVELOPMENT_TEAM_BRIEFING.md; CONSTITUTION.md; app_identity.md

**13f. Skills Architecture (Critical)** [REVIEWER addition]
- V1: 27 separate agents + a super chat. Each agent was an overlay with prepopulated context and instructions.
- V2: Users CREATE their own agents and ADD skills to them. Skills are pre-prompting, context, instructions -- user-selectable, not fixed.
- Widgets are portals to agents (not standalone features).
- Externally-initiated conversations (via widget) can be continued internally in Unified Inbox.

**Source:** session-knowledge.md Section 0, 0b

**13g. Environment Variables** [ANALYST addition]
- 33 environment variables required
- No `VITE_` env vars in frontend -- all API calls use relative URLs
- Key categories: Database, Auth, AI, VIN Solutions, VAPI, Tavus, Email, SMS, Google Calendar

**Source:** UNIFIED_HANDOFF_PROMPT.md Section 13

---

### Category 14: Known Gotchas

BOTH AGREE. Merged with additions from each.

**14a. VIN API Header Format**
Documentation says `application/vnd.coxauto.V3+json` (uppercase V3). Production API REJECTS uppercase. Use `application/vnd.coxauto.v3+json` (lowercase v3). Reference endpoints require v1 headers. Lead CRUD requires v3 headers. Gateway endpoints require `application/json`.
**Source:** DEVELOPMENT_TEAM_BRIEFING.md Lesson 3; MASTER_SRS.md Section 6.1

**14b. RLS Variable Name Mismatch (CRITICAL BUG)**
`SecureQueryBuilder` sets `app.current_organization_id` but RLS policies check `app.current_org_id`. Different variable names. System works because most routes bypass SecureQueryBuilder. SecureQueryBuilder also uses `SET LOCAL` without a transaction -- variable can persist on pooled connection. Risk: potential cross-tenant data leak. Do NOT add new routes that depend on SecureQueryBuilder for org isolation.
**Source:** DEVELOPMENT_TEAM_BRIEFING.md Lessons 4, 5

**14c. Excel Upload Pollution**
Any new lead query MUST exclude `source = 'excel_upload'` or metrics will show inflated numbers. Already fixed in 32+ queries across 11 files.
**Source:** DEVELOPMENT_TEAM_BRIEFING.md Lesson 7

**14d. Lead Creation Is Two-Step**
VIN lead creation: (1) create contact via gateway POST -> get ContactId, (2) create lead with contact as URL reference (`/contacts/id/12345?dealerid=67890`). `leadSource`, `leadType`, and `contact` fields are ALL href references, NOT string names. `dealerId` goes in query parameter, NOT in request body. [REVIEWER addition: dealerId placement]
**Source:** DEVELOPMENT_TEAM_BRIEFING.md Lesson 2; MASTER_SRS.md Section 6.1

**14e. VIN API Blocks 17 of 30 Endpoints**
17 VIN gateway endpoints return 403 Forbidden. Nexxus sees beginning (lead creation) and end (SOLD/LOST) but NOT middle (deals, appointments, communication logs). Do NOT build UI for data that does not exist.
**Source:** DEVELOPMENT_TEAM_BRIEFING.md Lesson 1; MASTER_SRS.md Section 6.1

**14f. Context Router Was Inverted**
Originally configured backwards (local DB primary, VIN fallback). Corrected to: VIN API primary, local DB fallback. `CONTEXT_ROUTER_ENABLED=true` in env.
**Source:** DEVELOPMENT_TEAM_BRIEFING.md Lesson 6

**14g. Webhook Route Order Matters**
VAPI webhook registered BEFORE body parsers in `server/routes.ts`. Tavus webhook needs raw body capture for HMAC verification. DO NOT move webhook registrations or change their order.
**Source:** DO_NOT_TOUCH.md Section 2; UNIFIED_HANDOFF_PROMPT.md Section 3.2

**14h. TextMagic Credentials Are Per-Org**
TextMagic credentials are stored per-organization in the database, NOT in `.env`. Testing with `.env` credentials produces 401 errors for org-level operations.
**Source:** session-knowledge.md; known_issues.md.md

**14i. CLAUDE.md Is chmod 444**
CLAUDE.md in nexxus-v2 is read-only (chmod 444). Only the owner can edit. This is a defensive measure against agents modifying it without consent.
**Source:** session-knowledge.md; opinions_facts.md.md

**14j. VIN API Has No 48-Hour Retention Limit** [ANALYST addition -- resolved CONFLICT 5]
Prior claims of a 48-hour data limit via VIN API were FALSE. VIN API has full history access (verified). DealerBrain system prompt lines referencing this are flagged for removal.
**Source:** IMPLEMENTATION_PLAN.md Phase 1.3; CLARIFICATION_ANSWERS.md Q6

**14k. VIN OAuth Token Expiry** [REVIEWER addition]
OAuth bearer tokens expire every 60 minutes -- caching handled in VinOAuthService.
**Source:** CLAUDE.md (pre-enforcer)

**14l. Three Governance Layers** [REVIEWER addition]
Three authority systems were historically stacked: `.project/` (from /init), `.agent_docs/` (from enforcer bootstrap), `filestore/` (original project files). Resolution: `.project/` gets gutted, `.agent_docs/` stays, new consolidated governance files at root.
**Source:** Current_State.md.md; session-knowledge.md Section 1

---

### Category 15: Prohibited Actions (Deduplicated -- 28 Items)

Both agents produced overlapping lists. Below is the merged, deduplicated set.

**Production Safety (7 items)**

| # | Rule | Source |
|---|------|--------|
| P1 | NEVER modify production v1 (`/home/ubuntu/Claude-store/nexxus/`) | CONSTITUTION.md Section 6 |
| P2 | NEVER share credentials between v1 and v2 | CONSTITUTION.md Section 6 |
| P3 | NEVER deploy from a feature branch | CONSTITUTION.md Section 6; CLAUDE.md |
| P4 | NEVER break webhook processing, VIN sync, or notification delivery | CONSTITUTION.md Section 6 |
| P5 | NEVER modify `server/webhooks/vapi.ts` without explicit approval | CONSTITUTION.md Section 6 |
| P6 | NEVER modify `server/webhooks/tavus.ts` without explicit approval | CONSTITUTION.md Section 6 |
| P7 | NEVER drop, truncate, or destructively migrate database tables | UNIFIED_HANDOFF_PROMPT.md Section 1 |

**Data Integrity (6 items)**

| # | Rule | Source |
|---|------|--------|
| D1 | NEVER fabricate data or show unverified metrics | CONSTITUTION.md Section 6 |
| D2 | NEVER display metrics depending on blocked endpoints | CONSTITUTION.md Section 2.4 |
| D3 | NEVER show placeholder data, "coming soon" indicators, or speculative numbers | CONSTITUTION.md Section 3.1 |
| D4 | NEVER serve stale/cached data as truth (respect cache TTLs) | CONSTITUTION.md Section 3.2 |
| D5 | NEVER bypass RLS or multi-tenant isolation | CONSTITUTION.md Section 6 |
| D6 | NEVER hardcode integration-specific values (API keys, phone numbers, lead assignments) | CONSTITUTION.md Section 6 |

**UI Rules (3 items)**

| # | Rule | Source |
|---|------|--------|
| U1 | NEVER expose vendor names ("Tavus", "VAPI", "TextMagic") in customer-facing UI | CONSTITUTION.md Section 3.1 |
| U2 | NEVER show source attribution labels ("VIN API", "Local + VIN") in UI | CONSTITUTION.md Section 3.1 |
| U3 | NEVER copy visual patterns from existing frontend -- build fresh from designs | DEVELOPMENT_TEAM_BRIEFING.md |

**Code/File Rules (7 items)**

| # | Rule | Source |
|---|------|--------|
| F1 | NEVER modify files in `server/`, `database/`, `widget/`, `scripts/` without explicit approval | DO_NOT_TOUCH.md |
| F2 | NEVER modify `shared/schema.ts` | DO_NOT_TOUCH.md |
| F3 | NEVER modify existing npm dependencies (versions or removal) | DO_NOT_TOUCH.md Section 15 |
| F4 | NEVER modify the `scripts` section of `package.json` | DO_NOT_TOUCH.md Section 15 |
| F5 | NEVER reorder routes in `server/routes.ts` | DO_NOT_TOUCH.md |
| F6 | NEVER modify WebSocket protocol or JWT token format/storage | DO_NOT_TOUCH.md Section 20 |
| F7 | NEVER rewrite PRESERVE files from CARRY_FORWARD_MANIFEST.md | CARRY_FORWARD_MANIFEST.md |

**Process Rules (5 items)**

| # | Rule | Source |
|---|------|--------|
| X1 | NEVER mark something COMPLETED without artifact + timestamp + verifiable reference | opinions_facts.md.md |
| X2 | NEVER modify CLAUDE.md without owner consent (chmod 444) | opinions_facts.md.md |
| X3 | NEVER self-certify work as complete -- separate validator required | Agent Instructions.md Section 7 |
| X4 | NEVER assume -- when in doubt, STOP and ask | Agent Instructions.md; Global CLAUDE.md |
| X5 | NEVER treat archived materials as current truth | session-knowledge.md |

**Plan Discipline (3 items)** [REVIEWER additions]

| # | Rule | Source |
|---|------|--------|
| L1 | NEVER ad-lib features or "do something else" -- follow the plan | CLAUDE.md Section 4 |
| L2 | NEVER skip ahead or work on later phases | CLAUDE.md Section 4 |
| L3 | NEVER build features that imply VIN data access without checking which endpoints are accessible | DEVELOPMENT_TEAM_BRIEFING.md |

---

## RECONCILED CONFLICTS

### CONFLICT 1: Document Truth Hierarchy Ordering
**Status:** FLAGGED AS DISAGREE-1 -- requires owner resolution.

### CONFLICT 2: Number of Governing Documents (RESOLVED)
**Analyst found:** CLAUDE.md (pre-enforcer) lists 4 docs in `docs/`; Standards.md defines 6 files at root.
**Reviewer found (C6-2):** Same observation -- old path `docs/` vs new root-level structure.
**Resolution:** BOTH AGREE. The new structure is 6 files at project root, replacing the old 4-in-docs structure. Standards.md is the owner's explicit decision. References in CLAUDE.md must use root paths.
**Source:** Standards.md; session-knowledge.md Section 2

### CONFLICT 3: Acceptance Criteria Status Claims (RESOLVED)
**Analyst found:** release_criteria.md, Run 2 FINAL_REPORT.md, and verified-findings.md all show different P0 counts.
**Resolution:** All three are historically accurate for their time but all are stale. The new PLAN.md gap tracker will be the single source of truth going forward.

### CONFLICT 4: Webhook Email (NO CONFLICT)
**Analyst found:** Both CLAUDE.md and session-knowledge.md agree -- webhook email on call complete is the only live production feature. Verify at every transition.
**Resolution:** No conflict. Included in Safety Gates (6h) above.

### CONFLICT 5: VIN Solutions Data Retention (RESOLVED)
**Analyst found:** DealerBrainService.ts (line 840) claims 48-hour limit; IMPLEMENTATION_PLAN.md and CLARIFICATION_ANSWERS.md disprove it.
**Resolution:** The 48-hour claim is FALSE. VIN API has full history access. The DealerBrain system prompt lines are flagged for removal. New CLAUDE.md must NOT include the 48-hour claim. Included in Gotchas (14j).

### CONFLICT C6-1: Acceptance Criteria Count
**Status:** FLAGGED AS DISAGREE-4 -- requires owner resolution.

### CONFLICT C6-3: Implementation Plan Sequencing
**Status:** FLAGGED AS DISAGREE-3 -- requires owner resolution.

### CONFLICT C6-4: RLS Variable Name (RESOLVED)
**Reviewer found:** CONSTITUTION.md presents SecureQueryBuilder as functional, but it uses the wrong variable name.
**Resolution:** Both agents document this in Gotchas (14b). CLAUDE.md should note it as a known bug and warn against using SecureQueryBuilder for new routes. Included above.

### CONFLICT C6-5: Widget Channel Count (MINOR -- NO ACTION)
**Reviewer found:** Code has 6 channel components; MASTER_SRS describes 4.
**Resolution:** Minor discrepancy. Code is authoritative for what exists. SRS.md reconciliation (Wave 4) should capture the correct count. No CLAUDE.md impact.

### CONFLICT C6-6: "MVP" Terminology (RESOLVED)
**Reviewer found:** Owner prefers "launch-critical" or "payment-critical" over "MVP."
**Resolution:** Included in Naming Conventions (3f). New CLAUDE.md must use "launch-critical" or "payment-critical."

---

## MERGED MISSING INFORMATION

Items found by one or both agents that are not currently documented in any file agents read. These must either be added to the new CLAUDE.md, SRS.md, or PLAN.md, or explicitly deferred.

### MISSING-1: Skills Architecture Documentation
**Found by:** Both (Analyst item 8, Reviewer M6-2)
**Description:** The V1-to-V2 architecture transition (27 hardcoded agents -> user-created agents with selectable skills) was explained 3+ times by the owner but never written to any file agents read. Only exists in session-knowledge.md.
**Recommendation:** Must be in SRS.md and referenced in CLAUDE.md.
**Target file:** SRS.md (primary), CLAUDE.md (reference)

### MISSING-2: Gatekeeper Function Replacement
**Found by:** Both (Analyst item in 8c, Reviewer M6-5)
**Description:** The gatekeeper was archived. The enforcer does not perform the gatekeeper's quality verification function (loop builder output against AC + RUI until criteria pass). This structural gap needs an owner decision.
**Recommendation:** Document in CLAUDE.md under Agent Team Structure -- either define a replacement mechanism or explicitly note the gap as accepted.
**Target file:** CLAUDE.md
**OWNER DECISION NEEDED**

### MISSING-3: Widget-as-Portal Pattern
**Found by:** Reviewer (M6-3)
**Description:** Widgets are portals to agents, not standalone features. Externally-initiated conversations continue internally in Unified Inbox. Only in session-knowledge.md.
**Recommendation:** Must be in SRS.md.
**Target file:** SRS.md

### MISSING-4: Owner's 5 Watch Areas
**Found by:** Reviewer (M6-4)
**Description:** From session-knowledge.md -- these require extra attention during every wave:
1. Agent functionality/defaults
2. Billing
3. Unified inbox handoff
4. Super Admin functionality
5. Context Router functionality
**Recommendation:** Include in CLAUDE.md or PLAN.md as a verification checklist.
**Target file:** PLAN.md (recommended) or CLAUDE.md

### MISSING-5: Change Consent Boundary
**Found by:** Reviewer (M6-6)
**Description:** opinions_facts.md.md requests: "Write down which files agents may modify without approval and which require explicit consent." DO_NOT_TOUCH.md covers backend freeze but does not define consent boundaries for governance files.
**Recommendation:** Define in CLAUDE.md: governance files (at root) require owner consent; client/ files within scope are modifiable; everything else follows DO_NOT_TOUCH.md.
**Target file:** CLAUDE.md

### MISSING-6: Testing Protocol Details
**Found by:** Reviewer (M6-7), Analyst (item 7)
**Description:** Testing details scattered across documents:
- Voice testing: use "Elliot" test-only VAPI agent
- SMS testing: loopback to self via TextMagic API -- never to real customers
- Email testing: use `neoweaver@gmail.com`
- Video testing: test sessions only -- never production Tavus sessions
- Playwright viewport: fixed to 1280x720
- Test battery location and naming standard not defined
**Recommendation:** Consolidate in CLAUDE.md under a "Testing Protocol" section.
**Target file:** CLAUDE.md
**Source:** UNIFIED_HANDOFF_PROMPT.md Section 10; MEMORY.md

### MISSING-7: Orchestration Agent Specification
**Found by:** Analyst (item 1)
**Description:** CLARIFICATION_ANSWERS.md Q10 says "Not a definite need. Build only if architectural deficiency requires it." No spec exists.
**Recommendation:** Note as deferred/conditional in CLAUDE.md.
**Target file:** CLAUDE.md (as "not yet needed" note)

### MISSING-8: System Agents Definition
**Found by:** Analyst (item 2)
**Description:** CLARIFICATION_ANSWERS.md Q11 mentions system agents (background, invisible) vs user agents, but no file defines what system agents currently exist or what they do.
**Recommendation:** Define in SRS.md when the skills architecture is documented.
**Target file:** SRS.md

### MISSING-9: MCP Proxy Integration Rules
**Found by:** Analyst (item 3)
**Description:** Central-MCP at port 4002 exists but no integration rules are defined. CLARIFICATION_ANSWERS.md Q15 defers this.
**Recommendation:** Deferred per owner. Note as "not yet defined" in SPEC.md.
**Target file:** SPEC.md

### MISSING-10: Collision Avoidance Protocol
**Found by:** Analyst (item 4)
**Description:** MASTER_SRS.md Section 5.6 mentions conversation state tracking (AI_ACTIVE / HUMAN_ACTIVE / DORMANT) but no implementation rules exist.
**Recommendation:** Define in SRS.md under communication agent behavior.
**Target file:** SRS.md

### MISSING-11: Payment-Critical Demo Flow
**Found by:** Reviewer (M6-1)
**Description:** The 7-item payment-critical demo list (session-knowledge.md Section 0c) is the actual launch filter but does not exist in any formal governance document yet.
**Recommendation:** Must be in PLAN.md as the launch-critical filter.
**Target file:** PLAN.md

---

## OWNER ACTION ITEMS SUMMARY

### Decisions Required (4)

| # | Decision | Context | Default if No Decision |
|---|----------|---------|----------------------|
| D1 | Final Document Truth Hierarchy ordering (positions 4-7) | DISAGREE-1 | Use Analyst's ordering (PRD > SRS > SPEC > PLAN) |
| D2 | Is 6-tier reading order mandatory every session or only for new features? | DISAGREE-2 | Every-session: short list; new features: full 6-tier |
| D3 | Confirm "follow the plan's execution order" replaces "strictly sequential" | DISAGREE-3 | Use plan-defined order (allows parallelism where plan specifies) |
| D4 | Which AC set is the launch-critical filter? | DISAGREE-4 | 7-item payment-critical list from session-knowledge.md |

### Files to Create/Update (by target)

| Target File | Items to Include |
|-------------|-----------------|
| CLAUDE.md | All 15 reconciled categories; gatekeeper gap note (MISSING-2); change consent boundary (MISSING-5); testing protocol (MISSING-6); "not yet needed" notes for MISSING-7 |
| SRS.md | Skills architecture (MISSING-1); widget-as-portal (MISSING-3); system agents (MISSING-8); collision avoidance (MISSING-10) |
| PLAN.md | 5 watch areas (MISSING-4); payment-critical demo flow (MISSING-11) |
| SPEC.md | MCP proxy rules (MISSING-9, deferred) |

### Conciseness Notes

The following items from the reconciled output could be shortened in the final CLAUDE.md without losing meaning:

1. **Codebase Quick-Reference (13a):** Include only the 10 most operationally relevant metrics. The full table is reference material for SRS/SPEC.
2. **RBAC Permissions Matrix (10a):** Consider moving the full matrix to SRS.md and keeping only the 4-tier summary in CLAUDE.md.
3. **Economics (13d):** 3-row table is fine as-is.
4. **Production Customers (13e):** Shorten to: "Serra Automotive and Hyundai of Columbia are live. Do not break webhook processing, VIN sync, or notification delivery."
5. **Known Gotchas (14a-14l):** 12 items is a lot. Consider grouping into "VIN API Gotchas" (5 items) and "Infrastructure Gotchas" (7 items) for readability.
6. **Prohibited Actions (28 items):** Consider grouping into "top 10 most critical" with the full list as an appendix or in enforcer docs.
7. **Agent Team Structure (8c-8e):** Development phases, communication protocol, and task lifecycle are more relevant to Agent Instructions.md than CLAUDE.md. Consider keeping only the role table and scaling rule in CLAUDE.md, with a reference to Agent Instructions.md for the rest.

---

*End of Wave 6 reconciled output. 15 categories merged, 4 disagreements flagged, 9 conflicts resolved or escalated, 11 missing items documented, 28 prohibited actions deduplicated.*
