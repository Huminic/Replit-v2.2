# Phase 4: Priority Triage

**Date:** 2026-03-03
**Input:** ground-truth-diff.md (validated gap list)
**Purpose:** Owner makes launch-critical vs can-wait decisions. Gaps organized into incremental clusters.

---

## Triage Framework

Every gap evaluated against: **"Does this block the payment-critical demo?"**
- **Launch-critical:** Must fix before customer demo
- **Launch-adjacent:** Should fix but demo can proceed without it
- **Can-wait:** Fix after payment is secured

The 7 demo items (owner-defined):
1. Metrics & Insights display
2. Communications Agent configuration
3. Appointment flow → calendar → VIN note
4. Proactive lead follow-up (outbound call + text)
5. Reactive after-hours coverage (SMS + phone)
6. Widgets (all 3 deployment modes)
7. Automa Chat

---

## Current Demo Readiness (1 of 7)

| # | Demo Item | Status | What's Blocking It |
|---|-----------|--------|-------------------|
| 7 | Automa Chat | WORKING | Nothing |
| 6 | Widgets | MOSTLY WORKING | P0-1: `/p/:slug` fetch URL (trivial fix) |
| 1 | Metrics & Insights | PARTIAL | P0-2: 5 null guards (trivial fix) |
| 3 | Appointment Flow | PARTIAL | P0-3: no status notifications; P0-5: no VIN note link |
| 2 | Comms Agent Config | NOT WORKING | P0-4: 0 trigger executions |
| 4 | Proactive Follow-up | NOT WORKING | P0-4: 0 trigger executions; operational config needed |
| 5 | After-Hours Coverage | NOT WORKING | P1-9: SMS routing not wired; P0-4: business hours blocking |

---

## Proposed Clusters (Incremental Build Order)

### Cluster 0: Foundation Fixes (Quick Wins)
**Goal:** Clear trivial P0s and safety issues in one pass.
**Estimated effort:** Small — mostly one-line fixes.

| Gap | Description | Fix |
|-----|-------------|-----|
| P0-1 | `/p/:slug` fetches wrong API path | Change fetch URL in `hosted-page-public.tsx:163` OR redirect `/p/:slug` → `/w/:slug` |
| P0-2 | 5 unguarded `.pct` accesses in insights | Add optional chaining at 5 locations |
| P1-13 | Vendor names visible ("VIN Solutions", "DealerBrain") | Replace with user-facing names in ~5 locations |

**Done when:** `/p/:slug` loads a hosted page. Insights page doesn't crash with empty data. No vendor names in UI.

---

### Cluster 1: Metrics & Insights (DEMO-1)
**Goal:** Metrics and Insights display correctly.
**Dependencies:** Cluster 0

| Gap | Description | Fix |
|-----|-------------|-----|
| P0-2 | Already fixed in Cluster 0 | — |
| — | Verify DealerPulse job runs and populates data | Verify job interval, check DB for pulse data |
| — | Verify main dashboard tiles show real data (not static fallbacks) | Check API returns real values |

**Done when:** Owner can log in and see real metrics. Insights page loads without crash risk. DealerPulse gauges show data.

---

### Cluster 2: Automa Chat (DEMO-7) — Verification Only
**Goal:** Confirm it works end-to-end.
**Dependencies:** None

| Gap | Description | Fix |
|-----|-------------|-----|
| — | No code gaps found | Verify: can chat, tools work, SSE streaming, conversation history |

**Done when:** Owner chats with Automa, gets a meaningful response using CRM data.

---

### Cluster 3: Appointment Flow (DEMO-3)
**Goal:** Appointment → Calendar → Notification → VIN Note
**Dependencies:** Cluster 0

| Gap | Description | Fix |
|-----|-------------|-----|
| P0-3 | `updateAppointment()` fires no notifications | Add notification + trigger evaluation to update path |
| P0-5 | No appointment-to-VIN note pipeline | Add VIN sync queue insert from `createAppointment()` |
| P1-3 | `appointment_created` trigger never emitted | Add `evaluateEvent('appointment_created')` to create path |

**Done when:** Create appointment → appears in calendar → notification sent → note inserted into VIN Solutions lead record. Status change → notification fires.

---

### Cluster 4: Trigger System (Foundation for DEMO-2, 4, 5)
**Goal:** Make triggers actually execute in production.
**Dependencies:** Cluster 0

| Gap | Description | Fix |
|-----|-------------|-----|
| P0-4 | Zero production executions — condition timing bug | Fix `lead_age_minutes` evaluation to use current time, not import time |
| P0-4 | Business hours skip blocks all rules | Verify org business hours config; ensure test rules aren't all `businessHoursOnly: true` |
| P1-2 | `hot_lead` event never emitted | Add emission call site (likely in VIN polling when lead matches hot criteria) |

**Done when:** A new lead enters VIN → trigger rule matches → action executes (call or SMS). At least 1 real trigger completion in production.

---

### Cluster 5: Proactive Follow-up (DEMO-4)
**Goal:** New leads get outbound call + text automatically.
**Dependencies:** Cluster 4 (triggers must work first)

| Gap | Description | Fix |
|-----|-------------|-----|
| — | VAPI phone numbers must be configured per org | Operational: configure `phoneNumberId` in trigger rule `action_config` |
| — | TextMagic credentials must be configured per org | Operational: populate `textmagic_config` table for each org |
| — | Verify outbound call + SMS fire on new lead | End-to-end test after trigger system works |

**Done when:** New VIN lead → outbound VAPI call initiated + TextMagic SMS sent.

---

### Cluster 6: After-Hours Coverage (DEMO-5)
**Goal:** SMS + phone AI coverage when staff unavailable.
**Dependencies:** Cluster 4 (triggers), Cluster 5 (SMS wiring)

| Gap | Description | Fix |
|-----|-------------|-----|
| P1-9 | SMS after-hours AI routing not wired | Connect routing decision point to org business hours + Claude Haiku |
| — | Business hours config must be set per org | Operational: verify org hours in DB |

**Done when:** Inbound SMS outside business hours → AI auto-response. Inbound call outside hours → AI handles.

---

### Cluster 7: Widgets Verification (DEMO-6)
**Goal:** All 3 widget deployment modes work.
**Dependencies:** Cluster 0 (hosted pages fix)

| Gap | Description | Fix |
|-----|-------------|-----|
| P0-1 | Already fixed in Cluster 0 | — |
| — | Verify unified widget (bottom corner) loads on external site | Operational: test with widget embed code |
| — | Verify embed code mode works | Operational: test direct embed |
| — | Verify hosted page renders at `/w/:slug` | Already works per Agent A |
| — | Domain whitelisting configured for customer domains | Operational: populate `allowedDomains` |

**Done when:** All 3 widget modes render and connect to the correct agent.

---

## Gaps NOT in Any Cluster (Can Wait)

These are real gaps but don't block any of the 7 demo items:

| Gap | Severity | Why It Can Wait |
|-----|----------|----------------|
| P1-1 | RLS variable mismatch | System works via bypass; only matters if someone refactors to use SecureQueryBuilder |
| P1-4 | Agent performance metrics never populated | Nice-to-have analytics, not demo-critical |
| P1-5 | Mark Contacted doesn't write to VIN | CRM write-back is desirable but not in the 7 demo items |
| P1-6 | Tavus zero sessions | Video agents not in demo items |
| P1-7 | 19-28% VIN lead capture gap | Polling works; gap is a tuning issue |
| P1-8 | 38 unregistered VAPI assistant calls | Historical data issue, not forward-blocking |
| P1-10 | Hub has 6 tabs, spec says 3 | UI mismatch — fix per RUI, but cosmetic for demo |
| P1-11 | Activity standalone vs Insights sub-tab | UI consolidation — cosmetic for demo |
| P1-12 | Skills catalog has 4 seeds, not 74 | Skills not in demo items (owner confirmed) |
| P1-14 | idle_trigger_count never resets | Edge case; leads would need 3+ idle cycles |
| P1-15 | VAPI webhook security soft-check | Security hardening, not demo-blocking |
| P2-1 through P2-4 | Documentation/process gaps | Phase 5 governance files address these |
| P3-1, P3-2 | CI/CD, npm vulnerabilities | Infrastructure, not demo-blocking |

---

## Owner Decisions Needed

1. **Does this cluster ordering make sense?** Or would you reorder any of them?
2. **Are any "can wait" items actually launch-critical?** (Especially P1-10 Hub tabs — the RUI shows 3 but fixing it is more than cosmetic, it requires removing 3 tabs from the component.)
3. **Cluster 5 and 6 depend heavily on operational config** (VAPI phone numbers, TextMagic creds, business hours). Do you have these values ready, or do they need to be gathered?
4. **Is Tavus/video (P1-6) truly can-wait?** The 5 personas are named but zero are wired.
