# Wave 2 RECONCILED Output -- System Behavior for SRS

**Date:** 2026-03-03
**Reconciled by:** Orchestrator
**Inputs:** wave2-analyst.md (1290 lines, 51 files read), wave2-reviewer.md (898 lines, 48 files read)

---

## Reconciliation Summary

| Metric | ANALYST | REVIEWER |
|--------|---------|----------|
| Files Read | 51 of 53 | 48 of 53 |
| Files Skipped | 2 (replit_reference, Chat-Checklist) | 5 (replit_reference, Chat-Checklist, Insights Layout copy, INSIGHT_CARDS_SPECIFICATION, NEXXUS_V2_BOOTSTRAP_PROMPT) |
| Categories Covered | 12/12 | 12/12 |
| Watch Areas Covered | 5/5 | 5/5 |
| Conflicts Found | 13 (C-01 through C-13) | 8 (CONFLICT 1 through CONFLICT 8) |
| Missing Items Found | 15 (MI-01 through MI-15) | 11 (NOT FOUND 1 through NOT FOUND 11) |
| Cross-Wave Notes | 7 verified | 7 verified |

**Agreement Level:** HIGH. Both agents agree on all core system behaviors, data flows, and architectural facts. Disagreements are limited to enumeration details (event type names, action type names) and depth of coverage. No factual contradictions found on any substantive claim.

**Key Differences:**
- ANALYST read 3 additional files (Insights Layout copy, INSIGHT_CARDS_SPECIFICATION, NEXXUS_V2_BOOTSTRAP_PROMPT) -- no unique findings resulted from the extra reads
- REVIEWER provided more detailed citations (specific line numbers) for data flow narratives
- ANALYST provided more detailed coverage of billing UI, Super Admin functionality, and aspirational architecture
- REVIEWER identified more specific production failure details (832 vs 159 records, 137 post-V2 records from bulk import)

---

## DISAGREEMENTS REQUIRING OWNER RESOLUTION

### DISAGREE-1: Trigger Event Type Names

**ANALYST claim:** 7 event types: `new_lead`, `hot_lead`, `idle_lead`, `missed_call`, `appointment_created`, `appointment_reminder`, `stale_lead`
**Source:** REVERSE_SRS_old.md, server-audit.md, DESIGNER_UPDATE_SPEC.md ~L1080-1104

**REVIEWER claim:** 7 event types: `new_lead`, `lead_status_change`, `hot_lead`, `appointment_created`/`appointment_scheduled`, `missed_call`, `widget_interaction`, `sms_received`
**Source:** REVERSE_SRS_old.md Section 5.5, server-audit.md, ACCEPTANCE_VERIFICATION_REPORT.md line 100, Nexxus_SRS_Addendum_v3.2

**Analysis:** Both agents found 7 event types but with different names. ANALYST lists `idle_lead`, `appointment_reminder`, `stale_lead` which REVIEWER does not. REVIEWER lists `lead_status_change`, `widget_interaction`, `sms_received` which ANALYST does not. Both agree `hot_lead` has no call site in codebase.

**Recommendation:** The true event type list should be verified against the actual codebase (server-audit.md is the closest-to-code source). Multiple documents use different vocabularies. The SRS should enumerate the canonical list with a note that document inconsistency exists (see also CONFLICT C-06 in Analyst / CONFLICT 6 in Reviewer).

### DISAGREE-2: Trigger Action Type Names

**ANALYST claim:** 5 action types: `outbound_call`, `outbound_sms`, `email_notification`, `create_task`, `update_lead_status`
**Source:** REVERSE_SRS_old.md, server-audit.md, DESIGNER_UPDATE_SPEC.md

**REVIEWER claim:** 5 action types: `outbound_call`, `send_sms`, `send_notification`/`send_email`, `create_task`, `assign_lead`/`webhook`
**Source:** ACCEPTANCE_VERIFICATION_REPORT.md line 97, REVERSE_SRS_old.md

**Analysis:** Both agents found 5 action types but with different names for 3 of them. This is the same underlying inconsistency -- different documents use different action type vocabularies. Both agents flagged this as a conflict (ANALYST C-06 / REVIEWER CONFLICT 7).

**Recommendation:** Verify canonical action type names against the server codebase. Standardize in SRS.

### DISAGREE-3: VAPI Webhook Event Type Names

**ANALYST claim:** Events: `call.started`, `call.ended`, `call.failed`, `transcript.ready`
**Source:** CLAUDE.md ~L216-220, ARCHITECTURE_VISUAL_MAP.md, SRS v3.0 ~L975-1050

**REVIEWER claim:** Events: `call.started`, `call.ended`, `end-of-call-report`, `transcript`, `status-update`
**Source:** REVERSE_SRS_old.md Section 5.2, server-audit.md, DATA_ACCURACY_REPORT.md

**Analysis:** REVIEWER's list appears closer to the actual webhook handler implementation (citing server-audit.md and the DATA_ACCURACY_REPORT which analyzed real data). ANALYST's `call.failed` and `transcript.ready` may be from the SRS specification rather than the implemented handler. REVIEWER's `end-of-call-report` is the critical event that the production bug revolves around (UPDATE with no matching INSERT from `call.started`).

**Recommendation:** Use REVIEWER's event list as canonical (closer to implementation). Note that `call.failed` may be specified but unimplemented. The `end-of-call-report` event name is critical to document accurately because the production ingestion bug depends on understanding this event.

### DISAGREE-4: VAPI Cost Per Minute

**ANALYST claim:** VAPI cost: $0.15/min, customer charge: $0.25/min, margin: 40%
**Source:** CLAUDE.md ~L317-319, ARCHITECTURE_VISUAL_MAP.md ~L1050-1057

**REVIEWER claim:** Same values: $0.15/min cost, $0.25/min customer charge, 40% margin
**Source:** REVERSE_SRS_old.md, CARRY_FORWARD_MANIFEST.md line 74, CLAUDE.md

**Analysis:** BOTH AGREE on $0.15/$0.25 economics. However, ANALYST also mentions in Category 3 (Webhook Processing, line 253) "$0.15/min (VAPI cost), customer charged $0.25/min" -- consistent. No actual disagreement on this point.

**Status:** RESOLVED -- no disagreement. Both agents agree.

### DISAGREE-5: Tavus Webhook Event Names

**ANALYST claim:** Events: `session.started`, `session.ended`, `recording.ready`
**Source:** ARCHITECTURE_VISUAL_MAP.md ~L1059-1156

**REVIEWER claim:** Events: `conversation.started`, `conversation.ended`, `replica.ready`, `video.ready`
**Source:** REVERSE_SRS_old.md, DATA_ACCURACY_REPORT.md

**Analysis:** Different event naming. REVIEWER's names (`conversation.started/ended`) may reflect the actual Tavus API terminology, while ANALYST's (`session.started/ended`) may be from the architecture map's abstracted description. REVIEWER also found additional events (`replica.ready`, `video.ready`).

**Recommendation:** Verify against actual Tavus API documentation. REVIEWER's list is likely more complete. Use REVIEWER's list with note that ANALYST's architecture map uses "session" terminology.

### DISAGREE-6: Number of Database Tables

**ANALYST states conflict:** SRS v3.0 says 20, CLAUDE.md says 36, database-audit.md and INIT_PROJECT_ANSWERS.txt say 53
**REVIEWER states:** 53 tables with RLS, ~100 policies, 33 migration files

**Analysis:** Both agents agree 53 is the actual count. ANALYST explicitly flagged the discrepancy as CONFLICT C-01.

**Status:** RESOLVED -- no disagreement. Both agree 53 is ground truth.

---

## RECONCILED CATEGORIES

### 1. Data Flow Narratives

#### 1.1 Voice Call (VAPI) to Lead Creation

**Sources:** REVERSE_SRS_old.md Section 5.2, DATA_ACCURACY_REPORT.md lines 30-100, CUSTOMER_ONBOARDING_KICKOFF.md lines 88-137, CLAUDE.md ~L216-220, ARCHITECTURE_VISUAL_MAP.md ~L1033-1057

Flow:
1. VAPI call ends -> webhook fires to `POST /api/webhooks/vapi`
2. `resolveOrganizationId()` checks `metadata.organizationId`, then `assistantId` lookup in `voice_agents` table
3. If `end-of-call-report` event: `handleEndOfCallReport()` attempts UPDATE on existing call record; if no row found, skips (designed to UPDATE, not INSERT) [REVIEWER addition: specific handler name and UPDATE-not-INSERT behavior]
4. If `call.started` event: should INSERT initial row -- but this event is never received for production calls [REVIEWER addition: specific production failure detail]
5. Call data stored in `vapi_call_logs` table with org isolation
6. Lead extraction: customer info parsed from call transcript/metadata
7. Lead inserted into `sync_queue` table with `action: 'create_lead'` [REVIEWER addition: specific action value]
8. SyncCoordinator picks from `sync_queue` (1-min interval outbound) -> 2-step VIN API process:
   a. Create contact via gateway POST -> returns ContactId
   b. Create lead with href references (contactUrl, leadSourceUrl, leadTypeUrl)
9. VIN API requires lowercase `v3` media type header and href-format references, not string names
10. Credit usage tracked: duration * cost_per_minute -> `credit_usage` table

**CRITICAL PRODUCTION ISSUE (both agents agree):** Real-time ingestion is broken. `call.started` never arrives for production calls, so `handleEndOfCallReport` UPDATE finds no row to update. Result: 832 VAPI API calls vs 159 local DB records; all 137 post-V2-deploy records were from manual bulk import, not live webhooks. (DATA_ACCURACY_REPORT.md lines 58-82) [REVIEWER provided the specific numbers]

**VIN Sync Bug (both agents agree):** 12/12 sync jobs failed in production. Root cause: `leadSource` field sent as string ("Phone") but VIN API expects href URL reference (`/leadSources/id/36`). Must query `/leadSources?dealerId=X` first to get valid hrefs. (CUSTOMER_ONBOARDING_KICKOFF.md lines 128-137, CLAUDE.md ~L72-84)

#### 1.2 DealerBrain Query Flow

**Sources:** REVERSE_SRS_old.md Section 5.3, CARRY_FORWARD_MANIFEST.md Section 4 lines 99-118, client-audit.md ~L587-618, UI_DEVELOPER_HANDOFF.md ~L859-879

Flow:
1. User sends message via chat UI -> `POST /api/conversations/{id}/stream`
2. Server opens SSE stream with 6 event types: `thinking`, `tool_start`, `tool_end`, `token`, `done`, `error`
3. DealerBrainService sends to Claude API with 24 tools available [REVIEWER addition: tool count]
4. If tool call involves VIN data: Context Router SourceSelector checks VIN API first (primary), falls back to local DB
5. CacheManager: 5-min VIN cache, 1-hr VAPI/Tavus cache
6. Response streamed token-by-token to client
7. Goal awareness injected into Claude context (if goals configured for org) [REVIEWER addition]

**SSE Protocol Details (CARRY_FORWARD_MANIFEST.md lines 106-118):** [REVIEWER addition: full payload schema]
- Auth: Bearer token header
- Body: `{ content: string }`
- Event types with payloads:
  - `thinking`: `{ type, message }`
  - `tool_start`: `{ type, toolName, toolDescription }`
  - `tool_end`: `{ type, toolName, success, summary, chartData? }`
  - `token`: `{ type, content }`
  - `done`: `{ type, tokensUsed: { input, output }, toolCalls? }`
  - `error`: `{ type, message }`

#### 1.3 Widget Chat to Staff Inbox

**Sources:** REVERSE_SRS_old.md Section 5.4, Nexxus_SRS_Addendum_v3.2 lines ~200-350, session-knowledge.md lines 17-21

Flow:
1. Customer opens widget on external website -> widget loads from `nexxusv2.huminicdev.com/widget/nexxus-widget.js?code=WIDGET_CODE`
2. Widget presents channel options: text chat, voice inbound, voice outbound, video agent, web audio, send a text [REVIEWER addition: specific channel list]
3. For text chat: conversation created in `inbox_conversations` table -> assigned to AI
4. AI handles conversation (Claude Haiku) [REVIEWER addition: specific model]
5. If AI cannot resolve OR human takes over: conversation status changes, appears in staff Unified Inbox
6. Staff continues from where agent left off -- continuity between external and internal surfaces

**Widget = Portal to Agent:** session-knowledge.md lines 17-21 -- widgets are not standalone features, they are portals to VAPI/Tavus/internal agents. External conversations can be continued internally in Unified Inbox. (Both agents agree)

#### 1.4 Metrics Data Flow

**Sources:** app_identity.md Section G lines 258-296, DATA_ACCURACY_REPORT.md, session-knowledge.md ~L24-31, CONSTITUTION.md lines ~80-100

Data enters metrics from 4 sources (both agents agree):
1. **VIN Solutions** -- query-only Lead Management API, polled every 60 min with 48-hr window
2. **Internal DB** -- lead records, call logs, video sessions, task completions, credit usage, agent activity
3. **External Services** -- VAPI call data, Tavus session data (via webhooks)
4. **User Uploads** -- Excel/CSV backfill for data VIN API cannot provide

**Truth Hierarchy (CONSTITUTION.md):** [REVIEWER addition]
1. VIN Solutions API (highest)
2. VAPI/Tavus APIs
3. Local Database
4. Derived Metrics (lowest)

**Excel Upload Exclusion:** All 32+ lead-related queries exclude `source = 'excel_upload'` records. 691 records filtered out. (DATA_ACCURACY_REPORT.md) (Both agents agree)

#### 1.5 Appointment Flow

**Sources:** CUSTOMER_ONBOARDING_KICKOFF.md Section 3, CLARIFICATION_ANSWERS.md, UI_INTERACTIVE_ELEMENTS_MAP.md lines 75-88, session-knowledge.md ~L69, known_issues.md.md

Flow (both agents agree):
1. Appointment created (by user via calendar, or by voice agent)
2. Stored in `appointments` table
3. Appears in Work Center Calendar
4. Lead should be inserted into VIN Solutions with appointment note
5. Appointment reminder job runs every 5 minutes
6. Google Calendar sync available via OAuth (useGoogleCalendar hook) [REVIEWER addition]
7. **CRITICAL GAP (both agents agree):** `updateAppointment()` fires zero status change events -- no SMS or notification sent when appointment status changes

#### 1.6 VIN Solutions Inbound Polling [ANALYST addition]

**Sources:** VIN_SOLUTIONS_INTEGRATION.md, MASTER_SRS.md, server-audit.md

Flow:
1. Scheduled job polls VIN Solutions every 60 minutes for new leads
2. OAuth 2.0 Client Credentials token obtained (cached, 60-min expiry)
3. GET leads with `lastModified` filter (48-hour window)
4. New leads stored in internal database with VIN external IDs
5. Context Router `SourceSelector` tags data source as "VIN"
6. Deduplication via `vin_customer_id` (0 duplicates detected)
7. 293,859 total API leads vs 775 local (0.26% coverage -- by design) [REVIEWER addition: specific numbers]

#### 1.7 Lead Insertion to VIN Solutions (Outbound) [ANALYST addition]

**Sources:** CLAUDE.md ~L72-84, VIN_SOLUTIONS_INTEGRATION.md, CUSTOMER_ONBOARDING_KICKOFF.md ~L170-200

Flow:
1. Lead captured by VAPI/Tavus/Widget
2. Contact created: `POST /contacts` -> returns `ContactId`
3. Contact href constructed: `/contacts/id/{ContactId}?dealerid={dealerId}` -- must include `dealerid` query param [REVIEWER addition: query param detail]
4. Lead sources queried: `GET /leadSources?dealerId=X` -> returns valid source hrefs
5. Lead created: `POST /leads` with `leadSource` (href), `leadType` (href), `contact` (href)
6. **KNOWN BUG (both agents agree):** Code sends string "Phone" for leadSource instead of URL reference format like `/leadSources/id/36`. 12/12 sync job failures.

---

### 2. Trigger & Event Mechanics

#### 2.1 Trigger Architecture

**7 Event Types:** (See DISAGREE-1 above -- names differ between documents)

Combined list from both agents (all mentioned names):
- `new_lead` -- new lead arrives (both agree)
- `hot_lead` -- lead score exceeds threshold; **no call site exists in codebase** (both agree)
- `idle_lead` [ANALYST] / not mentioned [REVIEWER]
- `missed_call` -- inbound call not answered (both agree)
- `appointment_created` / `appointment_scheduled` (both agree)
- `appointment_reminder` [ANALYST] / not mentioned [REVIEWER]
- `stale_lead` [ANALYST] / not mentioned [REVIEWER]
- `lead_status_change` [REVIEWER] / not mentioned [ANALYST]
- `widget_interaction` [REVIEWER] / not mentioned [ANALYST]
- `sms_received` [REVIEWER] / `inbound_message` [REVIEWER from ACCEPTANCE_VERIFICATION_REPORT]

**Owner resolution needed:** Canonical event type list.

**5 Action Types:** (See DISAGREE-2 above -- names differ between documents)

Combined list:
- `outbound_call` (both agree)
- `outbound_sms` [ANALYST] / `send_sms` [REVIEWER]
- `email_notification` [ANALYST] / `send_notification`/`send_email` [REVIEWER]
- `create_task` (both agree)
- `update_lead_status` [ANALYST] / `assign_lead`/`webhook` [REVIEWER]

**Owner resolution needed:** Canonical action type list.

#### 2.2 Trigger Execution Pipeline (both agents agree)

1. Trigger configured per-agent (confirmed by owner in DESIGNER_UPDATE_SPEC.md ~L1082)
2. Event fires -> TriggerService evaluates active rules for org
3. Checks: business hours (per org timezone), rate limiting (per trigger rule), criteria match
4. Prior-contact detection [REVIEWER addition]
5. If conditions met -> executes action
6. Re-evaluation job runs every 5 minutes for age-based conditions [REVIEWER addition: specific interval]
7. Execution logged with trigger_id, action taken, result

#### 2.3 Trigger Deduplication (both agents agree)

Two mechanisms exist in code (contrary to prior finding that claimed "no dedup"):
1. `notification_sent` column with atomic `UPDATE...WHERE notification_sent = false RETURNING *` pattern
2. `credit_recorded` column with same atomic pattern

**Sources:** session-knowledge.md lines 209-210, verified-findings.md

#### 2.4 Production Status (both agents agree)

- 8 active trigger rules in production DB [REVIEWER addition: rule count]
- 0/84 trigger executions completed in production
- 45 failed, 39 skipped (all from E2E tests, not production) [REVIEWER addition: failure breakdown]
- Likely causes: missing VAPI phoneNumberId per org, business hours restrictions, or rate limits [REVIEWER addition]

#### 2.5 Scheduled Events (8 Jobs) (both agents agree)

All jobs use `setInterval` (not cron). Run continuously while server is alive. Singleton guards (boolean flag prevents overlapping runs) and staggered startup delays [REVIEWER addition: guard mechanism].

| Job | Interval | Purpose |
|-----|----------|---------|
| VIN Token Refresh | 30 min | Refresh OAuth 2.0 access token (10-min threshold) |
| Sync Queue Worker (outbound) | 1 min | Process pending lead sync items |
| Sync Queue Worker (inbound) | 4 hr | Pull VIN leads from last 48 hours |
| Appointment Reminder | 5 min | Check for upcoming appointments, send notifications |
| Email Sync (IMAP) | 5 min | Pull new emails via IMAP |
| Trigger Re-evaluation | 5 min | Re-check trigger conditions against current state |
| Dealer Pulse | 4 hr | Compute dealership health metrics |
| Hunch Generation | 6 hr | Run Claude "Detective" agent to generate AI hunches |

**Sources:** server-audit.md, REVERSE_SRS_old.md

#### 2.6 Trigger Configuration UI [ANALYST addition]

Per DESIGNER_UPDATE_SPEC.md ~L1080-1104:
- Triggers section appears in Agent Config Pane (per-agent, not global)
- Trigger editor supports Event type or Schedule type
- Schedule supports cron expression or simple interval
- Each trigger has an on/off toggle

---

### 3. Webhook Processing

#### 3.1 VAPI Webhook Pipeline (both agents agree on core facts)

**Endpoint:** `POST /api/webhooks/vapi`

**Organization Resolution (both agree):**
1. Check `metadata.organizationId` in webhook payload
2. If not present, lookup `assistantId` in database (`voice_agents` table) to find registered org
3. Webhooks only process events for assistants registered to specific organizations
4. Reject events with no org match

**Events Processed:** (See DISAGREE-3 -- using REVIEWER's implementation-closer list)
- `call.started` -- should INSERT initial call record (**BROKEN: never received in production**)
- `call.ended` -- UPDATE call record with duration, end status
- `end-of-call-report` -- UPDATE with transcript, summary, recording URL; extract lead data; queue VIN sync
- `transcript` -- append to call transcript
- `status-update` -- update call status

**Idempotency (both agree):** `notification_sent` and `credit_recorded` boolean columns with atomic `UPDATE...WHERE...RETURNING` pattern

**Post-Processing (both agree):**
- Credit deduction: duration * $0.15/min (VAPI cost), customer charged $0.25/min
- Lead extraction from call data
- Sync queue entry for VIN Solutions insertion
- Activity event logged

**PM2 Restart Impact (both agree):** PM2 restarted 3,247 times. Each restart could lose in-flight webhook processing. Singleton job guards reset on restart, but any in-progress work is lost.

**Sources:** CLAUDE.md ~L216-220, ARCHITECTURE_VISUAL_MAP.md ~L1033-1057, SRS v3.0 ~L975-1050, REVERSE_SRS_old.md, DATA_ACCURACY_REPORT.md

#### 3.2 Tavus Webhook Pipeline

**Endpoint:** `POST /api/webhooks/tavus`
**Security:** HMAC-SHA256 with 5-minute timestamp tolerance (both agree)

**Events Processed:** (See DISAGREE-5 -- using REVIEWER's list as likely closer to Tavus API)
- `conversation.started` -- create session record
- `conversation.ended` -- update with duration, end status
- `replica.ready` -- update persona status
- `video.ready` -- update with video URL

**Cost Tracking (both agree):**
- Tavus cost: $0.20/min
- Customer charge: $0.32/min
- Nexxus margin: 37.5%

**Production Status (both agree):** Zero real sessions captured. 136 Tavus API conversations vs 1 seed record in local DB. Root causes:
- No V2 callback URLs configured in Tavus
- No video agents registered in DB (0 of type 'video')
- 47 conversations had undefined callback URL [REVIEWER addition: specific details]

**Sources:** CLAUDE.md ~L218, ARCHITECTURE_VISUAL_MAP.md ~L1059-1156, REVERSE_SRS_old.md, DATA_ACCURACY_REPORT.md

#### 3.3 TextMagic SMS Pipeline (both agents agree)

**Inbound SMS Flow:**
1. TextMagic webhook receives incoming SMS at `POST /api/webhooks/textmagic`
2. Phone number matched to organization via per-org DB credentials (NOT .env credentials)
3. Conversation state machine checked: AI_ACTIVE / HUMAN_ACTIVE / DORMANT
4. If AI_ACTIVE: auto-response generated by communications agent (Claude Haiku)
5. If HUMAN_ACTIVE: message routed to Unified Inbox for staff
6. SMS stored in conversation thread

**Outbound SMS Flow:**
1. Trigger or manual action initiates SMS
2. Per-org TextMagic credentials retrieved from database
3. SMS sent via TextMagic API
4. Credit usage tracked: $0.02/msg (cost), $0.05/msg (customer charge), 60% margin

**CRITICAL (both agree):** TextMagic uses per-org database credentials, NOT the .env TEXTMAGIC_API_KEY. Prior testing that used .env credentials was testing against the wrong account.

**Additional Detail [REVIEWER addition]:** Phone `18338096836` shared across 3 orgs -- first DB match wins routing. STOP keyword handling for compliance.

**Sources:** session-knowledge.md ~L209, SRS Addendum v3.2, REVERSE_SRS_old.md, ACCEPTANCE_VERIFICATION_REPORT.md

#### 3.4 VIN Solutions Webhook (Aspirational) (both agents agree)

ARCHITECTURE_VISUAL_MAP.md ~L941-958 describes a VIN Solutions webhook handler at `POST /api/webhooks/vin` with events and HMAC + IP whitelist security.

**IMPORTANT (both agree):** This is aspirational architecture. The actual VIN Solutions integration is QUERY-ONLY (polling-based), NOT webhook-based. SRS Addendum v3.1 explicitly clarifies: "VIN Solutions integration is QUERY-ONLY (not bidirectional sync)."

---

### 4. Authentication & Authorization

#### 4.1 JWT Architecture (both agents agree)

**Token Types:**
| Token | Duration | Storage | Purpose |
|-------|----------|---------|---------|
| Access Token | 24 hours | localStorage (`nexxus_access_token`) | API authentication |
| Refresh Token | 7 days | localStorage (`nexxus_refresh_token`) | Access token renewal |
| Appointment Confirmation | 48 hours | URL parameter | Appointment email links (`nexxus-appointment` audience) |

**Additional localStorage keys [REVIEWER addition]:** `nexxus_token_expiry`, `nexxus_accessible_orgs`

**Token Refresh Flow (both agree):**
1. Client-side interval checks every 60 seconds
2. If token expiry < 5 minutes away, calls `POST /api/auth/refresh`
3. Server validates refresh token, issues new access + refresh tokens
4. On failure: automatic logout, redirect to `/login`

**Auth Endpoints [REVIEWER addition]:**
- `POST /api/auth/login` -- returns access + refresh tokens
- `POST /api/auth/refresh` -- exchange refresh for new access token
- `GET /api/auth/me` -- get current user
- `POST /api/auth/switch-org` -- returns new tokens scoped to target org
- `POST /api/auth/logout` -- invalidate session

**JWT Payload [ANALYST addition]:**
```
{
  user_id: UUID,
  organization_id: UUID,  // CRITICAL for data isolation
  role_id: UUID,
  permissions: string[],
  exp: number,
  iat: number
}
```

**CRITICAL NOTE (both agree):** Backend uses JWT auth (access/refresh tokens), NOT express-session. No separate token service file exists -- all token management embedded in AuthContext.tsx [REVIEWER addition].

**Sources:** SRS v3.0 ~L1174-1185, client-audit.md ~L405-430, ~L745-820, INIT_PROJECT_ANSWERS.txt ~L61, CARRY_FORWARD_MANIFEST.md Section 5

#### 4.2 RBAC -- 4-Tier Role Hierarchy (both agents agree)

| Level | Role | Access Scope |
|-------|------|--------------|
| 1 | Super Admin | System-wide. All settings. All orgs. User/org management. Billing. |
| 2 | Partner Admin | Multi-org access. Org switching. Resource utilization. Creates orgs within partnership. |
| 3 | Org Admin | Single org. Knowledge, Email, Widget, Pages, Triggers settings. User management within org. |
| 4 | Org Staff | Basic access. Dashboard, Agents, Drive, Insights, Work Center. Uses agents, views insights. |

**Role-Level Mapping [REVIEWER addition]:** `1=super_admin, 2=partner_admin, 3=org_admin, 4+=org_staff` (CARRY_FORWARD_MANIFEST.md line 51)

**User Creation Matrix [ANALYST addition]:**
| Creator Role | Can Create | Scope |
|-------------|-----------|-------|
| Super Admin | All roles | All organizations |
| Partner Admin | Org Admin, Staff | Partner's organizations |
| Org Admin | Staff | Own organization only |
| Staff | None | N/A |

**Partner Admin Model (both agree):**
- `partners` table with company info and `credit_pool` [REVIEWER addition]
- `partner_org_assignments` table: many-to-many between partners and organizations
- `user_org_assignments` table: user access to organizations with per-org role [REVIEWER addition]
- RLS policy: partner admin can access only assigned organizations
- Tool provisioning: top-down (Super Admin -> Partner Admin -> Org Admin)

**Server Enforcement [REVIEWER addition]:** `requireRole()` middleware enforces role hierarchy on API endpoints

**Client-Side Role Enforcement (both agree):**
- `ROLE_VISIBILITY` maps in dashboard components
- Tab-level RBAC within settings page
- Sidebar items role-gated
- No route-level RBAC guard -- restrictions applied at component/tab level

**Multi-Org Design Question [REVIEWER addition]:** Org Admin can belong to multiple orgs. Unresolved design question: multi-org data queries behavior (app_identity.md line 177).

**CONFLICT (both agree):** RLS variable name mismatch: `app.current_organization_id` vs `app.current_org_id` -- confirmed security-relevant inconsistency.

**Sources:** SRS v3.0 ~L920-945, ARCHITECTURE_GUIDE_RBAC_ADDITION.md, client-audit.md, DESIGNER_UPDATE_SPEC.md ~L80-98, MASTER_SRS.md

#### 4.3 Organization Switching -- Partner Admin (both agents agree)

1. `accessibleOrganizations` populated from auth response
2. Org switcher in TopBar and profile dropdown
3. `switchOrganization(orgId)` calls `POST /api/auth/switch-org`
4. Server returns new tokens scoped to selected org
5. `queryClient.invalidateQueries()` clears ALL cached data
6. Navigation to `/` to reset page state
7. 3-second confirmation overlay displayed [ANALYST addition]

#### 4.4 Route Protection [REVIEWER addition]

- Public routes (no auth): `/login`, `/forgot-password`, `/reset-password`, `/w/:slug`
- Protected routes (13 active): all wrap in `<ProtectedRoute><AppLayout>...</AppLayout></ProtectedRoute>`
- ProtectedRoute shows spinner while loading, redirects to `/login` if not authenticated
- No route-level RBAC -- role restrictions applied at component/tab level within pages

**Sources:** client-audit.md Section 3 (lines 109-179)

#### 4.5 OAuth 2.0 -- VIN Solutions (both agents agree)

**Grant Type:** Client Credentials
**Token Expiry:** 60 minutes (3922s+ observed empirically) [REVIEWER addition]
**Refresh:** Scheduled job every 30 minutes (proactive, refreshes if within 10 minutes of expiry)
**Storage:** AES-256-GCM encrypted in database
- PBKDF2 key derivation: 100,000 iterations, SHA-256
- Per-credential random salt and IV

**Headers (both agree):**
- Gateway endpoints (`/gateway/v1/`): `Content-Type: application/json`
- Newer endpoints: `Content-Type: application/vnd.coxauto.v3+json` (lowercase "v3", not uppercase "V3")

---

### 5. State Machines & Transitions

#### 5.1 SMS Conversation State Machine (both agents agree)

**States:**
- `AI_ACTIVE` -- AI agent is responding to SMS messages
- `HUMAN_ACTIVE` -- Human staff has taken over the conversation
- `DORMANT` -- Conversation inactive for configured duration

**Transitions (both agree):**
- Inbound SMS on dormant conversation -> `AI_ACTIVE`
- AI response loop continues in `AI_ACTIVE`
- Staff claims conversation in Unified Inbox -> `HUMAN_ACTIVE`
- Staff releases or timeout -> `AI_ACTIVE` [ANALYST addition]
- No activity for configured timeout -> `DORMANT`
- New inbound message from customer on dormant -> `AI_ACTIVE`

**Implementation Status (both agree):** Schema defined in migration 032 (`sms_conversation_state` table). State constants referenced. **State machine transition logic is NOT fully implemented in code** -- schema defines the states but the runtime enforcement of transitions is incomplete.

**Sources:** SRS Addendum v3.2, REVERSE_SRS_old.md, database-audit.md, ACCEPTANCE_VERIFICATION_REPORT.md line 44

#### 5.2 Lead Status State Machine

**ANALYST version:** `new` -> `contacted` -> `qualified` -> `appointment_set` -> `closed`
**Sources:** UI_DEVELOPER_HANDOFF.md ~L489-510, client-audit.md ~L918

**REVIEWER version:** VIN Solutions Status Types (5): ACTIVE, SOLD, LOST (38 sub-statuses), BAD (with sub-statuses), Unknown/Other. Plus Lead Group Categories (3): NEW, WAITING, CONTACTED.
**Sources:** ---Tiles - Available data..md lines 68-78, DATA_SOURCE_INVENTORY.md

**Analysis:** These are complementary, not conflicting. ANALYST describes the internal lead lifecycle. REVIEWER describes VIN Solutions' lead status taxonomy. Both are needed in the SRS -- the internal status tracks Nexxus pipeline stage, the VIN status reflects the CRM classification.

**Merged:**
- **Internal Lead Lifecycle:** `new` -> `contacted` -> `qualified` -> `appointment_set` -> `closed`
- **VIN Solutions Status Types (5):** ACTIVE, SOLD, LOST (38 sub-statuses), BAD (sub-statuses), Unknown/Other
- **VIN Lead Group Categories (3):** NEW, WAITING, CONTACTED

#### 5.3 Agent Status (both agents agree)

**States:** `active`, `inactive`, `draft`
**Sources:** SRS v3.0 ~L1529-1547, client-audit.md ~L888

#### 5.4 Approval Workflow State Machine [ANALYST addition]

**States:** `pending` -> `approved` | `rejected` | `timeout`

**Transitions:**
- Created: hunch or external communication generates approval request -> `pending`
- Approved: authorized user approves -> `approved`, target entity updated
- Rejected: authorized user rejects -> `rejected`
- Timeout: `timeout_hours` exceeded without action -> `timeout`

**Schema:** `approval_workflows` (config), `approval_requests` (instances), `approval_actions` (decisions)
**Sources:** SRS v3.0 ~L800-850

#### 5.5 Hunch Lifecycle [ANALYST addition]

**States:** Generated -> Pending Review -> Accepted | Dismissed

**Flow:**
1. Hunch Generation job (6hr interval) runs Claude "Detective" agent
2. 7 hunch categories: opportunity, risk, trend, anomaly, recommendation, prediction, insight
3. Hunch stored with confidence score, category, supporting evidence
4. User reviews in Hunches tab (Insights page)
5. Accept -> hunch creates action item (task, follow-up, etc.)
6. Dismiss -> hunch archived with feedback (RLHF loop)

**Sources:** SRS v3.0 ~L700-780, Hunch Instructions.md, ---Hunches.md

#### 5.6 Trigger Execution States [REVIEWER addition]

**Source:** Agent Instructions.md lines 276-290

- CREATED -> ASSIGNED -> IN_PROGRESS -> REVIEW -> VALIDATED -> DONE
- Alternate path: IN_PROGRESS -> BLOCKED -> (resolved) -> REVIEW

#### 5.7 Inbox Conversation States [REVIEWER addition]

**Source:** Nexxus_SRS_Addendum_v3.2, CARRY_FORWARD_MANIFEST.md line 75

States managed via `useInboxConversations` hook: open, assigned, resolved, archived. Status transitions via `useUpdateConversationStatus`.

---

### 6. Integration Protocols

#### 6.1 VIN Solutions (both agents agree on all core facts)

**Protocol:** REST API over HTTPS
**Auth:** OAuth 2.0 Client Credentials
**Token Endpoint:** `https://api.vinsolutions.com/oauth2/token` [REVIEWER addition]
**Token Expiry:** 60 minutes documented, 3922s+ observed [REVIEWER addition]
**Refresh:** Every 30 minutes, proactive

**Credential Storage (both agree):** AES-256-GCM encrypted in `vin_credentials` table, PBKDF2 with 100K iterations, SHA-256
**Audit Trail [REVIEWER addition]:** `vin_audit_log` table with 5 action types: token_refresh, api_call, sync_started, sync_completed, error

**API Access (both agree):**
- 13 endpoints accessible (leads, contacts, lead sources, lead types, lead groups, dealers, users, inventory partial)
- 17 endpoints blocked (activities, deals, tasks, RO, notes -- most return 403)
- Gateway endpoints use `application/json`; newer endpoints use `application/vnd.coxauto.v3+json` (LOWERCASE v3)

**2-Step Lead Creation (both agree):**
1. `POST /contacts` with customer data -> returns `ContactId`
2. Contact href: `/contacts/id/{ContactId}?dealerid={dealerId}` -- must include `dealerid` query param
3. Query `GET /leadSources?dealerId=X` for valid source hrefs
4. `POST /leads` with `leadSource` (href), `leadType` (href), `contact` (href)

**KNOWN BUG (both agree):** `leadSource` field format mismatch. Code sends string name ("Phone"), API requires URL reference (`/leadSources/id/36`). 12/12 sync job failures.

**VIN Lead Polling [REVIEWER addition]:** Every 60 minutes, queries leads from last 48 hours by `modifiedUtc`. 293,859 total API leads vs 775 local (0.26% coverage -- by design). Deduplication via `vin_customer_id`.

**Rate Limits [ANALYST addition]:** Not explicitly documented but 200 req/hour mentioned in ARCHITECTURE_VISUAL_MAP.md for MCP proxy.

**Sources:** VIN_SOLUTIONS_INTEGRATION.md, CLAUDE.md ~L72-84, CUSTOMER_ONBOARDING_KICKOFF.md, DEVELOPMENT_TEAM_BRIEFING.md, DATA_SOURCE_INVENTORY.md, DATA_ACCURACY_REPORT.md

#### 6.2 VAPI -- Voice AI (both agents agree)

- Master API key, assistants tagged with org metadata
- Each org has a voice assistant with ID, phone number, and name in DB
- Webhooks receive call data (see Section 3.1)
- MCP connectivity from VAPI to Nexxus was in V1 but disconnected in V2 [REVIEWER addition]
- Outbound calls via `POST https://api.vapi.ai/call` with `assistantOverrides` [REVIEWER addition]
- 16 API endpoints available, 15 accessible [REVIEWER addition]
- Provisioning: Template duplication strategy (pre-defined assistants duplicated per org) [ANALYST addition]
- Retention: 30-day recording retention, auto-reaper cron at 2:00 AM daily [ANALYST addition]

**Sources:** SRS v3.0 ~L975-995, CLAUDE.md ~L223-225, app_identity.md, DATA_SOURCE_INVENTORY.md

#### 6.3 Tavus -- Video AI (both agents agree)

- Master API key, personas tagged with org metadata
- `x-api-key` header [ANALYST addition]
- 11 API endpoints available, 10 accessible [REVIEWER addition]
- Widget tech may not be finished [REVIEWER addition]
- Zero production sessions captured -- no callback URLs configured, no video agents in DB
- Template duplication for personas [ANALYST addition]
- Stock replicas reused across orgs (custom replicas quota-limited) [ANALYST addition]
- 30-day recording retention [ANALYST addition]

**Sources:** SRS v3.0 ~L997-1010, ARCHITECTURE_VISUAL_MAP.md, app_identity.md, DATA_ACCURACY_REPORT.md

#### 6.4 TextMagic -- SMS (both agents agree)

- Per-org credentials stored in database (NOT .env)
- E.164 phone format required (`+` prefix) [REVIEWER addition]
- Phone `18338096836` shared across 3 orgs -- first DB match wins routing [REVIEWER addition]
- Outbound + inbound via webhook
- AI auto-reply via Claude Haiku [REVIEWER addition]
- STOP keyword handling for compliance [REVIEWER addition]
- Cost: $0.02/msg (cost), $0.05/msg (customer charge), 60% margin

**Sources:** SRS Addendum v3.2, session-knowledge.md ~L209, DEVELOPMENT_TEAM_BRIEFING.md, ACCEPTANCE_VERIFICATION_REPORT.md

#### 6.5 Resend -- Email (both agents agree)

- Used for all outbound email notifications
- Email system accessible in Settings (IMAP/SMTP config) and Work Center (InboxPanel)
- 7 API endpoints: inbox, folders, messages, send, reply, settings, test-connection [REVIEWER addition]
- No inbound response mechanism built yet [REVIEWER addition]
- Used for: Appointment reminders, trigger notifications, system alerts, daily digest [ANALYST addition]

**Sources:** CLAUDE.md ~L226, SRS v3.0 ~L853-884, app_identity.md, ACCEPTANCE_VERIFICATION_REPORT.md

#### 6.6 Google Calendar (both agents agree)

- OAuth 2.0 Authorization Code
- Connect, disconnect, sync, toggle auto-sync
- `useGoogleCalendar` hook, CalendarConnectionStatus type [REVIEWER addition]
- Status: Implemented (Phase 17 complete per CLAUDE.md)

**Sources:** CLAUDE.md ~L194, client-audit.md, CARRY_FORWARD_MANIFEST.md line 78

#### 6.7 Claude AI -- DealerBrain (both agents agree)

- Model: claude-sonnet-4-20250514 (implementation; SRS v3.0 specifies older `claude-3-5-sonnet-20241022`)
- @anthropic-ai/sdk v0.72.1 [REVIEWER addition]
- Streaming API via SSE
- Tool calling: 24 DealerBrain tools documented [REVIEWER addition]
- System prompt configurable per-org via AI Configuration settings
- DealerBrainProcessor middleware: Stage 1 monitoring only, no enforcement [REVIEWER addition]
- Goal awareness injected into context [REVIEWER addition]

**Sources:** SRS v3.0 ~L1127, REVERSE_SRS_old.md, client-audit.md, DATA_SOURCE_INVENTORY.md

#### 6.8 MCP (Model Context Protocol) -- Aspirational [ANALYST addition]

ARCHITECTURE_VISUAL_MAP.md describes MCP Proxy on Port 3010 with VIN MCP Server (3011), VAPI MCP Server (3012), Tavus MCP Server (3013). Central-MCP exists at `../central-mcp/` (port 4002).

**Current Reality:** MCP tools tab in UI shows "No MCP tools configured" (placeholder). The central-mcp proxy pattern is ready but not all connectors are integrated.

**Sources:** ARCHITECTURE_VISUAL_MAP.md ~L860-968, DESIGNER_UPDATE_SPEC.md ~L187-215, session-knowledge.md

---

### 7. Context Router Behavior

#### 7.1 Architecture (both agents agree)

Components:
1. **SourceSelector** -- determines optimal data source. VIN Solutions primary, local database fallback.
2. **CacheManager** -- TTL-based caching. VIN data: 5-min TTL. VAPI/Tavus data: 1-hr TTL.
3. **Data Isolation Enforcement Layer** [ANALYST addition] -- organization_id validation on ALL queries, RLS, JWT scoping, audit logging
4. **Source Tagging** [REVIEWER addition] -- labels data by origin. Source labels: `vapi_voice` -> "Voice Agent", `tavus_video` -> "Video Agent", etc. Tags for internal tracking -- external surfaces show clean display names.

#### 7.2 Behavior Rules (both agents agree)

- Queries VIN API first for lead/CRM data
- Falls back to local DB if VIN unavailable
- Excludes `excel_upload` records across 32+ queries
- All data tagged with `organization_id` + source identifier
- Source badges displayed in UI: VIN, VAPI, Tavus, SMS, Email, Widget, Manual [ANALYST addition]

#### 7.3 Decision Flow -- Aspirational vs Implemented (both agents agree)

**Aspirational (ARCHITECTURE_VISUAL_MAP.md):** 6-step process with NLP parsing, domain classification, entity validation, 4-tier memory loading, agent selection, routing decision.

**Implemented (both agree):** SourceSelector + CacheManager for data source queries. The multi-agent orchestration, NLP parsing, and domain classification are NOT implemented.

#### 7.4 Coverage Gap (both agents agree)

~20% of data consumers use Context Router. The remaining 80% query data sources directly. Intelligent routing and caching benefits are only available to a fraction of the application.

#### 7.5 Known Issues (both agents agree)

- Context Router "was inverted" at some point -- VIN was fallback instead of primary. Corrected. [REVIEWER addition: specific detail]
- Excel upload pollution: 691 records polluted metrics until exclusion filters added [REVIEWER addition]
- Router needs expansion for non-lead data types

#### 7.6 Design Intent -- Owner-stated [REVIEWER addition]

From app_identity.md and ===DevDesign Notes===.md:
- Should have 3 clear sections: Memory stores, Sync Data, Upload Data Store and Web/3rd party data store
- Should be aware of information from various sources, tag data appropriately, track capabilities and weaknesses of each data source
- Owner deferred technical details to engineering team (CLARIFICATION_ANSWERS.md)

**Sources:** SRS v3.0 ~L1200-1270, ARCHITECTURE_VISUAL_MAP.md ~L1160-1293, DATA_SOURCE_INVENTORY.md, REVERSE_SRS_old.md, app_identity.md, ===DevDesign Notes===.md, DEVELOPMENT_TEAM_BRIEFING.md

---

### 8. Below-the-Line Behavior

#### 8.1 Encryption (both agents agree)

**At Rest:** AES-256-GCM encryption for sensitive credentials (OAuth tokens, API keys)
- PBKDF2 key derivation: 100,000 iterations, SHA-256
- Per-credential random salt and IV
- Stored in `vin_credentials` table [REVIEWER] / `integrations` table `credentials` JSONB field [ANALYST]

**In Transit:** TLS 1.3 for all connections (SRS v3.0 ~L1086) [ANALYST addition]

#### 8.2 Row-Level Security (both agents agree)

- 53 tables with RLS enabled
- ~100 policies across 6-7 patterns
- `SecureQueryBuilder` enforces RLS context on every query via `SET LOCAL`
- All queries parameterized (no SQL injection)

**CRITICAL BUG (both agents agree):** Two bugs:
1. **Variable name mismatch:** `SecureQueryBuilder` sets `app.current_organization_id` via `SET LOCAL`, but some RLS policies check `app.current_org_id` -- DIFFERENT VARIABLE NAMES. Data isolation may not be enforcing correctly.
2. **SET LOCAL without transaction [REVIEWER addition]:** `SET LOCAL` without an explicit transaction means the variable persists for the entire database connection lifetime, not just the current request. In a connection pool, this could leak organization context between requests.

**Sources:** database-audit.md, DEVELOPMENT_TEAM_BRIEFING.md lines 80-95, SRS v3.0 ~L1186-1197

#### 8.3 Database Layer [REVIEWER addition]

- 33 migration files (001-033, 011 missing)
- 58 JSONB columns, ~80 FK relationships
- 2 database functions, 11 triggers

**Sources:** database-audit.md

#### 8.4 Audit Logging [ANALYST addition]

- All data access and modifications logged
- Sensitive operations have dedicated audit trails
- `audit_log` table referenced in ER diagram
- Activity events stored in `activity_events` table with causal chains (aspirational)
- VIN audit trail: `vin_audit_log` table with 5 action types [REVIEWER addition]

#### 8.5 SecureQueryBuilder [ANALYST addition]

Every database query passes through `SecureQueryBuilder` which:
1. Enforces RLS context by setting `app.current_organization_id` from JWT
2. Requires organization_id -- never optional
3. Parameterizes all queries (no SQL injection)
4. Provides data access with organization isolation

**Sources:** CLAUDE.md ~L236-239

#### 8.6 Token Caching -- VIN Solutions (both agents agree)

- Access token cached server-side
- `VinOAuthService` handles token lifecycle
- 60-minute token expiry
- 30-minute proactive refresh via scheduled job
- If refresh fails, next API call will attempt fresh token acquisition

#### 8.7 Sync Queue (both agents agree)

Asynchronous queue for VIN Solutions write operations:
1. Items added to `sync_queue` table with `status: 'pending'`
2. Worker picks up items on 1-minute (outbound) or 4-hour (inbound) interval
3. Processes in order: contact creation, then lead creation
4. On failure: status updated to `failed` with error details
5. Retry logic: configurable (exact retry count not documented)

#### 8.8 Widget Bundle Serving [REVIEWER addition]

- Preact-based bundle: 50.13 KB minified
- Served at `/widget/nexxus-widget.js?code=WIDGET_CODE`
- Domain whitelist enforcement for external embedding
- Rate limited: 100 requests/hr/IP
- 19 active widget configs across orgs

**Sources:** ACCEPTANCE_VERIFICATION_REPORT.md lines 65-70

#### 8.9 Real-Time Features [REVIEWER addition]

- **SSE (Server-Sent Events)** for DealerBrain streaming
- **Polling** for: notifications (30s), inbox messages (15s), activity (60s), insights (60s)
- **No WebSocket connections in client** despite `socket.io` being in package.json (health-audit.md line 297)

**Sources:** CARRY_FORWARD_MANIFEST.md Section 10, health-audit.md

---

### 9. Error Handling & Recovery

#### 9.1 API Error Handling -- Client Side [ANALYST addition]

**`fetchApi()`:**
- Reads `nexxus_access_token` from localStorage
- Attaches `Authorization: Bearer <token>` header
- On 401: configurable behavior (return null or throw)
- Custom `getQueryFn` factory handles 401 responses

**TanStack Query defaults:**
- `staleTime: Infinity` (data never auto-stales)
- `refetchOnWindowFocus: false`
- `retry: false` (no automatic retries)

**Sources:** client-audit.md ~L487-500, ~L780-795

#### 9.2 Auth Error Recovery (both agents agree)

- Token refresh failure: automatic logout
- On 401 from any API call: configurable (null return vs throw)
- Refresh token expired: force logout, redirect to `/login`

#### 9.3 Webhook Error Handling (both agents agree)

- VAPI webhooks: try/catch with error logging, returns 200 even on internal errors to prevent VAPI retry storms
- Tavus webhooks: HMAC verification failure returns 401; processing errors caught and logged
- VIN sync: failed sync items remain in `sync_queue` with error status

#### 9.4 VIN API Error Handling [REVIEWER addition]

- Token refresh errors: logged to `vin_audit_log`, retry on next interval
- API call errors: logged with request/response details
- Sync queue: failed items remain in queue for retry; 12/12 production sync jobs currently in failed state

#### 9.5 Client-Side Error Handling [REVIEWER addition]

- All `console.error` in catch blocks (error handling, not leaked errors)
- TypeScript strict mode enforced
- **No React ErrorBoundary wrapper** -- graceful degradation not implemented
- Null-safe access patterns throughout (but 4 unsafe `.pct` accesses in insights.tsx)

#### 9.6 Known Error Conditions -- P0s (both agents agree)

1. **Hosted pages route mismatch:** Client fetches `/api/hosted-pages/public/${slug}`, server serves `/api/pages/:slug`. One-line fix needed.
2. **Insights crash risk:** 4 unsafe `.pct` accesses at lines 854, 1293, 2142, 2143 in insights.tsx. Direct `array[0]` without bounds checking. Null guards needed.
3. **Appointment status notifications:** `updateAppointment()` fires zero events. No SMS/notification sent on status change.

**Sources:** known_issues.md.md, verified-findings.md

#### 9.7 PM2 Restart Behavior (both agents agree)

- PM2 restarted 3,247 times
- Each restart can lose in-flight webhook processing
- Singleton job guards (boolean flags) reset on restart, but any in-progress work is lost

---

### 10. Security Mechanisms

#### 10.1 Defense-in-Depth Layers [ANALYST addition]

1. **Network:** CDN/DDoS protection (CloudFlare specified but may not be active)
2. **Application:** JWT authentication, API rate limiting
3. **Data:** AES-256 at rest, TLS 1.3 in transit
4. **Database:** Row-Level Security (RLS), parameterized queries
5. **Audit:** Comprehensive logging, intrusion detection (aspirational)

**Sources:** SRS v3.0 ~L1164-1173

#### 10.2 Rate Limiting (both agents agree)

- `express-rate-limit` v8.2.1 [REVIEWER addition]
- Widget endpoint: 100 req/hr/IP
- General API: rate limiting configured (specific limits not documented)
- DealerBrain: service quota with 80% alert threshold [ANALYST addition]

#### 10.3 Security Headers [REVIEWER addition]

- `helmet` v8.1.0 for security headers
- CORS configured

#### 10.4 Input Validation (both agents agree)

- Parameterized queries throughout (no SQL injection)
- Zod v3.24.2 for schema validation [REVIEWER addition]
- `SecureQueryBuilder` enforces org isolation

#### 10.5 Password Handling [REVIEWER addition]

- `bcrypt` v6.0.0 for password hashing

#### 10.6 Webhook Security (both agents agree)

- **VAPI:** Organization resolution via metadata or assistant lookup (no HMAC / no cryptographic verification)
- **Tavus:** HMAC-SHA256 signature with 5-minute timestamp tolerance
- **TextMagic:** Route-level authentication (specifics not detailed) [REVIEWER addition]
- **VIN (aspirational):** HMAC + IP whitelist (not implemented -- VIN is polling-based)

#### 10.7 Session / Token Storage (both agents agree)

- No express-session -- JWT-only
- Tokens in localStorage (not httpOnly cookies -- potential XSS vector) [ANALYST addition]
- `credentials: 'include'` on all fetch requests [ANALYST addition]

#### 10.8 Compliance -- Specified but Not Verified [ANALYST addition]

- GDPR readiness
- CCPA compliance
- HIPAA requirements
- SOC2 (grayed out in UI -- placeholder)

#### 10.9 MFA [ANALYST addition]

SRS v3.0 ~L1089: "MFA SHALL be required for administrative users." Security settings UI shows it as grayed out (ON but non-interactive). Actual MFA enforcement status unclear.

---

### 11. Notification Routing

#### 11.1 Notification System (both agents agree)

- `useNotifications` hook: list, unread count (polling at 30s), settings CRUD, event types
- Mark read, mark all read, bulk update settings
- Database hierarchy routing: notifications follow org -> user hierarchy
- Super Admin receives system-wide notifications
- Event types configurable per user

#### 11.2 Notification Channels

| Channel | Service | Status |
|---------|---------|--------|
| Email | Resend API | Implemented |
| SMS | TextMagic API | Implemented (per-org credentials) but not currently wired for notification events [REVIEWER addition] |
| In-App | Notification bell in TopBar (last 10, badge count) | Implemented |
| Push (Mobile) | Firebase/APNs | Future Phase 2 [ANALYST addition] |

**CONFLICT (both agents agree):** SRS v3.0 ~L859 specifies SSE for real-time notifications. Implementation note D-002 says WebSocket (Socket.IO) was chosen instead. BUT health-audit.md line 297 says no WebSocket connections exist in client despite socket.io being in package.json [REVIEWER addition]. DealerBrain streaming uses SSE (separate from notifications). **Current reality may be polling-based notifications, not SSE or WebSocket.**

#### 11.3 Notification Events (both agents agree)

- Call completion -> email notification (VAPI webhook handler) [REVIEWER addition]
- Low credits -> in-app notification [REVIEWER addition]
- Approval request assigned
- Task assigned or due
- Lead status change
- System alerts and errors
- Appointment reminders
- Daily digest (configurable) [ANALYST addition]
- New hunch generated [ANALYST addition]
- **GAP (both agree):** Appointment status changes fire zero notifications

#### 11.4 Notification Settings -- Two Levels [ANALYST addition]

1. **System-wide:** AI Configuration > Hunches tab (Super Admin controls)
   - Enable/disable hunches globally
   - Daily digest on/off
   - Confidence threshold defaults

2. **Per-user:** Notifications settings page
   - Global toggles: Email ON/OFF, SMS ON/OFF, Push ON/OFF
   - Quiet hours: Start/End time
   - Per-event channel preferences

#### 11.5 Database Hierarchy Routing [ANALYST addition]

- Organization-level events -> all admins of that org
- User-level events -> specific user
- System-level events -> Super Admins
- Partner-level events -> Partner Admin for assigned orgs

---

### 12. Credit & Usage Tracking

#### 12.1 Economic Model (both agents agree)

| Service | Cost/Unit | Customer Price/Unit | Margin |
|---------|-----------|-------------------|--------|
| Voice AI (VAPI) | $0.15/min | $0.25/min | 40% |
| Video AI (Tavus) | $0.20/min | $0.32/min | 37.5% |
| SMS (TextMagic) | $0.02/msg | $0.05/msg | 60% |
| AI Tokens (Claude) | Variable | Tracked | N/A | [ANALYST addition]

#### 12.2 Credit Tracking Tables (both agents agree)

- `credit_policies` -- Per-org credit rules and limits / pricing per service type per org
- `credit_allocations` -- Budget allocations per org per service per period
- `credit_usage` -- Actual usage records (timestamp, service, amount, org)
- Service quotas with 80% alert threshold

#### 12.3 Credit Recording (both agents agree)

Wired to webhooks in Phase 6:
- VAPI call ends -> credit recorded based on duration
- Tavus session ends -> credit recorded based on duration
- SMS sent -> credit recorded per message

**Idempotency (both agree):** `credit_recorded` boolean column with atomic `UPDATE...WHERE credit_recorded = false RETURNING *` prevents double-counting

#### 12.4 Client Hooks [REVIEWER addition]

`useCredits` hook provides: `useCreditBalance`, `useCreditUsage`, `useCreditPolicies`, `useRecentUsage`, `useCreditSummary`

#### 12.5 Quota-Based Provisioning [ANALYST addition]

- `service_quotas` table: max_voice_minutes, max_video_minutes, max_sms_messages per org
- `service_allocations` table: allocated resources per agent per org
- 80% usage threshold alerts
- Master API key approach: platform owns one key per service, allocates usage per org

#### 12.6 Billing System -- UI Specified, Backend Partial [ANALYST addition]

**Org-facing (View A):**
- Plan name, base monthly fee, anniversary date
- Usage progress bars (voice/video/SMS/documents) with default included amounts
- Overage calculation: `(usage - default_minutes) * markup_rate`
- Add-ons section (recurring or one-time)
- Invoice history

**Admin-facing (View C -- Super Admin):**
- Revenue dashboard: MRR, active accounts, avg rev/account, overage revenue
- Per-org billing configuration
- Invoice builder with auto-populated line items
- Rate configuration per tool via Economy settings on tool cards

**Data Flow:** Tool Card Economy Settings -> Invoice Line Items
- Super Admin sets rates on each tool card's Economy section
- System tracks usage per org per billing period
- Invoice Builder auto-populates: `(usage - default_minutes) * markup_rate`
- Rate changes take effect only in NEXT billing period

**Payment Processing:** NO payment processing in V1/V2 (no Stripe integration -- explicitly excluded in SRS v3.0 ~L893)

#### 12.7 Production Status (both agents agree)

- 0 credits recorded in production (despite 832 VAPI calls)
- 0 notifications sent in production
- Billing page commented out in routes (`/credits` and `/profile/billing` marked PHASE-FUTURE)
- No billing API endpoints documented beyond client hooks [REVIEWER addition]

**Sources:** CLAUDE.md ~L317-319, SRS v3.0, REVERSE_SRS_old.md, CARRY_FORWARD_MANIFEST.md, DESIGNER_UPDATE_SPEC.md ~L826-1006, client-audit.md, DATA_ACCURACY_REPORT.md

---

## RECONCILED WATCH AREAS

### Watch 1: Agent Functionality / Defaults (both agents agree on all findings)

1. **V1 -> V2 Transition:** V1 had 27 hardcoded agents + super chat. V2 changed to user-created agents with selectable skills from 74-skill catalog. Skills are the same concept (pre-prompting, context, instructions) but now user-selectable. This was the #1 source of testing agent confusion.

2. **Automa (master agent):** Always exists in every account. Has high-level org context awareness, knows goals, understands page context. Listed at top of agents list. Removed from agents page in V2.1 design -- right pop-out represents agent config. Also known as DealerBrain / formerly "Daria."

3. **Communications Agent:** Static, configured by Super Admin. Two default agents ship out of the box -- one voice (VAPI), one video (Tavus). Rest are user-created. Cannot be modified by user except triggers and instruction supplement. Handles proactive lead follow-up (outbound call + text) and reactive after-hours coverage (SMS and phone).

4. **Production Agent Inventory:** 12 active -- 5 voice (VAPI assistant IDs linked), 2 chat, 4 task, 0 video.

5. **Agent Types:** Voice (VAPI), Video (Tavus), Chat (DealerBrain), Email (Resend), Task (internal)

6. **Skills Catalog [ANALYST addition]:** 74 pre-built skills in 4 categories: Sales (20), Finance (20), Operations (20), General (14). Managed in AI Configuration > Skills tab (Super Admin only).

7. **Emergency Kill Switch [ANALYST addition]:** Super Admin only. Turns off ALL agent activity for ALL users in ALL organizations. Requires confirmation dialog.

8. **Agent Capabilities from Inside Nexxus [REVIEWER addition]:** Send SMS, send email, attach artifacts from Drive or upload from chat. Right pane shows: link to customer-facing page, phone number, text chat link, contextual instructions/prompt.

### Watch 2: Billing (both agents agree)

1. Credit tables exist and are wired (Phase 6 complete)
2. Billing page commented out in routes -- PHASE-FUTURE
3. Partner-level credit pool exists (`credit_pool DECIMAL`)
4. 0 credits recorded in production despite 832 VAPI calls
5. No Stripe or payment processor integration
6. All billing is manual Super Admin actions
7. DESIGNER_UPDATE_SPEC.md specifies comprehensive billing UI (org-facing + admin-facing) -- implementation status unclear
8. NEW Billing Page referenced in DESIGNER_UPDATE_SPEC Section 11 -- future work [REVIEWER addition]

### Watch 3: Unified Inbox Handoff (both agents agree)

1. Widgets are portals to agents. Externally-initiated conversations can be continued internally in Unified Inbox.
2. InboxPanel merges SMS + widget chat + email into unified view
3. Hub -> Inbox shows ALL communication with a prospect [REVIEWER addition: from ===DevDesign Notes===]
4. SMS state machine defines handoff states (AI_ACTIVE -> HUMAN_ACTIVE) but transition logic not fully implemented
5. Voice call handoff (VAPI to human) -- mechanism unclear
6. Video session (Tavus) -- no documented handoff mechanism (sessions are standalone) [ANALYST addition]
7. **NOT FOUND (both agree):** Detailed flow documentation for how an external widget conversation surfaces to staff in the internal inbox

### Watch 4: Super Admin Functionality (both agents agree)

1. **Organization Management:** Create orgs via 7-step wizard, view/edit all orgs, enable/disable billing, create users in any org
2. **System Configuration:** AI Configuration (system prompt, agent behavior, skills, hunches), Emergency Kill Switch, Data Management, Security & Privacy
3. **Tools & Integrations:** See technical names on tool cards, access API Keys tab, Webhooks tab, Economy settings, enable/disable tools
4. **Billing Management:** Revenue dashboard (MRR, active accounts, avg revenue, overage), per-org billing config, Invoice Builder, send invoices
5. **Org Switching [REVIEWER addition]:** Should be able to switch orgs like Partner Admin, with additional option to switch to "Nexxus System" view
6. **Tool Provisioning Flow:** Super Admin -> provisions tools -> Partner Admin -> manages orgs -> Org Admin -> uses
7. **Activity Page [REVIEWER addition]:** CSV export visible only to admins
8. **CONCERN (both agree):** Owner states "Super Admin functionality undertested, owner has focused on customer-facing features."

### Watch 5: Context Router (both agents agree -- see Section 7 above)

Key additions from watch area analysis:
1. Owner design intent: 3 clear sections (Memory stores, Sync Data, Upload Data Store + Web/3rd party)
2. Owner deferred technical details to engineering
3. Was inverted (VIN was fallback instead of primary) -- corrected but shows fragility
4. Needs expansion for non-lead data types

---

## RECONCILED CONFLICTS

All unique conflicts from both agents, merged and deduplicated:

### C-01: Table Count Discrepancy [ANALYST]
- SRS v3.0: 20 tables. CLAUDE.md: 36. database-audit.md / INIT_PROJECT_ANSWERS.txt: 53.
- **Resolution:** 53 is actual count. SRS and CLAUDE.md are stale.

### C-02: Tech Stack Mismatch [ANALYST]
- SRS v3.0: Next.js 14, Zustand, Tremor, Vercel
- Implementation: Vite + React 18, TanStack Query + React Context, shadcn/ui, PM2
- **Resolution:** Intentional divergence via implementation decisions D-003, D-009.

### C-03: AI Model Version [ANALYST]
- SRS v3.0: `claude-3-5-sonnet-20241022`
- Implementation: `claude-sonnet-4-20250514`
- **Resolution:** Model upgraded. SRS stale.

### C-04: Notification Transport [ANALYST]
- SRS v3.0: SSE. Implementation note D-002: WebSocket (Socket.IO).
- Client code: No WebSocket connections despite socket.io in package.json.
- DealerBrain: SSE streaming (separate).
- **Resolution needed:** Verify actual notification transport. May be polling-only.

### C-05: Work Center / Hub Tab Count [ANALYST + REVIEWER CONFLICT 3]
- DESIGNER_UPDATE_SPEC.md: Hub has exactly 3 tabs (Calendar, Leads, Inbox) -- latest owner decision
- ARCHITECTURE_GUIDE.md: 5 tabs (Messages, Calendar, Tasks, Hunches, Approvals) [REVIEWER addition]
- client-audit.md: 5 tabs (Calendar, Tasks, Approvals, Communication, Open Leads)
- **Resolution:** V2.1 frontend rebuild will implement 3-tab design. Current 5-tab is V2 legacy.

### C-06: Trigger Event Type Vocabulary [ANALYST + REVIEWER CONFLICT 6]
- Multiple documents use different event type names for the same 7 types.
- `hot_lead` has no call site in codebase.
- **Resolution needed:** Verify canonical list against server codebase.

### C-07: Trigger Action Type Vocabulary [REVIEWER CONFLICT 7]
- `send_email` vs `send_notification`, `webhook` vs `assign_lead`.
- **Resolution needed:** Verify canonical list against server codebase.

### C-08: VIN Solutions Data Window [ANALYST]
- "48-hour" refers to polling window, not API limitation.
- **Resolution:** No hard 48-hour limit. Polling uses configurable date range.

### C-09: VIN Header Casing [ANALYST]
- Some docs: uppercase V3. Actual API: lowercase v3.
- **Resolution:** Use lowercase v3.

### C-10: VIN Solutions Integration Direction [ANALYST]
- SRS v3.0: "bidirectional sync." Addendum v3.1: "QUERY-ONLY." Arch map: webhook handler.
- **Resolution:** Current reality is query-only + polling + outbound lead creation (with bug). No VIN webhooks inbound.

### C-11: RLS Variable Name [ANALYST + REVIEWER]
- `app.current_organization_id` vs `app.current_org_id`.
- **Resolution needed:** Security-critical bug. One must be chosen and all policies updated.

### C-12: View Configuration Names [REVIEWER CONFLICT 1]
- ARCHITECTURE_GUIDE.md: 4 types (A-D)
- app_identity.md: 5 types (A-E) with different descriptions
- **Resolution needed:** Standardize layout type naming in SRS.

### C-13: Main Page Layout [REVIEWER CONFLICT 2]
- Three different descriptions: Chat-only (Arch Guide), metrics+chat (app_identity), original+tiles (DevDesign Notes)
- Codebase: dashboard.tsx at `/` and main.tsx at `/chat` -- both exist as separate pages.
- **Resolution needed:** Owner decision on V2.1 main page layout.

### C-14: Insights Sub-Tabs [REVIEWER CONFLICT 4]
- app_identity.md: Dashboard, Dealer Pulse, Goals, Hunches, Reports
- ===DevDesign Notes===.md: Dashboard (3 sub-tabs), Reports (3 sub-tabs), Library, Hunches. **Goals REMOVED.**
- client-audit.md: 6 tabs (Dashboard, Goals, Reports, Attribution, Hunches, Dealer Pulse)
- **Resolution needed:** Owner decision. DevDesign Notes says remove Goals but codebase still has it.

### C-15: Activity Page Location [REVIEWER CONFLICT 5]
- ===DevDesign Notes===.md: "move activity into a sub-tab in insights"
- client-audit.md: standalone page at `/activity`
- **Resolution needed:** Owner decision on V2.1 placement.

### C-16: Settings Tab Count [ANALYST]
- client-audit.md: 16+ settings tabs
- DESIGNER_UPDATE_SPEC.md: 9 tiles + Billing sub-menu
- **Resolution:** V2.1 designer spec reorganizes. Current implementation has more granular tabs.

### C-17: Production URL [ANALYST]
- `nexxusdev.huminicdev.com` vs `nexxusv2.huminicdev.com`
- **Resolution needed:** Verify which is the actual production URL.

### C-18: VIN Token Refresh Interval [ANALYST]
- Some docs: 6-hour refresh. VIN_SOLUTIONS_INTEGRATION.md: 60-min expiry, 30-min refresh.
- **Resolution:** 60-minute expiry with 30-minute proactive refresh is implemented. 6-hour reference is stale.

### C-19: DESIGN_FLAGS.md State [ANALYST]
- DESIGN_FLAGS.md: Empty. docs-audit.md: D-FLAG-001 PENDING REVIEW for 5 days.
- **Resolution needed:** Verify current state of design flags.

### C-20: Menu Order [REVIEWER CONFLICT 8]
- ===DevDesign Notes===.md: Main, Insights, Agents, Hub, Drive
- ARCHITECTURE_GUIDE.md: Main, Agents, Drive, Insights, Work Center, Activity
- **Resolution needed:** Use latest owner decision (DevDesign Notes).

---

## MERGED MISSING INFORMATION

All unique missing items from both agents, deduplicated and merged:

### MI-01: SMS State Machine Controller (both agents)
Schema defined in migration 032 but full state transition logic is not documented as fully implemented. Timeout durations, trigger events for each transition unspecified.

### MI-02: Voice Call Handoff Mechanism (both agents)
How does a VAPI voice call transition from AI to human agent? SMS handoff documented (state machine) but voice call handoff is not.

### MI-03: Widget-to-Inbox Handoff Mechanism [REVIEWER NOT FOUND 2]
The specific event or trigger that surfaces an external widget conversation to staff in the Unified Inbox is not specified. The concept is described but technical mechanism is not.

### MI-04: Error Retry Policy for Sync Queue (both agents)
Retry count, backoff strategy, dead letter behavior for failed VIN sync queue items not specified. 12/12 failed items remain in queue.

### MI-05: Rate Limiting Configuration (both agents)
Widget: 100/hr/IP confirmed. General API rate limits configured but specific limits per endpoint category, window sizes, penalty behavior not documented.

### MI-06: Trigger Deduplication Details [ANALYST]
Two dedup mechanisms exist, but exact fields deduped, time windows, and mechanism details are not documented.

### MI-07: Redis Implementation Status [ANALYST]
SRS v3.0 specifies Redis for caching and session management. Actual deployment status in V2 not confirmed.

### MI-08: pgvector Implementation Status [ANALYST]
SRS v3.0 mentions pgvector for vector search. Actual implementation status unclear.

### MI-09: ClickHouse Implementation Status [ANALYST]
ARCHITECTURE_VISUAL_MAP references ClickHouse for OLAP. Not confirmed in V2 codebase.

### MI-10: Cube.js Semantic Layer [ANALYST]
ARCHITECTURE_VISUAL_MAP references Cube.js. Not confirmed in V2 codebase.

### MI-11: Auto-Reaper Cron for Recordings [ANALYST]
SRS v3.0 specifies daily 2:00 AM cron for 30-day recording cleanup. Implementation status not verified.

### MI-12: MFA Implementation [ANALYST]
SRS v3.0: "MFA SHALL be required for administrative users." UI shows grayed out. Actual enforcement unclear.

### MI-13: Widget Domain Whitelist Enforcement [ANALYST]
Feature exists. Actual enforcement mechanism and configuration location need verification.

### MI-14: Hunch Generation Prompt / Algorithm [ANALYST + REVIEWER NOT FOUND 9]
Agent prompt fully specified (Hunch Instructions.md). But system-level trigger (every 6 hours) and data pipeline feeding it are not specified. How it scores confidence not documented.

### MI-15: Appointment Confirmation Token Flow [ANALYST]
48-hour tokens mentioned but full flow (generation, email inclusion, validation endpoint, expiry handling) not documented.

### MI-16: Partner Admin Org Provisioning Flow [ANALYST]
RBAC addition doc describes top-down provisioning but actual API endpoints and UI flow for partner admin creating/managing organizations not fully specified.

### MI-17: Orchestration Agent Specification [REVIEWER NOT FOUND 3]
Mentioned as concept ("traffic cop for all system component activity" -- app_identity.md line 148) but no implementation details or specification found.

### MI-18: System Agent Specifications [REVIEWER NOT FOUND 4]
Mentioned as "background agents only Super Admin can access" (app_identity.md line 145) but no enumeration or specification.

### MI-19: DealerBrainProcessor Enforcement Rules [REVIEWER NOT FOUND 5]
Only Stage 1 (monitoring) described. Enforcement stages not specified.

### MI-20: Multi-Org Query Resolution [REVIEWER NOT FOUND 6]
Owner explicitly says this is an "unresolved design question" (app_identity.md line 177). No resolution documented.

### MI-21: Agent Skills Catalog Content [REVIEWER NOT FOUND 8]
Concept documented. DESIGNER_UPDATE_SPEC Section 16 references "Skills Catalog (NEW)" but content not in input files. No enumeration of individual skill behaviors. [NOTE: ANALYST found the 74-skill catalog organized into 4 categories with names but not behavioral details.]

### MI-22: Product Tour Configuration [REVIEWER NOT FOUND 10]
driver.js used for onboarding. Owner states tour needs RBAC-based differentiation. No tour step definitions found.

---

## CROSS-WAVE NOTES

Both agents verified cross-wave notes from Wave 1. Merged (no disagreements):

### CW-1: Hub has exactly 3 tabs (Calendar, Leads, Inbox)
**Status:** CONFIRMED by DESIGNER_UPDATE_SPEC.md. Implementation has 5 tabs -- V2 legacy, V2.1 will reduce to 3.

### CW-2: Skills = agent overlays (V1 -> V2 architecture)
**Status:** CONFIRMED. V1 had 27 hardcoded agents; V2 has 74-skill catalog. This was the #1 source of testing agent confusion.

### CW-3: Widgets are portals to agents
**Status:** CONFIRMED by session-knowledge.md lines 17-22. Not standalone features.

### CW-4: Payment-critical demo set (7 capabilities)
**Status:** CONFIRMED by session-knowledge.md ~L64-89. [ANALYST provided full list]:
1. Metrics & Insights display correctly
2. Communications Agent configuration with criteria from system and VIN fields
3. Appointment flow: appointment -> calendar -> VIN Solutions insert with note
4. Proactive lead follow-up: outbound call + text when leads arrive
5. Reactive after-hours coverage: SMS and phone when staff unavailable
6. Widgets: all 3 deployment modes (unified, embed, hosted)
7. Automa Chat: ability to chat with Automa

### CW-5: Lead assignment is NOT part of requirements
**Status:** CONFIRMED by session-knowledge.md ~L44.

### CW-6: Most actionable activities go through an agent at user level
**Status:** CONFIRMED. CRM insertions, two-way calls, two-way texts all go through an agent.

### CW-7: Communication agent cannot be modified by user except triggers and instruction supplement
**Status:** CONFIRMED by session-knowledge.md ~L42.

### Additional Cross-Wave Verifications [REVIEWER]

### CW-R1: MASTER_SRS.md webhook-to-lead data flow
**Status:** VERIFIED and expanded. Flow is BROKEN in production due to missing `call.started` events.

### CW-R2: Context Router needs expansion for non-lead data
**Status:** VERIFIED. Owner's design intent includes 3 sections but implementation only covers VIN lead data routing.

### CW-R3: RLS variable name mismatch
**Status:** VERIFIED. `app.current_organization_id` vs `app.current_org_id`. Security-critical.

### CW-R4: SET LOCAL without transaction
**Status:** VERIFIED. Could leak org context between pooled connections.

### CW-R5: SMS conversation state machine needs full documentation
**Status:** VERIFIED as gap. Schema exists, transitions incomplete.

### CW-R6: Trigger deduplication undocumented
**Status:** VERIFIED and documented. Two mechanisms exist with atomic UPDATE pattern.

### CW-R7: VAPI webhook ingestion broken
**Status:** VERIFIED. `call.started` never received. 72% of post-V2 calls missing from DB.

---

## OWNER ACTION ITEMS SUMMARY

| # | Item | Category | Priority | Action Required |
|---|------|----------|----------|-----------------|
| 1 | Canonical trigger event type list | DISAGREE-1 | HIGH | Verify against codebase, standardize in SRS |
| 2 | Canonical trigger action type list | DISAGREE-2 | HIGH | Verify against codebase, standardize in SRS |
| 3 | VAPI webhook event names | DISAGREE-3 | MEDIUM | Confirm which event names are in actual handler code |
| 4 | Tavus webhook event names | DISAGREE-5 | LOW | Confirm against Tavus API docs |
| 5 | RLS variable name fix | C-11 | **CRITICAL** | Security bug. Choose one name, update all policies |
| 6 | Main page layout decision | C-13 | HIGH | Which layout for V2.1 main/dashboard page? |
| 7 | Insights sub-tabs (Goals removed?) | C-14 | HIGH | Confirm DevDesign Notes "remove Goals" decision |
| 8 | Activity page location | C-15 | MEDIUM | Standalone vs sub-tab of Insights for V2.1 |
| 9 | View/layout type naming | C-12 | MEDIUM | Standardize 4 vs 5 layout types |
| 10 | Menu order | C-20 | LOW | Confirm latest menu order |
| 11 | Production URL | C-17 | LOW | Which URL is production? |
| 12 | Notification transport | C-04 | MEDIUM | SSE vs WebSocket vs polling -- verify actual implementation |
| 13 | DESIGN_FLAGS.md state | C-19 | LOW | Verify current design flag status |
| 14 | Multi-org query resolution | MI-20 | HIGH | Unresolved design question -- needs owner decision |
| 15 | SMS state machine transitions | MI-01 | HIGH | Specify timeout durations and transition triggers |
| 16 | Widget-to-inbox handoff mechanism | MI-03 | HIGH | Specify the technical trigger for surfacing conversations |
| 17 | Voice call handoff (VAPI to human) | MI-02 | HIGH | Specify mechanism |
| 18 | Sync queue retry policy | MI-04 | MEDIUM | Specify retry count, backoff, dead letter behavior |
| 19 | Redis/pgvector/ClickHouse/Cube.js status | MI-07/08/09/10 | MEDIUM | Confirm which are implemented vs aspirational |
| 20 | MFA enforcement status | MI-12 | MEDIUM | Is MFA actually enforced or placeholder? |
| 21 | Skills catalog behavioral spec | MI-21 | LOW | Document what each of the 74 skills does |
| 22 | Product tour steps | MI-22 | LOW | Define tour steps per role |

---

## END OF WAVE 2 RECONCILED OUTPUT
