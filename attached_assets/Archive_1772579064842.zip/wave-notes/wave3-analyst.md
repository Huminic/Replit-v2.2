# Wave 3 Analyst: Architecture Extraction (SPEC)

**Analyst:** Claude Opus 4.6
**Date:** 2026-03-03
**Input files examined:** 22 of 53 (prioritized by SPEC relevance)
**Total citations:** 200+

---

## 1. Technology Stack

### 1.1 Frontend

| Technology | Version/Detail | Source |
|-----------|---------------|--------|
| Build tool | Vite | client-audit.md line 48 |
| Framework | React 18 | client-audit.md line 49 |
| Language | TypeScript (strict mode) | client-audit.md line 50; REVERSE_SRS_old.md line 607 |
| Routing | Wouter (NOT React Router) | client-audit.md line 51 |
| Server state | TanStack Query (React Query) | client-audit.md line 52 |
| Client state | React Context API (4 providers) | client-audit.md line 53 |
| UI library | shadcn/ui (Radix UI primitives) | client-audit.md line 54 |
| Styling | Tailwind CSS v4 (615 lines custom CSS) | REVERSE_SRS_old.md line 544 |
| Icons | lucide-react (60+ unique icons) | REVERSE_SRS_old.md line 546 |
| Calendar | FullCalendar | REVERSE_SRS_old.md line 547 |
| Rich text editor | Tiptap | REVERSE_SRS_old.md line 548 |
| Charts | Recharts (via shadcn chart component) | REVERSE_SRS_old.md line 549 |
| Onboarding | driver.js (9-step product tour) | REVERSE_SRS_old.md line 550 |
| Date utility | date-fns | client-audit.md line 61 |
| HTTP client | Native fetch (wrapped in `api.ts`) | client-audit.md line 62 |
| Fonts | Inter (sans), Merriweather (serif), Fira Code (mono) | REVERSE_SRS_old.md line 551 |

### 1.2 Backend

| Technology | Version/Detail | Source |
|-----------|---------------|--------|
| Runtime | Node.js v20.19.5 | REVERSE_SRS_old.md line 1236 |
| Framework | Express.js 5 (pre-release) | REVERSE_SRS_old.md line 239; server-audit.md line 45 |
| Language | TypeScript (strict mode) | REVERSE_SRS_old.md line 607 |
| Database driver | pg (PostgreSQL Pool, max 10 connections) | REVERSE_SRS_old.md line 145 |
| Process manager | PM2 6.0.13 | REVERSE_SRS_old.md line 1237 |
| AI SDK | Anthropic Claude API (SDK) | REVERSE_SRS_old.md line 335 |
| Email (transactional) | Resend SDK | REVERSE_SRS_old.md line 333 |
| Email (IMAP/SMTP) | ImapFlow + Nodemailer | server-audit.md line 52 |
| File upload | Multer (in-memory, max 50MB) | server-audit.md line 52 |
| Encryption | AES-256-GCM via built-in crypto | REVERSE_SRS_old.md line 457; server-audit.md line 54 |
| Build tooling | esbuild (server), Vite (client + widget) | REVERSE_SRS_old.md lines 1250-1254 |
| TypeScript execution | tsx | REVERSE_SRS_old.md line 1315 |

### 1.3 Database

| Technology | Detail | Source |
|-----------|--------|--------|
| Provider | Supabase (PostgreSQL) | REVERSE_SRS_old.md line 144 |
| Hosting | AWS us-west-2 | REVERSE_SRS_old.md line 144 |
| Connection | pg.Pool, max 10, prefers direct URL (port 5432) over pgbouncer (port 6543) | REVERSE_SRS_old.md line 145 |
| Tables | 53 | database-audit.md line 63 |
| Migrations | 33 (numbered 001-033, 011 missing) | database-audit.md line 11 |
| RLS policies | ~100 across all tables | REVERSE_SRS_old.md line 48 |
| Indexes | ~160 | REVERSE_SRS_old.md line 233 |
| Foreign keys | ~80 | REVERSE_SRS_old.md line 234 |
| JSONB columns | 58 (no DB-level schema validation) | REVERSE_SRS_old.md line 231 |

### 1.4 Testing

| Technology | Detail | Source |
|-----------|--------|--------|
| E2E framework | Playwright ^1.58.1 | health-audit.md line 148 |
| Browser | Chromium (Desktop Chrome, 1280x720) | health-audit.md line 153 |
| Unit tests | **None** (no Jest configuration) | health-audit.md line 44 |
| Component tests | **None** | health-audit.md line 165 |

### 1.5 Embeddable Widget

| Technology | Detail | Source |
|-----------|--------|--------|
| Framework | Preact (smaller bundle than React) | REVERSE_SRS_old.md line 1257 |
| Build | Vite (separate build target) | REVERSE_SRS_old.md line 1253 |
| Tracking pixel | IIFE bundle via esbuild, minified | REVERSE_SRS_old.md line 1254 |

### 1.6 npm Dependencies

| Category | Count | Source |
|----------|-------|--------|
| Production | 91 | REVERSE_SRS_old.md line 54 |
| Development | 31 | REVERSE_SRS_old.md line 54 |
| Total | 122 | REVERSE_SRS_old.md line 54 |
| Known vulnerabilities | 7 (0 critical, 4 high, 2 moderate, 1 low) | REVERSE_SRS_old.md line 55 |

CONFLICT: ARCHITECTURE_VISUAL_MAP.md line 31 says "Next.js 14 App Router" and line 41 says "Zustand + React Query" for state management. Actual codebase uses Vite + React (not Next.js) and React Context (not Zustand). The visual map appears aspirational, not as-built.

CONFLICT: ARCHITECTURE_VISUAL_MAP.md line 152 shows Redis for short-term memory (Tier 1). No Redis is used in the actual system. All state is PostgreSQL + in-memory (setInterval).

CONFLICT: ARCHITECTURE_VISUAL_MAP.md lines 170-197 show ClickHouse for OLAP, Airbyte ETL, dbt, and Cube.js. None of these are implemented. The system uses only Supabase PostgreSQL.

---

## 2. Service Topology

### 2.1 Service Inventory (40 modules)

**Location:** `server/services/`
**Source:** server-audit.md lines 584-631; DO_NOT_TOUCH.md lines 96-155

#### Top-Level Services (36)

| Service | File | Lines | Dependencies | Source |
|---------|------|-------|-------------|--------|
| DealerBrainService | `DealerBrainService.ts` | 3,047 | Claude API (Anthropic SDK), ContextRouterService, all tool-target services | REVERSE_SRS_old.md line 299 |
| DealerBrainStreamingService | `DealerBrainStreamingService.ts` | 2,020 | Claude API (SSE), same tool targets as above | REVERSE_SRS_old.md line 300 |
| VinSolutionsService | `vinSolutionsService.ts` | 1,134 | VIN Solutions REST API (OAuth2), encryption utils | REVERSE_SRS_old.md line 301 |
| TriggerService | `TriggerService.ts` | 1,413 | VAPI API (outbound calls), TextMagicService, NotificationService, TaskService | REVERSE_SRS_old.md line 302 |
| AppointmentService | `AppointmentService.ts` | 1,248 | GoogleCalendarService, AppointmentConfirmationService | REVERSE_SRS_old.md line 303 |
| TextMagicService | `TextMagicService.ts` | 1,130 | TextMagic REST API v2 | REVERSE_SRS_old.md line 304 |
| CreditService | `CreditService.ts` | -- | Local DB (credit_policies, credit_allocations, credit_usage) | REVERSE_SRS_old.md line 305 |
| WidgetConfigService | `WidgetConfigService.ts` | -- | Local DB | REVERSE_SRS_old.md line 306 |
| WidgetInteractionService | `WidgetInteractionService.ts` | -- | WidgetAgentService, InboxService, TriggerService | REVERSE_SRS_old.md line 307 |
| WidgetAgentService | `WidgetAgentService.ts` | -- | Claude API | REVERSE_SRS_old.md line 308 |
| InboxService | `InboxService.ts` | -- | Local DB | REVERSE_SRS_old.md line 309 |
| DealerPulseService | `DealerPulseService.ts` | -- | Claude Haiku, VinSolutionsService, local DB | REVERSE_SRS_old.md line 310 |
| EmailService | `EmailService.ts` | -- | ImapFlow, Nodemailer | REVERSE_SRS_old.md line 311 |
| GoogleCalendarService | `GoogleCalendarService.ts` | -- | Google Calendar API (OAuth2) | REVERSE_SRS_old.md line 312 |
| NotificationService | `NotificationService.ts` | -- | Resend (email), local DB (in-app) | REVERSE_SRS_old.md line 313 |
| KnowledgeUploadService | `KnowledgeUploadService.ts` | -- | xlsx library | REVERSE_SRS_old.md line 314 |
| GoalsService | `GoalsService.ts` | -- | Local DB | REVERSE_SRS_old.md line 315 |
| HunchesService | `HunchesService.ts` | -- | Claude API | REVERSE_SRS_old.md line 316 |
| DriveService | `DriveService.ts` | -- | Local filesystem + DB (1GB quota) | REVERSE_SRS_old.md line 317 |
| MetricsEngine | `MetricsEngine.ts` | -- | Local DB, role-based filtering | REVERSE_SRS_old.md line 318 |
| AccessibleOrganizationsService | `AccessibleOrganizationsService.ts` | -- | Local DB | server-audit.md line 588 |
| ActivityService | `ActivityService.ts` | -- | Local DB (ai_usage_events) | server-audit.md line 589 |
| AgentService | `AgentService.ts` | -- | Local DB, VAPI/Tavus metadata tagging | server-audit.md line 590 |
| ApprovalService | `ApprovalService.ts` | -- | Local DB | server-audit.md line 594 |
| ConversationService | `ConversationService.ts` | -- | Local DB | server-audit.md line 595 |
| DashboardService | `DashboardService.ts` | -- | Multiple services aggregated | server-audit.md line 597 |
| FeedbackService | `FeedbackService.ts` | -- | Local DB | server-audit.md line 603 |
| HostedPageService | `HostedPageService.ts` | -- | Local DB, widget config | server-audit.md line 606 |
| PasswordResetService | `PasswordResetService.ts` | -- | Local DB, Resend (email) | server-audit.md line 612 |
| PdfReportService | `PdfReportService.ts` | -- | Puppeteer | server-audit.md line 613 |
| ReportService | `ReportService.ts` | -- | Local DB, PdfReportService | server-audit.md line 614 |
| TaskService | `TaskService.ts` | -- | Local DB | server-audit.md line 615 |
| TrackingService | `TrackingService.ts` | -- | Local DB (tracking_events) | server-audit.md line 617 |
| VinOAuthService | `vinOAuthService.ts` | -- | VIN Solutions auth endpoint, encryption utils | server-audit.md line 619 |
| AppointmentConfirmationService | `appointmentConfirmationService.ts` | -- | Resend (email), TextMagicService (SMS) | server-audit.md line 592 |
| AppointmentExtractionService | `appointmentExtractionService.ts` | -- | Claude API (extraction) | server-audit.md line 593 |

#### Sub-Service Modules (4 directories)

| Directory | Files | Purpose | Source |
|-----------|-------|---------|--------|
| `contextRouter/` | `ContextRouterService.ts`, `SourceSelector.ts`, `CacheManager.ts`, `index.ts` | Unified data query orchestration (VIN API primary, local DB fallback) | REVERSE_SRS_old.md lines 964-990 |
| `sync/` | `SyncCoordinator.ts`, `LeadMapper.ts`, `index.ts` | VIN bidirectional lead sync (sync_queue processing) | DO_NOT_TOUCH.md lines 152-154 |
| `notifications/` | `notificationEmailService.ts` | Resend email dispatch for call events | DO_NOT_TOUCH.md line 155 |
| `insights/` | `VoiceInsightService.ts`, `VideoInsightService.ts`, `LeadInsightService.ts`, `index.ts` | Voice/video/lead analytics | DO_NOT_TOUCH.md lines 145-148 |
| `leads/` | `LeadCreationService.ts`, `LeadExtractionService.ts`, `index.ts` | Lead creation (VIN 2-step), AI extraction from transcripts | DO_NOT_TOUCH.md lines 149-151 |

### 2.2 Middleware Chain

**Applied in order (per server-audit.md lines 667-753):**

1. **Helmet** -- Security headers (CSP disabled for SPA) | `server/index.ts`
2. **express.json** -- JSON body parser with rawBody capture | `server/index.ts`
3. **express.urlencoded** -- URL-encoded body parser | `server/index.ts`
4. **API Logging** -- Request/response logging with sensitive field redaction (keys matching `/token|secret|password/i`) | `server/index.ts`
5. **authenticate** -- JWT validation, attaches `req.user` and `req.rlsVariables` | `server/auth/middleware.ts`
6. **enforceOrganizationContext** -- Creates SecureQueryBuilder with RLS context from JWT | `server/middleware/enforceOrganizationContext.ts`
7. **validateResourceOwnership** -- Validates resource belongs to requesting org | `server/middleware/validateResourceOwnership.ts`

**Role-level middleware functions (server-audit.md lines 694-700):**
- `requireSuperAdmin` -- role level === 1
- `requirePartnerAdminOrHigher` -- role level <= 2
- `requireOrgAdminOrHigher` -- role level <= 3
- `requireRoleLevel(minLevel)` -- role level <= minLevel

### 2.3 Scheduled Jobs (8)

| Job | Interval | Singleton Guard | Startup Delay | Source |
|-----|----------|----------------|---------------|--------|
| VIN Token Refresh | 30 min | `isRunning` flag | 0s | REVERSE_SRS_old.md line 359 |
| Sync Queue Worker | 1 min (outbound), 4 hrs (inbound) | `isRunning` flag | staggered | REVERSE_SRS_old.md line 360 |
| Appointment Reminder | 5 min | `isRunning` flag | staggered | REVERSE_SRS_old.md line 361 |
| Email Sync | 5 min (up to 50 integrations/run) | `isRunning` flag | staggered | REVERSE_SRS_old.md line 362 |
| VIN Lead Polling | 60 min | `isRunning` flag | staggered | REVERSE_SRS_old.md line 363 |
| Trigger Re-evaluation | 5 min | `isRunning` flag | staggered | REVERSE_SRS_old.md line 364 |
| Dealer Pulse | 4 hrs | `isRunning` flag | staggered | REVERSE_SRS_old.md line 365 |
| Hunch Generation | 6 hrs | `isRunning` flag | staggered | REVERSE_SRS_old.md line 366 |

All jobs use native `setInterval` (no Redis, no Bull). Staggered startup delays (0-90s) prevent thundering herd. (REVERSE_SRS_old.md line 368)

CONFLICT: VIN_SOLUTIONS_INTEGRATION.md line 37 says token refresh runs "every 6 hours." REVERSE_SRS_old.md line 359 says "30 min." The REVERSE_SRS is a later forensic audit and likely reflects the current state.

---

## 3. Database Schema

### 3.1 Table Groups (53 tables across 33 migrations)

**Source:** database-audit.md lines 62-130; REVERSE_SRS_old.md lines 147-169

| Group | Tables | Count |
|-------|--------|-------|
| Core Identity | organizations, locations, roles, users, partner_admin_organizations | 5 |
| Integrations | integrations, user_integrations | 2 |
| AI Agents | agents, skills, agent_runs | 3 |
| Conversations | conversations, messages | 2 |
| Leads & CRM | leads, sync_queue, vin_reports_cache | 3 |
| Voice/Video | vapi_call_logs, tavus_sessions | 2 |
| Communication | textmagic_config, textmagic_messages, textmagic_opt_outs, sms_conversation_state, cached_emails, sent_emails, email_templates | 7 |
| Work Center | tasks, appointments, availability_blocks, appointment_reminders, inbox_conversations, inbox_messages | 6 |
| Insights & Analytics | dashboards, widgets, goals, insight_card_config, insight_card_state, dealer_pulse_cache, report_benchmarks | 7 |
| Widget System | widget_configs, widget_callback_requests, widget_visitors, widget_chat_messages, hosted_pages | 5 |
| Governance & Tracking | ai_usage_events, trigger_rules, trigger_executions, trigger_templates, tracking_events, audit_log | 6 |
| Business | credit_policies, credit_allocations, credit_usage, service_quotas | 4 |
| Drive & Artifacts | drive_folders, drive_files, artifacts, knowledge_uploads | 4 |
| Workflow | hunches, approval_requests | 2 |
| Auth | password_reset_tokens | 1 |
| Notifications | notification_settings, notifications | 2 |
| Config | dealerbrain_config, vin_api_calls | 2 |

### 3.2 RLS Architecture

**Pattern distribution (database-audit.md lines 140-183):**

| Pattern | Description | Table Count |
|---------|-------------|-------------|
| A: `app.current_org_id` | Organization isolation (most common) | 43 |
| B: `app.current_user_id` | User-self-access (personal data) | 7 |
| C: `app.user_role_level = 1` | Super Admin bypass | 16 |
| D: `TO service_role` | Background job/webhook bypass | 17 |
| E: Role-tiered | Org Admin+ manages, Staff reads | 5 |
| F: Open read | Authenticated read for all | 2 (roles, skills) |
| G: Special/anomalous | `app.current_role` (never set), `password_reset_tokens` open | 4 |

**CRITICAL BUG:** SecureQueryBuilder sets `app.current_organization_id` but all RLS policies check `app.current_org_id`. These are different variable names. System works because most routes bypass SecureQueryBuilder and use `set_config('app.current_org_id', ...)` directly. (REVERSE_SRS_old.md lines 203-216; database-audit.md lines 190-200)

**Additional RLS anomalies (REVERSE_SRS_old.md lines 221-227):**
- `app.current_role_level` set in triggers.ts line 38, should be `app.user_role_level`
- `app.current_role` checked in dealer_pulse_cache and knowledge_uploads policies but never set by application code
- `SET LOCAL` used without transaction wrapper in SecureQueryBuilder, risking cross-tenant leakage on pooled connections

### 3.3 Migration Anomalies

- Migration 011 is **missing** (gap between 010 and 012) | database-audit.md line 28
- Two files share the `004` prefix (numbering collision) | database-audit.md line 57
- 16+ tables have `updated_at` columns but no automatic trigger | REVERSE_SRS_old.md line 232

### 3.4 Key Table Structures

**Full table details with key columns:** database-audit.md lines 65-130

Notable JSONB-heavy tables:
- `organizations`: settings, billing_info
- `locations`: address, business_hours, contact_info, settings
- `agents`: config, performance_metrics
- `conversations`: customer_info, metadata
- `widget_configs`: config_appearance, config_channels, config_targeting, allowed_domains, chat_enabled_tools

### 3.5 Database Functions and Triggers

- `update_updated_at_column()` function created in migration 003 (database-audit.md line 19)
- 4 triggers created with migration 003 for auto-updating `updated_at`
- `create_default_notification_settings()` trigger function in migration 008 (database-audit.md line 25)
- 12 tables have `updated_at` triggers; 16+ do not (REVERSE_SRS_old.md line 232)

---

## 4. API Endpoint Inventory

### 4.1 Summary

**Total endpoints:** ~237 (REVERSE_SRS_old.md line 245)
**Route files:** 34 (server-audit.md line 33)
**Registration file:** `server/routes.ts` (server-audit.md line 62)

### 4.2 Complete Route Group Table

| Route Prefix | File | Endpoints | Auth Level | Source |
|-------------|------|-----------|------------|--------|
| `/api/webhooks/vapi` | `server/webhooks/vapi.ts` | 1 (multi-event) | Public (optional secret) | server-audit.md line 65 |
| `/api/webhooks/tavus` | `server/webhooks/tavus.ts` | 1 (multi-event) | Public (HMAC verified) | server-audit.md line 66 |
| `/api/auth` | `server/routes/auth.ts` | 9 | Mixed (public + JWT) | server-audit.md lines 106-119 |
| `/api/vin` | `server/routes/vin.ts` | 10 | Mixed (Any + Super Admin + Org Admin+) | server-audit.md lines 508-523 |
| `/api/integrations` | `server/routes/integrations.ts` | 6 | Mixed (Any + Org Admin+) | server-audit.md lines 367-378 |
| `/api/insights` | `server/routes/insights.ts` | 15 | Mixed (Any + Org Admin+) | server-audit.md lines 346-365 |
| `/api/agents` | `server/routes/agents.ts` | 9 | Mixed (Any + Org Admin+) | server-audit.md lines 145-159 |
| `/api/credits` | `server/routes/credits.ts` | 5 | Mixed (Any + Org Admin+) | server-audit.md lines 224-233 |
| `/api/tasks` | `server/routes/tasks.ts` | 9 | Any | server-audit.md lines 464-477 |
| `/api/appointments` | `server/routes/appointments.ts` | 10 | Mixed (Any + Org Admin+ + public confirm) | server-audit.md lines 162-177 |
| `/api/conversations` | `server/routes/conversations.ts` | 11 | Any (file upload 50MB) | server-audit.md lines 205-221 |
| `/api/admin` | `server/routes/admin.ts` | 14 | Super Admin | server-audit.md lines 123-141 |
| `/api/admin/knowledge` | `server/routes/knowledge.ts` | 4 | Org Admin+ | server-audit.md lines 381-389 |
| `/api/settings` | `server/routes/settings.ts` | 4 | Org Admin+ | server-audit.md lines 439-447 |
| `/api/email` | `server/routes/email.ts` | 7 | Any | server-audit.md lines 265-276 |
| `/api/user/integrations` | `server/routes/userIntegrations.ts` | 7 | Any | server-audit.md lines 557-568 |
| `/api/dealerbrain` | `server/routes/dealerbrain.ts` | 3 | Super Admin | server-audit.md lines 242-249 |
| `/api/notifications` | `server/routes/notifications.ts` | 8 | Any | server-audit.md lines 414-426 |
| `/api/sms` | `server/routes/sms.ts` | 7 | Mixed (public webhook + Any + Admin) | server-audit.md lines 449-461 |
| `/api/widgets/public` | `server/routes/widget-public.ts` | 8 | Public (rate limited 100/hr/IP) | server-audit.md lines 541-554 |
| `/api/widgets` | `server/routes/widgets.ts` | 9 | Mixed (Any + Org Admin+) | server-audit.md lines 526-539 |
| `/api/inbox` | `server/routes/inbox.ts` | 8 | Mixed (Any + Org Admin+) | server-audit.md lines 332-344 |
| `/api/tracking` | `server/routes/tracking.ts` | 6 | Mixed (public + Org Admin+) | server-audit.md lines 479-489 |
| `/api/triggers` | `server/routes/triggers.ts` | 10 | Mixed (Any + Org Admin+) | server-audit.md lines 493-507 |
| `/api/activity` | `server/routes/activity.ts` | 6 | Mixed (Any + Org Admin+) | server-audit.md lines 192-201 |
| `/api/goals` | `server/routes/goals.ts` | 7 | Mixed (Any + Org Admin+) | server-audit.md lines 278-289 |
| `/api/reports` | `server/routes/reports.ts` | 5 | Mixed (Any + Org Admin+) | server-audit.md lines 428-437 |
| `/api/drive` | `server/routes/drive.ts` | 8 | Any | server-audit.md lines 251-263 |
| `/api/hunches` | `server/routes/hunches.ts` | 4 | Any | server-audit.md lines 322-330 |
| `/api/approvals` | `server/routes/approvals.ts` | 5 | Any | server-audit.md lines 180-189 |
| `/api/leads` | `server/routes/leads.ts` | 6 | Any | server-audit.md lines 391-401 |
| `/api/dashboard` | `server/routes/dashboard.ts` | 1 | Any | server-audit.md lines 235-240 |
| `/api/metrics` | `server/routes/metrics.ts` | 3 | Mixed (Any + Super Admin) | server-audit.md lines 405-412 |
| `/api` (google-calendar) | `server/routes/google-calendar.ts` | 7 | Mixed (Any + public callback) | server-audit.md lines 291-302 |
| `/api/hosted-pages` | `server/routes/hosted-pages.ts` | 5 | Mixed (Any + Org Admin+) | server-audit.md lines 304-313 |
| `/api/pages` | `server/routes/hosted-pages-public.ts` | 1 | Public | server-audit.md lines 315-320 |
| `/api/health` | inline | 1 | Public | server-audit.md line 576 |

### 4.3 Auth Distribution

| Auth Level | Endpoint Count | Source |
|-----------|---------------|--------|
| Public (no auth) | ~15 | REVERSE_SRS_old.md line 290 |
| Any authenticated user | ~110 | REVERSE_SRS_old.md line 291 |
| Org Admin+ (role level <= 3) | ~40 | REVERSE_SRS_old.md line 292 |
| Super Admin only (role level = 1) | ~20 | REVERSE_SRS_old.md line 293 |

### 4.4 Rate Limiting

| Route | Limit | Window | Scope | Source |
|-------|-------|--------|-------|--------|
| POST /api/auth/login | 30 | 1 minute | Per IP | REVERSE_SRS_old.md line 407 |
| POST /api/auth/register | 5 | 1 hour | Per IP | REVERSE_SRS_old.md line 408 |
| POST /api/auth/forgot-password | 3 | 1 hour | Per IP | REVERSE_SRS_old.md line 409 |
| /api/widgets/public/* | 100 | 1 hour | Per IP | REVERSE_SRS_old.md line 410 |
| POST /api/insights/dealer-pulse/refresh | 1 | 15 minutes | Per org | REVERSE_SRS_old.md line 411 |

No global rate limiting applied. (REVERSE_SRS_old.md line 413)

---

## 5. Frontend Architecture

### 5.1 Pages and Routes

**Total pages:** 21 (17 main + 4 hosted/public) | client-audit.md line 34
**Active routes:** 17 protected + 4 public + 1 catch-all | client-audit.md line 35

**Public routes (4):** `/login`, `/forgot-password`, `/reset-password`, `/w/:slug` | client-audit.md lines 127-133

**Protected routes (13):** `/`, `/chat`, `/leads`, `/agents`, `/agents/create`, `/agents/:id/edit`, `/drive`, `/insights`, `/work-center`, `/activity`, `/notifications`, `/settings/system`, `/profile`, `/profile/preferences` | client-audit.md lines 138-153

**Commented-out routes (2):** `/credits`, `/profile/billing` -- PHASE-FUTURE | client-audit.md lines 154-159

**Route protection:** `ProtectedRoute` component wraps `AppLayout` wrapping `PageComponent`. No route-level RBAC; role restrictions applied at component/tab level. (client-audit.md lines 167-173)

### 5.2 Layout System

**3-Pane grid layout (ARCHITECTURE_GUIDE.md lines 17-25):**

```css
.app-layout {
  grid-template-columns: [sidebar] 64px [left-pane] 240px [center-pane] 1fr [right-pane] 320px;
  height: 100vh;
}
```

| Pane | Width | Purpose | Source |
|------|-------|---------|--------|
| Vertical Sidebar | 64px fixed (collapsible to w-10) | Main navigation | ARCHITECTURE_GUIDE.md line 28; client-audit.md line 271 |
| Left Pane / SubMenu | 240-400px resizable (w-64 in code) | Contextual popout menus | ARCHITECTURE_GUIDE.md line 29; client-audit.md line 273 |
| Center Pane | flexible, min 600px | Primary content | ARCHITECTURE_GUIDE.md line 30 |
| Right Pane | 320-500px resizable (w-80 in code) | Automa chat or contextual tools | ARCHITECTURE_GUIDE.md line 31; client-audit.md line 275 |

**ViewConfig system (client-audit.md line 269):** AppLayout supports view modes: `chat-only`, `data-display`, `sub-menu`, `heavy-chat`

**Responsive breakpoints (client-audit.md lines 553):**
- Mobile (<1024px / `lg`): Sheet-based sidebar, bottom nav
- Desktop (>=1024px): Icon sidebar w-16
- Wide desktop (1280px+): Optional right pane w-80

### 5.3 State Management

**Dual-layer architecture (REVERSE_SRS_old.md lines 530-533):**

1. **Server state:** TanStack Query -- 38 `useQuery` calls, 34 `useMutation` calls across 26 custom hooks
2. **Client state:** 4 React Context providers

**Provider hierarchy (client-audit.md lines 392-402):**
```
QueryClientProvider > TooltipProvider > ThemeProvider > AuthProvider > AppProvider > ChatProvider > <Router /> > <FloatingChat /> > <ProductTour /> > <Toaster />
```

**Context Providers:**
- **AuthContext** (`contexts/AuthContext.tsx`): JWT login/logout/refresh, token storage, user state, org switching, auto-refresh timer | client-audit.md lines 405-428
- **AppContext** (`contexts/AppContext.tsx`): Derives currentUser/currentOrganization, sidebar/panel states, favorites | client-audit.md lines 431-454
- **ChatContext** (`contexts/ChatContext.tsx`): Floating chat panel open/close/minimize, active conversation | client-audit.md lines 457-469
- **ThemeContext** (`contexts/ThemeContext.tsx`): Light/dark toggle, localStorage persistence (`nexxus:theme`), system preference detection | client-audit.md lines 471-485

**TanStack Query defaults (client-audit.md lines 487-498):**
- `staleTime: Infinity` (data never auto-stales)
- `refetchOnWindowFocus: false`
- `retry: false`
- Cache invalidation on org switch (invalidates ALL)

### 5.4 Custom Hooks (26)

Full inventory at client-audit.md lines 507-538. Key architectural hooks:

| Hook | Queries | Mutations | Source |
|------|---------|-----------|--------|
| `useStreamingMessage` | 0 | 0 | SSE streaming for AI chat (client-audit.md line 535) |
| `useAgents` | 3 | 4 | Agent CRUD (client-audit.md line 515) |
| `useInsights` | 3 | 0 | Dashboard cards (client-audit.md line 529) |
| `useConversations` | 3 | 2 | DealerBrain chat (client-audit.md line 518) |
| `useAdmin` | 2+ | 3+ | Super Admin user/org management (client-audit.md line 514) |

### 5.5 Component Inventory

| Category | Count | Source |
|----------|-------|--------|
| shadcn/ui primitives (Radix-based) | 47 | client-audit.md lines 209-261 |
| Layout components | 8 | client-audit.md lines 265-276 |
| Chat components | 6 | client-audit.md lines 278-287 |
| Modal components | 8 (+1 VideoPlayerModal) | client-audit.md lines 289-301 |
| Report components | 8 | client-audit.md lines 303-314 |
| Settings tab components | 8 | client-audit.md lines 316-327 |
| Insights components | 5 | client-audit.md lines 329-337 |
| Communication components | 3 | client-audit.md lines 339-345 |
| Calendar components | 2 | client-audit.md lines 347-352 |
| Admin components | 2 | client-audit.md lines 354-359 |
| Notification components | 3 | client-audit.md lines 361-367 |
| Other (auth, inbox, SMS, onboarding) | 4 | client-audit.md lines 369-377 |
| **Total** | **~105** (59 custom + 47 shadcn) | REVERSE_SRS_old.md line 526 |

---

## 6. File/Directory Structure

**Source:** REVERSE_SRS_old.md lines 1330-1388

```
nexxus-v2/
  client/                  # React SPA (Vite)
    src/
      components/          # 105 components (59 custom + 47 shadcn/ui)
        admin/             # 2 files — User/org dialogs
        auth/              # 1 file — ProtectedRoute
        calendar/          # 2 files — FullCalendar integration
        chat/              # 6 files — Chat panel, streaming, charts
        communication/     # 3 files — Email inbox/compose
        inbox/             # 1 file — Messaging panel
        insights/          # 5 files — Dashboard cards
        layout/            # 8 files — AppLayout, TopBar, Sidebar, SubMenu, RightPane, FavoritesBar
        modals/            # 8-9 files — Transcript, lead detail, table modals
        notifications/     # 3 files — Bell, settings, barrel export
        onboarding/        # 1 file — Product tour
        reports/           # 8 files — Report catalog, viewer, charts
        settings/          # 8 files — Tab components
        sms/               # 1 file — SMS compose dialog
        ui/                # 47 files — shadcn/ui primitives
      contexts/            # 4 files — Auth, App, Chat, Theme
      hooks/               # 26 files — TanStack Query + utility hooks
      lib/                 # 3 files — API client (api.ts), query config (queryClient.ts), utils (utils.ts)
      mocks/               # 9 files — Mock data modules (may be unused)
      pages/               # 17 main + 4 hosted
  server/                  # Express.js API
    auth/                  # JWT (jwt.ts) + middleware (middleware.ts)
    db/                    # SecureQueryBuilder.ts, index.ts
    jobs/                  # 8 scheduled jobs (vinTokenRefreshJob.ts etc.)
    middleware/            # enforceOrganizationContext.ts, validateResourceOwnership.ts, index.ts
    routes/                # 34 route files
    services/              # 36 top-level service files
      contextRouter/       # 4 files (ContextRouterService, SourceSelector, CacheManager, index)
      insights/            # 4 files (Voice, Video, Lead insight services + index)
      leads/               # 3 files (LeadCreation, LeadExtraction, index)
      sync/                # 3 files (SyncCoordinator, LeadMapper, index)
      notifications/       # 1 file (notificationEmailService)
    utils/                 # Encryption utils, env validation
    webhooks/              # 3 files (vapi.ts, tavus.ts, utils/signatureVerifier.ts)
    index.ts               # Main entry point
    routes.ts              # Route registry
    storage.ts             # Storage interface
    static.ts              # Static file serving
    vite.ts                # Dev server middleware
  database/
    migrations/            # 33 SQL files (001-033, 011 missing)
    seed.sql               # Development seed data
  tests/
    e2e/                   # 46 Playwright spec files (747 tests)
      helpers/             # global-setup.ts, test-utils.ts
    scripts/               # 7 diagnostic scripts
    verification/          # 11 verification scripts
  widget/                  # Preact embeddable widget (separate build)
  docs/                    # Documentation (40+ files)
    audit/                 # 5 forensic audit reports
    evidence/              # Certification evidence
    reference/             # Production deployment docs
    archive/               # Pre-stabilization archives (40+ files)
  dist/                    # Build output (not in git)
    public/                # Client SPA
      widget/              # Embeddable widget + tracking pixel
    index.cjs              # Server bundle
  uploads/                 # User uploads (not in git)
  .env                     # 33 environment variables (not in git)
  deploy.sh                # Deploy script (master branch guard)
  playwright.config.ts     # E2E test configuration
  package.json             # Dependencies and scripts
  tsconfig.json            # TypeScript configuration (strict mode, noEmit)
  vite.config.ts           # Vite build configuration
  shared/schema.ts         # Shared types (minimal, 18 lines)
```

---

## 7. Deployment Architecture

### 7.1 Infrastructure

| Component | Detail | Source |
|-----------|--------|--------|
| Server | Oracle Cloud, Linux 5.15.0-1081-oracle | REVERSE_SRS_old.md line 1235 |
| Runtime | Node.js v20.19.5 | REVERSE_SRS_old.md line 1236 |
| Process manager | PM2 6.0.13, process name `nexxus-v2`, ID 13 | REVERSE_SRS_old.md lines 1237, 1282-1283 |
| Reverse proxy | Caddy (managed by sysadmin project) | REVERSE_SRS_old.md line 1238 |
| SSL | Managed by Caddy/sysadmin | REVERSE_SRS_old.md line 1239 |
| Database | Supabase PostgreSQL (aws-0-us-west-2) | REVERSE_SRS_old.md line 1240 |
| Docker | NOT used | REVERSE_SRS_old.md line 1241 |
| CI/CD | NOT configured | REVERSE_SRS_old.md line 1242 |
| Monitoring | None project-specific | REVERSE_SRS_old.md line 1243 |
| Live URL | https://nexxusv2.huminicdev.com | REVERSE_SRS_old.md line 1392 |
| Health check | GET /api/health | REVERSE_SRS_old.md line 1393 |

### 7.2 Build Pipeline

**Orchestrated by:** `script/build.ts` (REVERSE_SRS_old.md lines 1247-1255)

| Step | Tool | Input | Output |
|------|------|-------|--------|
| 1 | rm -rf | dist/ | (clean) |
| 2 | Vite build | client/ | dist/public/ (React SPA) |
| 3 | Vite build | widget/ | dist/public/widget/ (Preact widget) |
| 4 | esbuild | tracking pixel | dist/public/widget/nexxus-pixel.js (IIFE, minified) |
| 5 | esbuild | server/ | dist/index.cjs (CJS, minified) |

**Four build outputs:** Client SPA, embeddable widget (Preact), tracking pixel (IIFE), server (CJS).

### 7.3 Deploy Process

**Script:** `./deploy.sh` (REVERSE_SRS_old.md lines 1261-1276)
1. Checks current branch is `master` (refuses feature branches)
2. Warns about uncommitted changes (y/N prompt)
3. Runs `npm run build`
4. Runs `pm2 restart nexxus-v2`
5. Shows `pm2 status`

**Missing:** No pre-deploy tests, no health check after restart, no rollback mechanism, no deploy notification.

### 7.4 PM2 Status

| Metric | Value | Source |
|--------|-------|--------|
| Memory | 148.9 MB | REVERSE_SRS_old.md line 1287 |
| CPU | 0.2% | REVERSE_SRS_old.md line 1288 |
| Total restarts | 3,327 in 31 days (~107/day) | REVERSE_SRS_old.md line 1290 |
| Unstable restarts | 0 | REVERSE_SRS_old.md line 1291 |
| Ecosystem config | NOT PRESENT | REVERSE_SRS_old.md line 1292 |

### 7.5 Disk Usage

| Directory | Size | Source |
|-----------|------|--------|
| Source + docs + assets | 34 MB | REVERSE_SRS_old.md line 1306 |
| node_modules/ | 575 MB | REVERSE_SRS_old.md line 1307 |
| dist/ (build output) | 12 MB | REVERSE_SRS_old.md line 1308 |
| **Total** | **656 MB** | REVERSE_SRS_old.md line 1309 |

### 7.6 NPM Scripts

| Script | Command | Source |
|--------|---------|--------|
| `build` | `tsx script/build.ts` | REVERSE_SRS_old.md line 1315 |
| `dev` | `NODE_ENV=development tsx server/index.ts` | REVERSE_SRS_old.md line 1319 |
| `start` | `NODE_ENV=production node dist/index.cjs` | REVERSE_SRS_old.md line 1320 |
| `check` | `tsc` (type checking, no emit) | REVERSE_SRS_old.md line 1317 |
| `test:quality` | `check && build && test:env && test:accuracy` | REVERSE_SRS_old.md line 1323 |

**Missing scripts:** No `lint`, `format`, `test` (Playwright), or `test:unit`. (REVERSE_SRS_old.md line 1326)

---

## 8. Integration Architecture

### 8.1 VIN Solutions (CRM)

| Aspect | Detail | Source |
|--------|--------|--------|
| Type | REST API | REVERSE_SRS_old.md line 330 |
| Auth | OAuth2 Client Credentials (tokens expire 60 min) | REVERSE_SRS_old.md line 330 |
| Token storage | AES-256-GCM encrypted in `integrations.credentials` | REVERSE_SRS_old.md line 940 |
| Token refresh | Every 30 min (job), refreshes within 10 min of expiry | REVERSE_SRS_old.md lines 943-948 |
| Base URL | `https://api.vinsolutions.com` | DATA_SOURCE_INVENTORY.md line 25 |
| Header versioning | v1 endpoints: `application/vnd.coxauto.v1+json`, v3 endpoints: `application/vnd.coxauto.v3+json` (lowercase), gateway: `application/json` | REVERSE_SRS_old.md lines 1028-1031 |
| Accessible endpoints | 13 (leads CRUD, contacts, lead sources/types/statuses, CRM users, dealers) | REVERSE_SRS_old.md lines 1009-1025 |
| Blocked endpoints | 17 (all return 403) | REVERSE_SRS_old.md lines 1033-1053 |
| Service files | `vinSolutionsService.ts`, `vinOAuthService.ts` | DO_NOT_TOUCH.md lines 134-135 |
| Sub-services | `sync/SyncCoordinator.ts`, `sync/LeadMapper.ts` | DO_NOT_TOUCH.md lines 152-153 |
| Context Router files | `contextRouter/ContextRouterService.ts`, `SourceSelector.ts`, `CacheManager.ts` | DO_NOT_TOUCH.md lines 141-144 |
| Lead creation | 2-step: POST /gateway/v1/contact -> get ContactId, then POST /leads with href references | REVERSE_SRS_old.md lines 820-823 |
| API call telemetry | `vin_api_calls` table (endpoint, params, duration, status, result_count) | database-audit.md line 127 |

**CRITICAL BUG:** Lead creation code calls `/leadSources` and `/leadTypes` with v3 headers but these endpoints require v1 headers. Calls fail silently (caught in try/catch). (DATA_SOURCE_INVENTORY.md lines 156-164)

### 8.2 VAPI (Voice AI)

| Aspect | Detail | Source |
|--------|--------|--------|
| Type | Webhook inbound + outbound API | REVERSE_SRS_old.md line 331 |
| Auth (inbound) | Optional shared secret (`X-Vapi-Secret`, timing-safe comparison) | REVERSE_SRS_old.md lines 340-344 |
| Webhook endpoint | `/api/webhooks/vapi` (registered BEFORE body parsers) | server-audit.md line 65 |
| Events handled | `call.started`, `call.ended`, `end-of-call-report`, `transcript`, `status-update` | REVERSE_SRS_old.md lines 341 |
| Org resolution | `metadata.organizationId` or `assistantId` lookup in agents table | REVERSE_SRS_old.md line 342 |
| Idempotency | `notification_sent` and `credit_recorded` columns with atomic UPDATE...WHERE...RETURNING | REVERSE_SRS_old.md line 343 |
| Processing chain | Call log -> lead extraction -> sync_queue -> credit recording -> email notification -> in-app notification -> appointment extraction | REVERSE_SRS_old.md lines 800-832 |

### 8.3 Tavus (Video AI)

| Aspect | Detail | Source |
|--------|--------|--------|
| Type | Webhook inbound + outbound API | REVERSE_SRS_old.md line 332 |
| Auth | HMAC-SHA256 with 5-minute timestamp tolerance | REVERSE_SRS_old.md line 349 |
| Webhook endpoint | `/api/webhooks/tavus` (raw body capture for HMAC) | server-audit.md line 66 |
| Events handled | `conversation.started`, `conversation.ended`, `replica.ready`, `video.ready` | REVERSE_SRS_old.md line 348 |
| Org resolution | `custom_data.organization_id` or `persona_id` lookup in agents table | REVERSE_SRS_old.md line 349 |
| Deployed agents | 5 personas (Caroline, Magnolia, Georgia, Elizabeth, Savannah) across 2 customers | REVERSE_SRS_old.md line 116 |

### 8.4 TextMagic (SMS)

| Aspect | Detail | Source |
|--------|--------|--------|
| Type | REST API v2 | REVERSE_SRS_old.md line 334 |
| Auth | Username + API key (per-org, stored in `textmagic_config`) | REVERSE_SRS_old.md line 334 |
| Inbound webhook | `/api/sms/webhook/inbound` (public, NO signature verification -- TextMagic does not sign) | REVERSE_SRS_old.md lines 351-353 |
| Service file | `TextMagicService.ts` (1,130 lines) | REVERSE_SRS_old.md line 304 |
| Tables | `textmagic_config`, `textmagic_messages`, `textmagic_opt_outs`, `sms_conversation_state` | database-audit.md lines 106-109, 129 |

### 8.5 Resend (Email)

| Aspect | Detail | Source |
|--------|--------|--------|
| Type | SDK | REVERSE_SRS_old.md line 333 |
| Auth | API key | REVERSE_SRS_old.md line 333 |
| Purpose | Transactional email (lead notifications, welcome emails, appointment confirmations) | REVERSE_SRS_old.md line 333 |
| Service file | `notifications/notificationEmailService.ts` | DO_NOT_TOUCH.md line 155 |

### 8.6 Anthropic Claude (AI/LLM)

| Aspect | Detail | Source |
|--------|--------|--------|
| Type | SDK | REVERSE_SRS_old.md line 335 |
| Auth | API key | REVERSE_SRS_old.md line 335 |
| Model | Configurable (defaults to claude-3-5-sonnet) | server-audit.md line 638 |
| Service files | `DealerBrainService.ts` (3,047 lines), `DealerBrainStreamingService.ts` (2,020 lines) | REVERSE_SRS_old.md lines 299-300 |
| Tools exposed | 24 tools for function calling | REVERSE_SRS_old.md lines 374-399 |
| Also used by | `DealerPulseService` (Claude Haiku for commentary), `HunchesService`, `AppointmentExtractionService`, `WidgetAgentService` | REVERSE_SRS_old.md lines 310, 316; server-audit.md line 593 |

### 8.7 Google Calendar

| Aspect | Detail | Source |
|--------|--------|--------|
| Type | OAuth2 (Authorization Code flow) | REVERSE_SRS_old.md line 336 |
| Auth | OAuth tokens (per-user) | REVERSE_SRS_old.md line 336 |
| Service file | `GoogleCalendarService.ts` | server-audit.md line 605 |
| Routes | 7 endpoints at `/api` (oauth/calendar paths) | server-audit.md lines 291-302 |
| Purpose | Calendar sync, appointment push to Google Calendar | REVERSE_SRS_old.md line 336 |

---

## 9. Real-Time Architecture

### 9.1 SSE Streaming (DealerBrain)

| Aspect | Detail | Source |
|--------|--------|--------|
| Endpoint | `POST /api/conversations/:id/stream` | CARRY_FORWARD_MANIFEST.md lines 107-108 |
| Auth | `Authorization: Bearer {token}` header | CARRY_FORWARD_MANIFEST.md line 109 |
| Body | `{ content: string }` | CARRY_FORWARD_MANIFEST.md line 110 |
| Event types | `thinking`, `tool_start`, `tool_end`, `token`, `done`, `error` | CARRY_FORWARD_MANIFEST.md lines 112-117 |
| Client hook | `useStreamingMessage.ts` | CARRY_FORWARD_MANIFEST.md line 103 |
| Also used | Widget public chat SSE at `POST /api/widgets/public/chat/stream` | server-audit.md line 548 |

### 9.2 Polling

| Feature | Interval | Source |
|---------|----------|--------|
| Token auto-refresh | 60 seconds (client-side) | client-audit.md line 428 |
| Notification unread count | Polling (interval not specified) | UNIFIED_HANDOFF_PROMPT.md line 177 |
| VIN lead polling | 60 minutes (server-side job) | REVERSE_SRS_old.md line 363 |
| Dashboard auto-refresh | 60 seconds with 5-min manual cooldown | client-audit.md line 84 |

### 9.3 WebSocket

Socket.io is installed but NOT actively used for production features. (UNIFIED_HANDOFF_PROMPT.md line 176; server-audit.md line 51)

CONFLICT: ARCHITECTURE_VISUAL_MAP.md line 59 says Daria (System Agent) "Monitor all activity streams (WebSocket)." This is aspirational; no WebSocket monitoring exists in the codebase.

---

## 10. Configuration Management

### 10.1 Environment Variables

- **33 environment variables** in `.env` | REVERSE_SRS_old.md line 1297
- `.env` is git-ignored | REVERSE_SRS_old.md line 1298
- No `.env.example` or `.env.template` exists | REVERSE_SRS_old.md line 1299

**Known env vars (from various sources):**

| Variable | Purpose | Source |
|----------|---------|--------|
| `VIN_SOLUTIONS_CLIENT_ID` | VIN OAuth client ID | VIN_SOLUTIONS_INTEGRATION.md line 68 |
| `VIN_SOLUTIONS_CLIENT_SECRET` | VIN OAuth client secret | VIN_SOLUTIONS_INTEGRATION.md line 69 |
| `VIN_SOLUTIONS_API_KEY` | VIN API key | VIN_SOLUTIONS_INTEGRATION.md line 70 |
| `CONTEXT_ROUTER_ENABLED` | Toggle Context Router (true/false) | REVERSE_SRS_old.md line 992 |
| `SESSION_SECRET` | Key derivation for AES-256-GCM encryption | REVERSE_SRS_old.md line 457 |
| `VAPI_WEBHOOK_SECRET` | VAPI webhook verification | REVERSE_SRS_old.md line 344 |
| `NODE_ENV` | production/development | REVERSE_SRS_old.md line 436 |
| `PORT` | Server port (default 5000) | server-audit.md line 46 |

### 10.2 Database Configuration

- **DealerBrain config** stored in `dealerbrain_config` table (key-value): system_instructions, feedback_enabled, feedback_instructions | database-audit.md line 102
- **Organization settings** stored in `organizations.settings` JSONB column | database-audit.md line 67
- **Per-user integration credentials** stored encrypted in `user_integrations.credentials` JSONB | database-audit.md line 95

### 10.3 RBAC Configuration

4-tier RBAC roles seeded in database (REVERSE_SRS_old.md lines 450-455):

| Level | Role | Source |
|-------|------|--------|
| 1 | Super Admin | REVERSE_SRS_old.md line 452 |
| 2 | Partner Admin | REVERSE_SRS_old.md line 453 |
| 3 | Org Admin | REVERSE_SRS_old.md line 454 |
| 4 | Org Staff | REVERSE_SRS_old.md line 455 |

### 10.4 Token Configuration

| Token | Expiry | Audience | Source |
|-------|--------|----------|--------|
| Access token | 24 hours | `nexxus-api` | REVERSE_SRS_old.md line 444 |
| Refresh token | 7 days | `nexxus-api` | REVERSE_SRS_old.md line 445 |
| Appointment confirmation | 48 hours | `nexxus-appointment` | REVERSE_SRS_old.md line 446 |

### 10.5 localStorage Keys (Client)

| Key | Purpose | Source |
|-----|---------|--------|
| `nexxus_access_token` | JWT access token | CARRY_FORWARD_MANIFEST.md line 39 |
| `nexxus_refresh_token` | JWT refresh token | CARRY_FORWARD_MANIFEST.md line 39 |
| `nexxus_token_expiry` | Token expiry timestamp | CARRY_FORWARD_MANIFEST.md line 39 |
| `nexxus_accessible_orgs` | Partner Admin org list | CARRY_FORWARD_MANIFEST.md line 39 |
| `nexxus:theme` | Light/dark theme preference | client-audit.md line 483 |
| `nexxus_welcome_shown` | Welcome modal state | CARRY_FORWARD_MANIFEST.md line 93 |
| `nexxus_hide_welcome` | Welcome modal suppression | CARRY_FORWARD_MANIFEST.md line 93 |

---

## 11. Frontend Component Map

### 11.1 Key Components by Page

**Dashboard (`/`):** DealershipPulse, GoalProgress, LeadFeed (VIN API sourced), AgentActions (sparkline), TeamLeaderboard. Role-based visibility via `ROLE_VISIBILITY` map. | client-audit.md line 84

**DealerBrain Chat (`/chat`):** Left panel (favorites + conversation history), main chat area (SSE streaming), file upload, suggested prompts. Uses `StreamingMessage` component. | client-audit.md line 85

**Insights (`/insights`, `/leads`):** 6-tab: Dashboard (VoiceAgentCard, VideoDataCard, LeadFeedCard + Quick Summary), Goals, Reports (ReportCatalog), Attribution, Hunches, Dealer Pulse. Date range filter. | client-audit.md line 86

**Agents (`/agents`):** Three-column layout: agent list (left w-72), chat interface (center), info/artifacts/stats panel (right w-80). Agent seeding on first load. Chat wired to DealerBrain streaming API. Automa always active. | client-audit.md line 87

**Work Center (`/work-center`):** 5-tab "Hub": Calendar (AppointmentCalendar + AppointmentModal), Tasks, Approvals, Communication (InboxPanel), Open Leads. Tab state synced with URL search params. | client-audit.md line 90

**Settings (`/settings/system`):** 16+ tabs, role-gated. Super Admin: Users, Organizations, Partner Links, Tools, Hunches, Automa, SMS. Org Admin+: Knowledge, Email, Widget, Pages, Report Upload, Triggers. All: Application, Integrations. | client-audit.md line 91

### 11.2 Interactive Element Handlers

Full mapping at UI_INTERACTIVE_ELEMENTS_MAP.md lines 1-200. Key patterns:
- Form submissions call TanStack Query mutations
- Navigation uses Wouter's `setLocation()`
- State toggles use React `useState` setters
- Modals use `setXxxOpen(true/false)` pattern
- Filters use `setXxxFilter(value)` with query invalidation

---

## 12. Build & Development Pipeline

### 12.1 Build Process

**Entry:** `npm run build` -> `tsx script/build.ts`

| Step | Tool | Target | Output | Source |
|------|------|--------|--------|--------|
| 1 | rm -rf | dist/ | clean | REVERSE_SRS_old.md line 1250 |
| 2 | Vite | client/ | dist/public/ | REVERSE_SRS_old.md line 1251 |
| 3 | Vite | widget/ | dist/public/widget/ | REVERSE_SRS_old.md line 1252 |
| 4 | esbuild | tracking pixel | dist/public/widget/nexxus-pixel.js | REVERSE_SRS_old.md line 1253 |
| 5 | esbuild | server/ | dist/index.cjs | REVERSE_SRS_old.md line 1254 |

### 12.2 Development Workflow

```
Working Directory -> TypeScript (.ts files)
                  -> npm run build
                  -> dist/ (compiled JavaScript)
                  -> PM2 serves dist/index.cjs
                  -> Users see compiled code
```
(REVERSE_SRS_old.md lines 1260-1270)

**Feature branch workflow:** Create feature branch -> work -> merge to master -> `./deploy.sh` -> clean up branch. Deploy script refuses non-master branches. (REVERSE_SRS_old.md lines 1266-1270)

### 12.3 Quality Gates

| Gate | Tool | Status | Source |
|------|------|--------|--------|
| TypeScript type check | `tsc` (strict mode, noEmit) | Configured | REVERSE_SRS_old.md line 1317 |
| ESLint | NOT configured | Missing | REVERSE_SRS_old.md line 612 |
| Prettier | NOT configured | Missing | REVERSE_SRS_old.md line 613 |
| Pre-commit hooks | NOT configured | Missing | REVERSE_SRS_old.md line 614 |
| CI/CD pipeline | NOT configured | Missing | REVERSE_SRS_old.md line 615 |
| Test coverage | NOT measured | Missing | health-audit.md line 168 |

### 12.4 Test Infrastructure

| Aspect | Detail | Source |
|--------|--------|--------|
| E2E test count | 747 across 46 files | health-audit.md lines 38-39 |
| Framework | Playwright ^1.58.1 | health-audit.md line 148 |
| Config file | `playwright.config.ts` | health-audit.md line 149 |
| Base URL | `https://nexxusv2.huminicdev.com` (tests against production) | health-audit.md line 152 |
| Browser | Chromium, Desktop Chrome, 1280x720 | health-audit.md line 153 |
| Parallelism | Fully parallel (local), 1 worker (CI) | health-audit.md line 154 |
| Retries | 0 (local), 2 (CI) | health-audit.md line 155 |
| Artifacts | Screenshots + video on failure, trace on first retry | health-audit.md line 156 |

**Unit tests:** ZERO (no Jest config, no test files) | health-audit.md lines 44, 163
**Component tests:** ZERO (no React Testing Library) | health-audit.md line 165
**Integration tests:** ZERO (API tested only via E2E) | health-audit.md line 164

---

## Watch Area Findings

### W1. Agent Functionality

**Service files:** `AgentService.ts` (CRUD), `DealerBrainService.ts` + `DealerBrainStreamingService.ts` (chat), `WidgetAgentService.ts` (widget chat) | server-audit.md lines 590, 598-599, 621

**Agent CRUD endpoints:** 9 at `/api/agents` (list, stats, seed, get, create, update, delete, duplicate, status toggle) | server-audit.md lines 145-159

**Tables:** `agents` (config, type, performance_metrics JSONB), `skills` (name, category, template, parameters_schema), `agent_runs` (execution tracking) | database-audit.md lines 74-77

**Default seed agents:** Automa (system agent, cannot be deleted/duplicated), Sales Coach, Message Crafter, VAPI voice agent | server-audit.md line 160

**Skills architecture:** 10 skill types defined in UI; skill execution NOT fully connected to agent runtime | REVERSE_SRS_old.md line 655

**Agent performance metrics:** `performanceMetrics` JSONB field exists in `agents` table but is NEVER populated by webhooks -- GAP-1 | REVERSE_SRS_old.md line 654

**DealerBrain tools:** 24 tools available for function calling (query_leads, query_vapi_calls, create_goal, create_agent, send_sms, etc.) | REVERSE_SRS_old.md lines 374-399

[SRS-relevant: session-knowledge.md lines 52-58 describe Skills as user-selectable agent overlays (V1->V2 architecture transition), not separate agent types]

### W2. Billing / Credits

**Service file:** `CreditService.ts` | server-audit.md line 596

**Tables:** `credit_policies` (per-org service pricing), `credit_allocations` (monthly tracking), `credit_usage` (real-time consumption), `service_quotas` (per-org limits, SCHEMA ONLY -- no enforcement logic found) | database-audit.md lines 83-85, 128

**Routes:** 5 at `/api/credits` (balance, usage, policies, recent, summary) | server-audit.md lines 224-233

**Pricing structure:**
- Voice: $0.25/min (customer) / $0.15/min (cost) = 40% margin
- Video: $0.32/min (customer) / $0.20/min (cost) = 37.5% margin
- SMS: $0.05/msg (customer) / $0.02/msg (cost) = 60% margin
| REVERSE_SRS_old.md lines 100-105; server-audit.md lines 654-656

**Credit recording:** Wired to VAPI/Tavus webhooks via idempotent `credit_recorded` flag on `vapi_call_logs` and `tavus_sessions` tables | REVERSE_SRS_old.md line 827; database-audit.md lines 41, 92-93

**Credit page UI:** Route `/credits` is commented out -- intentional business decision to defer | REVERSE_SRS_old.md line 733; client-audit.md line 158

**Service quotas:** Table exists (`service_quotas`) but NO enforcement logic found in routes | REVERSE_SRS_old.md line 736

### W3. Unified Inbox

**Service file:** `InboxService.ts` | server-audit.md line 608

**Tables:** `inbox_conversations` (channel, status, customer info, assigned_to, widget_visitor_id), `inbox_messages` (sender_type, sender_id, content, channel, metadata) | database-audit.md lines 114-115

**Routes:** 8 at `/api/inbox` (list threads, unread count, get thread, thread messages, send reply, assign, update status, mark read) | server-audit.md lines 332-344

**Widget-to-inbox wiring:** Widget chat messages create `inbox_conversation` and `inbox_message` records (fire-and-forget). Staff can see/respond in Work Center > Communication tab. | REVERSE_SRS_old.md lines 883-886

**Client components:** `InboxPanel.tsx` (Work Center communication tab), `UniversalInbox.tsx` (email inbox) | client-audit.md lines 343, 374

**Hook:** `useInbox` -- conversations, messages, unread count, send message, assign, update status, mark read | client-audit.md line 528

### W4. Super Admin Functionality

**Routes:** 14 endpoints at `/api/admin` -- all require Super Admin role | server-audit.md lines 123-141
- User CRUD (list, get, update, soft-delete)
- Organization CRUD (list, get, create, update, soft-delete with cascade)
- Partner link management (list, create, hard delete)
- Roles list, Locations list

**DealerBrain config:** 3 endpoints at `/api/dealerbrain` -- all Super Admin only | server-audit.md lines 242-249

**Additional Super Admin access:**
- POST /api/auth/register (create new user) | server-audit.md line 115
- POST /api/vin/refresh-tokens (refresh all VIN tokens) | server-audit.md line 518
- GET /api/vin/job-status | server-audit.md line 522
- GET /api/metrics/summary | server-audit.md line 411
- PUT /api/sms/config (update TextMagic config) | server-audit.md line 455
- POST /api/sms/test (test SMS) | server-audit.md line 460

**UI:** Settings page has Super Admin tabs: Users, Organizations, Partner Links, Tools, Hunches, Automa, SMS | client-audit.md line 91

**Client hook:** `useAdmin` -- users, orgs, partner links, roles, locations CRUD | client-audit.md line 514

### W5. Context Router

**Service files:** `contextRouter/ContextRouterService.ts`, `SourceSelector.ts`, `CacheManager.ts` | DO_NOT_TOUCH.md lines 141-143

**Architecture (REVERSE_SRS_old.md lines 964-990):**
```
DealerBrain / Dashboard / Insights
        |
        v
ContextRouterService
        |
        +-- SourceSelector (decides which source)
        |     |-- Priority 1: VIN Solutions API (live, authoritative)
        |     |-- Priority 2: Local Database (fallback)
        |     |-- Exclusion: excel_upload records filtered out
        |
        +-- CacheManager
        |     |-- VIN leads: 5-minute TTL
        |     |-- VIN reports: 1-hour TTL
        |     |-- VAPI/Tavus: 1-hour TTL
        |
        +-- Source Tagging (internal traceability, not displayed to users)
              |-- Tags: vin_api, local_db, vapi, tavus, manual, widget
```

**Configuration:** `CONTEXT_ROUTER_ENABLED=true` in `.env` (was `false` prior to 2026-02-16) | REVERSE_SRS_old.md line 992

**Truth hierarchy:** VIN Solutions API > VAPI/Tavus APIs > Local DB > Derived Metrics | CONSTITUTION.md lines 38-43

---

## Conflicts Found

| # | Topic | File A | File B | Detail |
|---|-------|--------|--------|--------|
| C1 | Frontend framework | ARCHITECTURE_VISUAL_MAP.md line 31: "Next.js 14 App Router" | client-audit.md line 49: "React 18", line 48: "Vite" | Visual map is aspirational. Actual codebase is Vite + React, NOT Next.js. |
| C2 | State management | ARCHITECTURE_VISUAL_MAP.md line 41: "Zustand + React Query" | client-audit.md lines 52-53: "TanStack Query" + "React Context API" | No Zustand in codebase. Uses React Context for client state. |
| C3 | Redis | ARCHITECTURE_VISUAL_MAP.md line 152: "Redis" for short-term memory (Tier 1) | REVERSE_SRS_old.md line 368: "native setInterval" | No Redis. All jobs use in-memory setInterval. |
| C4 | ClickHouse / OLAP | ARCHITECTURE_VISUAL_MAP.md lines 173-196: "ClickHouse", "Airbyte", "dbt", "Cube.js" | Entire REVERSE_SRS_old.md: only PostgreSQL mentioned | None of ClickHouse, Airbyte, dbt, or Cube.js are implemented. |
| C5 | MCP Gateway | ARCHITECTURE_VISUAL_MAP.md lines 119-141: "MCP Proxy Server (Port 3010)" | REVERSE_SRS_old.md (entire doc): no MCP proxy mentioned | No MCP proxy in codebase. Tools are called directly by DealerBrainService. Central-MCP exists at separate project (../central-mcp/) but not integrated. |
| C6 | VIN token refresh interval | VIN_SOLUTIONS_INTEGRATION.md line 37: "every 6 hours" | REVERSE_SRS_old.md line 359: "30 min" | REVERSE_SRS is the later forensic audit (2026-02-21). Likely reflects the current state. |
| C7 | Table count | CLAUDE.md (pre-enforcer, in preflight-input): "36 tables" | database-audit.md line 63: "53" | CLAUDE.md is outdated. 53 is correct per migration file analysis. |
| C8 | WebSocket usage | ARCHITECTURE_VISUAL_MAP.md line 59: "Monitor all activity streams (WebSocket)" | server-audit.md line 51: "no WebSocket in active use" | Socket.io installed but not used for production features. |
| C9 | Specialized agents (Daria, AutoDealer, ConvoAgent, InsightAgent) | ARCHITECTURE_VISUAL_MAP.md lines 49-112: full 4-tier agent hierarchy with named agents | REVERSE_SRS_old.md lines 644-655: only Automa (system), user-created agents | The named specialized agents (Daria, AutoDealer, ConvoAgent, InsightAgent) in the visual map do NOT exist in the codebase. DealerBrain/Automa is the only system agent. |
| C10 | Hosted pages route | REVERSE_SRS_old.md line 265: server route is `/api/pages/:slug` | session-knowledge.md (verified-findings reference): client fetches `/api/hosted-pages/public/${slug}` | Route mismatch -- confirmed P0 bug. |
| C11 | Endpoint count | server-audit.md line 34: "~185" | REVERSE_SRS_old.md line 245: "~237" | REVERSE_SRS was compiled from multiple audit sources and likely includes sub-endpoints. |

---

## Information Not Found

| # | Expected Detail | Looked In | Status |
|---|----------------|-----------|--------|
| NF1 | Full list of 33 environment variables | All input files | Only ~8 explicitly named. No `.env.example` exists (REVERSE_SRS_old.md line 1299). |
| NF2 | Server port allocation | All files | Default 5000 mentioned in server-audit.md line 46 but actual production port allocation not documented. |
| NF3 | Shared schema types (`shared/schema.ts`) content | All files | Described as "minimal (18 lines)" at REVERSE_SRS_old.md line 1151 but actual contents not provided. |
| NF4 | Widget Preact bundle configuration | All files | Build step mentioned (REVERSE_SRS_old.md line 1253) but no widget/vite.config.ts content visible. |
| NF5 | PM2 ecosystem.config.cjs | REVERSE_SRS_old.md line 1292 | "NOT PRESENT" -- no ecosystem config exists. |
| NF6 | DealerBrain AI model version (exact) | server-audit.md line 638 | "Configurable (defaults to claude-3-5-sonnet)" but specific version pinning not specified. |
| NF7 | Service quota enforcement logic | All route/service files | Table `service_quotas` exists but "no enforcement logic found in routes" (REVERSE_SRS_old.md line 736). |
| NF8 | SMS AI auto-reply implementation | All files | Schema field `ai_auto_reply_enabled` exists (database-audit.md line 106) but "logic not implemented" (REVERSE_SRS_old.md line 670). |
| NF9 | SMS collision avoidance state machine | All files | Table `sms_conversation_state` exists (database-audit.md line 129) but "state machine not implemented" (REVERSE_SRS_old.md line 680). |
| NF10 | Caddy reverse proxy configuration | All files | Mentioned as "managed by sysadmin project" (REVERSE_SRS_old.md line 1238). Configuration lives outside nexxus-v2. |

---

## Cross-Wave Notes

- [PRD-relevant: CONSTITUTION.md lines 9-28 contain platform identity narrative (what Nexxus is, partner model, industry-agnostic architecture)]
- [SRS-relevant: REVERSE_SRS_old.md lines 798-929 contain detailed data flow narratives (voice call -> lead creation, DealerBrain query, widget chat -> inbox, trigger execution, VIN OAuth lifecycle, Context Router)]
- [SRS-relevant: session-knowledge.md lines 8-48 contain owner's platform mental model (widgets = portals to agents, skills = agent overlays, V1->V2 transition)]
- [AC-relevant: REVERSE_SRS_old.md lines 122-128 contain 5 customer acceptance criteria with current status]
- [PLAN-relevant: REVERSE_SRS_old.md lines 1099-1157 contain prioritized known issues (5 CRITICAL, 10 HIGH, 15 MEDIUM, 8 LOW)]
- [PLAN-relevant: REVERSE_SRS_old.md lines 1174-1186 list 7 open feature gaps (GAP-1 through GAP-7)]
- [CLAUDE.md-relevant: REVERSE_SRS_old.md lines 1210-1225 list 10 document inconsistencies between CLAUDE.md and reality]

---

## Source File Log

| File | Lines Read | SPEC Relevance | Notes |
|------|-----------|---------------|-------|
| REVERSE_SRS_old.md | 1-1395 | **PRIMARY** | Forensic as-built audit. Most comprehensive single source. |
| server-audit.md | 1-780 | **HIGH** | Complete endpoint catalog, service inventory, middleware stack. |
| client-audit.md | 1-598 | **HIGH** | Pages, routes, components, hooks, state management. |
| database-audit.md | 1-200 | **HIGH** | Migration inventory, full table catalog, RLS policies. |
| health-audit.md | 1-200 | **HIGH** | Test inventory, code metrics, dependency health. |
| ARCHITECTURE_GUIDE.md | 1-full | **MEDIUM** | Layout system, sidebar, pane structure. Partially aspirational. |
| ARCHITECTURE_VISUAL_MAP.md | 1-600 | **MEDIUM** | 7-layer architecture. MOSTLY ASPIRATIONAL -- many layers not implemented. |
| DO_NOT_TOUCH.md | 1-200 | **HIGH** | Backend freeze manifest. Definitive file list for server layer. |
| CARRY_FORWARD_MANIFEST.md | 1-200 | **HIGH** | Frontend carry-forward inventory with PRESERVE/REFERENCE/REPLACEABLE verdicts. |
| VIN_SOLUTIONS_INTEGRATION.md | 1-200 | **MEDIUM** | Sprint 2 integration report. Contains PRODUCTION CREDENTIALS (lines 68-70). |
| DATA_SOURCE_INVENTORY.md | 1-200 | **HIGH** | Complete VIN API endpoint inventory with probe results. |
| UI_INTERACTIVE_ELEMENTS_MAP.md | 1-200 | **MEDIUM** | Element-to-handler mapping for key pages. |
| UNIFIED_HANDOFF_PROMPT.md | 1-200 | **MEDIUM** | Document reading order, existing infrastructure summary. |
| CONSTITUTION.md | 1-100 | **LOW** (for SPEC) | Truth hierarchy, RBAC roles, development rules. |
| IMPLEMENTATION_PLAN.md | 1-80 | **LOW** (for SPEC) | Phase plan (PLAN territory, not SPEC). |
| DEVELOPMENT_TEAM_BRIEFING.md | 1-150 | **MEDIUM** | Hard-won lessons about VIN API, RLS bug, Context Router. |
| THEME_CONTRACT.md | 1-100 | **LOW** | Design token system definition. |
| session-knowledge.md | 1-240 | **CONTEXT** | Owner's mental model, skills architecture, watch areas. |
| file-inventory.md | 1-145 | **CONTEXT** | File categorization and flags. |
| CLAUDE.md (pre-enforcer) | 1-full (system prompt) | **LOW** | Contains stale metrics. Many values outdated vs forensic audit. |
| Standards.md | (referenced) | -- | Not read directly; content captured via session-knowledge.md. |
| app_identity.md | (referenced) | -- | Not read directly; PRD content. |
