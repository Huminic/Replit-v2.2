# Wave 3 RECONCILED Output -- Architecture for SPEC

**Reconciled by:** Orchestrator (Claude Opus 4.6)
**Date:** 2026-03-03
**Inputs:** wave3-analyst.md (22 files examined, 200+ citations) + wave3-reviewer.md (all 53 files examined)
**Output for:** SPEC.md governance file

---

## Reconciliation Summary

Both agents produced highly congruent extractions across all 12 categories. The overlap is approximately 90%. Key differences are:

- **Coverage breadth:** REVIEWER examined all 53 input files; ANALYST examined 22 (prioritized by SPEC relevance). Both arrived at the same core architecture.
- **Citation granularity:** ANALYST provided more inline citations per table row. REVIEWER cited at section level and sometimes per row.
- **Structural additions:** REVIEWER added sections the ANALYST did not cover (route registration order, foreign key map, feature flags, theme contract, SMS unbuilt features). ANALYST added sections REVIEWER did not cover (HTTP client "native fetch wrapped in api.ts", exact client-audit line refs for hooks).
- **Conflicts found:** 11 by ANALYST (C1-C11), 6 by REVIEWER (CONFLICT 1-6). All are compatible -- REVIEWER grouped ANALYST's C1-C5 and C8-C9 into CONFLICT 1-3, then added the same C6-C7 and C10-C11 equivalents.
- **Missing info:** 10 items by ANALYST (NF1-NF10), 10 by REVIEWER (M1-M10). 7 overlap; 6 unique items total.
- **Disagreements requiring owner resolution:** 2 (see below).

---

## DISAGREEMENTS REQUIRING OWNER RESOLUTION

### DISAGREE-1: Node.js Version

- **ANALYST claim:** Node.js v20.19.5 (REVERSE_SRS_old.md line 1236)
- **REVIEWER claim:** "Node.js Runtime (version not explicitly stated in files)" (Section 7.1)
- **Evidence:** ANALYST cites REVERSE_SRS_old.md line 1236 directly. REVIEWER's Section 1.2 lists "Node.js | Runtime | server-audit.md line 45" without a version.
- **Recommendation:** Accept ANALYST's cite. REVERSE_SRS_old.md line 1236 explicitly states "v20.19.5." The REVIEWER appears to have missed this specific line reference in the deployment section while correctly noting "Runtime" in the backend stack section. Use **Node.js v20.19.5**.

### DISAGREE-2: Responsive Breakpoints

- **ANALYST claim:** Mobile (<1024px / `lg`): Sheet-based sidebar, bottom nav. Desktop (>=1024px): Icon sidebar w-16. Wide desktop (1280px+): Optional right pane w-80. (client-audit.md line 553)
- **REVIEWER claim:** Mobile (<768px): Single pane, sidebar overlay. Tablet (768-1024px): Sidebar + Center or toggle right. Desktop (>1024px): All panes visible. (Inferred from ARCHITECTURE_GUIDE.md)
- **Evidence:** ANALYST cites client-audit.md line 553 (forensic audit of actual code). REVIEWER appears to derive breakpoints from ARCHITECTURE_GUIDE.md (which may be aspirational).
- **Recommendation:** Use **ANALYST's breakpoints** (1024px boundary from actual code audit). Flag REVIEWER's 768px tablet breakpoint for live verification -- ARCHITECTURE_GUIDE.md may describe CSS rules that exist but are overridden.

---

## RECONCILED CATEGORIES

### 1. Technology Stack

#### 1.1 Frontend

Both agents agree on all items. Combined table with strongest citations:

| Technology | Version/Detail | Source |
|-----------|---------------|--------|
| Build tool | Vite | client-audit.md line 48 |
| Framework | React 18 | client-audit.md line 27 (REVIEWER), line 49 (ANALYST) |
| Language | TypeScript (strict mode) | client-audit.md line 50; REVERSE_SRS_old.md line 607 |
| Routing | Wouter (NOT React Router) | client-audit.md line 51-52 |
| Server state | TanStack Query (React Query) | client-audit.md line 52-53 |
| Client state | React Context API (4 providers) | client-audit.md line 53 (ANALYST), line 388 (REVIEWER) |
| UI library | shadcn/ui (47 Radix-based primitives) | client-audit.md line 54 (ANALYST), lines 209-262 (REVIEWER) |
| Styling | Tailwind CSS v4 (615 lines custom CSS) | REVERSE_SRS_old.md line 544 |
| Icons | lucide-react (60+ unique icons) | REVERSE_SRS_old.md line 546 |
| Calendar | FullCalendar | REVERSE_SRS_old.md line 547 |
| Rich text editor | Tiptap | REVERSE_SRS_old.md line 548 |
| Charts | Recharts (via shadcn chart component) | REVERSE_SRS_old.md line 549 |
| Onboarding | driver.js (9-step product tour) | REVERSE_SRS_old.md line 550 |
| Date utility | date-fns | client-audit.md line 61 |
| HTTP client | Native fetch (wrapped in `api.ts`) | client-audit.md line 62 [ANALYST addition] |
| Fonts | Inter (sans), Merriweather (serif), Fira Code (mono) | REVERSE_SRS_old.md line 551 |

**BOTH NOTE:** ARCHITECTURE_VISUAL_MAP.md line 31 claims "Next.js 14 App Router" -- this is WRONG. Actual codebase is Vite + React 18 + Wouter.

#### 1.2 Backend

Both agents agree on all items. Combined table with strongest citations:

| Technology | Version/Detail | Source |
|-----------|---------------|--------|
| Runtime | Node.js v20.19.5 | REVERSE_SRS_old.md line 1236 (see DISAGREE-1) |
| Framework | Express.js 5 (pre-release) | REVERSE_SRS_old.md line 239; server-audit.md line 45 |
| Language | TypeScript (strict mode, 325 `any` annotations) | REVERSE_SRS_old.md lines 607-608 |
| Database driver | pg (PostgreSQL Pool, max 10 connections) | REVERSE_SRS_old.md line 145 |
| Process manager | PM2 6.0.13 | REVERSE_SRS_old.md line 1237 |
| AI SDK | Anthropic Claude API (SDK) | REVERSE_SRS_old.md line 335 |
| Email (transactional) | Resend SDK | REVERSE_SRS_old.md line 333 |
| Email (IMAP/SMTP) | ImapFlow + Nodemailer | server-audit.md line 52-53 |
| File upload | Multer (in-memory, max 50MB) | server-audit.md line 52 |
| Encryption | AES-256-GCM via built-in crypto | REVERSE_SRS_old.md line 457; server-audit.md line 54 |
| Build tooling | esbuild (server), Vite (client + widget) | REVERSE_SRS_old.md lines 1250-1254 |
| TypeScript execution | tsx | REVERSE_SRS_old.md line 1315 |
| JWT | jsonwebtoken (24h access / 7d refresh) | REVERSE_SRS_old.md line 443 [REVIEWER addition] |
| bcrypt | 10 salt rounds | REVERSE_SRS_old.md line 1066 [REVIEWER addition] |
| Helmet | Security headers (CSP disabled for SPA) | REVERSE_SRS_old.md line 1062 [REVIEWER addition] |
| pdf-parse | PDF content extraction | server-audit.md line 222 [REVIEWER addition] |
| Puppeteer | PDF report generation | DO_NOT_TOUCH.md line 123 [REVIEWER addition] |

#### 1.3 External Services

[REVIEWER addition -- ANALYST covered these in Section 8 instead. Same data, different placement.]

| Service | Auth Method | Purpose | Source |
|---------|------------|---------|--------|
| VIN Solutions | OAuth2 Client Credentials (60-min tokens) | CRM: leads, contacts, dealers, users | REVERSE_SRS_old.md line 330 |
| VAPI | Shared secret (timing-safe) | Voice AI call data, transcripts | REVERSE_SRS_old.md line 331 |
| Tavus | HMAC-SHA256 + API key | Video AI sessions | REVERSE_SRS_old.md line 332 |
| Resend | API key (SDK) | Transactional email | REVERSE_SRS_old.md line 333 |
| TextMagic | Username + API key (REST v2) | SMS send/receive | REVERSE_SRS_old.md line 334 |
| Anthropic Claude | API key (SDK) | AI chat, tool calling, content gen | REVERSE_SRS_old.md line 335 |
| Google Calendar | OAuth2 (Authorization Code) | Calendar sync, appointment push | REVERSE_SRS_old.md line 336 |

#### 1.4 Database

Both agents agree:

| Technology | Detail | Source |
|-----------|--------|--------|
| Provider | Supabase (PostgreSQL) | REVERSE_SRS_old.md line 144 |
| Hosting | AWS us-west-2 | REVERSE_SRS_old.md line 144 |
| Connection | pg.Pool, max 10, prefers direct URL (port 5432) over pgbouncer (port 6543) | REVERSE_SRS_old.md line 145 |
| Tables | 53 | database-audit.md line 63 |
| Migrations | 33 (numbered 001-033, 011 missing) | database-audit.md line 11 |
| RLS policies | ~100 across all tables | REVERSE_SRS_old.md line 48 |
| Indexes | ~160 | REVERSE_SRS_old.md line 233 |
| Foreign keys | ~80 | REVERSE_SRS_old.md line 234 |
| JSONB columns | 58 (no DB-level schema validation) | REVERSE_SRS_old.md line 231 |

#### 1.5 Testing

Both agents agree:

| Technology | Detail | Source |
|-----------|--------|--------|
| E2E framework | Playwright ^1.58.1 | health-audit.md line 148 |
| Browser | Chromium (Desktop Chrome, 1280x720) | health-audit.md line 153 |
| E2E tests | 747 across 46 files | health-audit.md lines 38-39 |
| Unit tests | **None** (no Jest configuration) | health-audit.md line 44, 163 |
| Component tests | **None** | health-audit.md line 165 |
| ESLint | NOT configured | REVERSE_SRS_old.md line 612 [REVIEWER addition] |
| Prettier | NOT configured | REVERSE_SRS_old.md line 613 [REVIEWER addition] |
| CI/CD | NOT configured | REVERSE_SRS_old.md line 615 [REVIEWER addition] |

#### 1.6 Embeddable Widget

Both agents agree:

| Technology | Detail | Source |
|-----------|--------|--------|
| Framework | Preact (smaller bundle than React) | REVERSE_SRS_old.md line 1257 |
| Build | Vite (separate build target) | REVERSE_SRS_old.md line 1253 |
| Tracking pixel | IIFE bundle via esbuild, minified | REVERSE_SRS_old.md line 1254 |

#### 1.7 npm Dependencies

Both agents agree:

| Category | Count | Source |
|----------|-------|--------|
| Production | 91 | REVERSE_SRS_old.md line 54 |
| Development | 31 | REVERSE_SRS_old.md line 54 |
| Total | 122 | REVERSE_SRS_old.md line 54 |
| Known vulnerabilities | 7 (0 critical, 4 high, 2 moderate, 1 low) | REVERSE_SRS_old.md line 55 |

[REVIEWER addition] HIGH: `xlsx` (2 CVEs, no fix), `minimatch`, `glob`, `sucrase`. MODERATE: `lodash` (prototype pollution), `markdown-it` (ReDoS). (REVERSE_SRS_old.md lines 619-626)

---

### 2. Service Topology

#### 2.1 System Architecture Overview

Both agents agree on the architecture diagram. REVIEWER provided an ASCII diagram; ANALYST described it in prose. Using REVIEWER's explicit diagram:

```
Internet -> Caddy (reverse proxy, SSL) -> https://nexxusv2.huminicdev.com
  |
  +--> Static Assets (dist/public/) -> Vite SPA (React)
  +--> API Requests (/api/*) -> Express.js 5 Server
         |
         +--> Direct Pool (pg, max 10)
         +--> RLS Policies (~100)
         +--> Background Jobs (setInterval)
         |
         v
       Supabase PostgreSQL (aws-0-us-west-2)
         53 tables | ~160 indexes | 2 functions | 12+ triggers | ~80 FKs | 58 JSONB columns
```

#### 2.2 Server Entry Points

[REVIEWER addition -- not in ANALYST's extraction]

Source: DO_NOT_TOUCH.md lines 37-46

| File | Purpose |
|------|---------|
| `server/index.ts` | Main entry point. Express app, HTTP server, Helmet, body parsers, global error handlers. PM2 runs compiled `dist/index.cjs`. |
| `server/routes.ts` | Route registry. Imports and mounts 35+ route modules, webhook routers, background jobs. Registration order matters. |
| `server/storage.ts` | Storage interface and in-memory implementation. |
| `server/static.ts` | Serves `dist/public/` in production. Fallback 503 if build missing. |
| `server/vite.ts` | Vite dev server middleware for HMR. |

#### 2.3 Middleware Chain

Both agents agree. ANALYST provided more granular ordering:

**Applied in order (per server-audit.md lines 667-753):**

1. **Helmet** -- Security headers (CSP disabled for SPA) | `server/index.ts`
2. **express.json** -- JSON body parser with rawBody capture | `server/index.ts`
3. **express.urlencoded** -- URL-encoded body parser | `server/index.ts`
4. **API Logging** -- Request/response logging with sensitive field redaction (keys matching `/token|secret|password/i`) | `server/index.ts`
5. **authenticate** -- JWT validation, attaches `req.user` and `req.rlsVariables` | `server/auth/middleware.ts`
6. **enforceOrganizationContext** -- Creates SecureQueryBuilder with RLS context from JWT | `server/middleware/enforceOrganizationContext.ts`
7. **validateResourceOwnership** -- Validates resource belongs to requesting org | `server/middleware/validateResourceOwnership.ts`

[REVIEWER addition] `jwt.ts` (`server/auth/jwt.ts`) -- Token signing, verification, expiry config (separate from middleware)

**Role-level middleware functions (server-audit.md lines 694-700):**
- `requireSuperAdmin` -- role level === 1
- `requirePartnerAdminOrHigher` -- role level <= 2
- `requireOrgAdminOrHigher` -- role level <= 3
- `requireRoleLevel(minLevel)` -- role level <= minLevel

#### 2.4 Route Registration Order

[REVIEWER addition -- ANALYST listed routes in a table but did not specify registration order]

Source: server-audit.md lines 62-101. Order matters for Express path matching.

```
 1. /api/webhooks/vapi       (before body parsers)
 2. /api/webhooks/tavus      (raw body capture for HMAC)
 3. /api/auth
 4. /api/vin
 5. /api/integrations
 6. /api/insights
 7. /api/agents
 8. /api/credits
 9. /api/tasks
10. /api/appointments
11. /api/conversations
12. /api/admin
13. /api/admin/knowledge
14. /api/settings
15. /api/email
16. /api/user/integrations
17. /api/dealerbrain
18. /api/notifications
19. /api/sms
20. /api/widgets/public      (before /api/widgets)
21. /api/widgets
22. /api/inbox
23. /api/tracking
24. /api/triggers
25. /api/activity
26. /api/goals
27. /api/reports
28. /api/drive
29. /api/hunches
30. /api/approvals
31. /api/leads
32. /api/dashboard
33. /api/metrics
34. /api (google-calendar)
35. /api/hosted-pages
36. /api/pages              (hosted pages public)
37. /api/health
```

#### 2.5 Service Inventory (40 modules)

Both agents agree on the service list. Combined from ANALYST (with dependency details) and REVIEWER (with purpose descriptions):

**Top-Level Services (36):**

| Service | File | Lines | Dependencies / Purpose | Source |
|---------|------|-------|----------------------|--------|
| DealerBrainService | `DealerBrainService.ts` | 3,047 | Claude API with tool calling (non-streaming). LARGEST FILE. | REVERSE_SRS_old.md line 299 |
| DealerBrainStreamingService | `DealerBrainStreamingService.ts` | 2,020 | Claude API SSE streaming | REVERSE_SRS_old.md line 300 |
| VinSolutionsService | `vinSolutionsService.ts` | 1,134 | VIN CRM API client (OAuth2), encryption utils | REVERSE_SRS_old.md line 301 |
| TriggerService | `TriggerService.ts` | 1,413 | Event-driven automation engine. Deps: VAPI API, TextMagicService, NotificationService, TaskService | REVERSE_SRS_old.md line 302 |
| AppointmentService | `AppointmentService.ts` | 1,248 | Calendar CRUD with RBAC. Deps: GoogleCalendarService, AppointmentConfirmationService | REVERSE_SRS_old.md line 303 |
| TextMagicService | `TextMagicService.ts` | 1,130 | SMS send/receive (REST v2) | REVERSE_SRS_old.md line 304 |
| CreditService | `CreditService.ts` | -- | Usage tracking, billing. Local DB (credit_policies, allocations, usage) | REVERSE_SRS_old.md line 305 |
| WidgetConfigService | `WidgetConfigService.ts` | -- | Widget CRUD | REVERSE_SRS_old.md line 306 |
| WidgetInteractionService | `WidgetInteractionService.ts` | -- | Widget chat, callbacks, SMS, video. Deps: WidgetAgentService, InboxService, TriggerService | REVERSE_SRS_old.md line 307 |
| WidgetAgentService | `WidgetAgentService.ts` | -- | Widget AI chat (Claude API) | REVERSE_SRS_old.md line 308 |
| InboxService | `InboxService.ts` | -- | Unified messaging inbox | REVERSE_SRS_old.md line 309 |
| DealerPulseService | `DealerPulseService.ts` | -- | 5-phase health snapshots. Deps: Claude Haiku, VinSolutionsService | REVERSE_SRS_old.md line 310 |
| EmailService | `EmailService.ts` | -- | IMAP/SMTP operations | REVERSE_SRS_old.md line 311 |
| GoogleCalendarService | `GoogleCalendarService.ts` | -- | Google Calendar API (OAuth2) | REVERSE_SRS_old.md line 312 |
| NotificationService | `NotificationService.ts` | -- | In-app notifications. Deps: Resend (email), local DB | REVERSE_SRS_old.md line 313 |
| KnowledgeUploadService | `KnowledgeUploadService.ts` | -- | CSV/XLSX import | REVERSE_SRS_old.md line 314 |
| GoalsService | `GoalsService.ts` | -- | Goal tracking | REVERSE_SRS_old.md line 315 |
| HunchesService | `HunchesService.ts` | -- | AI-generated insights (Claude API) | REVERSE_SRS_old.md line 316 |
| DriveService | `DriveService.ts` | -- | File/folder management (local filesystem + DB, 1GB quota) | REVERSE_SRS_old.md line 317 |
| MetricsEngine | `MetricsEngine.ts` | -- | Certified metrics registry, role-based filtering | REVERSE_SRS_old.md line 318 |
| AccessibleOrganizationsService | `AccessibleOrganizationsService.ts` | -- | Resolves user->org access by RBAC | server-audit.md line 588 |
| ActivityService | `ActivityService.ts` | -- | Activity feed (ai_usage_events) | server-audit.md line 589 |
| AgentService | `AgentService.ts` | -- | VAPI + Tavus agent CRUD, metadata tagging | server-audit.md line 590 |
| ApprovalService | `ApprovalService.ts` | -- | Approval workflow state machine | server-audit.md line 594 |
| ConversationService | `ConversationService.ts` | -- | DealerBrain conversation persistence | server-audit.md line 595 |
| DashboardService | `DashboardService.ts` | -- | Dashboard data aggregation (multiple services) | server-audit.md line 597 |
| FeedbackService | `FeedbackService.ts` | -- | User feedback collection | server-audit.md line 603 |
| HostedPageService | `HostedPageService.ts` | -- | Hosted widget page rendering | server-audit.md line 606 |
| PasswordResetService | `PasswordResetService.ts` | -- | Token gen/validation. Deps: Resend (email) | server-audit.md line 612 |
| PdfReportService | `PdfReportService.ts` | -- | Puppeteer PDF generation | server-audit.md line 613 |
| ReportService | `ReportService.ts` | -- | Report data aggregation | server-audit.md line 614 |
| TaskService | `TaskService.ts` | -- | Task management | server-audit.md line 615 |
| TrackingService | `TrackingService.ts` | -- | Tracking pixel events | server-audit.md line 617 |
| VinOAuthService | `vinOAuthService.ts` | 156 | OAuth2 token management | server-audit.md line 619 |
| AppointmentConfirmationService | `appointmentConfirmationService.ts` | -- | Confirmation email/SMS. Deps: Resend, TextMagicService | server-audit.md line 592 |
| AppointmentExtractionService | `appointmentExtractionService.ts` | -- | AI extraction from transcripts (Claude API) | server-audit.md line 593 |

**Sub-Service Modules (4 directories, 5 including leads/):**

| Directory | Files | Purpose | Source |
|-----------|-------|---------|--------|
| `contextRouter/` | ContextRouterService.ts, SourceSelector.ts, CacheManager.ts, index.ts | Unified data query orchestration (VIN API primary, local DB fallback) | REVERSE_SRS_old.md lines 964-990; DO_NOT_TOUCH.md lines 141-144 |
| `sync/` | SyncCoordinator.ts, LeadMapper.ts, index.ts | VIN bidirectional lead sync (sync_queue processing) | DO_NOT_TOUCH.md lines 152-154 |
| `notifications/` | notificationEmailService.ts | Resend email dispatch for call events | DO_NOT_TOUCH.md line 155 |
| `insights/` | VoiceInsightService.ts, VideoInsightService.ts, LeadInsightService.ts, index.ts | Voice/video/lead analytics | DO_NOT_TOUCH.md lines 145-148 |
| `leads/` | LeadCreationService.ts, LeadExtractionService.ts, index.ts | Lead creation (VIN 2-step), AI extraction from transcripts | DO_NOT_TOUCH.md lines 149-151 |

#### 2.6 Scheduled Jobs (8)

Both agents agree:

| Job | Interval | Singleton Guard | Startup Delay | Source |
|-----|----------|----------------|---------------|--------|
| VIN Token Refresh | 30 min | `isRunning` flag | 0s | REVERSE_SRS_old.md line 359 |
| Sync Queue Worker | 1 min (outbound), 4 hrs (inbound) | `isRunning` flag | staggered | REVERSE_SRS_old.md line 360 |
| Appointment Reminder | 5 min | `isRunning` flag | staggered | REVERSE_SRS_old.md line 361 |
| Email Sync | 5 min (up to 50 integrations/run) | `isRunning` flag | staggered | REVERSE_SRS_old.md line 362 |
| VIN Lead Polling | 60 min | `isRunning` flag | staggered | REVERSE_SRS_old.md line 363 |
| Trigger Re-evaluation | 5 min | `isRunning` flag | staggered | REVERSE_SRS_old.md line 364 |
| Dealer Pulse | 4 hrs | `isRunning` flag | staggered | REVERSE_SRS_old.md line 365 |
| Hunch Generation | 6 hrs | `isRunning` flag | staggered | REVERSE_SRS_old.md line 366 |

All jobs use native `setInterval` (no Redis, no Bull). Staggered startup delays (0-90s) prevent thundering herd. (REVERSE_SRS_old.md line 368)

#### 2.7 Webhook Handlers

Both agents agree:

| Webhook | Endpoint | Events | Org Resolution | Security |
|---------|----------|--------|---------------|----------|
| VAPI | `/api/webhooks/vapi` | call.started, call.ended, end-of-call-report, transcript, status-update | `metadata.organizationId` or `assistantId` lookup | Optional shared secret (timing-safe); accepts without verification if header absent |
| Tavus | `/api/webhooks/tavus` | conversation.started, conversation.ended, replica.ready, video.ready | `custom_data.organization_id` or `persona_id` lookup | HMAC-SHA256 with 5-min timestamp tolerance |
| TextMagic | `/api/sms/webhook/inbound` | Inbound SMS | Via org-scoped textmagic_config | No verification (TextMagic does not sign) |

Idempotency: `notification_sent` and `credit_recorded` columns with atomic `UPDATE...WHERE...RETURNING` pattern (REVERSE_SRS_old.md line 343).

[ANALYST addition] VAPI processing chain: Call log -> lead extraction -> sync_queue -> credit recording -> email notification -> in-app notification -> appointment extraction (REVERSE_SRS_old.md lines 800-832)

---

### 3. Database Schema

#### 3.1 Table Groups (53 tables across 33 migrations)

Both agents agree on all 53 tables. ANALYST organized by group; REVIEWER provided a complete per-table enumeration with key columns and migration numbers. Using ANALYST's group summary plus REVIEWER's detail:

| Group | Tables | Count |
|-------|--------|-------|
| Core Identity | organizations, locations, roles, users, partner_admin_organizations | 5 |
| Integrations | integrations, user_integrations | 2 |
| AI Agents | agents, skills, agent_runs | 3 |
| Conversations | conversations, messages | 2 |
| Leads & CRM | leads, sync_queue, vin_reports_cache | 3 |
| Voice/Video | vapi_call_logs, tavus_sessions | 2 |
| Communication | textmagic_config, textmagic_messages, textmagic_opt_outs, sms_conversation_state, cached_emails, sent_emails, email_templates | 7 |
| Work Center | tasks, appointments, availability_blocks, appointment_reminders, inbox_conversations, inbox_messages | 6 |
| Insights & Analytics | dashboards, widgets, goals, insight_card_config, insight_card_state, dealer_pulse_cache, report_benchmarks | 7 |
| Widget System | widget_configs, widget_callback_requests, widget_visitors, widget_chat_messages, hosted_pages | 5 |
| Governance & Tracking | ai_usage_events, trigger_rules, trigger_executions, trigger_templates, tracking_events, audit_log | 6 |
| Business | credit_policies, credit_allocations, credit_usage, service_quotas | 4 |
| Drive & Artifacts | drive_folders, drive_files, artifacts, knowledge_uploads | 4 |
| Workflow | hunches, approval_requests | 2 |
| Auth | password_reset_tokens | 1 |
| Notifications | notification_settings, notifications | 2 |
| Config | dealerbrain_config, vin_api_calls | 2 |

[REVIEWER addition] Full per-table detail with key columns, migration numbers, and ALTER TABLE additions from migrations 020-032 -- see REVIEWER Section 3.2 for complete enumeration.

#### 3.2 RLS Architecture

Both agents agree on the critical findings:

**Pattern distribution (database-audit.md lines 140-183):**

| Pattern | Description | Table Count |
|---------|-------------|-------------|
| A: `app.current_org_id` | Organization isolation (most common) | 43 |
| B: `app.current_user_id` | User-self-access (personal data) | 7 |
| C: `app.user_role_level = 1` | Super Admin bypass | 16 |
| D: `TO service_role` | Background job/webhook bypass | 17 |
| E: Role-tiered | Org Admin+ manages, Staff reads | 5 |
| F: Open read | Authenticated read for all | 2 (roles, skills) |
| G: Special/anomalous | `app.current_role` (never set), `password_reset_tokens` open | 4 |

**CRITICAL BUG (Both agents, identical finding):** SecureQueryBuilder sets `app.current_organization_id` but all RLS policies check `app.current_org_id`. These are different variable names. System works because most routes bypass SecureQueryBuilder and use `set_config('app.current_org_id', ...)` directly. (REVERSE_SRS_old.md lines 203-216; database-audit.md lines 190-200)

**Additional RLS anomalies (both agents):**
- `app.current_role_level` set in triggers.ts line 38, should be `app.user_role_level`
- `app.current_role` checked in dealer_pulse_cache and knowledge_uploads policies but never set by application code
- `SET LOCAL` used without transaction wrapper in SecureQueryBuilder, risking cross-tenant leakage on pooled connections

[REVIEWER addition] 1 table with NO RLS: report_benchmarks (public reference data, intentional)

#### 3.3 Migration Anomalies

Both agents agree:
- Migration 011 is **missing** (gap between 010 and 012) | database-audit.md line 28
- Two files share the `004` prefix (numbering collision) | database-audit.md line 57
- 16+ tables have `updated_at` columns but no automatic trigger | REVERSE_SRS_old.md line 232

#### 3.4 Database Functions and Triggers

Both agents agree:
- `update_updated_at_column()` function created in migration 003 (database-audit.md line 19)
- 4 triggers created with migration 003 for auto-updating `updated_at`
- `create_default_notification_settings()` trigger function in migration 008 (database-audit.md line 25)
- 12 tables have `updated_at` triggers; 16+ do not (inconsistency)

#### 3.5 Key Table Structures

Both agents agree on JSONB-heavy tables:
- `organizations`: settings, billing_info
- `locations`: address, business_hours, contact_info, settings
- `agents`: config, performance_metrics
- `conversations`: customer_info, metadata
- `widget_configs`: config_appearance, config_channels, config_targeting, allowed_domains, chat_enabled_tools

Total JSONB columns: 58 (no CHECK constraints or JSON Schema validation at DB level)

#### 3.6 Foreign Key Map

[REVIEWER addition]

Source: database-audit.md lines 319-399

- **Total FK relationships:** ~80
- **Cascade patterns:** Most org-linked tables cascade on delete
- **Missing FKs:** `textmagic_messages.linked_lead_id` and `linked_appointment_id` (database-audit.md line 235)
- **Deferred FKs:** `leads.vapi_call_id`, `leads.tavus_session_id`, `vapi_call_logs.lead_id`, `tavus_sessions.lead_id` (circular refs)

---

### 4. API Endpoint Inventory

#### 4.1 Summary

Both agents agree:
- **Total endpoints:** ~237 (REVERSE_SRS_old.md line 245)
- **Route files:** 34 (server-audit.md line 33)
- **Registration file:** `server/routes.ts` (server-audit.md line 62)

#### 4.2 Complete Route Group Table

Both agents provide the same routes. ANALYST includes endpoint counts and auth level per source line; REVIEWER adds file name column. Combined:

| Route Prefix | File | Endpoints | Auth Level | Source |
|-------------|------|-----------|------------|--------|
| `/api/webhooks/vapi` | vapi.ts | 1 (multi-event) | Public (optional secret) | server-audit.md line 65 |
| `/api/webhooks/tavus` | tavus.ts | 1 (multi-event) | Public (HMAC verified) | server-audit.md line 66 |
| `/api/auth` | auth.ts | 9 | Mixed (public + JWT) | server-audit.md lines 106-119 |
| `/api/vin` | vin.ts | 10 | Mixed (Any + Super Admin + Org Admin+) | server-audit.md lines 508-523 |
| `/api/integrations` | integrations.ts | 6 | Mixed (Any + Org Admin+) | server-audit.md lines 367-378 |
| `/api/insights` | insights.ts | 15 | Mixed (Any + Org Admin+) | server-audit.md lines 346-365 |
| `/api/agents` | agents.ts | 9 | Mixed (Any + Org Admin+) | server-audit.md lines 145-159 |
| `/api/credits` | credits.ts | 5 | Mixed (Any + Org Admin+) | server-audit.md lines 224-233 |
| `/api/tasks` | tasks.ts | 9 | Any | server-audit.md lines 464-477 |
| `/api/appointments` | appointments.ts | 10 | Mixed (Any + Org Admin+ + public confirm) | server-audit.md lines 162-177 |
| `/api/conversations` | conversations.ts | 11 | Any (file upload 50MB) | server-audit.md lines 205-221 |
| `/api/admin` | admin.ts | 14 | Super Admin | server-audit.md lines 123-141 |
| `/api/admin/knowledge` | knowledge.ts | 4 | Org Admin+ | server-audit.md lines 381-389 |
| `/api/settings` | settings.ts | 4 | Org Admin+ | server-audit.md lines 439-447 |
| `/api/email` | email.ts | 7 | Any | server-audit.md lines 265-276 |
| `/api/user/integrations` | userIntegrations.ts | 7 | Any | server-audit.md lines 557-568 |
| `/api/dealerbrain` | dealerbrain.ts | 3 | Super Admin | server-audit.md lines 242-249 |
| `/api/notifications` | notifications.ts | 8 | Any | server-audit.md lines 414-426 |
| `/api/sms` | sms.ts | 7 | Mixed (public webhook + Any + Admin) | server-audit.md lines 449-461 |
| `/api/widgets/public` | widget-public.ts | 8 | Public (rate limited 100/hr/IP) | server-audit.md lines 541-554 |
| `/api/widgets` | widgets.ts | 9 | Mixed (Any + Org Admin+) | server-audit.md lines 526-539 |
| `/api/inbox` | inbox.ts | 8 | Mixed (Any + Org Admin+) | server-audit.md lines 332-344 |
| `/api/tracking` | tracking.ts | 6 | Mixed (public + Org Admin+) | server-audit.md lines 479-489 |
| `/api/triggers` | triggers.ts | 10 | Mixed (Any + Org Admin+) | server-audit.md lines 493-507 |
| `/api/activity` | activity.ts | 6 | Mixed (Any + Org Admin+) | server-audit.md lines 192-201 |
| `/api/goals` | goals.ts | 7 | Mixed (Any + Org Admin+) | server-audit.md lines 278-289 |
| `/api/reports` | reports.ts | 5 | Mixed (Any + Org Admin+) | server-audit.md lines 428-437 |
| `/api/drive` | drive.ts | 8 | Any | server-audit.md lines 251-263 |
| `/api/hunches` | hunches.ts | 4 | Any | server-audit.md lines 322-330 |
| `/api/approvals` | approvals.ts | 5 | Any | server-audit.md lines 180-189 |
| `/api/leads` | leads.ts | 6 | Any | server-audit.md lines 391-401 |
| `/api/dashboard` | dashboard.ts | 1 | Any | server-audit.md lines 235-240 |
| `/api/metrics` | metrics.ts | 3 | Mixed (Any + Super Admin) | server-audit.md lines 405-412 |
| `/api` (google-calendar) | google-calendar.ts | 7 | Mixed (Any + public callback) | server-audit.md lines 291-302 |
| `/api/hosted-pages` | hosted-pages.ts | 5 | Mixed (Any + Org Admin+) | server-audit.md lines 304-313 |
| `/api/pages` | hosted-pages-public.ts | 1 | Public | server-audit.md lines 315-320 |
| `/api/health` | inline | 1 | Public | server-audit.md line 576 |

#### 4.3 Auth Distribution

Both agents agree:

| Auth Level | Endpoint Count | Source |
|-----------|---------------|--------|
| Public (no auth) | ~15 | REVERSE_SRS_old.md line 290 |
| Any authenticated user | ~110 | REVERSE_SRS_old.md line 291 |
| Org Admin+ (role level <= 3) | ~40 | REVERSE_SRS_old.md line 292 |
| Super Admin only (role level = 1) | ~20 | REVERSE_SRS_old.md line 293 |

#### 4.4 Rate Limiting

Both agents agree:

| Route | Limit | Window | Scope | Source |
|-------|-------|--------|-------|--------|
| POST /api/auth/login | 30 | 1 minute | Per IP | REVERSE_SRS_old.md line 407 |
| POST /api/auth/register | 5 | 1 hour | Per IP | REVERSE_SRS_old.md line 408 |
| POST /api/auth/forgot-password | 3 | 1 hour | Per IP | REVERSE_SRS_old.md line 409 |
| /api/widgets/public/* | 100 | 1 hour | Per IP | REVERSE_SRS_old.md line 410 |
| POST /api/insights/dealer-pulse/refresh | 1 | 15 minutes | Per org | REVERSE_SRS_old.md line 411 |

No global rate limiting applied. (REVERSE_SRS_old.md line 413)

#### 4.5 Hosted Pages Route Mismatch (Known P0)

Both agents flag this:
- Client fetches: `/api/hosted-pages/public/${slug}`
- Server serves: `/api/pages/:slug`
- One-line fix needed in either client or server route.
- Source: session-knowledge.md (verified-findings); ANALYST C10; REVIEWER Section 4.4

---

### 5. Frontend Architecture

#### 5.1 Pages and Routes

Both agents agree on page count and routes. Combined table:

- **Total pages:** 21 (17 main + 4 hosted/public) | client-audit.md line 34
- **Active routes:** 17 protected + 4 public + 1 catch-all | client-audit.md line 35
- **Commented-out routes (2):** `/credits`, `/profile/billing` -- PHASE-FUTURE | client-audit.md lines 154-159

| Route | Component | Purpose |
|-------|-----------|---------|
| `/` | DashboardPage | Command Center: health scores, lead feed, goals |
| `/chat` | MainPage | DealerBrain AI chat with SSE streaming |
| `/agents` | AgentsPage | Three-column agent management with embedded chat |
| `/agents/create` | AgentCreatePage | Multi-step creation wizard |
| `/agents/:id/edit` | AgentEditPage | Agent config editor |
| `/insights` | InsightsPage | 6-tab: Dashboard, Goals, Reports, Attribution, Hunches, Dealer Pulse |
| `/leads` | InsightsPage | Alias to Insights (same component) |
| `/work-center` | WorkCenterPage | 5-tab: Calendar, Tasks, Approvals, Communication, Open Leads |
| `/drive` | DrivePage | File management grid/list view |
| `/activity` | ActivityPage | AI Governance: usage, artifacts, CSV export |
| `/settings/system` | SettingsPage | 16+ role-gated tabs |
| `/profile` | ProfilePage | Profile editing, preferences, Google Calendar |
| `/notifications` | NotificationsPage | History, filtering, settings |
| `/w/:slug` | HostedPage | Public widget pages (chat, video, callback, multi) |
| `/login` | LoginPage | Glass-effect login with 9 randomized wallpapers |
| `/forgot-password` | ForgotPasswordPage | Password reset request |
| `/reset-password` | ResetPasswordPage | Password reset with token |
| `*` | NotFound | 404 catch-all |

**Route protection:** `ProtectedRoute` component wraps `AppLayout` wrapping `PageComponent`. No route-level RBAC; role restrictions applied at component/tab level. (client-audit.md lines 167-173)

#### 5.2 Layout System

Both agents agree on 3-pane grid layout:

```css
.app-layout {
  grid-template-columns: [sidebar] 64px [left-pane] 240px [center-pane] 1fr [right-pane] 320px;
  height: 100vh;
}
```

| Pane | Width | Purpose | Source |
|------|-------|---------|--------|
| Vertical Sidebar | 64px fixed (collapsible to w-10/40px) | Main navigation | ARCHITECTURE_GUIDE.md line 28; client-audit.md line 271 |
| Left Pane / SubMenu | 240-400px resizable (w-64 in code) | Contextual popout menus | ARCHITECTURE_GUIDE.md line 29; client-audit.md line 273 |
| Center Pane | flexible, min 600px | Primary content | ARCHITECTURE_GUIDE.md line 30 |
| Right Pane | 320-500px resizable (w-80 in code) | Automa chat or contextual tools | ARCHITECTURE_GUIDE.md line 31; client-audit.md line 275 |

**ViewConfig system (client-audit.md line 269):** AppLayout supports view modes: `chat-only`, `data-display`, `sub-menu`, `heavy-chat`

**Responsive breakpoints:** See DISAGREE-2 above. Use ANALYST's from client-audit.md line 553 pending verification:
- Mobile (<1024px / `lg`): Sheet-based sidebar, bottom nav
- Desktop (>=1024px): Icon sidebar w-16
- Wide desktop (1280px+): Optional right pane w-80

#### 5.3 State Management

Both agents agree:

**Dual-layer architecture (REVERSE_SRS_old.md lines 530-533):**
1. **Server state:** TanStack Query -- 38 `useQuery` calls, 34 `useMutation` calls across 26 custom hooks
2. **Client state:** 4 React Context providers

**Provider hierarchy (client-audit.md lines 392-402):**
```
QueryClientProvider > TooltipProvider > ThemeProvider > AuthProvider > AppProvider > ChatProvider > <Router /> > <FloatingChat /> > <ProductTour /> > <Toaster />
```

**Context Providers:**
- **AuthContext** (`contexts/AuthContext.tsx`): JWT login/logout/refresh, token storage, user state, org switching, auto-refresh timer | client-audit.md lines 405-428
- **AppContext** (`contexts/AppContext.tsx`): Derives currentUser/currentOrganization, sidebar/panel states, favorites | client-audit.md lines 431-454
- **ChatContext** (`contexts/ChatContext.tsx`): Floating chat panel open/close/minimize, active conversation | client-audit.md lines 457-469
- **ThemeContext** (`contexts/ThemeContext.tsx`): Light/dark toggle, localStorage persistence (`nexxus:theme`), system preference detection | client-audit.md lines 471-485

**TanStack Query defaults (client-audit.md lines 487-498):**
- `staleTime: Infinity` (data never auto-stales)
- `refetchOnWindowFocus: false`
- `retry: false`
- Cache invalidation on org switch (invalidates ALL)

[REVIEWER addition] Token storage: localStorage keys: `nexxus_access_token`, `nexxus_refresh_token`, `nexxus_token_expiry`, `nexxus_accessible_orgs`. Auto-refresh every 60s, refreshes when < 5 min to expiry. (CARRY_FORWARD_MANIFEST.md lines 39-47)

#### 5.4 Custom Hooks (26)

Both agents agree. Full inventory at client-audit.md lines 507-538. Key architectural hooks:

| Hook | Queries | Mutations | Source |
|------|---------|-----------|--------|
| `useStreamingMessage` | 0 | 0 | SSE streaming for AI chat (client-audit.md line 535) |
| `useAgents` | 3 | 4 | Agent CRUD (client-audit.md line 515) |
| `useInsights` | 3 | 0 | Dashboard cards (client-audit.md line 529) |
| `useConversations` | 3 | 2 | DealerBrain chat (client-audit.md line 518) |
| `useAdmin` | 2+ | 3+ | Super Admin user/org management (client-audit.md line 514) |

[REVIEWER addition] Full PRESERVE verdict list: useLeads, useAgents, useInsights, useConversations, useAdmin, useEmail, useAppointments, useTasks, useNotifications, useCredits, useInbox, useGoals, useReports, useGoogleCalendar, useDrive, useHunches, useApprovals, useActivity, useMetrics, useTracking, useDealerPulse, useProfile, useDealerBrainConfig, useStreamingMessage (CARRY_FORWARD_MANIFEST.md lines 57-88)

#### 5.5 SSE Streaming Protocol

Both agents agree:

| Aspect | Detail | Source |
|--------|--------|--------|
| Endpoint | `POST /api/conversations/:id/stream` | CARRY_FORWARD_MANIFEST.md lines 107-108 |
| Auth | `Authorization: Bearer {token}` header | CARRY_FORWARD_MANIFEST.md line 109 |
| Body | `{ content: string }` | CARRY_FORWARD_MANIFEST.md line 110 |
| Event types | `thinking`, `tool_start`, `tool_end`, `token`, `done`, `error` | CARRY_FORWARD_MANIFEST.md lines 112-117 |
| Client hook | `useStreamingMessage.ts` | CARRY_FORWARD_MANIFEST.md line 103 |
| Also used | Widget public chat SSE at `POST /api/widgets/public/chat/stream` | server-audit.md line 548 |

#### 5.6 API Client Layer

[REVIEWER addition]

| File | Purpose | Verdict |
|------|---------|---------|
| `client/src/lib/api.ts` | Authenticated fetch wrapper (`fetchApi`, `apiGet`, `apiPost`, `apiPut`, `apiPatch`, `apiDelete`). JWT from localStorage. | PRESERVE |
| `client/src/lib/queryClient.ts` | TanStack Query client singleton, `getQueryFn`, `apiRequest` helper. | PRESERVE |

#### 5.7 Component Inventory

Both agents agree on counts:

| Category | Count | Source |
|----------|-------|--------|
| shadcn/ui primitives (Radix-based) | 47 | client-audit.md lines 209-261 |
| Layout components | 8 | client-audit.md lines 265-276 |
| Chat components | 6 | client-audit.md lines 278-287 |
| Modal components | 8 (+1 VideoPlayerModal) | client-audit.md lines 289-301 |
| Report components | 8 | client-audit.md lines 303-314 |
| Settings tab components | 8 | client-audit.md lines 316-327 |
| Insights components | 5 | client-audit.md lines 329-337 |
| Communication components | 3 | client-audit.md lines 339-345 |
| Calendar components | 2 | client-audit.md lines 347-352 |
| Admin components | 2 | client-audit.md lines 354-359 |
| Notification components | 3 | client-audit.md lines 361-367 |
| Other (auth, inbox, SMS, onboarding) | 4 | client-audit.md lines 369-377 |
| **Total** | **~106** (59 custom + 47 shadcn) | REVERSE_SRS_old.md line 526 |

[REVIEWER addition] Layout components detail:
- AppLayout -- main wrapper with ViewConfig
- TopBar -- header (h-14) with logo, org switcher, notifications, theme toggle
- Sidebar -- desktop icon sidebar (w-16, collapsible to w-10), purple active indicator
- MobileSidebar -- Sheet-based nav with labels
- SubMenuManager -- dynamic panel (w-64) for contextual nav
- SubMenuPanel -- reusable panel wrapper
- RightPane -- quick-chat pane (w-80), dual mode (inline or Sheet), DealerBrain streaming
- FavoritesBar -- bookmark bar with star toggle

#### 5.8 UI Framework

[REVIEWER addition]

| Feature | Implementation | Source |
|---------|---------------|--------|
| CSS | Tailwind CSS v4, 615 lines custom CSS | REVERSE_SRS_old.md line 544 |
| Theme | Light/dark via CSS class strategy (`dark` on `<html>`) | REVERSE_SRS_old.md line 545 |
| Icons | lucide-react (60+ unique) | REVERSE_SRS_old.md line 546 |
| Calendar | FullCalendar | REVERSE_SRS_old.md line 547 |
| Rich text | Tiptap editor | REVERSE_SRS_old.md line 548 |
| Charts | Recharts (via shadcn chart component) | REVERSE_SRS_old.md line 549 |
| Onboarding | driver.js (9-step tour) | REVERSE_SRS_old.md line 550 |

---

### 6. File/Directory Structure

Both agents agree on directory structure. ANALYST's version is more detailed with file counts and notes; REVIEWER includes additional entries (.project/, .agent_docs/, .claude/agents/). Combined:

```
nexxus-v2/
  client/                          # Vite + React frontend (SPA)
    src/
      components/                  # 105 components (59 custom + 47 shadcn/ui)
        admin/          (2 files)  # User/org dialogs
        auth/           (1 file)   # ProtectedRoute
        calendar/       (2 files)  # FullCalendar integration
        chat/           (6 files)  # Chat panel, streaming, charts
        communication/  (3 files)  # Email inbox/compose
        inbox/          (1 file)   # Messaging panel
        insights/       (5 files)  # Dashboard cards
        layout/         (8 files)  # AppLayout, TopBar, Sidebar, SubMenu, RightPane, FavoritesBar
        modals/         (8-9 files)# Transcript, lead detail, table modals
        notifications/  (3 files)  # Bell, settings, barrel export
        onboarding/     (1 file)   # Product tour
        reports/        (8 files)  # Report catalog, viewer, charts
        settings/       (8 files)  # Tab components
        sms/            (1 file)   # SMS compose dialog
        ui/             (47 files) # shadcn/ui primitives
      contexts/         (4 files)  # Auth, App, Chat, Theme
      hooks/            (26 files) # TanStack Query + utility hooks
      lib/              (3 files)  # API client (api.ts), query config (queryClient.ts), utils (utils.ts)
      mocks/            (9 files)  # Mock data modules (may be unused)
      pages/            (17 main)
        hosted/         (4 public page components)
      App.tsx
      index.css         (615 lines)
      main.tsx
  server/                          # Express.js API
    auth/                          # JWT (jwt.ts) + middleware (middleware.ts)
    db/                            # SecureQueryBuilder.ts, index.ts
    db.ts                          # Pool config
    jobs/                          # 8 scheduled jobs (vinTokenRefreshJob.ts etc.)
    middleware/                    # enforceOrganizationContext.ts, validateResourceOwnership.ts, index.ts
    routes/                        # 34 route files
    services/                      # 36 top-level service files
      contextRouter/               # 4 files (ContextRouterService, SourceSelector, CacheManager, index)
      insights/                    # 4 files (Voice, Video, Lead insight services + index)
      leads/                       # 3 files (LeadCreation, LeadExtraction, index)
      sync/                        # 3 files (SyncCoordinator, LeadMapper, index)
      notifications/               # 1 file (notificationEmailService)
    utils/                         # Encryption utils, env validation
    webhooks/                      # 3 files (vapi.ts, tavus.ts, utils/signatureVerifier.ts)
    index.ts                       # Main entry point
    routes.ts                      # Route registry
    storage.ts                     # Storage interface
    static.ts                      # Static file serving
    vite.ts                        # Dev server middleware
  database/
    migrations/                    # 33 SQL files (001-033, 011 missing)
    seed.sql                       # Development seed data
  tests/
    e2e/                           # 46 Playwright spec files (747 tests)
      helpers/                     # global-setup.ts, test-utils.ts
    scripts/                       # 7 diagnostic scripts
    verification/                  # 11 verification scripts
  widget/                          # Preact embeddable widget (separate build)
  shared/
    schema.ts                      # Shared types (minimal, 18 lines)
  docs/                            # Documentation (40+ files)
    audit/                         # 5 forensic audit reports
    evidence/                      # Certification evidence
    reference/                     # Production deployment docs
    archive/                       # Pre-stabilization archives (40+ files)
  dist/                            # Build output (not in git)
    public/                        # Client SPA
      widget/                      # Embeddable widget + tracking pixel
    index.cjs                      # Server bundle
  uploads/                         # User uploads (not in git)
  .env                             # 33 environment variables (not in git)
  .project/                        # /plan mode scratch (to be gutted) [REVIEWER addition]
  .agent_docs/                     # Enforcer workspace [REVIEWER addition]
  .claude/agents/                  # Agent definitions (only enforcer.md) [REVIEWER addition]
  deploy.sh                        # Deploy script (master branch guard)
  playwright.config.ts             # E2E test configuration
  package.json                     # Dependencies and scripts
  tsconfig.json                    # TypeScript configuration (strict mode, noEmit)
  vite.config.ts                   # Vite build configuration
```

---

### 7. Deployment Architecture

#### 7.1 Infrastructure

Both agents agree:

| Component | Detail | Source |
|-----------|--------|--------|
| Server | Oracle Cloud, Linux 5.15.0-1081-oracle | REVERSE_SRS_old.md line 1235 |
| Runtime | Node.js v20.19.5 | REVERSE_SRS_old.md line 1236 (see DISAGREE-1) |
| Process manager | PM2 6.0.13, process name `nexxus-v2`, ID 13 | REVERSE_SRS_old.md lines 1237, 1282-1283 |
| Reverse proxy | Caddy (managed by sysadmin project) | REVERSE_SRS_old.md line 1238 |
| SSL | Managed by Caddy/sysadmin | REVERSE_SRS_old.md line 1239 |
| Database | Supabase PostgreSQL (aws-0-us-west-2) | REVERSE_SRS_old.md line 1240 |
| Docker | NOT used | REVERSE_SRS_old.md line 1241 |
| CI/CD | NOT configured | REVERSE_SRS_old.md line 1242 |
| Monitoring | None project-specific | REVERSE_SRS_old.md line 1243 |
| Live URL | https://nexxusv2.huminicdev.com | REVERSE_SRS_old.md line 1392 |
| Health check | GET /api/health | REVERSE_SRS_old.md line 1393 |
| Port | Default 5000 (configurable via PORT env var) | server-audit.md line 46 [REVIEWER addition] |

#### 7.2 Build Pipeline

Both agents agree:

**Orchestrated by:** `script/build.ts` (REVERSE_SRS_old.md lines 1247-1255)

| Step | Tool | Input | Output |
|------|------|-------|--------|
| 1 | rm -rf | dist/ | (clean) |
| 2 | Vite build | client/ | dist/public/ (React SPA) |
| 3 | Vite build | widget/ | dist/public/widget/ (Preact widget) |
| 4 | esbuild | tracking pixel | dist/public/widget/nexxus-pixel.js (IIFE, minified) |
| 5 | esbuild | server/ | dist/index.cjs (CJS, minified) |

**Four build outputs:** Client SPA, embeddable widget (Preact), tracking pixel (IIFE), server (CJS).

#### 7.3 Deploy Process

Both agents agree:

**Script:** `./deploy.sh` (REVERSE_SRS_old.md lines 1261-1276)
1. Checks current branch is `master` (refuses feature branches)
2. Warns about uncommitted changes (y/N prompt)
3. Runs `npm run build`
4. Runs `pm2 restart nexxus-v2`
5. Shows `pm2 status`

**Missing:** No pre-deploy tests, no health check after restart, no rollback mechanism, no deploy notification.

**Feature branch workflow:** Create feature branch -> work -> merge to master -> `./deploy.sh` -> clean up branch. (REVERSE_SRS_old.md lines 1266-1270)

#### 7.4 PM2 Status

Both agents agree:

| Metric | Value | Source |
|--------|-------|--------|
| Memory | 148.9 MB | REVERSE_SRS_old.md line 1287 |
| CPU | 0.2% | REVERSE_SRS_old.md line 1288 |
| Total restarts | 3,327 in 31 days (~107/day) | REVERSE_SRS_old.md line 1290 |
| Unstable restarts | 0 | REVERSE_SRS_old.md line 1291 |
| Ecosystem config | NOT PRESENT | REVERSE_SRS_old.md line 1292 |

#### 7.5 Disk Usage

[ANALYST only; REVIEWER did not extract]

| Directory | Size | Source |
|-----------|------|--------|
| Source + docs + assets | 34 MB | REVERSE_SRS_old.md line 1306 |
| node_modules/ | 575 MB | REVERSE_SRS_old.md line 1307 |
| dist/ (build output) | 12 MB | REVERSE_SRS_old.md line 1308 |
| **Total** | **656 MB** | REVERSE_SRS_old.md line 1309 |

#### 7.6 NPM Scripts

Both agents agree:

| Script | Command | Source |
|--------|---------|--------|
| `build` | `tsx script/build.ts` | REVERSE_SRS_old.md line 1315 |
| `dev` | `NODE_ENV=development tsx server/index.ts` | REVERSE_SRS_old.md line 1319 |
| `start` | `NODE_ENV=production node dist/index.cjs` | REVERSE_SRS_old.md line 1320 |
| `check` | `tsc` (type checking, no emit) | REVERSE_SRS_old.md line 1317 |
| `test:quality` | `check && build && test:env && test:accuracy` | REVERSE_SRS_old.md line 1323 |

**Missing scripts:** No `lint`, `format`, `test` (Playwright), or `test:unit`. (REVERSE_SRS_old.md line 1326)

[REVIEWER addition] Additional test commands:
- `npx playwright test` -- E2E tests
- `npm run test:accuracy` -- data-accuracy.ts
- `npm run test:smoke` -- dealerbrain-smoke.ts
- `npm run test:env` -- env-check.ts

---

### 8. Integration Architecture

#### 8.1 VIN Solutions (CRM)

Both agents agree on all facts. Combined:

| Aspect | Detail | Source |
|--------|--------|--------|
| Type | REST API | REVERSE_SRS_old.md line 330 |
| Auth | OAuth2 Client Credentials (tokens expire 60 min) | REVERSE_SRS_old.md line 330 |
| Token storage | AES-256-GCM encrypted in `integrations.credentials` | REVERSE_SRS_old.md line 940 |
| Token refresh | Every 30 min (job), refreshes within 10 min of expiry | REVERSE_SRS_old.md lines 943-948 |
| Base URL | `https://api.vinsolutions.com` | DATA_SOURCE_INVENTORY.md line 25 |
| Header versioning | v1: `application/vnd.coxauto.v1+json`, v3: `application/vnd.coxauto.v3+json` (lowercase), gateway: `application/json` | REVERSE_SRS_old.md lines 1028-1031 |
| Accessible endpoints | 13 (leads CRUD, contacts, lead sources/types/statuses, CRM users, dealers) | REVERSE_SRS_old.md lines 1009-1025 |
| Blocked endpoints | 17 (all return 403) | REVERSE_SRS_old.md lines 1033-1053 |
| Service files | `vinSolutionsService.ts`, `vinOAuthService.ts` | DO_NOT_TOUCH.md lines 134-135 |
| Sub-services | `sync/SyncCoordinator.ts`, `sync/LeadMapper.ts` | DO_NOT_TOUCH.md lines 152-153 |
| Context Router files | `contextRouter/ContextRouterService.ts`, `SourceSelector.ts`, `CacheManager.ts` | DO_NOT_TOUCH.md lines 141-143 |
| Lead creation | 2-step: POST /gateway/v1/contact -> get ContactId, then POST /leads with href references | REVERSE_SRS_old.md lines 820-823 |
| API call telemetry | `vin_api_calls` table (endpoint, params, duration, status, result_count) | database-audit.md line 127 |
| Key derivation | AES-256-GCM via PBKDF2 (100k iterations) from SESSION_SECRET | REVERSE_SRS_old.md line 457 [REVIEWER addition] |
| Per-org credentials | Stored in `integrations` table per org, NOT in .env | session-knowledge.md line 208-209 [REVIEWER addition] |

**CRITICAL BUG (ANALYST only):** Lead creation code calls `/leadSources` and `/leadTypes` with v3 headers but these endpoints require v1 headers. Calls fail silently (caught in try/catch). (DATA_SOURCE_INVENTORY.md lines 156-164)

#### 8.2 VAPI (Voice AI)

Both agents agree:

| Aspect | Detail | Source |
|--------|--------|--------|
| Type | Webhook inbound + outbound API | REVERSE_SRS_old.md line 331 |
| Auth (inbound) | Optional shared secret (`X-Vapi-Secret`, timing-safe comparison) | REVERSE_SRS_old.md lines 340-344 |
| Webhook endpoint | `/api/webhooks/vapi` (registered BEFORE body parsers) | server-audit.md line 65 |
| Events handled | `call.started`, `call.ended`, `end-of-call-report`, `transcript`, `status-update` | REVERSE_SRS_old.md line 341 |
| Org resolution | `metadata.organizationId` or `assistantId` lookup in agents table | REVERSE_SRS_old.md line 342 |
| Idempotency | `notification_sent` and `credit_recorded` columns with atomic UPDATE...WHERE...RETURNING | REVERSE_SRS_old.md line 343 |
| Processing chain | Call log -> lead extraction -> sync_queue -> credit recording -> email notification -> in-app notification -> appointment extraction | REVERSE_SRS_old.md lines 800-832 |

[REVIEWER addition] Appointment extraction triggers when confidence >= 70%, then sync_queue entry created (lead_to_vin).

#### 8.3 Tavus (Video AI)

Both agents agree:

| Aspect | Detail | Source |
|--------|--------|--------|
| Type | Webhook inbound + outbound API | REVERSE_SRS_old.md line 332 |
| Auth | HMAC-SHA256 with 5-minute timestamp tolerance | REVERSE_SRS_old.md line 349 |
| Webhook endpoint | `/api/webhooks/tavus` (raw body capture for HMAC) | server-audit.md line 66 |
| Events handled | `conversation.started`, `conversation.ended`, `replica.ready`, `video.ready` | REVERSE_SRS_old.md line 348 |
| Org resolution | `custom_data.organization_id` or `persona_id` lookup in agents table | REVERSE_SRS_old.md line 349 |
| Deployed agents | 5 personas (Caroline, Magnolia, Georgia, Elizabeth, Savannah) across 2 customers | REVERSE_SRS_old.md line 116 |

#### 8.4 TextMagic (SMS)

Both agents agree:

| Aspect | Detail | Source |
|--------|--------|--------|
| Type | REST API v2 | REVERSE_SRS_old.md line 334 |
| Auth | Username + API key (per-org, stored in `textmagic_config`) | REVERSE_SRS_old.md line 334 |
| Inbound webhook | `/api/sms/webhook/inbound` (public, NO signature verification) | REVERSE_SRS_old.md lines 351-353 |
| Service file | `TextMagicService.ts` (1,130 lines) | REVERSE_SRS_old.md line 304 |
| Tables | `textmagic_config`, `textmagic_messages`, `textmagic_opt_outs`, `sms_conversation_state` | database-audit.md |

[REVIEWER addition] Not built: AI auto-reply (schema exists but logic not implemented), business hours routing, collision avoidance state machine (REVERSE_SRS_old.md lines 670-680)

#### 8.5 Resend (Email)

Both agents agree:

| Aspect | Detail | Source |
|--------|--------|--------|
| Type | SDK | REVERSE_SRS_old.md line 333 |
| Auth | API key | REVERSE_SRS_old.md line 333 |
| Purpose | Transactional email (lead notifications, welcome emails, appointment confirmations) | REVERSE_SRS_old.md line 333 |
| Service file | `notifications/notificationEmailService.ts` | DO_NOT_TOUCH.md line 155 |

#### 8.6 Anthropic Claude (AI/LLM)

Both agents agree:

| Aspect | Detail | Source |
|--------|--------|--------|
| Type | SDK | REVERSE_SRS_old.md line 335 |
| Auth | API key | REVERSE_SRS_old.md line 335 |
| Model | Configurable (defaults to claude-3-5-sonnet) | server-audit.md line 638 |
| Service files | `DealerBrainService.ts` (3,047 lines), `DealerBrainStreamingService.ts` (2,020 lines) | REVERSE_SRS_old.md lines 299-300 |
| Tools exposed | 24 tools for function calling | REVERSE_SRS_old.md lines 374-399 |
| Also used by | `DealerPulseService` (Claude Haiku), `HunchesService`, `AppointmentExtractionService`, `WidgetAgentService` | REVERSE_SRS_old.md lines 310, 316; server-audit.md line 593 |

[REVIEWER addition] DealerBrain Processor middleware: Stage 1 (monitoring only). Stages 2-3 (intervention, approval gates) deferred. (REVERSE_SRS_old.md line 401)

#### 8.7 Google Calendar

Both agents agree:

| Aspect | Detail | Source |
|--------|--------|--------|
| Type | OAuth2 (Authorization Code flow) | REVERSE_SRS_old.md line 336 |
| Auth | OAuth tokens (per-user) | REVERSE_SRS_old.md line 336 |
| Service file | `GoogleCalendarService.ts` | server-audit.md line 605 |
| Routes | 7 endpoints at `/api` (oauth/calendar paths) | server-audit.md lines 291-302 |
| Purpose | Calendar sync, appointment push to Google Calendar | REVERSE_SRS_old.md line 336 |

---

### 9. Real-Time Architecture

#### 9.1 SSE Streaming (DealerBrain)

Both agents agree (see 5.5 above for full details).

#### 9.2 Polling

Both agents agree:

| Feature | Interval | Source |
|---------|----------|--------|
| Token auto-refresh | 60 seconds (client-side) | client-audit.md line 428 |
| Dashboard auto-refresh | 60 seconds with 5-min manual cooldown | client-audit.md line 84 |
| Notification unread count | Polling (interval not specified) | UNIFIED_HANDOFF_PROMPT.md line 177 |
| VIN lead polling | 60 minutes (server-side job) | REVERSE_SRS_old.md line 363 |

#### 9.3 WebSocket

Both agents agree: Socket.io is installed but NOT actively used for production features. (UNIFIED_HANDOFF_PROMPT.md line 176; server-audit.md line 51)

ARCHITECTURE_VISUAL_MAP.md line 59 claims Daria monitors "activity streams (WebSocket)." This is aspirational; no WebSocket monitoring exists in the codebase.

---

### 10. Configuration Management

#### 10.1 Environment Variables

Both agents agree:

- **33 environment variables** in `.env` | REVERSE_SRS_old.md line 1297
- `.env` is git-ignored | REVERSE_SRS_old.md line 1298
- No `.env.example` or `.env.template` exists | REVERSE_SRS_old.md line 1299

**Known env vars (from various sources):**

| Variable | Purpose | Source |
|----------|---------|--------|
| `VIN_SOLUTIONS_CLIENT_ID` | VIN OAuth client ID | VIN_SOLUTIONS_INTEGRATION.md line 68 |
| `VIN_SOLUTIONS_CLIENT_SECRET` | VIN OAuth client secret | VIN_SOLUTIONS_INTEGRATION.md line 69 |
| `VIN_SOLUTIONS_API_KEY` | VIN API key | VIN_SOLUTIONS_INTEGRATION.md line 70 |
| `CONTEXT_ROUTER_ENABLED` | Toggle Context Router (true/false) | REVERSE_SRS_old.md line 992 |
| `SESSION_SECRET` | Key derivation for AES-256-GCM encryption | REVERSE_SRS_old.md line 457 |
| `VAPI_WEBHOOK_SECRET` | VAPI webhook verification | REVERSE_SRS_old.md line 344 |
| `NODE_ENV` | production/development | REVERSE_SRS_old.md line 436 |
| `PORT` | Server port (default 5000) | server-audit.md line 46 |

[REVIEWER addition] Also required but not individually named: Database connection URLs (Supabase direct + pgbouncer), Tavus/Resend/TextMagic/Claude API keys, Google Calendar OAuth client ID/secret.

#### 10.2 Database Configuration

Both agents agree:

| Table | Purpose | Source |
|-------|---------|--------|
| `dealerbrain_config` | 3 key-value rows: system_instructions, feedback_enabled, feedback_instructions | database-audit.md line 102 (ANALYST), line 24 (REVIEWER) |
| `integrations` | Per-org API credentials (VIN Solutions OAuth tokens, encrypted) | database-audit.md |
| `textmagic_config` | Per-org SMS config (api_username, api_key_encrypted, phone_number, business_hours) | database-audit.md |
| `user_integrations` | Per-user email/calendar settings (IMAP/SMTP creds, calendar OAuth tokens) | database-audit.md |
| `widget_configs` | Per-org widget config (appearance, channels, targeting, allowed domains) | database-audit.md |
| `credit_policies` | Per-org pricing (rate_per_unit, cost_per_unit, monthly_allowance) | database-audit.md |
| `service_quotas` | Per-org monthly limits (schema only, no enforcement logic found) | REVERSE_SRS_old.md line 736 |
| `organizations.settings` | Organization settings (JSONB) | database-audit.md line 67 |
| `roles` | 4 RBAC roles with permissions JSONB | database-audit.md [REVIEWER addition] |

#### 10.3 RBAC Configuration

Both agents agree:

4-tier RBAC roles seeded in database (REVERSE_SRS_old.md lines 450-455):

| Level | Role | Source |
|-------|------|--------|
| 1 | Super Admin | REVERSE_SRS_old.md line 452 |
| 2 | Partner Admin | REVERSE_SRS_old.md line 453 |
| 3 | Org Admin | REVERSE_SRS_old.md line 454 |
| 4 | Org Staff | REVERSE_SRS_old.md line 455 |

#### 10.4 Token Configuration

Both agents agree:

| Token | Expiry | Audience | Source |
|-------|--------|----------|--------|
| Access token | 24 hours | `nexxus-api` | REVERSE_SRS_old.md line 444 |
| Refresh token | 7 days | `nexxus-api` | REVERSE_SRS_old.md line 445 |
| Appointment confirmation | 48 hours | `nexxus-appointment` | REVERSE_SRS_old.md line 446 |

#### 10.5 localStorage Keys (Client)

Both agents agree:

| Key | Purpose | Source |
|-----|---------|--------|
| `nexxus_access_token` | JWT access token | CARRY_FORWARD_MANIFEST.md line 39 |
| `nexxus_refresh_token` | JWT refresh token | CARRY_FORWARD_MANIFEST.md line 39 |
| `nexxus_token_expiry` | Token expiry timestamp | CARRY_FORWARD_MANIFEST.md line 39 |
| `nexxus_accessible_orgs` | Partner Admin org list | CARRY_FORWARD_MANIFEST.md line 39 |
| `nexxus:theme` | Light/dark theme preference | client-audit.md line 483 |
| `nexxus_welcome_shown` | Welcome modal state | CARRY_FORWARD_MANIFEST.md line 93 |
| `nexxus_hide_welcome` | Welcome modal suppression | CARRY_FORWARD_MANIFEST.md line 93 |

#### 10.6 Feature Flags

[REVIEWER addition]

- `CONTEXT_ROUTER_ENABLED` -- env var, was `false` before 2026-02-16 (REVERSE_SRS_old.md line 992)
- Credit page route commented out (intentional defer) (REVERSE_SRS_old.md line 733)
- Billing profile tab commented out
- No formal feature flag system exists

---

### 11. Frontend Component Map

#### 11.1 Key Components by Page

Both agents agree. Combined:

| Page | Key Components | Interactive Elements |
|------|---------------|---------------------|
| Dashboard (`/`) | DealershipPulse, GoalProgress, LeadFeed, AgentActions (sparkline), TeamLeaderboard | 60s auto-refresh, score modals, role-based visibility via `ROLE_VISIBILITY` map |
| Chat (`/chat`) | FloatingChat, ChatPanel, StreamingMessage, SuggestedPrompts, ChatChart | SSE streaming, file upload/paste, favorites |
| Agents (`/agents`) | Agent list (w-72), chat interface (center), info/stats panel (w-80) | Search, type/status filter, CRUD, duplicate, status toggle, Automa always active |
| Insights (`/insights`, `/leads`) | VoiceAgentCard, VideoDataCard, LeadFeedCard, Quick Summary, AttributionPanel, DealerPulsePanel | 6 tabs, date range filter, modals (transcript, audio, video, leads) |
| Work Center (`/work-center`) | AppointmentCalendar, AppointmentModal, InboxPanel, SMSComposeDialog | 5 tabs (Calendar, Tasks, Approvals, Communication, Open Leads), task CRUD, dialer, tab state synced with URL params |
| Settings (`/settings/system`) | 8 settings tab components, UserDialogs, OrgDialogs | 16+ tabs, user/org CRUD, integration test/delete, trigger config. Super Admin: Users, Organizations, Partner Links, Tools, Hunches, Automa, SMS. Org Admin+: Knowledge, Email, Widget, Pages, Report Upload, Triggers. All: Application, Integrations. |
| Drive (`/drive`) | Grid/list view, folder nav, breadcrumbs | Upload, create folder, download, rename, delete |
| Activity (`/activity`) | Stats cards, activity feed, artifacts tab | Filter, pagination, CSV export (admin) |
| Profile (`/profile`) | Profile tab, Preferences tab, Google Calendar integration | Dark mode, notification prefs, calendar connect/disconnect |
| Login (`/login`) | Glass-effect login with 9 randomized wallpapers | [REVIEWER addition] |

#### 11.2 Interactive Element Handlers

[ANALYST only]

Full mapping at UI_INTERACTIVE_ELEMENTS_MAP.md lines 1-200. Key patterns:
- Form submissions call TanStack Query mutations
- Navigation uses Wouter's `setLocation()`
- State toggles use React `useState` setters
- Modals use `setXxxOpen(true/false)` pattern
- Filters use `setXxxFilter(value)` with query invalidation

---

### 12. Build & Development Pipeline

#### 12.1 Build Process

See Section 7.2 above (both agents agree).

#### 12.2 Development Workflow

Both agents agree:

```
Working Directory -> TypeScript (.ts files)
                  -> npm run build
                  -> dist/ (compiled JavaScript)
                  -> PM2 serves dist/index.cjs
                  -> Users see compiled code
```

Feature branch workflow: Create feature branch -> work -> merge to master -> `./deploy.sh` -> clean up branch. Deploy script refuses non-master branches.

#### 12.3 Quality Gates

Both agents agree:

| Gate | Tool | Status | Source |
|------|------|--------|--------|
| TypeScript type check | `tsc` (strict mode, noEmit) | Configured | REVERSE_SRS_old.md line 1317 |
| ESLint | NOT configured | Missing | REVERSE_SRS_old.md line 612 |
| Prettier | NOT configured | Missing | REVERSE_SRS_old.md line 613 |
| Pre-commit hooks | NOT configured | Missing | REVERSE_SRS_old.md line 614 |
| CI/CD pipeline | NOT configured | Missing | REVERSE_SRS_old.md line 615 |
| Test coverage | NOT measured | Missing | health-audit.md line 168 |

#### 12.4 Test Infrastructure

Both agents agree:

| Aspect | Detail | Source |
|--------|--------|--------|
| E2E test count | 747 across 46 files | health-audit.md lines 38-39 |
| Framework | Playwright ^1.58.1 | health-audit.md line 148 |
| Config file | `playwright.config.ts` | health-audit.md line 149 |
| Base URL | `https://nexxusv2.huminicdev.com` (tests against production) | health-audit.md line 152 |
| Browser | Chromium, Desktop Chrome, 1280x720 | health-audit.md line 153 |
| Parallelism | Fully parallel (local), 1 worker (CI) | health-audit.md line 154 |
| Retries | 0 (local), 2 (CI) | health-audit.md line 155 |
| Artifacts | Screenshots + video on failure, trace on first retry | health-audit.md line 156 |

**Unit tests:** ZERO (no Jest config, no test files) | health-audit.md lines 44, 163
**Component tests:** ZERO (no React Testing Library) | health-audit.md line 165
**Integration tests:** ZERO (API tested only via E2E) | health-audit.md line 164

---

## RECONCILED WATCH AREAS

### W1. Agent Functionality

Both agents agree on all facts:

- **Service files:** `AgentService.ts` (CRUD), `DealerBrainService.ts` + `DealerBrainStreamingService.ts` (chat), `WidgetAgentService.ts` (widget chat)
- **Routes:** 9 at `/api/agents` (list, stats, seed, get, create, update, delete, duplicate, status toggle) | server-audit.md lines 145-159
- **Tables:** `agents`, `skills`, `agent_runs` | database-audit.md lines 74-77
- **Default seed agents:** Automa (system, cannot be deleted/duplicated), Sales Coach, Message Crafter, VAPI voice agent
- **Skills:** 10 skill types defined in UI; execution NOT fully connected to agent runtime | REVERSE_SRS_old.md line 655
- **GAP-1:** `performanceMetrics` JSONB field in `agents` table is NEVER populated by webhooks
- **DealerBrain tools:** 24 tools for function calling | REVERSE_SRS_old.md lines 374-399
- **Owner clarification:** V1 had 27 hardcoded agents; V2 users CREATE agents and ADD skills. Skills = agent overlays (context + instructions). NOT a blocker. (session-knowledge.md lines 52-58)

### W2. Billing / Credits

Both agents agree on all facts:

- **Service file:** `CreditService.ts`
- **Tables:** `credit_policies`, `credit_allocations`, `credit_usage`, `service_quotas`
- **Routes:** 5 at `/api/credits` (balance, usage, policies, recent, summary)
- **Pricing:** Voice $0.25/min (40% margin), Video $0.32/min (37.5% margin), SMS $0.05/msg (60% margin)
- **Credit recording:** Wired to VAPI/Tavus webhooks via idempotent `credit_recorded` flag
- **UI:** `/credits` route commented out -- intentional business decision to defer
- **Service quotas:** Table exists but NO enforcement logic in routes | REVERSE_SRS_old.md line 736

### W3. Unified Inbox

Both agents agree on all facts:

- **Service file:** `InboxService.ts`
- **Tables:** `inbox_conversations`, `inbox_messages`
- **Routes:** 8 at `/api/inbox` (list threads, unread count, get thread, messages, send reply, assign, update status, mark read)
- **Widget-to-inbox wiring:** Widget chat creates `inbox_conversation` and `inbox_message` records (fire-and-forget)
- **Client:** InboxPanel (Work Center > Communication tab), `useInbox` hook
- **Owner concept:** External agent conversations (via widget) continued internally by staff in Unified Inbox

### W4. Super Admin Functionality

Both agents agree on all facts:

- **Routes:** 14 at `/api/admin` (all Super Admin) + 3 at `/api/dealerbrain` (Super Admin)
- **Additional Super Admin access:** POST /api/auth/register, POST /api/vin/refresh-tokens, GET /api/vin/job-status, GET /api/metrics/summary, PUT /api/sms/config, POST /api/sms/test
- **RLS:** 16 tables have Super Admin bypass policy (`app.user_role_level = 1`)
- **UI:** Settings page Super Admin tabs: Users, Organizations, Partner Links, Tools, Hunches, Automa, SMS
- **Owner note:** "Undertested" (session-knowledge.md line 98)

### W5. Context Router

Both agents agree on all facts:

- **Service files:** `contextRouter/ContextRouterService.ts`, `SourceSelector.ts`, `CacheManager.ts`
- **Architecture:** SourceSelector decides data source: VIN API (priority 1, live) > Local DB (priority 2, fallback). Exclusion: `excel_upload` records filtered out.
- **Cache TTLs:** VIN leads 5 min, VIN reports 1 hr, VAPI/Tavus 1 hr
- **Source tagging:** vin_api, local_db, vapi, tavus, manual, widget (internal traceability, not user-facing)
- **Config:** `CONTEXT_ROUTER_ENABLED=true` (was `false` before 2026-02-16) | REVERSE_SRS_old.md line 992
- **Truth hierarchy:** VIN Solutions API > VAPI/Tavus APIs > Local DB > Derived Metrics | CONSTITUTION.md lines 38-43

---

## RECONCILED CONFLICTS

Both agents identified the same conflicts. REVIEWER grouped some; ANALYST enumerated individually. Unified conflict list:

| # | Topic | File A | File B | Detail | Source Agent |
|---|-------|--------|--------|--------|-------------|
| C1 | Frontend framework | ARCHITECTURE_VISUAL_MAP.md line 31: "Next.js 14 App Router" | client-audit.md line 49: "React 18 + Vite" | Visual map is aspirational. Actual codebase is Vite + React, NOT Next.js. | Both |
| C2 | State management | ARCHITECTURE_VISUAL_MAP.md line 41: "Zustand + React Query" | client-audit.md lines 52-53: "TanStack Query + React Context API" | No Zustand in codebase. Uses React Context for client state. | Both |
| C3 | Redis | ARCHITECTURE_VISUAL_MAP.md line 152: "Redis" for short-term memory | REVERSE_SRS_old.md line 368: "native setInterval" | No Redis. All jobs use in-memory setInterval. | Both |
| C4 | ClickHouse / OLAP | ARCHITECTURE_VISUAL_MAP.md lines 173-196: "ClickHouse, Airbyte, dbt, Cube.js" | REVERSE_SRS_old.md: only PostgreSQL | None of these are implemented. | Both |
| C5 | MCP Gateway | ARCHITECTURE_VISUAL_MAP.md lines 119-141: "MCP Proxy Server (Port 3010)" | REVERSE_SRS_old.md: no MCP proxy | No MCP proxy in codebase. Central-MCP at ../central-mcp/ is separate and not integrated. | ANALYST |
| C6 | VIN token refresh interval | VIN_SOLUTIONS_INTEGRATION.md line 37: "every 6 hours" | REVERSE_SRS_old.md line 359: "30 min" | REVERSE_SRS is later forensic audit (2026-02-21), likely reflects current state. | Both |
| C7 | Table count | CLAUDE.md (pre-enforcer): "36 tables" | database-audit.md line 63: "53" | CLAUDE.md is outdated. 53 is correct. | Both |
| C8 | WebSocket usage | ARCHITECTURE_VISUAL_MAP.md line 59: "Monitor activity streams (WebSocket)" | server-audit.md line 51: "no WebSocket in active use" | Socket.io installed but not used for production features. | Both |
| C9 | Specialized agents (Daria, AutoDealer, etc.) | ARCHITECTURE_VISUAL_MAP.md lines 49-112: 4-tier agent hierarchy with named agents | REVERSE_SRS_old.md lines 644-655: only Automa + user-created agents | Named specialized agents do NOT exist in codebase. V1 concept replaced by user-created agents + skills model. | Both |
| C10 | Hosted pages route | Client code: `/api/hosted-pages/public/${slug}` | Server code: `/api/pages/:slug` | Confirmed P0 bug -- route mismatch. 1-line fix. | Both |
| C11 | Endpoint count | server-audit.md: "~185" | REVERSE_SRS_old.md: "~237" | Different counting methods. Use ~237 as upper bound. | ANALYST (REVIEWER noted as CONFLICT 5) |
| C12 | SecureQueryBuilder vs Direct Pool | SecureQueryBuilder sets `app.current_organization_id` | All RLS policies check `app.current_org_id` | Intended centralized security path is architecturally broken. Most routes bypass it. HIGH impact. | REVIEWER (ANALYST covered in RLS section) |

---

## MERGED MISSING INFORMATION

Both agents identified missing information. Combined unique list:

| # | Expected Detail | Status | Source Agent |
|---|----------------|--------|-------------|
| NF1 | Full list of 33 environment variables | Only ~8 explicitly named. No `.env.example` exists. | Both |
| NF2 | Server port allocation (actual production) | Default 5000 mentioned but actual production allocation not documented. | ANALYST |
| NF3 | Shared schema types (`shared/schema.ts`) content | "Minimal (18 lines)" but actual contents not provided. | ANALYST |
| NF4 | Widget Preact bundle configuration | Build step mentioned but widget/vite.config.ts content not visible. | ANALYST |
| NF5 | PM2 ecosystem.config.cjs | NOT PRESENT -- no ecosystem config exists. | Both |
| NF6 | DealerBrain AI model version (exact pin) | "Configurable (defaults to claude-3-5-sonnet)" but specific version not pinned. | ANALYST |
| NF7 | Service quota enforcement logic | Table exists but no enforcement logic in routes. | Both |
| NF8 | SMS AI auto-reply implementation | Schema field `ai_auto_reply_enabled` exists but logic not implemented. | Both |
| NF9 | SMS collision avoidance state machine | Table `sms_conversation_state` exists but state machine not implemented. | Both |
| NF10 | Caddy reverse proxy configuration | Managed by sysadmin project; lives outside nexxus-v2. | ANALYST |
| NF11 | Deployment rollback mechanism | None exists. | REVIEWER |
| NF12 | Express 5 pre-release version pinning | Not documented. | REVIEWER |
| NF13 | No structured logging | 242 unstructured console.log in server code. | REVIEWER |
| NF14 | Metrics fragmented across 5 services | No unified MetricsEngine wiring. | REVIEWER |

---

## CROSS-WAVE NOTES

Both agents provided cross-wave notes. Merged (deduplicated):

### For PRD (Wave 1)
- CONSTITUTION.md lines 9-28 contain platform identity narrative (what Nexxus is, partner model, industry-agnostic architecture)
- Per-usage economics (voice/video/SMS) are wired at DB schema level but credits UI is deferred

### For SRS (Wave 2)
- REVERSE_SRS_old.md lines 798-929 contain detailed data flow narratives (voice call -> lead creation, DealerBrain query, widget chat -> inbox, trigger execution, VIN OAuth lifecycle, Context Router)
- session-knowledge.md lines 8-48 contain owner's platform mental model (widgets = portals to agents, skills = agent overlays, V1->V2 transition)
- Context Router source prioritization (VIN > Local > Derived) is both architectural and behavioral
- SSE streaming protocol details (6 event types) describe "what happens when user chats"
- Trigger evaluation flow with 7 event types and 5 action types describes system behavior
- Widget-to-inbox handoff flow describes continuity between external and internal surfaces

### For AC (Wave 5)
- REVERSE_SRS_old.md lines 122-128 contain 5 customer acceptance criteria with current status
- 747 E2E tests exist covering auth, RBAC, all major features
- Hosted pages route mismatch is a testable regression
- Insights crash (4 unsafe .pct accesses) is a testable fix

### For PLAN (Wave 4)
- REVERSE_SRS_old.md lines 1099-1157 contain prioritized known issues (5 CRITICAL, 10 HIGH, 15 MEDIUM, 8 LOW)
- REVERSE_SRS_old.md lines 1174-1186 list 7 open feature gaps (GAP-1 through GAP-7)
- RLS variable mismatch (C12) is a known architecture fix
- Missing migration 011, duplicate 004 prefix are migration hygiene items
- 0 unit tests, no ESLint/Prettier/CI are infrastructure gaps
- Service quotas enforcement, SMS collision avoidance, AI auto-reply are schema-ready but unbuilt

### For CLAUDE.md (Wave 6)
- REVERSE_SRS_old.md lines 1210-1225 list 10 document inconsistencies between current CLAUDE.md and reality
- Stale data in CLAUDE.md (table count, phase status, etc.) needs correction
- Truth hierarchy: UI (Replit mockup) > AC > Release Plan
- Enforcer is the only agent file in .claude/agents/

---

## OWNER ACTION ITEMS SUMMARY

| # | Item | Type | Priority |
|---|------|------|----------|
| 1 | Resolve DISAGREE-1: Confirm Node.js v20.19.5 | Verify | LOW (likely ANALYST is correct) |
| 2 | Resolve DISAGREE-2: Confirm responsive breakpoint (1024px vs 768px) | Verify | LOW (live verification needed) |
| 3 | Confirm ARCHITECTURE_VISUAL_MAP.md status: aspirational (pre-build) vs as-built | Decision | MEDIUM -- affects whether it should be archived or updated |
| 4 | Decide if C5 (MCP Gateway) should be documented as a future integration target | Decision | LOW |
| 5 | Confirm C6 (VIN token refresh): is 30 min correct? | Verify | LOW (likely yes per REVERSE_SRS) |
| 6 | Acknowledge all 12 conflicts (C1-C12) for SPEC accuracy | Review | HIGH |
| 7 | Acknowledge 14 missing information items (NF1-NF14) for PLAN prioritization | Review | MEDIUM |

---

## Source Confidence Assessment

| Source File | Reliability | Notes |
|-------------|-------------|-------|
| REVERSE_SRS_old.md | **HIGHEST** -- forensic as-built audit (2026-02-21) | Most comprehensive; both agents relied on it as primary |
| server-audit.md | **HIGH** -- forensic audit | Complete endpoint catalog, middleware, services |
| client-audit.md | **HIGH** -- forensic audit | Complete page/component/hook/state inventory |
| database-audit.md | **HIGH** -- forensic audit | Migration and table analysis |
| health-audit.md | **HIGH** -- forensic audit | Test inventory, dependency health |
| DO_NOT_TOUCH.md | **HIGH** -- freeze manifest | Definitive backend file list |
| CARRY_FORWARD_MANIFEST.md | **HIGH** -- carry-forward inventory | Frontend preservation verdicts |
| ARCHITECTURE_GUIDE.md | **MEDIUM** -- partially aspirational | Layout system is accurate; some details may be stale |
| ARCHITECTURE_VISUAL_MAP.md | **LOW** -- aspirational/pre-build (2026-01-20) | Most claims contradicted by forensic audits |
| VIN_SOLUTIONS_INTEGRATION.md | **MEDIUM** -- sprint 2 report | Contains production credentials (lines 68-70) |
| DATA_SOURCE_INVENTORY.md | **HIGH** -- probe results | VIN API endpoint verification |
| session-knowledge.md | **CONTEXT** -- owner mental model | Qualitative; not code-verified |
| CLAUDE.md (pre-enforcer) | **LOW** -- stale | Many values outdated vs forensic audit |

---

**END OF WAVE 3 RECONCILED OUTPUT**
