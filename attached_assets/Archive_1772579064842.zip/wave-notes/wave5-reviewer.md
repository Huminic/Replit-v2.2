# Wave 5 — REVIEWER: Current State -> PLAN
**Date:** 2026-03-03
**Role:** REVIEWER (independent extraction for reconciliation with ANALYST)
**Purpose:** Extract current project state from all 53 input files + workbench artifacts to feed PLAN.md content.
**Evidence Standard:** Every claim cites source file and line/section. VERIFIED vs CLAIMED-BUT-UNVERIFIED distinguished.

---

## Section 1: Project Completion Status

### Overall Assessment: ~65-70% Feature-Complete, ~40-50% Demo-Ready

**Evidence basis:**
- REVERSE_SRS_old.md Section 1: "YELLOW" overall health verdict. 402 source files, 117,693 LOC, 237 endpoints, 53 tables built. (VERIFIED via health-audit.md Section 1)
- ACCEPTANCE_VERIFICATION_REPORT.md: Claims 13/13 AC items PASS (CLAIMED-BUT-UNVERIFIED — partially refuted by verified-findings.md F1, F9)
- verified-findings.md F10: After removing tainted/resolved findings, actual P0 count is 3-7, not 17. Platform is in better shape than Run 2 reported.
- DATA_ACCURACY_REPORT.md: 72% of post-V2 VAPI calls missing from DB; Tavus has 0 real sessions captured; VIN lead coverage ~0.26% of total but ~99% of ACTIVE leads in 30-day window. (VERIFIED)
- session-knowledge.md Section 0c: Owner defined 7 payment-critical capabilities. Mapping against codebase shows several are partially functional, not fully demo-ready.

### Payment-Critical Demo Readiness (session-knowledge.md 0c):

| # | Capability | Status | Evidence | Demo-Blocking? |
|---|-----------|--------|----------|----------------|
| 1 | Metrics & Insights display | PARTIAL | insights.tsx has 4 crash-risk lines (verified-findings.md F3, lines 854/1293/2142/2143). Metrics fragmented across 5 services (IMPLEMENTATION_PLAN.md Phase 4). DashboardService works for basic cards (DATA_ACCURACY_REPORT.md "Dashboard Card Metrics"). | YES — crash risk must be fixed |
| 2 | Communications Agent Configuration | PARTIAL | 8 active trigger rules exist (DATA_ACCURACY_REPORT.md "Trigger Rules Summary"). But 0 production triggers have fired (DATA_ACCURACY_REPORT.md "Trigger Execution History": 0 completed, 84 all E2E test). Trigger condition `lead_age_minutes >= 5` never met at import time. | YES — triggers don't fire |
| 3 | Appointment Flow | PARTIAL | AppointmentService exists (1,248 lines per health-audit.md 8.6). Calendar UI renders (ACCEPTANCE_VERIFICATION_REPORT.md AC-1). But updateAppointment() fires zero notification events (verified-findings.md F1, GAP-B5-STATUS-001). VIN has no calendar API (owner-resolved, session-knowledge.md Section 6). | YES — no status notifications |
| 4 | Proactive Lead Follow-up | PARTIAL | TriggerService code exists with outbound_call and send_sms actions (ACCEPTANCE_VERIFICATION_REPORT.md AC-11). Dedup mechanisms confirmed in code (verified-findings.md F1, TriggerService.ts:856-871, idleLeadChecker.ts:406-439). But 0/84 real executions completed (DATA_ACCURACY_REPORT.md). SMS fallback rules missing for Ford/Hyundai of Columbia. | YES — nothing fires in production |
| 5 | Reactive After-Hours Coverage | PARTIAL | TextMagic integration exists (TextMagicService.ts, 1,130 lines per health-audit.md 8.6). Per-org DB credentials confirmed (verified-findings.md F1, TextMagicService.ts:223-232). SMS conversation states defined (DORMANT/AI_ACTIVE/HUMAN_ACTIVE per ACCEPTANCE_VERIFICATION_REPORT.md AC-2). But 0 successful SMS sends recorded (DATA_ACCURACY_REPORT.md G-6). | YES — untested in production |
| 6 | Widgets (all 3 modes) | MOSTLY WORKING | Unified widget: 50.13KB bundle, 19 configs, 6 channels (ACCEPTANCE_VERIFICATION_REPORT.md AC-6). Embed code: functional (AC-6). Hosted pages: route mismatch blocks them — client fetches `/api/hosted-pages/public/${slug}`, server at `/api/pages/:slug` (verified-findings.md F2, hosted-page-public.tsx:163 vs routes.ts:175). | YES — hosted pages 404 |
| 7 | Automa Chat | WORKING | DealerBrain/Automa functional with Claude API integration, SSE streaming, tool calling (ACCEPTANCE_VERIFICATION_REPORT.md AC-1, CARRY_FORWARD_MANIFEST.md Section 4). FloatingChat rendered globally (ACCEPTANCE_VERIFICATION_REPORT.md "AC-1: Chat Popout Overlay"). | No — functional |

**Summary: 0 of 7 payment-critical items are fully demo-ready. 1 works (Automa). 6 have blocking issues ranging from 1-line fixes to architectural gaps.**

---

## Section 2: Known Gaps & Bugs

### Confirmed P0 Gaps (VERIFIED — verified-findings.md F1, F2, F3)

| ID | Description | Severity | File/Line | Fix Complexity | Demo-Blocking? |
|----|-------------|----------|-----------|----------------|----------------|
| GAP-B2-HOSTED-001 | Hosted pages return 404: client fetches `/api/hosted-pages/public/${slug}`, server serves `/api/pages/:slug` | P0 | hosted-page-public.tsx:163 vs routes.ts:175 | 1 line | YES |
| GAP-B6-INSIGHTS-001 | Insights page crash risk: 4 unsafe `.pct` accesses without null guards | P0 | insights.tsx: lines 854, 1293, 2142, 2143 | 4 null guards | YES |
| GAP-B5-STATUS-001 | Appointment status changes trigger zero notifications; updateAppointment() has no event hooks | P0 | AppointmentService.ts (no event emit), release_criteria.md line 70 | Code addition | YES |

### Confirmed P1 Gaps (VERIFIED — verified-findings.md F10, release_criteria.md)

| ID | Description | Status | Source |
|----|-------------|--------|--------|
| GAP-B1-STATUS-BYPASS-001 | Agent status toggle bypasses provisioning | OPEN | release_criteria.md |
| GAP-B1-SOURCE-MAP-001 | LeadMapper missing 6/8 source mappings | OPEN | release_criteria.md |
| GAP-B4-IDLE-RESET-001 | idle_trigger_count never resets | OPEN | release_criteria.md |
| GAP-B3-VIN-SYNC-001 | 0/22 successful VIN syncs at runtime | OPEN | release_criteria.md |
| GAP-B2-PERSONA-RESPONSE-001 | Persona data never reaches frontend | OPEN | release_criteria.md |
| GAP-B6-AGENT-NAME-001 | Legacy agent names block seed | OPEN | release_criteria.md |
| GAP-B6-SA-DATA-001 | Super Admin cannot view other orgs' data | OPEN | release_criteria.md |
| GAP-B5-APPT-STARTTIME-001 | start_time returns null in API | OPEN | release_criteria.md |

### Needs Live Verification (verified-findings.md F1)

| ID | Description | Status | What's Needed |
|----|-------------|--------|---------------|
| GAP-B2-PERSONA-001 | Widget header shows "Nexxus" not persona name | UNKNOWN | Re-test with corrected 1280x720 viewport |
| GAP-B5-AVAIL-001 | No availability validation for AI bookings | LIKELY REAL | Owner decision: is this launch-required? |
| GAP-B1-VIN-001 | Hyundai: no VIN integration config | OPERATIONAL | DB check: is VIN provisioned for this org? |
| GAP-B1-VIN-002 | Ford of Columbia: no VIN integration config | OPERATIONAL | Same DB check needed |

### Critical Data Integrity Gaps (DATA_ACCURACY_REPORT.md)

| Issue | Severity | Evidence | Impact |
|-------|----------|----------|--------|
| VAPI webhook ingestion broken — 66 post-V2 calls lost | P0 | DATA_ACCURACY_REPORT.md: 92 post-V2 calls, only 26 in DB. `call.started` never received for real calls. `handleEndOfCallReport` UPDATE-only, cannot INSERT. | Transcripts, summaries, recordings lost |
| Tavus: 0 real sessions captured | P0 | DATA_ACCURACY_REPORT.md: 136 API conversations vs 1 seed record in DB. Zero V2 callback URLs configured. Zero video agents registered with persona IDs. | No video data in platform |
| Zero production trigger executions | P0 | DATA_ACCURACY_REPORT.md: 0/84 completed. `lead_age_minutes >= 5` never met at import time (lead is 0 min old). | Outbound calls/SMS never fire |
| PM2 crash-looping | P1 | DATA_ACCURACY_REPORT.md: 3,247 restarts. IMAP auth failure, missing dist/public/index.html, socket timeouts. health-audit.md Section 6.1: 3,327 restarts. | Missed webhook events during downtime |
| Ford/Hyundai triggers with no VIN integration | P1 | DATA_ACCURACY_REPORT.md "Integration Status": Ford of Columbia and Hyundai of Columbia show VIN Active = NO | Dead trigger rules |
| 19-28% gap in 7-day VIN lead capture | P1 | DATA_ACCURACY_REPORT.md "Recency Comparison": local DB captures 72-81% of VIN leads | Missing actionable leads |

### Governance / Structural Gaps (failure-analysis.md, verified-findings.md)

| Issue | Category | Evidence |
|-------|----------|----------|
| 3 AC files claim authority, none reconciled | D1 | failure-analysis.md D1: docs/AC (89KB), .agent_docs/AC (58KB, PLACEHOLDER), filestore/AC (49KB) |
| CLAUDE.md on disk is pre-enforcer | B2 | failure-analysis.md B2: chmod 444, requires owner manual edit |
| Gatekeeper removal left quality verification gap | H1-H4 | failure-analysis.md Category H: nobody loops builder output against AC+RUI |
| 3 conflicting governance layers | D1-D4 | session-knowledge.md Section 1: .project/ vs .agent_docs/ vs filestore/ |
| Owner knowledge not in files | A1-A4 | failure-analysis.md Category A: architecture, TextMagic creds, trigger dedup, widget tools |

---

## Section 3: Implemented Features (Confirmed Working)

All items below are VERIFIED via code inspection, audit reports, or runtime evidence.

| Feature | Evidence Source | Status |
|---------|---------------|--------|
| VAPI voice webhooks (receiving end-of-call-report) | DATA_ACCURACY_REPORT.md: PM2 logs show receipt of events for calls 019c6e28, 019c6e67, 019c710b | WORKING (but INSERT path broken) |
| VIN Solutions OAuth + API (3/5 orgs) | DATA_ACCURACY_REPORT.md "Integration Configuration": Serra Honda, Serra Nissan, Tony Serra Ford all active, last sync Feb 19 | WORKING |
| Lead extraction pipeline (VAPI -> DB -> VIN sync queue) | ACCEPTANCE_VERIFICATION_REPORT.md AC-4: "Full pipeline: webhook -> processCallEnd() -> sync_queue insert -> SyncCoordinator -> VIN API" | WORKING (pipeline exists; runtime success rate low) |
| Calendar UI (FullCalendar renders, CRUD) | ACCEPTANCE_VERIFICATION_REPORT.md AC-1: "Fixed in f12b025" | WORKING |
| Main dashboard (AI Key Metrics render) | DATA_ACCURACY_REPORT.md "Dashboard Card Metrics": Overdue 263, New 223, Active 4, Recent 301 | WORKING |
| DealerBrain / Automa / Chat AI | ACCEPTANCE_VERIFICATION_REPORT.md AC-1: FloatingChat global, SSE streaming. CARRY_FORWARD_MANIFEST.md Section 4: SSE protocol documented. | WORKING |
| Trigger system (cron job + evaluation) | DATA_ACCURACY_REPORT.md: 8 active rules, triggerReevalJob runs every 5 min | WORKING (code runs; 0 completions) |
| Trigger deduplication (2 mechanisms) | verified-findings.md F1: TriggerService.ts:856-871 (checkLeadCommunication), idleLeadChecker.ts:406-439 (hasActiveConversation) | VERIFIED in code |
| TextMagic per-org credentials | verified-findings.md F1: TextMagicService.ts:223-232 (getConfig from textmagic_config table), line 330 (decryptApiKey) | VERIFIED in code |
| Widget tools (7 at system level) | verified-findings.md F1: WidgetConfigService.ts line 241: 7 tools in chatEnabledTools array | VERIFIED in code |
| Unified widget (Preact bundle) | ACCEPTANCE_VERIFICATION_REPORT.md AC-6: 50.13KB minified, 19 configs, 6 channels, domain whitelist | WORKING |
| Security primitives (JWT, RLS, RBAC, encryption) | health-audit.md Section 11: Helmet, rate limiting, bcrypt, JWT, 53 RLS policies. REVERSE_SRS_old.md Section 1: "Security primitives well-implemented" | WORKING |
| Email via Resend | ACCEPTANCE_VERIFICATION_REPORT.md AC-3: "Settings -> Email tab + Work Center -> Communication tab" | WORKING |
| TypeScript strict mode compiles | health-audit.md Section 7.1: strict = true, noEmit = true. Multiple sources confirm `npm run check` passes. | WORKING |
| E2E test suite | health-audit.md Section 2: 747 test cases across 46 files | EXISTS (pass rate not recently verified) |
| 4-tier RBAC | ACCEPTANCE_VERIFICATION_REPORT.md AC-8: ROLE_VISIBILITY matrix, sidebar filtering, server middleware | WORKING |
| Context Router | IMPLEMENTATION_PLAN.md AC cross-reference: "AC-006: ALREADY CERTIFIED (build-verified)" | CLAIMED WORKING |
| Agent CRUD + org isolation | ACCEPTANCE_VERIFICATION_REPORT.md AC-9: 12 active agents (5 voice, 2 chat, 4 task) | WORKING |
| Credit system | CARRY_FORWARD_MANIFEST.md: useCredits.ts hook PRESERVE. CLAUDE.md (preflight-input): "Phase 6: Credit Wiring COMPLETE" | WORKING (code exists; 0 credits recorded per DATA_ACCURACY_REPORT.md) |
| Notification system | CLAUDE.md (preflight-input): "Phase 7: Notifications System COMPLETE" | CLAIMED COMPLETE |
| Google Calendar OAuth | CLAUDE.md (preflight-input): "Phase 17: Google Calendar OAuth COMPLETE" | CLAIMED COMPLETE |
| Drive / file management | CLAUDE.md (preflight-input): "Phase 18: Drive & Artifacts COMPLETE" | CLAIMED COMPLETE |
| Hunches & Approvals | CLAUDE.md (preflight-input): "Phase 19: Hunches & Approvals COMPLETE" | CLAIMED COMPLETE |
| Goals integration | CLAUDE.md (preflight-input): "Phase 16: Goals Integration COMPLETE" | CLAIMED COMPLETE |
| Tracking pixel | CLAUDE.md (preflight-input): "Phase 13: Tracking Pixel COMPLETE" | CLAIMED COMPLETE |
| AI Governance Stage 1 | CLAUDE.md (preflight-input): "Phase 15: AI Governance Stage 1 COMPLETE" | CLAIMED COMPLETE |

**Note on CLAIMED items:** The preflight CLAUDE.md lists many phases as COMPLETE. These were marked complete before the rollback to commit 95c0290 and Phase 9 testing. Some may have been lost in the rollback. Current codebase state must be verified against the RUI and AC, not against these claims.

---

## Section 4: Broken Features (Built But Not Working)

| Feature | What's Broken | Evidence | Impact |
|---------|--------------|----------|--------|
| VAPI webhook call ingestion | `call.started` never received for real calls; `handleEndOfCallReport` cannot INSERT, only UPDATE. All 137 real DB records are bulk imports, not webhooks. | DATA_ACCURACY_REPORT.md "Root Cause Analysis" | Calls being processed but data lost. Transcripts, credits, notifications all fail silently. |
| Tavus video session capture | Zero V2 callback URLs configured on any Tavus conversation. Zero video agents registered with tavus_persona_id. `resolveOrganizationId()` would fail. | DATA_ACCURACY_REPORT.md "Tavus" section: 0 of 136 conversations have V2 callback | No video data enters the platform |
| Production trigger execution | `lead_age_minutes >= 5` evaluated at import time when lead is 0 min old. Needs delayed re-evaluation. 0/84 executions completed. | DATA_ACCURACY_REPORT.md "Trigger Execution History" + "Root Cause" | Outbound calls and SMS never fire for real leads |
| Hosted pages (public) | Route mismatch: client -> `/api/hosted-pages/public/${slug}`, server -> `/api/pages/:slug` | verified-findings.md F2: hosted-page-public.tsx:163 vs routes.ts:175 | All hosted pages return 404 |
| VIN sync runtime success | 0/22 successful VIN syncs at runtime (P1) | release_criteria.md | Leads not actually reaching VIN CRM |
| Agent performance metrics | updatePerformanceMetrics() defined but never called from webhooks | IMPLEMENTATION_PLAN.md Phase 3 Item 3.1 (GAP-1) | Agent metrics always zero |
| Insights page stability | 4 unsafe array accesses crash when data is empty | verified-findings.md F3: insights.tsx lines 854, 1293, 2142, 2143 | TypeError if any metric array is empty |
| Notification delivery for appointments | updateAppointment() has no event hooks; no appointment_status_change event type | verified-findings.md F1: GAP-B5-STATUS-001. release_criteria.md line 70. | Status changes are silent |

---

## Section 5: Missing Features (Specified But Not Built)

| Feature | Where Specified | Status | Notes |
|---------|----------------|--------|-------|
| MetricsEngine unified service | IMPLEMENTATION_PLAN.md Phase 4: "Create unified MetricsEngine service" | NOT BUILT (Phase 4 never started) | Metrics fragmented across 5 services. MetricsEngine.ts file exists per DO_NOT_TOUCH.md but may be a stub. |
| Combined cross-platform metrics | IMPLEMENTATION_PLAN.md Phase 6 | NOT BUILT | Depends on MetricsEngine |
| SMS business hours routing | IMPLEMENTATION_PLAN.md Phase 5: "After-hours / business-hours routing logic" | PARTIALLY BUILT | Migration 032_sms_business_hours.sql exists. Business logic may not be wired. |
| SMS collision avoidance state machine | IMPLEMENTATION_PLAN.md Phase 5 Item 5.3 | PARTIALLY BUILT | sms_conversation_state table exists per ACCEPTANCE_VERIFICATION_REPORT.md AC-2. Full state machine may not be complete. |
| Activity feed CSV export | IMPLEMENTATION_PLAN.md Phase 7 Item 7.1 (GAP-5) | NOT BUILT | |
| Mark Contacted -> VIN API write-back | IMPLEMENTATION_PLAN.md Phase 3 Item 3.2 (GAP-2) | NOT WIRED | Button exists in Work Center but only updates local DB |
| VAPI Analytics API integration | IMPLEMENTATION_PLAN.md Phase 3 Item 3.3 (GAP-7) | NOT BUILT | |
| Availability validation for AI bookings | verified-findings.md GAP-B5-AVAIL-001 | NOT BUILT | Owner decision needed on priority |
| Web scraping skill | session-knowledge.md Section 0: "web scraping will be added as a skill (not implemented yet)" | NOT BUILT | Future, not launch-critical |
| Custom agent creation by users | session-knowledge.md Section 0c: "NOT launch-critical" | PARTIALLY BUILT | Agent CRUD exists but not prioritized for demo |
| Skills configuration/catalog | session-knowledge.md Section 0b: user-selectable skills on agents | PARTIALLY BUILT | Agents page has skill option per session-knowledge.md, but completeness unknown |

---

## Section 6: Tainted Claims (Must NOT Re-Enter Gap List)

**Source:** verified-findings.md F1. These 8 findings from Phase 9 Run 2 are WRONG due to architectural misunderstanding. They must be excluded from any future gap tracking.

| # | Gap ID | Run 2 Claim | Why Wrong | Verification Source |
|---|--------|-------------|-----------|---------------------|
| 1 | GAP-B1-AGENT-001 | Serra Nissan: no chat agent | Automa IS the chat agent on homepage/popout | Owner statement, session-knowledge.md 0b |
| 2 | GAP-B1-AGENT-002 | Tony Serra Ford: no chat agent | Same as above | Owner statement |
| 3 | GAP-B1-AGENT-003 | Ford of Columbia: no chat agent | Same as above | Owner statement |
| 4 | GAP-B1-SKILLS-001 | No tools on any agent (tools=[]) | Tools at widget/system level, not per-agent | WidgetConfigService.ts line 241: 7 tools |
| 5 | GAP-B1-INSTR-001 | Lead Follow-Up lacks CRM instructions | Measured raw DB field, not skill overlay system | session-knowledge.md 0b: skills are prompt overlays |
| 6 | GAP-B1-INSTR-002 | 15-min idle trigger not in instructions | Same — instructions include skill overlay context | Owner statement |
| 7 | GAP-B1-TRIGGER-001 | No trigger dedup for active conversations | TWO dedup mechanisms exist | TriggerService.ts:856-871, idleLeadChecker.ts:406-439 |
| 8 | GAP-B3-SMS-001 | TextMagic API returns 401 | Tested .env creds; service uses per-org DB creds | TextMagicService.ts:223-232, line 330 |

**Additionally tainted:** 2 resolved by owner decision:
- GAP-B5-VIN-SYNC-001: VIN has no calendar API; platform calendar is standalone
- GAP-B5-BIDIR-001: Same as above

**The Run 2 readiness score of 22/100 is SIGNIFICANTLY WRONG** (verified-findings.md F9).

---

## Section 7: Dependencies & Prerequisites

### For Demo Readiness (payment-critical items):

| Dependency | Blocks | Source |
|------------|--------|--------|
| Fix hosted pages route (1 line) | Widget demo (hosted pages mode) | verified-findings.md F2 |
| Fix insights.tsx null guards (4 lines) | Metrics & Insights demo | verified-findings.md F3 |
| Fix VAPI webhook UPSERT | Lead pipeline, trigger execution, credit recording | DATA_ACCURACY_REPORT.md P0 recommendation |
| Fix trigger delayed re-evaluation | Proactive lead follow-up demo | DATA_ACCURACY_REPORT.md: lead_age_minutes issue |
| Register Tavus personas in agents table | Video agent demo | DATA_ACCURACY_REPORT.md Tavus P0 |
| Update Tavus callback URLs to V2 | Video session data capture | DATA_ACCURACY_REPORT.md Tavus P0 |
| VAPI phone numbers per org | Outbound call triggering | CUSTOMER_ONBOARDING_KICKOFF.md Item 2 |
| Activate trigger rules | Live outbound calls/SMS | CUSTOMER_ONBOARDING_KICKOFF.md Item 3 |
| Stabilize PM2 process | Reliability for all webhook events | DATA_ACCURACY_REPORT.md: 3,247 restarts |
| Appointment event hooks | Appointment notification demo | verified-findings.md GAP-B5-STATUS-001 |

### For Governance Resolution:

| Dependency | Blocks | Source |
|------------|--------|--------|
| Owner updates CLAUDE.md on disk (chmod 444) | Correct agent behavior for all future sessions | failure-analysis.md B2 |
| Resolve 3 AC files into 1 authoritative | Agent trust in truth hierarchy | failure-analysis.md D1 |
| Write owner's architecture knowledge to files | Prevent future tainted findings | failure-analysis.md A1-A4 |
| Decide on quality verification agent role | Sprint lifecycle quality assurance | failure-analysis.md H1-H4 |

### For Build Sequencing (IMPLEMENTATION_PLAN.md "Dependencies"):

```
Phase 1 (Critical Fixes) ----+
                               |
Phase 2 (Data Integrity) ----+----> Phase 4 (Metrics Consolidation) ----> Phase 6 (Combined Metrics)
                               |
Phase 3 (Wiring Gaps) --------+
                                                                                     |
Phase 5 (SMS Enhancement) -----------------------------------------> Phase 7 (Certification)
                                                                                     |
                                                                              Phase 8 (Deployment)
```

Critical path: Phase 2 -> Phase 3 -> Phase 4 -> Phase 6 -> Phase 7 -> Phase 8

---

## Section 8: Sprint/Phase History

### Build History (from health-audit.md, CLAUDE.md preflight-input):

| Period | Activity | Commits | Source |
|--------|----------|---------|--------|
| 2026-01-21 to 2026-01-24 | Project ramp-up | 9 | health-audit.md 3.2 |
| 2026-01-24 to 2026-01-31 | Early development | 8 | health-audit.md 3.2 |
| 2026-01-31 to 2026-02-07 | Peak sprint (MVP push) | 63 | health-audit.md 3.2 |
| 2026-02-02 | MVP deployed | — | CLAUDE.md (preflight-input) |
| 2026-02-07 to 2026-02-14 | Peak sprint (stabilization) | 66 | health-audit.md 3.2 |
| 2026-02-14 to 2026-02-21 | Post-stabilization | 35 | health-audit.md 3.2 |
| 2026-02-16 | "Second Wave Fresh Start" alignment | — | CLAUDE.md (preflight-input) |
| 2026-02-18 | Governing docs created (CONSTITUTION, MASTER_SRS, IMPLEMENTATION_PLAN) | — | File dates |
| 2026-02-19 | ACCEPTANCE_VERIFICATION_REPORT + DATA_ACCURACY_REPORT | — | File dates |
| 2026-02-21 | Forensic audits (health, server, client, database, docs) | — | File dates |
| 2026-02-22 | /init run (Tier 3), created .project/ layer | — | session-knowledge.md Section 1 |
| 2026-02-22 | DO_NOT_TOUCH + UNIFIED_HANDOFF_PROMPT + CARRY_FORWARD_MANIFEST written | — | File dates |
| 2026-03-01 | Enforcer bootstrap, .agent_docs/ layer created | — | session-knowledge.md Section 1 |
| 2026-03-01 | Phase 9 Run 2 executed (~40% tainted) | — | verified-findings.md, MEMORY.md |
| 2026-03-02 | Fact-finding session, failure analysis, preflight surgery plan | — | Workbench files |

### Phases Completed (per CLAUDE.md preflight-input, CLAIMED):

Phases 6-20 all marked COMPLETE. However, these claims predate the rollback to commit 95c0290 and Phase 9 testing. The DATA_ACCURACY_REPORT and verified-findings.md show several "completed" features are not actually working in production.

### Deviations from Plan:

1. **IMPLEMENTATION_PLAN.md was never executed.** It was written on 2026-02-18 as a forward-looking plan. Phases 1-8 in that document have NOT been started. The phases marked "COMPLETE" in CLAUDE.md are from a DIFFERENT numbering system (post-MVP roadmap phases 6-20). These two numbering systems are NOT the same plan. (VERIFIED: IMPLEMENTATION_PLAN.md Section "Phasing Strategy" line 2: "Phase numbers start at 1. There are no inherited phase numbers from prior plans.")

2. **The rollback to commit 95c0290** invalidated some prior work but preserved working backend code. The rollback was a response to 31 unauthorized commits during the gatekeeper incident. (MEMORY.md)

3. **/init created a parallel governance system** on 2026-02-22 that was never reconciled with the existing filestore/ governance or the enforcer's .agent_docs/ layer. (session-knowledge.md Section 1)

---

## Section 9: Environment Status

### Deployment Infrastructure (health-audit.md Section 6, DO_NOT_TOUCH.md):

| Component | Status | Evidence |
|-----------|--------|----------|
| Live URL | https://nexxusv2.huminicdev.com | health-audit.md Section 1 |
| Platform | Linux 5.15.0-1081-oracle (Oracle Cloud) | health-audit.md 6.3 |
| Node.js | v20.19.5 | health-audit.md 6.3 |
| PM2 | 6.0.13, process nexxus-v2 (PID 1616575) | health-audit.md 6.1 |
| PM2 restarts | 3,327 (avg ~107/day) | health-audit.md 6.1 |
| PM2 memory | 148.9 MB | health-audit.md 6.1 |
| Database | Supabase (PostgreSQL on AWS us-west-2) | REVERSE_SRS_old.md 3.1 |
| Reverse proxy | Caddy (managed by sysadmin) | health-audit.md 6.5 |
| SSL | External (managed by sysadmin) | health-audit.md 6.5 |
| Docker | NOT USED | health-audit.md 6.5 |
| CI/CD | NOT CONFIGURED | health-audit.md 6.5 |
| Deploy script | deploy.sh (master-only, no rollback, no health check) | health-audit.md 6.2 |

### Service Connectivity:

| Service | Status | Evidence |
|---------|--------|----------|
| VIN Solutions OAuth | WORKING (3/5 orgs) | DATA_ACCURACY_REPORT.md: tokens refreshing, last sync Feb 19 |
| VIN Solutions API | PARTIAL (17/30 endpoints blocked with 403) | UNIFIED_HANDOFF_PROMPT.md Lesson 1 |
| VAPI webhooks | RECEIVING (but INSERT broken) | DATA_ACCURACY_REPORT.md: PM2 logs show events |
| VAPI API (calls) | WORKING | DATA_ACCURACY_REPORT.md: 832 total calls on account |
| Tavus webhooks | NOT RECEIVING (no V2 callbacks configured) | DATA_ACCURACY_REPORT.md: 0 V2 callback URLs |
| Tavus API | WORKING | DATA_ACCURACY_REPORT.md: 136 conversations queryable |
| TextMagic | CONFIGURED (per-org DB creds) but UNTESTED | DATA_ACCURACY_REPORT.md G-6: 0 successful sends |
| Resend (email) | WORKING | ACCEPTANCE_VERIFICATION_REPORT.md AC-3 |
| Claude API (DealerBrain) | WORKING | ACCEPTANCE_VERIFICATION_REPORT.md: chat functional |
| Google Calendar | CONFIGURED | CLAUDE.md (preflight-input): Phase 17 COMPLETE |
| Central-MCP | EXISTS (port 4002) but no TextMagic connector | MEMORY.md: "No TextMagic connector exists yet" |

### Database Status:

| Metric | Value | Source |
|--------|-------|--------|
| Tables | 53 | REVERSE_SRS_old.md 3.1.1 |
| Migrations | 33 (001-033, 011 missing) | REVERSE_SRS_old.md 3.1.2, DO_NOT_TOUCH.md Section 11 |
| RLS policies | ~100 | REVERSE_SRS_old.md 3.1.3 |
| RLS variable name mismatch | `app.current_organization_id` (SecureQueryBuilder) vs `app.current_org_id` (policies) | UNIFIED_HANDOFF_PROMPT.md Lesson 4 |
| Known vulnerability | `xlsx` package: 2 high-severity CVEs, no fix available | health-audit.md 4.5 |

### Build System:

| Check | Status | Source |
|-------|--------|--------|
| `npm run check` (TypeScript) | PASSES | ACCEPTANCE_VERIFICATION_REPORT.md Quality Gates |
| `npm run build` (production build) | PASSES | ACCEPTANCE_VERIFICATION_REPORT.md Quality Gates |
| E2E test suite (747 tests) | EXISTS (last full run status unknown post-rollback) | health-audit.md Section 2 |
| Unit tests | ZERO | health-audit.md 2.5: "MISSING — No configuration, no files" |
| Linter | NOT CONFIGURED | health-audit.md 7.3 |

---

## Section 10: Owner Decisions Needed

| # | Decision | Context | Options | Urgency | Source |
|---|----------|---------|---------|---------|--------|
| 1 | Update CLAUDE.md on disk | File is chmod 444, pre-enforcer content. New sessions read wrong rules. | Owner must manually edit. | HIGH | failure-analysis.md B2, verified-findings.md F5 |
| 2 | Which AC file is authoritative? | 3 files (89KB + 58KB + 49KB) each claim authority. | Pick one, archive others. Surgery will create new consolidated AC at root. | HIGH | failure-analysis.md D1, verified-findings.md F4 |
| 3 | Is availability validation required for launch? | No bounds checking on AI-booked appointments. | Accept risk for demo OR build validation. | MEDIUM | verified-findings.md GAP-B5-AVAIL-001 |
| 4 | Are Ford/Hyundai Columbia VIN-integrated? | No VIN config for these orgs. May be intentional. | (a) These orgs don't use VIN, (b) Config needs adding. | MEDIUM | verified-findings.md GAP-B1-VIN-001/002, CUSTOMER_ONBOARDING_KICKOFF.md Items 7-9 |
| 5 | How to restore quality verification loop? | Gatekeeper archived. Enforcer doesn't do sprint-level quality. | (a) Restore gatekeeper function in new agent, (b) Add quality loop to enforcer, (c) Owner does manual QA. | HIGH | failure-analysis.md H1-H4, session-knowledge.md Section 4 |
| 6 | What's the archive folder path? | Owner has archive folder outside nexxus-v2 for deprecated files. Path not provided. | Owner provides path. | LOW | MEMORY.md: "get path" |
| 7 | Trigger activation preferences per customer | System has templates ready but all 15 trigger rules deactivated. | Customer decisions needed per CUSTOMER_ONBOARDING_KICKOFF.md Items 3-4. | HIGH (for demo) | CUSTOMER_ONBOARDING_KICKOFF.md, DATA_ACCURACY_REPORT.md |
| 8 | Customer website domains for widget deployment | Widget embed only works on whitelisted domains, currently localhost. | Customers must provide domains. | MEDIUM | CUSTOMER_ONBOARDING_KICKOFF.md Item 1 |
| 9 | VAPI phone number selection per org | Required for outbound call triggers. Must purchase/register in VAPI dashboard. | Huminic purchases, dealership approves area code. | HIGH (for demo) | CUSTOMER_ONBOARDING_KICKOFF.md Item 2 |
| 10 | Lead source tagging for VIN insertion | How should AI-generated leads appear in VIN Solutions? | "Nexxus AI", "Phone - AI", "Internet - Chatbot", or match existing CRM sources. | MEDIUM | CUSTOMER_ONBOARDING_KICKOFF.md Decision 3 |

---

## Watch Areas

### 1. Agent Functionality/Defaults

**Current State (VERIFIED):**
- 12 active agents: 5 voice (VAPI assistant IDs linked), 2 chat, 4 task, 0 video (ACCEPTANCE_VERIFICATION_REPORT.md AC-9)
- Automa is the master assistant / chat agent on homepage — always at top of agents list (app_identity.md B2, session-knowledge.md 0)
- V2 architecture: users CREATE agents and ADD skills (not 27 hardcoded agents like V1) — session-knowledge.md 0b
- Skills = pre-prompting overlays on Automa/super chat with context and instructions (session-knowledge.md 0b)
- Agent CRUD API with org isolation works (ACCEPTANCE_VERIFICATION_REPORT.md AC-9)
- Only 1 of 5 defined agent .md files exists (enforcer.md). Orchestrator and 3 builders DO NOT EXIST (verified-findings.md F6)

**Gaps:**
- 0 video agents registered with Tavus persona IDs (DATA_ACCURACY_REPORT.md Tavus section)
- Agent status toggle bypasses provisioning (release_criteria.md GAP-B1-STATUS-BYPASS-001)
- Legacy agent names block seed (release_criteria.md GAP-B6-AGENT-NAME-001)
- updatePerformanceMetrics() defined but never called (IMPLEMENTATION_PLAN.md Phase 3, GAP-1)
- `hot_lead` event type has no firing call site (ACCEPTANCE_VERIFICATION_REPORT.md AC-11 Note)

### 2. Billing

**Current State (VERIFIED):**
- Credit system code exists: CreditService, credit_policies, credit_allocations, credit_usage tables (DO_NOT_TOUCH.md Section 3)
- Revenue model documented: Voice $0.25/min (40% margin), Video $0.32/min (37.5%), SMS $0.05/msg (60%) (REVERSE_SRS_old.md 2.2, app_identity.md)
- Credit balance, usage, and policy hooks all marked PRESERVE (CARRY_FORWARD_MANIFEST.md Section 3a)
- Credits page UI intentionally deferred (IMPLEMENTATION_PLAN.md "Excluded Items": "Business decision to expose billing UI")

**Gaps:**
- 0 credits recorded on any VAPI call record (DATA_ACCURACY_REPORT.md: `credit_recorded = true` = 0 of 137)
- 0 notifications sent on any VAPI call record (DATA_ACCURACY_REPORT.md: `notification_sent = true` = 0 of 137)
- Root cause: bulk imports happened before credit/notification logic existed; idempotency guards on UPDATE path fail when row doesn't exist
- Service quotas table exists (migration 031) but utilization unknown

### 3. Unified Inbox Handoff

**Current State (VERIFIED):**
- InboxService exists with conversations, messages, assignment (DO_NOT_TOUCH.md Section 3)
- inbox_conversations and inbox_messages tables exist (REVERSE_SRS_old.md 3.1.1)
- Staff messaging inbox: useInbox hook with conversations, messages, assign, status, unread count (CARRY_FORWARD_MANIFEST.md Section 3a)
- Widget-initiated conversations can continue in unified inbox (session-knowledge.md 0: "Externally-initiated conversations via widget can be continued internally in the Unified Inbox")
- 21 inbox conversations in last 7 days (DATA_ACCURACY_REPORT.md "Agent Activity")

**Gaps:**
- Email missing from Hub/inbox (CLARIFICATION_ANSWERS.md Q12: "email missing, no SMS communication visible")
- SMS conversation visibility in inbox unclear
- Handoff from external agent to internal staff follow-up is the intended architecture (session-knowledge.md 0) but verification status unknown

### 4. Super Admin Functionality

**Current State (CLAIMED-BUT-UNVERIFIED):**
- Super Admin role level 1 with full platform access (CONSTITUTION.md Section 2.3)
- 14 admin API endpoints for user/org CRUD, partner links, roles, locations (UNIFIED_HANDOFF_PROMPT.md Section 3.2)
- useAdmin hook marked PRESERVE with extensive CRUD operations (CARRY_FORWARD_MANIFEST.md Section 3a)
- DealerBrain config CRUD is Super Admin only (CARRY_FORWARD_MANIFEST.md: useDealerBrainConfig)

**Gaps:**
- Super Admin cannot view other orgs' data (release_criteria.md GAP-B6-SA-DATA-001: OPEN)
- Owner says Super Admin is "undertested" (session-knowledge.md 0d)
- No evidence of Super Admin-specific test coverage beyond RBAC regression suite (41 tests in sprint-r4-rbac.spec.ts per health-audit.md 2.2)

### 5. Context Router Functionality

**Current State (VERIFIED):**
- Context Router service exists: ContextRouterService.ts, SourceSelector.ts, CacheManager.ts (DO_NOT_TOUCH.md Section 3)
- context_router_tables migration (003) exists (DO_NOT_TOUCH.md Section 11)
- IMPLEMENTATION_PLAN.md AC cross-reference: "AC-006: Context Router Refactor — ALREADY CERTIFIED (build-verified)"
- CLARIFICATION_ANSWERS.md Q3: owner defers technical implementation; must be careful about API rate limiting

**Gaps:**
- CacheManager.ts still contains false "48-hour API retention limit" comment (IMPLEMENTATION_PLAN.md Phase 1 Item 1.6: DATA-3)
- Stale doc comments reference old SRS v3.0 instead of MASTER_SRS (IMPLEMENTATION_PLAN.md Phase 1 Item 1.6)
- Context Router's role in combining VIN + local data sources needs clear documentation for agents (session-knowledge.md: "Context Router — how it works, what it routes, how it decides. Needs clear documentation.")
- Daily refresh + manual button model decided but implementation status unknown (CLARIFICATION_ANSWERS.md Q4-Q5)

---

## Conflicts Found

| # | Conflict | File A | File B | Resolution |
|---|----------|--------|--------|------------|
| C1 | AC file authority: 3 files claim governance | docs/ACCEPTANCE_CRITERIA.md (89KB) | .agent_docs/acceptance_criteria.md (58KB, PLACEHOLDER) + filestore/1b_ACCEPTANCE_CRITERIA.md (49KB) | Owner must pick one. Surgery creates new consolidated AC at root. (verified-findings.md F4) |
| C2 | CLAUDE.md on disk vs system prompt | CLAUDE.md at commit 95c0290 (pre-enforcer) | System prompt cache (has enforcer rules) | Owner must manually update file. (verified-findings.md F5) |
| C3 | P0 count: Run 1 vs Run 2 | release_criteria.md: "All 12 P0 Gaps FIXED" | FINAL_REPORT.md: "17-22 P0 blockers, 22/100 readiness" | Both wrong. Actual: 3-7 P0s. (verified-findings.md F9) |
| C4 | Work tree claims AC reconciliation COMPLETED | .agent_docs/work_tree.md | .agent_docs/acceptance_criteria.md: explicitly PLACEHOLDER | work_tree.md is wrong. (failure-analysis.md E1) |
| C5 | IMPLEMENTATION_PLAN phase numbers vs CLAUDE.md phase numbers | IMPLEMENTATION_PLAN.md: Phases 1-8 (NOT started) | CLAUDE.md: Phases 6-20 (claimed COMPLETE) | Different numbering systems. IMPLEMENTATION_PLAN phases start fresh. (IMPLEMENTATION_PLAN.md "Phasing Strategy") |
| C6 | Acceptance Verification Report (13/13 PASS) vs actual state | ACCEPTANCE_VERIFICATION_REPORT.md: all PASS | DATA_ACCURACY_REPORT.md + verified-findings.md: multiple items broken | Report was point-in-time (Feb 19). Subsequent findings show issues. |
| C7 | 3 governance layers (.project/ vs .agent_docs/ vs filestore/) | .project/implementation_plan.md (8 BDD sprints) | .agent_docs/plan_sequence.md (phases 0-4) + filestore/release_criteria.md (gap tracker) | Surgery plan: gut .project/, keep .agent_docs/, create 6 root files. (session-knowledge.md Section 1) |
| C8 | health-audit.md says 36 tables; REVERSE_SRS_old.md says 53 | health-audit.md: "Tables (per CLAUDE.md) 36" | REVERSE_SRS_old.md 3.1.1: "Total tables defined in migrations: 53" | 53 is correct. 36 was stale CLAUDE.md info. |

---

## Missing Information

| # | What's Missing | Why It Matters | Where It Should Be | Source |
|---|----------------|---------------|-------------------|--------|
| M1 | V1-to-V2 architecture narrative (skills model, Automa as chat agent) | Prevents future tainted findings | SRS.md or PRD.md | session-knowledge.md 0, 0b |
| M2 | TextMagic per-org credential model documentation | Agent tested wrong creds in Run 2 | SRS.md or SPEC.md | failure-analysis.md A2 |
| M3 | Trigger deduplication mechanism documentation | Agent claimed no dedup in Run 2 | SRS.md or SPEC.md | failure-analysis.md A3 |
| M4 | Widget tools documentation (7 system-level tools) | Agent claimed no tools in Run 2 | SRS.md or SPEC.md | failure-analysis.md A4 |
| M5 | Owner's mental model of platform (section 0 of session-knowledge.md) | Never written in any file before this session | PRD.md opening section | session-knowledge.md 0: "This model was never written in any document before" |
| M6 | PM2 ecosystem config file | Process config is non-reproducible | ecosystem.config.cjs at project root | health-audit.md 6.1 |
| M7 | .env.example or .env.template | New sessions cannot verify env setup | Project root | health-audit.md 6.4 |
| M8 | Context Router operational documentation | Agents don't understand routing logic | SPEC.md | session-knowledge.md 0d |
| M9 | Billing operational documentation | How credits flow, what's tracked, what's missing | SPEC.md or SRS.md | session-knowledge.md 0d |
| M10 | Super Admin functional scope documentation | Undertested, owner has focused on customer-facing | SPEC.md or AC | session-knowledge.md 0d |

---

## Cross-Wave Notes

### From Wave 1 (PRD extraction):
- PRD content is scattered across app_identity.md, CLARIFICATION_ANSWERS.md, owner verbal explanations, and the RUI mockup (Current_State.md.md line 9-12)
- Platform identity clearly stated in app_identity.md Sections A1-A7 but never consolidated into a single PRD

### From Wave 2 (SRS extraction):
- SRS-level content lives in the 89KB ACCEPTANCE_CRITERIA.md (docs/) and MASTER_SRS.md (257 requirements)
- MASTER_SRS.md (2026-02-18) is the most recent governing SRS but was written before the data accuracy findings and Phase 9 testing
- The "below the line" system behaviors (credential handling, dedup, trigger mechanics) are NOT in any doc agents read

### From Wave 3 (SPEC extraction):
- No SPEC.md exists currently (session-knowledge.md Section 2: "We don't have a SPEC.md")
- Architecture info scattered across ARCHITECTURE_GUIDE.md, ARCHITECTURE_VISUAL_MAP.md, REVERSE_SRS_old.md, DO_NOT_TOUCH.md
- CARRY_FORWARD_MANIFEST.md is the most practical build reference (32 preserve files, API contracts, hook inventory)

### From Wave 4 (AC extraction):
- Owner's 13-item demo AC (Acceptance Criteria.md lines 6-19) is the most direct expression of what customer payment requires
- session-knowledge.md Section 0c refines this to 7 payment-critical capabilities
- AC should mirror test battery structure (Standards.md lines 4-7: "acceptance criteria is the inverse of the testing batteries")

### For PLAN.md:
- PLAN.md must contain: current phase, prioritized gap list, what's done, what's next (session-knowledge.md Section 2)
- It is NOT the same as /plan mode scratchpad files (session-knowledge.md Section 2: "PLAN.md is a permanent project file — the roadmap, read every session")
- Must evaluate every gap against: "Does this block the demo?" (session-knowledge.md Section 0c)
- Owner's watch areas (agent defaults, billing, unified inbox, super admin, context router) must be tracked in PLAN

---

## Source File Log

| File | Location | Lines Read | Key Extractions |
|------|----------|-----------|-----------------|
| session-knowledge.md | workbench root | Full (240 lines) | Sections 0-8: platform mental model, skills architecture, payment-critical items, watch areas, /init impact, file structure, test batteries, gatekeeper gap, real P0s, tainted findings, file sprawl |
| file-inventory.md | workbench root | Full (145 lines) | 53 file inventory with flags, categories, priorities |
| verified-findings.md | workbench root | Full (293 lines) | F0-F11: gap tracker identity, P0 verification (8 tainted, 2 resolved, 3 real, 4 need verification), route mismatch, insights crash, AC conflict, CLAUDE.md mismatch, agent team files, MEMORY.md broken refs, docs/ assessment, report conflict, actual blockers, remediation items |
| failure-analysis.md | workbench root | Full (105 lines) | 31 items across 8 categories: A (knowledge), B (unresolved flags), C (enforcer scope), D (file sprawl), E (misrepresented status), F (unauthorized actions), G (structural design), H (gatekeeper removal) |
| IMPLEMENTATION_PLAN.md | preflight-input | Full (814 lines) | 8 phases, 19 ACs mapped, dependency chain, risk register, excluded items, AC cross-reference |
| ACCEPTANCE_VERIFICATION_REPORT.md | preflight-input | Full (137 lines) | 13/13 AC PASS claim (partially refuted), operational items, quality gates |
| DATA_ACCURACY_REPORT.md | preflight-input | Full (552 lines) | VAPI: 72% calls missing, INSERT broken; Tavus: 0 real sessions; VIN: 99% active coverage; triggers: 0 completions; PM2: 3,247 restarts |
| health-audit.md | preflight-input | Full (753 lines) | 402 files, 117K LOC, 747 E2E tests, 0 unit tests, 380 `any` types, 242 console.log, 7 vulnerabilities, 3,327 PM2 restarts, no CI/CD |
| DO_NOT_TOUCH.md | preflight-input | Full (662 lines) | 345+ frozen files inventory, 88 server files, 38 DB files, 17 widget files, 65 test files, safe-to-modify client/ scope |
| REVERSE_SRS_old.md | preflight-input | First 200 lines | 53 tables (corrects 36 claim), YELLOW health, 7 integrations, 8 scheduled jobs |
| CARRY_FORWARD_MANIFEST.md | preflight-input | First 200 lines | 32 PRESERVE files (API client, auth, 25 hooks, SSE), 8 REFERENCE, 11 REPLACEABLE |
| UNIFIED_HANDOFF_PROMPT.md | preflight-input | First 200 lines | 6-tier document reading order, frozen backend rules, lessons learned (VIN header casing, RLS mismatch) |
| CLAUDE.md (preflight-input) | preflight-input | Full (356 lines) | Pre-enforcer version, phases 6-20 claimed complete, project structure, deployment workflow |
| CONSTITUTION.md | preflight-input | First 100 lines | Truth hierarchy (VIN > VAPI/Tavus > Local > Derived), honest AI, RBAC, data accuracy, certification |
| app_identity.md | preflight-input | First 100 lines | Platform identity, partner model, customer problem, success criteria, navigation/workflow |
| -- Acceptance Criteria.md | preflight-input | First 150 lines | Owner's 13-item demo AC + full RUI mockup AC spec (Global Shell, Main Page, Insights, etc.) |
| CUSTOMER_ONBOARDING_KICKOFF.md | preflight-input | First 100 lines | Per-customer readiness checklist, 6 common needs, Columbia-specific needs, 5 customer decisions |
| CLARIFICATION_ANSWERS.md | preflight-input | Full (150 lines) | 20 owner decisions: VIN write-back, webhooks, context router, data warehouse, metrics, widget, SMS, triggers |
| Current_State.md.md | other_notes | Full (139 lines) | 3-layer governance conflict analysis, /init impact, context usage data |
| known_issues.md.md | other_notes | First 200 lines | Run 2 P0 verification narrative, enforcer analysis, owner dialogue |
| opinions_facts.md.md | other_notes | Full (68 lines) | Owner's facts (8 checkable items), suspicions (7 hypotheses), suggestions (7 rules) |
| Standards.md | other_notes | Full (261 lines) | Owner's doc type definitions (PRD=strategy, SRS=precision, SPEC=build logic, PLAN=execution, AC=testable), outline templates |
| Forensics.md.md | other_notes | Full (79 lines) | Evidence framework: 6 verified observations, 4 derived findings, non-verified claims, structural conditions |

---

*End of Wave 5 REVIEWER extraction. Ready for reconciliation with ANALYST output.*
