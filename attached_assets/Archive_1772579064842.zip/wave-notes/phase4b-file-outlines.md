# Phase 4b: File Structure Agreement

**Date:** 2026-03-03
**Input:** Wave reconciled notes (6), ground-truth-diff.md, phase4-triage.md, RUI navigation structure
**Purpose:** Agree on section outlines for all 6 governance files before drafting begins.

---

## Design Principles

1. **Organized by product capability area** — not by demo items, not by sprint history
2. **Above-the-line / below-the-line mapping** — each capability shows what users see and what powers it
3. **RUI is structural truth** — navigation sections from the Reference UI define the capability areas
4. **Each file serves a distinct audience:**
   - PRD → Owner, stakeholders (plain language, business context)
   - SRS → Owner + technical staff (system behavior narratives)
   - SPEC → Developer/agent (architecture reference, exact paths and configs)
   - AC → Tester/agent (pass/fail criteria per feature)
   - PLAN → Agent + owner (current marching orders, gap status)
   - CLAUDE.md → Agent only (operating rules, constraints, conventions)

---

## RUI Navigation Structure (Tier 1 Truth)

The Reference UI defines these main sections:

| Route | Label | Sub-Sections |
|-------|-------|-------------|
| `/` | Main | Dashboard tiles + Automa Chat |
| `/insights` | Insights | Dashboard, Reports (3 types × 3 sub-reports), Library (34 metrics), Hunches |
| `/agents` | Agents | Agent list + chat pane, Agent create |
| `/work-center` | Hub | Calendar (year/month/week/day), Leads (list + detail), Inbox (email/sms/voicemail) |
| `/drive` | Drive | File browser (grid/list), Templates |
| `/activity` | Activity | Activity feed with filters (All/User/Agent/System) |
| `/profile` | Profile | My Profile, Preferences, Billing |
| `/settings/system` | Settings | Users, Organization, Tools & Integrations, Knowledge Base, AI Config, Security, Notifications, Data Management, Appearance |
| `/w/:slug` | Widgets | External: Hosted page, Embedded, Unified (bottom corner) |
| Public | Auth | Login, Forgot Password, Reset Password |

---

## File 1: PRD.md — Product Requirements Document

**Audience:** Owner, stakeholders, anyone asking "what is this product?"
**Tone:** Plain language, business-focused, no code references

### Proposed Outline

```
# Nexxus V2 — Product Requirements Document

## 1. Product Identity
   - What Nexxus V2 is (AI-powered dealership engagement platform)
   - What it is NOT (not a CRM, not a DMS — companion to existing tools)
   - Target users (dealership staff: org admins, managers, staff)
   - Value proposition (AI agents handle routine engagement, staff focus on selling)

## 2. Platform Capabilities

### 2.1 Main — Command Center
   Above: Dashboard metric tiles, Automa Chat (always-available AI assistant)
   Below: DealerPulse metrics collection, real-time data aggregation

### 2.2 Insights — Analytics & Intelligence
   Above: Dashboard gauges, Reports (Loss/Channel/Trend), Metric Library, Hunches
   Below: Hunch generation engine, metric calculation, report aggregation

### 2.3 Agents — AI Workforce
   Above: Agent roster, chat interface per agent, favorites
   Below: LLM routing, tool execution (24 tools), skill overlay system, SSE streaming

### 2.4 Hub — Daily Operations
   Above: Calendar (appointments), Leads (active pipeline), Inbox (cross-channel messaging)
   Below: VIN Solutions polling, lead import/sync, appointment sync, trigger evaluation

### 2.5 Drive — Document Management
   Above: File browser, templates, sharing
   Below: File storage, permission enforcement

### 2.6 Widgets — External Deployment
   Above: 3 deployment modes (hosted page, embedded, unified corner widget)
   Below: Domain whitelisting, agent routing, conversation management

### 2.7 Settings — Configuration
   Above: 9 settings tiles (Users, Org, Tools, Knowledge, AI, Security, Notifications, Data, Appearance)
   Below: RBAC enforcement, integration credential management

### 2.8 Activity — Audit Trail
   Above: Activity feed with user/agent/system filtering
   Below: Event logging, search indexing

## 3. External Integration Ecosystem
   - VIN Solutions (CRM — lead polling, note writing)
   - VAPI (voice AI — inbound/outbound calls)
   - TextMagic (SMS — outbound messaging)
   - Tavus (video AI — persona-based video agents)
   - Resend (email — transactional and notification)
   - Central-MCP (infrastructure — MCP proxy for external services)

## 4. User Roles & Access
   - Role hierarchy (Super Admin → Partner Admin → Org Admin → Manager → Staff)
   - Multi-org isolation
   - What each role can see and do

## 5. Business Rules & Constraints
   - No vendor names visible to users (AC-016)
   - Widget branding per org, not platform-branded
   - VIN Solutions limitations (no calendar API, 403-blocked endpoints)
   - VAPI economics ($0.15/min cost, $0.25/min charge)
   - Multi-tenant isolation (org-level data separation)

## 6. Non-Goals (Explicitly Out of Scope)
   - Nexxus is not replacing VIN Solutions
   - Nexxus is not a standalone CRM
   - Mobile native app (web-responsive only)
```

**Notes:**
- Each capability section maps directly to a RUI navigation item
- "Below" items explain what powers the feature without technical detail
- Business rules section captures constraints the agent must respect

---

## File 2: SRS.md — System Requirements Specification

**Audience:** Owner + technical staff understanding system behavior
**Tone:** Behavioral narratives — "when X happens, the system does Y"

### Proposed Outline

```
# Nexxus V2 — System Requirements Specification

## 1. System Overview
   - Architecture pattern (Express + React SPA, PostgreSQL, external service integrations)
   - Request flow (client → API → service → database / external service)
   - Authentication flow (JWT-based, session management)

## 2. Capability Behaviors

### 2.1 Automa Chat
   Above: User sends message → Automa responds with CRM-aware context
   Below: Message → DealerBrainService → Claude API → tool calls (24 tools) → SSE stream → response
   - Tool inventory and what each does
   - Context window management
   - Skill overlay system (how skills modify agent behavior)

### 2.2 Insights & Metrics
   Above: Dashboard shows gauges, reports, hunches
   Below: DealerPulse job → polls metrics at interval → stores snapshots
   - Metric calculation flows
   - Hunch generation pipeline
   - Report data aggregation
   - 34 metrics in library with definitions

### 2.3 Agent Management
   Above: Create/edit/delete agents, chat with each
   Below: Agent CRUD → database → skills attachment → widget association
   - Agent-to-widget relationship
   - Persona system (instructions, temperature, model)
   - Tool assignment at system level (not per-agent)

### 2.4 Hub — Calendar
   Above: View/create/edit appointments across day/week/month/year
   Below: AppointmentService → database → notifications → VIN note sync
   - Appointment lifecycle (create → update → notify → VIN sync)
   - Status change behaviors

### 2.5 Hub — Leads
   Above: View leads, open detail, initiate call/text, mark contacted
   Below: VIN polling → lead import → dedup → trigger evaluation → action execution
   - Lead import pipeline (VIN Solutions polling every N minutes)
   - Lead status transitions
   - Dedup mechanisms (phone + email matching)

### 2.6 Hub — Inbox
   Above: Filter by channel, read/reply to messages across email/SMS/voicemail
   Below: Inbound routing (TextMagic webhook → SMS, Resend webhook → email, VAPI → voicemail)
   - Cross-channel conversation threading
   - After-hours routing decisions

### 2.7 Trigger System
   - Event types (7 canonical names with definitions)
   - Condition evaluation (lead age, score, status, business hours)
   - Action types (5 canonical names with definitions)
   - Execution pipeline: event → match rules → evaluate conditions → execute action
   - Dedup mechanisms (execution log + idle trigger count)
   - Business hours handling

### 2.8 Widget System
   - 3 deployment modes and how each renders
   - Domain whitelisting enforcement
   - Widget-to-agent routing
   - Conversation lifecycle in widget context

### 2.9 Drive
   - File CRUD operations
   - Permission model (read/comment/edit)
   - Template system
   - 10-level folder nesting

### 2.10 Settings & Configuration
   - RBAC tile visibility rules
   - Integration credential flow (per-org DB storage, not .env)
   - Knowledge base management
   - Widget configuration pipeline

## 3. Webhook Specifications
   - VAPI webhook events and handling
   - TextMagic webhook events and handling
   - Tavus callback events and handling

## 4. Background Jobs
   - DealerPulse (metrics collection)
   - VIN Solutions polling (lead import)
   - Idle lead checker (trigger follow-up)
   - Scheduled trigger evaluation

## 5. Data Flow Diagrams
   - New lead: VIN → poll → import → trigger → action (call/SMS)
   - Inbound call: VAPI → webhook → call record → transcript → notification
   - Inbound SMS: TextMagic → webhook → routing → AI response (if after-hours)
   - Widget chat: User → widget → agent → LLM → response

## 6. Error Handling & Degradation
   - VIN Solutions unavailable: queue operations, retry
   - VAPI service down: graceful fallback
   - Database connection loss: connection pooling behavior
```

**Notes:**
- Behavioral, not architectural — "when X happens" language
- Event and action type names MUST be canonical (resolved from wave conflicts)
- Trigger system gets its own section because it spans multiple UI areas

---

## File 3: SPEC.md — Architecture Specification

**Audience:** Developer/agent writing or modifying code
**Tone:** Technical reference — exact file paths, service names, configuration

### Proposed Outline

```
# Nexxus V2 — Architecture Specification

## 1. Technology Stack
   ### Frontend
   - Vite, React 18, TypeScript, Wouter (routing)
   - TanStack Query (data fetching), shadcn/ui (47 primitives)
   - Tailwind CSS v4 (615 lines custom), Recharts (charts)
   - Responsive breakpoints (actual values from code)

   ### Backend
   - Node.js v20.19.5, Express.js 5, TypeScript
   - PostgreSQL (Neon), Drizzle ORM
   - esbuild (server bundling)

   ### External Services
   - VIN Solutions, VAPI, Tavus, TextMagic, Resend, Anthropic (Claude)

## 2. Project Structure
   - Directory layout (server/, client/, shared/)
   - Key configuration files (.env, drizzle.config.ts, vite.config.ts)
   - Build output locations

## 3. Frontend Architecture
   - Route registration (App.tsx)
   - Component hierarchy (layout → pages → sections → components)
   - State management (TanStack Query + React context)
   - API client pattern (api.ts wrapper)
   - Theme contract (CSS variables, color system)

## 4. Backend Architecture
   ### Route Registration
   - Route file inventory (routes.ts master registration)
   - Middleware chain (auth, JSON parsing, CORS)

   ### Service Layer
   - Service inventory (40+ services with one-line descriptions)
   - Service-to-route mapping

   ### Database
   - Schema overview (53 tables, key relationships)
   - Migration system (Drizzle)
   - RLS policy structure
   - Connection pooling configuration

## 5. Integration Architecture
   ### VIN Solutions
   - Polling mechanism, API endpoints used
   - Authentication (per-org credentials in DB)
   - Known limitations (17/30 endpoints blocked)

   ### VAPI
   - Webhook endpoint and payload format
   - Assistant registration
   - Call lifecycle events
   - Cost tracking

   ### TextMagic
   - Per-org credential storage (textmagic_config table)
   - SMS send flow
   - Webhook handling

   ### Tavus
   - Persona configuration
   - Video session lifecycle
   - Callback handling

## 6. Security Model
   - JWT authentication
   - RBAC role hierarchy
   - RLS policies (and the current bypass)
   - Webhook security (VAPI soft-check issue)
   - Helmet/CSP configuration

## 7. Deployment
   - PM2 process management
   - Port allocation (5020)
   - Caddy reverse proxy
   - Environment variables reference

## 8. Widget Build
   - Separate Vite build for widget bundle
   - Embed code generation
   - Hosted page rendering
   - Domain whitelisting enforcement
```

**Notes:**
- This is the reference the agent opens when it needs to find a service, route, or table
- File paths are exact — agent can navigate directly
- No behavioral descriptions (those go in SRS)

---

## File 4: ACCEPTANCE_CRITERIA.md

**Audience:** Tester/agent verifying features
**Tone:** Testable pass/fail statements

### Proposed Outline

```
# Nexxus V2 — Acceptance Criteria

## How to Read This File
   - Each AC has a unique ID (AC-NNN)
   - Format: "Given [context], when [action], then [expected result]"
   - Status: UNTESTED | PASS | FAIL | BLOCKED
   - Priority: LAUNCH-CRITICAL | IMPORTANT | NICE-TO-HAVE

## 1. Authentication & Access (AC-001 through AC-011)
   - Login flow, password reset, session management
   - Role-based access enforcement

## 2. Navigation & Layout (AC-012 through AC-026)
   - Sidebar items and order
   - Responsive behavior
   - Sub-panel behavior
   - Mobile navigation
   - No vendor names visible (AC-016)

## 3. Main — Automa Chat (AC-027 through AC-039)
   - Chat sends and receives messages
   - Tool calls execute correctly
   - SSE streaming works
   - Conversation history persists
   - Dashboard tiles show real data

## 4. Insights — Dashboard & Reports (AC-040 through AC-056)
   - Dashboard gauges render with data
   - Report tabs load correctly
   - Metric library searchable
   - Hunches display with confidence filtering
   - No crash on empty data (null guards)

## 5. Agents (AC-057 through AC-067)
   - Agent CRUD operations
   - Agent chat works
   - Favorites toggle
   - Agent-to-widget association

## 6. Hub — Calendar (AC-068 through AC-075)
   - Appointment CRUD
   - View mode switching (day/week/month/year)
   - Status change notifications
   - VIN note sync from appointments

## 7. Hub — Leads (AC-076 through AC-082)
   - Lead list displays imported leads
   - Lead detail modal opens
   - Call/text actions work
   - Lead status transitions

## 8. Hub — Inbox (AC-083 through AC-091)
   - Channel filtering (email/SMS/voicemail)
   - Message thread display
   - Reply/compose functionality
   - Read/unread filtering

## 9. Widgets (AC-092 through AC-103)
   - Hosted page renders at /w/:slug
   - Embedded widget loads on external site
   - Unified widget appears in corner
   - Domain whitelisting enforced
   - Widget connects to correct agent

## 10. Triggers (AC-104 through AC-111)
   - Trigger rule CRUD
   - Event matching works
   - Condition evaluation correct
   - Actions execute (call, SMS, email, notification)
   - Business hours respected
   - Dedup prevents duplicate actions

## 11. Drive (AC-112 through AC-116)
   - File upload/download
   - Folder creation
   - Sharing with permissions
   - Template management

## 12. Settings (AC-117 through AC-128)
   - Each settings tile accessible per role
   - User management CRUD
   - Organization profile editing
   - Integration credential management
   - Widget configuration
   - Knowledge base upload

## 13. Metrics & Scores (AC-129 through AC-138)
   - DealerPulse gauges show data
   - Metric calculations correct
   - Score thresholds respected

## 14. Notifications (AC-139 through AC-145)
   - In-app notifications appear
   - Notification preferences respected
   - Trigger-generated notifications delivered

## 15. Activity & Governance (AC-146 through AC-151+)
   - Activity feed logs events
   - Filter by type works
   - Search works
   - Audit trail complete
```

**Notes:**
- AC IDs are sequential and stable — tests reference them
- The 15 feature areas come directly from Wave 4 reconciled analysis (151 ACs)
- Each AC will have the Given/When/Then format for testability
- Status tracking allows the agent to mark results per test run

---

## File 5: PLAN.md — Execution Plan

**Audience:** Agent (primary), owner (review)
**Tone:** Marching orders — what to do next, what's done, what's deferred

### Proposed Outline

```
# Nexxus V2 — Execution Plan

## Current Phase
   - Phase name and objective
   - What cluster is in progress
   - Blocking issues (if any)

## Demo Readiness Summary
   | Demo Item | Status | Blocking Gaps |
   (7 items with current status — updated as work progresses)

## Incremental Build Clusters

### Cluster 0: Foundation Fixes
   - Gaps addressed, fix descriptions, done-when criteria

### Cluster 1: Metrics & Insights (DEMO-1)
   - Gaps, fixes, verification criteria

### Cluster 2: Automa Chat Verification (DEMO-7)
   - Verification checklist (no code changes expected)

### Cluster 3: Appointment Flow (DEMO-3)
   - Gaps, fixes, verification criteria

### Cluster 4: Trigger System (DEMO-2, foundation for DEMO-4/5)
   - Gaps, fixes, verification criteria

### Cluster 5: Proactive Follow-up (DEMO-4)
   - Gaps, fixes, operational config needed

### Cluster 6: After-Hours Coverage (DEMO-5)
   - Gaps, fixes, operational config needed

### Cluster 7: Widgets Verification (DEMO-6)
   - Verification checklist

## Gap Tracker
   | ID | Description | Severity | Cluster | Status |
   (All validated gaps from ground-truth-diff — each row updated as fixed)

## Operational Config Checklist
   | Config Item | Required For | Status |
   - VAPI phone numbers per org
   - TextMagic credentials per org
   - Business hours per org
   - Domain whitelisting per widget
   - VIN Solutions credentials per org

## Watch Areas (Not Demo-Blocking)
   1. Agent defaults and skills
   2. Billing flow
   3. Unified inbox handoff
   4. Super Admin capabilities
   5. Context Router

## Deferred Items (Can Wait)
   | Gap | Severity | Why Deferred |
   (Items from phase4-triage "can wait" list)

## Retired Claims (Do Not Re-Open)
   | Claim | Why Retired |
   (From ground-truth-diff Part 2 — prevents tainted findings from re-entering)
```

**Notes:**
- This is the file the agent reads every session to know what to work on
- Gap Tracker is the single source of truth for gap status (replaces release_criteria.md)
- Retired Claims section prevents the agent from re-reporting tainted findings
- Cluster structure enables incremental verification by owner

---

## File 6: CLAUDE.md — Agent Operating Rules

**Audience:** Agent only
**Tone:** Directive — rules, constraints, conventions

### Proposed Outline

```
# CLAUDE.md — Nexxus V2 Agent Operating Rules

## 1. Truth Hierarchy
   1. Reference UI (RUI) — visual truth, immutable, can add but never modify
   2. Acceptance Criteria (AC) — testable truth
   3. CLAUDE.md rules — operating constraints
   4. PRD — business context
   5. SRS — system behavior
   6. SPEC — architecture reference
   7. PLAN — current marching orders
   (Positions 4-7 need owner confirmation)

## 2. Every-Session Checklist
   - Files to read before any work
   - State to verify (branch, environment, PLAN.md status)

## 3. Governance File Map
   - What each file is for
   - When to reference each file
   - File locations

## 4. Development Workflow
   - Read PLAN.md → identify current cluster → fix gaps → test → update PLAN.md → loop
   - Cluster completion criteria
   - When to stop and report to owner

## 5. Agent Team
   - Enforcer role and responsibilities
   - Builder role and responsibilities
   - Communication protocol between agents

## 6. Architecture Facts
   - Agent architecture (Automa IS the chat agent)
   - Skills model (system-level, not per-agent DB field)
   - Tool assignment (widget_configs level)
   - TextMagic credentials (per-org DB, not .env)
   - Trigger dedup (two mechanisms)
   - VIN Solutions limitations

## 7. Code Conventions
   - TypeScript patterns
   - Service layer structure
   - Error handling approach
   - Configuration over hard-coding

## 8. Testing Protocol
   - Minimum test requirements before commit
   - Playwright battery structure
   - Evidence capture requirements

## 9. Prohibited Actions (28 rules)
   - Grouped by category: UI, architecture, data, process
   - Each with brief reason

## 10. File Management
   - What can be created/modified
   - What is read-only (CLAUDE.md is chmod 444)
   - Archive vs delete policy
   - .agent_docs/ usage rules

## 11. Operational Context
   - Port allocation (5020)
   - PM2 process management
   - Environment variables
   - Webhook endpoints

## 12. Vocabulary
   - Canonical event type names
   - Canonical action type names
   - Term definitions (Hub vs Work Center, etc.)
```

**Notes:**
- Section 6 (Architecture Facts) directly addresses the architectural misunderstandings that caused tainted findings
- Prohibited Actions are deduplicated from Wave 6 (28 unique rules)
- Truth hierarchy positions 4-7 still need owner confirmation from Wave 6 conflict

---

## Cross-File Relationship Map

```
PRD  ←→ "What and why"
 ↓
SRS  ←→ "How the system behaves"
 ↓
SPEC ←→ "Where things are in the code"
 ↓
AC   ←→ "How to verify it works"
 ↓
PLAN ←→ "What to do right now"
 ↓
CLAUDE.md ←→ "Rules for doing it"
```

Each file references others but doesn't duplicate content:
- PRD says "the system handles inbound SMS" → SRS describes the routing behavior → SPEC lists the webhook endpoint and service → AC has "given inbound SMS, when after hours, then AI responds" → PLAN tracks whether it works → CLAUDE.md says "don't hard-code TextMagic creds"

---

## Open Questions for Owner

1. **Truth hierarchy positions 4-7:** Wave 6 flagged a conflict between analyst and reviewer on the ordering of PRD, SRS, SPEC, PLAN, and audit files. Current proposal: PRD > SRS > SPEC > PLAN. Does this ranking work?

2. **Activity page placement:** Activity is a standalone page in the RUI (`/activity`) but Wave 4 had a disagreement about whether it should be a sub-tab of Insights. The RUI shows it standalone. Should it stay standalone in the governance files?

3. **Profile vs Settings:** The RUI has both `/profile` (with billing tab) and `/settings/system`. Is billing under Profile correct, or should it move to Settings?

4. **Do any sections need to be added or removed?** The outlines above cover all 15 feature areas from Wave 4 AC analysis and all RUI navigation items. Missing anything?
