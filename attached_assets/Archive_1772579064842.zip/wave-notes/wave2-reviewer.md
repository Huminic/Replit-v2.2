# Wave 2 — REVIEWER Extraction (System Behavior / SRS)

**Agent:** REVIEWER (independent from ANALYST)
**Date:** 2026-03-03
**Input Files Scanned:** 48 of 53 (skipped: Chat-Checklist.pdf [blank template], replit_reference.textClipping [binary], Insights Layout copy.md [duplicate], INSIGHT_CARDS_SPECIFICATION.md [superseded], NEXXUS_V2_BOOTSTRAP_PROMPT.md [executed session prompt])
**Purpose:** Extract all system behavior relevant to an SRS from the complete input corpus. Every claim cites source file and line/section.

---

## TABLE OF CONTENTS

1. [Data Flow Narratives](#1-data-flow-narratives)
2. [Trigger and Event Mechanics](#2-trigger-and-event-mechanics)
3. [Webhook Processing](#3-webhook-processing)
4. [Authentication and Authorization Mechanics](#4-authentication-and-authorization-mechanics)
5. [State Machines and Transitions](#5-state-machines-and-transitions)
6. [Integration Protocols](#6-integration-protocols)
7. [Context Router Behavior](#7-context-router-behavior)
8. [Below-the-Line Behavior](#8-below-the-line-behavior)
9. [Error Handling and Recovery](#9-error-handling-and-recovery)
10. [Security Mechanisms](#10-security-mechanisms)
11. [Notification Routing](#11-notification-routing)
12. [Credit and Usage Tracking](#12-credit-and-usage-tracking)
13. [Watch Area Findings](#13-watch-area-findings)
14. [Conflicts Detected](#14-conflicts-detected)
15. [Missing Information](#15-missing-information)
16. [Cross-Wave Notes from Wave 1 — Verification](#16-cross-wave-notes-from-wave-1--verification)

---

## 1. Data Flow Narratives

### 1.1 Voice Call to Lead Creation

**Source:** REVERSE_SRS_old.md Section 5.2 (lines ~400-450), DATA_ACCURACY_REPORT.md (lines 30-100), CUSTOMER_ONBOARDING_KICKOFF.md (lines 88-137)

Flow:
1. VAPI call ends → webhook fires to `/api/webhooks/vapi`
2. `resolveOrganizationId()` checks `metadata.organizationId`, then `assistantId` lookup in `voice_agents` table
3. If `end-of-call-report` event: `handleEndOfCallReport()` → attempts UPDATE on existing call record → if no row found, skips (designed to UPDATE, not INSERT)
4. If `call.started` event: should INSERT initial row — but this event is never received for production calls
5. When lead data extracted: inserts into `leads` table → inserts into `sync_queue` with `action: 'create_lead'`
6. SyncCoordinator picks from `sync_queue` (1-min interval outbound) → 2-step VIN API process:
   a. Create contact via gateway POST → returns ContactId
   b. Create lead with href references (contactUrl, leadSourceUrl, leadTypeUrl)
7. VIN API requires lowercase `v3` media type header and href-format references, not string names

**CRITICAL ISSUE:** Real-time ingestion is broken. `call.started` never arrives for production calls, so `handleEndOfCallReport` UPDATE finds no row to update. Result: 832 VAPI API calls vs 159 local DB records; all 137 post-V2-deploy records were from manual bulk import, not live webhooks. (DATA_ACCURACY_REPORT.md lines 58-82)

**VIN Sync Bug:** 12/12 sync jobs failed in production. Root cause: `leadSource` field sent as string ("Phone") but VIN API expects href URL reference (`/leadSources/id/36`). Must query `/leadSources?dealerId=X` first to get valid hrefs. (CUSTOMER_ONBOARDING_KICKOFF.md lines 128-137, DEVELOPMENT_TEAM_BRIEFING.md lines 50-65)

### 1.2 DealerBrain Query Flow

**Source:** REVERSE_SRS_old.md Section 5.3 (lines ~450-500), CARRY_FORWARD_MANIFEST.md Section 4 (lines 99-118)

Flow:
1. User sends message via chat UI → `POST /api/conversations/{id}/stream`
2. Server opens SSE stream with event types: `thinking`, `tool_start`, `tool_end`, `token`, `done`, `error`
3. DealerBrainService sends to Claude API with 24 tools available
4. If tool call involves VIN data: Context Router SourceSelector checks VIN API first (primary), falls back to local DB
5. CacheManager: 5-min VIN cache, 1-hr VAPI/Tavus cache
6. Response streamed token-by-token to client
7. Goal awareness injected into Claude context (if goals configured for org)

**SSE Protocol Details (CARRY_FORWARD_MANIFEST.md lines 106-118):**
- Auth: Bearer token header
- Body: `{ content: string }`
- Event types with payloads:
  - `thinking`: `{ type, message }`
  - `tool_start`: `{ type, toolName, toolDescription }`
  - `tool_end`: `{ type, toolName, success, summary, chartData? }`
  - `token`: `{ type, content }`
  - `done`: `{ type, tokensUsed: { input, output }, toolCalls? }`
  - `error`: `{ type, message }`

### 1.3 Widget Chat to Staff Inbox

**Source:** REVERSE_SRS_old.md Section 5.4 (lines ~500-540), Nexxus_SRS_Addendum_v3.2 (lines ~200-350)

Flow:
1. Customer opens widget on external website → widget loads from `nexxusv2.huminicdev.com/widget/nexxus-widget.js?code=WIDGET_CODE`
2. Widget presents channel options: text chat, voice inbound, voice outbound, video agent, web audio, send a text
3. For text chat: conversation created in `inbox_conversations` table → assigned to AI
4. AI handles conversation (Claude Haiku)
5. If AI cannot resolve OR human takes over: conversation status changes, appears in staff Unified Inbox
6. Staff continues from where agent left off — continuity between external and internal surfaces

**Widget = Portal to Agent:** session-knowledge.md lines 17-21 — widgets are not standalone features, they are portals to VAPI/Tavus/internal agents. External conversations can be continued internally in Unified Inbox.

### 1.4 Metrics Data Flow

**Source:** app_identity.md Section G (lines 258-296), DATA_ACCURACY_REPORT.md (lines 1-50), CONSTITUTION.md (lines ~80-100)

Data enters metrics from 4 sources:
1. **VIN Solutions** — query-only Lead Management API, polled every 60 min with 48-hr window
2. **Internal DB** — lead records, call logs, video sessions, task completions
3. **External Services** — VAPI call data, Tavus session data (via webhooks)
4. **User Uploads** — Excel/CSV backfill for data VIN API cannot provide

**Truth Hierarchy (CONSTITUTION.md lines ~80-100):**
1. VIN Solutions API (highest)
2. VAPI/Tavus APIs
3. Local Database
4. Derived Metrics (lowest)

**Excel Upload Exclusion:** All 32+ lead-related queries exclude `source = 'excel_upload'` records. 691 records filtered out. (DATA_ACCURACY_REPORT.md lines ~150-170)

### 1.5 Appointment Flow

**Source:** CUSTOMER_ONBOARDING_KICKOFF.md Section 3, CLARIFICATION_ANSWERS.md lines ~30-50, UI_INTERACTIVE_ELEMENTS_MAP.md lines 75-88

Flow:
1. Appointment created (by user via calendar, or by voice agent)
2. Stored in `appointments` table
3. Appears in Work Center Calendar
4. Lead should be inserted into VIN Solutions with appointment note (CLARIFICATION_ANSWERS.md)
5. Appointment reminder job runs every 5 minutes (server-audit.md)
6. Google Calendar sync available via OAuth (useGoogleCalendar hook)
7. **CRITICAL GAP:** `updateAppointment()` fires zero status change events — no SMS or notification sent when appointment status changes (known_issues.md.md line 11)

---

## 2. Trigger and Event Mechanics

**Source:** REVERSE_SRS_old.md Section 5.5 (lines ~540-590), server-audit.md (lines ~400-450), ACCEPTANCE_VERIFICATION_REPORT.md (lines 95-100), Nexxus_SRS_Addendum_v3.2 (lines ~450-550)

### 2.1 Trigger Architecture

**7 Event Types:**
1. `new_lead` — fires when lead created
2. `lead_status_change` — fires on lead status update
3. `hot_lead` — defined but **no call site exists in codebase** (ACCEPTANCE_VERIFICATION_REPORT.md line 100)
4. `appointment_created` / `appointment_scheduled`
5. `missed_call` — fires on unanswered inbound
6. `widget_interaction` — fires on widget engagement
7. `sms_received` — fires on inbound SMS

**5 Action Types:**
1. `outbound_call` — VAPI `POST /call` with assistantOverrides
2. `send_sms` — TextMagic API
3. `send_notification` / `send_email` — Resend email
4. `create_task` — internal task creation
5. `assign_lead` / `webhook` — mentioned in varying documents

### 2.2 Trigger Execution Pipeline

1. Event fires → TriggerService evaluates active rules for org
2. Checks: business hours (per org timezone), rate limiting (per trigger rule), prior-contact detection
3. If conditions met → executes action
4. Re-evaluation job runs every 5 minutes for age-based conditions (e.g., "if no contact after 2 hours")

### 2.3 Trigger Deduplication

**Source:** session-knowledge.md lines 209-210, verified-findings.md

Two mechanisms exist in code:
1. `notification_sent` column with atomic `UPDATE...WHERE notification_sent = false RETURNING *` pattern
2. `credit_recorded` column with same atomic pattern

These prevent duplicate processing. Prior agent reported "no trigger dedup" — this was tainted by architectural misunderstanding.

### 2.4 Production Status

**Source:** DATA_ACCURACY_REPORT.md lines ~300-350

- 8 active trigger rules in production DB
- 0/84 executions completed
- 45 failed, 39 skipped (all from E2E tests, not production)
- Likely causes: missing VAPI phoneNumberId per org, business hours restrictions, or rate limits

---

## 3. Webhook Processing

### 3.1 VAPI Webhooks

**Source:** REVERSE_SRS_old.md Section 5.2, server-audit.md (lines ~300-350), DATA_ACCURACY_REPORT.md (lines 30-100)

**Endpoint:** `POST /api/webhooks/vapi`

**Org Resolution:** `resolveOrganizationId()` — checks `metadata.organizationId` first, then `assistantId` lookup in `voice_agents` table

**Events Processed:**
- `call.started` — should INSERT initial call record (BROKEN: never received in production)
- `call.ended` — UPDATE call record with duration, end status
- `end-of-call-report` — UPDATE with transcript, summary, recording URL; extract lead data; queue VIN sync
- `transcript` — append to call transcript
- `status-update` — update call status

**Idempotency:** `notification_sent` and `credit_recorded` boolean columns with atomic `UPDATE...WHERE...RETURNING` pattern

**PM2 Restart Impact:** PM2 restarted 3,247 times (DATA_ACCURACY_REPORT.md line ~90). Each restart could lose in-flight webhook processing.

### 3.2 Tavus Webhooks

**Source:** REVERSE_SRS_old.md (lines ~600-650), DATA_ACCURACY_REPORT.md (lines 100-150)

**Endpoint:** `POST /api/webhooks/tavus`
**Authentication:** HMAC-SHA256 with 5-minute timestamp tolerance

**Events Processed:**
- `conversation.started` — create session record
- `conversation.ended` — update with duration, end status
- `replica.ready` — update persona status
- `video.ready` — update with video URL

**Production Status:** Zero real sessions captured. 136 Tavus API conversations vs 1 seed record in local DB. Root causes:
- No V2 callback URLs configured in Tavus
- No video agents registered in DB (0 of type 'video')
- 47 conversations had undefined callback URL

### 3.3 TextMagic SMS Webhook

**Source:** Nexxus_SRS_Addendum_v3.2 (lines ~250-300)

**Endpoint:** `POST /api/webhooks/textmagic`
**Processing:** Inbound SMS → route to org via phone number lookup → create/update conversation → AI auto-reply (Claude Haiku) if in AI_ACTIVE state

---

## 4. Authentication and Authorization Mechanics

### 4.1 JWT Architecture

**Source:** UNIFIED_HANDOFF_PROMPT.md (lines ~200-250), CARRY_FORWARD_MANIFEST.md Section 5 (lines 121-132), server-audit.md (lines ~150-200)

**Token Types:**
- Access token: 24-hour expiry
- Refresh token: 7-day expiry
- Appointment confirmation token: 48-hour expiry, `nexxus-appointment` audience

**localStorage Keys:** `nexxus_access_token`, `nexxus_refresh_token`, `nexxus_token_expiry`, `nexxus_accessible_orgs`

**Auth Endpoints:**
- `POST /api/auth/login` — returns access + refresh tokens
- `POST /api/auth/refresh` — exchange refresh for new access token
- `GET /api/auth/me` — get current user
- `POST /api/auth/switch-org` — returns new tokens scoped to target org
- `POST /api/auth/logout` — invalidate session

**Client Auto-Refresh:** Every 60 seconds, checks if within 5 minutes of expiry. If so, calls refresh endpoint. (CARRY_FORWARD_MANIFEST.md lines 45-46)

**No separate token service file exists.** All token management embedded in AuthContext.tsx.

### 4.2 RBAC — 4-Tier Role Hierarchy

**Source:** MASTER_SRS.md Section 3 (RBAC), ARCHITECTURE_GUIDE_RBAC_ADDITION.md (complete), app_identity.md Section D (lines 165-182)

| Level | Role | Capabilities |
|-------|------|-------------|
| 1 | Super Admin | System-wide access, partner management, tool provisioning, org creation, billing |
| 2 | Partner Admin | Manages assigned orgs, views resource utilization, creates orgs within partnership |
| 3 | Org Admin | User management within org, agent creation, settings configuration |
| 4 | Org Staff | Uses agents, views insights, accesses work hub, chat with Automa |

**Role-Level Mapping (CARRY_FORWARD_MANIFEST.md line 51):**
`1=super_admin, 2=partner_admin, 3=org_admin, 4+=org_staff`

**Server Enforcement:** `requireRole()` middleware enforces role hierarchy on API endpoints (client-audit.md line 172)

**Client Enforcement:** `ROLE_VISIBILITY` map controls which dashboard sections each role sees. Tab-level RBAC within settings page. Sidebar items role-gated. (client-audit.md lines 174-178)

**Partner Entity (ARCHITECTURE_GUIDE_RBAC_ADDITION.md):**
- `partners` table with credit_pool
- `partner_org_assignments` table links partners to orgs
- `user_org_assignments` table with per-org role
- Tool provisioning flows: Super Admin → provisions → Partner Admin → manages orgs → Org Admin → uses

**Multi-Org Behavior:** Org Admin can belong to multiple orgs. Org switcher available. Unresolved design question: multi-org data queries behavior. (app_identity.md line 177)

### 4.3 Route Protection

**Source:** client-audit.md Section 3 (lines 109-179)

- Public routes (no auth): `/login`, `/forgot-password`, `/reset-password`, `/w/:slug`
- Protected routes (13 active): all wrap in `<ProtectedRoute><AppLayout>...</AppLayout></ProtectedRoute>`
- ProtectedRoute shows spinner while loading, redirects to `/login` if not authenticated
- No route-level RBAC — role restrictions applied at component/tab level within pages

---

## 5. State Machines and Transitions

### 5.1 SMS Conversation State Machine

**Source:** Nexxus_SRS_Addendum_v3.2 (lines ~280-310), database-audit.md (migration 032), ACCEPTANCE_VERIFICATION_REPORT.md line 44

**States:**
- `DORMANT` — no active conversation
- `AI_ACTIVE` — AI is handling the conversation
- `HUMAN_ACTIVE` — staff has taken over

**Transitions:**
- Inbound SMS on dormant conversation → `AI_ACTIVE`
- AI response loop continues in `AI_ACTIVE`
- Staff claims conversation → `HUMAN_ACTIVE`
- Timeout (configurable) → `DORMANT`

**Implementation Status:** Schema exists in `sms_conversation_state` table (migration 032). State constants referenced in ACCEPTANCE_VERIFICATION_REPORT.md. **State machine transition logic is NOT fully implemented in code** — schema defines the states but the runtime enforcement of transitions is incomplete.

### 5.2 Lead Status Lifecycle

**Source:** —Tiles - Available data..md (lines 68-78), DATA_SOURCE_INVENTORY.md

**VIN Solutions Status Types (5):**
- ACTIVE — lead in pipeline
- SOLD — deal closed
- LOST — deal lost (38 granular sub-statuses)
- BAD — junk lead (sub-statuses: BAD_BAD_OR_NO_CONTACT_INFORMATION, BAD_DUPLICATE, etc.)
- (Unknown/Other)

**Lead Group Categories (3):**
- NEW — uncontacted
- WAITING — ball in customer's court
- CONTACTED — engaged

### 5.3 Trigger Execution States

**Source:** Agent Instructions.md (lines 276-290)

- CREATED → ASSIGNED → IN_PROGRESS → REVIEW → VALIDATED → DONE
- Alternate path: IN_PROGRESS → BLOCKED → (resolved) → REVIEW

### 5.4 Inbox Conversation States

**Source:** Nexxus_SRS_Addendum_v3.2 (lines ~300-340), CARRY_FORWARD_MANIFEST.md line 75

States managed via `useInboxConversations` hook: open, assigned, resolved, archived. Status transitions via `useUpdateConversationStatus`.

---

## 6. Integration Protocols

### 6.1 VIN Solutions

**Source:** VIN_SOLUTIONS_INTEGRATION.md (lines 1-359), DEVELOPMENT_TEAM_BRIEFING.md (lines 30-80), DATA_SOURCE_INVENTORY.md

**Auth:** OAuth2 Client Credentials flow
- Token endpoint: `https://api.vinsolutions.com/oauth2/token`
- Token lifetime: 3600s documented, 3922s+ observed empirically (VIN_SOLUTIONS_INTEGRATION.md line ~120)
- Refresh job: every 30 minutes, refreshes if within 10 minutes of expiry
- Storage: AES-256-GCM encrypted in `vin_credentials` table, PBKDF2 with 100K iterations, SHA-256

**API Access (DATA_SOURCE_INVENTORY.md):**
- 13 endpoints accessible (leads, contacts, lead sources, lead types, lead groups, dealers, users, inventory partial)
- 17 endpoints blocked (activities, deals, tasks, RO, notes — most return 403)
- Gateway endpoints use `application/json`; newer endpoints use `application/vnd.coxauto.v3+json` (LOWERCASE v3)

**Critical Implementation Details (DEVELOPMENT_TEAM_BRIEFING.md):**
- Lead creation is 2-step: create contact (gateway POST) → create lead with href references
- `contactUrl` format: `/contacts/id/{ContactId}?dealerid={dealerId}` — must include `dealerid` query param
- Header casing: media type must use lowercase `v3` — production rejects uppercase `V3`
- `dealerId` goes in query param, not body

**VIN Lead Polling:** Every 60 minutes, queries leads from last 48 hours by `modifiedUtc`. 293,859 total API leads vs 775 local (0.26% coverage — by design). Deduplication via `vin_customer_id` (0 duplicates detected). (DATA_ACCURACY_REPORT.md lines 150-200)

### 6.2 VAPI (Voice)

**Source:** app_identity.md Section E2 (lines 204-215), CLARIFICATION_ANSWERS.md, DATA_SOURCE_INVENTORY.md

- Master API key, assistants tagged with org metadata
- Each org has a voice assistant with ID, phone number, and name in DB
- Webhooks receive call data (see Section 3.1)
- MCP connectivity from VAPI to Nexxus was in V1 but disconnected in V2 (app_identity.md line 211)
- Outbound calls via `POST https://api.vapi.ai/call` with `assistantOverrides`
- 16 API endpoints available, 15 accessible (DATA_SOURCE_INVENTORY.md)

### 6.3 Tavus (Video)

**Source:** app_identity.md Section E3 (lines 217-219), DATA_ACCURACY_REPORT.md lines 100-150

- Master API key, personas tagged with org metadata
- 11 API endpoints available, 10 accessible (DATA_SOURCE_INVENTORY.md)
- Widget tech may not be finished (app_identity.md line 219)
- Zero production sessions captured — no callback URLs configured, no video agents in DB

### 6.4 TextMagic (SMS)

**Source:** Nexxus_SRS_Addendum_v3.2 (lines ~200-280), DEVELOPMENT_TEAM_BRIEFING.md

- Per-org credentials stored in database (NOT .env) — this was a misunderstanding source in prior testing
- E.164 phone format required (`+` prefix)
- Phone `18338096836` shared across 3 orgs — first DB match wins routing (ACCEPTANCE_VERIFICATION_REPORT.md line 45)
- Outbound-only currently. SMS responses via webhook. AI auto-reply via Claude Haiku.
- STOP keyword handling for compliance (Nexxus_SRS_Addendum_v3.2)

### 6.5 Resend (Email)

**Source:** app_identity.md Section E7 (line 234), ACCEPTANCE_VERIFICATION_REPORT.md line 50

- Used for all outbound email notifications
- Email system accessible in Settings (IMAP/SMTP config) and Work Center (InboxPanel)
- 7 API endpoints: inbox, folders, messages, send, reply, settings, test-connection
- No inbound response mechanism built yet

### 6.6 Claude API (DealerBrain)

**Source:** REVERSE_SRS_old.md Section 5.3, DATA_SOURCE_INVENTORY.md

- @anthropic-ai/sdk v0.72.1
- 24 DealerBrain tools documented
- SSE streaming for real-time responses
- DealerBrainProcessor middleware (Stage 1: monitoring only, no enforcement)
- Goal awareness injected into context

### 6.7 Google Calendar

**Source:** CARRY_FORWARD_MANIFEST.md line 78

- OAuth connection via `useGoogleCalendar` hook
- Connect/disconnect/sync/push appointment/toggle sync
- CalendarConnectionStatus type

---

## 7. Context Router Behavior

**Source:** REVERSE_SRS_old.md Section 5.7 (lines ~650-700), app_identity.md Section G2 (lines 271-278), DEVELOPMENT_TEAM_BRIEFING.md (lines 100-120), CLARIFICATION_ANSWERS.md

### 7.1 Architecture

Components:
1. **SourceSelector** — determines where to get data. VIN API = primary source, local DB = fallback
2. **CacheManager** — 5-min cache for VIN data, 1-hr cache for VAPI/Tavus data
3. **Source Tagging** — labels data by origin (internal display only — tags not shown to end users)

### 7.2 Behavior Rules

- Queries VIN API first for lead/CRM data
- Falls back to local DB if VIN unavailable
- Excludes `excel_upload` records across 32+ queries
- Source labels: `vapi_voice` → "Voice Agent", `tavus_video` → "Video Agent", etc.
- Tags are for internal tracking — external surfaces show clean display names

### 7.3 Known Issues

- Context Router "was inverted" at some point — VIN was fallback instead of primary (DEVELOPMENT_TEAM_BRIEFING.md line ~110). This was corrected.
- Excel upload pollution: 691 records polluted metrics until exclusion filters added
- Router needs expansion for non-lead data types (wave1-reconciled.md cross-wave note)

### 7.4 Design Intent (Owner-stated)

From app_identity.md Section C7 (lines 155-157):
- Context Router should be aware of information from various sources
- Tags data appropriately
- Tracks capabilities and weaknesses of each data source
- Should have 3 clear sections: Memory stores, Sync Data, Upload Data Store and Web/3rd party data store (===DevDesign Notes===.md line 41)

---

## 8. Below-the-Line Behavior

### 8.1 Scheduled Background Jobs

**Source:** REVERSE_SRS_old.md (lines ~750-800), server-audit.md (lines ~450-500)

| Job | Interval | Purpose |
|-----|----------|---------|
| VIN Token Refresh | 30 min | Refresh OAuth tokens nearing expiry (10-min threshold) |
| Sync Queue Worker (outbound) | 1 min | Process lead creation queue to VIN API |
| Sync Queue Worker (inbound) | 4 hrs | Pull VIN leads from last 48 hours |
| Appointment Reminder | 5 min | Send reminders for upcoming appointments |
| Email Sync | 5 min | IMAP folder synchronization |
| Trigger Re-evaluation | 5 min | Re-check age-based trigger conditions |
| Dealer Pulse | 4 hrs | Refresh VIN API dashboard gauges |
| Hunch Generation | 6 hrs | AI-generated insights from lead data |

All use native `setInterval` with singleton guards (boolean flag prevents overlapping runs) and staggered startup delays.

### 8.2 VIN Token Encryption

**Source:** VIN_SOLUTIONS_INTEGRATION.md (lines 100-150)

- Algorithm: AES-256-GCM
- Key derivation: PBKDF2 with 100K iterations, SHA-256 digest
- Storage: `vin_credentials` table with encrypted `access_token` and `refresh_token` columns
- Audit trail: `vin_audit_log` table with 5 action types (token_refresh, api_call, sync_started, sync_completed, error)

### 8.3 Widget Bundle Serving

**Source:** ACCEPTANCE_VERIFICATION_REPORT.md (lines 65-70)

- Preact-based bundle: 50.13 KB minified
- Served at `/widget/nexxus-widget.js?code=WIDGET_CODE`
- Domain whitelist enforcement for external embedding
- Rate limited: 100 requests/hr/IP
- 19 active widget configs across orgs

### 8.4 Database Layer

**Source:** database-audit.md (lines 1-500), DEVELOPMENT_TEAM_BRIEFING.md (lines 80-95)

- `SecureQueryBuilder` — enforces RLS context on every query via `SET LOCAL`
- All 53 tables have RLS policies (~100 policies across 7 patterns)
- 33 migration files (001-033, 011 missing)
- 58 JSONB columns, ~80 FK relationships
- 2 database functions, 11 triggers

### 8.5 Real-Time Features

**Source:** CARRY_FORWARD_MANIFEST.md Section 10 (lines 241-246), health-audit.md line 297

- **SSE (Server-Sent Events)** for DealerBrain streaming
- **Polling** for: notifications (30s), inbox messages (15s), activity (60s), insights (60s)
- **No WebSocket connections in client** despite `socket.io` being in package.json (health-audit.md line 297)

---

## 9. Error Handling and Recovery

### 9.1 Webhook Error Handling

**Source:** REVERSE_SRS_old.md (lines ~500-520)

- VAPI webhooks: try/catch with error logging, returns 200 even on internal errors to prevent VAPI retry storms
- Tavus webhooks: HMAC verification failure returns 401; processing errors caught and logged

### 9.2 VIN API Error Handling

**Source:** VIN_SOLUTIONS_INTEGRATION.md (lines ~150-200), DEVELOPMENT_TEAM_BRIEFING.md (lines ~60-70)

- Token refresh errors: logged to `vin_audit_log`, retry on next interval
- API call errors: logged with request/response details
- Sync queue: failed items remain in queue for retry; 12/12 production sync jobs currently in failed state

### 9.3 Client-Side Error Handling

**Source:** ACCEPTANCE_VERIFICATION_REPORT.md (lines 107-112)

- All `console.error` in catch blocks (error handling, not leaked errors)
- TypeScript strict mode enforced
- **No React ErrorBoundary wrapper** — graceful degradation not implemented
- Null-safe access patterns throughout (but 4 unsafe `.pct` accesses found in insights.tsx — known_issues.md.md)

### 9.4 PM2 Restart Behavior

**Source:** DATA_ACCURACY_REPORT.md (line ~90)

- PM2 restarted 3,247 times
- Each restart can lose in-flight webhook processing
- Singleton job guards (boolean flags) reset on restart, but any in-progress work is lost

---

## 10. Security Mechanisms

### 10.1 RLS (Row-Level Security)

**Source:** database-audit.md (lines ~200-350), DEVELOPMENT_TEAM_BRIEFING.md (lines 80-95)

- 53 tables with RLS enabled
- ~100 policies across 7 patterns
- **CRITICAL BUG:** `SecureQueryBuilder` sets `app.current_organization_id` via `SET LOCAL`, but RLS policies check `app.current_org_id` — DIFFERENT VARIABLE NAMES. This means RLS policies may not be enforcing isolation correctly.
- **CRITICAL BUG:** `SET LOCAL` without an explicit transaction means the variable persists for the entire database connection lifetime, not just the current request. In a connection pool, this could leak organization context between requests.

### 10.2 Rate Limiting

**Source:** server-audit.md (lines ~200-250), health-audit.md line 295

- `express-rate-limit` v8.2.1
- Widget endpoint: 100 req/hr/IP
- General API: rate limiting configured (specific limits not documented in input files)
- DealerBrain: service quota with 80% alert threshold

### 10.3 Security Headers

**Source:** health-audit.md line 291

- `helmet` v8.1.0 for security headers
- CORS configured

### 10.4 Input Validation

**Source:** health-audit.md line 293

- Zod v3.24.2 for schema validation
- Used for request body validation on API endpoints

### 10.5 Password Handling

**Source:** health-audit.md line 291

- `bcrypt` v6.0.0 for password hashing

### 10.6 Webhook Authentication

- VAPI: org resolution via metadata/assistantId (no cryptographic verification)
- Tavus: HMAC-SHA256 signature with 5-minute timestamp tolerance
- TextMagic: route-level authentication (specifics not detailed in input files)

---

## 11. Notification Routing

**Source:** server-audit.md (lines ~350-400), CARRY_FORWARD_MANIFEST.md line 73, Nexxus_SRS_Addendum_v3.2 (lines ~350-400)

### 11.1 Notification System

- `useNotifications` hook: list, unread count (polling at 30s), settings CRUD, event types
- Mark read, mark all read, bulk update settings
- Database hierarchy routing: notifications follow org → user hierarchy
- Super Admin receives system-wide notifications
- Event types configurable per user

### 11.2 Notification Channels

- In-app: notification bell in TopBar (last 10, badge count)
- Email: Resend API for outbound email notifications
- SMS: TextMagic for text-based notifications (not currently wired for notification events)

### 11.3 Notification Triggers

- Call completion → email notification (VAPI webhook handler)
- Low credits → in-app notification
- Approval required → in-app notification
- Task assigned → in-app notification
- **GAP:** Appointment status changes fire zero notifications (known_issues.md.md)

---

## 12. Credit and Usage Tracking

**Source:** REVERSE_SRS_old.md (lines ~700-750), CARRY_FORWARD_MANIFEST.md line 74, CLAUDE.md (preflight-input, lines 316-319)

### 12.1 Credit Economics

| Service | Customer Price | Cost | Margin |
|---------|---------------|------|--------|
| Voice AI | $0.25/min | $0.15/min | 40% |
| Video AI | $0.32/min | $0.20/min | 37.5% |
| SMS | $0.05/msg | $0.02/msg | 60% |

### 12.2 Credit Tables

- `credit_policies` — defines pricing per service type per org
- `credit_allocations` — budget allocations per org
- `credit_usage` — actual usage records with timestamps
- Service quotas with 80% alert threshold

### 12.3 Credit Recording

Wired to webhooks in Phase 6:
- VAPI call ends → credit recorded based on duration
- Tavus session ends → credit recorded based on duration
- SMS sent → credit recorded per message

**Idempotency:** `credit_recorded` boolean column with atomic `UPDATE...WHERE credit_recorded = false RETURNING *` prevents double-counting

### 12.4 Client Hooks

`useCredits` hook provides: `useCreditBalance`, `useCreditUsage`, `useCreditPolicies`, `useRecentUsage`, `useCreditSummary`

### 12.5 Production Status

- 0 credits recorded in production (DATA_ACCURACY_REPORT.md)
- 0 notifications sent in production
- Billing page commented out in routes (`/credits` and `/profile/billing` marked PHASE-FUTURE, client-audit.md line 158)

---

## 13. Watch Area Findings

### WATCH 1: Agent Functionality/Defaults

**Sources:** session-knowledge.md (lines 52-58, 68-88), ===DevDesign Notes===.md (lines 68-90, 183-191), app_identity.md Section C (lines 127-162)

**Key Findings:**

1. **V1 had 27 hardcoded agents + super chat. V2 changed to user-created agents with selectable skills.** Skills are the same concept (pre-prompting, context, instructions) but now user-selectable, not fixed. (session-knowledge.md lines 52-58)

2. **Automa (master agent)** always exists in every account. Has high-level org context awareness, knows goals, understands page context. Listed at top of agents list. Removed from agents page in V2.1 design — right pop-out represents agent config, so Automa doesn't need a presence there. (app_identity.md Section C6 line 151, ===DevDesign Notes===.md line 187)

3. **Communications Agent** is static, configured by Super Admin. Two default agents ship out of the box — one voice (VAPI), one video (Tavus). The rest are user-created. (===DevDesign Notes===.md lines 72-74)

4. **Agent capabilities from inside Nexxus (===DevDesign Notes===.md lines 78-89):**
   - Send SMS to customer(s)
   - Send email to customer(s)
   - Attach artifacts from Drive or upload from chat
   - Right pane shows: link to customer-facing page, phone number, text chat link, contextual instructions/prompt

5. **Production agent inventory (ACCEPTANCE_VERIFICATION_REPORT.md line 85):** 12 active — 5 voice (VAPI assistant IDs linked), 2 chat, 4 task, 0 video

6. **Payment-critical agent behavior (session-knowledge.md lines 68-76):**
   - Communications agent handles proactive lead follow-up (outbound call + text when lead arrives)
   - Reactive after-hours coverage (SMS and phone when staff unavailable)
   - Cannot be modified by user except triggers and instruction supplement

7. **Skills catalog:** On Agents page, option to add skills when creating/editing agent. Skills catalog draws from what old 27 agents used to do. (session-knowledge.md line 56)

### WATCH 2: Billing

**Sources:** CARRY_FORWARD_MANIFEST.md line 74, client-audit.md line 158, ARCHITECTURE_GUIDE_RBAC_ADDITION.md line 19, DESIGNER_UPDATE_SPEC.md Section 11

**Key Findings:**

1. **Credit tables exist and are wired** (credit_policies, credit_allocations, credit_usage) — see Section 12
2. **Billing page commented out** in routes — `/credits` and `/profile/billing` marked PHASE-FUTURE (client-audit.md line 158)
3. **Partner-level credit pool** exists in partner table schema (`credit_pool DECIMAL`) (ARCHITECTURE_GUIDE_RBAC_ADDITION.md line 19)
4. **0 credits recorded in production** despite 832 VAPI calls (DATA_ACCURACY_REPORT.md)
5. **DESIGNER_UPDATE_SPEC.md Section 11** references a NEW Billing Page to be added to the Replit reference design — this is future work
6. **Billing settings:** Part of Settings page, Super Admin only
7. **No billing API endpoints documented in input files** beyond the client hooks

### WATCH 3: Unified Inbox Handoff

**Sources:** session-knowledge.md (lines 17-21), Nexxus_SRS_Addendum_v3.2 (lines ~300-350), CARRY_FORWARD_MANIFEST.md line 75

**Key Findings:**

1. **Architecture concept (session-knowledge.md lines 17-21):** Widgets are portals to agents. Externally-initiated conversations (via widget) can be continued internally in the Unified Inbox. Staff can pick up where the agent left off — continuity between external and internal surfaces.

2. **Inbox hooks (CARRY_FORWARD_MANIFEST.md line 75):** `useInboxConversations`, `useInboxConversation`, `useInboxMessages`, `useInboxUnreadCount`, `useSendInboxMessage`, `useAssignConversation`, `useUpdateConversationStatus`, `useMarkConversationRead`

3. **Hub Inbox (===DevDesign Notes===.md lines 194-198):** Hub → Inbox takes to universal inbox showing ALL communication with a prospect. From here user can create SMS, create email. Calendar and Leads are sibling tabs.

4. **InboxPanel** merges SMS + widget chat + email into unified view (ACCEPTANCE_VERIFICATION_REPORT.md line 49)

5. **SMS state machine defines handoff states** (AI_ACTIVE → HUMAN_ACTIVE) but transition logic not fully implemented (see Section 5.1)

6. **NOT FOUND:** Detailed flow documentation for how an external widget conversation transitions to the internal inbox — the mechanism is implied but the specific event/trigger that surfaces it to staff is not specified

### WATCH 4: Super Admin Functionality

**Sources:** app_identity.md Section D1 (line 168), ===DevDesign Notes===.md (lines 37-39), DESIGNER_UPDATE_SPEC.md (lines 79-98), ARCHITECTURE_GUIDE.md (lines 226-241)

**Key Findings:**

1. **Super Admin capabilities (app_identity.md line 168-169):** Create partners, directly create organizations (when no partner involved), manage master billing, maintain the system.

2. **Super Admin org switching (===DevDesign Notes===.md lines 37-38):** Should be able to switch orgs like Partner Admin, except with option to switch to "Nexxus System" which shows the org UI as configured.

3. **Settings RBAC (DESIGNER_UPDATE_SPEC.md lines 79-98):** Super Admin sees all 9 settings tiles. Additional exclusive access: Data Management tile, Skills tab in AI Configuration, Emergency kill switch. Partner Admin has read-only access to AI Configuration (system prompt, agent behavior, hunches) but cannot edit.

4. **System settings (===DevDesign Notes===.md lines 212-214):** System settings include System Prompt, System Instructions, Misc System Settings — Super Admin only.

5. **Tool provisioning flow (ARCHITECTURE_GUIDE_RBAC_ADDITION.md lines 68-77):** Super Admin → Provisions tools → Partner Admin → Manages orgs → Org Admin → Uses tools. Super Admin controls all tool provisioning (VIN Solutions, VAPI, Tavus).

6. **Activity page (client-audit.md line 93):** CSV export visible only to admins.

7. **CONCERN:** Owner states "Super Admin functionality undertested, owner has focused on customer-facing features. Needs thorough extraction of what super admin can see/do vs org admin vs staff." (session-knowledge.md lines 97-98)

### WATCH 5: Context Router

**See Section 7 above for full documentation.**

**Additional findings from watch area analysis:**

1. **Owner design intent (===DevDesign Notes===.md line 41):** Context Router should have 3 clear sections: Memory stores, Sync Data, Upload Data Store and Web/3rd party data store. This is not reflected in current implementation.

2. **Deferred to tech (CLARIFICATION_ANSWERS.md):** Owner deferred Context Router technical details to engineering team.

3. **Was inverted (DEVELOPMENT_TEAM_BRIEFING.md line ~110):** At some point VIN was fallback instead of primary. Corrected but shows fragility.

4. **Needs expansion for non-lead data (wave1-reconciled.md cross-wave note):** Current implementation focuses on lead/CRM data. Other data types (VAPI metrics, Tavus metrics, internal analytics) may not route through the same architecture.

---

## 14. Conflicts Detected

### CONFLICT 1: View Configuration Names

**File A:** ARCHITECTURE_GUIDE.md uses View A (Chat Only), View B (Data Display), View C (Sub Menu), View D (Heavy Chat Work)
**File B:** app_identity.md Section H (lines 299-309) uses Type A (Chat-only), Type B (Info + chat), Type C (Chat center + info right), Type D (Settings no chat), Type E (Library/artifact)
**Impact:** The layout type naming conventions do not match. Architecture Guide has 4 types; app_identity has 5 types with different descriptions.

### CONFLICT 2: Main Page Layout

**File A:** ARCHITECTURE_GUIDE.md line 108 — Main page is View A (Chat Only), center pane is Automa chat, right pane NOT VISIBLE
**File B:** app_identity.md line 66 — Main page is Type B Layout with metrics in center + chat on right
**File C:** ===DevDesign Notes===.md lines 109-136 — Going back to original design but adding 4 metric tiles at top, keeping chat on main page
**Impact:** Three different descriptions of what the main/dashboard page should look like. The codebase currently has a `dashboard.tsx` (metrics) at `/` and `main.tsx` (chat) at `/chat` — so both exist as separate pages.

### CONFLICT 3: Hub Tab Count

**File A:** DESIGNER_UPDATE_SPEC.md line 11 — "Hub has exactly 3 tabs: Calendar, Leads, Inbox" (confirmed by owner 2026-02-22)
**File B:** ARCHITECTURE_GUIDE.md lines 190-194 — Work Center has 5 tabs: Messages, Calendar, Tasks, Hunches, Approvals
**File C:** client-audit.md line 90 — work-center.tsx has 5 tabs: Calendar, Tasks, Approvals, Communication, Open Leads
**Impact:** Hub tabs have been redesigned multiple times. DESIGNER_UPDATE_SPEC.md is the latest owner decision (3 tabs), but the actual codebase still has 5 tabs.

### CONFLICT 4: Insights Sub-Tabs

**File A:** app_identity.md lines 95-100 — Insights has: Dashboard, Dealer Pulse, Goals, Hunches, Reports
**File B:** ===DevDesign Notes===.md lines 52-67 — Insights restructured to: Dashboard (Command Center, Pipeline Health, Performance Scorecard) + Reports (Loss Analysis, Channel Intelligence, Trend Reports) + Library + Hunches. Goals REMOVED.
**File C:** client-audit.md line 86 — insights.tsx has 6 tabs: Dashboard, Goals, Reports, Attribution, Hunches, Dealer Pulse
**Impact:** Three conflicting descriptions of Insights structure. DevDesign Notes explicitly says "Goals - Remove" but goals still exist in codebase.

### CONFLICT 5: Activity Page Location

**File A:** ===DevDesign Notes===.md line 128 — "We are going to move activity into a sub-tab in insights"
**File B:** client-audit.md line 93 — activity.tsx is a standalone page at `/activity`
**Impact:** Owner intent to merge Activity into Insights; codebase has it as standalone page.

### CONFLICT 6: Agent Event Types

**File A:** server-audit.md mentions 7 event types including `custom`
**File B:** ACCEPTANCE_VERIFICATION_REPORT.md line 96 lists 7 types with `inbound_message` instead of `sms_received`
**File C:** CUSTOMER_ONBOARDING_KICKOFF.md line 92 lists 6 types (omits `custom` and `hot_lead`)
**Impact:** Inconsistent event type lists across documents. `hot_lead` has no call site.

### CONFLICT 7: Agent Action Types

**File A:** ACCEPTANCE_VERIFICATION_REPORT.md line 97 lists 5 actions: outbound_call, send_sms, send_email, create_task, webhook
**File B:** REVERSE_SRS_old.md lists 5 actions: outbound_call, send_sms, send_notification, create_task, assign_lead
**Impact:** `send_email` vs `send_notification` and `webhook` vs `assign_lead` — the action type vocabulary is inconsistent across documents.

### CONFLICT 8: Menu Order

**File A:** ===DevDesign Notes===.md line 129 — "The order of the left side menu will be Main, Insights, Agents, Hub, Drive"
**File B:** ARCHITECTURE_GUIDE.md lines 44-73 — Menu order: Main, Agents, Drive, Insights, Work Center, Activity
**Impact:** Different menu orderings specified.

---

## 15. Missing Information

### NOT FOUND 1: SMS State Machine Transition Logic
**Expected:** Code-level documentation of how SMS conversations transition between AI_ACTIVE, HUMAN_ACTIVE, and DORMANT states (timeout durations, trigger events for each transition)
**Looked in:** Nexxus_SRS_Addendum_v3.2, database-audit.md, server-audit.md, REVERSE_SRS_old.md
**Status:** Schema exists. Constants referenced. Transition logic implementation details not documented.

### NOT FOUND 2: Widget-to-Inbox Handoff Mechanism
**Expected:** Specific event or trigger that surfaces an external widget conversation to staff in the Unified Inbox
**Looked in:** Nexxus_SRS_Addendum_v3.2, CARRY_FORWARD_MANIFEST.md, session-knowledge.md, REVERSE_SRS_old.md
**Status:** The concept is described (widgets → agents → inbox continuity) but the technical mechanism for the handoff is not specified.

### NOT FOUND 3: Orchestration Agent Specification
**Expected:** Behavior specification for the Orchestration Agent ("traffic cop for all system component activity")
**Looked in:** app_identity.md Section C5, Agent Instructions.md, all audit files
**Status:** Mentioned as a concept (app_identity.md line 148) but no implementation details or specification found.

### NOT FOUND 4: System Agent Specifications
**Expected:** What system agents exist, what they do, how they're configured
**Looked in:** app_identity.md Section C4, server-audit.md, MASTER_SRS.md
**Status:** Mentioned as "background agents only Super Admin can access" (app_identity.md line 145) but no enumeration or specification.

### NOT FOUND 5: DealerBrainProcessor Enforcement Rules
**Expected:** What the DealerBrainProcessor middleware will enforce beyond Stage 1 monitoring
**Looked in:** REVERSE_SRS_old.md, server-audit.md, CONSTITUTION.md
**Status:** Only Stage 1 (monitoring) described. Enforcement stages not specified.

### NOT FOUND 6: Multi-Org Query Resolution
**Expected:** How the system handles queries when a user has access to multiple organizations — does it search all, ask the user, or default to current?
**Looked in:** app_identity.md Section D3, CLARIFICATION_ANSWERS.md
**Status:** Owner explicitly says this is an "unresolved design question" that "got messy" (app_identity.md line 177). No resolution documented.

### NOT FOUND 7: Error Recovery for Failed Sync Queue Items
**Expected:** Retry policy, backoff strategy, maximum retry count for failed VIN sync queue items
**Looked in:** VIN_SOLUTIONS_INTEGRATION.md, server-audit.md, REVERSE_SRS_old.md
**Status:** 12/12 failed items remain in queue. No retry policy documented.

### NOT FOUND 8: Agent Skills Catalog Content
**Expected:** What skills are available, what each skill does, how skills compose on agents
**Looked in:** session-knowledge.md, ===DevDesign Notes===.md, DESIGNER_UPDATE_SPEC.md Section 16
**Status:** Concept documented (skills = context + instructions overlays). DESIGNER_UPDATE_SPEC.md Section 16 references a "Skills Catalog (NEW)" section but content not in the input files read. No enumeration of actual skills.

### NOT FOUND 9: Hunch Generation Algorithm
**Expected:** How the system decides when to generate hunches, what data it analyzes, how it scores confidence
**Looked in:** Hunch Instructions.md, —Hunches.md, server-audit.md
**Status:** Agent prompt for hunch generation is fully specified (Hunch Instructions.md — detailed agent persona, methodology, output format). But the system-level trigger (every 6 hours via background job) and the data pipeline feeding it are not specified — only the AI prompt.

### NOT FOUND 10: Product Tour Configuration
**Expected:** What the onboarding tour shows, how it differs by role, tour step definitions
**Looked in:** ===DevDesign Notes===.md line 40, client-audit.md
**Status:** Owner states "WE HAVE TO REMEMBER TO REACTIVATE THE TOUR AND SET IT UP WITH RBAC SO THE TOUR WORKS DIFFERENTLY DEPENDING ON THE ROLE" (===DevDesign Notes===.md line 40). driver.js used for onboarding. No tour step definitions found.

### NOT FOUND 11: Rate Limiting Configuration Details
**Expected:** Specific rate limits per endpoint category, window sizes, penalty behavior
**Looked in:** server-audit.md, health-audit.md
**Status:** Widget endpoint confirmed at 100/hr/IP. General API rate limiting configured but specific limits not documented.

---

## 16. Cross-Wave Notes from Wave 1 — Verification

### CW-1: MASTER_SRS.md Section 7.3 webhook-to-lead data flow
**Status:** VERIFIED and expanded. See Section 1.1 above. The flow is technically detailed in MASTER_SRS.md and corroborated by REVERSE_SRS_old.md Section 5.2 and DATA_ACCURACY_REPORT.md. Key addition: the flow is BROKEN in production due to missing `call.started` events.

### CW-2: Context Router needs expansion for non-lead data
**Status:** VERIFIED. See Section 7.3-7.4 above. Current implementation focuses on lead/CRM data. Owner's design intent includes 3 clear sections for different data types (===DevDesign Notes===.md line 41), but implementation only covers VIN lead data routing.

### CW-3: RLS variable name mismatch
**Status:** VERIFIED. See Section 10.1. `SecureQueryBuilder` sets `app.current_organization_id` but policies check `app.current_org_id`. Documented in DEVELOPMENT_TEAM_BRIEFING.md lines 80-95 and database-audit.md.

### CW-4: SET LOCAL without transaction
**Status:** VERIFIED. See Section 10.1. `SET LOCAL` without explicit transaction means variable persists for connection lifetime in connection pool. Documented in DEVELOPMENT_TEAM_BRIEFING.md.

### CW-5: SMS conversation state machine needs full documentation
**Status:** VERIFIED as gap. See Section 5.1 and NOT FOUND 1. Schema exists in migration 032. State constants referenced. Transition logic not fully implemented or documented.

### CW-6: Trigger deduplication undocumented
**Status:** VERIFIED and documented. See Section 2.3. Two mechanisms exist: `notification_sent` and `credit_recorded` columns with atomic UPDATE...WHERE...RETURNING pattern. Now documented.

### CW-7: VAPI webhook ingestion broken
**Status:** VERIFIED. See Section 1.1 and Section 3.1. `call.started` never received for production calls. All 137 real records are from bulk import. 72% of post-V2 calls missing from DB.

---

## END OF WAVE 2 REVIEWER EXTRACTION
