# Wave 3 — REVIEWER: Architecture (SPEC) Extraction

**Reviewer Agent:** Claude Opus 4.6
**Date:** 2026-03-03
**Scope:** Extract all SPEC-relevant content (how the system is built, where code lives, how pieces connect) from all 53 input files.
**Output for:** SPEC.md governance file

---

## 1. Technology Stack

### 1.1 Frontend Stack

| Technology | Version/Detail | File Source |
|------------|---------------|-------------|
| React | 18 | client-audit.md line 27 |
| TypeScript | Strict mode enabled | REVERSE_SRS_old.md line 607 |
| Vite | Build tool | client-audit.md line 48 |
| Wouter | Routing (NOT React Router) | client-audit.md line 52 |
| TanStack Query (React Query) | Server state management | client-audit.md line 53 |
| React Context API | Client state (4 providers) | client-audit.md line 388 |
| Tailwind CSS | v4, 615 lines custom CSS | REVERSE_SRS_old.md line 544 |
| shadcn/ui | 47 Radix-based primitives | client-audit.md lines 209-262 |
| lucide-react | 60+ icons | REVERSE_SRS_old.md line 546 |
| FullCalendar | Calendar display | REVERSE_SRS_old.md line 547 |
| Tiptap | Rich text editor | REVERSE_SRS_old.md line 548 |
| Recharts | Charts (via shadcn chart component) | REVERSE_SRS_old.md line 549 |
| driver.js | 9-step product onboarding tour | REVERSE_SRS_old.md line 550 |
| date-fns | Date utility | client-audit.md line 61 |
| Inter / Merriweather / Fira Code | Font stack (sans/serif/mono) | REVERSE_SRS_old.md line 551 |

**NOTE:** ARCHITECTURE_VISUAL_MAP.md line 31 claims "Next.js 14 App Router" for Layer 1. This is WRONG. The actual codebase uses Vite + React 18 + Wouter. The visual map is aspirational/pre-build, not as-built.

### 1.2 Backend Stack

| Technology | Version/Detail | File Source |
|------------|---------------|-------------|
| Node.js | Runtime | server-audit.md line 45 |
| Express.js | v5 (pre-release) | REVERSE_SRS_old.md line 239, line 1141 |
| TypeScript | Strict mode, 325 `any` annotations | REVERSE_SRS_old.md lines 607-608 |
| PostgreSQL | Supabase-hosted, AWS us-west-2 | REVERSE_SRS_old.md line 144 |
| pg (node-postgres) | Pool, max 10 connections | REVERSE_SRS_old.md line 145 |
| JWT (jsonwebtoken) | 24h access / 7d refresh tokens | REVERSE_SRS_old.md line 443 |
| bcrypt | 10 salt rounds | REVERSE_SRS_old.md line 1066 |
| Multer | File uploads (in-memory, 50MB max) | server-audit.md line 52 |
| ImapFlow + Nodemailer | Email IMAP/SMTP | server-audit.md line 53 |
| Resend SDK | Transactional email | REVERSE_SRS_old.md line 333 |
| Helmet | Security headers (CSP disabled for SPA) | REVERSE_SRS_old.md line 1062 |
| pdf-parse | PDF content extraction | server-audit.md line 222 |
| Puppeteer | PDF report generation | DO_NOT_TOUCH.md line 123 |

### 1.3 External Services

| Service | Auth Method | Purpose | Source |
|---------|------------|---------|--------|
| VIN Solutions | OAuth2 Client Credentials (60-min tokens) | CRM: leads, contacts, dealers, users | REVERSE_SRS_old.md line 330 |
| VAPI | Shared secret (timing-safe) | Voice AI call data, transcripts | REVERSE_SRS_old.md line 331 |
| Tavus | HMAC-SHA256 + API key | Video AI sessions | REVERSE_SRS_old.md line 332 |
| Resend | API key (SDK) | Transactional email | REVERSE_SRS_old.md line 333 |
| TextMagic | Username + API key (REST v2) | SMS send/receive | REVERSE_SRS_old.md line 334 |
| Anthropic Claude | API key (SDK) | AI chat, tool calling, content gen | REVERSE_SRS_old.md line 335 |
| Google Calendar | OAuth2 (Authorization Code) | Calendar sync, appointment push | REVERSE_SRS_old.md line 336 |

### 1.4 Testing & Build

| Tool | Detail | Source |
|------|--------|--------|
| Playwright | ^1.58.1, Chromium only, 1280x720, 747 E2E tests | health-audit.md lines 144-157 |
| Jest | NOT configured (0 unit tests) | health-audit.md line 163 |
| ESLint | NOT configured | REVERSE_SRS_old.md line 612 |
| Prettier | NOT configured | REVERSE_SRS_old.md line 613 |
| CI/CD | NOT configured | REVERSE_SRS_old.md line 615 |
| PM2 | Process manager, 148.9 MB | health-audit.md line 28 |

### 1.5 npm Dependencies

- 91 production + 31 dev = 122 total (health-audit.md line 26)
- 7 known vulnerabilities: 0 critical, 4 high, 2 moderate, 1 low (REVERSE_SRS_old.md lines 619-626)
- HIGH: `xlsx` (2 CVEs, no fix), `minimatch`, `glob`, `sucrase`
- MODERATE: `lodash` (prototype pollution), `markdown-it` (ReDoS)

---

## 2. Service Topology

### 2.1 System Architecture Overview

Source: REVERSE_SRS_old.md lines 743-796

```
Internet -> Caddy (reverse proxy, SSL) -> https://nexxusv2.huminicdev.com
  |
  +--> Static Assets (dist/public/) -> Vite SPA (React)
  +--> API Requests (/api/*) -> Express.js 5 Server
         |
         +--> Direct Pool (pg, max 10)
         +--> RLS Policies (~100)
         +--> Background Jobs (setInterval)
         |
         v
       Supabase PostgreSQL (aws-0-us-west-2)
         53 tables | ~160 indexes | 2 functions | 12+ triggers | ~80 FKs | 58 JSONB columns
```

### 2.2 Server Entry Points

Source: DO_NOT_TOUCH.md lines 37-46

| File | Purpose |
|------|---------|
| `server/index.ts` | Main entry point. Express app, HTTP server, Helmet, body parsers, global error handlers. PM2 runs compiled `dist/index.cjs`. |
| `server/routes.ts` | Route registry. Imports and mounts 35+ route modules, webhook routers, background jobs. Registration order matters. |
| `server/storage.ts` | Storage interface and in-memory implementation. |
| `server/static.ts` | Serves `dist/public/` in production. Fallback 503 if build missing. |
| `server/vite.ts` | Vite dev server middleware for HMR. |

### 2.3 Middleware Chain

Source: DO_NOT_TOUCH.md lines 172-179, server-audit.md lines 43-50

| Middleware | File | Purpose |
|-----------|------|---------|
| `authenticate` | `server/auth/middleware.ts` | Validates JWT from Authorization header, populates `req.user` |
| `enforceOrganizationContext` | `server/middleware/enforceOrganizationContext.ts` | Validates `x-organization-id` header, sets RLS context |
| `validateResourceOwnership` | `server/middleware/validateResourceOwnership.ts` | Validates resource belongs to requesting org |
| `jwt.ts` | `server/auth/jwt.ts` | Token signing, verification, expiry config |

### 2.4 Route Registration Order

Source: server-audit.md lines 62-101. Order matters for Express path matching.

```
 1. /api/webhooks/vapi       (before body parsers)
 2. /api/webhooks/tavus      (raw body capture for HMAC)
 3. /api/auth
 4. /api/vin
 5. /api/integrations
 6. /api/insights
 7. /api/agents
 8. /api/credits
 9. /api/tasks
10. /api/appointments
11. /api/conversations
12. /api/admin
13. /api/admin/knowledge
14. /api/settings
15. /api/email
16. /api/user/integrations
17. /api/dealerbrain
18. /api/notifications
19. /api/sms
20. /api/widgets/public      (before /api/widgets)
21. /api/widgets
22. /api/inbox
23. /api/tracking
24. /api/triggers
25. /api/activity
26. /api/goals
27. /api/reports
28. /api/drive
29. /api/hunches
30. /api/approvals
31. /api/leads
32. /api/dashboard
33. /api/metrics
34. /api (google-calendar)
35. /api/hosted-pages
36. /api/pages              (hosted pages public)
37. /api/health
```

### 2.5 Service Inventory (40 modules)

Source: REVERSE_SRS_old.md lines 295-325, DO_NOT_TOUCH.md lines 94-156

**Top-Level Services (36):**

| Service | File | Lines | Purpose |
|---------|------|-------|---------|
| DealerBrainService | `server/services/DealerBrainService.ts` | 3,047 | Claude API with tool calling (non-streaming). LARGEST FILE. |
| DealerBrainStreamingService | `server/services/DealerBrainStreamingService.ts` | 2,020 | Claude API SSE streaming |
| VinSolutionsService | `server/services/vinSolutionsService.ts` | 1,134 | VIN CRM API client |
| TriggerService | `server/services/TriggerService.ts` | 1,413 | Event-driven automation engine |
| AppointmentService | `server/services/AppointmentService.ts` | 1,248 | Calendar CRUD with RBAC |
| TextMagicService | `server/services/TextMagicService.ts` | 1,130 | SMS send/receive |
| CreditService | `server/services/CreditService.ts` | -- | Usage tracking, billing |
| WidgetConfigService | `server/services/WidgetConfigService.ts` | -- | Widget CRUD |
| WidgetInteractionService | `server/services/WidgetInteractionService.ts` | -- | Widget chat, callbacks, SMS, video |
| WidgetAgentService | `server/services/WidgetAgentService.ts` | -- | Widget AI chat |
| InboxService | `server/services/InboxService.ts` | -- | Unified messaging inbox |
| DealerPulseService | `server/services/DealerPulseService.ts` | -- | 5-phase health snapshots |
| EmailService | `server/services/EmailService.ts` | -- | IMAP/SMTP operations |
| GoogleCalendarService | `server/services/GoogleCalendarService.ts` | -- | Google Calendar OAuth + CRUD |
| NotificationService | `server/services/NotificationService.ts` | -- | In-app notifications |
| KnowledgeUploadService | `server/services/KnowledgeUploadService.ts` | -- | CSV/XLSX import |
| GoalsService | `server/services/GoalsService.ts` | -- | Goal tracking |
| HunchesService | `server/services/HunchesService.ts` | -- | AI-generated insights |
| DriveService | `server/services/DriveService.ts` | -- | File/folder management |
| MetricsEngine | `server/services/MetricsEngine.ts` | -- | Certified metrics registry |
| AccessibleOrganizationsService | `server/services/AccessibleOrganizationsService.ts` | -- | Resolves user->org access by RBAC |
| ActivityService | `server/services/ActivityService.ts` | -- | Activity feed |
| AgentService | `server/services/AgentService.ts` | -- | VAPI + Tavus agent CRUD |
| ApprovalService | `server/services/ApprovalService.ts` | -- | Approval workflow state machine |
| ConversationService | `server/services/ConversationService.ts` | -- | DealerBrain conversation persistence |
| DashboardService | `server/services/DashboardService.ts` | -- | Dashboard data aggregation |
| FeedbackService | `server/services/FeedbackService.ts` | -- | User feedback collection |
| HostedPageService | `server/services/HostedPageService.ts` | -- | Hosted widget page rendering |
| PasswordResetService | `server/services/PasswordResetService.ts` | -- | Token gen/validation |
| PdfReportService | `server/services/PdfReportService.ts` | -- | Puppeteer PDF generation |
| ReportService | `server/services/ReportService.ts` | -- | Report data aggregation |
| TaskService | `server/services/TaskService.ts` | -- | Task management |
| TrackingService | `server/services/TrackingService.ts` | -- | Tracking pixel events |
| appointmentConfirmationService | `server/services/appointmentConfirmationService.ts` | -- | Confirmation email/SMS |
| appointmentExtractionService | `server/services/appointmentExtractionService.ts` | -- | AI extraction from transcripts |
| vinOAuthService | `server/services/vinOAuthService.ts` | 156 | OAuth2 token management |

**Sub-Service Modules (4 directories):**

| Directory | File | Purpose |
|-----------|------|---------|
| `contextRouter/` | ContextRouterService.ts | Routes data requests to VIN API or local DB |
| `contextRouter/` | SourceSelector.ts | Selects data source by availability/freshness |
| `contextRouter/` | CacheManager.ts | Caches VIN API responses |
| `sync/` | SyncCoordinator.ts | Processes sync_queue for VIN lead sync |
| `sync/` | LeadMapper.ts | Maps local lead format to VIN v3 API format |
| `leads/` | LeadCreationService.ts | 2-step VIN lead creation (contact + lead) |
| `leads/` | LeadExtractionService.ts | AI extraction from call/video transcripts |
| `insights/` | VoiceInsightService.ts | Voice call analytics |
| `insights/` | VideoInsightService.ts | Video session analytics |
| `insights/` | LeadInsightService.ts | Lead funnel analytics |
| `notifications/` | notificationEmailService.ts | Resend email delivery |

### 2.6 Background Jobs (8)

Source: REVERSE_SRS_old.md lines 356-368

| Job | Interval | Purpose |
|-----|----------|---------|
| VIN Token Refresh | 30 min | Refresh OAuth tokens before expiry |
| Sync Queue Worker | 1 min (outbound), 4 hrs (inbound) | Process sync_queue (Nexxus <-> VIN) |
| Appointment Reminder | 5 min | Send 24h and 2h reminders |
| Email Sync | 5 min | Sync IMAP emails for all users |
| VIN Lead Polling | 60 min | Import new VIN leads |
| Trigger Re-evaluation | 5 min | Re-evaluate age-based trigger conditions |
| Dealer Pulse | 4 hrs | Generate dealership health snapshots |
| Hunch Generation | 6 hrs | Generate AI-powered insights |

All use native `setInterval` (no Redis/Bull). Singleton guards (`isRunning` flag). Staggered startup (0-90s delay). (REVERSE_SRS_old.md line 368)

### 2.7 Webhook Handlers

Source: REVERSE_SRS_old.md lines 340-353, DO_NOT_TOUCH.md lines 193-200

| Webhook | Endpoint | Events | Org Resolution | Security |
|---------|----------|--------|---------------|----------|
| VAPI | `/api/webhooks/vapi` | call.started, call.ended, end-of-call-report, transcript, status-update | `metadata.organizationId` or `assistantId` lookup | Optional shared secret (timing-safe); accepts without verification if header absent |
| Tavus | `/api/webhooks/tavus` | conversation.started, conversation.ended, replica.ready, video.ready | `custom_data.organization_id` or `persona_id` lookup | HMAC-SHA256 with 5-min timestamp tolerance |
| TextMagic | `/api/sms/webhook/inbound` | Inbound SMS | Via org-scoped textmagic_config | No verification (TextMagic does not sign) |

Idempotency: `notification_sent` and `credit_recorded` columns with atomic `UPDATE...WHERE...RETURNING` pattern (REVERSE_SRS_old.md line 343).

---

## 3. Database Schema

### 3.1 Database Provider

- **Provider:** Supabase (PostgreSQL), hosted on AWS us-west-2
- **Connection:** pg.Pool (max 10), prefers direct URL (port 5432) over pgbouncer (port 6543)
- Source: REVERSE_SRS_old.md lines 144-145

### 3.2 Tables (53 CREATE TABLE statements across 33 migration files)

Source: database-audit.md lines 62-130

| # | Table | Migration | Group | Key Columns |
|---|-------|-----------|-------|-------------|
| 1 | organizations | 001 | Core | id, name, slug, type, settings (JSONB), billing_info (JSONB), status |
| 2 | locations | 001 | Core | id, organization_id, name, address (JSONB), timezone, business_hours (JSONB) |
| 3 | roles | 001 | Core | id, name, level (1-4), permissions (JSONB) |
| 4 | users | 001 | Core | id, organization_id, location_id, email, password_hash, first_name, last_name, role_id, settings (JSONB), status |
| 5 | partner_admin_organizations | 001 | Core | id, user_id, organization_id, assigned_at, assigned_by |
| 6 | integrations | 001 (+004b, +026) | Core | id, organization_id, type, config (JSONB), credentials (JSONB), status, external_id, lead_duration_threshold |
| 7 | agents | 001 | AI | id, organization_id, name, description, type, config (JSONB), status, performance_metrics (JSONB), created_by |
| 8 | skills | 001 | AI | id, name, category, description, template (JSONB), parameters_schema (JSONB), is_system |
| 9 | conversations | 001 | Chat | id, organization_id, type, channel, customer_info (JSONB), agent_id, user_id, status |
| 10 | messages | 001 | Chat | id, conversation_id, sender_type, sender_id, content, content_type, metadata (JSONB) |
| 11 | agent_runs | 001 | AI | id, agent_id, conversation_id, task_id, status, input/output/error (JSONB), credits_consumed |
| 12 | tasks | 002 | Work | id, organization_id, title, type, status, priority, assigned_to, agent_id, due_date |
| 13 | dashboards | 002 | Insights | id, organization_id, user_id, name, layout (JSONB) |
| 14 | widgets (dashboard) | 002 | Insights | id, dashboard_id, type, config (JSONB), position (JSONB) |
| 15 | goals | 002 | Insights | id, organization_id, user_id, name, type, target_value, current_value, period, status |
| 16 | artifacts | 002 | Drive | id, organization_id, name, type, file_size, storage_path |
| 17 | credit_policies | 002 (+012) | Billing | id, organization_id, service_type, rate_per_unit, cost_per_unit, unit_type, monthly_allowance, overage_rate. UNIQUE(org_id, service_type) added in 012. |
| 18 | credit_allocations | 002 | Billing | id, organization_id, policy_id, period_start/end, allocated_credits, used_credits |
| 19 | credit_usage | 002 | Billing | id, allocation_id, agent_run_id, service_type, units_consumed, cost |
| 20 | hunches | 002 (+023) | AI | id, organization_id, type, confidence, data (JSONB), status, title, priority, feedback (023) |
| 21 | audit_log | 002 | Governance | id, organization_id, user_id, action, resource_type, resource_id, details (JSONB), ip_address |
| 22 | insight_card_config | 002 | Insights | id, organization_id, user_id, card_type, config (JSONB), display_order, is_enabled |
| 23 | insight_card_state | 002 | Insights | id, user_id, card_config_id, filters (JSONB), view_preference, is_collapsed |
| 24 | leads | 003 | CRM | id, organization_id, first_name, last_name, phone, email, vehicle_interest, source, is_nexxus_originated, vin_customer_id, status, lead_score |
| 25 | vin_reports_cache | 003 | CRM | id, organization_id, integration_id, report_type, data (JSONB), expires_at, is_stale |
| 26 | vapi_call_logs | 003 (+024, +028) | Voice | id, organization_id, vapi_call_id, vapi_assistant_id, phone_number, direction, status, transcript, summary, credit_recorded, notification_sent |
| 27 | tavus_sessions | 003 (+024) | Video | id, organization_id, tavus_conversation_id, status, transcript, summary, engagement_score, credit_recorded |
| 28 | sync_queue | 003 | Sync | id, organization_id, job_type, priority, source_table, source_id, target_system, status, attempts, payload (JSONB) |
| 29 | user_integrations | 004a | User | id, user_id, organization_id, integration_type, credentials (JSONB), config (JSONB), status |
| 30 | appointments | 005 | Work | id, organization_id, title, start_time, end_time, appointment_type, customer_id, assigned_user_id, status |
| 31 | availability_blocks | 005 | Work | id, organization_id, user_id, day_of_week, start_time, end_time, is_recurring, max_concurrent |
| 32 | appointment_reminders | 005 | Work | id, appointment_id, reminder_type, reminder_timing, send_at, status |
| 33 | cached_emails | 006 | Email | id, user_integration_id, user_id, organization_id, message_id, uid, folder, subject, body_text, body_html, to_addresses (JSONB) |
| 34 | sent_emails | 006 | Email | id, user_id, organization_id, to_addresses (JSONB), subject, body_html, status |
| 35 | email_templates | 006 | Email | id, organization_id, name, slug, category, subject_template, body_html_template |
| 36 | dealerbrain_config | 007 | Config | id, config_key, config_value, description |
| 37 | notification_settings | 008 | Notifications | id, user_id, organization_id, channel, event_type, enabled |
| 38 | notifications | 008 | Notifications | id, user_id, organization_id, title, body, type, priority, data (JSONB), read_at |
| 39 | password_reset_tokens | 009 | Auth | id, user_id, token, expires_at, used_at |
| 40 | textmagic_config | 010 (+032) | SMS | id, organization_id, api_username, api_key_encrypted, phone_number, enabled, business_hours (JSONB), ai_auto_reply_enabled |
| 41 | textmagic_messages | 010 | SMS | id, organization_id, direction, from_number, to_number, message_text, status |
| 42 | textmagic_opt_outs | 010 | SMS | id, organization_id, phone_number, opted_out_at |
| 43 | widget_configs | 013 (+021) | Widget | id, organization_id, widget_code, widget_name, config_appearance/channels/targeting (JSONB), chat_instructions, chat_agent_name, chat_enabled_tools (JSONB) |
| 44 | widget_callback_requests | 013 | Widget | id, widget_config_id, organization_id, customer_name, customer_phone, status, vapi_call_id |
| 45 | widget_visitors | 014 | Widget | id, visitor_id, widget_config_id, organization_id, customer_name/email/phone, lead_id |
| 46 | widget_chat_messages | 014 | Widget | id, visitor_id, widget_config_id, organization_id, role, content |
| 47 | hosted_pages | 015 | Widget | id, organization_id, widget_config_id, page_type, slug, title, config_appearance/meta (JSONB), published, status |
| 48 | inbox_conversations | 016 | Inbox | id, organization_id, channel, status, customer_name/phone/email, assigned_to, widget_visitor_id |
| 49 | inbox_messages | 016 | Inbox | id, conversation_id, sender_type, sender_id, content, channel |
| 50 | tracking_events | 017 | Tracking | id, organization_id, visitor_id, event_type, page_url, utm_source/medium/campaign/term/content |
| 51 | trigger_rules | 018 | Triggers | id, organization_id, name, event_type, conditions (JSONB), action_type, action_config (JSONB), delay_seconds, business_hours_only |
| 52 | trigger_executions | 018 | Triggers | id, trigger_rule_id, organization_id, event_data (JSONB), action_result (JSONB), status |
| 53 | ai_usage_events | 019 | Governance | id, organization_id, user_id, action_type, tool_invoked, tokens_used_input/output, duration_ms |

**Additional tables from ALTER TABLE migrations (not new CREATE TABLE):**

| Table | Migration | Addition |
|-------|-----------|----------|
| report_benchmarks | 020 | 12 seed benchmark rows, NO RLS (public ref data) |
| drive_folders | 022 | Self-referencing FK (parent_id) |
| drive_files | 022 | folder_id FK, disk_path |
| approval_requests | 023 | Approval workflow |
| dealer_pulse_cache | 025 | Periodic health snapshots |
| knowledge_uploads | 027 | Admin CSV/Excel import tracking |
| trigger_templates | 029 | System-defined trigger blueprints |
| vin_api_calls | 030 | VIN API telemetry |
| service_quotas | 031 | Per-org monthly limits |
| sms_conversation_state | 032 | AI/human collision avoidance state machine |

### 3.3 Migration Anomalies

- Migration 011 is **MISSING** (database-audit.md line 28)
- Two files share 004 prefix: `004_create_user_integrations.sql` and `004_serra_seed_data.sql` (database-audit.md line 57)
- Total migration files: 33 (numbered 001-033 minus 011)

### 3.4 RLS Architecture

Source: database-audit.md lines 135-186

- **Total tables with RLS enabled:** 53 (every CREATE TABLE)
- **Total RLS policies:** ~100
- **1 table with NO RLS:** report_benchmarks (public reference data, intentional)

**RLS Variable Mapping:**

| Variable | Used By | Set By |
|----------|---------|--------|
| `app.current_org_id` | All SQL RLS policies (org isolation) | jwt.ts, most route handlers via `set_config()` |
| `app.current_organization_id` | SecureQueryBuilder ONLY | **WRONG NAME** -- not matched by any RLS policy |
| `app.current_user_id` | 7 tables (user-self-access) | SecureQueryBuilder, jwt.ts |
| `app.user_role_level` | 16 tables (super admin bypass) | SecureQueryBuilder, most route handlers |
| `app.current_role` | 2 tables (dealer_pulse_cache, knowledge_uploads) | **NEVER SET** by application code |
| `app.current_role_level` | triggers.ts line 38 | **WRONG NAME** -- should be `app.user_role_level` |

**CRITICAL: SecureQueryBuilder RLS mismatch** (REVERSE_SRS_old.md lines 202-228, DEVELOPMENT_TEAM_BRIEFING.md lines 62-69): The intended centralized security layer sets the wrong variable. System works because most routes bypass SecureQueryBuilder and call `set_config('app.current_org_id', ...)` directly on the pool.

**CRITICAL: SET LOCAL without transaction** (REVERSE_SRS_old.md line 228): `SET LOCAL` outside a transaction persists for the session, potentially leaking RLS context on pooled connections.

### 3.5 Foreign Key Map

Source: database-audit.md lines 319-399

- **Total FK relationships:** ~80
- **Cascade patterns:** Most org-linked tables cascade on delete
- **Missing FKs:** `textmagic_messages.linked_lead_id` and `linked_appointment_id` (database-audit.md line 235)
- **Deferred FKs:** `leads.vapi_call_id`, `leads.tavus_session_id`, `vapi_call_logs.lead_id`, `tavus_sessions.lead_id` (circular refs)

### 3.6 JSONB Columns

- **Total:** 58 JSONB columns (database-audit.md lines 235-315)
- **No CHECK constraints or JSON Schema validation at DB level** (all validation at app layer)
- **Notable JSONB structures:** widget_configs stores 4 complex JSONB objects (appearance, channels, targeting, allowed_domains); trigger_rules.conditions is a JSON condition evaluation object

### 3.7 Indexes and Functions

- **~160 indexes** across all tables (database-audit.md, REVERSE_SRS_old.md line 233)
- **2 functions:** `update_updated_at_column()` trigger function (database-audit.md line 19)
- **12+ triggers** for auto-updating `updated_at` (16+ tables lack this trigger -- inconsistency)

---

## 4. API Endpoint Inventory

### 4.1 Summary

Source: REVERSE_SRS_old.md lines 243-284, server-audit.md lines 60-400+

- **Total API endpoints:** ~237
- **Route files:** 34
- **Auth distribution:** ~15 public, ~110 any authenticated, ~40 Org Admin+, ~20 Super Admin only

### 4.2 Complete Route Table

| Route Prefix | Endpoints | Auth | File | Source |
|-------------|-----------|------|------|--------|
| /api/auth | 9 | Mixed (public + JWT) | auth.ts | server-audit.md lines 107-120 |
| /api/admin | 14 | Super Admin | admin.ts | server-audit.md lines 123-143 |
| /api/admin/knowledge | 4 | Org Admin+ | knowledge.ts | server-audit.md lines 381-389 |
| /api/agents | 9 | Mixed | agents.ts | server-audit.md lines 145-159 |
| /api/appointments | 10 | Mixed (+ public confirm) | appointments.ts | server-audit.md lines 162-177 |
| /api/approvals | 5 | Any | approvals.ts | server-audit.md lines 180-190 |
| /api/activity | 6 | Mixed | activity.ts | server-audit.md lines 192-202 |
| /api/conversations | 11 | Any | conversations.ts | server-audit.md lines 205-221 |
| /api/credits | 5 | Mixed | credits.ts | server-audit.md lines 224-234 |
| /api/dashboard | 1 | Any | dashboard.ts | server-audit.md lines 236-240 |
| /api/dealerbrain | 3 | Super Admin | dealerbrain.ts | server-audit.md lines 242-250 |
| /api/drive | 8 | Any | drive.ts | server-audit.md lines 252-264 |
| /api/email | 7 | Any | email.ts | server-audit.md lines 266-277 |
| /api/goals | 7 | Mixed | goals.ts | server-audit.md lines 279-289 |
| /api (google-calendar) | 7 | Mixed (+ public callback) | google-calendar.ts | server-audit.md lines 291-303 |
| /api/hosted-pages | 5 | Mixed | hosted-pages.ts | server-audit.md lines 305-313 |
| /api/pages | 1 | Public | hosted-pages-public.ts | server-audit.md lines 315-320 |
| /api/hunches | 4 | Any | hunches.ts | server-audit.md lines 322-331 |
| /api/inbox | 8 | Mixed | inbox.ts | server-audit.md lines 333-344 |
| /api/insights | 15 | Mixed | insights.ts | server-audit.md lines 346-366 |
| /api/integrations | 6 | Mixed | integrations.ts | server-audit.md lines 368-378 |
| /api/leads | 6 | Any | leads.ts | server-audit.md lines 391-399 |
| /api/metrics | 3 | Mixed | metrics.ts | REVERSE_SRS_old.md line 271 |
| /api/notifications | 8 | Any | notifications.ts | REVERSE_SRS_old.md line 272 |
| /api/reports | 5 | Mixed | reports.ts | REVERSE_SRS_old.md line 273 |
| /api/settings | 4 | Org Admin+ | settings.ts | REVERSE_SRS_old.md line 274 |
| /api/sms | 7 | Mixed (+ public webhook) | sms.ts | REVERSE_SRS_old.md line 275 |
| /api/tasks | 9 | Any | tasks.ts | REVERSE_SRS_old.md line 276 |
| /api/tracking | 6 | Mixed (public + Org Admin+) | tracking.ts | REVERSE_SRS_old.md line 277 |
| /api/triggers | 10 | Mixed | triggers.ts | REVERSE_SRS_old.md line 278 |
| /api/vin | 10 | Mixed | vin.ts | REVERSE_SRS_old.md line 279 |
| /api/widgets | 9 | Mixed | widgets.ts | REVERSE_SRS_old.md line 280 |
| /api/widgets/public | 8 | Public (100/hr rate limit) | widget-public.ts | REVERSE_SRS_old.md line 281 |
| /api/user/integrations | 7 | Any | userIntegrations.ts | REVERSE_SRS_old.md line 282 |
| /api/health | 1 | Public | -- | REVERSE_SRS_old.md line 283 |
| /api/webhooks | 2 | Public (signature) | webhooks/ | REVERSE_SRS_old.md line 284 |

### 4.3 Rate Limiting

Source: REVERSE_SRS_old.md lines 404-413

| Route | Limit | Window | Scope |
|-------|-------|--------|-------|
| POST /api/auth/login | 30 | 1 min | Per IP |
| POST /api/auth/register | 5 | 1 hr | Per IP |
| POST /api/auth/forgot-password | 3 | 1 hr | Per IP |
| /api/widgets/public/* | 100 | 1 hr | Per IP |
| POST /api/insights/dealer-pulse/refresh | 1 | 15 min | Per org |

No global rate limiting applied.

### 4.4 Hosted Pages Route Mismatch (Known P0)

Source: session-knowledge.md line 198 (verified-findings)

- Client fetches: `/api/hosted-pages/public/${slug}`
- Server serves: `/api/pages/:slug`
- One-line fix needed in either client or server route.

---

## 5. Frontend Architecture

### 5.1 Pages and Routes

Source: REVERSE_SRS_old.md lines 488-508, client-audit.md lines 66-166

- **Total pages:** 21 (17 main + 4 hosted/public)
- **Active routes:** 13 protected + 4 public + 1 catch-all
- **Commented out routes:** `/credits`, `/profile/billing` (deferred)

| Route | Component | Purpose |
|-------|-----------|---------|
| `/` | DashboardPage | Command Center: health scores, lead feed, goals |
| `/chat` | MainPage | DealerBrain AI chat with SSE streaming |
| `/agents` | AgentsPage | Three-column agent management with embedded chat |
| `/agents/create` | AgentCreatePage | Multi-step creation wizard |
| `/agents/:id/edit` | AgentEditPage | Agent config editor |
| `/insights` | InsightsPage | 6-tab: Dashboard, Goals, Reports, Attribution, Hunches, Dealer Pulse |
| `/leads` | InsightsPage | Alias to Insights (same component) |
| `/work-center` | WorkCenterPage | 5-tab: Calendar, Tasks, Approvals, Communication, Open Leads |
| `/drive` | DrivePage | File management grid/list view |
| `/activity` | ActivityPage | AI Governance: usage, artifacts, CSV export |
| `/settings/system` | SettingsPage | 16+ role-gated tabs |
| `/profile` | ProfilePage | Profile editing, preferences, Google Calendar |
| `/notifications` | NotificationsPage | History, filtering, settings |
| `/w/:slug` | HostedPage | Public widget pages (chat, video, callback, multi) |
| `/login` | LoginPage | Glass-effect login with 9 randomized wallpapers |
| `/forgot-password` | ForgotPasswordPage | Password reset request |
| `/reset-password` | ResetPasswordPage | Password reset with token |
| `*` | NotFound | 404 catch-all |

### 5.2 Component Inventory

Source: client-audit.md lines 186-377

| Category | Count | Source |
|----------|-------|--------|
| shadcn/ui primitives (Radix) | 47 | client-audit.md lines 209-262 |
| Layout | 8 | client-audit.md lines 266-277 |
| Chat | 6 | client-audit.md lines 278-288 |
| Modals | 8 (+ 1 in modals/) | client-audit.md lines 289-302 |
| Reports | 8 | client-audit.md lines 303-315 |
| Settings tabs | 8 | client-audit.md lines 316-328 |
| Insights | 5 | client-audit.md lines 329-337 |
| Communication | 3 | client-audit.md lines 339-345 |
| Calendar | 2 | client-audit.md lines 347-352 |
| Admin | 2 | client-audit.md lines 354-359 |
| Notifications | 3 | client-audit.md lines 361-367 |
| Other (onboarding, inbox, sms, auth) | 4 | client-audit.md lines 369-377 |
| **Total custom** | **59** | |
| **Total (custom + shadcn)** | **106** | |

### 5.3 State Management

Source: client-audit.md lines 380-399, REVERSE_SRS_old.md lines 528-540

**Dual-layer architecture:**

1. **Server state:** TanStack Query -- 38 `useQuery` calls, 34 `useMutation` calls across 26 custom hooks
2. **Client state:** 4 React Context providers

**Provider hierarchy (in App.tsx):**
```
QueryClientProvider > TooltipProvider > ThemeProvider > AuthProvider > AppProvider > ChatProvider > <Router>
```

**Context providers:**
| Provider | File | Purpose | Verdict |
|----------|------|---------|---------|
| AuthProvider | `contexts/AuthContext.tsx` | JWT login/logout/refresh, token storage, org switching | PRESERVE |
| AppProvider | `contexts/AppContext.tsx` | currentUser, currentOrg, sidebar/panel UI state | REFERENCE |
| ChatProvider | `contexts/ChatContext.tsx` | Global DealerBrain panel state | REFERENCE |
| ThemeProvider | `contexts/ThemeContext.tsx` | Light/dark toggle, localStorage persistence | REFERENCE |

**Token storage:** localStorage keys: `nexxus_access_token`, `nexxus_refresh_token`, `nexxus_token_expiry`, `nexxus_accessible_orgs`. Auto-refresh every 60s, refreshes when < 5 min to expiry. (CARRY_FORWARD_MANIFEST.md lines 39-47)

### 5.4 Custom Hooks (26)

Source: CARRY_FORWARD_MANIFEST.md lines 57-88

All PRESERVE verdict. Key hooks include:
- `useLeads`, `useAgents`, `useInsights`, `useConversations`, `useAdmin`
- `useEmail`, `useAppointments`, `useTasks`, `useNotifications`, `useCredits`
- `useInbox`, `useGoals`, `useReports`, `useGoogleCalendar`, `useDrive`
- `useHunches`, `useApprovals`, `useActivity`, `useMetrics`, `useTracking`
- `useDealerPulse`, `useProfile`, `useDealerBrainConfig`
- `useStreamingMessage` (SSE streaming for DealerBrain chat)

### 5.5 SSE Streaming Protocol

Source: CARRY_FORWARD_MANIFEST.md lines 99-117

- **Endpoint:** `POST /api/conversations/{conversationId}/stream`
- **Auth:** `Authorization: Bearer {token}` header
- **Body:** `{ content: string }`
- **Event types:** `thinking`, `tool_start`, `tool_end`, `token`, `done`, `error`
- **File:** `client/src/hooks/useStreamingMessage.ts` (PRESERVE)

### 5.6 API Client Layer

Source: CARRY_FORWARD_MANIFEST.md lines 14-23

| File | Purpose | Verdict |
|------|---------|---------|
| `client/src/lib/api.ts` | Authenticated fetch wrapper (`fetchApi`, `apiGet`, `apiPost`, `apiPut`, `apiPatch`, `apiDelete`). JWT from localStorage. | PRESERVE |
| `client/src/lib/queryClient.ts` | TanStack Query client singleton, `getQueryFn`, `apiRequest` helper. | PRESERVE |

### 5.7 Layout System

Source: ARCHITECTURE_GUIDE.md lines 15-32, client-audit.md lines 266-277

**3-Pane grid layout:**
```css
.app-layout {
  grid-template-columns: [sidebar] 64px [left-pane] 240px [center-pane] 1fr [right-pane] 320px;
}
```

| Pane | Width | Purpose |
|------|-------|---------|
| Sidebar | 64px fixed (collapsible to 40px) | Main navigation, 6 items + admin + logout |
| Left Pane | 240-400px resizable | Sub-menu/context panel |
| Center Pane | Flex (min 600px) | Primary content |
| Right Pane | 320-500px resizable | Automa chat or contextual tools |

**Responsive breakpoints:**
- Mobile (<768px): Single pane, sidebar overlay
- Tablet (768-1024px): Sidebar + Center or toggle right
- Desktop (>1024px): All panes visible

**ViewConfig system** (AppLayout): `chat-only`, `data-display`, `sub-menu`, `heavy-chat` (client-audit.md line 269)

### 5.8 UI Framework

Source: REVERSE_SRS_old.md lines 543-553

| Feature | Implementation |
|---------|---------------|
| CSS | Tailwind CSS v4, 615 lines custom CSS |
| Theme | Light/dark via CSS class strategy (`dark` on `<html>`) |
| Icons | lucide-react (60+ unique) |
| Calendar | FullCalendar |
| Rich text | Tiptap editor |
| Charts | Recharts (via shadcn chart component) |
| Onboarding | driver.js (9-step tour) |
| Mobile | breakpoint at 1024px (`lg`), Sheet-based sidebar + bottom nav |

---

## 6. File/Directory Structure

Source: CLAUDE.md (from preflight-input), DO_NOT_TOUCH.md, client-audit.md, server-audit.md

```
nexxus-v2/
  client/                          # Vite + React frontend
    src/
      components/
        admin/          (2 files)
        auth/           (1 file)
        calendar/       (2 files)
        chat/           (6 files)
        communication/  (3 files)
        inbox/          (1 file)
        insights/       (5 files)
        layout/         (8 files)
        modals/         (8+1 files)
        notifications/  (3 files)
        onboarding/     (1 file)
        reports/        (8 files)
        settings/       (8 files)
        sms/            (1 file)
        ui/             (47 files — shadcn/ui)
      contexts/         (4 files: Auth, App, Chat, Theme)
      hooks/            (26 custom hooks + 3 UI hooks)
      lib/              (3 files: api.ts, queryClient.ts, utils.ts)
      pages/            (17 main pages)
        hosted/         (4 public page components)
      App.tsx
      index.css         (615 lines)
      main.tsx
  server/                          # Node.js/Express API
    auth/
      jwt.ts
      middleware.ts
    db/
      SecureQueryBuilder.ts
      index.ts
    db.ts                          # Pool config
    index.ts                       # Entry point
    middleware/
      enforceOrganizationContext.ts
      validateResourceOwnership.ts
      index.ts
    routes/                        # 34 route files
    routes.ts                      # Route registry
    services/                      # 36 top-level service files
      contextRouter/               # 4 files
      insights/                    # 4 files
      leads/                       # 3 files
      sync/                        # 3 files
      notifications/               # 1 file
    jobs/                          # Background job files
    utils/
      encryption.ts
    webhooks/
      vapi.ts
      tavus.ts
      utils/signatureVerifier.ts
    static.ts
    storage.ts
    vite.ts
  database/
    migrations/                    # 33 migration files (001-033, 011 missing)
    seed.sql
  tests/
    e2e/                           # 46 Playwright spec files
      helpers/
    verification/                  # 11 verification scripts
    scripts/                       # 7 diagnostic scripts
  shared/
    schema.ts                      # Minimal (18 lines)
  docs/                            # Documentation
  uploads/                         # User uploads (gitignored)
  .env                             # Environment vars
  .project/                        # /plan mode scratch (to be gutted)
  .agent_docs/                     # Enforcer workspace
  .claude/agents/                  # Agent definitions (only enforcer.md)
  dist/                            # Compiled output (PM2 serves this)
  deploy.sh                        # Safe deploy script
  playwright.config.ts
  tsconfig.json
  package.json
  vite.config.ts
```

---

## 7. Deployment Architecture

### 7.1 Production Environment

Source: REVERSE_SRS_old.md lines 743-796, CLAUDE.md

| Component | Detail |
|-----------|--------|
| Host | Oracle Cloud (server managed by sysadmin project) |
| Reverse proxy | Caddy (managed by sysadmin, SSL termination) |
| Live URL | https://nexxusv2.huminicdev.com |
| Process manager | PM2 (PID 1616575, 148.9 MB, dist/index.cjs) |
| Port | Default 5000 (configurable via PORT env var) |
| Database | Supabase PostgreSQL, aws-0-us-west-2 |
| Branch | master |
| Node.js | Runtime (version not explicitly stated in files) |

### 7.2 Build & Deploy Pipeline

Source: CLAUDE.md "Deployment Workflow" section

```
Working Directory (.ts files) -> npm run build -> dist/ (compiled .cjs) -> PM2 serves
```

**deploy.sh script:**
1. Checks you are on `master` branch (fails if not)
2. Warns about uncommitted changes
3. Runs `npm run build`
4. Restarts PM2

**Feature branch workflow:**
1. `git checkout -b feature/{name}`
2. Do work, commit changes (webserver unchanged -- still serving old dist/)
3. Merge to master
4. `./deploy.sh`
5. Cleanup branch

### 7.3 Environment Variables

Source: VIN_SOLUTIONS_INTEGRATION.md lines 66-71, REVERSE_SRS_old.md line 992, CLAUDE.md

Known env vars (from various files):
- `VIN_SOLUTIONS_CLIENT_ID`, `VIN_SOLUTIONS_CLIENT_SECRET`, `VIN_SOLUTIONS_API_KEY`
- `CONTEXT_ROUTER_ENABLED=true`
- `PORT` (default 5000)
- `SESSION_SECRET` (AES key derivation source)
- `NODE_ENV` (production vs development)
- Database URL(s) -- direct and pgbouncer
- VAPI/Tavus/Resend/TextMagic/Claude API keys
- Google Calendar OAuth credentials

**No `.env.example` file exists** (REVERSE_SRS_old.md line M-10)

---

## 8. Integration Architecture

### 8.1 VIN Solutions

Source: VIN_SOLUTIONS_INTEGRATION.md, DATA_SOURCE_INVENTORY.md, REVERSE_SRS_old.md lines 1005-1055, DEVELOPMENT_TEAM_BRIEFING.md

**Files:**
- `server/services/vinSolutionsService.ts` (1,134 lines) -- API client
- `server/services/vinOAuthService.ts` (156 lines) -- Token management
- `server/jobs/vinTokenRefreshJob.ts` (193 lines) -- 30-min refresh job
- `server/utils/encryption.ts` (73 lines) -- AES-256-GCM
- `server/routes/vin.ts` -- 10 endpoints
- `server/services/sync/SyncCoordinator.ts` -- Queue-based sync
- `server/services/sync/LeadMapper.ts` -- Format mapping

**Auth:** OAuth2 Client Credentials, 60-min tokens, encrypted in `integrations.credentials` JSONB with AES-256-GCM. Key derived from SESSION_SECRET via PBKDF2 (100k iterations).

**Accessible endpoints (13):** GET/POST/PUT leads, leadSources, leadTypes, leadStatuses, leadStatusTypes, leadGroupCategories, contact (CRUD), tenant/user, tenant/dealer (REVERSE_SRS_old.md lines 1009-1025)

**Blocked endpoints (17):** communication, activity, deals, contacts (search), appointments, notes, tasks, calls, calldetails, emails, inventory, vehicles, desking, customer, lead(s) gateway versions (REVERSE_SRS_old.md lines 1033-1053)

**Header versioning (CRITICAL):**
- v1 for reference endpoints: `Accept: application/vnd.coxauto.v1+json`
- v3 for lead CRUD: `Accept: application/vnd.coxauto.v3+json` (lowercase, NOT uppercase V3)
- Gateway: `Accept: application/json`
(DEVELOPMENT_TEAM_BRIEFING.md lines 54-58)

**Lead creation 2-step:** POST /gateway/v1/contact -> get ContactId -> POST /leads with href refs (contact, leadSource, leadType as URLs). (DEVELOPMENT_TEAM_BRIEFING.md lines 40-52)

**Per-org credentials:** Stored in `integrations` table per org, NOT in .env. TextMagic similarly uses per-org DB credentials, not .env. (session-knowledge.md line 208-209)

### 8.2 VAPI (Voice AI)

**Files:** `server/webhooks/vapi.ts`
**Webhook:** `/api/webhooks/vapi`
**Events:** call.started, call.ended, end-of-call-report, transcript, status-update
**Org resolution:** `metadata.organizationId` or `assistantId` lookup in agents table
**Post-processing chain:** Lead extraction -> credit recording -> email notification -> in-app notification -> appointment extraction (if confidence >= 70%) -> sync_queue (lead_to_vin)

### 8.3 Tavus (Video AI)

**Files:** `server/webhooks/tavus.ts`, `server/webhooks/utils/signatureVerifier.ts`
**Webhook:** `/api/webhooks/tavus`
**Events:** conversation.started, conversation.ended, replica.ready, video.ready
**Security:** HMAC-SHA256, 5-min timestamp tolerance
**5 deployed personas:** Caroline (Serra Honda), Magnolia (Serra Nissan), Georgia (Tony Serra Ford), Elizabeth (Hyundai of Columbia), Savannah (Ford of Columbia) (REVERSE_SRS_old.md line 116)

### 8.4 TextMagic (SMS)

**Files:** `server/services/TextMagicService.ts` (1,130 lines), `server/routes/sms.ts`
**Auth:** Username + API key (per-org, from `textmagic_config` table)
**Inbound webhook:** `/api/sms/webhook/inbound` (public, no signature verification)
**Tables:** textmagic_config, textmagic_messages, textmagic_opt_outs, sms_conversation_state
**Not built:** AI auto-reply (schema exists but logic not implemented), business hours routing, collision avoidance state machine (REVERSE_SRS_old.md lines 670-680)

### 8.5 Anthropic Claude (AI)

**Files:** `server/services/DealerBrainService.ts` (3,047 lines), `server/services/DealerBrainStreamingService.ts` (2,020 lines)
**24 tools** exposed to Claude for function calling (REVERSE_SRS_old.md lines 374-399)
**DealerBrain Processor middleware:** Stage 1 (monitoring only). Stages 2-3 (intervention, approval gates) deferred. (REVERSE_SRS_old.md line 401)

### 8.6 Google Calendar

**Files:** `server/services/GoogleCalendarService.ts`, `server/routes/google-calendar.ts`
**Auth:** OAuth2 Authorization Code flow, 7 endpoints
**Functionality:** Connect/disconnect, calendar sync, appointment push, toggle auto-sync

### 8.7 Resend (Email)

**Files:** `server/services/notifications/notificationEmailService.ts`
**Auth:** API key (SDK)
**Purpose:** Transactional email -- lead notifications, welcome emails, appointment confirmations

---

## 9. Real-Time Architecture

Source: server-audit.md line 51, REVERSE_SRS_old.md lines 836-864, CARRY_FORWARD_MANIFEST.md lines 99-117

### 9.1 SSE (Server-Sent Events) -- ACTIVE

- Used for DealerBrain AI chat streaming
- Endpoint: `POST /api/conversations/{id}/stream`
- Also: `POST /api/widgets/public/chat/stream` (widget public SSE)
- 6 event types: thinking, tool_start, tool_end, token, done, error
- Server: DealerBrainStreamingService
- Client: useStreamingMessage.ts hook with AbortController for cancellation

### 9.2 WebSocket -- NOT IN ACTIVE USE

- ARCHITECTURE_VISUAL_MAP.md line 43 mentions "WebSocket" under Daria's monitoring
- server-audit.md line 51: "SSE (Server-Sent Events) for AI streaming, no WebSocket in active use"
- DO_NOT_TOUCH.md Section 8 ("Server WebSocket") exists but appears to be for a dormant/aspirational feature

### 9.3 Polling

- Dashboard auto-refresh: 60s interval, 5-min manual cooldown (REVERSE_SRS_old.md line 495)
- Notification unread count: polling via TanStack Query
- VIN Lead Polling: 60-min server-side job
- Email Sync: 5-min server-side job

---

## 10. Configuration Management

### 10.1 Environment Variables (.env)

Source: VIN_SOLUTIONS_INTEGRATION.md lines 66-71, REVERSE_SRS_old.md line 992

Known variables:
- `PORT` (default 5000)
- `NODE_ENV` (production/development)
- `SESSION_SECRET` (AES key derivation)
- `CONTEXT_ROUTER_ENABLED` (true/false)
- `VIN_SOLUTIONS_CLIENT_ID`, `VIN_SOLUTIONS_CLIENT_SECRET`, `VIN_SOLUTIONS_API_KEY`
- Database connection URLs (Supabase direct + pgbouncer)
- VAPI, Tavus, Resend, TextMagic, Claude API keys
- Google Calendar OAuth client ID/secret
- No `.env.example` template exists (REVERSE_SRS_old.md line M-10)

### 10.2 Database-Stored Configuration

| Table | Purpose | Source |
|-------|---------|--------|
| dealerbrain_config | 3 key-value rows: system_instructions, feedback_enabled, feedback_instructions | database-audit.md line 24 |
| integrations | Per-org API credentials (VIN Solutions OAuth tokens, encrypted) | database-audit.md line 6 |
| textmagic_config | Per-org SMS config (api_username, api_key_encrypted, phone_number, business_hours) | database-audit.md line 40 |
| user_integrations | Per-user email/calendar settings (IMAP/SMTP creds, calendar OAuth tokens) | database-audit.md line 29 |
| widget_configs | Per-org widget config (appearance, channels, targeting, allowed domains) | database-audit.md line 43 |
| credit_policies | Per-org pricing (rate_per_unit, cost_per_unit, monthly_allowance) | database-audit.md line 17 |
| service_quotas | Per-org monthly limits (schema only, no enforcement logic found) | REVERSE_SRS_old.md line 736 |
| roles | 4 RBAC roles with permissions JSONB | database-audit.md line 3 |

### 10.3 Feature Flags

- `CONTEXT_ROUTER_ENABLED` -- env var, was `false` before 2026-02-16 (REVERSE_SRS_old.md line 992)
- Credit page route commented out (intentional defer) (REVERSE_SRS_old.md line 733)
- Billing profile tab commented out (REVERSE_SRS_old.md client-audit)
- No formal feature flag system exists

---

## 11. Frontend Component Map

Source: UI_INTERACTIVE_ELEMENTS_MAP.md, client-audit.md

### 11.1 Components by Page

| Page | Key Components | Interactive Elements |
|------|---------------|---------------------|
| Dashboard (/) | DealershipPulse, GoalProgress, LeadFeed, AgentActions, TeamLeaderboard | 60s auto-refresh, score modals, role-based visibility |
| Chat (/chat) | FloatingChat, ChatPanel, StreamingMessage, SuggestedPrompts, ChatChart | SSE streaming, file upload/paste, favorites |
| Agents (/agents) | Agent list (w-72), chat interface (center), info/stats panel (w-80) | Search, type/status filter, CRUD, duplicate, status toggle |
| Insights (/insights) | VoiceAgentCard, VideoDataCard, LeadFeedCard, AttributionPanel, DealerPulsePanel | 6 tabs, date range filter, modals (transcript, audio, video, leads) |
| Work Center (/work-center) | AppointmentCalendar, AppointmentModal, InboxPanel, SMSComposeDialog | 5 tabs, task CRUD, appointment modal, dialer |
| Settings (/settings/system) | 8 settings tab components, UserDialogs, OrgDialogs | 16+ tabs, user/org CRUD, integration test/delete, trigger config |
| Drive (/drive) | Grid/list view, folder nav, breadcrumbs | Upload, create folder, download, rename, delete |
| Activity (/activity) | Stats cards, activity feed, artifacts tab | Filter, pagination, CSV export (admin) |
| Profile (/profile) | Profile tab, Preferences tab, Google Calendar integration | Dark mode, notification prefs, calendar connect/disconnect |

### 11.2 Layout Components (8)

Source: client-audit.md lines 266-277

| Component | Purpose |
|-----------|---------|
| AppLayout | Main wrapper. ViewConfig system. |
| TopBar | Header (h-14). Logo, org switcher, NotificationBell, ActivityDropdown, theme toggle, profile dropdown. |
| Sidebar | Desktop icon sidebar (w-16, collapsible to w-10). 6 main + 1 admin + logout. Purple active indicator. |
| MobileSidebar | Mobile Sheet-based nav with labels. |
| SubMenuManager | Dynamic panel (w-64) for contextual nav per page. |
| SubMenuPanel | Reusable panel wrapper with header, collapse, scroll. |
| RightPane | Quick-chat pane (w-80). Dual mode: inline or Sheet. DealerBrain streaming. |
| FavoritesBar | Bookmark bar with star toggle. |

---

## 12. Build & Development Pipeline

### 12.1 Build System

Source: CLAUDE.md, health-audit.md

| Tool | Purpose |
|------|---------|
| Vite | Build tool, dev server with HMR |
| TypeScript | Strict mode, compiles to .cjs via Vite |
| Tailwind CSS v4 | CSS utility framework |
| PM2 | Production process manager |
| Caddy | Reverse proxy, SSL (managed externally by sysadmin) |

### 12.2 Build Output

- Source: `.ts` / `.tsx` files
- Output: `dist/` directory (compiled JavaScript `.cjs`)
- Entry: `dist/index.cjs` (PM2 runs this)
- Static: `dist/public/` (served by Express)

### 12.3 Test Infrastructure

Source: health-audit.md lines 144-168

| Framework | Config | Details |
|-----------|--------|---------|
| Playwright | `playwright.config.ts` | ^1.58.1, Chromium, 1280x720, 747 tests |
| Jest | NOT CONFIGURED | 0 unit tests, no jest.config |
| ESLint | NOT CONFIGURED | No .eslintrc |
| Prettier | NOT CONFIGURED | No .prettierrc |
| CI/CD | NOT CONFIGURED | Manual deploys only |

### 12.4 Test Execution

- `npx playwright test` -- E2E tests
- `npm run test:accuracy` -- data-accuracy.ts
- `npm run test:smoke` -- dealerbrain-smoke.ts
- `npm run test:env` -- env-check.ts
- Global setup: `tests/e2e/helpers/global-setup.ts`
- Base URL: `https://nexxusv2.huminicdev.com`

---

## Watch Areas (Owner-Flagged)

### W1. Agent Functionality

Source: session-knowledge.md lines 91-101, REVERSE_SRS_old.md lines 644-656

**Code Locations:**
- Service: `server/services/AgentService.ts`
- Routes: `server/routes/agents.ts` (9 endpoints)
- Table: `agents` (type, config JSONB, performance_metrics JSONB)
- Table: `skills` (name, category, template JSONB, parameters_schema JSONB)
- Table: `agent_runs` (execution tracking)
- Default agents seeded: Automa, Sales Coach, Message Crafter, VAPI voice agent (server-audit.md line 160)
- Automa: always active, cannot be deleted/duplicated
- Skills: 10 skill types in UI, execution not fully connected to runtime (REVERSE_SRS_old.md line 655)
- Performance metrics: GAP -- `performanceMetrics` field exists but never populated by webhooks (REVERSE_SRS_old.md line 654)
- Owner clarification: V1 had 27 hardcoded agents; V2 users CREATE agents and ADD skills. Skills = agent overlays (context + instructions). This is NOT a blocker. (session-knowledge.md lines 52-58)

### W2. Billing / Credits

Source: REVERSE_SRS_old.md lines 726-737

**Code Locations:**
- Service: `server/services/CreditService.ts`
- Routes: `server/routes/credits.ts` (5 endpoints)
- Tables: `credit_policies` (per-org pricing), `credit_allocations` (monthly tracking), `credit_usage` (real-time consumption), `service_quotas` (monthly limits)
- UI: `/credits` route COMMENTED OUT (intentional business decision)
- Backend: Working (policies, allocations, usage, balance calculation)
- Economics: Voice $0.25/min (customer) / $0.15/min (cost) = 40%; Video $0.32/min / $0.20/min = 37.5%; SMS $0.05/msg / $0.02/msg = 60%
- Service quotas: Schema only, no enforcement logic in routes (REVERSE_SRS_old.md line 736)

### W3. Unified Inbox

Source: REVERSE_SRS_old.md line 684, session-knowledge.md lines 17-21

**Code Locations:**
- Service: `server/services/InboxService.ts`
- Routes: `server/routes/inbox.ts` (8 endpoints)
- Tables: `inbox_conversations` (channel, status, assigned_to, widget_visitor_id), `inbox_messages` (sender_type, sender_id, content, channel)
- UI: Work Center > Communication tab > InboxPanel component
- Widget-to-inbox wiring: WidgetInteractionService creates inbox_conversation (channel: 'widget_chat') fire-and-forget (REVERSE_SRS_old.md lines 883-886)
- Owner concept: External agent conversations (via widget) can be continued internally by staff in Unified Inbox (session-knowledge.md lines 17-21)

### W4. Super Admin

Source: session-knowledge.md line 98

**Code Locations:**
- Routes: `server/routes/admin.ts` (14 endpoints, all Super Admin)
- DealerBrain config: `server/routes/dealerbrain.ts` (3 endpoints, Super Admin)
- Activity CSV export: admin-only
- UI: Settings page has Super Admin-only tabs (Users, Organizations, Partner Links, Tools, Hunches, Automa, SMS)
- RLS: 16 tables have Super Admin bypass policy (`app.user_role_level = 1`)
- Sidebar: System settings link visible only to super_admin, partner_admin, org_admin (client-audit.md line 177)
- Note: Owner says this area is "undertested" (session-knowledge.md line 98)

### W5. Context Router

Source: REVERSE_SRS_old.md lines 964-1003, session-knowledge.md line 99

**Code Locations:**
- Service: `server/services/contextRouter/ContextRouterService.ts`
- Source selection: `server/services/contextRouter/SourceSelector.ts`
- Cache: `server/services/contextRouter/CacheManager.ts`
- Config: `CONTEXT_ROUTER_ENABLED=true` in .env (was false before 2026-02-16)
- Priority: VIN API (primary, live) > Local DB (fallback)
- Cache TTLs: VIN leads 5 min, VIN reports 1 hr, VAPI/Tavus 1 hr
- Exclusion: `excel_upload` records filtered out (DEVELOPMENT_TEAM_BRIEFING.md lines 81-83)
- Source tagging: vin_api, local_db, vapi, tavus, manual, widget (internal traceability, not user-facing)

---

## Conflicts Detected

### CONFLICT 1: Architecture Visual Map vs. As-Built Reality

- **File:** ARCHITECTURE_VISUAL_MAP.md line 31
- **Claims:** "Next.js 14 App Router + TypeScript + Tailwind CSS", Zustand + React Query, Redis, ClickHouse, Airbyte -> dbt -> ClickHouse ETL, Cube.js semantic layer, MCP Gateway (port 3010)
- **Reality (REVERSE_SRS_old.md, client-audit.md, server-audit.md):** Vite + React 18 + Wouter, TanStack Query + React Context (no Zustand), no Redis, no ClickHouse, no Airbyte/dbt/Cube.js, no MCP Gateway
- **Assessment:** ARCHITECTURE_VISUAL_MAP.md is a pre-build aspirational design (dated 2026-01-20), NOT an as-built document. The REVERSE_SRS_old.md and audits (dated 2026-02-21) reflect actual implementation.

### CONFLICT 2: Daria Agent Layer

- **File:** ARCHITECTURE_VISUAL_MAP.md lines 47-64
- **Claims:** "Daria (System Agent)" as Layer 2, with NLP parsing, WebSocket monitoring, hunch generation
- **Reality:** DealerBrain/Automa is the system agent. No "Daria" entity exists in codebase. DealerBrainService does tool calling, not NLP intent classification. No WebSocket in active use.
- **Assessment:** "Daria" was V1/planning terminology. V2 implementation uses DealerBrain + Automa.

### CONFLICT 3: Agent Tier Architecture

- **File:** ARCHITECTURE_VISUAL_MAP.md lines 87-116
- **Claims:** 3 specialized tier-2 agents (AutoDealer, ConvoAgent, InsightAgent) with distinct tool sets
- **Reality:** Agents are user-configurable entities stored in `agents` table. No hardcoded specialized agents except Automa. 24 tools are available to DealerBrain (all of them), not partitioned by agent tier.
- **Assessment:** V1 concept of specialized agents was replaced by user-created agents + skills model. This matches owner clarification in session-knowledge.md lines 52-58.

### CONFLICT 4: Table Count

- **File:** CLAUDE.md says "36 tables", REVERSE_SRS_old.md says "53 tables"
- **Reality:** 53 CREATE TABLE statements across migrations (database-audit.md line 63). CLAUDE.md is outdated.

### CONFLICT 5: Endpoint Count Discrepancy

- **File:** server-audit.md line 34 says "~185 endpoints", REVERSE_SRS_old.md says "~237 endpoints"
- **Assessment:** Both are approximations from different counting methods. The REVERSE_SRS_old.md uses a broader count (includes sub-paths and webhook variations). The server-audit.md counts distinct handler functions. Use ~237 as the upper bound.

### CONFLICT 6: SecureQueryBuilder vs. Direct Pool

- **Files:** database-audit.md lines 194-218, DEVELOPMENT_TEAM_BRIEFING.md lines 62-75
- **Issue:** SecureQueryBuilder sets `app.current_organization_id` but all RLS policies check `app.current_org_id`. Most routes bypass SecureQueryBuilder and use direct `set_config()`. The intended centralized security path is architecturally broken.
- **Impact:** HIGH -- security depends on each route handler remembering to set the correct variable directly.

---

## Missing Information

### M1. No `.env.example` -- full list of required env vars undocumented
Source: REVERSE_SRS_old.md line M-10

### M2. No deployment rollback mechanism
Source: REVERSE_SRS_old.md line H-9

### M3. No PM2 ecosystem config file
Source: REVERSE_SRS_old.md line M-9

### M4. Express 5 pre-release -- version pinning not documented
Source: REVERSE_SRS_old.md line M-12

### M5. shared/schema.ts minimal (18 lines) -- type sharing between client/server negligible
Source: REVERSE_SRS_old.md line L-1

### M6. No structured logging -- 242 unstructured console.log (server)
Source: REVERSE_SRS_old.md line H-4

### M7. AI auto-reply logic not implemented despite schema support
Source: REVERSE_SRS_old.md lines 670, 680

### M8. SMS collision avoidance state machine not implemented despite schema
Source: REVERSE_SRS_old.md line 680

### M9. Service quotas table exists but no enforcement logic in routes
Source: REVERSE_SRS_old.md line 736

### M10. Metrics fragmented across 5 services -- no unified MetricsEngine wiring
Source: REVERSE_SRS_old.md line 699

---

## Cross-Wave Notes

### For PRD (Wave 1)
- The technology choices and architecture support the partner-enabled, multi-tenant, AI-first business model
- Per-usage economics (voice/video/SMS) are wired at the DB schema level but the credits UI is deferred

### For SRS (Wave 2)
- The Context Router's source prioritization (VIN > Local > Derived) is both an architectural and behavioral pattern
- SSE streaming protocol details (6 event types) are SRS-relevant for "what happens when user chats"
- Trigger evaluation flow with 7 event types and 5 action types describes system behavior
- Widget-to-inbox handoff flow describes continuity behavior between external and internal surfaces

### For PLAN (Wave 4)
- RLS variable mismatch (C-1) is a known architecture fix
- Missing migration 011, duplicate 004 prefix are migration hygiene items
- 0 unit tests, no ESLint/Prettier/CI are infrastructure gaps
- Service quotas enforcement, SMS collision avoidance, AI auto-reply are schema-ready but unbuilt features

### For AC (Wave 5)
- 747 E2E tests exist covering auth, RBAC, all major features
- Hosted pages route mismatch is a testable regression
- Insights crash (4 unsafe .pct accesses) is a testable fix

### For CLAUDE.md (Wave 6)
- Stale data in CLAUDE.md (table count, phase status, etc.) needs correction
- Truth hierarchy: UI (Replit mockup) > AC > Release Plan
- Enforcer is the only agent file in .claude/agents/

---

## Source File Log

| File | Relevance | Sections Extracted From |
|------|-----------|------------------------|
| REVERSE_SRS_old.md | PRIMARY | All 12 sections. Most comprehensive source for as-built architecture. |
| database-audit.md | PRIMARY | Sections 3, 6 (schema, RLS, FKs, JSONB, indexes) |
| server-audit.md | PRIMARY | Sections 2, 4 (routes, endpoints, middleware, services) |
| client-audit.md | PRIMARY | Sections 5, 11 (pages, components, state, hooks, routing) |
| health-audit.md | PRIMARY | Sections 1, 12 (metrics, test inventory, dependencies) |
| DO_NOT_TOUCH.md | HIGH | Sections 2, 6 (backend freeze list, service inventory, all file paths) |
| CARRY_FORWARD_MANIFEST.md | HIGH | Sections 5, 6, 9 (hooks, contexts, API client, SSE, auth tokens) |
| ARCHITECTURE_GUIDE.md | HIGH | Section 5 (layout system, 3-pane grid, responsive) |
| ARCHITECTURE_VISUAL_MAP.md | MEDIUM | Conflicts section (aspirational vs as-built delta) |
| VIN_SOLUTIONS_INTEGRATION.md | HIGH | Section 8 (VIN integration files, auth, env vars) |
| DATA_SOURCE_INVENTORY.md | HIGH | Section 8 (VIN API endpoints, header requirements, blocked endpoints) |
| DEVELOPMENT_TEAM_BRIEFING.md | HIGH | Sections 3, 8 (hard-won lessons, header casing, RLS bug, lead sync) |
| UI_INTERACTIVE_ELEMENTS_MAP.md | MEDIUM | Section 11 (component-to-handler mapping) |
| UNIFIED_HANDOFF_PROMPT.md | MEDIUM | Sections 7, 10 (deployment, conflict resolution, document reading order) |
| IMPLEMENTATION_PLAN.md | LOW | Section 4 (endpoint references, file:line fix targets) |
| MASTER_SRS.md | LOW | Section 1 (RBAC roles, naming conventions) |
| CONSTITUTION.md | LOW | Section 8 (truth hierarchy for Context Router) |
| THEME_CONTRACT.md | MEDIUM | Section 5 (design token system, color tokens TypeScript interface) |
| CLARIFICATION_ANSWERS.md | MEDIUM | Sections 8, 10 (VIN write-back, Context Router, widget options, SMS decisions) |
| app_identity.md | LOW | Section 1 (platform identity confirmation) |
| session-knowledge.md | HIGH | Watch Areas (skills architecture, payment-critical, agent functionality) |
| CLAUDE.md (preflight-input) | LOW | Sections 6, 7, 10 (pre-enforcer version, stale but has project structure) |
| other_notes/Standards.md | LOW | Section 6 (owner's governance file structure definition) |

**Files SKIPPED per instructions:** replit_reference.textClipping, Chat-Checklist.pdf, --Insights Layout copy.md

---

**END OF WAVE 3 REVIEWER EXTRACTION**
