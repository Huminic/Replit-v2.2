# Wave 1 REVIEWER Output -- Business Context for PRD

**Agent:** REVIEWER
**Wave:** 1 (Business Context -> PRD)
**Date:** 2026-03-02
**Input Files Read:** 50 of 53 (3 skipped: binary artifact, blank PDF, duplicate layout)
**Method:** Extraction only -- no inferences made beyond what files explicitly state

---

## CATEGORY 1: Product Identity

### 1.1 What Nexxus IS

- "AI orchestration layer that bridges businesses, their data, third-party integrations, language models, and tools." (MASTER_SRS.md, line 1, Section 2.1)
- "Partner-enabled platform." Domain experts recruit customers into segments and manage them through the platform. (app_identity.md, Section A3)
- First vertical is automotive dealerships, but "the platform is industry-agnostic by design; automotive is the first vertical, not the only one." (app_identity.md, Section A2; MASTER_SRS.md, Section 2.2)
- "Intelligent execution layer for automotive dealerships that solves response gaps and follow-up inconsistencies through AI-powered voice, video, and chat interactions." (NEXXUS_V2_BOOTSTRAP_PROMPT.md, line 20)
- Core value proposition: "Dealerships don't lose because of lead volume -- they lose because of response gaps and execution failures. Nexxus fixes this." (CLAUDE.md line 9; NEXXUS_V2_BOOTSTRAP_PROMPT.md line 24)

### 1.2 What Nexxus IS NOT

- "NOT a CRM" (app_identity.md, Section A6)
- "NOT a marketing automation tool" (app_identity.md, Section A6)
- "NOT a content development platform" (app_identity.md, Section A6)
- "NOT a lead generation tool" (NEXXUS_V2_BOOTSTRAP_PROMPT.md, line 22)

### 1.3 Platform Operator

- Huminic (company), operated by Duane Wells (MASTER_SRS.md, Section 1; session-knowledge.md, line 10)
- Live URL: https://nexxusv2.huminicdev.com (health-audit.md, line 7)

### 1.4 Naming Conventions

- DealerBrain = the concept/system (AI intelligence layer)
- Automa = the user-facing chat interface name
- Skills = agent capabilities (user-selectable overlays with context + instructions)
- "Chat on main page = Automa. DealerBrain omitted from user-facing naming." (===DevDesign Notes===.md)
- No vendor names (Tavus, VAPI) in user-facing UI. Use "Voice Agent", "Video Agent", "AI Assistant" instead. (CONSTITUTION.md, Section: UI Rules; MASTER_SRS.md, AC-002)

---

## CATEGORY 2: Target Customers

### 2.1 Business Model

- Partner-enabled delivery model. (app_identity.md, Section A3; MASTER_SRS.md, Section 2.3)
- First partner: Duran Cage, automotive sales expert. (app_identity.md, Section A7; REVERSE_SRS_old.md, line 87)

### 2.2 Current Customers

| Customer | Status | Deployed | Dealer IDs |
|----------|--------|----------|------------|
| Serra Automotive | Live | 2026-01-16 | 21043 (Serra Honda), 21044 (Serra Nissan), 21047 (Tony Serra Ford) |
| Hyundai of Columbia | Live | 2026-01-16 | 6374 (needs verification) |
| Ford of Columbia | Live | 2026-01-16 | 3027 (needs verification) |

(REVERSE_SRS_old.md, lines 109-116; CUSTOMER_ONBOARDING_KICKOFF.md, Section 6)

### 2.3 Tavus Video Agents Deployed

5 named agents across customers: Caroline (Serra Honda), Magnolia (Serra Nissan), Georgia (Tony Serra Ford), Elizabeth (Hyundai of Columbia), Savannah (Ford of Columbia). (REVERSE_SRS_old.md, line 116)

### 2.4 Target Verticals

- Automotive dealerships (current first vertical)
- Platform designed to scale to other industries via the partner model. (app_identity.md, Section A2)

---

## CATEGORY 3: Business Model / Economics

### 3.1 Revenue Model

Per-usage AI economics plus platform subscription. (INIT_PROJECT_ANSWERS.txt, Q8)

| Service | Customer Rate | Platform Cost | Margin |
|---------|--------------|---------------|--------|
| Voice AI (VAPI) | $0.25/min | $0.15/min | 40% |
| Video AI (Tavus) | $0.32/min | $0.20/min | 37.5% |
| SMS (TextMagic) | $0.05/msg | $0.02/msg | 60% |

(MASTER_SRS.md, Section 12; CLAUDE.md, lines 317-319; UNIFIED_HANDOFF_PROMPT.md)

### 3.2 Credit System

- CreditService tracks usage per organization, wired to webhooks (Phase 6 complete). (MASTER_SRS.md, line 917)
- Service quotas tracked in `service_quotas` and `service_allocations` tables with alerts at 80% usage. (MASTER_SRS.md, line 917)
- Credit policies per org: rate_per_unit, cost_per_unit, monthly_allowance, overage_rate. (database-audit.md, table 17)
- Billing page commented out as PHASE-FUTURE in frontend. (client-audit.md, line 94)

### 3.3 Tool Provisioning Flow

- Super Admin provisions tools -> Partner Admin manages orgs -> Org Admin uses tools. (ARCHITECTURE_GUIDE_RBAC_ADDITION.md, line 72-77)
- Tools "pushed down" to organizations by Super Admin. Partner Admin can view usage but cannot configure. (ARCHITECTURE_GUIDE_RBAC_ADDITION.md, line 74-76)

---

## CATEGORY 4: User Roles & Permissions

### 4.1 Four-Tier RBAC

| Role | Level | Description | Typical User |
|------|-------|-------------|-------------|
| super_admin | 1 | Platform-wide access, provisions tools, manages partners | Huminic (Duane Wells) |
| partner_admin | 2 | Multi-org management, aggregate metrics, no PII | Duran Cage, partner operators |
| org_admin | 3 | Single org management, users, settings, full org data | Dealership Sales Manager, BDC Manager |
| org_staff | 4 | Daily operational use, personal leads/tasks only | Salesperson, BDC Agent |

(MASTER_SRS.md, Section 3.1-3.3; app_identity.md, Section D1-D4; CLAUDE.md, lines 303-307)

### 4.2 Key Permission Distinctions

- Staff CANNOT see Settings. (===DevDesign Notes===.md)
- Partner Admin sees aggregate data across assigned orgs, NO individual lead data (no PII). (MASTER_SRS.md, AC-010)
- Partner Admin has READ-ONLY view of AI Configuration. (DESIGNER_UPDATE_SPEC.md, Section 1)
- Org Admin sees all org data. Org Staff sees only own assignments. (MASTER_SRS.md, Section 7.4)
- Activity page: Org Admin+ only. (UI_DEVELOPER_HANDOFF.md, line 57)

### 4.3 Multi-Org Support

- Partner Admin can switch between assigned orgs via org switcher in top bar. (client-audit.md, line 154)
- `partner_admin_organizations` junction table maps partners to orgs. (database-audit.md, table 5)

---

## CATEGORY 5: Feature Inventory

### 5.1 Navigation / UI Sections

Left sidebar navigation order (from ===DevDesign Notes===.md; app_identity.md, Section B):

1. **Main** (Home/Chat) -- Automa chat interface
2. **Insights** -- Dashboard, Dealer Pulse, Goals, Hunches, Reports, Attribution
3. **Agents** -- Agent management, creation, chat interface
4. **Hub** (Work Center) -- Calendar, Leads, Inbox (3 tabs per DESIGNER_UPDATE_SPEC.md)
5. **Drive** -- File management, templates

Bottom:
6. **System** (Settings) -- 9 tiles, role-gated
7. **Profile** -- Edit, preferences, integrations

### 5.2 Main Page / Automa Chat

- DealerBrain AI chat with SSE streaming via Claude API. (client-audit.md, line 85)
- 24 tools available to Claude for function calling. (REVERSE_SRS_old.md, lines 376-399)
- Conversation history in left panel. File upload and paste-data features. (client-audit.md, line 85)
- FloatingChat global overlay (not inline on dashboard). (ACCEPTANCE_VERIFICATION_REPORT.md, AC-1)

### 5.3 Insights Section

- **Dashboard**: Command Center (3-zone alert: Red/Yellow/Green), Pipeline Health, Performance Scorecard, DealerPulse health gauges, Lead Feed, Agent Actions, Team Leaderboard. (---Insights Layout.md; client-audit.md, line 86)
- **Goals**: CRUD with status tracking, target values, current values, periods. (client-audit.md, line 86)
- **Reports**: 6 priority reports: Deal Death Autopsy, Lead Source Quality, Channel Performance, Pipeline Velocity, Active Lead Triage, Deal Status Snapshot. (---Reports.md)
- **Hunches**: AI-generated insights by "The Detective" agent prompt. 5-10 hunches per run with confidence scoring and opportunity sizing. (---Hunches.md; Hunch Instructions.md)
- **Dealer Pulse**: 5-phase health snapshots, 4-hour refresh cycle. (REVERSE_SRS_old.md, line 366)
- **Attribution**: Tracking pixel for UTM and page visit tracking. (client-audit.md, line 86)

### 5.4 Role-Based Dashboard Tiles

**Partner Admin tiles**: # sub orgs, customer logins 24hrs, actions 24hrs, agent actions 24hrs. (===DevDesign Notes===.md)

**Org Admin tiles** (scored 0-100 each):
- Pipeline Health Score
- Lead Source Performance Score
- Lead Quality Score
- Market Demand Insight Score
(---Org admin Metrics - Main - org admin.md)

**Staff tiles** (scored 0-100 each):
- Hot Opportunities
- What Customers Are Buying (Buying Intelligence)
- Competitive Threat Alert
- Pipeline Urgency
(---Staff Metrics.md)

### 5.5 Agents Page

- Three-column layout: agent list, chat interface, info/artifacts/stats panel. (client-audit.md, line 87)
- Agent creation wizard: Basic Info, Channel Config (voice/video/chat/email/task), Skills, Triggers, Review. (client-audit.md, line 88)
- Default agents seeded: Automa (system, cannot be deleted/duplicated), Sales Coach, Message Crafter, VAPI voice agent. (server-audit.md, line 160)
- Communications Agent is static, configured by Super Admin. 2 agents available out of box. (===DevDesign Notes===.md)
- Skills architecture: users CREATE agents and ADD skills. Skills = pre-prompting, context, instructions. Same concept as V1's 27 agents but now user-selectable. (session-knowledge.md, Section 0b)

### 5.6 Hub (Work Center)

- **3 tabs** (confirmed by owner, per DESIGNER_UPDATE_SPEC.md): Calendar, Leads, Inbox
- Calendar: AppointmentCalendar + AppointmentModal, FullCalendar integration. (client-audit.md, line 90)
- Leads: Status management with mark-contacted. (client-audit.md, line 90)
- Inbox: Universal inbox merging SMS + widget chat + email (InboxPanel). (client-audit.md, line 90)
- Quick action buttons. (===DevDesign Notes===.md)
- Dialer with keypad. (UI_INTERACTIVE_ELEMENTS_MAP.md, line 85)

### 5.7 Drive

- File management with grid/list view toggle. Folder navigation with breadcrumb trail. Upload, create, delete, download. Storage usage display. (client-audit.md, line 92)

### 5.8 Settings

- 9 tiles: Users, Organization, Tools & Integrations, Knowledge Base, AI Configuration, Security & Privacy, Notifications, Data Management, Appearance. (DESIGNER_UPDATE_SPEC.md, Section 1)
- Previously had standalone API & Webhooks tile -- REMOVED, moved inside Tools & Integrations. (DESIGNER_UPDATE_SPEC.md, Section 1)
- Sub-menu for Tools gets additional sub-items. (DESIGNER_UPDATE_SPEC.md)
- Org Creation Wizard accessible from Settings (Super Admin only). (DESIGNER_UPDATE_SPEC.md, Section 15)
- Context Router should have 3 sections: Memory stores, Sync Data, Upload Data Store + Web/3rd party. (===DevDesign Notes===.md)

### 5.9 Widget System

- 6 channel options: Text Chat, Voice Inbound, Voice Outbound, Video Agent, Web Audio, Send a Text. (CLARIFICATION_ANSWERS.md, Q7)
- Enable/disable per org + custom items with URL. (CLARIFICATION_ANSWERS.md, Q7)
- 3 deployment modes: unified floating widget, embed code, hosted landing pages. (session-knowledge.md, Section 0)
- Widgets are portals to agents (not standalone features). (session-knowledge.md, Section 0)
- Widget configuration is HIGHER PRIORITY than expected. (CLARIFICATION_ANSWERS.md, Q17)
- Domain whitelist enforcement, rate limiting (100 interactions/hour/visitor). (MASTER_SRS.md, Section 11.2)
- Preact-based bundle: 50.13 KB minified. (ACCEPTANCE_VERIFICATION_REPORT.md, AC-6)

### 5.10 Trigger System

- 7 event types: new_lead, lead_status_change, missed_call, appointment_scheduled, inbound_message, hot_lead, custom. (ACCEPTANCE_VERIFICATION_REPORT.md, AC-11)
- 5 action types: outbound_call, send_sms, send_email, create_task, webhook. (ACCEPTANCE_VERIFICATION_REPORT.md, AC-11)
- Rate limiting, business hours checking, prior-contact detection. (CUSTOMER_ONBOARDING_KICKOFF.md, AC-1)
- "Neglected Lead Auto-Call" template ready: call if no contact after 2 hours. (CUSTOMER_ONBOARDING_KICKOFF.md)
- #1 PRIORITY is auto-outbound when leads go unattended. (CLARIFICATION_ANSWERS.md, Q9)
- hot_lead event has NO firing call site in codebase. (ACCEPTANCE_VERIFICATION_REPORT.md, AC-11)
- 0/84 trigger executions completed in production (45 failed, 39 skipped). (ACCEPTANCE_VERIFICATION_REPORT.md, AC-5)

### 5.11 Activity

- AI Governance page. Stats cards, activity feed with filtering, CSV export for admins. (client-audit.md, line 93)
- Activity moving to sub-tab in Insights (per ===DevDesign Notes===.md)

### 5.12 Additional Features

- Product tour (driver.js) needs reactivation with RBAC. (===DevDesign Notes===.md)
- Google Calendar OAuth per-user sync. (MASTER_SRS.md, Section 6.6)
- Email system: IMAP/SMTP + Resend for transactional. (server-audit.md; MASTER_SRS.md, Section 6.5)
- Password reset flow. (client-audit.md, line 78)

---

## CATEGORY 6: External Interaction Surfaces

### 6.1 VAPI (Voice AI)

- Master API key, assistants tagged with org metadata. (CLAUDE.md, line 224)
- 15 of 16 endpoints accessible. (MASTER_SRS.md, Section 6.2)
- Webhook at `/api/webhooks/vapi`: processes call.started, call.ended, end-of-call-report, transcript, status-update. (REVERSE_SRS_old.md, line 341)
- Org resolution via `metadata.organizationId` or `assistantId` lookup in agents table. (MASTER_SRS.md, Section 7.3)
- 18 total assistants on VAPI account, 5 registered in V2 agents table. (DATA_ACCURACY_REPORT.md, line 92)
- Outbound call API: `POST https://api.vapi.ai/call` with assistantOverrides. (CUSTOMER_ONBOARDING_KICKOFF.md, AC-1)

**CRITICAL DATA ISSUE**: Real-time webhook ingestion is broken. All 137 real records were BULK IMPORTED, not created by webhooks. `call.started` events are not being received for production calls. `end-of-call-report` UPDATE finds no row and silently loses data. PM2 has restarted 3,247 times. (DATA_ACCURACY_REPORT.md, lines 98-139)

### 6.2 Tavus (Video AI)

- Master API key, org-specific personas, HMAC-SHA256 webhook verification. (REVERSE_SRS_old.md, line 332)
- 10 of 11 endpoints accessible. `/landing-pages` returns 404. (MASTER_SRS.md, Section 6.3)
- Webhook at `/api/webhooks/tavus`: conversation.started, conversation.ended, replica.ready, video.ready. (REVERSE_SRS_old.md, line 347)
- No cost API available. Video cost tracking requires manual rate application ($0.20/min). (MASTER_SRS.md, Section 10.6)

### 6.3 TextMagic (SMS)

- Per-org phone numbers, two-way via inbound webhook. (MASTER_SRS.md, Appendix C)
- SMS outbound-only for now; bi-directional when each store gets own number. (CLARIFICATION_ANSWERS.md, Q8)
- AI SMS responses powered by DealerBrain (Claude API), NOT VAPI. (MASTER_SRS.md, Section 6.4)
- Conversation state tracking: AI_ACTIVE / HUMAN_ACTIVE / DORMANT. (MASTER_SRS.md, Section 6.4)
- Collision avoidance: human takeover stops AI responses. (MASTER_SRS.md, Section 6.4)
- Shared phone `18338096836` assigned to 3 orgs -- first DB match wins routing. (ACCEPTANCE_VERIFICATION_REPORT.md, AC-2)
- TextMagic inbound webhook has no signature verification (TextMagic does not sign). (REVERSE_SRS_old.md, line 352)

### 6.4 Widgets

- Embeddable JavaScript widget serving as portal to VAPI, Tavus, and internal agents. (session-knowledge.md, Section 0)
- Hosted pages at `/w/:slug`: 5 deployed slugs (serra-honda, serra-nissan, tony-serra-ford, hyundai-columbia, ford-columbia). (ACCEPTANCE_VERIFICATION_REPORT.md, AC-7)
- 4 page types: chat, video, callback, multi. (client-audit.md, line 102)

---

## CATEGORY 7: Internal Interaction Surfaces

### 7.1 Automa Chat (DealerBrain)

- Claude API integration with tool calling and SSE streaming. (REVERSE_SRS_old.md, line 299)
- DealerBrainService: 3,047 lines. DealerBrainStreamingService: 2,020 lines. (REVERSE_SRS_old.md, lines 299-300)
- 24 tools available for function calling including: query_leads, query_vapi_calls, query_tavus_sessions, query_vin_data, create_goal, create_agent, get_lead_details, get_call_transcript, check_availability, create_appointment, create_task, send_sms, get_dashboard_metrics, get_dealer_pulse, query_credit_usage, get_org_settings. (REVERSE_SRS_old.md, lines 376-399)
- Goal awareness injected into AI context. (CUSTOMER_ONBOARDING_KICKOFF.md, AC-2)
- System prompt should include explicit list of available vs blocked data. (MASTER_SRS.md, AC-011)

### 7.2 Agents Page

- IS the chat agents feature. `type` field = channel integration. (session-knowledge.md, Section 6)
- Users CREATE agents and ADD skills (V2 architecture). Skills catalog draws from what V1's 27 agents used to do. (session-knowledge.md, Section 0b)

### 7.3 Unified Inbox

- Merges SMS, widget chat, and email into single inbox. (client-audit.md, line 90; ACCEPTANCE_VERIFICATION_REPORT.md, AC-3)
- External agent conversations can be continued internally by staff. (session-knowledge.md, Section 0)
- Continuity between external and internal surfaces. (session-knowledge.md, Section 0)

### 7.4 Metrics / Insights

- 50+ derivable metrics across 5 categories: Pipeline Health, Sales/Dealership Performance, Voice Agent Performance, Video Agent Performance, Cross-Platform. (MASTER_SRS.md, Sections 8.3.1-8.3.5)
- Metrics currently fragmented across ~5 services, need consolidation into unified MetricsEngine. (MASTER_SRS.md, Section 7.6)
- 80+ computable metrics from VIN Solutions data documented. (---Tiles - Available data..md)

---

## CATEGORY 8: Data Sources & Architecture

### 8.1 Truth Hierarchy

| Priority | Source | Notes |
|----------|--------|-------|
| 1 (highest) | VIN Solutions API | Authoritative CRM data. Query + limited write. |
| 2 | VAPI / Tavus webhooks | AI interaction records with transcripts, costs, analysis. |
| 3 | Local database | Nexxus-internal data. User records, configs, local records. |
| 4 (lowest) | Derived / computed | Metrics, scores, aggregations. |

(MASTER_SRS.md, Section 7.1; CONSTITUTION.md)

### 8.2 Context Router

- `SourceSelector` uses VIN API as primary, local DB as fallback. (MASTER_SRS.md, Section 7.2)
- `CONTEXT_ROUTER_ENABLED=true` in `.env`. (MASTER_SRS.md, Section 7.2)
- Source tags: VIN, VAPI, TAVUS, LOCAL -- internal only, NOT shown in UI. (MASTER_SRS.md, Section 7.2)
- Cache TTL: 5 min VIN leads, 1 hour VAPI/Tavus, no cache for local-only. (MASTER_SRS.md, Section 7.2)
- Fallback: VIN fail -> local cache with staleness warning in logs (not UI). (MASTER_SRS.md, Section 7.2)
- `excel_upload` records excluded from ALL lead queries (32+ queries, 11 files). (MASTER_SRS.md, Section 7.2)
- Was initially inverted (local primary, VIN fallback) -- corrected. (DEVELOPMENT_TEAM_BRIEFING.md, Section 6)

### 8.3 VIN Solutions API

- OAuth 2.0 Client Credentials, tokens expire every 60 minutes. (VIN_SOLUTIONS_INTEGRATION.md)
- 13 accessible endpoints, 17 blocked (403). (MASTER_SRS.md, Section 6.1)
- Lead creation is 2-step: create contact via gateway, then create lead with href references. (MASTER_SRS.md, Section 7.3)
- Headers: lowercase `v3` required (production rejects uppercase). (MASTER_SRS.md, Section 10.4; DEVELOPMENT_TEAM_BRIEFING.md, Section 3)
- `/leads` does NOT support `userId` filter -- returns 404; must filter locally. (MASTER_SRS.md, line 802)
- Rate limits: 250ms minimum delay between calls. (MASTER_SRS.md, line 805)
- CAN measure: AI performance, pipeline state, outcomes, vehicle demand, staff roster. (MASTER_SRS.md, Section 7.5)
- CANNOT measure: human execution quality, deal economics, appointment conversion, inventory metrics, CRM activity detail. (MASTER_SRS.md, Section 7.5)

### 8.4 Data Refresh Strategy

- Hybrid: pull once a day + manual refresh button. (CLARIFICATION_ANSWERS.md, Q4-Q5)
- VIN polling every 4 hours, discreet refresh button. (CLARIFICATION_ANSWERS.md, Q18)
- Excel upload data NEVER supposed to be in DB; Context Router must tag/categorize. (CLARIFICATION_ANSWERS.md, Q6)

### 8.5 Database

- 53 tables with 100% RLS coverage. ~100 RLS policies. 160+ indexes. 33 migrations. (database-audit.md)
- Supabase (PostgreSQL) with pgbouncer connection pooling. (REVERSE_SRS_old.md, line 144)
- `SecureQueryBuilder` intended as centralized security layer, but has RLS variable name mismatch (`app.current_organization_id` vs `app.current_org_id`). Most routes bypass it. (database-audit.md, Section 4; DEVELOPMENT_TEAM_BRIEFING.md, Section 4)

### 8.6 Integrations (7 Third-Party Systems)

| Integration | Auth | Purpose |
|-------------|------|---------|
| VIN Solutions | OAuth2 Client Credentials | CRM: leads, contacts, dealers, users |
| VAPI | Webhook + shared secret | Voice AI call data, transcripts |
| Tavus | HMAC-SHA256 + API key | Video AI session data |
| Resend | API key | Transactional email |
| TextMagic | Username + API key | SMS send/receive |
| Anthropic Claude | API key | AI chat, tool calling, content generation |
| Google Calendar | OAuth2 Authorization Code | Calendar sync |

(REVERSE_SRS_old.md, Section 3.2.3)

### 8.7 Scheduled Jobs (8)

| Job | Interval | Purpose |
|-----|----------|---------|
| VIN Token Refresh | 30 min | OAuth token refresh |
| Sync Queue Worker | 1 min (outbound), 4 hrs (inbound) | VIN sync |
| Appointment Reminder | 5 min | 24h and 2h reminders |
| Email Sync | 5 min | IMAP sync |
| VIN Lead Polling | 60 min | Import new leads |
| Trigger Re-evaluation | 5 min | Age-based trigger conditions |
| Dealer Pulse | 4 hrs | Health snapshots |
| Hunch Generation | 6 hrs | AI insights |

(REVERSE_SRS_old.md, Section 3.2.5)

---

## CATEGORY 9: Key Business Rules

### 9.1 Data Accuracy Rules

- "Data accuracy is non-negotiable." (CLARIFICATION_ANSWERS.md, OVERARCHING MANDATE)
- Metric certification requires: >50% field fill rate, ground truth match within 2%, accessible data source. (MASTER_SRS.md, Section 8.2)
- Metrics depending on blocked endpoints are excluded entirely -- not shown, not placeholdered. (MASTER_SRS.md, Section 7.5)
- No source labels visible to end users. (MASTER_SRS.md, AC-003; CONSTITUTION.md)
- No placeholder UI. (CONSTITUTION.md)
- No vendor names in UI. (CONSTITUTION.md; MASTER_SRS.md, AC-002)

### 9.2 Communication Rules

- Most actionable activities go through an agent at the user level. (session-knowledge.md, Section 0)
- Communication agent cannot be modified by user except triggers and instruction supplement. (session-knowledge.md, Section 0)
- Scheduling is a hub action (both user and agent can do it). (session-knowledge.md, Section 0)
- Lead assignment is NOT part of requirements. (session-knowledge.md, Section 0)

### 9.3 Appointment Flow

- Appointments go in OUR calendar (not VIN Solutions -- VIN has no appointment endpoint). (CLARIFICATION_ANSWERS.md, Q1)
- Google Calendar is sync target, not source of truth. (MASTER_SRS.md, Section 6.6)
- VIN Solutions CAN create leads (verified). (CLARIFICATION_ANSWERS.md, Q1)

### 9.4 Security Rules

- RLS from day 1 on all tables. (CLAUDE.md, line 29)
- JWT authentication (NOT express-session). Access: 15 min, Refresh: 7 days. (MASTER_SRS.md, Section 11.2; INIT_PROJECT_ANSWERS.txt, Q9)
- AES-256-GCM encrypted storage for OAuth tokens and API keys. (MASTER_SRS.md, Section 11.2)
- Multi-tenant isolation at database level via organization_id FK + RLS. (MASTER_SRS.md, Section 11.2)
- Webhook security: VAPI via assistantId/metadata lookup, Tavus via HMAC. (MASTER_SRS.md, Section 11.2)

### 9.5 Honest AI Principle

- DealerBrain must not fabricate information. (CONSTITUTION.md)
- When asked about blocked data, must explain unavailability and offer alternatives. (MASTER_SRS.md, AC-011)
- 50% fill rate minimum for metric certification. (CONSTITUTION.md)

---

## CATEGORY 10: Competitive Positioning

### 10.1 Stated Differentiators

- AI-first platform (not retrofitted AI onto existing tool). (app_identity.md, Section A4)
- Partner-enabled model scales via domain experts. (app_identity.md, Section A3)
- Bridges multiple AI modalities (voice, video, chat, SMS) in one platform. (app_identity.md)
- Widgets are portals to agents -- not standalone chat widgets. Continuity between external conversations and internal staff follow-up. (session-knowledge.md, Section 0)

### 10.2 What Files Say About Competition

No files explicitly name competitors. The positioning is defined negatively ("NOT a CRM, NOT marketing automation") and positively ("AI orchestration layer," "intelligent execution layer").

---

## PAYMENT-CRITICAL DEMO ITEMS

### DEMO-1: Metrics & Insights Display Correctly

**File evidence:**
- Dashboard with DealerPulse health gauges, lead feed, team leaderboard implemented. (client-audit.md, line 84)
- All queries use real DB sources, excel_upload excluded. (ACCEPTANCE_VERIFICATION_REPORT.md, AC-10)
- Source labels masked. (ACCEPTANCE_VERIFICATION_REPORT.md, AC-10)
- 4 org admin tiles and 4 staff tiles defined with score formulas. (---Org admin Metrics.md; ---Staff Metrics.md)
- Metrics fragmentation across 5 services needs consolidation. (MASTER_SRS.md, Section 7.6)
- **Status per CUSTOMER_ONBOARDING_KICKOFF.md**: Ready to demo.

### DEMO-2: Communications Agent Configuration

**File evidence:**
- Communications Agent is static, configured by Super Admin. (===DevDesign Notes===.md)
- 7 event types, 5 action types in trigger system. (ACCEPTANCE_VERIFICATION_REPORT.md, AC-11)
- Conditional triggers configurable per agent: IF [field] [operator] [value] THEN notify [user]. (MASTER_SRS.md, AC-013)
- Can use VIN Solutions fields and system criteria. (session-knowledge.md, Section 0c)
- **Gap**: hot_lead event has no firing call site. 0/84 executions completed. (ACCEPTANCE_VERIFICATION_REPORT.md)

### DEMO-3: Appointment Flow

**File evidence:**
- Appointments live in local `appointments` table, sync to Google Calendar. (MASTER_SRS.md, Section 6.6)
- AppointmentService handles CRUD with RBAC. 10 endpoints. (server-audit.md, lines 162-176)
- Public confirmation endpoint with signed JWT. (server-audit.md, line 175)
- **Gap**: Lead inserted into VIN with appointment note -- no explicit file evidence of the "note about appointment" step in VIN lead creation. Lead creation pipeline exists (webhook -> sync_queue -> VIN), but appointment-to-VIN-note link is unverified.
- VIN Solutions has NO appointment endpoint (403). (MASTER_SRS.md, Section 10.2)

### DEMO-4: Proactive Lead Follow-up

**File evidence:**
- TriggerService with outbound call via VAPI `POST /call`. (CUSTOMER_ONBOARDING_KICKOFF.md, AC-1)
- "Neglected Lead Auto-Call" template: call if no contact after 2 hours. (CUSTOMER_ONBOARDING_KICKOFF.md)
- TextMagic SMS send endpoint wired. (ACCEPTANCE_VERIFICATION_REPORT.md, AC-2)
- #1 PRIORITY stated by owner. (CLARIFICATION_ANSWERS.md, Q9)
- **Gap**: 0 completed trigger executions in production. VAPI phone numbers not assigned per org. (ACCEPTANCE_VERIFICATION_REPORT.md, AC-5; CUSTOMER_ONBOARDING_KICKOFF.md)

### DEMO-5: Reactive After-Hours Coverage

**File evidence:**
- SMS: after-hours AI responds via DealerBrain (Claude API). Business hours routes to staff. (MASTER_SRS.md, Section 6.4)
- Conversation state tracking: AI_ACTIVE / HUMAN_ACTIVE / DORMANT. (MASTER_SRS.md, Section 6.4)
- Business hours configurable per org. (CUSTOMER_ONBOARDING_KICKOFF.md)
- **Gap**: SMS collision avoidance and business hours routing listed as "Needs Work" in MASTER_SRS.md. Shared phone number across 3 orgs. (ACCEPTANCE_VERIFICATION_REPORT.md, operational item 1)

### DEMO-6: Widgets (All 3 Modes)

**File evidence:**
- Unified widget: 50.13 KB bundle, 19 configs, 6 channels. (ACCEPTANCE_VERIFICATION_REPORT.md, AC-6)
- Embed code: `<script src="...nexxus-widget.js" data-widget-code="...">`. (CUSTOMER_ONBOARDING_KICKOFF.md)
- Hosted pages: 5 deployed slugs, all HTTP 200. (ACCEPTANCE_VERIFICATION_REPORT.md, AC-7)
- **Gap**: Customer domains not whitelisted yet. Voice agent IDs not wired in widget config. Serra Honda video disabled (no Tavus persona assigned). (CUSTOMER_ONBOARDING_KICKOFF.md, Section 6)
- **Known P0 bug**: Hosted pages route mismatch -- client fetches `/api/hosted-pages/public/${slug}`, server serves `/api/pages/:slug`. (session-knowledge.md, Section 5)

### DEMO-7: Automa Chat

**File evidence:**
- DealerBrain with 24 tools, SSE streaming, Claude API. (REVERSE_SRS_old.md, lines 299-399)
- Goal awareness injected into AI context. (CUSTOMER_ONBOARDING_KICKOFF.md, AC-2)
- Follow-up prompt suggestions for contextual conversation flow. (CUSTOMER_ONBOARDING_KICKOFF.md)
- **Status per CUSTOMER_ONBOARDING_KICKOFF.md**: Ready to demo for Serra orgs.

---

## WATCH AREA FINDINGS

### WATCH-1: Agent Functionality / Defaults

- Default seed agents: Automa (system, undeletable), Sales Coach, Message Crafter, VAPI voice agent. (server-audit.md, line 160)
- Communications Agent: static, Super Admin configured. 2 agents out of box. (===DevDesign Notes===.md)
- Skills architecture: users create agents and add skills from catalog. Skills = context + instructions overlay. (session-knowledge.md, Section 0b)
- Agent page IS the chat agents feature. `type` = channel integration. (session-knowledge.md, Section 6)
- 12 active agents in production: 5 voice, 2 chat, 4 task. 0 video (operational gap). (ACCEPTANCE_VERIFICATION_REPORT.md, AC-9)
- Migration 033 creates 5 Tavus video agents but may not be applied to production. (ACCEPTANCE_VERIFICATION_REPORT.md, operational item 2)
- From inside an agent: send SMS/email, attach artifact, link to customer-facing version, phone number, text chat link. (===DevDesign Notes===.md)
- **Missing from files**: Complete skills catalog definition. What skills exist and what they do is not documented in any single file.

### WATCH-2: Billing

- Economics documented: Voice $0.25/min, Video $0.32/min, SMS $0.05/msg. (MASTER_SRS.md, Section 12)
- CreditService wired to webhooks. credit_policies, credit_allocations, credit_usage tables exist. (database-audit.md, tables 17-19)
- service_quotas table with monthly limits and 80% alert threshold. (database-audit.md, table 62)
- Billing page commented out as PHASE-FUTURE in frontend. (client-audit.md, line 94)
- Credits page route commented out. (client-audit.md, line 158)
- **Status**: Backend wiring complete, frontend deferred. No customer-facing billing UI exists.
- **Missing from files**: Subscription pricing model (how much per month/seat). Only per-usage rates documented.

### WATCH-3: Unified Inbox Handoff

- InboxPanel merges SMS + widget chat + email in Work Center -> Inbox tab. (client-audit.md)
- External agent conversations can be continued internally by staff. (session-knowledge.md, Section 0)
- inbox_conversations and inbox_messages tables exist. (database-audit.md, tables 48-49)
- InboxService exists. (REVERSE_SRS_old.md, line 309)
- **Missing from files**: Explicit description of handoff mechanics. How does an external widget conversation transition to an internal inbox thread? What triggers the handoff? Is it automatic or manual? No file explicitly documents this workflow end-to-end.

### WATCH-4: Super Admin Functionality

- Super Admin has platform-wide access. All 14 admin endpoints are Super Admin only. (server-audit.md, lines 124-142)
- Super Admin visible features: Users, Organizations, Partner Links, Tools, Hunches, Automa (in Settings). (client-audit.md, line 91)
- Data Management tile: Super Admin ONLY. (DESIGNER_UPDATE_SPEC.md, Section 1)
- AI Configuration: Super Admin has full access including emergency kill switch and skills tab. (DESIGNER_UPDATE_SPEC.md)
- Super Admin provisions tools to orgs. (ARCHITECTURE_GUIDE_RBAC_ADDITION.md)
- Total metrics visible: 5 system-wide health, cost, usage metrics minimum. (MASTER_SRS.md, Section 8.4)
- **Gap per session-knowledge.md**: "Super Admin functionality is undertested. Owner has focused on customer-facing features. Needs thorough extraction."
- **Missing from files**: No document comprehensively lists all Super Admin capabilities vs what org_admin and partner_admin can see/do. The information is scattered across multiple files.

### WATCH-5: Context Router Functionality

- SourceSelector: VIN API primary, local DB fallback. (MASTER_SRS.md, Section 7.2)
- Source tags (VIN, VAPI, TAVUS, LOCAL) internal only, not UI. (MASTER_SRS.md, Section 7.2)
- Cache: 5 min VIN, 1 hour VAPI/Tavus, no cache local. (MASTER_SRS.md, Section 7.2)
- Fallback: logged, not silent. (MASTER_SRS.md, Section 7.2)
- excel_upload exclusion across 32+ queries, 11 files. (MASTER_SRS.md, Section 7.2)
- Version-aware VIN queries: v1 for reference, v3 for leads. (MASTER_SRS.md, Section 7.2)
- Service files: ContextRouterService.ts, SourceSelector.ts, CacheManager.ts. (REVERSE_SRS_old.md, line 322)
- **Was inverted** (local primary, VIN fallback) -- corrected. (DEVELOPMENT_TEAM_BRIEFING.md, Section 6)
- Owner wants Context Router to have 3 sections in UI: Memory stores, Sync Data, Upload Data Store + Web/3rd party. (===DevDesign Notes===.md)
- **Missing from files**: How Context Router decides between sources for non-lead data (e.g., VAPI call logs, Tavus sessions). The documented logic covers leads but not other data types.

---

## CONFLICTS DETECTED

### CONFLICT-1: Table Count

- CLAUDE.md (preflight-input) states "36 tables". (CLAUDE.md, line 204)
- database-audit.md states "53 unique tables (CREATE TABLE)" and "63 distinct tables including ALTER TABLE". (database-audit.md, line 131)
- REVERSE_SRS_old.md states "53 tables". (REVERSE_SRS_old.md, line 46)
- health-audit.md states "33 migrations". (health-audit.md, line 25)
- **Resolution**: 53 is the correct CREATE TABLE count per forensic audit. CLAUDE.md is outdated.

### CONFLICT-2: E2E Test Count

- CLAUDE.md states "376/379 passing" and elsewhere "500+ tests". (CLAUDE.md, lines 171, 205)
- health-audit.md states "747 E2E tests across 46 files". (health-audit.md, line 23)
- MASTER_SRS.md states "~1,699 E2E tests across 50 Playwright spec files". (MASTER_SRS.md, line 896)
- REVERSE_SRS_old.md states "747 E2E tests". (REVERSE_SRS_old.md, line 52)
- **Resolution**: 747 and 1,699 are both cited in governing documents. Possible that 1,699 includes individual assertions while 747 counts test blocks. Cannot resolve from files alone.

### CONFLICT-3: API Endpoint Count

- server-audit.md states "~185 endpoints". (server-audit.md, line 34)
- UNIFIED_HANDOFF_PROMPT.md states "~237 endpoints across 34 route files". (UNIFIED_HANDOFF_PROMPT.md)
- REVERSE_SRS_old.md states "~237 endpoints". (REVERSE_SRS_old.md, line 45)
- health-audit.md states "237 endpoints". (health-audit.md, line 24)
- **Likely resolution**: 185 vs 237 may be different counting methods (unique routes vs total method+path combinations). Multiple files converge on 237.

### CONFLICT-4: Hub/Work Center Tabs

- DESIGNER_UPDATE_SPEC.md states "Hub has exactly 3 tabs: Calendar, Leads, Inbox." (DESIGNER_UPDATE_SPEC.md, line 11-13)
- UI_DEVELOPER_HANDOFF.md lists 5 sub-routes: messages, calendar, tasks, hunches, approvals. (UI_DEVELOPER_HANDOFF.md, lines 120-125)
- client-audit.md describes 5 tabs: Calendar, Tasks, Approvals, Communication, Open Leads. (client-audit.md, line 90)
- **Resolution per DESIGNER_UPDATE_SPEC.md**: 3 tabs is the CORRECT, owner-confirmed final answer. Older documents showing 4-5 tabs are "WRONG and contaminated."

### CONFLICT-5: SRS Chain vs Master SRS

- SRS v3.0, Addendum v3.1, Addendum v3.2 are all in the input files.
- MASTER_SRS.md v2.0 (2026-02-18) explicitly states it "supersedes all prior SRS versions, addendums, and archived specifications." (MASTER_SRS.md, lines 1019-1024)
- **Resolution**: MASTER_SRS.md is authoritative. The SRS chain files are historical input.

### CONFLICT-6: Webhook Status

- CLARIFICATION_ANSWERS.md, Q2 states "Webhooks ARE live, no polling needed."
- DATA_ACCURACY_REPORT.md demonstrates webhooks are NOT working for real-time ingestion (0 real-time records created since Feb 9). (DATA_ACCURACY_REPORT.md, line 75)
- **Resolution**: Webhooks exist and are registered, but production ingestion is broken due to missing `call.started` events and PM2 instability.

---

## MISSING INFORMATION (Not Found in Any File)

### M-1: Subscription Pricing
No file states monthly subscription pricing. Only per-usage AI economics documented.

### M-2: Skills Catalog Definition
No file provides a complete list of available skills, what each skill does, or how skills map to agent capabilities. The concept is described but the catalog is not documented.

### M-3: Unified Inbox Handoff Mechanics
No file describes the end-to-end workflow for how an external widget/VAPI conversation transitions to an internal staff inbox thread.

### M-4: Super Admin Comprehensive Capability List
Super Admin capabilities are scattered across 10+ files. No single document consolidates what Super Admin can see and do vs other roles.

### M-5: Partner Credit Pool Mechanics
The `partners` table has a `credit_pool` column (ARCHITECTURE_GUIDE_RBAC_ADDITION.md), but no file explains how partner-level credit pooling works, how it relates to org-level credit policies, or how it's allocated.

### M-6: Orchestration Agent Decision
CLARIFICATION_ANSWERS.md, Q10 states "Orchestration agent -- not a definite need." This is unresolved. The ARCHITECTURE_VISUAL_MAP.md describes an Orchestrator component in the coordination layer, but the owner deferred the decision.

### M-7: Inventory Data Strategy
VIN Solutions inventory endpoints return 403. No file specifies a fallback strategy for inventory data or whether inventory features should be removed from the UI entirely.

### M-8: Org Creation Wizard Details
DESIGNER_UPDATE_SPEC.md references Section 15 (Org Creation Wizard) but the file was only read to line 150. The wizard is mentioned but its complete specification was not extracted.

---

## CROSS-WAVE NOTES (For Waves 2-4)

### For Wave 2 (SRS)

- MASTER_SRS.md Section 7.3 (webhook-to-lead data flow) is technically detailed and should be carried forward verbatim.
- Context Router architecture (Section 7.2) needs expansion for non-lead data types.
- RLS variable name mismatch (database-audit.md, Section 4; DEVELOPMENT_TEAM_BRIEFING.md, Section 4) is a critical below-the-line detail.
- SET LOCAL without transaction issue (DEVELOPMENT_TEAM_BRIEFING.md, Section 5) is a security architecture concern.
- SMS conversation state machine (AI_ACTIVE / HUMAN_ACTIVE / DORMANT) needs full state transition documentation.
- Trigger deduplication: "two mechanisms exist in code" per session-knowledge.md but not documented in any specification file.

### For Wave 3 (SPEC)

- 53 database tables fully inventoried in database-audit.md -- carry forward.
- 237 API endpoints catalogued in server-audit.md -- carry forward.
- 40+ services listed in REVERSE_SRS_old.md -- carry forward.
- 8 scheduled jobs with intervals documented in REVERSE_SRS_old.md Section 3.2.5.
- Frontend: 174 TS/TSX files, 21 pages, 26 hooks, 4 context providers per client-audit.md.

### For Wave 4 (PLAN)

- DATA_ACCURACY_REPORT.md documents broken webhook ingestion -- P0 fix.
- 3 confirmed real P0 bugs: hosted pages route mismatch, insights crash (4 null guards), appointment notifications. (session-knowledge.md, Section 5)
- Trigger system: 0/84 executions completed -- needs live verification before customer demo.
- VAPI phone numbers not assigned per org -- operational prerequisite for demo items 4 and 5.
- Customer domains not whitelisted -- prerequisite for demo item 6.
- Owner timeline: ~1 week (was "by morning"). (session-knowledge.md, Section 8)

---

## SOURCE FILE LOG

| # | File | Path | Lines Read | PRD Relevance |
|---|------|------|-----------|---------------|
| 1 | session-knowledge.md | workbench root | Full | HIGH -- owner mental model, payment-critical items, watch areas |
| 2 | file-inventory.md | workbench root | Full | MEDIUM -- file categorization |
| 3 | app_identity.md | preflight-input/ | Full | HIGH -- platform identity, RBAC, integrations |
| 4 | -- Acceptance Criteria.md | preflight-input/ | Full | HIGH -- 13 demo AC items |
| 5 | opinions_facts.md.md | preflight-input/other_notes/ | Full | MEDIUM -- owner rules, governance state |
| 6 | Standards.md | preflight-input/other_notes/ | Full | HIGH -- file type definitions |
| 7 | Current_State.md.md | preflight-input/other_notes/ | Full | MEDIUM -- governance layer conflicts |
| 8 | CLARIFICATION_ANSWERS.md | preflight-input/ | Full | HIGH -- 20 owner decisions |
| 9 | ===DevDesign Notes===.md | preflight-input/ | Full | HIGH -- UI redesign, agent architecture |
| 10 | MASTER_SRS.md | preflight-input/ | Full (1035 lines) | CRITICAL -- governing document, 257 requirements |
| 11 | CONSTITUTION.md | preflight-input/ | Full | HIGH -- principles, truth hierarchy |
| 12 | IMPLEMENTATION_PLAN.md | preflight-input/ | Full | HIGH -- 8 phases, 19 ACs |
| 13 | DO_NOT_TOUCH.md | preflight-input/ | Full | MEDIUM -- backend freeze inventory |
| 14 | UNIFIED_HANDOFF_PROMPT.md | preflight-input/ | Full | HIGH -- endpoint catalog, operational lessons |
| 15 | CARRY_FORWARD_MANIFEST.md | preflight-input/ | Full | MEDIUM -- 32 preserve files |
| 16 | --Insights Layout.md | preflight-input/ | Full | HIGH -- insights wireframes |
| 17 | --Org admin Metrics.md | preflight-input/ | Full | HIGH -- org admin tile formulas |
| 18 | --Staff Metrics.md | preflight-input/ | Full | HIGH -- staff tile formulas |
| 19 | --Reports.md | preflight-input/ | Full | HIGH -- 6 priority reports |
| 20 | --Tiles - Available data..md | preflight-input/ | Full | HIGH -- 80+ computable metrics |
| 21 | --Hunches.md | preflight-input/ | Full | HIGH -- hunch agent prompt |
| 22 | Forensics.md.md | preflight-input/other_notes/ | Full | MEDIUM -- audit findings |
| 23 | known_issues.md.md | preflight-input/other_notes/ | Full | MEDIUM -- P0 bug status |
| 24 | CLAUDE.md | preflight-input/ | Full | MEDIUM -- project config (outdated metrics) |
| 25 | ARCHITECTURE_GUIDE.md | preflight-input/ | Partial (persisted, 69.5KB) | MEDIUM -- 3-pane layout, navigation, components |
| 26 | ARCHITECTURE_VISUAL_MAP.md | preflight-input/ | 800 lines | LOW -- aspirational 7-layer architecture (not current reality) |
| 27 | VIN_SOLUTIONS_INTEGRATION.md | preflight-input/ | Full | MEDIUM -- OAuth implementation details |
| 28 | ARCHITECTURE_GUIDE_RBAC_ADDITION.md | preflight-input/ | Full (79 lines) | HIGH -- partner model, tool provisioning |
| 29 | UI_INTERACTIVE_ELEMENTS_MAP.md | preflight-input/ | Full | MEDIUM -- handler-to-element mapping |
| 30 | DATA_SOURCE_INVENTORY.md | preflight-input/ | Partial (persisted, 50.3KB) | HIGH -- complete API field inventory |
| 31 | REVERSE_SRS_old.md | preflight-input/ | 400 lines | HIGH -- as-built inventory, service catalog |
| 32 | database-audit.md | preflight-input/ | 200 lines | HIGH -- 53 tables, RLS policies, critical findings |
| 33 | server-audit.md | preflight-input/ | 200 lines | HIGH -- 237 endpoints, auth architecture |
| 34 | client-audit.md | preflight-input/ | 200 lines | HIGH -- 21 pages, routing, components |
| 35 | health-audit.md | preflight-input/ | 200 lines | HIGH -- 747 E2E tests, git history |
| 36 | DATA_ACCURACY_REPORT.md | preflight-input/ | 200 lines | CRITICAL -- broken webhook ingestion |
| 37 | ACCEPTANCE_VERIFICATION_REPORT.md | preflight-input/ | Full (137 lines) | CRITICAL -- 13/13 AC pass status |
| 38 | Agent Instructions.md | preflight-input/ | Full | LOW -- agent team protocol (process, not product) |
| 39 | CUSTOMER_ONBOARDING_KICKOFF.md | preflight-input/ | Full | HIGH -- per-org readiness, operational gaps |
| 40 | DEVELOPMENT_TEAM_BRIEFING.md | preflight-input/ | 150 lines | HIGH -- hard-won lessons, what works/doesn't |
| 41 | DESIGNER_UPDATE_SPEC.md | preflight-input/ | 150 lines | HIGH -- settings redesign, RBAC visibility |
| 42 | DESIGN_FLAGS.md | preflight-input/ | Full (43 lines) | LOW -- empty (no open flags) |
| 43 | UI_DEVELOPER_HANDOFF.md | preflight-input/ | 150 lines | MEDIUM -- navigation, routes, user flows |
| 44 | THEME_CONTRACT.md | preflight-input/ | 100 lines | LOW -- design token system |
| 45 | NEXXUS_V2_BOOTSTRAP_PROMPT.md | preflight-input/ | 100 lines | MEDIUM -- original rebuild rationale |
| 46 | Hunch Instructions.md | preflight-input/ | 100 lines | HIGH -- hunch agent methodology |
| 47 | INIT_PROJECT_ANSWERS.txt | preflight-input/ | 100 lines | MEDIUM -- init interview answers |
| 48 | docs-audit.md | preflight-input/ | 100 lines | MEDIUM -- document inventory, consistency |
| 49 | Nexxus_SRS_Addendum_v3.1 | preflight-input/ | 100 lines | LOW -- superseded by MASTER_SRS.md |
| 50 | Nexxus_SRS_Addendum_v3.2 | preflight-input/ | 100 lines | LOW -- superseded by MASTER_SRS.md |
| -- | SYSTEM_REQUIREMENTS_SPECIFICATION_v3.0.md | preflight-input/ | 100 lines | LOW -- superseded by MASTER_SRS.md |
| SKIP | replit_reference.textClipping | preflight-input/ | N/A | Binary artifact |
| SKIP | Chat-Checklist.pdf | preflight-input/ | N/A | Blank template |
| SKIP | --Insights Layout copy.md | preflight-input/ | N/A | Duplicate of --Insights Layout.md |

---

*End of Wave 1 REVIEWER extraction. This file contains only what the input files explicitly state. No inferences have been added.*
