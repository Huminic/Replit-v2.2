# Wave 2 — ANALYST Output: System Behavior -> SRS
**Date:** 2026-03-03
**Agent:** Wave 2 ANALYST
**Input:** 53 files from `/home/ubuntu/Claude-store/Nexxus_workbench/preflight-input/`
**Output Target:** SRS.md (System Requirements Specification)

---

## FILES READ (Complete List)

### Tier 1 (Governing Documents)
1. CLAUDE.md (project-level)
2. MASTER_SRS.md
3. CONSTITUTION.md
4. IMPLEMENTATION_PLAN.md (partial - first ~300 lines)

### Tier 2 (Technical Specifications)
5. SYSTEM_REQUIREMENTS_SPECIFICATION_v3.0.md (full, ~1585 lines)
6. Nexxus_SRS_Addendum_v3.1_MVP_Critical.md (first ~300 lines)
7. Nexxus_SRS_Addendum_v3.2_Widget_SMS_Notifications.md (full)
8. ARCHITECTURE_GUIDE.md (partial)
9. ARCHITECTURE_GUIDE_RBAC_ADDITION.md (full, 79 lines)
10. ARCHITECTURE_VISUAL_MAP.md (full, ~1300 lines)
11. VIN_SOLUTIONS_INTEGRATION.md (full)
12. THEME_CONTRACT.md (full, 1324 lines)
13. UI_DEVELOPER_HANDOFF.md (full, 758 lines)
14. UI_INTERACTIVE_ELEMENTS_MAP.md (full, 207 lines)
15. DESIGNER_UPDATE_SPEC.md (full, ~1500 lines)
16. INSIGHT_CARDS_SPECIFICATION.md (partial)

### Tier 3 (Audit & Assessment)
17. database-audit.md (full)
18. server-audit.md (full)
19. client-audit.md (full, ~1214 lines)
20. docs-audit.md (full, 666 lines)
21. health-audit.md (partial)
22. ACCEPTANCE_VERIFICATION_REPORT.md (full)
23. DATA_ACCURACY_REPORT.md (full)

### Tier 4 (Context & Reference)
24. REVERSE_SRS_old.md (full)
25. DO_NOT_TOUCH.md (full)
26. UNIFIED_HANDOFF_PROMPT.md (full)
27. DATA_SOURCE_INVENTORY.md (full)
28. CUSTOMER_ONBOARDING_KICKOFF.md (full, 286 lines)
29. CARRY_FORWARD_MANIFEST.md (partial)
30. NEXXUS_V2_BOOTSTRAP_PROMPT.md (full, 626 lines)
31. INIT_PROJECT_ANSWERS.txt (full, 147 lines)
32. DESIGN_FLAGS.md (full, 43 lines)
33. app_identity.md (full)
34. DEVELOPMENT_TEAM_BRIEFING.md (full)
35. CLARIFICATION_ANSWERS.md (full)

### Tier 5 (Feature Specifications)
36. -- Acceptance Criteria.md (partial, first ~300 lines)
37. ---Insights Layout.md (full, 749 lines)
38. ---Org admin Metrics - Main - org admin.md (full, 77 lines)
39. ---Staff Metrics.md (full, 109 lines)
40. ---Reports.md (full, 361 lines)
41. ---Tiles - Available data..md (full, 122 lines)
42. ===DevDesign Notes===.md (full)
43. Agent Instructions.md (full, 359 lines)
44. Hunch Instructions.md (full)
45. ---Hunches.md (full)

### Tier 6 (Session Knowledge & Notes)
46. session-knowledge.md (full, 240 lines)
47. other_notes/Current_State.md.md (full, 139 lines)
48. other_notes/Forensics.md.md (full, 79 lines)
49. other_notes/Standards.md (full, 261 lines)
50. other_notes/known_issues.md.md (full, 229 lines)
51. other_notes/opinions_facts.md.md (full, 68 lines)

### SKIPPED (per instructions)
- replit_reference.textClipping
- Chat-Checklist.pdf
- "Insights Layout copy.md"

---

## CATEGORY 1: DATA FLOW NARRATIVES

### 1.1 External-to-Internal Data Flow (Inbound)

**VAPI Call Completion -> Lead Pipeline:**
1. VAPI sends webhook to `POST /api/webhooks/vapi` with call event data
2. `resolveOrganizationId()` extracts org from `metadata.organizationId` or `assistantId` lookup in the database
3. Call data stored in `vapi_call_logs` table with org isolation
4. Lead extraction: customer info parsed from call transcript/metadata
5. Lead inserted into `sync_queue` table with status `pending`
6. Sync queue worker (runs every 1 minute or 4 hours depending on config) picks up pending items
7. VIN Solutions 2-step lead creation: (a) POST contact, (b) POST lead with contact href reference
8. Credit usage tracked: duration * cost_per_minute -> `credit_usage` table

**Sources:** CLAUDE.md ~L216-220, REVERSE_SRS_old.md, server-audit.md, ARCHITECTURE_VISUAL_MAP.md ~L1033-1057, VIN_SOLUTIONS_INTEGRATION.md

**Tavus Session Completion -> Data Pipeline:**
1. Tavus sends callback to `POST /api/webhooks/tavus`
2. HMAC signature verification
3. Session data stored with duration, engagement metrics
4. Cost tracking: duration * $0.20/min (cost) and $0.32/min (customer charge)
5. Credit deduction from organization balance

**Sources:** CLAUDE.md ~L218, ARCHITECTURE_VISUAL_MAP.md ~L1059-1156

**VIN Solutions -> Nexxus (Inbound Polling):**
1. Scheduled job polls VIN Solutions every 60 minutes for new leads
2. OAuth 2.0 Client Credentials token obtained (cached, 60-min expiry)
3. GET leads with `lastModified` filter
4. New leads stored in internal database with VIN external IDs
5. Context Router `SourceSelector` tags data source as "VIN"

**Sources:** VIN_SOLUTIONS_INTEGRATION.md, MASTER_SRS.md, server-audit.md

### 1.2 Internal-to-External Data Flow (Outbound)

**Lead Insertion to VIN Solutions:**
1. Lead captured by VAPI/Tavus/Widget
2. Contact created: `POST /contacts` -> returns `ContactId`
3. Contact href constructed: `/contacts/id/{ContactId}?dealerid={dealerId}`
4. Lead sources queried: `GET /leadSources?dealerId=X` -> returns valid source hrefs
5. Lead created: `POST /leads` with `leadSource` (href), `leadType` (href), `contact` (href)
6. KNOWN BUG: Code sends string "Phone" for leadSource instead of URL reference format like `/leadSources/id/36`. This caused 12/12 sync job failures in production.

**Sources:** CLAUDE.md ~L72-84, VIN_SOLUTIONS_INTEGRATION.md, CUSTOMER_ONBOARDING_KICKOFF.md ~L170-200

**Appointment -> VIN Solutions:**
1. Appointment created in calendar (user or agent action)
2. Appointment stored in `appointments` table
3. Lead note created in VIN Solutions with appointment details
4. MISSING: Appointment status change notifications (P0 confirmed gap)

**Sources:** session-knowledge.md ~L69, known_issues.md.md ~L11

### 1.3 Internal Data Flows

**Context Router Data Aggregation:**
1. `SourceSelector`: VIN Solutions primary, local database fallback
2. `CacheManager`: 5-minute TTL for VIN data, 1-hour TTL for VAPI/Tavus data
3. Excel uploads excluded from Context Router pipeline (processed separately)
4. ~20% of data consumers currently use Context Router
5. Data labels: every datum tagged with `organization_id` + source identifier

**Sources:** DATA_SOURCE_INVENTORY.md, REVERSE_SRS_old.md, session-knowledge.md ~L24-31

**DealerBrain AI Processing:**
1. User sends message via chat interface
2. SSE stream initiated: `POST /api/conversations/*/stream`
3. Claude API called with tool definitions and conversation history
4. 6 SSE event types emitted: `thinking`, `tool_start`, `tool_end`, `token`, `done`, `error`
5. Tool invocations may query VIN Solutions, internal DB, or Context Router
6. Response streamed progressively to client

**Sources:** client-audit.md ~L587-618, UI_DEVELOPER_HANDOFF.md ~L859-879

### 1.4 Metrics Data Sources (Complete Picture)

Data flows into metrics/insights from 4 sources:
1. **VIN Solutions API** -- CRM leads, contacts, appointments, inventory (via Context Router or direct query)
2. **Internal Database** -- VAPI call logs, Tavus sessions, credit usage, agent activity, task/approval status
3. **User Uploads** -- CSV/Excel files uploaded via Data Management settings (backend processed, not through Context Router)
4. **External Services** -- Real-time webhook events from VAPI, Tavus, TextMagic

**Sources:** session-knowledge.md ~L24-31, ---Insights Layout.md, ---Tiles - Available data..md

---

## CATEGORY 2: TRIGGER & EVENT MECHANICS

### 2.1 Trigger System Architecture

**7 Event Types:**
1. `new_lead` -- New lead arrives in system
2. `hot_lead` -- Lead score exceeds threshold
3. `idle_lead` -- Lead idle for configured duration
4. `missed_call` -- Inbound call not answered
5. `appointment_created` -- New appointment scheduled
6. `appointment_reminder` -- Upcoming appointment within window
7. `stale_lead` -- Lead aging past configured days

**5 Action Types:**
1. `outbound_call` -- Trigger VAPI outbound call
2. `outbound_sms` -- Send TextMagic SMS
3. `email_notification` -- Send Resend email
4. `create_task` -- Create internal task
5. `update_lead_status` -- Modify lead status in system

**Sources:** REVERSE_SRS_old.md, server-audit.md, DESIGNER_UPDATE_SPEC.md ~L1080-1104

### 2.2 Trigger Execution Pipeline

1. Trigger configured per-agent (confirmed by owner in DESIGNER_UPDATE_SPEC.md ~L1082)
2. Trigger conditions evaluated: event type match + criteria match (lead score threshold, time window, business hours)
3. Rate limiting enforced: configurable per trigger
4. Business hours check: triggers can be restricted to business hours or after-hours only
5. Deduplication: TWO mechanisms exist in code (contrary to prior finding that claimed "no dedup")
6. Action executed: calls appropriate service (VapiService, TextMagicService, etc.)
7. Execution logged with trigger_id, action taken, result

**Production Status:** 0/84 trigger executions completed in production. The execution path has never fired a real outbound call.

**Sources:** session-knowledge.md ~L209, REVERSE_SRS_old.md, CUSTOMER_ONBOARDING_KICKOFF.md

### 2.3 Scheduled Events (8 Jobs)

All jobs use `setInterval` (not cron). Run continuously while server is alive.

| Job | Interval | Purpose |
|-----|----------|---------|
| VIN Token Refresh | 30 min | Refresh OAuth 2.0 access token |
| Sync Queue Worker | 1 min or 4 hr | Process pending lead sync items |
| Appointment Reminder | 5 min | Check for upcoming appointments, send notifications |
| Email Sync (IMAP) | 5 min | Pull new emails via IMAP |
| VIN Lead Polling | 60 min | Poll VIN Solutions for new/updated leads |
| Trigger Re-evaluation | 5 min | Re-check trigger conditions against current state |
| Dealer Pulse | 4 hr | Compute dealership health metrics |
| Hunch Generation | 6 hr | Run Claude "Detective" agent to generate AI hunches |

**Sources:** server-audit.md, REVERSE_SRS_old.md

### 2.4 Trigger Configuration UI

Per DESIGNER_UPDATE_SPEC.md ~L1080-1104:
- Triggers section appears in Agent Config Pane (per-agent, not global)
- Trigger editor supports Event type or Schedule type
- Schedule supports cron expression or simple interval
- Each trigger has an on/off toggle
- Trigger types: Event, Schedule (with cron)

**Sources:** DESIGNER_UPDATE_SPEC.md ~L1080-1104

---

## CATEGORY 3: WEBHOOK PROCESSING

### 3.1 VAPI Webhook Pipeline

**Endpoint:** `POST /api/webhooks/vapi`

**Event Types Handled:**
- `call.started` -- Update call status, notify UI via WebSocket/SSE
- `call.ended` -- Save transcript, calculate cost, update credits, extract lead
- `call.failed` -- Log error, notify manager
- `transcript.ready` -- Store transcript in long-term memory

**Organization Resolution:**
1. Check `metadata.organizationId` in webhook payload
2. If not present, lookup `assistantId` in database to find registered org
3. Webhooks only process events for assistants registered to specific organizations
4. Reject events with no org match

**Post-Processing:**
- Credit deduction: duration * $0.15/min (VAPI cost), customer charged $0.25/min
- Lead extraction from call data
- Sync queue entry for VIN Solutions insertion
- Activity event logged

**Sources:** CLAUDE.md ~L216-220, ARCHITECTURE_VISUAL_MAP.md ~L1033-1057, SRS v3.0 ~L975-1050

### 3.2 Tavus Webhook Pipeline

**Endpoint:** `POST /api/webhooks/tavus`

**Security:** HMAC signature verification

**Event Types:**
- `session.started` -- Update status, notify UI
- `session.ended` -- Calculate duration, cost, save recording URL
- `recording.ready` -- Store recording link

**Cost Tracking:**
- Tavus cost: $0.20/min
- Customer charge: $0.32/min
- Nexxus margin: 37.5%

**Sources:** CLAUDE.md ~L218, ARCHITECTURE_VISUAL_MAP.md ~L1059-1156

### 3.3 TextMagic SMS Pipeline

**Inbound SMS Flow:**
1. TextMagic webhook receives incoming SMS
2. Phone number matched to organization via per-org DB credentials (NOT .env credentials)
3. Conversation state machine checked: AI_ACTIVE / HUMAN_ACTIVE / DORMANT
4. If AI_ACTIVE: auto-response generated by communications agent
5. If HUMAN_ACTIVE: message routed to Unified Inbox for staff
6. SMS stored in conversation thread

**Outbound SMS Flow:**
1. Trigger or manual action initiates SMS
2. Per-org TextMagic credentials retrieved from database
3. SMS sent via TextMagic API
4. Credit usage tracked: $0.02/msg (cost), $0.05/msg (customer charge), 60% margin

**CRITICAL:** TextMagic uses per-org database credentials, NOT the .env TEXTMAGIC_API_KEY. Prior testing that used .env credentials was testing against the wrong account.

**Sources:** session-knowledge.md ~L209, SRS Addendum v3.2, REVERSE_SRS_old.md

### 3.4 VIN Solutions Webhook (Aspirational)

The ARCHITECTURE_VISUAL_MAP.md ~L941-958 describes a VIN Solutions webhook handler at `POST /api/webhooks/vin` that handles customer.created, customer.updated, appointment.created, appointment.cancelled, inventory.updated events with HMAC + IP whitelist security.

**IMPORTANT:** This is aspirational architecture. The actual VIN Solutions integration is QUERY-ONLY (polling-based), NOT webhook-based. VIN Solutions does not currently push webhooks to Nexxus. The SRS Addendum v3.1 explicitly clarifies: "VIN Solutions integration is QUERY-ONLY (not bidirectional sync)."

**Sources:** ARCHITECTURE_VISUAL_MAP.md ~L941-958, SRS Addendum v3.1

---

## CATEGORY 4: AUTHENTICATION & AUTHORIZATION

### 4.1 JWT Architecture

**Token Types:**
| Token | Duration | Storage | Purpose |
|-------|----------|---------|---------|
| Access Token | 24 hours | localStorage (`nexxus_access_token`) | API authentication |
| Refresh Token | 7 days | localStorage (`nexxus_refresh_token`) | Access token renewal |
| Appointment Confirmation | 48 hours | URL parameter | Appointment email links |

**Token Refresh Flow:**
1. Client-side interval checks every 60 seconds
2. If token expiry < 5 minutes away, calls `POST /api/auth/refresh`
3. Server validates refresh token, issues new access + refresh tokens
4. On failure: automatic logout, redirect to `/login`

**JWT Payload:**
```typescript
{
  user_id: UUID,
  organization_id: UUID,  // CRITICAL for data isolation
  role_id: UUID,
  permissions: string[],
  exp: number,
  iat: number
}
```

**CRITICAL NOTE:** Backend uses JWT auth (access/refresh tokens), NOT express-session. Any document referencing express-session is wrong.

**Sources:** SRS v3.0 ~L1174-1185, client-audit.md ~L405-430, ~L745-820, INIT_PROJECT_ANSWERS.txt ~L61

### 4.2 RBAC (4-Tier Role-Based Access Control)

| Level | Role | Access Scope |
|-------|------|--------------|
| 1 | Super Admin | System-wide. All settings. All orgs. User/org management. |
| 2 | Partner Admin | Multi-org access. Org switching. Settings except system-level. |
| 3 | Org Admin | Single org. Knowledge, Email, Widget, Pages, Triggers settings. |
| 4 | Org Staff | Basic access. Dashboard, Agents, Drive, Insights, Work Center. |

**User Creation Matrix:**
| Creator Role | Can Create | Scope |
|-------------|-----------|-------|
| Super Admin | All roles | All organizations |
| Partner Admin | Org Admin, Staff | Partner's organizations |
| Org Admin | Staff | Own organization only |
| Staff | None | N/A |

**Partner Admin Model:**
- `partners` table with company info
- `partner_org_assignments` table: many-to-many between partners and organizations
- `user_org_assignments` table: user access to organizations
- RLS policy: partner admin can access only assigned organizations
- Tool provisioning: top-down (Super Admin -> Partner Admin -> Org Admin)

**Client-Side Role Enforcement:**
- `currentUser.role` from AppContext (mapped from numeric level to string)
- Route-level access checks: NO route-level RBAC guard exists; restrictions applied at component/tab level
- `canAccessSystem(role)` helper function
- `ROLE_VISIBILITY` maps in dashboard components

**CONFLICT:** SRS v3.0 ~L1193 uses `app.current_organization_id` as RLS variable name. REVERSE_SRS_old and database-audit report a mismatch: some policies use `app.current_organization_id`, others use `app.current_org_id`. This is a confirmed security-relevant inconsistency.

**Sources:** SRS v3.0 ~L920-945, ~L1186-1197, ARCHITECTURE_GUIDE_RBAC_ADDITION.md, client-audit.md ~L820-837, DESIGNER_UPDATE_SPEC.md ~L80-98

### 4.3 Organization Switching (Partner Admin)

1. `accessibleOrganizations` populated from auth response
2. Org switcher in TopBar and profile dropdown
3. `switchOrganization(orgId)` calls `POST /api/auth/switch-org`
4. Server returns new tokens scoped to selected org
5. `queryClient.invalidateQueries()` clears ALL cached data
6. Navigation to `/` to reset page state
7. 3-second confirmation overlay displayed

**Sources:** client-audit.md ~L810-820

### 4.4 OAuth 2.0 (VIN Solutions)

**Grant Type:** Client Credentials
**Token Expiry:** 60 minutes
**Refresh:** Scheduled job every 30 minutes (proactive)
**Storage:** AES-256-GCM encrypted in database
- PBKDF2 key derivation: 100,000 iterations, SHA-256
- Per-credential random salt and IV

**Headers:**
- Gateway endpoints (`/gateway/v1/`): `Content-Type: application/json`
- Newer endpoints: `Content-Type: application/vnd.coxauto.V3+json` (NOTE: lowercase "v3", not uppercase "V3")

**Sources:** VIN_SOLUTIONS_INTEGRATION.md, CLAUDE.md ~L72-84, REVERSE_SRS_old.md

---

## CATEGORY 5: STATE MACHINES & TRANSITIONS

### 5.1 SMS Conversation State Machine

**States:**
- `AI_ACTIVE` -- AI agent is responding to SMS messages
- `HUMAN_ACTIVE` -- Human staff has taken over the conversation
- `DORMANT` -- Conversation inactive for configured duration

**Transitions:**
- `AI_ACTIVE` -> `HUMAN_ACTIVE`: Staff claims conversation in Unified Inbox
- `HUMAN_ACTIVE` -> `AI_ACTIVE`: Staff releases conversation or timeout
- `AI_ACTIVE` -> `DORMANT`: No activity for configured timeout
- `HUMAN_ACTIVE` -> `DORMANT`: No activity for configured timeout
- `DORMANT` -> `AI_ACTIVE`: New inbound message from customer

**Implementation Status:** Schema defined in migration 032. Logic NOT fully implemented -- state transitions exist in schema but the full state machine controller is incomplete.

**Sources:** SRS Addendum v3.2, REVERSE_SRS_old.md

### 5.2 Lead Status State Machine

**States:** `new` -> `contacted` -> `qualified` -> `appointment_set` -> `closed`

**Transitions:**
- System-initiated: new lead from VAPI/Tavus/Widget -> `new`
- Agent-initiated: communications agent makes outbound call/SMS -> `contacted`
- Manual: staff marks as qualified in UI -> `qualified`
- System or manual: appointment created -> `appointment_set`
- Manual: deal closed or lost -> `closed`

**Sources:** UI_DEVELOPER_HANDOFF.md ~L489-510, client-audit.md ~L918

### 5.3 Agent Status

**States:** `active`, `inactive`, `draft`

**Sources:** SRS v3.0 ~L1529-1547, client-audit.md ~L888

### 5.4 Approval Workflow State Machine

**States:** `pending` -> `approved` | `rejected` | `timeout`

**Transitions:**
- Created: hunch or external communication generates approval request -> `pending`
- Approved: authorized user approves -> `approved`, target entity updated
- Rejected: authorized user rejects -> `rejected`
- Timeout: `timeout_hours` exceeded without action -> `timeout`

**Schema:** `approval_workflows` (config), `approval_requests` (instances), `approval_actions` (decisions)

**Sources:** SRS v3.0 ~L800-850

### 5.5 Hunch Lifecycle

**States:** Generated -> Pending Review -> Accepted | Dismissed

**Flow:**
1. Hunch Generation job (6hr interval) runs Claude "Detective" agent
2. 7 hunch categories: opportunity, risk, trend, anomaly, recommendation, prediction, insight
3. Hunch stored with confidence score, category, supporting evidence
4. User reviews in Hunches tab (Insights page)
5. Accept -> hunch creates action item (task, follow-up, etc.)
6. Dismiss -> hunch archived with feedback (RLHF loop)

**Sources:** SRS v3.0 ~L700-780, Hunch Instructions.md, ---Hunches.md

---

## CATEGORY 6: INTEGRATION PROTOCOLS

### 6.1 VIN Solutions Integration

**Protocol:** REST API over HTTPS
**Auth:** OAuth 2.0 Client Credentials
**Base URL:** Referenced in VIN docs
**Rate Limits:** Not explicitly documented, but 200 req/hour mentioned in ARCHITECTURE_VISUAL_MAP.md for MCP proxy

**Accessible Endpoints (13 of 30):**
- GET/POST contacts
- GET/POST leads
- GET leadSources
- GET leadTypes
- GET appointments
- GET inventory (limited)
- Others (see VIN_SOLUTIONS_INTEGRATION.md for full list)

**Blocked Endpoints (17):** Return 403 Forbidden. Do NOT build UI for these.

**2-Step Lead Creation:**
1. `POST /contacts` with customer data -> returns `ContactId`
2. Convert to href: `/contacts/id/{ContactId}?dealerid={dealerId}`
3. Query `GET /leadSources?dealerId=X` for valid source hrefs
4. `POST /leads` with `leadSource` (href), `leadType` (href), `contact` (href)

**KNOWN BUG:** `leadSource` field format mismatch. Code sends string name (e.g., "Phone"), API requires URL reference (e.g., `/leadSources/id/36`). This caused 12/12 sync job failures.

**Header Casing Issue:** Some docs say `application/vnd.coxauto.V3+json` (uppercase V), actual API requires lowercase `v3`. See docs-audit.md for details.

**Sources:** CLAUDE.md ~L72-84, VIN_SOLUTIONS_INTEGRATION.md, CUSTOMER_ONBOARDING_KICKOFF.md

### 6.2 VAPI Voice AI Integration

**Protocol:** REST API + Webhooks
**Auth:** Bearer token (master API key)
**Org Isolation:** Assistants tagged with `metadata.organizationId`
**Provisioning:** Template duplication strategy (pre-defined assistants duplicated per org)
**Retention:** 30-day recording retention, auto-reaper cron at 2:00 AM daily

**Sources:** SRS v3.0 ~L975-995, CLAUDE.md ~L223-225

### 6.3 Tavus Video AI Integration

**Protocol:** REST API + Webhooks
**Auth:** `x-api-key` header (master API key)
**Org Isolation:** Personas tagged with org metadata
**Provisioning:** Template duplication for personas
**Stock Replicas:** Reused across orgs (custom replicas quota-limited)
**Retention:** 30-day recording retention

**Sources:** SRS v3.0 ~L997-1010, ARCHITECTURE_VISUAL_MAP.md ~L1059-1156

### 6.4 TextMagic SMS Integration

**Protocol:** REST API
**Auth:** Per-org database credentials (username + API key stored encrypted in DB)
**NOT:** Global .env credentials
**Channels:** SMS inbound + outbound
**Cost:** $0.02/msg (cost), $0.05/msg (customer charge), 60% margin

**Sources:** SRS Addendum v3.2, session-knowledge.md ~L209

### 6.5 Resend Email Integration

**Protocol:** REST API
**Purpose:** Transactional and notification emails
**Routing:** Database hierarchy routing for notification delivery
**Used for:** Appointment reminders, trigger notifications, system alerts, daily digest

**Sources:** CLAUDE.md ~L226, SRS v3.0 ~L853-884

### 6.6 Google Calendar OAuth

**Protocol:** OAuth 2.0 Authorization Code
**Features:** Connect, disconnect, sync, toggle auto-sync
**Status:** Implemented (Phase 17 complete per CLAUDE.md)

**Sources:** CLAUDE.md ~L194, client-audit.md ~L987-988

### 6.7 Claude AI (DealerBrain)

**Model:** claude-sonnet-4-20250514 (per implementation note; SRS v3.0 specifies older `claude-3-5-sonnet-20241022`)
**Protocol:** Streaming API via SSE
**Tool Calling:** Supported -- DealerBrain can invoke VIN queries, internal lookups, etc.
**System Prompt:** Configurable per-org via AI Configuration settings

**Sources:** SRS v3.0 ~L1127, REVERSE_SRS_old.md, client-audit.md ~L859-879

### 6.8 MCP (Model Context Protocol) -- Aspirational

ARCHITECTURE_VISUAL_MAP.md describes an MCP Proxy on Port 3010 with VIN MCP Server (3011), VAPI MCP Server (3012), Tavus MCP Server (3013). Central-MCP exists at `../central-mcp/` (port 4002).

**Current Reality:** MCP tools tab in UI shows "No MCP tools configured" (placeholder). The central-mcp proxy pattern is ready but not all connectors are integrated.

**Sources:** ARCHITECTURE_VISUAL_MAP.md ~L860-968, DESIGNER_UPDATE_SPEC.md ~L187-215, session-knowledge.md (central-mcp reference)

---

## CATEGORY 7: CONTEXT ROUTER BEHAVIOR

### 7.1 Architecture

The Context Router is the intelligent data orchestration layer managing flows between Nexxus, VIN Solutions, VAPI, Tavus, and other external systems.

**Core Components:**
1. **SourceSelector** -- Determines optimal data source. VIN Solutions primary, local database fallback.
2. **CacheManager** -- TTL-based caching. VIN data: 5 min TTL. VAPI/Tavus: 1 hr TTL.
3. **Data Isolation Enforcement Layer** -- organization_id validation on ALL queries, RLS, JWT scoping, audit logging

**Sources:** SRS v3.0 ~L1200-1270, DATA_SOURCE_INVENTORY.md, REVERSE_SRS_old.md

### 7.2 Decision Flow (from ARCHITECTURE_VISUAL_MAP.md ~L1160-1293)

1. **NLP Parsing** -- Claude API extracts action and entities from user intent
2. **Domain Classification** -- Maps to domains: automotive, communication, analytics, system
3. **Entity Validation** -- Checks required entities present, requests missing ones from user
4. **Context Loading** -- Loads from 4 memory tiers (short-term, working, long-term, external)
5. **Agent Selection** -- Maps domain to agent type (auto_dealer, convo_agent, etc.)
6. **Routing Decision** -- Single agent = direct, multi-agent = orchestrate

**IMPORTANT:** This 6-step decision flow is aspirational architecture from the visual map. The actual Context Router implementation is simpler -- it primarily routes data source queries, not multi-agent orchestration. The SourceSelector + CacheManager are the implemented components.

### 7.3 Data Labeling

All data passing through Context Router is tagged:
- `organization_id` -- mandatory, immutable once set
- `source` -- "vin", "vapi", "tavus", "upload", "widget", "manual"
- Source badges displayed in UI: VIN, VAPI, Tavus, SMS, Email, Widget, Manual

**Excel Upload Exclusion:** User uploads (CSV/Excel) are processed separately and do NOT flow through Context Router. They are stored directly and labeled as "upload" source.

**Sources:** DATA_SOURCE_INVENTORY.md, session-knowledge.md ~L24-31

### 7.4 Coverage Gap

~20% of data consumers currently use Context Router. The remaining 80% query data sources directly. This means data source selection is not centralized for most of the application.

**Sources:** REVERSE_SRS_old.md, DATA_SOURCE_INVENTORY.md

---

## CATEGORY 8: BELOW-THE-LINE BEHAVIOR

### 8.1 Encryption

**At Rest:** AES-256-GCM encryption for sensitive credentials (OAuth tokens, API keys)
- PBKDF2 key derivation: 100,000 iterations, SHA-256
- Per-credential random salt and IV
- Stored in `integrations` table `credentials` JSONB field

**In Transit:** TLS 1.3 for all connections (specified in SRS v3.0 ~L1086)

**Sources:** SRS v3.0 ~L1085-1102, VIN_SOLUTIONS_INTEGRATION.md

### 8.2 Row-Level Security (RLS)

**Scale:** 53 tables, ~100 policies, 6 policy patterns
**Enforcement:** PostgreSQL RLS policies + `SecureQueryBuilder` in application layer

**CRITICAL BUG:** Variable name mismatch across policies:
- Some policies use: `current_setting('app.current_organization_id')::uuid`
- Others use: `current_setting('app.current_org_id')::uuid`
- These are DIFFERENT variable names and will cause data isolation failures if the wrong one is set

**Application-side:** `SET LOCAL app.current_organization_id = '<org_id_from_jwt>'` -- but if some policies check `app.current_org_id`, those policies will not filter correctly.

**Sources:** SRS v3.0 ~L1186-1197, database-audit.md, REVERSE_SRS_old.md

### 8.3 Audit Logging

- All data access and modifications logged
- Sensitive operations have dedicated audit trails
- `audit_log` table referenced in ER diagram
- Activity events stored in `activity_events` table with causal chains (aspirational)

**Sources:** SRS v3.0 ~L1091-1102

### 8.4 SecureQueryBuilder

Every database query passes through `SecureQueryBuilder` which:
1. Enforces RLS context by setting `app.current_organization_id` from JWT
2. Requires organization_id -- never optional
3. Parameterizes all queries (no SQL injection)
4. Provides data access with organization isolation

**Sources:** CLAUDE.md ~L236-239

### 8.5 Token Caching (VIN Solutions)

- Access token cached server-side
- `VinOAuthService` handles token lifecycle
- 60-minute token expiry
- 30-minute proactive refresh via scheduled job
- If refresh fails, next API call will attempt fresh token acquisition

**Sources:** CLAUDE.md ~L84, VIN_SOLUTIONS_INTEGRATION.md

### 8.6 Sync Queue

Asynchronous queue for VIN Solutions write operations:
1. Items added to `sync_queue` table with `status: 'pending'`
2. Worker picks up items on 1-minute or 4-hour interval
3. Processes in order: contact creation, then lead creation
4. On failure: status updated to `failed` with error details
5. Retry logic: configurable (exact retry count not documented)

**Sources:** REVERSE_SRS_old.md, server-audit.md

---

## CATEGORY 9: ERROR HANDLING & RECOVERY

### 9.1 API Error Handling

**Client-side `fetchApi()`:**
- Reads `nexxus_access_token` from localStorage
- Attaches `Authorization: Bearer <token>` header
- On 401: configurable behavior (return null or throw)
- Custom `getQueryFn` factory handles 401 responses

**TanStack Query defaults:**
```typescript
{
  staleTime: Infinity,       // Data never auto-stales
  refetchOnWindowFocus: false,
  retry: false,              // No automatic retries
}
```

**Sources:** client-audit.md ~L487-500, ~L780-795

### 9.2 Auth Error Recovery

- Token refresh failure: automatic logout
- On 401 from any API call: configurable (null return vs throw)
- Refresh token expired: force logout, redirect to `/login`

**Sources:** client-audit.md ~L770-776

### 9.3 Webhook Error Handling

- VAPI: `call.failed` event -> log error, notify manager
- Tavus: HMAC verification failure -> reject webhook
- VIN sync: failed sync items remain in `sync_queue` with error status

### 9.4 Known Error Conditions (P0s)

1. **Hosted pages route mismatch:** Client fetches `/api/hosted-pages/public/${slug}`, server serves `/api/pages/:slug`. One-line fix needed.
2. **Insights crash risk:** 4 unsafe `.pct` accesses at lines 854, 1293, 2142, 2143 in insights.tsx. Direct `array[0]` without bounds checking. Null guards needed.
3. **Appointment status notifications:** `updateAppointment()` fires zero events. No SMS/notification sent on status change.

**Sources:** known_issues.md.md ~L8-11, verified-findings.md (referenced in session-knowledge.md ~L197-201)

---

## CATEGORY 10: SECURITY MECHANISMS

### 10.1 Defense-in-Depth Layers

1. **Network:** CDN/DDoS protection (CloudFlare specified but may not be active in current deployment)
2. **Application:** JWT authentication, API rate limiting
3. **Data:** AES-256 at rest, TLS 1.3 in transit
4. **Database:** Row-Level Security (RLS), parameterized queries
5. **Audit:** Comprehensive logging, intrusion detection (aspirational)

**Sources:** SRS v3.0 ~L1164-1173

### 10.2 Input Validation

- Parameterized queries throughout (no SQL injection)
- Input validation on all endpoints
- `SecureQueryBuilder` enforces org isolation

**Sources:** CLAUDE.md ~L29-30

### 10.3 Webhook Security

- **VAPI:** Organization resolution via metadata or assistant lookup (no HMAC mentioned)
- **Tavus:** HMAC signature verification
- **VIN (aspirational):** HMAC + IP whitelist (not implemented -- VIN integration is polling-based)

### 10.4 CORS / Session

- No express-session -- JWT-only
- Tokens in localStorage (not httpOnly cookies -- potential XSS vector)
- `credentials: 'include'` on all fetch requests

**Sources:** client-audit.md ~L780-795

### 10.5 Compliance (Specified but Not Verified)

- GDPR readiness
- CCPA compliance
- HIPAA requirements
- SOC2 (grayed out in UI -- placeholder)

**Sources:** SRS v3.0 ~L1093

---

## CATEGORY 11: NOTIFICATION ROUTING

### 11.1 Notification Channels

| Channel | Service | Status |
|---------|---------|--------|
| Email | Resend API | Implemented |
| SMS | TextMagic API | Implemented (per-org credentials) |
| In-App | WebSocket (Socket.IO) | Implemented (changed from SSE per D-002) |
| Push (Mobile) | Firebase/APNs | Future Phase 2 |

**CONFLICT:** SRS v3.0 ~L859 specifies SSE for real-time notifications. Implementation note D-002 says WebSocket (Socket.IO) was chosen instead. The acceptance criteria on line 966 still reference "SSE connection established on login." Client-side code uses SSE for DealerBrain streaming but WebSocket for notifications.

**Sources:** SRS v3.0 ~L853-970, client-audit.md ~L587-618

### 11.2 Notification Events

- New hunch generated
- Approval request assigned
- Task assigned or due
- Lead status change
- System alerts and errors
- Appointment reminders
- Daily digest (configurable)

### 11.3 Notification Settings (Two Levels)

1. **System-wide:** AI Configuration > Hunches tab (Super Admin controls)
   - Enable/disable hunches globally
   - Daily digest on/off
   - Confidence threshold defaults

2. **Per-user:** Notifications settings page
   - Global toggles: Email ON/OFF, SMS ON/OFF, Push ON/OFF
   - Quiet hours: Start/End time
   - Per-event channel preferences

**Sources:** DESIGNER_UPDATE_SPEC.md ~L616-645, ~L565-585, ~L1471-1500

### 11.4 Database Hierarchy Routing

Notifications use database hierarchy to determine recipients:
- Organization-level events -> all admins of that org
- User-level events -> specific user
- System-level events -> Super Admins
- Partner-level events -> Partner Admin for assigned orgs

**Sources:** CLAUDE.md ~L226

---

## CATEGORY 12: CREDIT & USAGE TRACKING

### 12.1 Economic Model

| Service | Cost/Unit | Customer Price/Unit | Margin |
|---------|-----------|-------------------|--------|
| Voice AI (VAPI) | $0.15/min | $0.25/min | 40% |
| Video AI (Tavus) | $0.20/min | $0.32/min | 37.5% |
| SMS (TextMagic) | $0.02/msg | $0.05/msg | 60% |
| AI Tokens (Claude) | Variable | Tracked | N/A |

**Sources:** CLAUDE.md ~L317-319, ARCHITECTURE_VISUAL_MAP.md ~L1050-1057

### 12.2 Credit Tracking Tables

- `credit_policies` -- Per-org credit rules and limits
- `credit_allocations` -- Allocated credits per service per org per period
- `credit_usage` -- Individual usage records (timestamp, service, amount, org)

**Sources:** SRS v3.0 ~L1321-1323, REVERSE_SRS_old.md

### 12.3 Quota-Based Provisioning

- `service_quotas` table: max_voice_minutes, max_video_minutes, max_sms_messages per org
- `service_allocations` table: allocated resources per agent per org
- 80% usage threshold alerts
- Master API key approach: platform owns one key per service, allocates usage per org

**Sources:** SRS v3.0 ~L350-420

### 12.4 Billing System (UI Specified, Backend Partial)

**DESIGNER_UPDATE_SPEC.md** specifies a comprehensive billing UI:

**Org-facing (View A):**
- Plan name, base monthly fee, anniversary date
- Usage progress bars (voice/video/SMS/documents) with default included amounts
- Overage calculation: `(usage - default_minutes) * markup_rate`
- Add-ons section (recurring or one-time)
- Invoice history

**Admin-facing (View C -- Super Admin):**
- Revenue dashboard: MRR, active accounts, avg rev/account, overage revenue
- Per-org billing configuration
- Invoice builder with auto-populated line items
- Rate configuration per tool via Economy settings on tool cards

**Data Flow:** Tool Card Economy Settings -> Invoice Line Items
- Super Admin sets rates on each tool card's Economy section
- System tracks usage per org per billing period
- Invoice Builder auto-populates: `(usage - default_minutes) * markup_rate`
- Rate changes take effect only in NEXT billing period

**Implementation Status:** Credit tracking (Phase 6) is complete. Full billing UI with invoicing is specified in DESIGNER_UPDATE_SPEC but implementation status unclear for V2.1.

**Sources:** DESIGNER_UPDATE_SPEC.md ~L826-1006, CLAUDE.md ~L183

---

## WATCH AREA 1: AGENT FUNCTIONALITY / DEFAULTS

### What Agents Exist by Default

**System Agent (Always Present):**
- **Automa** (also called DealerBrain, formerly "Daria" in early architecture docs)
- Tier 0 / System Level agent
- Available to all users via floating chat and dedicated `/chat` page
- Has full tool access: CRM queries, VIN lookups, internal DB queries
- System prompt configurable by Super Admin via AI Configuration settings
- Uses Claude API with streaming SSE

**Default Communications Agent (Per-Org):**
- Created during Org Creation Wizard (Step 6)
- Handles: outbound calls (VAPI), outbound SMS (TextMagic), reactive after-hours coverage
- Skills assigned from 74-skill catalog during creation
- Cannot be modified by users except: triggers and instruction supplement
- This is the agent that executes proactive lead follow-up

**Sources:** session-knowledge.md ~L56-58, ~L69-70, DESIGNER_UPDATE_SPEC.md ~L1313-1335

### Agent Architecture (V1 -> V2 Transition)

**V1:** 27 hardcoded agents + a "super chat." Each agent was an overlay with prepopulated context and instructions on the super chat.

**V2:** Users CREATE agents and ADD skills to them from a 74-skill catalog. Skills are the same concept (context + instructions) but now user-selectable. The Agents page has an option to add skills when creating/editing an agent.

**This is NOT a blocker.** It was reported as one because the V1->V2 transition was not understood by testing agents. The architecture changed intentionally.

**Sources:** session-knowledge.md ~L52-58

### Agent Types in V2

| Type | Channel | Service |
|------|---------|---------|
| Voice | Phone calls | VAPI |
| Video | Video sessions | Tavus |
| Chat | Text chat | Internal (DealerBrain) |
| Email | Email responses | Resend |
| Task | Background automation | Internal |

**Sources:** client-audit.md ~L884-896

### Skills Catalog

74 pre-built skills organized into 4 categories:
- **Sales (20):** Lead Qualifier, Payment Calculator, Inventory Optimizer, Trade-In Valuator, etc.
- **Finance (20):** Deal Structurer, Credit Analyzer, Lender Matcher, etc.
- **Operations (20):** Service Scheduler, Parts Inventory Manager, Workflow Optimizer, etc.
- **General (14):** Data Intelligence, AI Chat, Document Generator, etc.

Skills are managed in AI Configuration > Skills tab (Super Admin only). Per-agent skill assignment via Agent Config Pane > Tools & Skills section.

**Sources:** DESIGNER_UPDATE_SPEC.md ~L1365-1467

### Emergency Kill Switch

Super Admin only. Located in AI Configuration > Skills tab.
- Turns off ALL agent activity for ALL users in ALL organizations
- Requires confirmation dialog
- Safety mechanism for production incidents

**Sources:** DESIGNER_UPDATE_SPEC.md ~L523-529

---

## WATCH AREA 2: BILLING

### Current State

- **Credit tracking:** Implemented (Phase 6 complete per CLAUDE.md ~L183)
- **Usage tracking:** Per-org, per-service tracking in `credit_usage` table
- **Billing UI:** Fully specified in DESIGNER_UPDATE_SPEC.md but implementation unclear
- **Payment processing:** NO payment processing in V1/V2 (no Stripe integration -- explicitly excluded in SRS v3.0 ~L893)
- **Invoice generation:** PDF invoice generation specified (REQ-BILL-001), manual billing by Super Admin only

### Billing Model

- Default OFF per organization
- Anniversary-based billing periods
- Base monthly fee + overage charges
- Default included minutes per service (voice, video)
- Overage: `(actual_usage - default_minutes) * markup_rate`
- Add-ons: recurring or one-time line items
- Proration for mid-cycle enables

### What's Missing

1. No Stripe or payment processor integration
2. No automated billing -- all manual Super Admin actions
3. Billing page in Profile (Org Admin view) may be "commented out -- PHASE-FUTURE" per client-audit.md ~L989
4. Invoice Builder UI specified but backend invoice generation service status unclear

**Sources:** SRS v3.0 ~L887-917, DESIGNER_UPDATE_SPEC.md ~L826-1006, client-audit.md ~L989

---

## WATCH AREA 3: UNIFIED INBOX HANDOFF

### How External Agent Conversations Transition to Staff

1. External conversation initiated via Widget (chat/video/callback) or inbound SMS/call
2. Widget is a "portal to an agent" -- not standalone. It connects to a VAPI, Tavus, or chat agent.
3. Conversation data stored in `conversations` + `messages` tables with org isolation
4. SMS state machine: `AI_ACTIVE` -> `HUMAN_ACTIVE` when staff claims in Unified Inbox
5. Staff sees conversation thread in Work Center > Communication tab (UniversalInbox component)
6. Staff can pick up where the agent left off -- full conversation history visible
7. When staff responds, conversation mode flips to `HUMAN_ACTIVE`
8. Agent stops responding until staff releases or timeout occurs

### Gaps

- SMS state machine schema exists (migration 032) but full controller logic is incomplete
- Voice call handoff (VAPI to human) -- mechanism unclear in documentation
- Video session (Tavus) -- no documented handoff mechanism (sessions are standalone)
- "Unified Inbox" currently maps to Work Center > Communication tab, which shows email threads via UniversalInbox component + SMS compose via TextMagic

**Sources:** session-knowledge.md ~L17-22, ~L46-48, SRS Addendum v3.2, client-audit.md ~L917

---

## WATCH AREA 4: SUPER ADMIN FUNCTIONALITY

### What Super Admin Can Do (Extracted from All Sources)

**Organization Management:**
- Create organizations via Org Creation Wizard (7 steps)
- View/edit all organizations
- Enable/disable billing per org
- Configure billing rates and default minutes
- Create users in any organization
- Assign any role level

**System Configuration:**
- AI Configuration: System Prompt, Agent Behavior, Skills management (74 skills), Hunches settings
- Emergency Kill Switch (disable ALL agents globally)
- Data Management: Database Uploads, Data Health monitoring
- Security & Privacy settings (currently grayed out/non-interactive except password reset)

**Tools & Integrations:**
- See technical names on tool cards (other roles see friendly names only)
- Access API Keys tab (rotate keys, set rate limits)
- Access Webhooks tab (configure webhook URLs and event subscriptions)
- Economy settings on tool cards (set base rate and markup rate per tool)
- Enable/disable tools system-wide

**Billing Management:**
- Revenue dashboard (MRR, active accounts, avg revenue, overage)
- Per-org billing configuration
- Invoice Builder with auto-populated line items
- Send invoices
- Add manual add-ons

**Monitoring:**
- View all organization billing status
- Credit usage across all orgs
- Activity & AI Governance page (stats, feed, CSV export)

### What's Undertested

Per owner statement: "Super Admin functionality undertested, owner has focused on customer-facing features. Needs thorough extraction of what super admin can see/do vs org admin vs staff."

Specific areas needing verification:
- Partner link management (Settings > Partner Links)
- Cross-org user management
- System-level settings application
- Billing management end-to-end flow
- Tool economy configuration -> invoice line item flow

**Sources:** DESIGNER_UPDATE_SPEC.md ~L80-98, ~L826-1006, ~L187-316, session-knowledge.md ~L98-99, client-audit.md ~L949-968

---

## WATCH AREA 5: CONTEXT ROUTER FUNCTIONALITY

### What It Routes

The Context Router manages data source selection and caching for queries that need external + internal data:
- VIN Solutions queries (primary source for CRM data)
- Local database queries (fallback, also for non-CRM data)
- Caches results with TTL-based expiration

### How It Decides

1. **SourceSelector:** Checks if requested data type is available from VIN Solutions
   - If yes and cache not expired: return cached VIN data
   - If yes and cache expired: query VIN API, cache result, return
   - If no: fall back to local database
2. **CacheManager:** Manages TTL per data source
   - VIN data: 5-minute TTL
   - VAPI/Tavus data: 1-hour TTL

### What It Does NOT Route

- Excel/CSV uploads (processed separately via Data Management)
- Internal-only data (tasks, approvals, hunches -- these come from internal DB directly)
- Real-time webhook events (these write directly to DB without Context Router intermediation)

### Coverage

~20% of data consumers use Context Router. The rest query data sources directly. This means the intelligent routing and caching benefits are only available to a fraction of the application.

### Aspirational vs Implemented

The ARCHITECTURE_VISUAL_MAP.md describes a sophisticated Context Router with:
- NLP parsing for intent extraction
- Domain classification
- Entity validation with interactive entity collection
- 4-tier memory loading
- Multi-agent orchestration

The implemented Context Router is simpler: SourceSelector + CacheManager for data source queries. The multi-agent orchestration and NLP parsing are not implemented.

**Sources:** SRS v3.0 ~L1200-1270, ARCHITECTURE_VISUAL_MAP.md ~L1160-1293, DATA_SOURCE_INVENTORY.md, REVERSE_SRS_old.md

---

## CROSS-WAVE NOTES VERIFICATION

### CW-1: Hub has exactly 3 tabs (Calendar, Leads, Inbox)

**CONFIRMED** by DESIGNER_UPDATE_SPEC.md ~L10-13: "Hub has exactly 3 tabs: Calendar, Leads, Inbox. Any older document that mentions 4 Hub tabs is WRONG and contaminated."

**CONFLICT:** Current implementation (`work-center.tsx`) has 5 tabs: Calendar, Tasks, Approvals, Communication, Open Leads (per client-audit.md ~L913-918). The frontend rebuild (V2.1) will reduce this to 3 per designer spec.

### CW-2: Skills = agent overlays (V1 -> V2 architecture)

**CONFIRMED** by session-knowledge.md ~L52-58 and DESIGNER_UPDATE_SPEC.md ~L1365-1467. V1 had 27 hardcoded agents; V2 has a 74-skill catalog that users assign to agents. This was the #1 source of testing agent confusion.

### CW-3: Widgets are portals to agents

**CONFIRMED** by session-knowledge.md ~L17-22. A widget connects to a VAPI agent, Tavus agent, or chat agent. It is not standalone. Externally-initiated conversations can be continued internally in the Unified Inbox.

### CW-4: Payment-critical demo set (7 capabilities)

**CONFIRMED** by session-knowledge.md ~L64-89:
1. Metrics & Insights display correctly
2. Communications Agent configuration with criteria from system and VIN fields
3. Appointment flow: appointment -> calendar -> VIN Solutions insert with note
4. Proactive lead follow-up: outbound call + outbound text when leads arrive
5. Reactive after-hours coverage: SMS and phone coverage when staff unavailable
6. Widgets: all 3 deployment modes (unified, embed, hosted)
7. Automa Chat: ability to chat with Automa

### CW-5: Lead assignment is NOT part of requirements

**CONFIRMED** by session-knowledge.md ~L44.

### CW-6: Most actionable activities go through an agent at user level

**CONFIRMED** by session-knowledge.md ~L39-41. CRM insertions, two-way calls, two-way texts all go through an agent.

### CW-7: Communication agent cannot be modified by user except triggers and instruction supplement

**CONFIRMED** by session-knowledge.md ~L42.

---

## CONFLICTS DETECTED

### CONFLICT C-01: Table Count Discrepancy
- SRS v3.0 specifies 20 tables (original spec, ~L1333)
- CLAUDE.md says 36 tables (~L175)
- database-audit.md says 53 tables
- INIT_PROJECT_ANSWERS.txt says 53 tables (~L16)
- **Resolution needed:** 53 is the actual count (database-audit is closest to ground truth). SRS and CLAUDE.md are stale.

### CONFLICT C-02: Tech Stack Mismatch (Spec vs Implementation)
- SRS v3.0 specifies: Next.js 14, Zustand, Tremor, Vercel deployment (~L1110-1141)
- Implementation uses: Vite + React 18, TanStack Query + React Context, shadcn/ui, PM2 deployment
- **Resolution:** Implementation decisions D-003 and D-009 changed the stack. SRS v3.0 is the original spec; implementation diverged intentionally.

### CONFLICT C-03: AI Model Version
- SRS v3.0 says: `claude-3-5-sonnet-20241022` (~L1127)
- Implementation note says: `claude-sonnet-4-20250514`
- **Resolution:** Model was upgraded. SRS is stale.

### CONFLICT C-04: Notification Transport
- SRS v3.0 ~L859: SSE for real-time notifications
- Implementation note D-002: WebSocket (Socket.IO) chosen instead
- SRS v3.0 ~L966 AC still says "SSE connection established on login"
- DealerBrain streaming uses SSE (separate from notifications)
- **Resolution:** Notifications use WebSocket; DealerBrain streaming uses SSE. Both coexist.

### CONFLICT C-05: Work Center Tab Count
- DESIGNER_UPDATE_SPEC.md ~L10-13: Hub has exactly 3 tabs (Calendar, Leads, Inbox)
- client-audit.md ~L913-918: Current implementation has 5 tabs (Calendar, Tasks, Approvals, Communication, Open Leads)
- **Resolution:** V2.1 frontend rebuild will implement 3-tab design. Current 5-tab implementation is V2 legacy.

### CONFLICT C-06: RLS Variable Name
- SRS v3.0 ~L1193: `app.current_organization_id`
- Some policies in database: `app.current_org_id`
- **Resolution needed:** These are different variable names. One must be chosen and all policies updated. This is a security-critical bug.

### CONFLICT C-07: VIN Solutions Data Window
- Some docs reference "48-hour API window" for VIN data
- VIN_SOLUTIONS_INTEGRATION.md and Addendum v3.1 clarify: VIN is QUERY-ONLY, data available as long as API returns it, no inherent 48-hour limit
- "48-hour" refers to the last-modified window used for polling, not an API limitation
- **Resolution:** No hard 48-hour limit. Polling uses configurable date range.

### CONFLICT C-08: VIN Header Casing
- Some docs: `application/vnd.coxauto.V3+json` (uppercase V)
- Actual API: `application/vnd.coxauto.v3+json` (lowercase v)
- **Resolution:** Use lowercase v3. docs-audit.md flagged this inconsistency.

### CONFLICT C-09: DESIGN_FLAGS.md State
- DESIGN_FLAGS.md: No open flags, no resolved flags (empty)
- docs-audit.md: D-FLAG-001 (Consolidate Triggers into Voice Agent Entity) PENDING REVIEW for 5 days
- **Resolution needed:** Either DESIGN_FLAGS.md was updated after the audit, or the audit looked at a different version.

### CONFLICT C-10: VIN Solutions Integration Direction
- SRS v3.0 ~L1275: "bidirectional sync (Nexxus -> VIN outbound Phase 1, VIN -> Nexxus inbound Phase 2)"
- SRS Addendum v3.1: "VIN Solutions integration is QUERY-ONLY (not bidirectional sync)"
- ARCHITECTURE_VISUAL_MAP.md ~L941-958: Describes VIN webhook handler (implies bidirectional)
- **Resolution:** Current reality is query-only + polling. Lead creation (outbound) exists but has the leadSource format bug. No VIN webhooks (inbound) exist.

### CONFLICT C-11: Settings Tab Count and Structure
- client-audit.md ~L949: 16+ settings tabs
- DESIGNER_UPDATE_SPEC.md ~L64-76: 9 tiles + Billing sub-menu item
- **Resolution:** V2.1 designer spec reduces and reorganizes settings. Current implementation has more granular tabs.

### CONFLICT C-12: Production URL
- Some docs: `nexxusdev.huminicdev.com`
- Other docs: `nexxusv2.huminicdev.com`
- **Resolution needed:** Verify which is the actual production URL.

### CONFLICT C-13: VIN Token Refresh Interval
- Some docs mention 6-hour VIN token refresh
- VIN_SOLUTIONS_INTEGRATION.md: tokens expire every 60 minutes
- Scheduled job: 30-minute refresh interval
- **Resolution:** 60-minute expiry with 30-minute proactive refresh is the implemented behavior. 6-hour reference is stale.

---

## MISSING INFORMATION

### MI-01: SMS State Machine Controller
Schema defined in migration 032 but full state transition logic is not documented as fully implemented. Need to verify code coverage of AI_ACTIVE / HUMAN_ACTIVE / DORMANT transitions.

### MI-02: Voice Call Handoff Mechanism
How does a VAPI voice call transition from AI to human agent? The SMS handoff is documented (state machine) but voice call handoff is not.

### MI-03: Trigger Deduplication Details
Two dedup mechanisms exist per owner confirmation, but their exact implementation (what field is deduped, time window, mechanism type) is not documented in any file.

### MI-04: Error Retry Policy for Sync Queue
Sync queue failure handling is mentioned but retry count, backoff strategy, and dead letter behavior are not specified.

### MI-05: Rate Limiting Configuration
ARCHITECTURE_VISUAL_MAP mentions rate limits (200-1000 req/hour per agent), but actual implemented rate limiting configuration is not documented.

### MI-06: Redis Implementation Status
SRS v3.0 specifies Redis for caching and session management. ARCHITECTURE_VISUAL_MAP references Redis for Tier 1 short-term memory. Actual Redis deployment status in V2 is not confirmed.

### MI-07: pgvector Implementation Status
SRS v3.0 mentions pgvector for vector search. ARCHITECTURE_VISUAL_MAP references it for Tier 3 long-term semantic memory. Actual implementation status unclear.

### MI-08: ClickHouse Implementation Status
ARCHITECTURE_VISUAL_MAP references ClickHouse for OLAP data warehouse. Not confirmed in V2 codebase.

### MI-09: Cube.js Semantic Layer
ARCHITECTURE_VISUAL_MAP references Cube.js. Not confirmed in V2 codebase.

### MI-10: Auto-Reaper Cron for Recordings
SRS v3.0 specifies daily 2:00 AM cron for 30-day recording cleanup. Implementation status not verified.

### MI-11: MFA Implementation
SRS v3.0 ~L1089: "MFA SHALL be required for administrative users." Security settings UI shows it as grayed out (ON but non-interactive). Actual MFA enforcement status unclear.

### MI-12: Widget Domain Whitelist Enforcement
Widget system includes domain whitelist feature. Actual enforcement mechanism and configuration location need verification.

### MI-13: Hunch Generation Prompt Details
Hunch generation uses Claude "Detective" agent with 7 categories. The actual prompt template and data it receives are not documented in accessible files.

### MI-14: Appointment Confirmation Token Flow
48-hour appointment confirmation tokens mentioned but the full flow (generation, email inclusion, validation endpoint, expiry handling) is not fully documented.

### MI-15: Partner Admin Org Provisioning Flow
ARCHITECTURE_GUIDE_RBAC_ADDITION.md describes top-down provisioning but the actual API endpoints and UI flow for partner admin creating/managing organizations are not fully specified.

---

## SUMMARY STATISTICS

| Category | Items Extracted | Key Conflicts | Missing Info |
|----------|----------------|---------------|--------------|
| 1. Data Flow Narratives | 8 major flows | 1 (VIN direction) | 0 |
| 2. Trigger & Event Mechanics | 7 event types, 5 actions, 8 jobs | 0 | 1 (dedup details) |
| 3. Webhook Processing | 4 webhook pipelines | 1 (VIN webhook aspirational) | 0 |
| 4. Auth & Authorization | 4 subsystems | 1 (RLS variable) | 1 (MFA status) |
| 5. State Machines | 5 state machines | 0 | 1 (SMS controller) |
| 6. Integration Protocols | 8 integrations | 2 (model, headers) | 3 (Redis, pgvector, ClickHouse) |
| 7. Context Router | 4 components | 1 (aspirational vs real) | 0 |
| 8. Below-the-Line | 6 mechanisms | 1 (RLS variable) | 2 (retry, rate limit) |
| 9. Error Handling | 4 subsystems | 0 | 1 (retry policy) |
| 10. Security | 5 layers | 0 | 2 (MFA, domain whitelist) |
| 11. Notification Routing | 4 channels | 1 (SSE vs WebSocket) | 0 |
| 12. Credit & Usage | 4 subsystems | 0 | 1 (billing backend) |
| **Watch Areas** | 5 areas analyzed | 2 total | 4 total |
| **Cross-Wave Notes** | 7 verified | 1 (tab count) | 0 |
| **TOTALS** | ~60+ items | 13 conflicts | 15 missing items |

---

## END OF WAVE 2 ANALYST OUTPUT
