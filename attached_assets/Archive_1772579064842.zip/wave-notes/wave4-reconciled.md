# Wave 4 RECONCILED Output -- Acceptance Criteria

**Reconciliation By:** Orchestrator (Claude Opus 4.6)
**Date:** 2026-03-03
**Inputs:** wave4-analyst.md (247 AC, 1126 lines), wave4-reviewer.md (98 AC, 1108 lines)

---

## Reconciliation Summary

### AC Counts Per Feature Area

| # | Feature Area | Analyst | Reviewer | Agreed | Analyst-Only | Reviewer-Only | Disagree | Reconciled Total |
|---|-------------|---------|----------|--------|--------------|---------------|----------|-----------------|
| 1 | Authentication & Access | 10 | 6 | 6 | 4 | 0 | 0 | 10 |
| 2 | Navigation & Layout | 14 | 11 | 7 | 3 | 4 | 1 | 15 |
| 3 | Automa Chat | 13 | 9 | 7 | 4 | 2 | 0 | 13 |
| 4 | Insights Dashboard | 14 | 13 | 9 | 3 | 4 | 0 | 17 |
| 5 | Agents Page | 11 | 8 | 7 | 3 | 1 | 0 | 11 |
| 6 | Hub - Calendar | 8 | 5 | 5 | 2 | 1 | 0 | 8 |
| 7 | Hub - Leads | 6 | 6 | 5 | 1 | 1 | 0 | 7 |
| 8 | Hub - Inbox | 8 | 8 | 6 | 1 | 2 | 0 | 9 |
| 9 | Widgets | 7 | 11 | 6 | 1 | 5 | 0 | 12 |
| 10 | Triggers | 7 | 6 | 5 | 2 | 1 | 0 | 8 |
| 11 | Drive | 3 | 4 | 2 | 1 | 2 | 0 | 5 |
| 12 | Settings | 10 | 11 | 8 | 1 | 3 | 0 | 12 |
| 13 | Metrics & Scores | 8 | 8 | 5 | 2 | 3 | 0 | 10 |
| 14 | Notifications | 6 | 6 | 5 | 1 | 1 | 0 | 7 |
| 15 | Activity & Governance | 5 | 6 | 3 | 1 | 3 | 0 | 7 |
| — | **TOTALS** | **130** | **118** | **85** | **30** | **33** | **1** | **151** |

**Notes on count discrepancy:** The Analyst's summary claims 247 total AC items, but the enumerated items (AUTH-001 through GOVERN-005) total approximately 130 unique AC items. The 247 figure likely includes watch-area findings, conflict items, and missing-AC entries counted alongside formal AC extractions. The Reviewer's summary claims 98 AC items, and the enumerated items (AC-R001 through AC-R185) total approximately 118 unique AC items (the reviewer's numbering skips ranges, e.g. R007-R009, R020-R029, etc., but still yields more than 98 formal AC entries). For reconciliation purposes, the actual enumerated items are what matter.

### Agreement Level
- **85 items** have clear agreement between both agents (same feature, same testable outcome, potentially different source citations)
- **30 items** are Analyst-only additions (mostly INFERRED or more granular breakdowns)
- **33 items** are Reviewer-only additions (mostly from additional source files the Reviewer read: 38 vs Analyst's 28)
- **1 item** has a genuine disagreement requiring owner decision

---

## DISAGREEMENTS REQUIRING OWNER RESOLUTION

### DISAGREE-1: Sidebar Navigation Order

**Analyst (NAV-001):** Main, Insights, Agents, Hub, Drive
**Source:** ===DevDesign Notes===.md line 129; Acceptance Criteria.md line ~35

**Reviewer (AC-R010):** Main, Insights, Agents, Hub, Drive, Activity, Settings, Profile
**Source:** ===DevDesign Notes===.md line 129; ARCHITECTURE_GUIDE.md; MASTER_SRS.md Section 4.2
**Reviewer Note:** MASTER_SRS.md says Main, Agents, Drive, Insights, Hub, Activity, Settings -- flagged as CONFLICT.

**Analysis:** Both agents agree DevDesign Notes says "Main, Insights, Agents, Hub, Drive." The Reviewer additionally noted MASTER_SRS contradicts this with a different order. The Reviewer's AC includes Activity, Settings, Profile as sidebar items; the Analyst limits to the 5 primary items.

**Owner Decision Needed:**
1. What is the canonical sidebar order?
2. Are Activity, Settings, and Profile sidebar items or accessed differently?
3. Per DevDesign Notes, Activity moved to Insights sub-tab -- does it still appear in sidebar?

---

## RECONCILED AC BY FEATURE AREA

### 1. Authentication & Access

| AC ID | Statement | Tag | Agreement | Sources |
|-------|-----------|-----|-----------|---------|
| AC-001 | Login page renders with email, password fields, and "Sign In" button at /login | [EXPLICIT] | AGREED (AUTH-001 = AC-R001) | Analyst: Acceptance Criteria.md line ~45; Reviewer: UI_INTERACTIVE_ELEMENTS_MAP.md, MASTER_SRS.md 5.1 |
| AC-002 | Successful login redirects to Main page and stores JWT tokens (access 15 min, refresh 7 day) in localStorage | [EXPLICIT] | AGREED (AUTH-002 = AC-R001+R002 combined) | Analyst: CARRY_FORWARD_MANIFEST.md lines 39-44; Reviewer: MASTER_SRS.md 11.2, UNIFIED_HANDOFF_PROMPT.md |
| AC-003 | Invalid login shows error message, no redirect occurs | [EXPLICIT] | AGREED (AUTH-003, Reviewer implicit in R001 negative case) | Analyst: Acceptance Criteria.md line ~45, UNIFIED_HANDOFF_PROMPT.md line 152 |
| AC-004 | JWT token auto-refreshes when access token is within 5 minutes of expiry via POST /api/auth/refresh | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | AUTH-004; CARRY_FORWARD_MANIFEST.md lines 39-46; UNIFIED_HANDOFF_PROMPT.md lines 153-160 |
| AC-005 | Organization switching: Partner/Super Admin can switch org via org switcher; POST /api/auth/switch-org returns new scoped tokens | [EXPLICIT] | AGREED (AUTH-005 = AC-R005) | Analyst: CARRY_FORWARD_MANIFEST.md lines 138-146; Reviewer: UI_INTERACTIVE_ELEMENTS_MAP.md, MASTER_SRS.md 3.2 |
| AC-006 | Super Admin org switcher includes "Nexxus System" option showing default system configuration | [EXPLICIT] | AGREED (AUTH-006 = AC-R006) | Both: ===DevDesign Notes===.md line 37 |
| AC-007 | Logout clears all 4 localStorage keys and redirects to /login | [EXPLICIT] | AGREED (AUTH-007 = AC-R185) | Analyst: CARRY_FORWARD_MANIFEST.md lines 125-129; Reviewer: UI_INTERACTIVE_ELEMENTS_MAP.md |
| AC-008 | Password reset flow: "Forgot Password" link sends reset email; user can set new password via reset link | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | AUTH-008; UNIFIED_HANDOFF_PROMPT.md line 113 |
| AC-009 | 4-tier RBAC enforcement (super_admin, partner_admin, org_admin, org_staff): only authorized features visible per role | [EXPLICIT] | AGREED (AUTH-009 = AC-R004) | Analyst: MASTER_SRS.md Section 3; Reviewer: MASTER_SRS.md 3.3, CONSTITUTION.md 5 |
| AC-010 | Protected route guard: unauthenticated users redirected to /login | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | AUTH-010; CARRY_FORWARD_MANIFEST.md line 253 |
| AC-RLS | RLS tenant isolation: logged-in user cannot see or modify data from another org | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R003; MASTER_SRS.md 5.1, 11.2; CONSTITUTION.md 2.3 |

**Unified Count: 11**

---

### 2. Navigation & Layout

| AC ID | Statement | Tag | Agreement | Sources |
|-------|-----------|-----|-----------|---------|
| AC-011 | Sidebar navigation order (see DISAGREE-1 for canonical order dispute) | [EXPLICIT] | DISAGREE-1 (AUTH-001 vs AC-R010) | See DISAGREE-1 |
| AC-012 | Sidebar width is 64px when collapsed | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | NAV-002; ARCHITECTURE_GUIDE.md, Acceptance Criteria.md line ~36 |
| AC-013 | 3-pane grid layout on desktop (>1024px): sidebar 64px, left 240-400px, center flexible, right 320-500px optional | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | NAV-003; ARCHITECTURE_GUIDE.md |
| AC-014 | Settings accessible as submenu with 9 tile-based categories for org_admin+ | [EXPLICIT] | AGREED (NAV-004 ~ AC-R015 + AC-R140) | Analyst: DESIGNER_UPDATE_SPEC.md; Reviewer: ===DevDesign Notes===.md line 220 |
| AC-015 | Staff cannot see Settings in sidebar | [EXPLICIT] | AGREED (NAV-005 = AC-R015) | Both: ===DevDesign Notes===.md line 220 |
| AC-016 | No vendor names (VIN Solutions, VAPI, Tavus, TextMagic) in user-visible UI | [EXPLICIT] | AGREED (NAV-006 = AC-R017) | Both: CONSTITUTION.md, MASTER_SRS.md AC-002 |
| AC-017 | No data source labels ("excel_upload", "vin_api", etc.) in user-visible UI | [EXPLICIT] | AGREED (NAV-007 = AC-R018) | Both: CONSTITUTION.md, MASTER_SRS.md AC-002/003 |
| AC-018 | Nexxus logo renders WITHOUT icon element | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | NAV-008; ===DevDesign Notes===.md line 120 |
| AC-019 | Activity feed icon/indicator in header for current org lead activity | [EXPLICIT] | AGREED (NAV-009, similar to AC-R180) | NAV-009; ===DevDesign Notes===.md line 122 |
| AC-020 | Mobile responsive (<768px): sidebar collapses to hamburger, single-column layout | [EXPLICIT] | AGREED (NAV-010 = AC-R016) | Both: ARCHITECTURE_GUIDE.md responsive breakpoints |
| AC-021 | Theme toggle (light/dark) in top nav bar, persists in localStorage | [EXPLICIT] | AGREED (NAV-011 = AC-R184) | Analyst: CARRY_FORWARD_MANIFEST.md; Reviewer: UI_INTERACTIVE_ELEMENTS_MAP.md |
| AC-022 | 5 layout types: A (chat-only), B (info+chat), C (chat+info), D (settings), E (library) | [EXPLICIT] | [ANALYST addition] [EXPLICIT] (partial: Reviewer has R012, R013 for specific layouts) | NAV-012; app_identity.md Section B |
| AC-023 | Notifications bell in header with unread count badge | [INFERRED] | AGREED (NAV-013 ~ AC-R172) | NAV-013; UI_INTERACTIVE_ELEMENTS_MAP.md; Reviewer also AC-R172 |
| AC-024 | Product tour RBAC: first-login tour adapts content based on user's role | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | NAV-014; ===DevDesign Notes===.md line 40 |
| AC-R011 | Sidebar pop-out submenu on hover; double-arrow click locks it open | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R011; MASTER_SRS.md 4.2, ARCHITECTURE_GUIDE.md 1.2, app_identity.md H |
| AC-R012 | Layout Type B on Main Dashboard: info center, chat right, chat opens by default on this page only | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R012; MASTER_SRS.md 4.1, 4.3; app_identity.md B1 |
| AC-R013 | Layout Type C on Agents page: chat center, config in right pane | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R013; MASTER_SRS.md 4.1; app_identity.md B2 |
| AC-R014 | Activity tab hidden from org_staff | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R014; MASTER_SRS.md 4.2 |
| AC-R019 | Zero JavaScript errors in browser console when navigating all pages | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R019; Acceptance Criteria.md item 12; MASTER_SRS.md AC-019 |
| AC-R020 | Each page loads within 3 seconds | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R020; MASTER_SRS.md 11.1 |

**Unified Count: 20**

---

### 3. Automa Chat

| AC ID | Statement | Tag | Agreement | Sources |
|-------|-----------|-----|-----------|---------|
| AC-030 | Chat interface (Automa) present and ready on Main page | [EXPLICIT] | AGREED (CHAT-001 = AC-R030) | Both: ===DevDesign Notes===.md, Acceptance Criteria.md |
| AC-031 | Chat labeled "Automa"; name "DealerBrain" does NOT appear in UI | [EXPLICIT] | AGREED (CHAT-002, Reviewer confirms in AC-R017 vendor name rule) | Analyst: ===DevDesign Notes===.md line 127; CONSTITUTION.md |
| AC-032 | SSE streaming with 6 event types: thinking, tool_start, tool_end, token, done, error | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | CHAT-003; CARRY_FORWARD_MANIFEST.md lines 106-117 |
| AC-033 | Thinking animation is flat line wave (not dots or spinner) | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | CHAT-004; ===DevDesign Notes===.md line 125 |
| AC-034 | Bot messages on left, user messages on right, no bot icon needed | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | CHAT-005; ===DevDesign Notes===.md line 126 |
| AC-035 | Automa functions as ChatGPT replacement for dealership context | [EXPLICIT] | AGREED (CHAT-006 = AC-R032) | Both: Acceptance Criteria.md item 9 |
| AC-036 | Per-org system context configurable in Settings, incorporated into Automa responses | [EXPLICIT] | AGREED (CHAT-007 = AC-R038) | Both: ===DevDesign Notes===.md line 88; DESIGNER_UPDATE_SPEC.md |
| AC-037 | Tool calling visibility: user sees tool_start indicator, then tool_end with result | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | CHAT-008; CARRY_FORWARD_MANIFEST.md lines 110-115 |
| AC-038 | Chart rendering inline in chat when tool_end returns chartData | [EXPLICIT] | AGREED (CHAT-009, AC-R035 for artifacts broadly) | Analyst: CARRY_FORWARD_MANIFEST.md line 115; UNIFIED_HANDOFF_PROMPT.md line 268 |
| AC-039 | VIN query limitations disclosed to user when VIN API is limited | [EXPLICIT] | AGREED (CHAT-010 = AC-R034) | Both: ===DevDesign Notes===.md line 36 / MASTER_SRS.md AC-011 |
| AC-040 | Multi-turn conversations (5-10 turns minimum) with context maintained | [EXPLICIT] | AGREED (CHAT-011 = AC-R032) | Both: Acceptance Criteria.md items 8, 9 |
| AC-041 | Send SMS/Email from chat via TextMagic/Resend after user approval | [INFERRED] | [ANALYST addition] [INFERRED] | CHAT-012; ===DevDesign Notes===.md lines 79-81 |
| AC-042 | Attach artifact from Drive or upload within chat | [INFERRED] | [ANALYST addition] [INFERRED] | CHAT-013; ===DevDesign Notes===.md line 81 |
| AC-R031 | Automa chat appears as floating popout overlay (not inline), available globally except on dedicated chat page | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R031; ACCEPTANCE_VERIFICATION_REPORT.md AC-1 |
| AC-R033 | Automa CRM data query: "Search VIN for [name]" returns lead information | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R033; Acceptance Criteria.md items 4, 9; MASTER_SRS.md 5.3 |
| AC-R036 | Automa first-token response time within 3 seconds | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R036; MASTER_SRS.md 11.1 |

**Unified Count: 16**

---

### 4. Insights Dashboard

| AC ID | Statement | Tag | Agreement | Sources |
|-------|-----------|-----|-----------|---------|
| AC-050 | Command Center displays 3 alert zones: Red (immediate), Yellow (watch list), Green (performance) | [EXPLICIT] | AGREED (INSIGHTS-001 = AC-R041) | Both: Insights Layout.md; ===DevDesign Notes===.md lines 52-64 |
| AC-051 | Dashboard sub-navigation: Dashboard (Command Center, Pipeline Health, Performance Scorecard) and Reports (Loss & Quality, Channel Intelligence, Trend & Forecast) | [EXPLICIT] | AGREED (INSIGHTS-002 = AC-R040) | Both: ===DevDesign Notes===.md lines 52-64, 163-176 |
| AC-052 | Hunches sub-tab available showing AI-generated insights | [EXPLICIT] | AGREED (INSIGHTS-003, included in AC-R040) | Both: ===DevDesign Notes===.md lines 65, 178 |
| AC-053 | Goals sub-tab REMOVED from Insights | [EXPLICIT] | AGREED (INSIGHTS-004, Reviewer CONFLICT-W4-4) | Both: ===DevDesign Notes===.md line 66 |
| AC-054 | Activity moved to Insights sub-tab (not standalone) | [EXPLICIT] | AGREED (INSIGHTS-005, Reviewer CONFLICT-W4-5) | Both: ===DevDesign Notes===.md line 128 |
| AC-055 | 6 priority reports available in Reports section | [EXPLICIT] | AGREED (INSIGHTS-006, Reviewer covers reports under AC-R040) | Analyst: Reports.md |
| AC-056 | Grid/tile view toggle on Insights data cards | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | INSIGHTS-007; ===DevDesign Notes===.md line 181 |
| AC-057 | VAPI voice metrics display (total calls, avg duration, calls by status) | [EXPLICIT] | AGREED (INSIGHTS-008 = AC-R044) | Both: Acceptance Criteria.md; MASTER_SRS.md Section 8 |
| AC-058 | Tavus video metrics display | [EXPLICIT] | AGREED (INSIGHTS-009 = AC-R045) | Both: Acceptance Criteria.md; MASTER_SRS.md Section 8 |
| AC-059 | Data accuracy mandate: displayed values within 2% of ground truth | [EXPLICIT] | AGREED (INSIGHTS-010 = AC-R047) | Both: CLARIFICATION_ANSWERS.md; MASTER_SRS.md AC-007 |
| AC-060 | Excel upload records excluded from all metric calculations | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | INSIGHTS-011; UNIFIED_HANDOFF_PROMPT.md Lesson 5 |
| AC-061 | Null guard safety on Insights percentage values (no crash on null .pct) | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | INSIGHTS-012; known_issues.md.md line 8 |
| AC-062 | Hunch lifecycle management with statuses and actionable recommendations | [EXPLICIT] | AGREED (INSIGHTS-013, similar coverage in Reviewer MISSING-W4-8) | Analyst: Hunches.md |
| AC-063 | Drill-down from metric tiles to detailed data and underlying records | [EXPLICIT] | AGREED (INSIGHTS-014 = AC-R042) | Both: Acceptance Criteria.md item 2 |
| AC-R046 | View Transcript: click on completed voice call shows full transcript in modal | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R046; Acceptance Criteria.md item 3; UI_INTERACTIVE_ELEMENTS_MAP.md |
| AC-R048 | Test calls excluded from metrics (IDs matching test-e2e-* pattern) | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R048; MASTER_SRS.md 11.3; ACCEPTANCE_VERIFICATION_REPORT.md AC-10 |
| AC-R049 | Dashboard Refresh button invalidates and reloads all metrics queries | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R049; UI_INTERACTIVE_ELEMENTS_MAP.md; CLARIFICATION_ANSWERS.md Q18 |
| AC-R050 | No placeholder metrics: if metric cannot be calculated, it is not displayed at all | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R050; CONSTITUTION.md 2.4, 3.1; MASTER_SRS.md 8.2 |
| AC-R051 | Date range filter on Insights: 24h, 48h, 7d, 30d | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R051; UI_INTERACTIVE_ELEMENTS_MAP.md |
| AC-R052 | CSV export from Command Center stale leads section | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R052; Insights Layout.md; IMPLEMENTATION_PLAN.md 7.1 |

**Unified Count: 20**

---

### 5. Agents Page

| AC ID | Statement | Tag | Agreement | Sources |
|-------|-----------|-----|-----------|---------|
| AC-070 | Agent list page displays configured agents for current org | [EXPLICIT] | AGREED (AGENTS-001 = AC-R060) | Both: Acceptance Criteria.md; UI_INTERACTIVE_ELEMENTS_MAP.md |
| AC-071 | Automa NOT listed on Agents page | [EXPLICIT] | AGREED (AGENTS-002 = AC-R037) | Both: ===DevDesign Notes===.md line 187. Note: Reviewer flags CONFLICT-W4-2 (MASTER_SRS says "always at top"). Both agents use DevDesign Notes as resolution. |
| AC-072 | New Agent creation: center dialog with input, channel buttons, tool tiles below; clicking tiles opens modal | [EXPLICIT] | AGREED (AGENTS-003 = AC-R061) | Both: ===DevDesign Notes===.md line 185; UI_INTERACTIVE_ELEMENTS_MAP.md |
| AC-073 | Agent right pane shows: configuration, activity log, triggers, prompt, knowledge, customer-facing link, phone number, chat link | [EXPLICIT] | AGREED (AGENTS-004 = AC-R064) | Both: ===DevDesign Notes===.md lines 83-89, 186-190 |
| AC-074 | Communications Agent is static, configured by Super Admin only, available out of the box | [EXPLICIT] | AGREED (AGENTS-005, Reviewer WATCH-1) | Both: ===DevDesign Notes===.md lines 72-75 |
| AC-075 | Agent name consistent across Tavus video, VAPI voice, and internal UI | [EXPLICIT] | AGREED (AGENTS-006 = AC-R067) | Both: Acceptance Criteria.md item 7; ===DevDesign Notes===.md lines 75-76 |
| AC-076 | Agent instructions editable in Settings | [EXPLICIT] | AGREED (AGENTS-007 = AC-R148) | Both: Acceptance Criteria.md item 13 |
| AC-077 | Skills architecture: users select from catalog of pre-built skills (74 from V1) | [EXPLICIT] | AGREED (AGENTS-009 = AC-R062) | Both: session-knowledge.md; DESIGNER_UPDATE_SPEC.md |
| AC-078 | Skills tab Super Admin only with emergency kill switch | [EXPLICIT] | AGREED (AGENTS-010 ~ AC-R146) | Both: DESIGNER_UPDATE_SPEC.md AI Configuration section |
| AC-079 | Agent CRUD operations (create, read, update, delete, duplicate, status toggle) | [INFERRED] | AGREED (AGENTS-011 = AC-R066) | Both: CARRY_FORWARD_MANIFEST.md; UI_INTERACTIVE_ELEMENTS_MAP.md |
| AC-080 | Agent right pane shows customer-facing link, phone number, text chat link | [EXPLICIT] | [ANALYST addition] [EXPLICIT] (more specific than AGENTS-004/AC-R064) | AGENTS-008; ===DevDesign Notes===.md lines 83-86 |
| AC-R060x | Agent list with search and type/status filters | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R060; UI_INTERACTIVE_ELEMENTS_MAP.md (search + filter detail) |
| AC-R063 | Agent chat interaction: selecting agent opens chat in center pane, 5-10 turn conversation | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R063; Acceptance Criteria.md item 8; UI_INTERACTIVE_ELEMENTS_MAP.md |
| AC-R065 | Agent toggle active/inactive status | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] (subset of AGENTS-011 but explicitly called out) | AC-R065; UI_INTERACTIVE_ELEMENTS_MAP.md |

**Unified Count: 14**

---

### 6. Hub - Calendar

| AC ID | Statement | Tag | Agreement | Sources |
|-------|-----------|-----|-----------|---------|
| AC-090 | Hub has exactly 3 tabs: Calendar, Leads, Inbox | [EXPLICIT] | AGREED (HUBCAL-001, Reviewer puts this at AC-R090 under Inbox) | Both: session-knowledge.md; ===DevDesign Notes===.md; DESIGNER_UPDATE_SPEC.md |
| AC-091 | Calendar view displays appointments/events for current user (staff) or all users (org_admin) | [EXPLICIT] | AGREED (HUBCAL-002 = AC-R070) | Both: ===DevDesign Notes===.md line 195; UI_INTERACTIVE_ELEMENTS_MAP.md |
| AC-092 | Appointment CRUD via /api/appointments/* endpoints | [EXPLICIT] | AGREED (HUBCAL-003 = AC-R071) | Both: CARRY_FORWARD_MANIFEST.md; UI_INTERACTIVE_ELEMENTS_MAP.md |
| AC-093 | Appointment confirmation SMS sent to customer via TextMagic | [EXPLICIT] | AGREED (HUBCAL-004 = AC-R173) | Both: SRS Addendum v3.2 REQ-SMS-002 |
| AC-094 | Appointment status update fires notification events (fix for known P0: updateAppointment() fires zero events) | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | HUBCAL-005; known_issues.md.md line 11 |
| AC-095 | Hub activity filtered by user: staff sees own activity; org_admin sees all with color-coded key | [EXPLICIT] | AGREED (HUBCAL-006 = AC-R182) | Both: ===DevDesign Notes===.md lines 92-93 |
| AC-096 | Org admin/partner admin can filter Hub by specific user | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | HUBCAL-007; ===DevDesign Notes===.md lines 93-94 |
| AC-097 | Google Calendar integration: appointments push to connected Google Calendar | [INFERRED] | AGREED (HUBCAL-008 = AC-R073) | Both: CARRY_FORWARD_MANIFEST.md; MASTER_SRS.md 6.6 |
| AC-R072 | Appointment creation triggers lead insertion to VIN Solutions with appointment note | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R072; Acceptance Criteria.md item 3; session-knowledge.md 0c item 3 |
| AC-R074 | Appointment drag-and-drop reschedule | [INFERRED] | [REVIEWER addition] [INFERRED] | AC-R074; UI_INTERACTIVE_ELEMENTS_MAP.md |

**Unified Count: 10**

---

### 7. Hub - Leads

| AC ID | Statement | Tag | Agreement | Sources |
|-------|-----------|-----|-----------|---------|
| AC-100 | Leads list view with text, call, schedule buttons per lead | [EXPLICIT] | AGREED (HUBLEAD-001 = AC-R080) | Both: ===DevDesign Notes===.md line 196 |
| AC-101 | Lead follow-up trigger: new lead > 2h without contact triggers outbound call/SMS | [EXPLICIT] | AGREED (HUBLEAD-002 = AC-R083, though Reviewer specifies 5 min not 2h) | Analyst: Acceptance Criteria.md item 10; Reviewer: Acceptance Criteria.md item 10 **NOTE: Time threshold differs -- Analyst says 2h, Reviewer says 5 min. Owner decision needed.** |
| AC-102 | Lead insertion to VIN Solutions from VAPI/Tavus via sync_queue | [EXPLICIT] | AGREED (HUBLEAD-003 = AC-R084) | Both: Acceptance Criteria.md; MASTER_SRS.md AC-004 |
| AC-103 | Mark lead as contacted via PATCH /api/leads/:id/mark-contacted | [EXPLICIT] | AGREED (HUBLEAD-004 = AC-R081) | Both: CARRY_FORWARD_MANIFEST.md; Reviewer adds VIN CRM sync |
| AC-104 | Lead status update via PUT /api/leads/:id/status | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | HUBLEAD-005; CARRY_FORWARD_MANIFEST.md |
| AC-105 | VIN-sourced lead data accuracy: displayed fields match VIN API response exactly | [EXPLICIT] | AGREED (HUBLEAD-006 = AC-R166) | Both: MASTER_SRS.md AC-005 |
| AC-R082 | Lead detail modal: clicking lead ID opens full information modal | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R082; Insights Layout.md; UI_INTERACTIVE_ELEMENTS_MAP.md |
| AC-R085 | Lead duplicate detection: check phone/email before creating new VIN lead | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R085; MASTER_SRS.md AC-004, Section 7.3 |

**Owner Attention:** AC-101 has a time threshold conflict. Analyst extracted "lead age > 2h, no contact" while Reviewer extracted "not addressed within 5 minutes." Both cite Acceptance Criteria.md item 10. Owner must clarify the correct threshold.

**Unified Count: 8**

---

### 8. Hub - Inbox

| AC ID | Statement | Tag | Agreement | Sources |
|-------|-----------|-----|-----------|---------|
| AC-110 | Unified messaging inbox shows all threads: widget chats, SMS, callbacks | [EXPLICIT] | AGREED (HUBINBOX-001 = AC-R091) | Both: SRS Addendum v3.2; ===DevDesign Notes===.md |
| AC-111 | Two-way text messaging: staff sends SMS via TextMagic, customer replies appear in inbox | [EXPLICIT] | AGREED (HUBINBOX-002 = AC-R092) | Both: Acceptance Criteria.md item 6; MASTER_SRS.md AC-012 |
| AC-112 | New Message modal with SMS and Email options | [EXPLICIT] | AGREED (HUBINBOX-003 = AC-R096) | Both: ===DevDesign Notes===.md line 194 |
| AC-113 | Conversation assignment: admin assigns to staff, conversation moves to staff's view | [EXPLICIT] | AGREED (HUBINBOX-004, Reviewer implicit in AC-R091) | Analyst: CARRY_FORWARD_MANIFEST.md; SRS Addendum v3.2 |
| AC-114 | Conversation status tracking (open, in_progress, closed) with working filters | [EXPLICIT] | AGREED (HUBINBOX-005, Reviewer implicit in AC-R091) | Analyst: CARRY_FORWARD_MANIFEST.md; SRS Addendum v3.2 |
| AC-115 | Unread count badge on Inbox tab | [EXPLICIT] | AGREED (HUBINBOX-006, Reviewer implicit in inbox design) | Analyst: CARRY_FORWARD_MANIFEST.md |
| AC-116 | Staff can send SMS from Inbox via TextMagic API | [EXPLICIT] | [ANALYST addition] [EXPLICIT] (more specific than HUBINBOX-002) | HUBINBOX-007; SRS Addendum v3.2 REQ-STAFF-MSG-002 |
| AC-117 | External agent conversations continued by staff with full conversation history | [INFERRED] | AGREED (HUBINBOX-008 = AC-R095) | Both: session-knowledge.md; app_identity.md B5 |
| AC-R093 | SMS after-hours AI response: inbound SMS after hours gets AI response via Claude API (not VAPI) | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R093; MASTER_SRS.md AC-012; IMPLEMENTATION_PLAN.md Phase 5 |
| AC-R094 | SMS human takeover: when staff sends manual reply, AI responses stop (HUMAN_ACTIVE state) | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R094; MASTER_SRS.md AC-012; IMPLEMENTATION_PLAN.md 5.3 |
| AC-R097 | Email in Inbox: IMAP/SMTP integration, rich-text compose for email | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R097; ACCEPTANCE_VERIFICATION_REPORT.md AC-3; CLARIFICATION_ANSWERS.md Q12 |

**Unified Count: 11**

---

### 9. Widgets

| AC ID | Statement | Tag | Agreement | Sources |
|-------|-----------|-----|-----------|---------|
| AC-120 | Master widget with 6 communication options: Text Chat, Web Video Agent, Call Us, Call You, Web Audio, Send a Text | [EXPLICIT] | AGREED (WIDGET-001 = AC-R100) | Both: SRS Addendum v3.2 REQ-WIDGET-001 |
| AC-121 | Widget configuration UI in Settings > Tools & Integrations > Widgets with appearance, channels, targeting, embed code | [EXPLICIT] | AGREED (WIDGET-002 = AC-R101 + AC-R147) | Both: SRS Addendum v3.2; DESIGNER_UPDATE_SPEC.md |
| AC-122 | Hosted widget pages at /hosted/{orgSlug}/{widgetCode}/[chat|video|callback] | [EXPLICIT] | AGREED (WIDGET-003 = AC-R102) | Both: SRS Addendum v3.2 REQ-HOSTED-001; Acceptance Criteria.md item 5 |
| AC-123 | Hosted pages route match: client and server routes must align (known P0 fix) | [EXPLICIT] | AGREED (WIDGET-004, Reviewer covers in AC-R102 with session-knowledge ref) | Both: known_issues.md.md; session-knowledge.md Section 5 |
| AC-124 | Widget demo shows working widget that loads within 1.5s with all enabled channels functional | [EXPLICIT] | AGREED (WIDGET-005 = AC-R105) | Both: Acceptance Criteria.md item 5; MASTER_SRS.md 11.1 |
| AC-125 | Domain restrictions: widget does not render on unauthorized domains | [EXPLICIT] | AGREED (WIDGET-006 = AC-R104) | Both: SRS Addendum v3.2; MASTER_SRS.md 11.2 |
| AC-126 | Widget load time under 1.5 seconds | [EXPLICIT] | AGREED (WIDGET-007 = AC-R105) | Both: MASTER_SRS.md 11.1 |
| AC-R101 | Widget channel enable/disable per org individually | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R101; SRS Addendum v3.2 2.1; CLARIFICATION_ANSWERS.md Q7 |
| AC-R103 | 3 deployment modes: unified widget (corner), embed code (customer site), hosted landing page | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R103; Acceptance Criteria.md item 5; session-knowledge.md 0c item 6 |
| AC-R106 | Widget chat AI response within 5 seconds | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R106; MASTER_SRS.md AC-017 |
| AC-R107 | Widget UI contains zero vendor names | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] (extends AC-016 to widget specifically) | AC-R107; MASTER_SRS.md AC-017; CONSTITUTION.md 3.1 |
| AC-R108 | Widget responsive: functions on mobile, tablet, desktop | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R108; MASTER_SRS.md AC-017 |
| AC-R109 | Inbound calls from widget ("Call Us" / "Web Audio") connect to configured VAPI assistant | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R109; Acceptance Criteria.md item 11 |
| AC-R110 | Outbound call from widget: "Call You" triggers VAPI outbound call to customer | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R110; Acceptance Criteria.md item 5a; SRS Addendum v3.2 2.6 |

**Unified Count: 14**

---

### 10. Triggers

| AC ID | Statement | Tag | Agreement | Sources |
|-------|-----------|-----|-----------|---------|
| AC-130 | Automatic outbound call triggering when conditions met (new lead, hot lead, missed call) | [EXPLICIT] | AGREED (TRIGGER-001 = AC-R120 broadly) | Both: Acceptance Criteria.md item 1; MASTER_SRS.md AC-013 |
| AC-131 | Trigger CRUD via /api/triggers/* endpoints | [EXPLICIT] | AGREED (TRIGGER-002, subset of AC-R120) | Both: CARRY_FORWARD_MANIFEST.md; DO_NOT_TOUCH.md |
| AC-132 | Trigger deduplication: only one action per lead within time window | [EXPLICIT] | AGREED (TRIGGER-003 = AC-R122) | Both: session-knowledge.md; ACCEPTANCE_VERIFICATION_REPORT.md AC-11 |
| AC-133 | Business hours enforcement: triggers with business_hours_only defer outside hours | [EXPLICIT] | AGREED (TRIGGER-004 = AC-R123) | Both: SRS Addendum v3.2 REQ-TRIGGER-001 |
| AC-134 | Global enable/disable toggle (Super Admin) for all triggers across all orgs | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | TRIGGER-005; SRS Addendum v3.2 REQ-TRIGGER-001 line 606 |
| AC-135 | Trigger notification delivered within 60 seconds of trigger event | [EXPLICIT] | AGREED (TRIGGER-006 = AC-R124) | Both: MASTER_SRS.md 11.1 |
| AC-136 | All 15 existing trigger rules currently deactivated (status=inactive) | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | TRIGGER-007; REVERSE_SRS_old.md line 37 |
| AC-R121 | 5 trigger action types: outbound_call, send_sms, send_email, create_task, webhook | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R121; MASTER_SRS.md 5.10; ACCEPTANCE_VERIFICATION_REPORT.md AC-11 |
| AC-R125 | Triggers associated with an agent visible in agent's right pane | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R125; ===DevDesign Notes===.md line 188 |

**Unified Count: 9**

---

### 11. Drive

| AC ID | Statement | Tag | Agreement | Sources |
|-------|-----------|-----|-----------|---------|
| AC-140 | File management CRUD: create folders, upload files, rename, delete via /api/drive/* | [EXPLICIT] | AGREED (DRIVE-001 = AC-R131 + AC-R130) | Both: CARRY_FORWARD_MANIFEST.md; ===DevDesign Notes===.md |
| AC-141 | Share files via email or SMS | [EXPLICIT] | AGREED (DRIVE-002 = AC-R133) | Both: ===DevDesign Notes===.md lines 98, 201-203 |
| AC-142 | Storage usage display for organization | [INFERRED] | [ANALYST addition] [INFERRED] | DRIVE-003; CARRY_FORWARD_MANIFEST.md |
| AC-R130 | Drive personal and shared folders (two spaces) | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R130; MASTER_SRS.md 5.4; app_identity.md B3 |
| AC-R131 | Drive grid/list view toggle | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R131; UI_INTERACTIVE_ELEMENTS_MAP.md |
| AC-R132 | Artifacts created in Automa chat auto-saved to user's Drive | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R132; app_identity.md B3; MASTER_SRS.md 5.4 |

**Unified Count: 6**

---

### 12. Settings

| AC ID | Statement | Tag | Agreement | Sources |
|-------|-----------|-----|-----------|---------|
| AC-150 | 9 settings tile categories displayed | [EXPLICIT] | AGREED (SETTINGS-001 = AC-R140) | Both: DESIGNER_UPDATE_SPEC.md; ===DevDesign Notes===.md |
| AC-151 | RBAC visibility on settings tiles: Super Admin all 9, Partner Admin subset, Org Admin subset, Staff sees none | [EXPLICIT] | AGREED (SETTINGS-002 = AC-R141) | Both: DESIGNER_UPDATE_SPEC.md RBAC matrix |
| AC-152 | Tools & Integrations: 5 tabs (MCP, API, Other, Widgets, Landing Pages) + 2 for Super Admin (API Keys, Webhooks) | [EXPLICIT] | AGREED (SETTINGS-003 = AC-R143) | Both: DESIGNER_UPDATE_SPEC.md |
| AC-153 | AI Configuration: 4 tabs (System Prompt, Agent Behavior, Skills, Hunches) | [EXPLICIT] | AGREED (SETTINGS-004 = AC-R145) | Both: DESIGNER_UPDATE_SPEC.md |
| AC-154 | Knowledge Base: 4 tabs (Documents, Web Pages, Databases, Settings) | [EXPLICIT] | AGREED (SETTINGS-005, Reviewer MISSING-W4-2 notes gap) | Analyst: DESIGNER_UPDATE_SPEC.md |
| AC-155 | Billing page with subscription tiers, usage meters, invoice info | [EXPLICIT] | AGREED (SETTINGS-006, Reviewer WATCH-2) | Both: DESIGNER_UPDATE_SPEC.md Billing section |
| AC-156 | Users CRUD: org_admin can add/remove users within current org | [EXPLICIT] | AGREED (SETTINGS-007 = AC-R142) | Both: ===DevDesign Notes===.md; CARRY_FORWARD_MANIFEST.md |
| AC-157 | Org Creation Wizard for Super Admin | [EXPLICIT] | AGREED (SETTINGS-008 = AC-R149) | Both: DESIGNER_UPDATE_SPEC.md |
| AC-158 | Economy/billing rate on tool cards | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | SETTINGS-009; DESIGNER_UPDATE_SPEC.md Economy section |
| AC-159 | Data Management: 2 tabs (Database Uploads, Data Health) | [EXPLICIT] | AGREED (SETTINGS-010, Reviewer MISSING-W4-3 notes gap) | Analyst: DESIGNER_UPDATE_SPEC.md |
| AC-R144 | Integration test connection button with success/failure feedback | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R144; UI_INTERACTIVE_ELEMENTS_MAP.md |
| AC-R146 | Emergency kill switch: disables ALL agent activity for ALL users/orgs with confirmation dialog | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] (Analyst had AGENTS-010 but less detailed) | AC-R146; DESIGNER_UPDATE_SPEC.md Section 6 Tab 3 |
| AC-R147 | Widget configuration with live preview that updates in real-time | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R147; SRS Addendum v3.2; DESIGNER_UPDATE_SPEC.md Tab 4 |
| AC-R148 | Agent instructions from Settings: agents parse and apply custom instructions | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] (more specific than AGENTS-007) | AC-R148; Acceptance Criteria.md item 13 |
| AC-R150 | Lead assignment configurable in Settings (not hardcoded). Default: Dustin Herman | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R150; MASTER_SRS.md 5.8, AC-014; CONSTITUTION.md 5 |

**Unified Count: 15**

---

### 13. Metrics & Scores

| AC ID | Statement | Tag | Agreement | Sources |
|-------|-----------|-----|-----------|---------|
| AC-160 | Main page org_admin: 4 tiles (Pipeline Health, Lead Source Performance, Lead Quality, Market Demand Insight) scored 0-100 | [EXPLICIT] | AGREED (METRICS-001 = AC-R043) | Both: Org admin Metrics.md; ===DevDesign Notes===.md |
| AC-161 | Main page staff: 4 tiles (Hot Opportunities, Buying Intelligence, Competitive Threats, Pipeline Urgency) | [EXPLICIT] | AGREED (METRICS-002 = AC-R163) | Both: Staff Metrics.md; ===DevDesign Notes===.md |
| AC-162 | Main page partner admin: 4 tiles (# sub-orgs, # customer logins 24h, # actions taken 24h, # agent actions 24h) | [EXPLICIT] | AGREED (METRICS-003 = AC-R164) | Both: ===DevDesign Notes===.md lines 138-144 |
| AC-163 | Pipeline Health Score formula: (0.3 * lead_volume_trend) + (0.25 * conversion_rate) + (0.25 * avg_response_time_score) + (0.2 * pipeline_stage_distribution_score) | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | METRICS-004; Org admin Metrics.md |
| AC-164 | Certified Metrics Registry at /api/metrics/registry with role-based filtering | [EXPLICIT] | AGREED (METRICS-005 ~ AC-R165) | Both: MASTER_SRS.md AC-007; CARRY_FORWARD_MANIFEST.md |
| AC-165 | Metrics accuracy within 2% of ground truth | [EXPLICIT] | AGREED (METRICS-006 = AC-R047, also AC-R166) | Both: MASTER_SRS.md AC-007; CLARIFICATION_ANSWERS.md |
| AC-166 | Field fill rate >50% for all certified metrics | [EXPLICIT] | AGREED (METRICS-007 ~ AC-R165) | Both: MASTER_SRS.md AC-005 |
| AC-167 | Staff tile modal drill-down with detailed breakdown per metrics formula | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | METRICS-008; Staff Metrics.md |
| AC-R160 | Org admin minimum 10 certified metrics covering pipeline, team, AI activity | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R160; MASTER_SRS.md 8.4, AC-007 |
| AC-R161 | Org staff minimum 5 certified personal metrics | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R161; MASTER_SRS.md 8.4, AC-009 |
| AC-R162 | Partner admin minimum 5 certified aggregate metrics (no individual PII) | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R162; MASTER_SRS.md 8.4, AC-010 |
| AC-R167 | Agent performance_metrics JSONB auto-updated after VAPI/Tavus webhook | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R167; MASTER_SRS.md AC-013; IMPLEMENTATION_PLAN.md 3.1 |

**Unified Count: 12**

---

### 14. Notifications

| AC ID | Statement | Tag | Agreement | Sources |
|-------|-----------|-----|-----------|---------|
| AC-170 | In-app notification list with read/unread status via notification bell | [EXPLICIT] | AGREED (NOTIF-001 = AC-R172) | Both: CARRY_FORWARD_MANIFEST.md; UI_INTERACTIVE_ELEMENTS_MAP.md |
| AC-171 | Notifications from Hunches: new hunch generates visible notification | [EXPLICIT] | AGREED (NOTIF-002 = AC-R174) | Both: ===DevDesign Notes===.md line 123 |
| AC-172 | Notification settings CRUD: toggle notification types on/off | [EXPLICIT] | AGREED (NOTIF-003, Reviewer implicit) | Analyst: CARRY_FORWARD_MANIFEST.md |
| AC-173 | Unread count polling at 30-second interval | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | NOTIF-004; CARRY_FORWARD_MANIFEST.md; UNIFIED_HANDOFF_PROMPT.md line 245 |
| AC-174 | Email notification on VAPI call complete (webhook-triggered) | [EXPLICIT] | AGREED (NOTIF-005 = AC-R170) | Both: MASTER_SRS.md 7.3; session-knowledge.md (live production feature) |
| AC-175 | Mark All as Read via PUT /api/notifications/read-all | [EXPLICIT] | AGREED (NOTIF-006, Reviewer implicit) | Analyst: CARRY_FORWARD_MANIFEST.md |
| AC-R171 | In-app notification on lead assignment: assignee receives SMS and email | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R171; MASTER_SRS.md AC-014 |
| AC-R175 | Notification delivery from triggers within 60 seconds | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] (overlaps with TRIGGER AC-135) | AC-R175; MASTER_SRS.md AC-013, 11.1 |

**Unified Count: 8**

---

### 15. Activity & Governance

| AC ID | Statement | Tag | Agreement | Sources |
|-------|-----------|-----|-----------|---------|
| AC-180 | AI usage event logging: tokens, tool calls, cost logged per AI interaction | [EXPLICIT] | AGREED (GOVERN-001 = AC-R180) | Both: CARRY_FORWARD_MANIFEST.md; DO_NOT_TOUCH.md |
| AC-181 | Activity feed display within Insights: recent AI usage events with action type, description, timestamp | [EXPLICIT] | AGREED (GOVERN-002 = AC-R180) | Both: CARRY_FORWARD_MANIFEST.md; ===DevDesign Notes===.md line 128 |
| AC-182 | Credit balance tracking: deducted on AI-billable actions, updates in real time | [EXPLICIT] | AGREED (GOVERN-003, Reviewer WATCH-2 notes billing gap) | Analyst: CARRY_FORWARD_MANIFEST.md; DO_NOT_TOUCH.md |
| AC-183 | Approval workflow: approve or reject with comments via /api/approvals/:id/resolve | [EXPLICIT] | [ANALYST addition] [EXPLICIT] | GOVERN-004; CARRY_FORWARD_MANIFEST.md |
| AC-184 | Artifacts associated with source conversation | [EXPLICIT] | AGREED (GOVERN-005 ~ AC-R132) | Analyst: CARRY_FORWARD_MANIFEST.md |
| AC-R181 | Activity feed CSV export with columns: timestamp, user, action, target, details | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R181; IMPLEMENTATION_PLAN.md 7.1; MASTER_SRS.md 5.7 |
| AC-R183 | Quality gates pass before deployment: npm run check, npm run build, npx playwright test -- zero errors | [EXPLICIT] | [REVIEWER addition] [EXPLICIT] | AC-R183; MASTER_SRS.md AC-019; CONSTITUTION.md 3.4 |

**Unified Count: 7**

---

## RECONCILED WATCH AREAS

Both agents identified 5 watch areas. They are merged here with findings from both.

### Watch Area 1: Agent Functionality / Defaults

| # | Finding | Risk | Analyst | Reviewer | Agreement |
|---|---------|------|---------|----------|-----------|
| W1-1 | Skills architecture (V2 model) was never documented in any AC file the agent reads | HIGH | W1-1 | WATCH-1 | AGREED -- both flagged |
| W1-2 | V1 had 27 hardcoded agents; V2 replaces with user-created agents + skills catalog (74 pre-built) | HIGH | W1-2 | WATCH-1 | AGREED |
| W1-3 | Communications Agent is static, configured by Super Admin only | MEDIUM | W1-3 | WATCH-1 | AGREED |
| W1-4 | Agent tools exist at widget level (7 system tools), not per-agent | MEDIUM | W1-4 | Not flagged | ANALYST-ONLY |
| W1-5 | CONFLICT: Automa on Agents page (MASTER_SRS yes, DevDesign Notes no) | HIGH | Covered in CONFLICT-06 | WATCH-1 / CONFLICT-W4-2 | AGREED |
| W1-6 | No AC describes default communications agent configuration or what happens if absent | MEDIUM | Not flagged | WATCH-1 | REVIEWER-ONLY |

### Watch Area 2: Billing

| # | Finding | Risk | Analyst | Reviewer | Agreement |
|---|---------|------|---------|----------|-----------|
| W2-1 | Billing page is NEW feature with no testable AC | HIGH | W2-1 | WATCH-2 | AGREED |
| W2-2 | Economy section on tool cards has no AC for rate calculations | MEDIUM | W2-2 | WATCH-2 | AGREED |
| W2-3 | Credit service wired but no AC for displaying balance to users | MEDIUM | W2-3 | WATCH-2 | AGREED |
| W2-4 | Credits page intentionally deferred in codebase (App.tsx:106-114) | MEDIUM | Not flagged | WATCH-2 | REVIEWER-ONLY |
| W2-5 | Pricing rates documented: Voice $0.25/min, Video $0.32/min, SMS $0.05/msg | INFO | Not flagged | WATCH-2 | REVIEWER-ONLY |

### Watch Area 3: Unified Inbox Handoff

| # | Finding | Risk | Analyst | Reviewer | Agreement |
|---|---------|------|---------|----------|-----------|
| W3-1 | External agent conversation continuity by staff has no formal AC | HIGH | W3-1 | WATCH-3 | AGREED |
| W3-2 | Email integration exists but "missing from interface" per owner | HIGH | W3-2 | WATCH-3 (covered in AC-R097) | AGREED -- Reviewer wrote AC for it |
| W3-3 | Canned responses mentioned in SRS Addendum but not in AC | LOW | W3-3 | Not flagged | ANALYST-ONLY |
| W3-4 | Conversation state machine (DORMANT -> AI_ACTIVE -> HUMAN_ACTIVE) needs AC | MEDIUM | Not flagged | WATCH-3 | REVIEWER-ONLY |
| W3-5 | Human takeover stops AI responses -- no AC in Analyst | MEDIUM | Not flagged | Covered in AC-R094 | REVIEWER wrote AC |

### Watch Area 4: Super Admin Exclusive Capabilities

| # | Finding | Risk | Analyst | Reviewer | Agreement |
|---|---------|------|---------|----------|-----------|
| W4-1 | Org Creation Wizard: new feature with design spec but minimal AC | MEDIUM | W4-1 | WATCH-4 | AGREED |
| W4-2 | Super Admin "Nexxus System" view: mentioned once, no AC for what it shows | MEDIUM | W4-2 | WATCH-4 | AGREED |
| W4-3 | Emergency kill switch: no AC for behavior when activated | HIGH | W4-3 | WATCH-4 (Reviewer wrote AC-R146) | Reviewer RESOLVED with AC-R146 |
| W4-4 | No dedicated AC tests full super_admin E2E experience | MEDIUM | Not flagged | WATCH-4 | REVIEWER-ONLY |

### Watch Area 5: Context Router

| # | Finding | Risk | Analyst | Reviewer | Agreement |
|---|---------|------|---------|----------|-----------|
| W5-1 | Truth hierarchy (VIN > VAPI/Tavus > Local > Derived) has no AC to test ordering | HIGH | W5-1 | WATCH-5 | AGREED |
| W5-2 | Context Router UI should have 3 sections per owner; no AC | MEDIUM | W5-2 | WATCH-5 | AGREED |
| W5-3 | VIN API graceful degradation (17 of 30 endpoints return 403) has no explicit AC | HIGH | W5-3 | WATCH-5 | AGREED |
| W5-4 | Data freshness: VIN 5 min cache, VAPI/Tavus 1 hour -- no user-facing AC | LOW | Not flagged | WATCH-5 | REVIEWER-ONLY |
| W5-5 | excel_upload exclusion: 32+ queries across 11 files | MEDIUM | Not flagged | WATCH-5 | REVIEWER-ONLY (Analyst covered as INSIGHTS-011) |

---

## RECONCILED CONFLICTS

Both agents identified conflicts. Merged below with resolution consensus.

### CONFLICT-R01: Sidebar Navigation Order
- **Analyst CONFLICT-05 / Reviewer CONFLICT-W4-1**
- DevDesign Notes: Main, Insights, Agents, Hub, Drive
- MASTER_SRS.md: Main, Agents, Drive, Insights, Hub, Activity, Settings
- ARCHITECTURE_GUIDE: Main, Agents, Drive, Insights, Work Center, Activity, Settings, Profile
- **Status:** AGREED this is a conflict. OWNER DECISION NEEDED.

### CONFLICT-R02: Hub Tab Count
- **Analyst CONFLICT-01 / Reviewer CONFLICT-W4-3**
- Older docs: 4+ tabs (Calendar, Leads, Inbox, Tasks, Approvals, Messages)
- DESIGNER_UPDATE_SPEC (marked "final"): exactly 3 tabs (Calendar, Leads, Inbox)
- **Resolution:** Both agents agree: **3 tabs**. DESIGNER_UPDATE_SPEC is authoritative.

### CONFLICT-R03: VIN Write-Back Scope
- **Analyst CONFLICT-02 / Reviewer implicit in AC-R084**
- MASTER_SRS implies general write; Addendum v3.1 says "no write-back"; CLARIFICATION_ANSWERS says "leads only"
- **Resolution:** Both agents agree: **Lead creation only** (2-step: create contact, then create lead). No other writes.

### CONFLICT-R04: Settings Tile Count
- **Analyst CONFLICT-03 / Reviewer AC-R140**
- Some docs say 10; DESIGNER_UPDATE_SPEC says 9 (API & Webhooks moved inside Tools & Integrations)
- **Resolution:** Both agents agree: **9 tiles**.

### CONFLICT-R05: Goals Feature
- **Analyst CONFLICT-04 / Reviewer CONFLICT-W4-4**
- MASTER_SRS includes Goals; DevDesign Notes says "Goals - Remove"
- **Resolution:** Both agents agree: **Goals removed from Insights UI**. Backend may persist but no UI rendering.

### CONFLICT-R06: Activity Feed Location
- **Analyst CONFLICT-05 / Reviewer CONFLICT-W4-5**
- Some docs: standalone sidebar item. DevDesign Notes: sub-tab in Insights.
- **Resolution:** Both agents agree: **Activity is inside Insights as a sub-tab**.

### CONFLICT-R07: DealerBrain vs Automa Naming
- **Analyst CONFLICT-06**
- Backend references "DealerBrain"; UI must show "Automa" only.
- **Resolution:** Both agents agree: **"Automa" in all user-facing surfaces**.

### CONFLICT-R08: VIN Integration Model
- **Analyst CONFLICT-07**
- Query-driven with caching. No bidirectional sync. Lead creation is only write.
- **Resolution:** AGREED.

### CONFLICT-R09: AC File Authority
- **Analyst CONFLICT-08**
- Three AC files exist with different content. Owner's preflight-input version is latest intent.
- **Resolution:** AGREED -- this surgery's output must produce ONE authoritative AC file.

### CONFLICT-R10: Hosted Pages URL Pattern
- **Analyst CONFLICT-09 / Reviewer references in AC-R102**
- Client fetches /api/hosted-pages/public/:slug; server serves /api/pages/:slug.
- **Resolution:** AGREED -- known P0, one-line fix. AC should test the corrected route.

### CONFLICT-R11: TextMagic Credential Storage
- **Analyst CONFLICT-10**
- Per-org in database (textmagic_config table), not in .env.
- **Resolution:** AGREED -- AC should specify per-org DB storage with encrypted API key.

### CONFLICT-R12: Email in Hub
- **Analyst CONFLICT-11 / Reviewer AC-R097**
- DevDesign Notes mentions email; CLARIFICATION_ANSWERS says "email missing from interface."
- **Resolution:** Backend hooks exist. Reviewer wrote AC-R097 for it. **Flag as partially implemented -- OWNER DECISION on MVP scope.**

### CONFLICT-R13: Report Upload vs Data Uploads
- **Analyst CONFLICT-12**
- VIN report upload via Drive vs. Data Uploads under Settings > Data Management.
- **Resolution:** AGREED -- Settings > Data Management is primary path.

### CONFLICT-R14: Automa on Agents Page
- **Reviewer CONFLICT-W4-2**
- MASTER_SRS says "always at top"; DevDesign Notes says "not listed anymore."
- **Resolution:** Both agents used DevDesign Notes resolution (NOT on Agents page). **OWNER DECISION NEEDED** to confirm DevDesign Notes overrides MASTER_SRS here.

### CONFLICT-R15: Insights Sub-Sections (Dealer Pulse)
- **Reviewer CONFLICT-W4-6**
- MASTER_SRS lists Dealer Pulse; DevDesign Notes/Insights Layout does not.
- **Resolution:** Reviewer-only flag. **OWNER DECISION NEEDED** on Dealer Pulse placement.

---

## MERGED MISSING AC AREAS

Both agents identified areas where no testable AC exists despite features being specified. Merged and deduplicated below.

| # | Missing AC Area | Analyst | Reviewer | Risk | Owner Action |
|---|----------------|---------|----------|------|-------------|
| M-01 | Billing page UI acceptance criteria | MISSING-01 | MISSING-W4-1 | HIGH | Write AC for billing page (DESIGNER_UPDATE_SPEC.md Section 11) |
| M-02 | Profile page CRUD | MISSING-02 | MISSING-W4-4 | LOW | Write AC for profile view/edit |
| M-03 | Password reset E2E flow (email + reset form) | MISSING-03 | Not flagged | MEDIUM | Write AC for forgot-password to reset-password |
| M-04 | Tracking pixel / UTM capture behavior | MISSING-04 | Not flagged | MEDIUM | Write AC for attribution tracking (SRS Addendum v3.2) |
| M-05 | Knowledge Base upload/management | MISSING-05 | MISSING-W4-2 | MEDIUM | Write AC for KB document upload and indexing |
| M-06 | Email integration full flow (IMAP/SMTP in Hub) | MISSING-06 | Partially covered by AC-R097 | HIGH | Decide MVP scope; if in, expand AC-R097 |
| M-07 | Drive sharing flow (email/SMS) | MISSING-07 | Not flagged | MEDIUM | Write AC for share action |
| M-08 | Reporting PDF export | MISSING-08 | Not flagged | MEDIUM | Write AC for report generation and download |
| M-09 | VIN API graceful degradation (403 handling) | MISSING-09 | WATCH-5 | HIGH | Write AC for fallback behavior when VIN returns 403 |
| M-10 | Context Router UI in Settings (3 sections) | MISSING-10 | WATCH-5 | MEDIUM | Write AC for Context Router settings UI |
| M-11 | SMS opt-out compliance (STOP keyword, opt-out confirmation) | MISSING-11 | Not flagged | HIGH | Write AC for compliance (SRS Addendum v3.2 lines 699-706) |
| M-12 | Data Health Dashboard | MISSING-12 | MISSING-W4-3 | MEDIUM | Write AC for Data Management tile |
| M-13 | Emergency kill switch behavior specification | MISSING-13 | Partially covered by AC-R146 | HIGH | Expand AC-R146 with post-activation behavior |
| M-14 | Dealer Pulse feature | MISSING-14 | Not flagged | LOW | Decide if in MVP; if yes, write AC |
| M-15 | Tour system with RBAC | Not flagged | MISSING-W4-5 | MEDIUM | Write AC for product tour |
| M-16 | Communications Agent default behavior | Not flagged | MISSING-W4-6 | MEDIUM | Write AC for default comms agent config |
| M-17 | After-hours voice routing | Not flagged | MISSING-W4-7 | MEDIUM | Write AC for voice after-hours (SMS covered in AC-R093) |
| M-18 | Hunch lifecycle management | Not flagged | MISSING-W4-8 | LOW | Write AC for hunch state transitions |
| M-19 | Embed code copy action | Not flagged | MISSING-W4-9 | LOW | Write AC for copy-embed-code |
| M-20 | Search / Command Palette (Cmd+K) | Not flagged | MISSING-W4-10 | LOW | Decide if in MVP; if yes, write AC |

---

## OWNER ACTION ITEMS SUMMARY

### Decisions Required (Cannot proceed without owner input)

| # | Decision | Priority | Context |
|---|----------|----------|---------|
| D-1 | **Sidebar navigation order** -- which source is canonical? DevDesign Notes, MASTER_SRS, or ARCHITECTURE_GUIDE? | HIGH | DISAGREE-1, CONFLICT-R01 |
| D-2 | **Automa on Agents page** -- listed or not? MASTER_SRS says yes, DevDesign Notes says no. | HIGH | CONFLICT-R14 |
| D-3 | **Lead follow-up trigger threshold** -- 2 hours or 5 minutes? Both agents cite Acceptance Criteria.md item 10. | HIGH | AC-101 |
| D-4 | **Email in Hub MVP scope** -- is email in Inbox part of MVP or deferred? Backend exists but owner says "missing from interface." | HIGH | CONFLICT-R12, M-06 |
| D-5 | **Dealer Pulse placement** -- in Insights, standalone, or deferred? MASTER_SRS includes it, DevDesign Notes omits it. | MEDIUM | CONFLICT-R15 |
| D-6 | **Activity location** -- both agents agree it moved to Insights sub-tab per DevDesign Notes. Confirm this overrides MASTER_SRS. | MEDIUM | CONFLICT-R06 |
| D-7 | **Goals removal** -- both agents agree it is removed per DevDesign Notes. Confirm this overrides MASTER_SRS. | LOW | CONFLICT-R05 |

### AC Items to Write (Missing coverage for specified features)

| Priority | Items | Count |
|----------|-------|-------|
| HIGH | M-01 (Billing), M-06 (Email), M-09 (VIN 403 handling), M-11 (SMS compliance), M-13 (Kill switch behavior) | 5 |
| MEDIUM | M-03 (Password reset), M-04 (Tracking pixel), M-05 (Knowledge Base), M-07 (Drive sharing), M-08 (PDF export), M-10 (Context Router UI), M-12 (Data Health), M-15 (Tour), M-16 (Comms Agent default), M-17 (Voice after-hours) | 10 |
| LOW | M-02 (Profile), M-14 (Dealer Pulse), M-18 (Hunch lifecycle), M-19 (Embed copy), M-20 (Search/Cmd+K) | 5 |

### Confirmations Needed (Both agents agree, but owner should ratify)

1. Hub has exactly 3 tabs (Calendar, Leads, Inbox) -- CONFLICT-R02
2. Settings has 9 tiles (not 10) -- CONFLICT-R04
3. UI shows "Automa" only, never "DealerBrain" -- CONFLICT-R07
4. VIN write-back is lead creation only -- CONFLICT-R03
5. Hosted pages route fix is the one-line P0 -- CONFLICT-R10
6. TextMagic credentials stored per-org in DB, not .env -- CONFLICT-R11

---

## FINAL STATISTICS

| Metric | Value |
|--------|-------|
| Total reconciled AC items | 151 |
| Items in agreement (both agents) | 85 |
| Analyst-only additions | 30 |
| Reviewer-only additions | 33 |
| Disagreements requiring owner decision | 1 (+ 6 conflict confirmations) |
| Explicit items | 141 |
| Inferred items | 10 |
| Testable by Playwright | ~125 |
| Testable manually only | ~26 |
| Conflicts reconciled | 15 |
| Missing AC areas identified | 20 |
| Watch area findings merged | 25 |
| Owner decisions required | 7 |
| AC items to write from missing areas | 20 |

---

## SOURCE CITATION LEGEND

Both agents cited source files by filename. The full paths are:
- Files in `preflight-input/`: `/home/ubuntu/Claude-store/Nexxus_workbench/preflight-input/`
- Files in `preflight-input/other_notes/`: `/home/ubuntu/Claude-store/Nexxus_workbench/preflight-input/other_notes/`
- `session-knowledge.md`: `/home/ubuntu/Claude-store/Nexxus_workbench/session-knowledge.md`
- `file-inventory.md`: `/home/ubuntu/Claude-store/Nexxus_workbench/file-inventory.md`

---

*End of Wave 4 Reconciled Output.*
*Analyst scanned 28 files, Reviewer scanned 38 files.*
*Reconciliation performed by Orchestrator on 2026-03-03.*
