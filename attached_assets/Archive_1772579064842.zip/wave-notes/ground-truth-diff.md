# Ground Truth Diff — Phase 3 Unified Results

**Date:** 2026-03-03
**Inputs:** Diff Agent A (code vs waves), Diff Agent B (claims vs waves)
**Method:** Independent parallel agents, orchestrator merge

---

## PART 1: Validated Gap List (Real Gaps With Evidence)

These are confirmed real gaps that must be tracked in the new PLAN.md.

---

### P0 Gaps (Block Payment-Critical Demo)

| ID | Gap | Evidence | Demo Impact | Fix Complexity |
|----|-----|----------|-------------|----------------|
| P0-1 | Hosted pages `/p/:slug` broken | `hosted-page-public.tsx:163` fetches wrong path; `/w/:slug` works correctly | Blocks DEMO-6 (Widgets) partially | TRIVIAL: redirect `/p/:slug` → `/w/:slug` or fix fetch URL |
| P0-2 | Insights crash risk — 5 unguarded `.pct` accesses | `insights.tsx:854,2087-2088,2136,2142-2143` — array[0] without bounds check | Blocks DEMO-1 (Metrics) conditionally | TRIVIAL: add optional chaining |
| P0-3 | Appointment status change notifications missing | `AppointmentService.ts:663-750` — `updateAppointment()` fires nothing | Blocks DEMO-3 (Appointment Flow) | MODERATE: add event emission + trigger evaluation |
| P0-4 | Zero production trigger executions | Business hours skip + `hot_lead` no call site + condition evaluates at import time (lead age = 0) | Blocks DEMO-2 (Comms Agent) and DEMO-4 (Proactive Follow-up) | MODERATE: fix condition timing, add hot_lead emission, verify business hours config |
| P0-5 | Appointment-to-VIN note link missing | `AppointmentService.ts` has no import of VinSolutionsService, no sync_queue insert | Blocks DEMO-3 (Appointment Flow) | MODERATE: add VIN sync from createAppointment |
| P0-6 | VAPI webhook ingestion | Code now has UPSERT (defensive). Owner resolved config. | Was blocking DEMO-2/4 | RESOLVED — needs live verification only |

**P0 Summary:** 5 real P0s to fix (P0-1 through P0-5). P0-6 resolved by owner. 2 are trivial fixes, 3 are moderate.

---

### P1 Gaps (Important but Don't Block Demo)

| ID | Gap | Evidence | Severity Rationale |
|----|-----|----------|-------------------|
| P1-1 | RLS variable name mismatch | `SecureQueryBuilder.ts:244` sets `app.current_organization_id`; RLS policies check `app.current_org_id` | Security architecture broken but bypassed; must fix before any refactor uses SecureQueryBuilder |
| P1-2 | `hot_lead` event type — no emission call site | Defined in `TriggerService.ts:24`, configurable in UI, but never emitted anywhere in codebase | Triggers configured for hot_lead silently never fire |
| P1-3 | `appointment_created` trigger event — no emission call site | Defined in `TriggerService.ts:25`, but no `evaluateEvent('appointment_created')` in appointments route or service | Appointment triggers never fire |
| P1-4 | `updatePerformanceMetrics()` defined but never called | `AgentService` method exists but no webhook/route calls it | Agent performance data always empty |
| P1-5 | Mark Contacted doesn't write to VIN | Local DB updated but VIN PUT endpoint never called | CRM source of truth not updated |
| P1-6 | Tavus: zero real video sessions captured | Zero V2 callback URLs configured in Tavus; 5 personas named but not wired | Video agent feature completely non-functional |
| P1-7 | 19-28% VIN lead capture gap | Polling misses leads vs VIN API count over same 7-day window | Missing leads can't be followed up |
| P1-8 | 38 unregistered VAPI assistant calls | Calls from Elliott, Andor, Gabrielle not in agents table | Calls not associated with any org |
| P1-9 | SMS after-hours AI routing not wired | Migration 032 exists, state machine exists, but routing decision point not connected | After-hours AI coverage (DEMO-5) non-functional |
| P1-10 | Hub has 6 tabs, spec says 3 | `work-center.tsx:473-506` has calendar, tasks, hunches, approvals, communication, leads | UI doesn't match owner-confirmed spec |
| P1-11 | Activity is standalone page, not Insights sub-tab | `App.tsx:109` — `/activity` renders standalone page | UI doesn't match owner-confirmed consolidation |
| P1-12 | Skills catalog has 4 seeds, not 74 | `migration 034` inserts only 4 skills | Skills selection nearly empty for users |
| P1-13 | Vendor names visible in UI | `settings.tsx:1880,1982,1995` shows "VIN Solutions"; `activity.tsx:546` shows "DealerBrain" | Violates AC-016 (no vendor names) |
| P1-14 | `idle_trigger_count` never resets | Per wave5 P1-3; needs code verification | Leads permanently stop getting follow-up after 3 attempts |
| P1-15 | VAPI webhook security is soft-check only | `vapi.ts:140` — if header missing, proceeds without auth | Any client can POST crafted payloads |

---

### P2 Gaps (Documentation/Process/Coverage)

| ID | Gap | Notes |
|----|-----|-------|
| P2-1 | 20 feature areas have no acceptance criteria | Billing UI, profile CRUD, password reset, tracking pixel, knowledge base, email, Drive, reports PDF, VIN degradation, Context Router UI, SMS compliance, data health, kill switch, DealerPulse, product tour, comms defaults, voice after-hours, hunches, embed copy, search/Cmd+K |
| P2-2 | 18 missing PRD information items | Subscription pricing, skills catalog content, inbox handoff mechanics, Super Admin capabilities, partner credit pools, orchestration agent, inventory data, org creation wizard, video agent config details |
| P2-3 | 10 architecture/spec contradictions unresolved | Hub tab count, table count, endpoint count, framework, agent architecture vision vs reality, goals location, Work Center vs Hub naming, SRS authority |
| P2-4 | PM2 restart count (3,349) — stability unknown | Currently 42h uptime; if stabilized, historical artifact; if still looping, P0 |

---

### P3 Gaps (Low Priority)

| ID | Gap |
|----|-----|
| P3-1 | No CI/CD pipeline (manual deploys only) |
| P3-2 | 7 npm dependency vulnerabilities (0 critical, 4 high) |

---

## PART 2: Retired Claims List (False/Tainted/Resolved)

These claims from existing tracking files are NOT real gaps. They must NOT re-enter the gap tracker.

| Claim | Source | Verdict | Why It's Wrong |
|-------|--------|---------|----------------|
| GAP-B1-AGENT-001/002/003 "3/5 orgs missing chat agents" | FINAL_REPORT | TAINTED | Automa IS the chat agent — architecture misunderstanding |
| GAP-B1-SKILLS-001 "No tools (tools=[])" | FINAL_REPORT | TAINTED | 7 tools at widget/system level, not per-agent DB field |
| GAP-B1-INSTR-001/002 "Instructions lack CRM/trigger docs" | FINAL_REPORT | TAINTED | Measured raw DB field, not skill overlay system |
| GAP-B1-TRIGGER-001 "No trigger dedup" | FINAL_REPORT | TAINTED | Two dedup mechanisms exist in TriggerService + idleLeadChecker |
| GAP-B3-SMS-001 "TextMagic 401" | FINAL_REPORT | TAINTED | Agent tested .env creds; service uses per-org DB creds |
| GAP-B5-VIN-SYNC-001 "VIN appointment sync missing" | FINAL_REPORT | RESOLVED | VIN Solutions has no calendar API — owner decision |
| GAP-B5-BIDIR-001 "Bidirectional sync impossible" | FINAL_REPORT | RESOLVED | Same as above — owner decision, not a bug |
| FR-P0-11 "Widget persona shows Nexxus" | FINAL_REPORT | DISPUTED | Widget header branding is narrower issue (P1 not P0) |
| FINAL_REPORT readiness score 22/100 | FINAL_REPORT | INVALID | Score contaminated by 8 tainted + 2 resolved findings |
| "All 12 P0 FIXED, 0 Blockers" header | release_criteria | PARTIALLY INACCURATE | Original 12 were fixed, but 5 new/incomplete P0s exist |

---

## PART 3: Positive Corrections (Better Than Wave Notes Said)

| Item | Wave Notes Said | Code Shows | Impact |
|------|-----------------|------------|--------|
| Billing routes | "Commented out as PHASE-FUTURE" | `App.tsx:95` and `routes.ts:178` — billing routes ARE registered and active | Billing is more complete than expected |
| VAPI webhook code | "handleEndOfCallReport is UPDATE-only" | Code now has UPSERT (`ON CONFLICT DO UPDATE`) | Code is defensive; issue was config, now resolved |
| Goals tab | "Should be removed from Insights" | Correctly absent from Insights tabs (only dashboard, reports, library, hunches) | Already done correctly |
| Context Router | "Needs verification" | 44 `excel_upload` exclusion occurrences confirmed; SourceSelector, CacheManager implemented | Fully implemented |
| Automa Chat | "DEMO-READY" | 24 tools confirmed, SSE streaming wired, floating overlay works | Most complete feature — confirmed |

---

## PART 4: Contradictions Requiring Owner Decision

| # | Contradiction | Agent A Says | Agent B Says | Recommendation |
|---|---------------|-------------|-------------|----------------|
| C-1 | Appointment notifications: P1 or P0? | P0-3 confirmed | Elevate from P1 to P0 | **P0** — blocks demo item #3 |
| C-2 | Hosted pages FIXED status | `/w/:slug` works, `/p/:slug` broken | FIXED claim incomplete | **Update release_criteria**: partial fix |
| C-3 | "All 12 P0 FIXED" header | 5 real P0s remain | Header must be updated | **Update header** in new PLAN.md |
| C-4 | Platform readiness 22/100 | ~40-50% demo-ready per wave analysis | 22/100 contaminated | **Retire 22/100 score** — use validated assessment |
| C-5 | Trigger code FIXED vs 0 executions | Code correct, rules seeded, 0 real completions | Runtime logic bug not visible from code review | **Both correct at their level** — new P0-4 gap tracks the runtime issue |
| C-6 | Hub tab count: 6 in code, 3 in RUI | Code has 6 tabs | RUI shows 3 tabs | **Not a contradiction** — RUI is Tier 1 truth. Code is wrong. Gap P1-10 tracks the fix. |

---

## PART 5: Payment-Critical Demo Readiness Summary

| Demo Item | Status | Blocking Gaps |
|-----------|--------|---------------|
| 1. Metrics & Insights | PARTIAL | P0-2 (crash risk) |
| 2. Communications Agent Config | NOT WORKING | P0-4 (0 trigger executions), P1-2 (hot_lead no callsite), P1-3 (appointment_created no callsite) |
| 3. Appointment Flow | PARTIAL | P0-3 (no status notifications), P0-5 (no VIN note link) |
| 4. Proactive Lead Follow-up | NOT WORKING | P0-4 (0 trigger executions), P1-9 (SMS routing not wired) |
| 5. Reactive After-Hours | NOT WORKING | P1-9 (SMS after-hours not wired), P0-4 (business hours blocking) |
| 6. Widgets (3 modes) | MOSTLY WORKING | P0-1 (hosted pages `/p/:slug` broken; `/w/:slug` works) |
| 7. Automa Chat | WORKING | No blocking gaps |

**Bottom line:** 1 of 7 demo items works end-to-end (Automa Chat). 1 mostly works (Widgets). 5 have blocking gaps.

---

## PART 6: Recommended Cluster Ordering for PLAN.md

Based on dependencies and demo impact, recommended incremental build order:

| Cluster | Features | P0s Addressed | Est. Complexity |
|---------|----------|---------------|----------------|
| 0 | Foundation fixes: P0-1 (hosted route), P0-2 (null guards), P1-1 (RLS var), P1-13 (vendor names), P1-15 (webhook security) | P0-1, P0-2 | Low — mostly one-liners |
| 1 | Metrics & Insights | Clears DEMO-1 | Low |
| 2 | Automa Chat | Already working (DEMO-7) — verify only | Verification only |
| 3 | Appointment Flow: P0-3 (notifications), P0-5 (VIN note), P1-3 (trigger emission) | P0-3, P0-5 | Moderate |
| 4 | Trigger System + Comms Agent: P0-4 (execution logic), P1-2 (hot_lead), business hours fix | P0-4 | Moderate-High |
| 5 | Proactive Follow-up: depends on Cluster 4 triggers working | Clears DEMO-4 | Moderate |
| 6 | After-Hours Coverage: P1-9 (SMS routing), depends on Cluster 4 | Clears DEMO-5 | Moderate |
| 7 | Widgets: verify all 3 modes after Cluster 0 fixes | Clears DEMO-6 | Low (mostly verification) |

---

*Both diff agent reports preserved at:*
- `wave-notes/diff-A-code-vs-waves.md` (Agent A — code verification)
- `wave-notes/diff-B-claims-vs-waves.md` (Agent B — claims audit)
