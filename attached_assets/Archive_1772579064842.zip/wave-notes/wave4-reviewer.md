# Wave 4 — Testable Outcomes (Acceptance Criteria) — REVIEWER

**Agent:** Reviewer
**Wave:** 4 of 6
**Date:** 2026-03-03
**Input files scanned:** 38 of 53 (low-relevance/duplicate/superseded files excluded)

---

## Methodology

Each acceptance criterion extracted follows this format:
- **AC-RXXX:** Statement of what the user should experience (Given/When/Then or "User can..." phrasing)
- **Source:** File and approximate location
- **Testable:** YES or NO
- **Role:** Which RBAC role(s) this applies to
- **Tag:** [EXPLICIT] = directly stated in source, [INFERRED] = derived from feature description or UI spec

The "R" prefix distinguishes Reviewer-extracted ACs from Analyst-extracted ACs to enable reconciliation.

---

## 1. Authentication & Access

### AC-R001: Login and Redirect
Given a user with valid credentials, when they enter email and password and click Sign In, then they are authenticated and redirected to the Main Dashboard.
- **Source:** UI_INTERACTIVE_ELEMENTS_MAP.md, Login Page section; MASTER_SRS.md Section 5.1
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R002: JWT Token Issuance
Given a successful login, the system issues JWT access (15 min) and refresh (7 day) tokens stored in localStorage.
- **Source:** MASTER_SRS.md Section 11.2; UNIFIED_HANDOFF_PROMPT.md Section 1 rule 6
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R003: RLS Tenant Isolation
Given a logged-in user in Org A, when they make any API request, they cannot see or modify data belonging to Org B.
- **Source:** MASTER_SRS.md Section 5.1, 11.2; CONSTITUTION.md Section 2.3
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R004: Role-Gated API Endpoints
Given a user with `org_staff` role, when they attempt to access admin-only endpoints (e.g., user management, system settings), the server returns 403 Forbidden.
- **Source:** MASTER_SRS.md Section 3.3 Permissions Matrix; CONSTITUTION.md Section 5
- **Testable:** YES
- **Role:** All roles (test boundary per role)
- **Tag:** [EXPLICIT]

### AC-R005: Organization Switching
Given a user assigned to multiple organizations (org_admin, partner_admin, super_admin), when they use the org switcher in the top bar, the dashboard reloads with the selected org's data.
- **Source:** UI_INTERACTIVE_ELEMENTS_MAP.md TopBar section; MASTER_SRS.md Section 3.2
- **Testable:** YES
- **Role:** org_admin (if multi-org), partner_admin, super_admin
- **Tag:** [EXPLICIT]

### AC-R006: Super Admin System View
Given a super_admin user, when they switch to "Nexxus System" view, they see the org UI in its default system configuration.
- **Source:** ===DevDesign Notes===.md line 37
- **Testable:** YES
- **Role:** super_admin
- **Tag:** [EXPLICIT]

---

## 2. Navigation & Layout

### AC-R010: Sidebar Navigation Order
The sidebar displays navigation items in this order: Main, Insights, Agents, Hub, Drive, Activity, Settings, Profile.
- **Source:** ===DevDesign Notes===.md line 129; ARCHITECTURE_GUIDE.md Section 1.2; MASTER_SRS.md Section 4.2
- **Testable:** YES
- **Role:** All roles (some items hidden per role)
- **Tag:** [EXPLICIT] (Note: DevDesign Notes says Main, Insights, Agents, Hub, Drive; MASTER_SRS says Main, Agents, Drive, Insights, Hub, Activity, Settings. CONFLICT flagged below.)

### AC-R011: Sidebar Pop-out Submenu
When a user hovers over a sidebar item with submenus, a pop-out submenu appears. Double-arrow click locks the submenu open.
- **Source:** MASTER_SRS.md Section 4.2; ARCHITECTURE_GUIDE.md Section 1.2; app_identity.md Section H
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R012: Layout Type B — Dashboard
The Main Dashboard uses Layout Type B: information display in center pane, chat window on right side. Chat opens by default on this page only.
- **Source:** MASTER_SRS.md Section 4.1, 4.3; app_identity.md Section B1
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R013: Layout Type C — Agents
The Agents page uses Layout Type C: chat display in center, configuration/info in right pane.
- **Source:** MASTER_SRS.md Section 4.1; app_identity.md Section B2
- **Testable:** YES
- **Role:** All roles with agent access
- **Tag:** [EXPLICIT]

### AC-R014: Activity Tab Hidden from Staff
Given a user with `org_staff` role, the Activity sidebar item is not visible.
- **Source:** MASTER_SRS.md Section 4.2 (Activity: minimum role org_admin)
- **Testable:** YES
- **Role:** org_staff (negative test)
- **Tag:** [EXPLICIT]

### AC-R015: Settings Hidden from Staff
Given a user with `org_staff` role, the Settings sidebar item is not visible.
- **Source:** ===DevDesign Notes===.md line 220; DESIGNER_UPDATE_SPEC.md Section 1 RBAC table
- **Testable:** YES
- **Role:** org_staff (negative test)
- **Tag:** [EXPLICIT]

### AC-R016: Responsive Layout
On mobile (<768px), the layout shows a single center pane with sidebar as overlay. On tablet (768-1024px), sidebar + center are visible.
- **Source:** ARCHITECTURE_GUIDE.md Section 1.1 Responsive Breakpoints
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R017: No Vendor Names in UI
Zero occurrences of "Tavus", "Vapi", or "VAPI" appear in any user-facing UI text. Replaced with "Voice Agent", "Video Agent", "AI Assistant".
- **Source:** MASTER_SRS.md AC-002; CONSTITUTION.md Section 3.1; IMPLEMENTATION_PLAN.md Phase 1
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R018: No Source Labels in UI
Zero occurrences of "Local + VIN", "VIN API", or other internal data source attribution appear in user-facing UI.
- **Source:** MASTER_SRS.md AC-003; CONSTITUTION.md Section 3.1; IMPLEMENTATION_PLAN.md Phase 1
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R019: No UI Console Errors
When navigating through all pages, the browser console shows zero JavaScript errors.
- **Source:** Acceptance Criteria.md item 12; MASTER_SRS.md AC-019
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R020: Page Load Performance
Each page loads within 3 seconds.
- **Source:** MASTER_SRS.md Section 11.1
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

---

## 3. Automa Chat

### AC-R030: Automa Chat on Main Dashboard
When the Main Dashboard loads, the Automa chat window is visible in the right pane and is ready to accept user input.
- **Source:** MASTER_SRS.md Section 4.3; app_identity.md Section B1; Acceptance Criteria.md item 9
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R031: Automa Chat as Popout Overlay
Automa chat appears as a floating popout overlay (not inline in the main content area). It is available globally from any page except the dedicated chat page.
- **Source:** ACCEPTANCE_VERIFICATION_REPORT.md AC-1; Acceptance Criteria.md (derived from demo requirement)
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R032: Automa Conversational Competence
Given a user chatting with Automa, when they ask a general knowledge question, Automa provides a coherent, multi-turn response (5-10 turns minimum) as a reasonable LLM replacement.
- **Source:** Acceptance Criteria.md item 9
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R033: Automa CRM Data Query
Given an org_admin chatting with Automa, when they ask "Search VIN for [name]", Automa uses the VIN Solutions tool to query CRM data and returns lead information.
- **Source:** Acceptance Criteria.md items 4, 9; MASTER_SRS.md Section 5.3
- **Testable:** YES
- **Role:** org_admin, partner_admin, super_admin
- **Tag:** [EXPLICIT]

### AC-R034: Automa Blocked Data Honesty
Given a user asking Automa about blocked data (deals, inventory, communication logs), Automa explains that the data is unavailable and offers what it can provide instead.
- **Source:** MASTER_SRS.md AC-011; CONSTITUTION.md Section 2.2; IMPLEMENTATION_PLAN.md Phase 1 item 1.4
- **Testable:** YES
- **Role:** All roles with DealerBrain access
- **Tag:** [EXPLICIT]

### AC-R035: Automa Drive Artifact Creation
Given a user asking Automa to "create a lead report from a data query", Automa generates the report artifact and it appears in the Drive.
- **Source:** Acceptance Criteria.md item 9
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R036: Automa First-Token Response Time
When a user sends a message to Automa, the first token of the AI response appears within 3 seconds.
- **Source:** MASTER_SRS.md Section 11.1
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R037: Automa Not Listed on Agents Page
Automa does not appear as an entry on the Agents page list.
- **Source:** ===DevDesign Notes===.md line 187; session-knowledge.md Section 0 (Automa always at top of agents list vs. not listed — see CONFLICT below)
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT] (but conflicted — see Conflicts section)

### AC-R038: Automa Per-Org System Context
Given a super_admin, when they add per-org instructions in Settings > AI Configuration > System Prompt, Automa incorporates those instructions into responses for that org.
- **Source:** Acceptance Criteria.md item 13; ===DevDesign Notes===.md line 88; DESIGNER_UPDATE_SPEC.md Section 6
- **Testable:** YES
- **Role:** super_admin (configure), all roles (observe)
- **Tag:** [EXPLICIT]

---

## 4. Insights Dashboard

### AC-R040: Insights Sub-Navigation
The Insights page has sub-sections: Dashboard (Command Center, Pipeline Health, Performance Scorecard), Reports (Loss & Quality Analysis, Channel Intelligence, Trend & Forecast), and Hunches.
- **Source:** Insights Layout.md; ===DevDesign Notes===.md lines 51-66
- **Testable:** YES
- **Role:** org_admin, partner_admin, super_admin (full); org_staff (limited)
- **Tag:** [EXPLICIT]

### AC-R041: Command Center 3-Zone Layout
The Insights > Dashboard > Command Center displays three zones: Red Zone (immediate action), Yellow Zone (watch list), Green Zone (today's performance).
- **Source:** Insights Layout.md (full wireframe)
- **Testable:** YES
- **Role:** org_admin
- **Tag:** [EXPLICIT]

### AC-R042: Metric Drill-Down on Click
When a user clicks a metric tile on the Main Dashboard, a modal opens showing the detailed data that composes the score.
- **Source:** Org admin Metrics.md (modal breakdown description); Acceptance Criteria.md item 2
- **Testable:** YES
- **Role:** org_admin, partner_admin, super_admin
- **Tag:** [EXPLICIT]

### AC-R043: Org Admin 4 Dashboard Tiles
The Main Dashboard for org_admin displays 4 score tiles: Pipeline Health Score, Lead Source Performance Score, Lead Quality Score, Market Demand Insight Score.
- **Source:** Org admin Metrics.md (full specification with formulas)
- **Testable:** YES
- **Role:** org_admin
- **Tag:** [EXPLICIT]

### AC-R044: Voice Agent Metrics Display
The Voice Agent insight card displays actual call count, and the count matches the VAPI Analytics API query within a 1-minute cache window.
- **Source:** MASTER_SRS.md AC-003; Acceptance Criteria.md item 3
- **Testable:** YES
- **Role:** org_admin, super_admin
- **Tag:** [EXPLICIT]

### AC-R045: Video Agent Metrics Display
The Video Data insight card displays actual session count from Tavus API.
- **Source:** MASTER_SRS.md AC-003; Acceptance Criteria.md item 3
- **Testable:** YES
- **Role:** org_admin, super_admin
- **Tag:** [EXPLICIT]

### AC-R046: Transcript Viewable
Given a completed voice call, when the user clicks "View Transcript" on the Voice Agent card, the full transcript is displayed in a modal.
- **Source:** Acceptance Criteria.md item 3; UI_INTERACTIVE_ELEMENTS_MAP.md Insights Page
- **Testable:** YES
- **Role:** org_admin, partner_admin, super_admin
- **Tag:** [EXPLICIT]

### AC-R047: Metric Accuracy Within 2%
Every certified metric displayed on any dashboard matches ground truth (direct API query) within 2%.
- **Source:** MASTER_SRS.md AC-007; CONSTITUTION.md Section 2.4
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R048: Test Call Exclusion
Metrics exclude test calls (calls with IDs matching `test-e2e-*` pattern).
- **Source:** MASTER_SRS.md Section 11.3; ACCEPTANCE_VERIFICATION_REPORT.md AC-10
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R049: Dashboard Refresh
When a user clicks the Refresh button on the Insights page, all metrics queries are invalidated and reloaded.
- **Source:** UI_INTERACTIVE_ELEMENTS_MAP.md Insights Page; CLARIFICATION_ANSWERS.md Q18
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R050: No Placeholder Metrics
If a metric cannot be calculated (blocked API, insufficient data, fill rate <50%), the metric is not displayed at all. No "coming soon" or placeholder values.
- **Source:** CONSTITUTION.md Sections 2.4, 3.1; MASTER_SRS.md Section 8.2
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R051: Date Range Filter
The Insights page provides a date range selector with options: 24h, 48h, 7d, 30d.
- **Source:** UI_INTERACTIVE_ELEMENTS_MAP.md Insights Page
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R052: CSV Export from Command Center
When user clicks "Export CSV" on the Command Center stale leads section, a valid CSV file downloads.
- **Source:** Insights Layout.md (Export CSV button in Yellow Zone); IMPLEMENTATION_PLAN.md Phase 7 item 7.1
- **Testable:** YES
- **Role:** org_admin
- **Tag:** [EXPLICIT]

---

## 5. Agents Page

### AC-R060: Agent List with Search and Filters
The Agents page displays a searchable list of agents with type filter (voice/chat/video/task) and status filter (active/inactive).
- **Source:** UI_INTERACTIVE_ELEMENTS_MAP.md Agents Page
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R061: Create Agent Flow
Given an org_admin, when they click "Create Agent", a center-page dialog opens with name/description fields, channel buttons (voice/chat/video/email/task), trigger switches, and tool badges.
- **Source:** UI_INTERACTIVE_ELEMENTS_MAP.md Agent Create Page; ===DevDesign Notes===.md line 185
- **Testable:** YES
- **Role:** org_admin, partner_admin, super_admin
- **Tag:** [EXPLICIT]

### AC-R062: Agent Skills (Add Skills to Agent)
When creating or editing an agent, the user can add skills from a catalog. Skills are agent overlays with prepopulated context and instructions.
- **Source:** session-knowledge.md Section 0b; DESIGNER_UPDATE_SPEC.md Section 16 Skills Catalog
- **Testable:** YES
- **Role:** org_admin, partner_admin, super_admin
- **Tag:** [EXPLICIT]

### AC-R063: Agent Chat Interaction
Given a user with access to an agent, when they select the agent from the list, a chat interface opens in the center pane. The user can send messages and receive responses (5-10 turn conversation).
- **Source:** Acceptance Criteria.md item 8; UI_INTERACTIVE_ELEMENTS_MAP.md Agents Page (Send Chat Button)
- **Testable:** YES
- **Role:** All roles (if agent is shared)
- **Tag:** [EXPLICIT]

### AC-R064: Agent Right Pane Configuration
When an agent is selected, the right pane shows: agent configuration, triggers, prompt, knowledge, activity log, and (for communication agents) the customer-facing link and phone number.
- **Source:** ===DevDesign Notes===.md lines 83-89; DESIGNER_UPDATE_SPEC.md Section 12
- **Testable:** YES
- **Role:** org_admin, partner_admin, super_admin
- **Tag:** [EXPLICIT]

### AC-R065: Agent Toggle Active/Inactive
Given an admin user, when they toggle an agent's status, the agent state changes between active and inactive.
- **Source:** UI_INTERACTIVE_ELEMENTS_MAP.md Agents Page (Play/Pause Status)
- **Testable:** YES
- **Role:** org_admin, partner_admin, super_admin
- **Tag:** [EXPLICIT]

### AC-R066: Agent CRUD Operations
Admin users can create, edit, duplicate, and delete agents.
- **Source:** UI_INTERACTIVE_ELEMENTS_MAP.md Agents Page
- **Testable:** YES
- **Role:** org_admin, partner_admin, super_admin
- **Tag:** [EXPLICIT]

### AC-R067: Consistent Agent Name Across Channels
The video agent, inbound call agent, outbound call agent, and text chat agent for an org all display the same persona name.
- **Source:** Acceptance Criteria.md item 7
- **Testable:** YES
- **Role:** All roles (observable from customer side)
- **Tag:** [EXPLICIT]

---

## 6. Hub - Calendar

### AC-R070: Calendar View
The Hub Calendar tab displays appointments in a calendar view. Clicking a date opens an appointment creation modal. Clicking an existing event opens appointment details.
- **Source:** UI_INTERACTIVE_ELEMENTS_MAP.md Work Center Page; MASTER_SRS.md Section 5.6.2
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R071: Appointment Creation
Given a user on the Calendar tab, when they select a date and fill in appointment details, a new appointment is created and appears on the calendar.
- **Source:** UI_INTERACTIVE_ELEMENTS_MAP.md Work Center Page (Calendar Date Select)
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R072: Appointment to VIN Lead Insertion
When an appointment is created (via calendar or agent), the corresponding lead is inserted into VIN Solutions with a note about the appointment.
- **Source:** Acceptance Criteria.md item 3 (payment-critical); session-knowledge.md Section 0c item 3
- **Testable:** YES
- **Role:** System-level (verify via VIN API)
- **Tag:** [EXPLICIT]

### AC-R073: Google Calendar Sync
Given a user who has connected Google Calendar via OAuth, appointments created in Nexxus sync to their Google Calendar.
- **Source:** MASTER_SRS.md Section 6.6
- **Testable:** YES
- **Role:** All roles (per-user)
- **Tag:** [EXPLICIT]

### AC-R074: Appointment Drag-and-Drop Reschedule
Given an appointment on the calendar, when the user drags it to a new time slot, the appointment is rescheduled.
- **Source:** UI_INTERACTIVE_ELEMENTS_MAP.md (useRescheduleAppointment hook)
- **Testable:** YES
- **Role:** All roles
- **Tag:** [INFERRED]

---

## 7. Hub - Leads

### AC-R080: Leads List with Actions
The Hub Leads tab displays a list of leads with text, call, and schedule buttons per lead.
- **Source:** ===DevDesign Notes===.md line 196; DESIGNER_UPDATE_SPEC.md Hub section
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R081: Mark Contacted Updates VIN CRM
Given a user clicking "Mark Contacted" on a lead, both the local database and VIN Solutions CRM lead status are updated.
- **Source:** IMPLEMENTATION_PLAN.md Phase 3 item 3.2; MASTER_SRS.md AC-014
- **Testable:** YES
- **Role:** org_admin, org_staff
- **Tag:** [EXPLICIT]

### AC-R082: Lead Detail Modal
When a user clicks a lead ID, a lead detail modal opens showing full lead information.
- **Source:** Insights Layout.md interaction features; UI_INTERACTIVE_ELEMENTS_MAP.md (handleViewLead)
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R083: Proactive Lead Follow-Up
Given a new lead in VIN Solutions that has not been addressed within 5 minutes, the communications agent proactively initiates an outbound phone call AND an outbound text message.
- **Source:** Acceptance Criteria.md item 10 (payment-critical); session-knowledge.md Section 0c item 4
- **Testable:** YES
- **Role:** System-level (verify via VAPI + TextMagic)
- **Tag:** [EXPLICIT]

### AC-R084: Lead Insertion from VAPI Webhook
When a VAPI call completes, a lead is created in VIN Solutions with valid leadSource and leadType hrefs, assigned to the configured default user.
- **Source:** MASTER_SRS.md AC-004; ACCEPTANCE_VERIFICATION_REPORT.md AC-4
- **Testable:** YES
- **Role:** System-level
- **Tag:** [EXPLICIT]

### AC-R085: Lead Duplicate Detection
Before creating a new lead in VIN from webhook data, the system checks for existing leads by phone/email and links to existing records instead of creating duplicates.
- **Source:** MASTER_SRS.md AC-004; MASTER_SRS.md Section 7.3
- **Testable:** YES
- **Role:** System-level
- **Tag:** [EXPLICIT]

---

## 8. Hub - Inbox

### AC-R090: Hub Has Exactly 3 Tabs
The Hub page displays exactly 3 tabs: Calendar, Leads, Inbox.
- **Source:** DESIGNER_UPDATE_SPEC.md Critical Clarification (top of document)
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R091: Unified Inbox
The Inbox tab shows all communication in a unified view: widget chats, SMS threads, and email threads.
- **Source:** SRS Addendum v3.2 Section 6.1; ===DevDesign Notes===.md lines 194-197; session-knowledge.md Section 0 (Unified Inbox concept)
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R092: Two-Way SMS Conversation
Given a customer who has texted the org's TextMagic number, when staff opens the Inbox, they can see the inbound message and reply with an outbound SMS.
- **Source:** Acceptance Criteria.md item 6; MASTER_SRS.md AC-012
- **Testable:** YES
- **Role:** org_staff, org_admin
- **Tag:** [EXPLICIT]

### AC-R093: SMS After-Hours AI Response
Given an inbound SMS received after business hours, the system generates and sends an AI response via DealerBrain (Claude API), not VAPI.
- **Source:** MASTER_SRS.md AC-012; IMPLEMENTATION_PLAN.md Phase 5; session-knowledge.md Section 0c item 5
- **Testable:** YES
- **Role:** System-level
- **Tag:** [EXPLICIT]

### AC-R094: SMS Human Takeover
Given an AI-active SMS conversation, when a staff member sends a manual reply, AI responses stop (conversation state transitions to HUMAN_ACTIVE).
- **Source:** MASTER_SRS.md AC-012; IMPLEMENTATION_PLAN.md Phase 5 item 5.3
- **Testable:** YES
- **Role:** org_staff, org_admin
- **Tag:** [EXPLICIT]

### AC-R095: External Conversation Continuity
Given a customer who started a conversation via the widget (external), when staff opens the Inbox, they can see the conversation history and continue it internally.
- **Source:** session-knowledge.md Section 0 (Unified Inbox concept, widget-to-internal continuity); app_identity.md Section B5
- **Testable:** YES
- **Role:** org_staff, org_admin
- **Tag:** [EXPLICIT]

### AC-R096: New Message Quick Action
The Hub page has a "New Message" quick action button that opens a modal with SMS/Email selection.
- **Source:** ===DevDesign Notes===.md line 194
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R097: Email in Inbox
The Inbox includes email threads accessible via IMAP/SMTP integration. Staff can compose emails with a rich-text editor.
- **Source:** ACCEPTANCE_VERIFICATION_REPORT.md AC-3; CLARIFICATION_ANSWERS.md Q12
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

---

## 9. Widgets

### AC-R100: Unified Widget 6 Channels
The embeddable widget presents up to 6 communication options: Text Chat, Web Video Agent, Call Us, Call You, Web Audio, Send a Text.
- **Source:** SRS Addendum v3.2 Section 2.2; MASTER_SRS.md Section 5.9; CLARIFICATION_ANSWERS.md Q7
- **Testable:** YES
- **Role:** External (customer-facing)
- **Tag:** [EXPLICIT]

### AC-R101: Widget Channel Enable/Disable Per Org
Each widget channel can be individually enabled or disabled per organization in Settings > Tools & Integrations > Widgets.
- **Source:** SRS Addendum v3.2 Section 2.1; CLARIFICATION_ANSWERS.md Q7
- **Testable:** YES
- **Role:** org_admin, partner_admin, super_admin
- **Tag:** [EXPLICIT]

### AC-R102: Hosted Landing Pages Load Successfully
Given a deployed hosted page slug (e.g., /w/serra-honda), the page loads with HTTP 200, displays the org's branding, and the widget is embedded and functional.
- **Source:** Acceptance Criteria.md item 5; ACCEPTANCE_VERIFICATION_REPORT.md AC-7; session-knowledge.md Section 5 (hosted pages route mismatch P0)
- **Testable:** YES
- **Role:** External (public URL)
- **Tag:** [EXPLICIT]

### AC-R103: Hosted Page 3 Deployment Modes
Widgets can be deployed in 3 modes: unified widget (bottom corner), embed code (directly into customer website), hosted landing page.
- **Source:** Acceptance Criteria.md item 5; session-knowledge.md Section 0c item 6
- **Testable:** YES
- **Role:** External
- **Tag:** [EXPLICIT]

### AC-R104: Widget Domain Whitelist
The widget only loads on domains listed in the widget config's allowed_domains. Requests from non-whitelisted domains are rejected.
- **Source:** SRS Addendum v3.2 Section 10.1; MASTER_SRS.md Section 11.2
- **Testable:** YES
- **Role:** System-level
- **Tag:** [EXPLICIT]

### AC-R105: Widget Load Time
The widget bundle loads and becomes interactive within 1.5 seconds.
- **Source:** MASTER_SRS.md Section 11.1
- **Testable:** YES
- **Role:** External
- **Tag:** [EXPLICIT]

### AC-R106: Widget Chat AI Response Time
When a visitor starts a text chat via the widget, the AI responds within 5 seconds.
- **Source:** MASTER_SRS.md AC-017
- **Testable:** YES
- **Role:** External
- **Tag:** [EXPLICIT]

### AC-R107: Widget No Vendor Names
The widget UI contains zero occurrences of vendor names (Tavus, VAPI, TextMagic).
- **Source:** MASTER_SRS.md AC-017; CONSTITUTION.md Section 3.1
- **Testable:** YES
- **Role:** External
- **Tag:** [EXPLICIT]

### AC-R108: Widget Responsive
The widget functions correctly on mobile, tablet, and desktop viewports.
- **Source:** MASTER_SRS.md AC-017
- **Testable:** YES
- **Role:** External
- **Tag:** [EXPLICIT]

### AC-R109: Inbound Calls from Widget to VAPI
When a visitor uses the "Call Us" or "Web Audio" widget option, the call connects to the configured VAPI assistant.
- **Source:** Acceptance Criteria.md item 11 (payment-critical)
- **Testable:** YES
- **Role:** External
- **Tag:** [EXPLICIT]

### AC-R110: Outbound Call Trigger from Widget
When a visitor uses "Call You" widget option and provides their phone number, VAPI initiates an outbound call to the customer.
- **Source:** Acceptance Criteria.md item 5a; SRS Addendum v3.2 Section 2.6
- **Testable:** YES
- **Role:** External
- **Tag:** [EXPLICIT]

---

## 10. Triggers

### AC-R120: Trigger Configuration
Given an org_admin, they can create conditional triggers: IF [field] [operator] [value] THEN [action]. Supported event types include: new_lead, lead_status_change, missed_call, appointment_scheduled, inbound_message, hot_lead, custom.
- **Source:** MASTER_SRS.md AC-013, Section 5.10; ACCEPTANCE_VERIFICATION_REPORT.md AC-11
- **Testable:** YES
- **Role:** org_admin, partner_admin, super_admin
- **Tag:** [EXPLICIT]

### AC-R121: Trigger Actions
Triggers support 5 action types: outbound_call, send_sms, send_email, create_task, webhook.
- **Source:** MASTER_SRS.md Section 5.10; ACCEPTANCE_VERIFICATION_REPORT.md AC-11
- **Testable:** YES
- **Role:** org_admin, partner_admin, super_admin
- **Tag:** [EXPLICIT]

### AC-R122: Trigger Rate Limiting
Triggers enforce rate limiting per rule to prevent duplicate actions.
- **Source:** ACCEPTANCE_VERIFICATION_REPORT.md AC-11
- **Testable:** YES
- **Role:** System-level
- **Tag:** [EXPLICIT]

### AC-R123: Trigger Business Hours Enforcement
Triggers respect per-org business hours configuration. Triggers configured as business-hours-only do not fire outside those hours.
- **Source:** ACCEPTANCE_VERIFICATION_REPORT.md AC-11; IMPLEMENTATION_PLAN.md Phase 5
- **Testable:** YES
- **Role:** System-level
- **Tag:** [EXPLICIT]

### AC-R124: Trigger Notification Delivery Within 60 Seconds
When a trigger fires, the notification (email, SMS, or in-app) is delivered to the target user within 60 seconds.
- **Source:** MASTER_SRS.md AC-013, Section 11.1
- **Testable:** YES
- **Role:** System-level
- **Tag:** [EXPLICIT]

### AC-R125: Trigger View in Agent Right Pane
Triggers associated with an agent are visible in the agent's right pane popout.
- **Source:** ===DevDesign Notes===.md line 188
- **Testable:** YES
- **Role:** org_admin, partner_admin, super_admin
- **Tag:** [EXPLICIT]

---

## 11. Drive

### AC-R130: Drive Personal and Shared Folders
The Drive page shows two spaces: a personal folder and a public shared folder.
- **Source:** MASTER_SRS.md Section 5.4; app_identity.md Section B3
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R131: Drive Grid/List View Toggle
The Drive page supports grid view and list view, toggled by buttons.
- **Source:** UI_INTERACTIVE_ELEMENTS_MAP.md Drive Page
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R132: Drive Artifact Auto-Save
When an artifact is created in an Automa chat, it is automatically saved to the user's Drive.
- **Source:** app_identity.md Section B3; MASTER_SRS.md Section 5.4
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R133: Drive File Sharing
Each file in Drive has a share button allowing sharing via email or SMS.
- **Source:** ===DevDesign Notes===.md lines 98, 202-203; DESIGNER_UPDATE_SPEC.md Section 14
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

---

## 12. Settings

### AC-R140: Settings Tile Grid
The Settings page displays a grid of 9 tiles: Users, Organization, Tools & Integrations, Knowledge Base, AI Configuration, Security & Privacy, Notifications, Data Management, Appearance.
- **Source:** DESIGNER_UPDATE_SPEC.md Section 1
- **Testable:** YES
- **Role:** org_admin+ (visibility per RBAC matrix in DESIGNER_UPDATE_SPEC.md)
- **Tag:** [EXPLICIT]

### AC-R141: Settings RBAC Visibility
Settings tiles are shown/hidden per role according to the RBAC matrix: Staff sees none, Org Admin sees Users/Org/Tools/KB/Notifications/Appearance, Partner Admin adds AI Config (read-only) and Security, Super Admin sees all.
- **Source:** DESIGNER_UPDATE_SPEC.md Section 1 RBAC table
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R142: User Management CRUD
Given an org_admin, they can add, edit, and deactivate users within their organization.
- **Source:** UI_INTERACTIVE_ELEMENTS_MAP.md Settings Page; DESIGNER_UPDATE_SPEC.md Section 2
- **Testable:** YES
- **Role:** org_admin, partner_admin, super_admin
- **Tag:** [EXPLICIT]

### AC-R143: Tools & Integrations 5-7 Tabs
The Tools & Integrations tile opens with 5 tabs (MCP, API, Other, Widgets, Landing Pages). Super Admin sees 2 additional tabs (API Keys, Webhooks).
- **Source:** DESIGNER_UPDATE_SPEC.md Section 4
- **Testable:** YES
- **Role:** org_admin (5 tabs), super_admin (7 tabs)
- **Tag:** [EXPLICIT]

### AC-R144: Integration Test Connection
Given an admin user on the Tools & Integrations page, when they click "Test" on an integration, the system attempts a connection and displays success or failure.
- **Source:** UI_INTERACTIVE_ELEMENTS_MAP.md Settings Page (Integration Test Button)
- **Testable:** YES
- **Role:** org_admin, partner_admin, super_admin
- **Tag:** [EXPLICIT]

### AC-R145: AI Configuration Tabs
The AI Configuration tile has 4 tabs: System Prompt, Agent Behavior, Skills (Super Admin only), Hunches.
- **Source:** DESIGNER_UPDATE_SPEC.md Section 6
- **Testable:** YES
- **Role:** super_admin (all tabs), partner_admin (read-only, no Skills tab)
- **Tag:** [EXPLICIT]

### AC-R146: Emergency Kill Switch
Given a super_admin on AI Configuration > Skills tab, they can activate an emergency kill switch that disables ALL agent activity for ALL users in ALL organizations. Requires confirmation dialog.
- **Source:** DESIGNER_UPDATE_SPEC.md Section 6 Tab 3
- **Testable:** YES
- **Role:** super_admin
- **Tag:** [EXPLICIT]

### AC-R147: Widget Configuration with Live Preview
Given an admin user in Settings > Widgets, when they configure appearance/channels/targeting, a live preview updates in real-time.
- **Source:** SRS Addendum v3.2 Section 2.1; DESIGNER_UPDATE_SPEC.md Section 4 Tab 4
- **Testable:** YES
- **Role:** org_admin, partner_admin, super_admin
- **Tag:** [EXPLICIT]

### AC-R148: Agent Instructions from Settings
Given an org_admin, when they add agent instructions in Settings, the agents parse and apply those instructions in their behavior.
- **Source:** Acceptance Criteria.md item 13 (payment-critical)
- **Testable:** YES
- **Role:** org_admin
- **Tag:** [EXPLICIT]

### AC-R149: Organization Creation Wizard (Super Admin)
Given a super_admin, when they click "+ New Organization" in User Management, an organization creation wizard launches.
- **Source:** DESIGNER_UPDATE_SPEC.md Sections 2 and 15
- **Testable:** YES
- **Role:** super_admin
- **Tag:** [EXPLICIT]

### AC-R150: Lead Assignment Configurable
The default lead assignee is configurable in Settings (not hardcoded). Default: Dustin Herman.
- **Source:** MASTER_SRS.md Section 5.8, AC-014; CONSTITUTION.md Section 5
- **Testable:** YES
- **Role:** org_admin, super_admin
- **Tag:** [EXPLICIT]

---

## 13. Metrics & Scores

### AC-R160: Org Admin Minimum 10 Certified Metrics
The org_admin dashboard displays at least 10 certified metrics covering pipeline health, team performance, and AI activity.
- **Source:** MASTER_SRS.md Section 8.4, AC-007
- **Testable:** YES
- **Role:** org_admin
- **Tag:** [EXPLICIT]

### AC-R161: Org Staff Minimum 5 Certified Metrics
The org_staff dashboard displays at least 5 certified personal metrics: my active leads, my overdue leads, my AI calls, my success rate, personal performance vs team average.
- **Source:** MASTER_SRS.md Section 8.4, AC-009
- **Testable:** YES
- **Role:** org_staff
- **Tag:** [EXPLICIT]

### AC-R162: Partner Admin Minimum 5 Certified Metrics
The partner_admin dashboard displays at least 5 aggregate metrics: org engagement, AI activity per org, credit usage, multi-store comparison. No individual PII visible.
- **Source:** MASTER_SRS.md Section 8.4, AC-010
- **Testable:** YES
- **Role:** partner_admin
- **Tag:** [EXPLICIT]

### AC-R163: Staff 4 Dashboard Tiles
The Main Dashboard for org_staff displays 4 tiles: Hot Opportunities, What Customers Are Buying, Competitive Threat Alert, Pipeline Urgency.
- **Source:** Staff Metrics.md (full specification with formulas)
- **Testable:** YES
- **Role:** org_staff
- **Tag:** [EXPLICIT]

### AC-R164: Partner Admin 4 Dashboard Tiles
The Main Dashboard for partner_admin displays 4 tiles: # of sub orgs, customer logins last 24h, actions taken 24h, agent actions 24h.
- **Source:** ===DevDesign Notes===.md lines 139-144
- **Testable:** YES
- **Role:** partner_admin
- **Tag:** [EXPLICIT]

### AC-R165: Metric Certification Requirement
A metric is only displayed if: its underlying data fields have >50% fill rate, the computed result matches ground truth within 2%, and its data source is accessible (not returning 403).
- **Source:** MASTER_SRS.md Section 8.2; CONSTITUTION.md Section 2.4
- **Testable:** YES
- **Role:** System-level
- **Tag:** [EXPLICIT]

### AC-R166: VIN Data Accuracy Verification
Dashboard lead counts match VIN API query results within a 1-minute cache window.
- **Source:** MASTER_SRS.md AC-003; Acceptance Criteria.md item 4
- **Testable:** YES
- **Role:** org_admin
- **Tag:** [EXPLICIT]

### AC-R167: Agent Performance Metrics Auto-Populate
After a VAPI call-ended or Tavus session-ended webhook fires, the corresponding agent's performance_metrics JSONB column is updated.
- **Source:** MASTER_SRS.md AC-013; IMPLEMENTATION_PLAN.md Phase 3 item 3.1
- **Testable:** YES
- **Role:** System-level
- **Tag:** [EXPLICIT]

---

## 14. Notifications

### AC-R170: Email Notification on Call Complete
When a VAPI call completes, an email notification is sent to configured recipients (Super Admins + Partner Admins + Org Admins).
- **Source:** MASTER_SRS.md Section 7.3; ACCEPTANCE_VERIFICATION_REPORT.md AC-4
- **Testable:** YES
- **Role:** System-level
- **Tag:** [EXPLICIT]

### AC-R171: In-App Notification on Lead Assignment
When a lead is assigned, the assignee receives an SMS and email notification.
- **Source:** MASTER_SRS.md AC-014
- **Testable:** YES
- **Role:** org_staff (assignee)
- **Tag:** [EXPLICIT]

### AC-R172: In-App Notification Bell
The top bar shows a notification bell. Clicking it reveals a dropdown of notifications. Clicking a notification marks it as read and navigates to the relevant item.
- **Source:** UI_INTERACTIVE_ELEMENTS_MAP.md TopBar section
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R173: Appointment SMS Confirmation
When an appointment is booked, an SMS confirmation is sent to the customer with dealership name, date, time, and opt-out instructions.
- **Source:** SRS Addendum v3.2 Section 3.2
- **Testable:** YES
- **Role:** System-level
- **Tag:** [EXPLICIT]

### AC-R174: Hunches as Notification Source
Notifications can originate from the Hunches system (AI-generated insights).
- **Source:** ===DevDesign Notes===.md line 123
- **Testable:** YES
- **Role:** org_admin
- **Tag:** [EXPLICIT]

### AC-R175: Notification Delivery from Triggers
When a trigger fires an action (send_sms, send_email, in-app notification), the notification is delivered within 60 seconds.
- **Source:** MASTER_SRS.md AC-013, Section 11.1
- **Testable:** YES
- **Role:** Target user
- **Tag:** [EXPLICIT]

---

## 15. Activity/Governance

### AC-R180: Activity Feed Visibility
The Activity page is visible to org_admin, partner_admin, and super_admin. It shows staff activity: chat sessions, artifact creation, system usage.
- **Source:** MASTER_SRS.md Section 5.7; app_identity.md Section B6
- **Testable:** YES
- **Role:** org_admin, partner_admin, super_admin
- **Tag:** [EXPLICIT]

### AC-R181: Activity Feed CSV Export
Given an org_admin on the Activity page, when they click "Export CSV", a valid CSV file downloads with columns: timestamp, user, action, target, details.
- **Source:** IMPLEMENTATION_PLAN.md Phase 7 item 7.1; MASTER_SRS.md Section 5.7
- **Testable:** YES
- **Role:** org_admin+
- **Tag:** [EXPLICIT]

### AC-R182: Hub Activity Filtered by User
Hub activities are filtered by user in the system. Org admin sees all activity with color-coded user keys. Org admins and partner admins can filter by specific user.
- **Source:** ===DevDesign Notes===.md lines 92-93
- **Testable:** YES
- **Role:** org_admin, partner_admin
- **Tag:** [EXPLICIT]

### AC-R183: Quality Gates Pass
Before any deployment: `npm run check` (TypeScript compilation), `npm run build` (production build), and `npx playwright test` (E2E suite) all pass with zero errors.
- **Source:** MASTER_SRS.md AC-019; CONSTITUTION.md Section 3.4
- **Testable:** YES
- **Role:** System-level
- **Tag:** [EXPLICIT]

### AC-R184: Theme Toggle
Users can toggle between light and dark themes via the top bar.
- **Source:** UI_INTERACTIVE_ELEMENTS_MAP.md TopBar section
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

### AC-R185: Logout
When a user clicks Logout, their session is terminated and they are redirected to the login page.
- **Source:** UI_INTERACTIVE_ELEMENTS_MAP.md Sidebar and TopBar sections
- **Testable:** YES
- **Role:** All roles
- **Tag:** [EXPLICIT]

---

## Watch Areas (Flagged Per Owner Instruction)

### WATCH-1: Agent Functionality / Defaults

**Findings:**
- Communications agent is preconfigured by super_admin, cannot be modified by user except triggers and instruction supplement (===DevDesign Notes===.md lines 72-73)
- Two "out of the box" agents exist: Automa and Communications Agent. All other agents are user-created (===DevDesign Notes===.md line 73)
- Skills architecture: users CREATE agents and ADD skills from a catalog of 74 pre-built prompts from V1 (DESIGNER_UPDATE_SPEC.md Section 16)
- Skills tab in Settings is Super Admin only (DESIGNER_UPDATE_SPEC.md Section 6)
- CONFLICT: Whether Automa appears on Agents page (MASTER_SRS says yes — "always at top of agents list"; DevDesign Notes says no — "Automa will not be listed on the agent page anymore"). See Conflicts section.

**AC gaps:** No AC explicitly states what the communications agent's default configuration includes, or what happens if it is missing for an org.

### WATCH-2: Billing

**Findings:**
- Billing page is specified in DESIGNER_UPDATE_SPEC.md Section 11 with: Billing Management (super_admin invoice builder), Org Billing Page (usage bars, credit limits, invoice list)
- Credits page intentionally deferred in current codebase (`App.tsx:106-114` per IMPLEMENTATION_PLAN.md)
- Economy section on tool cards feeds into invoice line items (DESIGNER_UPDATE_SPEC.md Section 4)
- Pricing: Voice $0.25/min, Video $0.32/min, SMS $0.05/msg (MASTER_SRS.md Section 12)
- Credit tracking wired to webhooks (MASTER_SRS.md Section 12)

**AC gaps:** No testable AC exists for billing UI. The billing page is fully specified in DESIGNER_UPDATE_SPEC.md but excluded from MASTER_SRS AC-001 through AC-019. This is a structural gap.

### WATCH-3: Unified Inbox Handoff

**Findings:**
- Widget-initiated conversations can be continued by staff in Inbox (session-knowledge.md Section 0)
- Conversation state machine: DORMANT -> AI_ACTIVE -> HUMAN_ACTIVE (MASTER_SRS.md AC-012)
- Human takeover stops AI responses (IMPLEMENTATION_PLAN.md Phase 5)
- SMS, email, widget chat all converge in unified inbox

**AC gaps:** No AC explicitly tests the handoff moment — i.e., that when staff opens a widget-originated conversation, they see full history including the AI-handled portion.

### WATCH-4: Super Admin Exclusive Capabilities

**Findings from extraction:**
- Create/manage partners and organizations (MASTER_SRS.md Section 3.2)
- Master billing management (MASTER_SRS.md Section 3.2)
- System-wide settings (MASTER_SRS.md Section 3.2)
- AI Configuration > Skills tab (DESIGNER_UPDATE_SPEC.md Section 6)
- Emergency kill switch (DESIGNER_UPDATE_SPEC.md Section 6)
- API Keys and Webhooks tabs in Settings (DESIGNER_UPDATE_SPEC.md Section 4)
- Data Management tile (DESIGNER_UPDATE_SPEC.md Section 1)
- Economy settings on tool cards (DESIGNER_UPDATE_SPEC.md Section 4)
- "Nexxus System" view in org switcher (===DevDesign Notes===.md line 37)
- Organization creation wizard (DESIGNER_UPDATE_SPEC.md Section 15)

**AC gaps:** No dedicated AC tests the full super_admin experience end-to-end. Many individual capabilities are covered but the aggregate is untested.

### WATCH-5: Context Router User-Visible Behavior

**Findings:**
- Context Router is below-the-line infrastructure. User-visible effects:
  - Data freshness: VIN leads cached 5 min, VAPI/Tavus 1 hour (MASTER_SRS.md Section 7.2)
  - Fallback: when VIN fails, cached data is used with staleness logged (not shown to user)
  - Source tags are internal only — never shown in UI
  - excel_upload records excluded from all queries (32+ queries across 11 files)
- User sees: correct numbers, no source labels, no stale-data indicators

**AC gaps:** No user-facing AC for Context Router (correct — it is below-the-line). But metric accuracy ACs (AC-R047, AC-R166) implicitly test its correctness.

---

## Conflicts Found

### CONFLICT-W4-1: Sidebar Navigation Order
- **MASTER_SRS.md Section 4.2** says: Main, Agents, Drive, Insights, Hub, Activity, Settings
- **===DevDesign Notes===.md line 129** says: Main, Insights, Agents, Hub, Drive
- **ARCHITECTURE_GUIDE.md Section 1.2** says: Main, Agents, Drive, Insights, Work Center, Activity, Settings, Profile
- **Impact:** Sidebar order is directly testable. These three sources disagree.
- **Resolution needed:** Owner decision on canonical order.

### CONFLICT-W4-2: Automa on Agents Page
- **MASTER_SRS.md Section 2.4, 5.3** says: "Automa is always at the top of the agents list"
- **===DevDesign Notes===.md line 187** says: "Automa will not be listed on the agent page anymore"
- **Impact:** Directly contradictory. Cannot write a stable AC without resolution.
- **Resolution needed:** Owner decision.

### CONFLICT-W4-3: Hub Tab Count
- **DESIGNER_UPDATE_SPEC.md** (Critical Clarification at top): Hub has exactly 3 tabs: Calendar, Leads, Inbox
- **MASTER_SRS.md Section 4.2** lists Hub subsections as: Messages, Calendar, Tasks, Approvals, Leads
- **app_identity.md Section B5** lists: Email, Text, Calendar, Tasks, Approvals
- **Impact:** DESIGNER_UPDATE_SPEC explicitly overrides older docs and is marked "final". But MASTER_SRS is a governing document.
- **Resolution needed:** Confirm DESIGNER_UPDATE_SPEC is authoritative for Hub tab structure. Tasks and Approvals may still exist as features but not as Hub tabs.

### CONFLICT-W4-4: Goals Section
- **Insights Layout.md** lists Goals as a sub-section of Insights
- **===DevDesign Notes===.md line 66** says: "Goals - Remove"
- **MASTER_SRS.md Section 5.5.3** describes Goals as active
- **Impact:** Unclear if Goals sub-tab exists in Insights.
- **Resolution needed:** Owner decision.

### CONFLICT-W4-5: Activity Location
- **MASTER_SRS.md Section 4.2** lists Activity as its own sidebar item
- **===DevDesign Notes===.md line 128** says: "We are going to move activity in to a sub-tab in insights"
- **Impact:** Is Activity a standalone page or an Insights sub-tab?
- **Resolution needed:** Owner decision.

### CONFLICT-W4-6: Insights Sub-Sections
- **MASTER_SRS.md Section 5.5** lists: Dashboard, Dealer Pulse, Goals, Hunches, Reports
- **Insights Layout.md / ===DevDesign Notes===.md** lists: Dashboard (3 sub-pages), Reports (3 sub-pages), Hunches. No Dealer Pulse, no Goals.
- **Impact:** Feature presence/absence on the Insights page.
- **Resolution needed:** Owner decision on Dealer Pulse placement.

---

## Missing AC (Gaps in Source Material)

### MISSING-W4-1: Billing UI Acceptance Criteria
No testable AC exists for the Billing page despite full specification in DESIGNER_UPDATE_SPEC.md Section 11. Payment-critical for business model.

### MISSING-W4-2: Knowledge Base Upload/Management
No AC covers the Knowledge Base settings tile (DESIGNER_UPDATE_SPEC.md Section 5). Users should be able to upload documents, add web pages, and see them reflected in Automa's knowledge.

### MISSING-W4-3: Data Management (Super Admin)
No AC covers the Data Management tile (DESIGNER_UPDATE_SPEC.md Section 9). This is a super_admin-only feature for data import/export.

### MISSING-W4-4: Profile Page
No AC covers the Profile page where users change profile information and password (app_identity.md Section B8).

### MISSING-W4-5: Tour System
===DevDesign Notes===.md line 40 says: "WE HAVE TO REMEMBER TO REACTIVATE THE TOUR AND SET IT UP WITH RBAC SO THE TOUR WORKS DIFFERENTLY DEPENDING ON THE ROLE." No AC exists.

### MISSING-W4-6: Communications Agent Default Behavior
No AC describes what the default communications agent does out of the box, how it's configured, or what happens if it's absent.

### MISSING-W4-7: Reactive After-Hours Phone Coverage
Session-knowledge.md Section 0c item 5 lists "reactive after-hours coverage" (SMS and phone) as payment-critical. SMS after-hours is covered (AC-R093) but voice after-hours routing has no explicit AC.

### MISSING-W4-8: Hunch Lifecycle Management
Hunches.md specifies lifecycle states (New -> Under Investigation -> Test in Progress -> Validated -> Implemented -> Monitoring) and a dashboard integration, but no AC exists for the user experience of managing hunch states.

### MISSING-W4-9: Embed Code Copy
No AC explicitly tests the "copy embed code" action in Widget Configuration. User should be able to copy and paste a working embed snippet.

### MISSING-W4-10: Search / Command Palette
ARCHITECTURE_GUIDE.md shows a Search (Cmd+K) entry in the sidebar. No AC tests this.

---

## Cross-Wave Notes

### For Wave 2 (SRS):
- The skills architecture (V1 27 agents -> V2 user-created agents with selectable skills) MUST be documented in SRS. It was explained 3+ times by owner but never captured in any file an agent reads (session-knowledge.md Section 0b).
- Context Router's 3-section model (Memory stores, Synch Data, Upload Data Store, Web/3rd party data store) from ===DevDesign Notes===.md line 41 needs SRS documentation.

### For Wave 3 (SPEC):
- Route mismatch for hosted pages: client fetches `/api/hosted-pages/public/${slug}`, server serves `/api/pages/:slug`. One-line fix needed (session-knowledge.md Section 5 P0).
- Insights crash: 4 unsafe `.pct` accesses at lines 854, 1293, 2142, 2143 (session-knowledge.md Section 5 P0).

### For Wave 5 (PLAN):
- Billing UI needs to be placed in the plan if it's launch-critical.
- Tour reactivation needs plan placement.
- 6 conflicts above need owner resolution before plan can be finalized.

---

## Source File Log

| File | Relevance | AC Extracted |
|------|-----------|-------------|
| -- Acceptance Criteria.md | HIGH | 13+ demo ACs + full Replit mockup spec |
| MASTER_SRS.md | HIGH | 19 numbered ACs (AC-001 through AC-019) + RBAC matrix + metrics spec |
| IMPLEMENTATION_PLAN.md | HIGH | Phase completion criteria, gap-specific ACs |
| ACCEPTANCE_VERIFICATION_REPORT.md | HIGH | 13/13 verification claims with caveats |
| UI_INTERACTIVE_ELEMENTS_MAP.md | HIGH | All interactive elements and handlers |
| DESIGNER_UPDATE_SPEC.md | HIGH | Settings tiles, RBAC visibility, billing, skills, new UI elements |
| CONSTITUTION.md | HIGH | Governing principles, rules, naming conventions |
| app_identity.md | HIGH | Platform identity, user workflows, layout types |
| ===DevDesign Notes===.md | HIGH | Owner's raw design intent, sidebar order, agent architecture |
| Insights Layout.md | HIGH | Full wireframe spec for Insights dashboard |
| Org admin Metrics.md | MEDIUM-HIGH | 4-tile score formulas for org_admin |
| Staff Metrics.md | MEDIUM-HIGH | 4-tile score formulas for staff |
| Hunches.md | MEDIUM | Agent prompt, lifecycle management spec |
| CLARIFICATION_ANSWERS.md | MEDIUM | Owner decisions on 20 questions |
| SRS Addendum v3.2 | MEDIUM | Widget, SMS, hosted pages, staff messaging specs |
| ARCHITECTURE_GUIDE.md | MEDIUM | Layout architecture, responsive breakpoints |
| UNIFIED_HANDOFF_PROMPT.md | MEDIUM | Document reading order, conflict resolution rule |
| DO_NOT_TOUCH.md | LOW | Backend freeze manifest (below-the-line) |
| session-knowledge.md | HIGH | Owner mental model, payment-critical items, confirmed P0s |
| Standards.md (other_notes) | MEDIUM | Owner's definition of AC vs SRS distinction |
| Reports.md | LOW | Report layout spec (covered by Insights Layout) |
| Tiles Available Data.md | LOW | Data dictionary (below-the-line metric source) |

---

## Summary Statistics

- **Total ACs extracted:** 98
- **Testable:** 98/98 (100%)
- **Explicit (directly stated):** 93
- **Inferred (derived):** 5
- **Conflicts found:** 6
- **Missing AC areas:** 10
- **Watch area flags:** 5 (all 5 addressed)

---

*End of Wave 4 Reviewer output.*
