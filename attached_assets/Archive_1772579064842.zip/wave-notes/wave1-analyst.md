# Wave 1 Analyst Report: Business Context for PRD
**Agent:** ANALYST
**Date:** 2026-03-02
**Files Analyzed:** 53 input files (all read)
**Output Purpose:** Extract PRD-relevant business context from all input files

---

## 1. Product Identity

### What Nexxus IS
- **AI orchestration layer** that bridges businesses, their data, third-party integrations, language models, and tools
  - Source: MASTER_SRS.md (line ~30), app_identity.md (Section A, line ~5)
- **Partner-enabled platform** where domain experts deliver AI to their industry verticals; NOT automotive-only
  - Source: app_identity.md (Section A, line ~15), CONSTITUTION.md (line ~20), session-knowledge.md (Section 0, line ~10)
- First vertical is automotive dealerships, but architecture is industry-agnostic
  - Source: MASTER_SRS.md (line ~45: "Nexxus is NOT automotive-specific"), app_identity.md (Section A)
- Platform operator: **Huminic** (company of owner Duane Wells)
  - Source: MASTER_SRS.md (Section 1, line ~15), REVERSE_SRS_old.md (line ~33)
- First partner: **Duran Cage** (automotive sales expert)
  - Source: session-knowledge.md (Section 0, line ~20), REVERSE_SRS_old.md (line ~33)

### What Nexxus is NOT
- NOT a CRM (it orchestrates CRM data from VIN Solutions, does not replace it)
  - Source: MASTER_SRS.md (line ~50), CONSTITUTION.md (line ~25)
- NOT a marketing automation tool
  - Source: MASTER_SRS.md (line ~50)
- NOT a content development platform
  - Source: MASTER_SRS.md (line ~50)

### Platform Mental Model (Owner-Stated, Previously Undocumented)
The owner describes Nexxus through two surfaces:
1. **External surfaces** facing customers: VAPI voice agents, Tavus video agents, Widgets (chat/SMS/callback)
2. **Internal surfaces** facing staff: Automa Chat (DealerBrain), Agents page, Metrics/Insights dashboard, Hub (Calendar/Leads/Inbox)
3. **Data flow layer**: VIN Solutions CRM data, internal PostgreSQL, user uploads, external service APIs
  - Source: session-knowledge.md (Section 0b, 0c, 0d — lines ~25-80)

### Core Value Proposition
Dealerships lose not because of lead volume but because of **response gaps and execution failures**. Nexxus fixes this through AI-powered voice, video, and chat interactions that ensure every lead gets timely, intelligent follow-up.
  - Source: CLAUDE.md (preflight-input version, line ~9), app_identity.md (Section C)

---

## 2. Target Customers

### Primary Customers (Live)
| Customer | Organizations | Status |
|----------|--------------|--------|
| Serra Automotive | Serra Honda of Sylacauga, Serra Nissan of Sylacauga, Tony Serra Ford | Live, paying |
| Hyundai of Columbia | Hyundai of Columbia, Ford of Columbia | Live, paying |
  - Source: CUSTOMER_ONBOARDING_KICKOFF.md (lines ~5-25), DEVELOPMENT_TEAM_BRIEFING.md (line ~170), DATA_ACCURACY_REPORT.md (lines ~55-62)

### Customer Profile
- Automotive dealerships (first vertical)
- Need: AI-powered customer interaction for response speed, not lead volume
- Architecture supports any B2B vertical through partner model
  - Source: app_identity.md (Section B), MASTER_SRS.md (Section 2)

### User Personas Within Customers
| Role | Who | Use Case |
|------|-----|----------|
| Org Admin | Dealership manager/owner | Configure agents, view metrics, manage staff |
| Org Staff | Sales person, BDC rep | Use chat, view assigned leads, respond to hunches |
  - Source: MASTER_SRS.md (Section 3, lines ~70-120), UI_DEVELOPER_HANDOFF.md (lines ~145-160)

### Onboarding Requirements Per Customer
11 items needed from customers, 5 decisions customers must make before go-live:
- VIN Solutions OAuth credentials, VAPI assistant configuration, phone numbers for SMS, business hours, widget embedding domains
  - Source: CUSTOMER_ONBOARDING_KICKOFF.md (lines ~30-80)

---

## 3. Business Model

### Revenue Model
B2B SaaS with **per-minute/per-message AI usage billing** plus platform subscription:

| Service | Customer Price | Nexxus Cost | Margin |
|---------|---------------|-------------|--------|
| Voice AI (VAPI) | $0.25/min | $0.15/min | 40% |
| Video AI (Tavus) | $0.32/min | $0.20/min | 37.5% |
| SMS (TextMagic) | $0.05/msg | $0.02/msg | 60% |
  - Source: MASTER_SRS.md (Section 12, lines ~700-720), CLAUDE.md (preflight, lines ~317-319), INIT_PROJECT_ANSWERS.txt (line ~49)

### Credit System
- CreditService tracks per-minute/per-message usage
- credit_policies table defines rates per org per service type
- credit_allocations track monthly budgets
- credit_usage records real-time consumption
- Wired to webhooks: VAPI call end and Tavus session end automatically record credits
  - Source: database-audit.md (tables 17-19, lines ~84-86), server-audit.md (line ~8 "CreditService"), DEVELOPMENT_TEAM_BRIEFING.md (line ~93)

### Partner Model
- Partners are domain experts who recruit customers into verticals
- Partners get multi-org access (Partner Admin role)
- Tool provisioning flows through partners: Super Admin provisions tools to org, partner manages org settings
  - Source: ARCHITECTURE_GUIDE_RBAC_ADDITION.md (lines ~1-50), app_identity.md (Section D)

### PAYMENT-CRITICAL DEMO TAG: Billing
- Billing page exists but is commented out as "PHASE-FUTURE" in profile.tsx
  - Source: client-audit.md (line ~94: "Billing tab commented out")
- DESIGNER_UPDATE_SPEC.md Section 11 specifies a NEW Billing Page with credit balance, usage charts, invoice history
  - Source: DESIGNER_UPDATE_SPEC.md (line ~41: "Billing Page (NEW)")
- Credit tracking is wired (backend complete), but no customer-facing billing UI exists yet

---

## 4. User Roles (RBAC)

### 4-Tier Role Hierarchy
| Level | Role | Scope | Key Capabilities |
|-------|------|-------|------------------|
| 1 | Super Admin | Platform-wide | Provision tools, manage partners, manage all orgs, system config, all settings access |
| 2 | Partner Admin | Multi-org (assigned) | Manage assigned orgs, view cross-org data, org switcher |
| 3 | Org Admin | Single org | Manage users, org settings, integrations, knowledge base |
| 4 | Org Staff | Single org (limited) | Use agents, view leads, respond to tasks, view insights (read-only) |
  - Source: MASTER_SRS.md (Section 3, lines ~70-120), CONSTITUTION.md (lines ~60-80), app_identity.md (Section D)

### RBAC Access Matrix (Settings Tiles)
| Tile | Super Admin | Partner Admin | Org Admin | Staff |
|------|:-----------:|:------------:|:---------:|:-----:|
| User Management | Yes | Yes | Yes | No |
| Organization | Yes | Yes | Yes | No |
| Tools & Integrations | Yes | Yes | Yes | No |
| Knowledge Base | Yes | Yes | Yes | No |
| AI Configuration | Yes | Read-Only | No | No |
| Security & Privacy | Yes | Yes | No | No |
| Notifications | Yes | Yes | Yes | No |
| Data Management | Yes | No | No | No |
| Appearance | Yes | Yes | Yes | No |
  - Source: DESIGNER_UPDATE_SPEC.md (lines ~80-98)

### Database Implementation
- roles table with 4 levels, permissions as JSONB
- users table with role_id FK, organization_id FK
- partner_admin_organizations junction table for multi-org assignment
- Server middleware: requireRole() enforces hierarchy
  - Source: database-audit.md (tables 3-5, lines ~69-72), server-audit.md (line ~49)

### WATCH AREA: Super Admin Functionality
- Super Admin (Huminic) is the platform operator. Only one exists.
- Super Admin provisions tools to orgs, manages partners, has system-wide visibility
- Some Super Admin capabilities are referenced but implementation status varies
  - Source: app_identity.md (Section D), CONSTITUTION.md (lines ~60-80)

---

## 5. Feature Inventory

### Navigation Structure (8 Main Items)
| # | Item | Route | View Mode | Access |
|---|------|-------|-----------|--------|
| 1 | Main (Automa Chat) | / or /chat | Chat Only (A) | All |
| 2 | Agents | /agents | Heavy Chat Work (D) | All |
| 3 | Drive | /drive | Data Display (B) | All |
| 4 | Insights | /insights | Data Display (B) | All |
| 5 | Hub (Work Center) | /work-center | Sub Menu (C) | All |
| 6 | Activity | /activity | Data Display (B) | Org Admin+ |
| 7 | System (Settings) | /settings/system | Sub Menu (C) | Admin roles |
| 8 | Profile | /profile | Sub Menu (C) | All |
  - Source: ARCHITECTURE_GUIDE.md (Section 1.3, lines ~102-258), UI_DEVELOPER_HANDOFF.md (lines ~50-65)

### 5 Layout Types
| Type | Name | Use |
|------|------|-----|
| A | Chat Only | Main page (center only, no right pane) |
| B | Data Display | Insights, Drive, Activity (filters + data + chat) |
| C | Sub Menu | Settings, Hub (tabs + forms + chat) |
| D | Heavy Chat Work | Agents (list + chat + artifacts) |
| E | Dashboard | Dashboard metrics (tiles + widgets) |
  - Source: ARCHITECTURE_GUIDE.md (Section 1.5, lines ~309-394), app_identity.md (Section H, line ~130)

### Core Feature Areas

#### Automa Chat (DealerBrain)
- AI command palette (previously "DealerBrain", now branded "Automa")
- Claude API with tool calling, SSE streaming
- 24 tools available to DealerBrain
- Accessible from main page (center pane) and as floating overlay on other pages
- **PAYMENT-CRITICAL DEMO TAG: Automa Chat**
  - Source: ===DevDesign Notes===.md (line ~55: "Automa aka dealer brain"), DEVELOPMENT_TEAM_BRIEFING.md (line ~91), Acceptance Criteria.md (lines ~20-30)

#### Agents System
- V2 architecture: user-created agents with selectable skills from a catalog
- V1 had 27 hardcoded agents + super chat; V2 moves to skills-based model
- Agent types: voice, video, chat, email, task
- Agent CRUD with org isolation
- Skills catalog (64+ skill templates referenced)
- **PAYMENT-CRITICAL DEMO TAG: Comms Agent Configuration**
  - Source: session-knowledge.md (Section 0 — V1-to-V2 transition), ARCHITECTURE_GUIDE.md (lines ~122-138), DESIGNER_UPDATE_SPEC.md (Section 12, line ~180+)

#### Insights Dashboard
- Dashboard tab with metric tiles: DealershipPulse, GoalProgress, LeadFeed, AgentActions, TeamLeaderboard
- 4 tabs per DevDesign Notes: Dashboard, Reports, Library, Hunches (Goals removed from Insights, moved elsewhere)
- 3-zone alert system: Red (action required), Yellow (watchlist), Green (performing)
- 80+ computable metrics across 14 categories
- **PAYMENT-CRITICAL DEMO TAG: Metrics/Insights**
  - Source: ===DevDesign Notes===.md (lines ~15-30), Insights Layout.md (lines ~1-50), Tiles - Available data.md (entire file), Org admin Metrics.md, Staff Metrics.md

#### Hub (Work Center)
- **3 tabs per owner decision: Calendar, Leads, Inbox** (NOT 4 or 5)
  - Source: DESIGNER_UPDATE_SPEC.md (lines ~9-13: "Hub has exactly 3 tabs: Calendar, Leads, Inbox")
  - CONFLICT: ARCHITECTURE_GUIDE.md (line ~190-198) and UI_DEVELOPER_HANDOFF.md (line ~56) list 5 items: Messages, Calendar, Tasks, Hunches, Approvals. The DevDesign Notes and DESIGNER_UPDATE_SPEC override this.
- Calendar with appointment CRUD, drag-drop rescheduling
- Leads management with status workflows
- Unified inbox merging SMS + widget chat + email
- **PAYMENT-CRITICAL DEMO TAG: Appointment Flow**
  - Source: CLARIFICATION_ANSWERS.md (Q8, line ~65: "Hub = Work Hub = unified inbox, yes exactly")

#### Widgets
- Embeddable customer-facing widgets: 6 channel options
- textChat, videoAgent, callUs, callYou, webAudio, sendText
- Master Widget config + per-org hosted landing pages
- 50.13KB Preact-based bundle
- Domain whitelist enforcement
- **PAYMENT-CRITICAL DEMO TAG: Widgets**
  - Source: ACCEPTANCE_VERIFICATION_REPORT.md (AC-6, lines ~66-71), CLARIFICATION_ANSWERS.md (Q14: "6 widget options confirmed")

#### Triggers
- Rule engine for automated actions based on lead events
- 7 event types: new_lead, lead_status_change, missed_call, appointment_scheduled, inbound_message, hot_lead, custom
- 5 action types: outbound_call, send_sms, send_email, create_task, webhook
- Rate limiting per trigger rule, business hours checking
- **PAYMENT-CRITICAL DEMO TAG: Proactive Lead Follow-up / Reactive After-Hours**
  - Source: ACCEPTANCE_VERIFICATION_REPORT.md (AC-5, AC-11), MASTER_SRS.md (Appendix A: 13 triggerable events)

#### Drive (File Management)
- Folder hierarchy with file upload/download
- Grid/list view toggle, breadcrumb navigation
- Storage usage display
  - Source: ARCHITECTURE_GUIDE.md (lines ~143-157), client-audit.md (line ~92)

#### Settings (16+ tabs, role-gated)
- 9 setting tiles per DESIGNER_UPDATE_SPEC (reduced from 10)
- User Management, Organization, Tools & Integrations, Knowledge Base, AI Configuration, Security & Privacy, Notifications, Data Management, Appearance
- Tools & Integrations reworked to 5-7 tabs (MCP, API, Other, Widgets, Landing Pages + API Keys, Webhooks for Super Admin)
  - Source: DESIGNER_UPDATE_SPEC.md (Sections 1-10), client-audit.md (line ~91)

#### Reports
- 6 report specifications: Deal Death Autopsy, Lead Source Quality, Channel Performance, Pipeline Velocity, Active Lead Triage, Deal Status Snapshot
- All declared "100% buildable" from available VIN data
  - Source: Reports.md (entire file, lines ~1-200)

#### Hunches
- AI detective agent generating cross-dimensional insights
- Pattern detection across time, segmentation, quality, and hidden opportunity dimensions
- Accept/dismiss workflow with feedback loop
  - Source: Hunches.md (entire file), Hunch Instructions.md (entire file — same content)

---

## 6. External Interaction Surfaces

### VIN Solutions CRM
- OAuth 2.0 Client Credentials flow with encrypted token storage
- Token refresh every 6 hours (automated background job)
- **Accessible endpoints (13):** Leads (CRUD), Contacts (CRUD), Lead Sources, Lead Types, Lead Statuses, Lead Groups, CRM Users
- **Blocked endpoints (17, return 403):** Deals/Desking, Appointments, Inventory, Trade-ins, Tasks, Phone calls, Email history
- Lead creation is 2-step: create contact (gateway POST) -> create lead with href references
- Header casing critical: lowercase `v3` required (prod rejects uppercase)
  - Source: DEVELOPMENT_TEAM_BRIEFING.md (lines ~20-58), VIN_SOLUTIONS_INTEGRATION.md (entire file), MASTER_SRS.md (Section 6)

### VAPI (Voice AI)
- Master API key with assistants tagged with org metadata
- Webhook: call end -> org resolution -> lead extraction -> credit recording -> notifications
- 15 API endpoints documented
- 18 total assistants on VAPI account, 5 registered in V2 agents table
- **Critical data finding:** Real-time webhook ingestion was broken — all 137 real call records were bulk imported, not created by webhooks
  - Source: DATA_ACCURACY_REPORT.md (lines ~98-100), server-audit.md (line ~5), MASTER_SRS.md (Section 6)

### Tavus (Video AI)
- Master API key with personas tagged with org metadata
- Webhook: session end -> HMAC verification -> processing
- 10 API endpoints documented
  - Source: MASTER_SRS.md (Section 6), server-audit.md (line ~5)

### TextMagic (SMS)
- Two-way SMS: send and receive
- Phone format: E.164 required (+ prefix)
- AI auto-reply using Claude Haiku with conversation states: DORMANT -> AI_ACTIVE -> HUMAN_ACTIVE
- Business hours checking per org
- Shared phone number across orgs (first DB match wins routing)
- Credentials stored in DB per org (NOT env vars) — uses textmagic_config table
  - Source: ACCEPTANCE_VERIFICATION_REPORT.md (AC-2, lines ~40-46), session-knowledge.md (Section 0d), CLARIFICATION_ANSWERS.md (Q12)

### Resend (Email)
- Transactional email delivery
- Used for: welcome emails, password resets, notification routing
- Email templates stored in database
  - Source: server-audit.md (line ~54), database-audit.md (tables 33-35)

### Google Calendar
- OAuth integration for appointment sync
- Connect/disconnect/sync/toggle in profile preferences
  - Source: client-audit.md (line ~94)

### MCP Proxy (Central-MCP)
- Located at ../central-mcp/ (port 4002)
- MCP proxy for Notion/Supabase/ClickUp/VAPI
- No TextMagic connector exists yet (connector pattern ready)
- Owner intended to route TextMagic through this proxy but never integrated
  - Source: session-knowledge.md (Central-MCP section, line ~95+)

---

## 7. Internal Interaction Surfaces

### DealerBrain/Automa
- Claude API integration with 24 tool-calling capabilities
- SSE streaming for real-time response delivery
- Conversation history stored in conversations/messages tables
- Tools include: VIN data queries, lead management, appointment booking, SMS sending, metric lookups
- Context Router determines data source priority: VIN API primary, local DB fallback
  - Source: DEVELOPMENT_TEAM_BRIEFING.md (line ~91), MASTER_SRS.md (Section 7: Context Router), CLARIFICATION_ANSWERS.md (Q2)

### WATCH AREA: Context Router
- Decides where DealerBrain gets data: VIN API vs local DB vs derived metrics
- Was initially inverted (local first) — corrected to VIN API primary
- Controlled by env var CONTEXT_ROUTER_ENABLED=true
- Owner deferred Context Router details to dev phase (CLARIFICATION_ANSWERS.md Q2)
  - Source: DEVELOPMENT_TEAM_BRIEFING.md (line ~79), CLARIFICATION_ANSWERS.md (Q2), MASTER_SRS.md (Section 7)

### Notification System
- In-app notifications with bell icon badge
- Email notifications via Resend
- SMS notifications via TextMagic
- Notification settings per user per channel per event type
- Idempotency via notification_sent flag on vapi_call_logs
  - Source: database-audit.md (tables 37-38), server-audit.md (line ~18)

### Activity/Governance Feed
- AI usage tracking: tokens, tool invocations, duration
- Activity feed with filtering and pagination
- CSV export for admins
  - Source: client-audit.md (line ~93), database-audit.md (table 53: ai_usage_events)

### WATCH AREA: Unified Inbox Handoff
- Hub's Inbox tab merges SMS, widget chat, and email into single view
- InboxPanel component handles channel merging
- inbox_conversations and inbox_messages tables handle storage
- Compose functionality via ComposeEmailModal with Tiptap rich-text editor
  - Source: client-audit.md (line ~90: work-center.tsx), database-audit.md (tables 48-49)

---

## 8. Data Sources

### Truth Hierarchy (Data Priority)
1. VIN Solutions API (external source of truth for CRM data)
2. VAPI/Tavus webhooks (event data from AI interactions)
3. Local PostgreSQL database (Nexxus internal data)
4. Derived metrics (calculated from above sources)
  - Source: CONSTITUTION.md (line ~30), MASTER_SRS.md (Section 7)

### Database (PostgreSQL via Supabase)
- 53 tables defined across 33 migrations
- 100+ RLS policies enforcing multi-tenant isolation via app.current_org_id
- 160+ indexes
- Key JSONB columns: organizations.settings, users.settings, agents.config, leads.metadata
  - Source: database-audit.md (entire file), health-audit.md (lines ~20-28)

### VIN Solutions Data (What We Actually Have)
- Leads (CRUD) + Contacts (CRUD) + Sources + Types + Statuses + Groups + CRM Users
- **Cannot access:** Deals, Desking, Appointments (VIN side), Inventory, Trade-ins, Tasks, Phone calls, Email history
- This means: Nexxus sees beginning (lead creation) and end (SOLD/LOST status) but NOT the middle (deals, follow-ups, execution)
  - Source: DEVELOPMENT_TEAM_BRIEFING.md (lines ~24-36), DATA_SOURCE_INVENTORY.md (lines ~1-100)

### Field Population Reality
- 100-record field audit conducted
- Many VIN fields are sparsely populated (sellingPrice, downPaymentRequested, monthlyPaymentRequested often null)
- >50% field fill rate required per Constitution
  - Source: docs-audit.md (lines ~56-57: "field-population-audit.json"), CONSTITUTION.md (line ~85)

### Webhook Data
- VAPI: call transcripts, summaries, recording URLs, end-of-call reports, duration
- Tavus: session transcripts, engagement scores, lead extraction results
- **Critical finding:** VAPI webhook ingestion was broken as of audit date — 697 calls missing from local DB
  - Source: DATA_ACCURACY_REPORT.md (lines ~18-19, ~98-100)

---

## 9. Key Business Rules

### Data Accuracy is Non-Negotiable
- Metrics must be verified against external sources
- Excel upload records MUST be excluded from all lead metrics (32+ queries affected)
- Source labels mask vendor names: "vapi_voice" -> "Voice Agent"
  - Source: CONSTITUTION.md (Principle 4: "Data accuracy over features"), DEVELOPMENT_TEAM_BRIEFING.md (lines ~83-84)

### Multi-Tenancy Isolation
- Every query scoped to organization via RLS
- Cross-tenant data access architecturally prevented
- Organization context set on every request via JWT -> middleware -> SET config
- **Known risk:** RLS variable name mismatch (app.current_organization_id in SecureQueryBuilder vs app.current_org_id in policies) — works only because routes bypass SecureQueryBuilder
  - Source: DEVELOPMENT_TEAM_BRIEFING.md (lines ~62-76), CONSTITUTION.md (line ~90)

### Non-Destructive Operations
- Soft deletes preferred (status=inactive, not DELETE)
- Audit logging for all sensitive operations
- No cascading deletes without explicit approval
  - Source: CONSTITUTION.md (Principle 5: "Non-destructive operations")

### Certification Over Credit
- Features must be verifiable, not just claimed
- 3-proof validation: Configuration test, Functional test, Visual/E2E test
  - Source: CONSTITUTION.md (Principle 6), CLAUDE.md (preflight, lines ~143-149)

### Backend Freeze
- 345+ files in server/, database/, scripts/ are frozen
- Only client/ directory safe to modify in current development cycle
- Webhook handlers, scheduled jobs, middleware must not be modified
  - Source: DO_NOT_TOUCH.md (entire file — 345+ frozen files), INIT_PROJECT_ANSWERS.txt (lines ~55-59)

### VIN Solutions API Rules
- Lead creation requires href references, NOT string names
- Two-step process: create contact -> create lead with contact href
- Header casing: lowercase v3 only
- dealerId in query param, not body
- Bearer tokens expire every 60 minutes — caching implemented
  - Source: DEVELOPMENT_TEAM_BRIEFING.md (lines ~40-58), VIN_SOLUTIONS_INTEGRATION.md (lines ~40-75), CLAUDE.md (preflight, lines ~79-84)

### Excel Upload Exclusion
- Records imported via excel upload were polluting all metrics
- Filter `source != 'excel_upload'` required on ALL lead queries
- 32+ queries across 11 files already fixed
  - Source: DEVELOPMENT_TEAM_BRIEFING.md (lines ~82-84)

---

## 10. Competitive Positioning

### Differentiation
- AI-first platform (not CRM with AI bolted on)
- Partner delivery model (domain experts recruit and manage customers)
- Multi-modal AI: voice + video + chat + SMS (not just one channel)
- Orchestration layer that works WITH existing CRM (VIN Solutions), not replacing it
  - Source: MASTER_SRS.md (Section 2), app_identity.md (Section A, C)

### Current Competition Context
- Dealerships use VIN Solutions (Cox Automotive) as CRM
- No direct competitor offers unified AI voice + video + chat orchestration for automotive
- Traditional BDC (Business Development Center) is human-staffed; Nexxus automates this
  - Source: app_identity.md (Section C), session-knowledge.md (Section 0)

### Unique Selling Points
1. Response gap elimination — AI ensures no lead goes unanswered
2. Multi-channel AI (voice, video, chat, SMS) unified under one platform
3. Partner model enables vertical specialization without Huminic needing domain expertise
4. White-label capability (org branding limited to logo + 2 colors)
  - Source: THEME_CONTRACT.md (lines ~20-37), app_identity.md (Section A, C)

---

## 11. Payment-Critical Demo Items

These 7 items are flagged throughout the analysis as payment-critical for customer acceptance:

### DEMO-1: Metrics/Insights
- 4 org admin tiles (Pipeline Health, Lead Source Performance, Lead Quality, Market Demand Insight) each with 0-100 scores
- 4 staff tiles (Hot Opportunities, Customer Buying Patterns, Competitive Threat Alert, Pipeline Urgency)
- 6 buildable reports
- 3-zone alert system (Red/Yellow/Green)
- **Risk:** VAPI webhook ingestion was broken — call metrics may be incomplete
  - Source: Org admin Metrics.md, Staff Metrics.md, Reports.md, DATA_ACCURACY_REPORT.md

### DEMO-2: Comms Agent Configuration
- Skills-based agent creation (V2 architecture)
- 5 channel types: voice, video, chat, email, task
- Agent CRUD with org isolation
- Skills catalog with 64+ templates
- **Risk:** V1-to-V2 transition means old hardcoded agents need migration to skills model
  - Source: session-knowledge.md (Section 0), DESIGNER_UPDATE_SPEC.md (Section 12, 16)

### DEMO-3: Appointment Flow
- Calendar CRUD with drag-drop rescheduling
- AppointmentService with RBAC
- Appointment reminders (SMS/email)
- **Risk:** AC-9 noted 0 video agents in production (migration 033 may not be applied); appointment notification events not firing (known P0)
  - Source: ACCEPTANCE_VERIFICATION_REPORT.md (AC-9, line ~87), known_issues.md.md (line ~11)

### DEMO-4: Proactive Lead Follow-up
- Trigger rules firing outbound calls via VAPI when conditions met (new_lead, hot_lead, etc.)
- **Risk:** AC-5 showed 0/84 trigger executions completed (45 failed, 39 skipped). Triggers may not be activating.
  - Source: ACCEPTANCE_VERIFICATION_REPORT.md (AC-5, line ~63), DEVELOPMENT_TEAM_BRIEFING.md (lines ~158-164)

### DEMO-5: Reactive After-Hours Coverage
- Business hours checking per org timezone
- AI auto-reply for SMS outside business hours
- Trigger rules with business_hours_only flag
  - Source: database-audit.md (table 63: sms_conversation_state), ACCEPTANCE_VERIFICATION_REPORT.md (AC-11)

### DEMO-6: Widgets
- 6 channel options confirmed: textChat, videoAgent, callUs, callYou, webAudio, sendText
- Master Widget config + per-org hosted landing pages (5 deployed slugs)
- 50.13KB Preact bundle with domain whitelist
- **Known P0:** Hosted pages route mismatch (client fetches /api/hosted-pages/public/:slug, server serves /api/pages/:slug) — one-line fix
  - Source: ACCEPTANCE_VERIFICATION_REPORT.md (AC-6, AC-7), known_issues.md.md (line ~9)

### DEMO-7: Automa Chat
- DealerBrain renamed to Automa for customer-facing branding
- Claude API with 24 tools, SSE streaming
- Floating overlay on all pages (not inline on dashboard)
- Conversation history, favorites, suggested prompts
  - Source: ===DevDesign Notes===.md (line ~55), ACCEPTANCE_VERIFICATION_REPORT.md (AC-1)

---

## 12. Watch Areas

### WATCH-1: Agent Functionality/Defaults
- V1 had 27 hardcoded agents; V2 has user-created agents with skills
- This architectural transition is the single biggest knowledge gap — it was "in the owner's head, not in any file" until session-knowledge.md documented it
- Skills catalog (64+ templates) referenced but implementation details sparse in input files
- Agent seeding happens on first load (client-audit.md line ~87)
- **Risk:** Any agent working on this needs to understand V1->V2 transition or will make same mistakes as Run 2
  - Source: session-knowledge.md (Section 0), DEVELOPMENT_TEAM_BRIEFING.md (lines ~87-98)

### WATCH-2: Billing
- Credit system fully wired in backend (CreditService, credit_policies, credit_allocations, credit_usage tables)
- No customer-facing billing UI exists (commented out as PHASE-FUTURE)
- DESIGNER_UPDATE_SPEC specifies new Billing Page design
- Economics model defined but UI not built
  - Source: client-audit.md (line ~94), DESIGNER_UPDATE_SPEC.md (Section 11)

### WATCH-3: Unified Inbox Handoff
- Hub Inbox merges SMS + widget chat + email
- Owner confirmed Hub = Work Hub = unified inbox (CLARIFICATION_ANSWERS Q8)
- Tab count changed from 5 (Calendar, Tasks, Hunches, Approvals, Messages) to 3 (Calendar, Leads, Inbox)
- Multiple documents still reference old 5-tab structure
  - Source: DESIGNER_UPDATE_SPEC.md (lines ~9-13), CLARIFICATION_ANSWERS.md (Q8)

### WATCH-4: Super Admin Functionality
- Only one Super Admin exists (Huminic)
- Super Admin provisions tools, manages partners, has system-wide access
- AI Configuration tabs: System Prompt, Agent Behavior, Skills, Hunches, Emergency kill switch — all Super Admin only (Partner Admin gets read-only on some)
- Data Management is Super Admin only
  - Source: DESIGNER_UPDATE_SPEC.md (lines ~86-98), app_identity.md (Section D)

### WATCH-5: Context Router
- Decides VIN API vs local DB vs derived metrics for DealerBrain queries
- Was inverted (local first); corrected to VIN API primary
- Owner deferred detailed Context Router spec to dev phase
- CONTEXT_ROUTER_ENABLED env var controls behavior
  - Source: CLARIFICATION_ANSWERS.md (Q2), DEVELOPMENT_TEAM_BRIEFING.md (line ~79)

---

## 13. Conflicts Detected

### CONFLICT-1: Hub Tab Count
- **Source A:** ARCHITECTURE_GUIDE.md (line ~190) and UI_DEVELOPER_HANDOFF.md (line ~56) list 5 Work Center items: Messages, Calendar, Tasks, Hunches, Approvals
- **Source B:** DESIGNER_UPDATE_SPEC.md (line ~11) explicitly states: "Hub has exactly 3 tabs: Calendar, Leads, Inbox. Any older document that mentions 4 Hub tabs is WRONG and contaminated."
- **Source C:** ===DevDesign Notes===.md (lines ~60-70) references Hub with "quick actions" and Calendar/Leads/Inbox structure
- **Resolution:** DESIGNER_UPDATE_SPEC.md is newer (2026-02-22) and explicitly overrides. Hub = 3 tabs.

### CONFLICT-2: Navigation Item "Activity" vs "AI Governance"
- **Source A:** ARCHITECTURE_GUIDE.md (line ~203) calls it "Activity" with route `/activity`
- **Source B:** client-audit.md (line ~93) describes activity.tsx as "AI Governance page" with stats cards, activity feed, artifacts tab
- **Note:** Same page, different emphasis. Route is /activity, content is governance-focused.

### CONFLICT-3: Insights Tab Structure
- **Source A:** Older docs (ARCHITECTURE_GUIDE.md line ~166) describe Insights as having "Insight Engine" and "Goals" in popout
- **Source B:** ===DevDesign Notes===.md (lines ~15-30) restructures Insights to: Dashboard, Reports, Library, Hunches — "Goals removed"
- **Source C:** client-audit.md (line ~86) shows current implementation has 6 tabs: Dashboard, Goals, Reports, Attribution, Hunches, Dealer Pulse
- **Resolution:** DevDesign Notes represents owner's latest intent. Current implementation may not match.

### CONFLICT-4: Table Count
- **Source A:** CLAUDE.md (preflight) states "36 tables"
- **Source B:** database-audit.md (line ~131) documents 53 CREATE TABLE statements across migrations
- **Resolution:** 53 is the verified count. CLAUDE.md is stale.

### CONFLICT-5: Endpoint Count
- **Source A:** CLAUDE.md states "119 endpoints"
- **Source B:** health-audit.md (line ~24) states 237 endpoints
- **Source C:** server-audit.md (line ~35) states ~185 from route files
- **Resolution:** 237 is the health audit count; ~185 from route file analysis. CLAUDE.md figure is stale.

### CONFLICT-6: Test Count
- **Source A:** CLAUDE.md (line ~171) states "376/379 passing"
- **Source B:** health-audit.md (line ~23) states 747 E2E test cases
- **Resolution:** 747 is the current count. CLAUDE.md references older count.

### CONFLICT-7: Insights Goals Feature Location
- **Source A:** UI_DEVELOPER_HANDOFF.md (line ~118) shows /insights/goals route
- **Source B:** ===DevDesign Notes===.md explicitly removes Goals from Insights
- **Resolution:** Owner intent (DevDesign Notes) moves Goals elsewhere. Implementation still has it in Insights.

### CONFLICT-8: Work Center Route Name
- **Source A:** Most docs use "Work Center" at /work-center
- **Source B:** Owner and DESIGNER_UPDATE_SPEC use "Hub"
- **Source C:** CLARIFICATION_ANSWERS.md Q8: "Hub = Work Hub = unified inbox, yes exactly"
- **Resolution:** Same feature, different names. Owner prefers "Hub." Route may remain /work-center technically.

### CONFLICT-9: Frontend Framework
- **Source A:** ARCHITECTURE_VISUAL_MAP.md (line ~31) references "Next.js 14 App Router" and "Zustand"
- **Source B:** Actual stack is Vite + React 18 + Wouter + TanStack Query (no Next.js, no Zustand)
- **Resolution:** ARCHITECTURE_VISUAL_MAP.md is aspirational/outdated. Actual stack per client-audit.md and CLAUDE.md is correct.

### CONFLICT-10: Agent Architecture Vision vs Reality
- **Source A:** ARCHITECTURE_VISUAL_MAP.md describes 7-layer architecture with "Daria" system agent, "AutoDealer/ConvoAgent/InsightAgent" specialized agents, "Context Router/Orchestrator/Operator" coordination layer
- **Source B:** Actual implementation has DealerBrain (single AI service with tool calling), no named specialized agents, basic Context Router
- **Resolution:** Visual map is design vision, not current implementation. PRD should note the gap.

---

## 14. Missing Information

### MISSING-1: Partner Economics
- How partners are compensated is not defined in any input file
- Revenue sharing model, commission structure, or fee schedule: absent
- **Impact on PRD:** Business model section incomplete without partner economics

### MISSING-2: Subscription Pricing
- Per-minute AI usage is documented, but base platform subscription price is not
- No pricing tiers defined (starter, professional, enterprise)
- **Impact on PRD:** Revenue model section needs this

### MISSING-3: Customer Success Metrics / KPIs
- No defined success metrics for customer value (e.g., "reduce response time by X%", "increase lead conversion by Y%")
- The 5 original ACs (AC-1 through AC-5 in CLAUDE.md) defined capabilities, not outcomes
- **Impact on PRD:** Competitive positioning and success criteria sections need measurable outcomes

### MISSING-4: Onboarding Flow for New Verticals
- Partner model claims industry-agnostic design, but no documentation exists for adding a non-automotive vertical
- VIN Solutions integration is deeply automotive-specific
- **Impact on PRD:** Platform identity as "not automotive-only" needs reconciliation with current automotive-only integrations

### MISSING-5: Disaster Recovery / Data Backup
- No documentation on backup strategy, failover, or disaster recovery
- Single Oracle Cloud server running PM2
- **Impact on PRD:** Non-functional requirements section

### MISSING-6: API Rate Limits
- VIN Solutions rate limits not documented (just that tokens expire every 60 min)
- VAPI and Tavus rate limits not documented
- TextMagic rate limits not documented
- **Impact on PRD:** External integration surface section needs this for accurate capacity planning

### MISSING-7: Video Agent Details
- AC-9 noted 0 video agents in production (migration 033 creates them but may not be applied)
- Tavus persona configuration process not documented in input files
- **Impact on PRD:** Feature inventory for video agents is incomplete

### MISSING-8: Skills Catalog Content
- 64+ skill templates referenced but no list of specific skills exists in input files
- DESIGNER_UPDATE_SPEC.md Section 16 specifies "Skills Catalog (NEW)" but content not provided
- **Impact on PRD:** Agent architecture section needs skill inventory

### MISSING-9: DealerBrain Tool List
- "24 tools" referenced but complete list not in input files
- Tools mentioned include: VIN queries, lead management, appointments, SMS, metrics — but not enumerated
- **Impact on PRD:** Internal interaction surfaces section needs complete tool inventory

### MISSING-10: Competitive Analysis
- No formal competitive analysis document exists
- No named competitors identified
- **Impact on PRD:** Competitive positioning section is based on inferred differentiation, not market research

### MISSING-11: Legal/Compliance Requirements
- TCPA compliance for SMS not explicitly addressed
- Call recording consent requirements not documented
- Data retention policies not defined
- **Impact on PRD:** Compliance section needed

### MISSING-12: Scalability Plan
- Current architecture is single-server (Oracle Cloud + PM2)
- No documentation on horizontal scaling, load balancing, or multi-region deployment
- **Impact on PRD:** Growth strategy section

---

## End of Wave 1 Analyst Report

**Files Read:** All 53 input files plus 5 in other_notes/ subfolder
**Total Findings:** 10 PRD categories extracted, 7 payment-critical items tagged, 5 watch areas documented, 10 conflicts detected, 12 missing information items identified
**Confidence Level:** HIGH for categories 1-9 (well-documented across multiple sources), MEDIUM for category 10 (competitive positioning inferred, not explicitly documented)
