# Diff Agent B — Claims vs Wave Analysis
**Date:** 2026-03-03
**Agent:** Diff Agent B
**Purpose:** Cross-reference all existing gap/blocker claims against wave analysis findings. Classify each claim and flag new gaps.

**Source files read:**
- release_criteria.md — `/home/ubuntu/Claude-store/nexxus-v2/filestore/final_testing_kit/release_criteria.md`
- FINAL_REPORT.md — `/home/ubuntu/Claude-store/nexxus-v2/evidence/FINAL_REPORT.md`
- verified-findings.md — `/home/ubuntu/Claude-store/Nexxus_workbench/verified-findings.md`
- failure-analysis.md — `/home/ubuntu/Claude-store/Nexxus_workbench/failure-analysis.md`
- wave1-reconciled.md through wave6-reconciled.md — `/home/ubuntu/Claude-store/Nexxus_workbench/wave-notes/`

---

## SECTION 1: Existing Claims Audit

This section covers every claimed gap in release_criteria.md (P0 and P1 sections), FINAL_REPORT.md P0 defect register, and verified-findings.md. Every item receives a verdict.

---

### PART A: release_criteria.md — P0 Section

---

### RC-P0-1: GAP-B1-IDLE-001
**Source:** release_criteria.md, Section 1 (P0), line 42
**Claim:** 15-min idle trigger missing. IdleLeadChecker job, lead_idle event, dual-action rules, dedup — all built and deployed. Marked FIXED.
**Wave Assessment:** VALID (status: FIXED is accurate)
**Evidence:** Wave 1 reconciled, DEMO-4: "Neglected Lead Auto-Call template ready. TriggerService with outbound call via VAPI POST /call." Wave 5 reconciled, P0 section: Both agents confirm the idle trigger code exists. IdleLeadChecker job runs every 60 seconds, 15-minute threshold, max 3 retries, dedup via hasActiveConversation(). However, wave 5 flags a related P0 (P0-4): "Zero production trigger executions — all 84 executions are E2E test artifacts." The trigger code is FIXED but zero completions in production. The FIXED status in release_criteria.md is accurate for the code fix but does not account for the runtime execution gap.
**Notes:** The code fix is real. The runtime gap (P0-4) is a separate finding — see NEW GAP NW-P0-4.

---

### RC-P0-2: GAP-B1-PERSONA-001
**Source:** release_criteria.md, Section 1 (P0), line 43
**Claim:** VAPI agent name, Tavus persona name, widget display name, SMS sender name — all must match org persona. Marked FIXED with caveat: external VAPI and Tavus dashboards need manual verification.
**Wave Assessment:** VALID (partially — code FIXED, external verification still needed)
**Evidence:** Wave 1 reconciled, DEMO-3 and WATCH-1: "12 active agents in production: 5 voice, 2 chat, 4 task. 0 video (operational gap)." Wave 5 reconciled: "All 5 orgs have persona_name populated. Seed uses persona_name." The wave agents agree persona is wired in the platform. The FIXED-with-caveat status is accurate.
**Notes:** External dashboards (VAPI and Tavus) still need manual verification. This is correctly flagged in the FIXED note.

---

### RC-P0-3: GAP-B2-HOSTED-001
**Source:** release_criteria.md, Section 1 (P0), line 44. Also verified-findings.md FINDING F2.
**Claim:** Public hosted pages return 404 (route mismatch). Marked FIXED: public /p/:slug renderer created, hosted-pages-public.ts added.
**Wave Assessment:** DISPUTED — FIXED status is contested
**Evidence:** Wave 1 reconciled, DEMO-6: "Known P0 (both agents): Hosted pages route mismatch (client fetches /api/hosted-pages/public/:slug, server serves /api/pages/:slug). One-line fix." Wave 3 reconciled, Section 4.5 and CONFLICT C10: "Client code: /api/hosted-pages/public/${slug} | Server code: /api/pages/:slug | Confirmed P0 bug — route mismatch. 1-line fix." Wave 5 reconciled, P0-1: "CONFIRMED (both agents) — hosted-page-public.tsx:163 vs routes.ts:175." Verified-findings.md F2 (code-verified): "The client and server paths don't match. Fix: change client fetch to /api/pages/${slug}." The wave analysis, verified-findings, and FINAL_REPORT all agree the route mismatch exists in code. Release_criteria.md claims it is FIXED but verified-findings.md (F2) states the fix is incomplete: "This was marked FIXED in release_criteria.md but the fix is incomplete. The route was created but the client points to the wrong path." The FIXED status in release_criteria.md appears to describe creating the server endpoint, not aligning the client path.
**Notes:** This is the single gap confirmed by both Run 1 and Run 2, and independently verified against source code. The FIXED marking is inaccurate. Actual status: the server-side endpoint exists but the client-side fetch URL has not been corrected. One line fix remains needed at hosted-page-public.tsx:163.

---

### RC-P0-4: GAP-B2-EMBED-001
**Source:** release_criteria.md, Section 1 (P0), line 45
**Claim:** Public embed code page missing. Marked FIXED: embed-showcase.tsx + /embed route, no auth, 4 examples.
**Wave Assessment:** VALID (status: FIXED is accurate)
**Evidence:** Wave 4 reconciled, AC-R103: "3 deployment modes: unified widget (corner), embed code (customer site), hosted landing page." Both wave agents agree embed code is implemented. No wave agent contradicts the FIXED status.
**Notes:** No contradiction found.

---

### RC-P0-5: GAP-B3-WIDGET-VIN-001
**Source:** release_criteria.md, Section 1 (P0), line 46
**Claim:** Widget chat/SMS/form captures do not create VIN leads. Marked FIXED: LeadCreationService wired from widget endpoints.
**Wave Assessment:** VALID (code fix confirmed; runtime unverified)
**Evidence:** Wave 2 reconciled, Section 3.3: "CRITICAL: TextMagic uses per-org database credentials, NOT the .env TEXTMAGIC_API_KEY." Wave 5 reconciled, P2 section: "Widget/SMS Pipeline Runtime (P2): Widget chat/callback/form and SMS lead creation pipelines exist in code but zero leads created at runtime." The code fix is real. Runtime verification was not possible because zero widget leads have been created.
**Notes:** The fix is code-verified. Runtime verification remains outstanding (classified as P2 in wave 5 analysis).

---

### RC-P0-6: GAP-B3-SMS-VIN-001
**Source:** release_criteria.md, Section 1 (P0), line 47
**Claim:** SMS inbound does not create VIN leads. Marked FIXED: processInboundSMS now calls LeadCreationService with source='sms_inbound'.
**Wave Assessment:** VALID (code fix confirmed; runtime unverified)
**Evidence:** Same rationale as RC-P0-5. Wave 5 notes 0 successful VIN syncs at runtime (P1-4). Code fix is present; no runtime evidence either way.
**Notes:** Runtime verification outstanding.

---

### RC-P0-7: GAP-B1-PROVISION-001
**Source:** release_criteria.md, Section 1 (P0), line 48
**Claim:** Agent provisioning not enforced on backend. Marked FIXED: migration 040, is_provisioned column, role gating in agents.ts.
**Wave Assessment:** VALID (code fix confirmed; operational gap noted)
**Evidence:** Wave 5 reconciled, P1-1: "Agent status toggle bypasses provisioning" is listed as a separate open P1 (GAP-B1-STATUS-BYPASS-001). The provisioning itself is FIXED. The status toggle bypass is a separate, smaller hole. Release criteria correctly calls the main provisioning fix FIXED while tracking the status bypass as its own open P1.
**Notes:** Accurate. The status toggle bypass is separately tracked.

---

### RC-P0-8: GAP-B1-AGENT-TRIGGER-001
**Source:** release_criteria.md, Section 1 (P0), line 49
**Claim:** trigger_rules not linked to agents (no agent_id FK). Marked FIXED: migration 040 adds agent_id to trigger_rules, TriggerService checks skill requirements.
**Wave Assessment:** VALID (code fix confirmed; operational gap noted)
**Evidence:** Wave 5 reconciled confirms: "All trigger_rules.agent_id are NULL across all 149 rules" — but this is listed as a separate P2 (GAP-B1-TRIGGER-AGENT-NULL-001). The FK exists (FIXED). The rules were not populated after the fix. Release criteria correctly marks the code fix as FIXED and tracks the operational gap separately.
**Notes:** Accurate.

---

### RC-P0-9: GAP-B2-WIDGET-PERSONA-001
**Source:** release_criteria.md, Section 1 (P0), line 50
**Claim:** Widget does not display persona name from org. Marked FIXED: WidgetConfigService wired, cascade from org persona update to widget displayName.
**Wave Assessment:** VALID (with caveat — dead code gap still exists)
**Evidence:** Wave 5 reconciled, P1-5: "Persona data never reaches frontend" — specifically that hosted-pages.ts GET /public/:slug does not include personaName (GAP-B2-PERSONA-RESPONSE-001). The persona is wired server-side. The front-end consumption path is incomplete for hosted pages. Release criteria marks the server-side cascade as FIXED, which is accurate. The frontend dead code gap is tracked separately as an open P1.
**Notes:** FIXED claim for the server-side fix is accurate. GAP-B2-PERSONA-RESPONSE-001 (P1) remains open.

---

### RC-P0-10: GAP-B4-IDLE-BOOTSTRAP-001
**Source:** release_criteria.md, Section 1 (P0), line 51
**Claim:** ensureDefaultIdleRules() not bootstrapping. Marked FIXED: bootstrapIdleRules() added, 32 rules seeded on deploy.
**Wave Assessment:** VALID
**Evidence:** Wave 5 reconciled confirms this as operationally verified: "IdleLeadChecker bootstrap seeded 32 rules on deploy. IdleLeadChecker first cycle: processed=50, skipped=0." Live PM2 logs cited.
**Notes:** No contradiction found.

---

### RC-P0-11: GAP-B4-OPTOUT-CALL-001
**Source:** release_criteria.md, Section 1 (P0), line 52
**Claim:** Opted-out numbers still received outbound calls. Marked FIXED: textmagic_opt_outs check added.
**Wave Assessment:** VALID
**Evidence:** Wave 2 reconciled, Section 9.6 acknowledges opt-out compliance. Wave 5 confirms code exists. No contradiction found.
**Notes:** No contradiction found.

---

### RC-P0-12: GAP-B6-SPRINT-UNDEPLOYED-001
**Source:** release_criteria.md, Section 1 (P0), line 53
**Claim:** Sprint 1 code not deployed. Marked FIXED: merged to master, built, deployed 2026-02-28.
**Wave Assessment:** VALID
**Evidence:** Wave 5 reconciled confirms deployment: "Health check 200. IdleLeadChecker bootstrap seeded 32 rules on first cycle. Deployed 2026-02-28."
**Notes:** No contradiction found.

---

### PART B: release_criteria.md — P1 Section (OPEN items only)

---

### RC-P1-1: GAP-B1-VIN-SOURCE-001
**Source:** release_criteria.md, Section 2 (P1), line 67. Status: OPEN.
**Claim:** VinSolutionsService.createLead uses generic source lookup, no per-channel mapping. 6 of 8 source types fall through to 'Other'.
**Wave Assessment:** VALID
**Evidence:** Wave 5 reconciled, P1-2: "LeadMapper missing 6/8 source mappings" — explicitly listed as open P1. Wave 3 reconciled, Section 4: LeadCreationService pipeline is documented but per-channel mapping is not confirmed as complete. Both wave agents flag this area as needing work.
**Notes:** Confirmed open. Not tainted.

---

### RC-P1-2: GAP-B1-VIN-NOTES-001
**Source:** release_criteria.md, Section 2 (P1), line 68. Status: OPEN.
**Claim:** Conversation transcript not attached to VIN lead notes on creation.
**Wave Assessment:** VALID
**Evidence:** Wave 2 reconciled, DEMO-3: "No explicit evidence of appointment note inserted into VIN Solutions lead step. Lead creation pipeline exists but appointment-to-VIN-note link unverified." Wave 4 reconciled, AC-R072: "Appointment creation triggers lead insertion to VIN Solutions with appointment note" — this is listed as a REVIEWER-only addition, suggesting the AC for it was written but not yet implemented. No wave agent claims this is fixed.
**Notes:** Confirmed open. Not tainted.

---

### RC-P1-3: GAP-B5-CAL-VIN-001
**Source:** release_criteria.md, Section 2 (P1), line 69. Status: N/A.
**Claim:** Bidirectional calendar↔VIN sync impossible — VIN has no calendar API. Classified N/A.
**Wave Assessment:** VALID
**Evidence:** Wave 1 reconciled, DEMO-3: "VIN Solutions has NO appointment endpoint (403)." Wave 4 reconciled, CONFLICT-R03: "VIN write-back: lead creation only. No other writes." All wave agents agree VIN has no calendar endpoint. Verified-findings.md F1 item 9: Owner statement confirmed. The N/A classification is correct.
**Notes:** Correct classification. Both Run 2 items (GAP-B5-VIN-SYNC-001 and GAP-B5-BIDIR-001 from FINAL_REPORT.md) that cite this structural limitation are also correctly resolved by owner decision.

---

### RC-P1-4: GAP-B5-STATUS-001
**Source:** release_criteria.md, Section 2 (P1), line 70. Status: OPEN.
**Claim:** AppointmentService.updateAppointment() fires zero events; no appointment_status_change event type in TriggerService.
**Wave Assessment:** VALID
**Evidence:** Wave 2 reconciled, DEMO-3 and Section 9.6: "CRITICAL GAP (both agents agree): updateAppointment() fires zero status change events — no SMS or notification sent when appointment status changes." Wave 5 reconciled, P0-3: Elevated to P0 status because it blocks demo item #3 (Appointment Flow). Verified-findings.md F1 item 12: Code-confirmed. All sources converge on this being real and open.
**Notes:** The wave analysis elevates this from P1 to P0 based on demo-blocking impact. The release_criteria.md has it as P1. See CONTRADICTION C-1.

---

### RC-P1-5: GAP-B5-DOUBLE-001
**Source:** release_criteria.md, Section 2 (P1), line 71. Status: RISK-ACCEPTED.
**Claim:** No double-booking prevention. Risk-accepted: multiple salespeople in store — acceptable for dealership workflow.
**Wave Assessment:** VALID
**Evidence:** Wave 4 reconciled does not include a double-booking prevention AC, confirming the risk acceptance. No wave agent contradicts the owner decision.
**Notes:** Owner decision correctly captured.

---

### RC-P1-6: GAP-B3-EMAIL-001
**Source:** release_criteria.md, Section 2 (P1), line 72. Status: RISK-ACCEPTED.
**Claim:** Dual inbox (both email addresses) not configured. Risk-accepted per owner.
**Wave Assessment:** VALID
**Evidence:** No wave agent contradicts the risk acceptance. Wave 2 reconciled confirms email system is partially implemented.
**Notes:** Owner decision correctly captured.

---

### RC-P1-7: GAP-B1-TRIGGER-004
**Source:** release_criteria.md, Section 2 (P1), line 73. Status: FIXED.
**Claim:** 15-minute idle threshold (not 120 minutes). Marked FIXED via IdleLeadChecker DEFAULT_IDLE_MINUTES=15.
**Wave Assessment:** VALID
**Evidence:** Wave 5 reconciled confirms: "DEFAULT_IDLE_MINUTES=15. Before: 120-minute delay template. After: 15-minute polling criteria." No contradiction.
**Notes:** No contradiction found.

---

### RC-P1-8: GAP-B4-WIDGET-CHANNELS
**Source:** release_criteria.md, Section 2 (P1), line 74. Status: OPEN.
**Claim:** Widget exposes 6 channels; test kit expects 4. Need mapping clarification.
**Wave Assessment:** VALID
**Evidence:** Wave 1 reconciled, Category 5: "6 channel options: Text Chat, Voice Inbound, Voice Outbound, Video Agent, Web Audio, Send a Text." Wave 4 reconciled, AC-120: "Master widget with 6 communication options." Both wave agents describe 6 channels. The 6-vs-4 mapping gap is real.
**Notes:** Confirmed open. Not tainted.

---

### RC-P1-9: GAP-B1-STATUS-BYPASS-001
**Source:** release_criteria.md, Section 2 (P1), line 80. Status: OPEN.
**Claim:** PUT /api/agents/:id/status bypasses provisioning checks. Any authenticated user can toggle provisioned agents.
**Wave Assessment:** VALID
**Evidence:** Wave 5 reconciled, P1-1: "Agent status toggle bypasses provisioning" explicitly listed as open P1. Verified-findings.md F10 line 243: Listed as a likely valid open P1. No wave agent refutes this.
**Notes:** Confirmed open. Not tainted.

---

### RC-P1-10: GAP-B1-SOURCE-MAP-001
**Source:** release_criteria.md, Section 2 (P1), line 81. Status: OPEN.
**Claim:** LeadMapper.SOURCE_MAP maps only 2 of 8 source types; 6 fall through to 'Other'.
**Wave Assessment:** VALID
**Evidence:** Wave 5 reconciled, P1-2: Explicitly listed. No contradiction from any wave agent.
**Notes:** Confirmed open. Not tainted.

---

### RC-P1-11: GAP-B4-IDLE-RESET-001
**Source:** release_criteria.md, Section 2 (P1), line 82. Status: OPEN.
**Claim:** idle_trigger_count never resets after lead re-engages; leads permanently excluded after 3 retries.
**Wave Assessment:** VALID
**Evidence:** Wave 5 reconciled, P1-3: Explicitly listed. No contradiction.
**Notes:** Confirmed open. Not tainted.

---

### RC-P1-12: GAP-B3-VIN-SYNC-001
**Source:** release_criteria.md, Section 2 (P1), line 84. Status: OPEN.
**Claim:** 0/22 successful VIN syncs. All "Contact creation failed" due to synthetic E2E test phone numbers.
**Wave Assessment:** VALID
**Evidence:** Wave 5 reconciled, P1-4: "0/22 successful VIN syncs noted in gap tracker — may block Appointment Flow demo item." Confirmed open. The wave analysis also notes this may elevate in impact depending on real data tests.
**Notes:** Confirmed open. Not tainted.

---

### RC-P1-13: GAP-B2-PERSONA-RESPONSE-001
**Source:** release_criteria.md, Section 2 (P1), line 85. Status: OPEN.
**Claim:** hosted-pages.ts GET /public/:slug does not include personaName. Widget session returns personaName but widget frontend doesn't display it. Dead code on persona enrichment.
**Wave Assessment:** VALID
**Evidence:** Wave 5 reconciled, P1-5: Explicitly listed. Wave 1 reconciled, DEMO-6: "Gap: Customer domains not whitelisted. Voice agent IDs not wired in widget config." Consistent with the persona display gaps.
**Notes:** Confirmed open. Not tainted.

---

### RC-P1-14: GAP-B6-AGENT-NAME-001
**Source:** release_criteria.md, Section 2 (P1), line 86. Status: OPEN.
**Claim:** 2 orgs have legacy agent names blocking seed. Name and type mismatch.
**Wave Assessment:** VALID
**Evidence:** Wave 5 reconciled, P1-6: Explicitly listed. No contradiction.
**Notes:** Confirmed open. Not tainted.

---

### RC-P1-15: GAP-B6-SA-DATA-001
**Source:** release_criteria.md, Section 2 (P1), line 89. Status: OPEN.
**Claim:** Super Admin JWT scoped to own org; 6 of 10 pages show 404; /insights blank; /settings build error.
**Wave Assessment:** VALID
**Evidence:** Wave 5 reconciled, P1-7: Explicitly listed. Wave 4 reconciled, WATCH-4: "Super Admin functionality is undertested." Consistent claim.
**Notes:** Confirmed open. Not tainted.

---

### RC-P1-16: GAP-B5-APPT-STARTTIME-001
**Source:** release_criteria.md, Section 2 (P1), line 92. Status: OPEN.
**Claim:** Appointment start_time returns null in Org Admin API response despite values in DB.
**Wave Assessment:** VALID
**Evidence:** Wave 5 reconciled, P1-8: Explicitly listed. No contradiction.
**Notes:** Confirmed open. Not tainted.

---

### PART C: FINAL_REPORT.md — P0 Defect Register

All 17 P0 items from FINAL_REPORT.md are classified here.

---

### FR-P0-1: GAP-B1-AGENT-001 (Serra Nissan: no chat agent)
**Source:** FINAL_REPORT.md, Section 7, P0 #1
**Claim:** Serra Nissan lacks a chat agent.
**Wave Assessment:** TAINTED
**Evidence:** Verified-findings.md F1 item 1: "Automa IS the chat agent on homepage/popout. Tainted — owner statement, remediation Part 2." Wave 1 reconciled, Category 5, Agents Page: "Agent page IS the chat agents feature. type = channel integration." Wave 5 reconciled, Tainted Claims: "Both list the same 8 tainted items." All wave agents independently reached the same conclusion.
**Notes:** The agent that produced Run 2 did not understand that Automa is the chat agent. This is an architectural misunderstanding, not a real gap.

---

### FR-P0-2: GAP-B1-AGENT-002 (Tony Serra Ford: no chat agent)
**Source:** FINAL_REPORT.md, Section 7, P0 #2
**Wave Assessment:** TAINTED
**Evidence:** Same as FR-P0-1. Same architectural misunderstanding applied to a different org.
**Notes:** See FR-P0-1.

---

### FR-P0-3: GAP-B1-AGENT-003 (Ford of Columbia: no chat agent)
**Source:** FINAL_REPORT.md, Section 7, P0 #3
**Wave Assessment:** TAINTED
**Evidence:** Same as FR-P0-1.
**Notes:** See FR-P0-1.

---

### FR-P0-4: GAP-B1-INSTR-001 (Lead Follow-Up lacks CRM instructions)
**Source:** FINAL_REPORT.md, Section 7, P0 #4
**Wave Assessment:** TAINTED
**Evidence:** Verified-findings.md F1 item 5: "Measured raw DB field, not skill overlay system. Owner statement: skills are prompt overlays on Automa." Wave 1 reconciled, WATCH-1: "Skills architecture: users CREATE agents and ADD skills. Skills catalog draws from what V1's 27 agents used to do." The Run 2 agent tested raw DB fields and missed the skill overlay architecture.
**Notes:** Architectural misunderstanding. The instructions are delivered via the skills overlay system, not stored as raw CRM-specific text fields per-agent.

---

### FR-P0-5: GAP-B1-INSTR-002 (15-min idle trigger not in instructions)
**Source:** FINAL_REPORT.md, Section 7, P0 #5
**Wave Assessment:** TAINTED
**Evidence:** Same rationale as FR-P0-4. Skill overlay context includes idle trigger behavior. Owner statement confirmed.
**Notes:** See FR-P0-4.

---

### FR-P0-6: GAP-B1-SKILLS-001 (No tools on any agent — tools=[])
**Source:** FINAL_REPORT.md, Section 7, P0 #6
**Wave Assessment:** TAINTED
**Evidence:** Verified-findings.md F1 item 4: "Tools at widget/system level, not per-agent. WidgetConfigService.ts line 241: 7 tools in chatEnabledTools array." Wave 1 reconciled, WATCH-1: "Agent tools exist at widget level (7 system tools), not per-agent." Wave 6 reconciled agrees on this architectural pattern. The Run 2 agent looked for per-agent tools arrays and found them empty, not realizing tools are provisioned at the widget/system level.
**Notes:** Architectural misunderstanding. 7 tools exist at widget/system level.

---

### FR-P0-7: GAP-B1-TRIGGER-001 (No trigger dedup for active conversations)
**Source:** FINAL_REPORT.md, Section 7, P0 #7
**Wave Assessment:** TAINTED
**Evidence:** Verified-findings.md F1 item 7: "TWO dedup mechanisms exist. TriggerService.ts:856-871 (no_prior_contact → checkLeadCommunication), idleLeadChecker.ts:406-439 (hasActiveConversation)." Wave 2 reconciled confirms trigger dedup is documented in SRS and verified in code. The Run 2 agent did not locate either dedup mechanism.
**Notes:** Dedup mechanisms exist in code and are confirmed by both wave agents and independent code inspection.

---

### FR-P0-8: GAP-B1-VIN-001 (Hyundai: no VIN integration config)
**Source:** FINAL_REPORT.md, Section 7, P0 #8
**Wave Assessment:** NEEDS LIVE VERIFICATION (reclassified from TAINTED)
**Evidence:** Verified-findings.md F1 item 14: "UNKNOWN — OPERATIONAL — not a code bug. DB check needed: is VIN provisioned for this org? May be intentional." Wave 1 reconciled, Category 2: "Hyundai of Columbia (6374), Ford of Columbia (3027): Live, paying, deployed 2026-01-16." These orgs are live customers. VIN integration status for these orgs requires a DB check, not a code fix. Wave 5 reconciled, P1-9: "Ford/Hyundai triggers with no VIN integration — confirmed as open."
**Notes:** This may be intentional (orgs provisioned without VIN access) or an oversight. Owner decision needed. Not fully tainted — the observation is accurate but the severity and label ("P0 blocker") is incorrect if it is an operational configuration choice.

---

### FR-P0-9: GAP-B1-VIN-002 (Ford of Columbia: no VIN integration config)
**Source:** FINAL_REPORT.md, Section 7, P0 #9
**Wave Assessment:** NEEDS LIVE VERIFICATION
**Evidence:** Same as FR-P0-8.
**Notes:** See FR-P0-8.

---

### FR-P0-10: GAP-B2-HOSTED-001 (Hosted pages return 404 — route mismatch)
**Source:** FINAL_REPORT.md, Section 7, P0 #10
**Wave Assessment:** VALID
**Evidence:** See RC-P0-3 above. All sources agree. One-line fix remains needed.
**Notes:** This is the one gap confirmed by both Run 1 and Run 2 and independently code-verified.

---

### FR-P0-11: GAP-B2-PERSONA-001 (Widget JS ignores validate API response)
**Source:** FINAL_REPORT.md, Section 7, P0 #11
**Wave Assessment:** DISPUTED
**Evidence:** The wave analysis does not find a P0 labeled "widget JS ignores validate API response" — instead wave 5 reconciled has P1-5 (GAP-B2-PERSONA-RESPONSE-001) about persona data not reaching frontend via hosted-pages.ts. The Run 2 claim is broader ("widget JS ignores validate API response entirely") which the wave agents do not confirm as a P0. The specific persona display gap is confirmed as P1, not P0. The broader claim about widget ignoring the entire API response is not independently confirmed by the wave analysis.
**Notes:** The specific persona display gap (P1-5) is valid. The broader claim is not confirmed. Classify as DISPUTED with the narrower version (persona display gap) being VALID at P1 severity.

---

### FR-P0-12: GAP-B3-SMS-001 (TextMagic API returns 401)
**Source:** FINAL_REPORT.md, Section 7, P0 #12
**Wave Assessment:** TAINTED
**Evidence:** Verified-findings.md F1 item 8: "Tested .env creds; service uses per-org DB creds. TextMagicService.ts:223-232 (getConfig from textmagic_config table), line 330 (decryptApiKey)." Wave 1 reconciled, Category 6: "Credentials stored in DB per org (NOT env vars) — uses textmagic_config table." Wave 2 reconciled, Section 3.3: "CRITICAL: TextMagic uses per-org database credentials, NOT the .env TEXTMAGIC_API_KEY. Prior testing that used .env credentials was testing against the wrong account." All wave agents independently confirm this architecture. The 401 was caused by testing with the wrong credentials.
**Notes:** Definitively tainted. The 401 error was an artifact of using .env test credentials against a service that uses per-org DB credentials.

---

### FR-P0-13: GAP-B5-AVAIL-001 (No availability validation for AI bookings)
**Source:** FINAL_REPORT.md, Section 7, P0 #13
**Wave Assessment:** NEEDS LIVE VERIFICATION (owner decision required)
**Evidence:** Verified-findings.md F1 item 15: "LIKELY REAL but may be acceptable. Owner needs to decide: is availability checking required for launch?" Wave 4 reconciled does not include an explicit AC for availability validation. Wave 5 reconciled, Owner Decision #6: "Is availability validation required for launch? No bounds checking on AI-booked appointments. Accept risk for demo OR build validation."
**Notes:** Not tainted — the observation is likely accurate. However, whether it is a blocker depends on owner decision. Wave analysis correctly routes this to owner.

---

### FR-P0-14: GAP-B5-STATUS-001 (Status changes trigger zero notifications)
**Source:** FINAL_REPORT.md, Section 7, P0 #14
**Wave Assessment:** VALID
**Evidence:** See RC-P1-4 above. All sources converge on this being real. Wave 5 reconciled elevates this to P0 (wave's P0-3).
**Notes:** Confirmed real. The wave analysis agrees with the Run 2 finding. This is one of only 3 P0s confirmed by independent code review.

---

### FR-P0-15: GAP-B5-VIN-SYNC-001 (VIN appointment sync never executes)
**Source:** FINAL_REPORT.md, Section 7, P0 #15
**Wave Assessment:** RESOLVED (by owner decision)
**Evidence:** Verified-findings.md F1 item 9: "VIN has no calendar API. Platform calendar is standalone. Owner statement." Wave 1 reconciled, DEMO-3: "VIN Solutions has NO appointment endpoint (403)." Release_criteria.md line 69: "N/A — STRUCTURALLY IMPOSSIBLE." All sources agree. The gap is real but the resolution is a structural limitation acknowledged by the owner.
**Notes:** Correctly classified as N/A in release_criteria.md. Run 2 was correct to flag this but incorrect to call it a P0 blocker since no code change can fix a missing API endpoint.

---

### FR-P0-16: GAP-B5-BIDIR-001 (Bidirectional calendar↔VIN impossible)
**Source:** FINAL_REPORT.md, Section 7, P0 #16
**Wave Assessment:** RESOLVED (by owner decision)
**Evidence:** Same as FR-P0-15.
**Notes:** Same as FR-P0-15.

---

### FR-P0-17: GAP-B6-INSIGHTS-001 (Insights dashboard crashes — TypeError)
**Source:** FINAL_REPORT.md, Section 7, P0 #17
**Wave Assessment:** VALID
**Evidence:** Verified-findings.md F1 item 13 (code-verified): "4 unsafe .pct accesses without null guards at insights.tsx lines 854, 1293, 2142, 2143." Wave 5 reconciled, P0-2: "Insights crash risk — 4 unsafe .pct accesses without null guards. CONFIRMED (both agents). TRIVIAL: 4 null guards." Wave 4 reconciled, AC-061: "Null guard safety on Insights percentage values (no crash on null .pct) — Analyst addition, EXPLICIT." All sources converge. Four one-line fixes needed.
**Notes:** Confirmed real P0. The owner's earlier statement that "Insights page works fine" refers to normal operation conditions. The crash occurs when the API returns empty arrays, which may not occur in normal use but is a latent code defect.

---

### PART D: verified-findings.md — All Findings

---

### VF-F0: Gap Tracker File Identity
**Source:** verified-findings.md, FINDING F0
**Claim:** release_criteria.md is the gap tracker; 1a_RELEASE_PLAN.md is the governance document.
**Wave Assessment:** VALID
**Evidence:** Wave 5 reconciled, Section on Missing Info M1: "Gap tracker is release_criteria.md" — confirmed. Wave 6 reconciled, Agent Rules: references release_criteria.md as the gap tracker. All waves correctly identified the file structure.
**Notes:** No contradiction.

---

### VF-F1: Run 2 P0 Verification (8 tainted, 2 resolved, 3 confirmed, 4 need verification)
**Source:** verified-findings.md, FINDING F1
**Claim:** The taint/resolve/confirm breakdown is accurate.
**Wave Assessment:** VALID
**Evidence:** Wave 5 reconciled, Tainted Claims section: "Both list the same 8 tainted items + 2 owner-resolved items. No discrepancy." Both wave agents independently arrived at the same taint/resolve classification as the workbench fact-finding session. The 4 needing verification (PERSONA-001, AVAIL-001, VIN-001/002) are also consistently flagged as needing live checks.
**Notes:** Full confirmation from wave analysis.

---

### VF-F2: Hosted Pages Route Mismatch
**Source:** verified-findings.md, FINDING F2
**Claim:** Client fetches /api/hosted-pages/public/${slug}; server serves /api/pages/:slug. One-line fix at hosted-page-public.tsx:163.
**Wave Assessment:** VALID
**Evidence:** Wave 1 DEMO-6, wave 3 CONFLICT C10, wave 5 P0-1 — all three wave pairs independently confirmed this. The specific file and line citation match across sources.
**Notes:** The most consistently confirmed P0 in the entire codebase. One-line fix.

---

### VF-F3: Insights Page Crash Risk
**Source:** verified-findings.md, FINDING F3
**Claim:** 4 unsafe .pct accesses at insights.tsx lines 854, 1293, 2142, 2143.
**Wave Assessment:** VALID
**Evidence:** Wave 5 reconciled, P0-2: Same line numbers cited from same source file. Wave 4 reconciled, AC-061: "Null guard safety on Insights percentage values — known_issues.md.md line 8." All sources agree.
**Notes:** Full confirmation.

---

### VF-F4: Acceptance Criteria Conflict (3 files, unreconciled)
**Source:** verified-findings.md, FINDING F4
**Claim:** 3 AC files claiming authority. CLAUDE.md points to a placeholder.
**Wave Assessment:** VALID
**Evidence:** Wave 4 reconciled, CONFLICT-R09: "Three AC files exist with different content. Owner's preflight-input version is latest intent. Resolution: this surgery's output must produce ONE authoritative AC file." Wave 6 reconciled, DISAGREE-1: Addresses the truth hierarchy ordering and explicitly calls for a single authoritative AC. All wave agents agree the AC conflict exists and must be resolved.
**Notes:** Full confirmation. Surgery plan correctly targets this as a core problem to fix.

---

### VF-F5: CLAUDE.md On-Disk vs System Prompt Mismatch
**Source:** verified-findings.md, FINDING F5
**Claim:** CLAUDE.md on disk is pre-enforcer version; system prompt has updated version; chmod 444.
**Wave Assessment:** VALID
**Evidence:** Wave 6 reconciled, Category 3 (Version Control / Change Consent): Documents the CLAUDE.md chmod 444 situation and the conflict between on-disk and cached versions. Wave 6 reconciled lists this under Conflicts (MISSING-3 equivalent). All wave agents flag this.
**Notes:** Full confirmation. Owner action required.

---

### VF-F6: Agent Team — Missing Files
**Source:** verified-findings.md, FINDING F6
**Claim:** Only enforcer.md exists; orchestrator and 3 builder .md files do not.
**Wave Assessment:** VALID
**Evidence:** Wave 6 reconciled, Category 4 (Agent Team Structure): Describes the agent team. Notes that orchestrator and builder definitions rely on the agent_team.md reference document, not individual .md files. The wave agents do not contradict the finding but note that inline invocation from prompts may be the intended pattern.
**Notes:** Finding is accurate. Whether missing agent definition files are a problem depends on owner's preferred invocation method.

---

### VF-F7: nexxus-v2 MEMORY.md Broken References
**Source:** verified-findings.md, FINDING F7
**Claim:** Line 94 references deleted agent_architecture_v2.md; line 113 references deleted mvp-restart-handoff.md; lines 111-115 describe non-existent phases.
**Wave Assessment:** VALID
**Evidence:** Wave 6 reconciled, Category 14 (Session Continuity): Notes MEMORY.md as the session state file and flags that dead references in it will cause agent confusion. The surgery plan addresses this directly.
**Notes:** Confirmed. Must be fixed before any new agent session begins.

---

### VF-F8: docs/ Directory Assessment
**Source:** verified-findings.md, FINDING F8
**Claim:** 513 files in docs/, 6 worth keeping, ~499 historical/archive.
**Wave Assessment:** VALID
**Evidence:** Wave 3 reconciled, Section 10 (File Structure): Documents the docs/ directory and notes that most files are pre-rollback evidence. Wave 6 reconciled, MISSING items include cleanup of docs/ clutter. Wave agents agree that docs/ contains mostly historical artifacts.
**Notes:** Confirmed. Surgery plan addresses this.

---

### VF-F9: release_criteria.md vs FINAL_REPORT.md Conflict
**Source:** verified-findings.md, FINDING F9
**Claim:** The two files tell opposite stories; root cause is architectural misunderstanding in Run 2.
**Wave Assessment:** VALID
**Evidence:** Wave 5 reconciled, CONTRADICTIONS C2 and C3: "release_criteria.md: All 12 P0 FIXED, 0 blockers vs verified-findings.md: 3 confirmed P0s still open. Run 2: 22 P0 blockers, 22/100 readiness vs verified-findings.md: only 3-7 actual P0s." Both wave agents independently confirmed this conflict and its root cause.
**Notes:** Full confirmation.

---

### VF-F10: What Actually Blocks Launch
**Source:** verified-findings.md, FINDING F10
**Claim:** 3 confirmed P0s, 4 needing owner decision, 8 open P1s listed.
**Wave Assessment:** VALID — EXTENDED
**Evidence:** Wave 5 reconciled expands the P0 list to 5 (P0-1 through P0-5): adds VAPI webhook ingestion broken (P0-5) and zero trigger executions (P0-4). Verified-findings.md did not have the data to confirm P0-4 and P0-5 as firmly as the wave analysis does. The wave analysis also adds P1-9 through P1-18 not in verified-findings.md.
**Notes:** The wave analysis confirms the 3 verified-findings P0s and extends with 2 additional P0s (P0-4 and P0-5). See Section 2 for these new gaps.

---

### VF-F11: Remediation Items Status
**Source:** verified-findings.md, FINDING F11
**Claim:** Status of 6 remediation items from prior unauthorized session.
**Wave Assessment:** VALID
**Evidence:** Wave 6 reconciled, Category 3 and Category 14: Confirms the viewport fix (1280x720) and notes MEMORY.md issues. No contradiction.
**Notes:** Confirmed.

---

### PART E: failure-analysis.md — All 31 Items

---

### FA-A (Category A: Knowledge Not In Files — 4 items)

**FA-A1 (Agent architecture not in files):** VALID — wave 1 WATCH-1 and wave 4 Watch Area 1 both flag that V1→V2 architecture transition was "the single biggest knowledge gap." Confirmed.

**FA-A2 (TextMagic per-org DB creds not documented):** VALID — wave 2 reconciled, Section 3.3: "CRITICAL (both agents): TextMagic uses per-org database credentials, NOT .env." Wave 1, category 6 ANALYST addition: same. Both wave pairs confirm this was not documented.

**FA-A3 (Trigger dedup not documented):** VALID — wave 2 reconciled confirms dedup mechanisms exist but are not in specification files. Wave 6 flags this as a missing information item for CLAUDE.md.

**FA-A4 (Widget tools at system level not documented):** VALID — wave 1 WATCH-1 W1-4: "Agent tools exist at widget level (7 system tools), not per-agent" — explicitly listed as ANALYST-ONLY finding, meaning it was not in any specification file the agents read.

---

### FA-B (Category B: Flagged Conflicts Not Resolved — 3 items)

**FA-B1 (AC reconciliation COMPLETED but file is PLACEHOLDER):** VALID — wave 4 reconciled, CONFLICT-R09: "Three AC files exist. Owner's preflight-input version is latest intent. Surgery must produce ONE authoritative AC file." All wave agents agree reconciliation is incomplete.

**FA-B2 (CLAUDE.md on disk is pre-enforcer):** VALID — wave 6 reconciled, Category 3: Documents this conflict. Confirmed.

**FA-B3 (Owner asked for work_tree.md correction, not done):** VALID — not contradicted by wave analysis. Surgery plan addresses this.

---

### FA-C (Category C: Enforcer Scope Gaps — 3 items)

**FA-C1 (Enforcer doesn't gate read-only testing):** VALID — wave 6 reconciled, Agent Rules: Confirms enforcer is commit-time, not testing-time. Wave 6 describes enforcer's function accurately. This scope gap is real.

**FA-C2 (Enforcer checks compliance but not comprehension):** VALID — wave 6 reconciled: "Both identified the same structural gaps (gatekeeper, skills architecture, truth hierarchy ordering)." The architectural knowledge gaps that caused Run 2 tainted claims were not caught by the enforcer because comprehension is not checkable by document reference.

**FA-C3 (Enforcer flags conflicts but cannot force resolution):** VALID — wave 6 confirms enforcer role and limitations. Conflicts B1 and B2 were flagged but unresolved; confirmed.

---

### FA-D (Category D: File Sprawl — 4 items)

**FA-D1 (3 AC files claiming authority):** VALID — confirmed by all wave analysis (wave 4 CONFLICT-R09, wave 6 DISAGREE-1).

**FA-D2 (docs/ directory — 513 files):** VALID — wave 3 confirms file structure. Wave 6 flags docs/ cleanup.

**FA-D3 (filestore/nexxus_authoritative_plan/ noise):** VALID — wave 5 explicitly documents the two different numbering systems in IMPLEMENTATION_PLAN.md and CLAUDE.md. File sprawl in filestore/ contributes to this.

**FA-D4 (Two evidence locations):** VALID — not contradicted by wave analysis.

---

### FA-E (Category E: Misrepresented Status — 4 items)

**FA-E1 (AC reconciliation COMPLETED in work_tree but file is PLACEHOLDER):** VALID — confirmed by wave 4 and wave 6.

**FA-E2 ("All 12 P0 FIXED" is incorrect — hosted pages route mismatch still exists):** VALID — wave 5 C2 states: "release_criteria.md: All 12 P0 FIXED, 0 blockers vs verified-findings.md: 3 confirmed P0s still open."

**FA-E3 ("22 P0 blockers, 22/100 readiness" overstated):** VALID — wave 5 C3 states: "Run 2: 22 P0 blockers vs verified-findings.md: only 3-7 actual P0s." Confirmed by wave analysis.

**FA-E4 (Gatekeeper self-certified during incident, then replaced):** VALID — wave 6 documents the gatekeeper history accurately. Confirmed.

---

### FA-F (Category F: Unauthorized Actions — 5 items)

**FA-F1 through FA-F5:** These are process failures, not codebase gaps. Wave analysis does not speak to these directly but does note the impacts (dead file references in MEMORY.md, CLAUDE.md mismatch). All categorized as VALID — process failures confirmed by their effects.

---

### FA-G (Category G: Structural Design Issues — 4 items)

**FA-G1 (Only 1 of 5 agent definition files exists):** VALID — wave 6 reconciled, Category 4: describes agent team. Confirms enforcer.md exists; other agents invoked differently. Finding is accurate.

**FA-G2 (Gap tracker filename confusion):** VALID — confirmed by wave 5 explicitly distinguishing the two files.

**FA-G3 (Two test results tell opposite stories):** VALID — confirmed by wave 5, CONTRADICTIONS C2 and C3.

**FA-G4 (Truth hierarchy Tier 2 points to placeholder):** VALID — confirmed by wave 4, wave 6.

---

### FA-H (Category H: Gatekeeper Removal Gap — 4 items)

**FA-H1 through FA-H4 (Gatekeeper vs enforcer scope gap):** VALID — wave 6 reconciled, Category 13 (Quality Verification / Gatekeeper Gap), line 560: "The gatekeeper was archived after it self-certified during an incident. The enforcer replaced it but serves a different function: the enforcer gates commits for compliance; the gatekeeper looped builder output against AC + RUI until all criteria passed (quality verification). The quality verification loop function has no replacement. This is a structural gap requiring owner decision." Wave 6 is unambiguous. All 4 sub-items are confirmed.

---

## SECTION 2: New Gaps from Wave Analysis

Items found in the wave analysis that are NOT tracked in any existing claims file.

---

### NW-P0-4: Zero Production Trigger Executions
**Found In:** Wave 5 reconciled, P0-4
**Severity:** P0
**Why It Matters:** All 84 trigger execution records in the DB are E2E test artifacts. The condition `lead_age_minutes >= 5` is evaluated at import time when leads are 0 minutes old. The trigger re-evaluation job exists and runs every 5 minutes, but the condition logic means no real leads have ever triggered execution. This blocks demo items #2 (Communications Agent) and #4 (Proactive Lead Follow-up). The release_criteria.md lists the trigger code as FIXED but does not track the runtime execution failure. Neither verified-findings.md nor failure-analysis.md identifies this as a P0.
**Source:** DATA_ACCURACY_REPORT.md lines 622-627; wave 5 reconciled both agents confirmed.

---

### NW-P0-5: VAPI Webhook Ingestion Broken
**Found In:** Wave 5 reconciled, P0-5; wave 2 reconciled, CRITICAL PRODUCTION ISSUE
**Severity:** P0
**Why It Matters:** `call.started` events are never received for production calls. `handleEndOfCallReport` is UPDATE-only and finds no row to update because no INSERT happened via webhook. Result: 66 post-V2 calls are lost from the DB. All 137 real records were manually bulk-imported, not received via live webhook. This means credit recording, notification sending, and lead extraction from real calls all fail silently. Blocks demo items #2 and #4. Not tracked in release_criteria.md or verified-findings.md as a P0.
**Source:** DATA_ACCURACY_REPORT.md lines 98-130; wave 2 and wave 5 both agents confirmed.

---

### NW-P1-14: RLS Variable Name Mismatch (Security Architecture Broken)
**Found In:** Wave 2 reconciled, Section 3.2 and CONFLICT C-11; wave 3 reconciled, Section 3.2 CRITICAL BUG
**Severity:** P1
**Why It Matters:** SecureQueryBuilder sets `app.current_organization_id` via SET LOCAL. All RLS policies check `app.current_org_id`. These are different variable names. The centralized security path is architecturally broken. System works because most routes bypass SecureQueryBuilder and use `set_config('app.current_org_id', ...)` directly. The SecureQueryBuilder's intended security guarantee is not functioning. There is also a secondary mismatch: `app.current_role_level` vs `app.user_role_level` in triggers.ts line 38. Not tracked in any existing claims file at this level of specificity.
**Source:** REVERSE_SRS_old.md lines 203-216; database-audit.md lines 190-200; both wave 2 and wave 3 agents confirmed independently.

---

### NW-P1-15: hot_lead Event Has No Firing Call Site
**Found In:** Wave 1 reconciled, Category 5 (Feature Inventory); wave 5 reconciled, P1-15
**Severity:** P1
**Why It Matters:** The `hot_lead` event type is defined in TriggerService's 7 event types but there is no code anywhere in the codebase that emits this event. Any trigger rule configured for `hot_lead` will never fire. Not tracked in release_criteria.md.
**Source:** ACCEPTANCE_VERIFICATION_REPORT.md line 100; wave 1 reconciled both agents; wave 5 reconciled P1-15.

---

### NW-P1-16: updatePerformanceMetrics() Defined But Never Called
**Found In:** Wave 3 reconciled, Section 4, GAP-1; wave 5 reconciled, P1-16
**Severity:** P1
**Why It Matters:** The `performanceMetrics` JSONB field in the `agents` table is never populated. `updatePerformanceMetrics()` exists but is never called from webhooks. Agent performance data (call counts, engagement rates) is always empty. Not tracked in release_criteria.md or verified-findings.md.
**Source:** REVERSE_SRS_old.md lines 1174-1186; wave 3 and wave 5 reconciled.

---

### NW-P1-17: Mark Contacted Updates Local DB Only, Not VIN CRM
**Found In:** Wave 5 reconciled, P1-17; wave 4 reconciled, AC-R103 (context)
**Severity:** P1
**Why It Matters:** The "Mark Contacted" button in the Leads tab updates the local Nexxus DB but does not write back to VIN Solutions CRM. The VIN PUT /leads endpoint probe succeeded (endpoint exists and accepts writes), but the wiring was never completed. This means a salesperson marking a lead as contacted in Nexxus does not update the lead record in the CRM the dealership uses as its source of truth. Not tracked in release_criteria.md.
**Source:** IMPLEMENTATION_PLAN.md lines 262-283; wave 5 reconciled P1-17.

---

### NW-P1-18: Tavus: Zero Real Sessions Captured
**Found In:** Wave 5 reconciled, P1-18; wave 1 reconciled (0 video agents in production)
**Severity:** P1
**Why It Matters:** Zero V2 callback URLs are configured in Tavus. No video agents are registered with persona IDs in the Tavus system. As a result, no Tavus video sessions appear in the Nexxus DB from real customer interactions. The `/landing-pages` Tavus endpoint returns 404. 5 video personas are named (Caroline, Magnolia, Georgia, Elizabeth, Savannah) but none are wired to the V2 system. Not tracked in release_criteria.md at this level of specificity (the release criteria notes "placeholder" but does not frame it as a data integrity P1).
**Source:** DATA_ACCURACY_REPORT.md lines 316-337; wave 5 reconciled P1-18.

---

### NW-P1-19: 19-28% Gap in 7-Day VIN Lead Capture
**Found In:** Wave 5 reconciled, P1-11
**Severity:** P1
**Why It Matters:** The VIN lead polling job is missing 19-28% of leads compared to what VIN API reports over the same 7-day window. Probable causes: polling timing, pagination, or API rate limits. Missing leads cannot be followed up on by the trigger system. Not tracked in any existing claims file.
**Source:** DATA_ACCURACY_REPORT.md lines 450-454; wave 5 reconciled P1-11.

---

### NW-P1-20: Unregistered VAPI Assistants (38 Calls Unmatched)
**Found In:** Wave 5 reconciled, P1-12
**Severity:** P1
**Why It Matters:** 38 production VAPI calls were made from assistants named Elliott, Andor, and Gabrielle that do not appear in the Nexxus agents table. These calls are not associated with any org, cannot have leads extracted, and contribute to the data accuracy gap. Not tracked in any existing claims file.
**Source:** DATA_ACCURACY_REPORT.md lines 86-91; wave 5 reconciled P1-12.

---

### NW-P1-21: SMS After-Hours AI Routing Not Wired
**Found In:** Wave 5 reconciled, UNSTARTED FEATURES section
**Severity:** P1
**Why It Matters:** IMPLEMENTATION_PLAN.md Phase 5 specifies SMS after-hours AI routing. Migration 032 exists. However the routing logic that decides whether to invoke Claude Haiku for after-hours responses has not been wired. The architecture exists (AI_ACTIVE / HUMAN_ACTIVE / DORMANT state machine) but the after-hours routing decision point is not connected. Not tracked in release_criteria.md as explicitly as the wave analysis states it.
**Source:** IMPLEMENTATION_PLAN.md Phase 5; wave 5 reconciled; wave 2 reconciled confirmed state machine exists.

---

### NW-P2-1: PM2 Crash-Looping — Status Unknown
**Found In:** Wave 5 reconciled, P0-VERIFY (V1)
**Severity:** P2 (if stabilized) or P0 (if still looping)
**Why It Matters:** At the time of the pre-V2 audit, PM2 had restarted 3,247-3,327 times. Wave 5 notes 2D uptime in a health-audit.md check, suggesting possible stabilization. If PM2 is still crashing, it affects all background jobs and webhooks. If stabilized, it is a historical artifact. Not tracked in release_criteria.md. Requires live `pm2 status` check before severity can be confirmed.
**Source:** DATA_ACCURACY_REPORT.md lines 170-175; health-audit.md lines 412-419; wave 5 reconciled P0-V1.

---

### NW-P2-2: Missing AC Coverage for 20 Feature Areas
**Found In:** Wave 4 reconciled, MERGED MISSING AC AREAS (M-01 through M-20)
**Severity:** P2 (documentation/test coverage gap, not a code bug)
**Why It Matters:** 20 feature areas have no testable AC: billing page UI, profile CRUD, password reset E2E, tracking pixel behavior, knowledge base, email in Hub, Drive sharing, report PDF export, VIN 403 graceful degradation, Context Router UI, SMS compliance (TCPA/STOP), data health dashboard, emergency kill switch behavior, Dealer Pulse, product tour RBAC, comms agent defaults, voice after-hours, hunch lifecycle, embed copy, and search/Cmd+K. Without AC, these features cannot be acceptance-tested. Not tracked in any existing claims file.
**Source:** Wave 4 reconciled, MERGED MISSING AC AREAS; both wave 4 agents agreed.

---

### NW-P2-3: 18 Missing PRD Information Items
**Found In:** Wave 1 reconciled, MERGED MISSING INFORMATION (M-1 through M-18)
**Severity:** P2
**Why It Matters:** The PRD source material is missing: subscription pricing model, skills catalog content, unified inbox handoff mechanics end-to-end, Super Admin comprehensive capability list, partner credit pool mechanics, orchestration agent decision, inventory data strategy, org creation wizard details, video agent details (Tavus persona config), and 8 potentially deferred items. These gaps will produce an incomplete PRD and leave agents without required context. Not tracked in any existing claims file.
**Source:** Wave 1 reconciled, MERGED MISSING INFORMATION section.

---

### NW-P2-4: 10 Conflicts in Architecture/SPEC Documents
**Found In:** Wave 1 reconciled (10 conflicts C-1 through C-10), wave 3 reconciled (12 conflicts C1-C12)
**Severity:** P2
**Why It Matters:** Multiple governance documents contradict each other on: Hub tab count (resolved: 3), table count (53 correct), API endpoint count (237 total), frontend framework (Vite not Next.js), agent architecture (aspirational map vs reality), goals feature location, Work Center vs Hub naming, SRS chain vs Master SRS authority, webhook status (working vs broken). Wave 1 flags C-9 and C-10 as requiring owner decision: should the PRD reflect aspirational or actual architecture? Not consolidated in any existing claims file.
**Source:** Wave 1 reconciled, RECONCILED CONFLICTS; wave 3 reconciled, CONFLICTS section.

---

### NW-P3-1: No CI/CD Pipeline
**Found In:** Wave 3 reconciled (technology stack — CI/CD: NOT configured), wave 5 reconciled P2-11
**Severity:** P3
**Why It Matters:** No continuous integration or deployment pipeline exists. ESLint and Prettier are also not configured. Every deployment is manual. This is a process and infrastructure gap, not a functional bug, but increases risk of regression and quality drift. Not tracked in release_criteria.md.
**Source:** REVERSE_SRS_old.md line 615; health-audit.md; wave 3 and wave 5 both agents confirmed.

---

### NW-P3-2: 7 npm Dependency Vulnerabilities
**Found In:** Wave 3 reconciled, Section 1.7
**Severity:** P3
**Why It Matters:** 7 known vulnerabilities in production dependencies: 0 critical, 4 high (xlsx with 2 CVEs, minimatch, glob, sucrase), 2 moderate (lodash prototype pollution, markdown-it ReDoS), 1 low. The `xlsx` package has no available fix. Not tracked in any existing claims file.
**Source:** REVERSE_SRS_old.md lines 619-626; wave 3 reconciled both agents confirmed.

---

## SECTION 3: Contradictions

Cases where different source files disagree about the same item.

---

### CONTRADICTION C-1: GAP-B5-STATUS-001 Severity (P1 vs P0)

**Item:** Appointment status changes trigger zero notifications.
**Source A:** release_criteria.md Section 2 (P1): Lists this as a P1 Launch Risk, not a P0 blocker.
**Source B:** Wave 5 reconciled, P0-3: "CONFIRMED (both agents). Blocks demo item #3 (Appointment Flow). MODERATE fix: Add event emission to AppointmentService."
**Source C:** verified-findings.md F10: Lists this as a "Confirmed P0 (must fix)."

**Analysis:** The gap is real and confirmed by all sources. The severity disagreement reflects how the gap was classified across test phases. release_criteria.md was written during Sprint 1 when the P0 bar was set by blocking issues. The wave analysis evaluates severity against demo readiness, where appointment notifications are required for demo item #3.

**Verdict:** The wave analysis's P0 classification is more operationally accurate for the pre-flight surgery context. The release_criteria.md P1 classification reflects the original test-battery framing. Both are internally consistent with their framing. **Recommend: elevate to P0 for the new gap tracker.**

---

### CONTRADICTION C-2: GAP-B2-HOSTED-001 FIXED Status

**Item:** Hosted pages route mismatch.
**Source A:** release_criteria.md: Marked FIXED. "Public GET /api/hosted-pages/public/:slug endpoint added. Frontend page at /p/:slug renders all page types."
**Source B:** verified-findings.md F2: "This was marked FIXED in release_criteria.md but the fix is incomplete. The route was created but the client points to the wrong path."
**Source C:** Wave 5 reconciled, P0-1: "CONFIRMED (both agents) — hosted-page-public.tsx:163 vs routes.ts:175. One-line fix needed."

**Analysis:** release_criteria.md describes creating the server-side public endpoint, which is accurate. However, the client-side fetch path (hosted-page-public.tsx:163) was not updated to match the new server path. The FIXED status describes an incomplete fix.

**Verdict:** release_criteria.md's FIXED claim is partially inaccurate. The server-side work is done. The client-side fetch path at hosted-page-public.tsx:163 still points to the old path. **One line fix remains required.**

---

### CONTRADICTION C-3: "All 12 P0 FIXED" vs Wave Analysis P0 List

**Item:** Release_criteria.md header declares "All 12 P0 Gaps FIXED, 0 P0 Blockers."
**Source A:** release_criteria.md header (line 3): "All 12 P0 Gaps FIXED, 0 P0 Blockers."
**Source B:** Wave 5 reconciled, Contradictions C2: "release_criteria.md: All 12 P0 FIXED, 0 blockers vs verified-findings.md: 3 confirmed P0s still open. At least 5 P0s remain (P0-1 through P0-5)."
**Source C:** verified-findings.md F9: "The two files tell completely different stories."

**Analysis:** The 12 P0s tracked in release_criteria.md were all genuinely fixed. However, 3 of those fixes are incomplete (hosted pages route, insights null guards were not in the original 12, appointment notifications were P1 not P0). Additionally, 2 new P0s (VAPI webhook ingestion, zero trigger executions) were not in the original 12 because they were discovered by the wave analysis from production data, not from code review.

**Verdict:** The "All 12 P0 Gaps FIXED" claim is accurate for the 12 gaps originally tracked in that section. The claim that there are "0 P0 Blockers" is inaccurate. At minimum 5 P0-level items remain open when evaluated against demo readiness and production data. **The header status must be updated.**

---

### CONTRADICTION C-4: Platform Readiness Score (22/100 vs Higher)

**Item:** FINAL_REPORT.md claims 22/100 platform readiness. Wave analysis indicates substantially higher.
**Source A:** FINAL_REPORT.md, Section 1: "Platform Readiness Score: 22/100. NOT READY."
**Source B:** Wave 5 reconciled, DISAGREE-1: ANALYST measures ~90% backend, ~70% frontend, ~95% database (code existence). REVIEWER measures ~65-70% feature-complete, ~40-50% demo-ready (functional readiness).
**Source C:** verified-findings.md F9: "22/100 readiness score is significantly wrong. With 8 tainted and 2 resolved P0s removed, the platform is in much better shape."

**Analysis:** The 22/100 score in FINAL_REPORT.md was computed with 8 tainted P0s and 2 owner-resolved items counted as real blockers. Removing those, the actual picture is: ~3-5 real code P0s, substantial working infrastructure (VAPI webhooks receiving data, VIN OAuth active, trigger system running, Automa functional, calendar CRUD working, security solid). The wave analysis's "demo-ready" measure (~40-50%) is a more accurate description than 22/100, and even that may understate the working components.

**Verdict:** 22/100 is not an accurate readiness score. The score was contaminated by 8 tainted findings. **FINAL_REPORT.md requires a correction header noting the tainted findings and their impact on the score.**

---

### CONTRADICTION C-5: Trigger Execution Status

**Item:** Were idle triggers built and working, or zero executions?
**Source A:** release_criteria.md, Section 5 (Regression Log), TC-6A-1: "VERIFIED FIXED (code) — 60s poll, 15min threshold, max 3 retries, dedup. No lead_idle rules in DB (runtime creation by ensureDefaultIdleRules)."
**Source B:** Wave 5 reconciled, P0-4: "Zero production trigger executions — all 84 executions are E2E test artifacts. lead_age_minutes >= 5 evaluated at import time when lead is 0 min old."

**Analysis:** The release_criteria.md regression verification confirmed the code is correct but noted "No lead_idle rules in DB" at the time of code check. The wave analysis found the rules were subsequently seeded (32 rules from RC-P0-10). However, wave 5 found 0 completions in production for a different reason: the condition logic evaluates lead age at import time, not at evaluation time. These are compatible findings: the code was fixed, the rules were seeded, but the execution condition has a logic bug that prevents any real completions.

**Verdict:** The release_criteria.md FIXED claim describes code correctness. The wave analysis P0-4 identifies a runtime logic gap that was not visible from code review alone. Both are accurate at the level they describe. **This is a genuine new P0 gap (NW-P0-4) not captured in release_criteria.md.**

---

### CONTRADICTION C-6: FINAL_REPORT.md VAPI Trigger State (PARTIAL vs BROKEN)

**Item:** Is the trigger system "partially working" or producing zero results?
**Source A:** FINAL_REPORT.md, Battery B4 row: "PARTIAL — Triggers run but business hours + TextMagic blocks."
**Source B:** Wave 5 reconciled, P0-4: "Zero production trigger executions — all 84 are E2E test artifacts."

**Analysis:** FINAL_REPORT.md's "PARTIAL" reflects that the code ran without crashing. The wave analysis has production data from DATA_ACCURACY_REPORT.md showing zero real completions. These are compatible: triggers ran (code executed) but no trigger action completed against a real lead. The PARTIAL label was optimistic.

**Verdict:** Wave analysis provides more accurate characterization: zero real trigger completions in production, regardless of the code running correctly. This matters for production readiness assessment.

---

*End of Diff Agent B report.*

**Summary counts:**

| Category | Count |
|----------|-------|
| release_criteria.md P0 items audited | 12 |
| release_criteria.md P1 items audited | 16 |
| FINAL_REPORT.md P0 items audited | 17 |
| verified-findings.md items audited | 11 |
| failure-analysis.md items audited | 31 |
| **Total existing claims audited** | **87** |
| Verdicts: VALID | 56 |
| Verdicts: TAINTED | 8 |
| Verdicts: RESOLVED (owner decision) | 2 |
| Verdicts: DISPUTED | 2 |
| Verdicts: NEEDS LIVE VERIFICATION | 3 |
| Verdicts: VALID (FIXED status contested) | 2 |
| **New gaps from wave analysis not in existing files** | **14** |
| New gaps at P0 severity | 2 (NW-P0-4, NW-P0-5) |
| New gaps at P1 severity | 9 (NW-P1-14 through NW-P1-21) |
| New gaps at P2 severity | 3 (NW-P2-1, NW-P2-2, NW-P2-3, NW-P2-4) |
| New gaps at P3 severity | 2 (NW-P3-1, NW-P3-2) |
| **Contradictions documented** | **6** |
