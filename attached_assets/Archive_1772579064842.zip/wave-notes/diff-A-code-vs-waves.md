# Diff Agent A: Code vs Wave Notes

**Agent:** Diff Agent A
**Date:** 2026-03-03
**Method:** Direct codebase inspection against wave-notes/wave[1-6]-reconciled.md
**Scope:** P0 gaps, payment-critical demo items, watch areas, other significant gaps

---

## Approach

All claims below are verified directly from source code. File paths and line numbers are cited. Items that cannot be verified from static code analysis are marked UNVERIFIABLE and the reason stated.

---

## 1. P0 Gaps (The 5 Confirmed Ones)

---

### P0-1: Hosted Pages Route Mismatch

**Wave Says:** Client fetches `/api/hosted-pages/public/:slug`, server serves `/api/pages/:slug`. One-line fix. (wave3-reconciled.md Section 4.5; wave5-reconciled.md P0-1)

**Code Status:** CONFIRMED PARTIAL -- The mismatch exists, but TWO separate client pages exist, each using different routes.

**Evidence:**
- `client/src/pages/hosted-page-public.tsx:163` fetches `/api/hosted-pages/public/${encodeURIComponent(slug)}`
- `client/src/pages/hosted/HostedPage.tsx:96` fetches `/api/pages/${encodeURIComponent(slug)}`
- `server/routes.ts:172` registers `app.use("/api/hosted-pages", hostedPagesRoutes)`
- `server/routes.ts:175` registers `app.use("/api/pages", hostedPagesPublicRoutes)`
- `client/src/App.tsx:41` routes `/w/:slug` to `HostedPage` (uses `/api/pages/:slug` -- CORRECT)
- `client/src/App.tsx:42` routes `/p/:slug` to `HostedPagePublic` (uses `/api/hosted-pages/public/:slug` -- NO SERVER ROUTE EXISTS at that path)

**Gap:** There are two separate hosted-page client components. `HostedPage` (at `/w/:slug`) calls the correct server endpoint `/api/pages/:slug` and works. `HostedPagePublic` (at `/p/:slug`) calls `/api/hosted-pages/public/:slug` which has no matching server handler. The wave notes describe this as "one-line fix" but the actual situation is that the `/w/:slug` path already works correctly via `HostedPage.tsx`. The `/p/:slug` path uses the incorrect URL. Fix: either remove `HostedPagePublic` and redirect `/p/:slug` to `/w/:slug`, or add a public endpoint at `/api/hosted-pages/public/:slug`.

---

### P0-2: Insights Crash Risk (4 Null Guard Locations)

**Wave Says:** 4 unsafe `.pct` accesses without null guards at `insights.tsx` lines 854, 1293, 2142, 2143. Crash risk on null response. (wave5-reconciled.md P0-2)

**Code Status:** PARTIAL -- 3 of 4 locations confirmed as unguarded. Line 1293 is actually line 1221 accessing `.pct` in a table row. The default fallback data is populated but API could return different structure.

**Evidence:**
- `client/src/pages/insights.tsx:854`: `pipelineHealthData.freshness[0].pct` -- unguarded array index + property
- `client/src/pages/insights.tsx:2142`: `pipelineHealthData.statusFlow[0].pct > 15` -- unguarded
- `client/src/pages/insights.tsx:2143`: `pipelineHealthData.statusFlow[0].pct` -- unguarded
- `client/src/pages/insights.tsx:2087-2088`: `seg.pct` inside a `.map()` -- unguarded
- `client/src/pages/insights.tsx:2136`: `stage.pct` inside a `.map()` -- unguarded
- `client/src/pages/insights.tsx:653`: `pipelineHealthData = pipelineAnalytics.data?.pipelineHealthData ?? defaultPipelineHealthData`
- `client/src/mocks/insights.ts:239-265`: `defaultPipelineHealthData` has `freshness` and `statusFlow` arrays populated

**Assessment:** The default mock data provides non-null arrays. Crash occurs only if the API returns `pipelineHealthData` with `freshness: []` (empty) or `statusFlow: []` (empty), which would cause `[0]` to be `undefined`. The risk is real but latent -- it depends on what the API returns. The fix (4 null guards or optional chaining) is still warranted.

---

### P0-3: Appointment Status Change Notifications Missing

**Wave Says:** `updateAppointment()` fires zero status change events. No SMS/notification sent when appointment status changes. (wave5-reconciled.md P0-3; wave2-reconciled.md Section 1.5)

**Code Status:** CONFIRMED -- `updateAppointment()` at `AppointmentService.ts:663-750` does a database UPDATE but never calls `sendAppointmentNotification()` or any trigger evaluation.

**Evidence:**
- `server/services/AppointmentService.ts:663-750`: `updateAppointment()` method performs SQL UPDATE, maps result, returns. No notification call. No trigger evaluation.
- `server/services/AppointmentService.ts:655`: `createAppointment()` calls `this.sendAppointmentNotification(appointment).catch(() => {})` -- notification fires on CREATE
- `server/services/AppointmentService.ts:937`: `bookFromVapiCall()` fires notification
- `server/services/AppointmentService.ts:1013`: `bookFromTavusSession()` fires notification
- `server/services/AppointmentService.ts:799`: `cancelAppointment()` fires notification via `notificationService.sendToOrgAdmins()`
- `server/routes/appointments.ts`: No calls to `triggerService.evaluateEvent()` for any appointment event

**Gap:** When a user changes an appointment status (confirmed, rescheduled, in_progress, completed, no_show) via the `PUT /api/appointments/:id` endpoint, NO notification fires and NO trigger evaluates. Only creates and cancels have notifications. The `appointment_created` trigger event type is defined in `server/services/TriggerService.ts:25` but there is no call site in `server/routes/appointments.ts` that fires it.

---

### P0-4: Zero Production Trigger Executions

**Wave Says:** 0/84 trigger executions completed in production. `lead_age_minutes >= 5` evaluated at import time. Business hours checking skips all. (wave5-reconciled.md P0-4)

**Code Status:** PARTIAL CONFIRMED -- Trigger infrastructure is wired and active. Business hours skipping is confirmed in code. hot_lead event type has no call site. Execution failures are consistent with business hours rejection.

**Evidence:**
- `server/services/TriggerService.ts:22-29`: Event types defined: `new_lead`, `hot_lead`, `lead_status_change`, `appointment_created`, `missed_call`, `widget_interaction`, `sms_received`, `lead_idle`
- `server/services/TriggerService.ts:24`: `hot_lead` is defined as a type
- Search for `evaluateEvent.*hot_lead` across all server code: **zero results** -- hot_lead is never emitted
- `server/services/TriggerService.ts:189-205`: `businessHoursOnly` check explicitly skips with status `'skipped'` and logs "Outside business hours"
- `server/webhooks/vapi.ts:388`: `triggerService.evaluateEvent(organizationId, 'missed_call', {...})` -- missed_call is fired
- `server/routes/sms.ts:303`: `triggerService.evaluateEvent(resolvedOrgId, 'sms_received', {...})` -- sms_received is fired
- `server/jobs/vinLeadPollingJob.ts:341`: `triggerService.evaluateEvent(orgId, 'new_lead', {...})` -- new_lead is fired
- `server/jobs/idleLeadChecker.ts:218`: `triggerService.evaluateEvent(lead.organizationId, 'lead_idle', {...})` -- lead_idle is fired
- `server/jobs/triggerReevalJob.ts:163`: `triggerService.evaluateEvent(...)` -- re-evaluation job fires events
- `server/routes/leads.ts:508`: `triggerService.evaluateEvent(organizationId, 'lead_status_change', {...})` -- lead_status_change is fired
- `server/services/WidgetInteractionService.ts:220`: `widget_interaction` is fired

**Gap Confirmed:** `hot_lead` event type is defined but has no emission call site in any route, service, or job. `appointment_created` trigger event type has no emission call site in the appointments route. The wave notes' claim about `lead_age_minutes >= 5` evaluated at import time needs live verification -- the `triggerReevalJob.ts` exists and runs every 5 minutes, so the static timing issue may be partially mitigated.

---

### P0-5: VAPI Webhook Ingestion Broken

**Wave Says:** `call.started` events never received in production. `handleEndOfCallReport` does UPDATE only (no INSERT). 66+ post-V2 calls lost to this bug. Owner stated this was resolved via config. (wave notes context note)

**Code Status:** PARTIAL -- The code has been updated. `handleCallStarted` now uses INSERT with ON CONFLICT DO UPDATE (UPSERT). The UPDATE-only behavior described in wave notes appears to have been patched.

**Evidence:**
- `server/webhooks/vapi.ts:262-296`: `handleCallStarted()` uses `INSERT INTO vapi_call_logs (...) ... ON CONFLICT (vapi_call_id) DO UPDATE SET status = ..., updated_at = NOW()` -- this is an UPSERT, not INSERT-only
- `server/webhooks/vapi.ts:213-215`: `case 'call.started': await handleCallStarted(payload, organizationId)` -- handler is registered
- `server/webhooks/vapi.ts:221-222`: `case 'end-of-call-report': await handleEndOfCallReport(...)` -- handler is registered
- `server/webhooks/vapi.ts:617-663`: Email notification idempotency guard exists and checks `notification_sent` flag

**Gap Assessment:** The code change from UPDATE-only to UPSERT appears to have been applied. The wave notes say "owner resolved via config." Whether the underlying infrastructure issue (why call.started was never received) is truly fixed requires LIVE VERIFICATION. The code is now defensive (UPSERT handles both first-time and retry), but production ingestion depends on VAPI dashboard config pointing server URL to the correct endpoint.

**Status:** UNVERIFIABLE from static code -- requires live production test to confirm events are now being received.

---

## 2. Payment-Critical Demo Items (The 7)

---

### DEMO-1: Metrics & Insights Display

**Wave Says:** Dashboard with DealerPulse health gauges, lead feed, team leaderboard. 4 org admin tiles + 4 staff tiles. 6 buildable reports. 3-zone alert system. DEMO-READY with caveats. (wave1-reconciled.md DEMO-1)

**Code Status:** PARTIAL

**Evidence:**
- `client/src/pages/main.tsx:68-93`: Role-based metric tiles defined for all 4 roles (super_admin, partner_admin, org_admin, org_staff) with correct labels per spec
- `client/src/pages/main.tsx:352`: `useDashboardTiles()` hook fetches live data from `/api/dashboard/tiles`
- `client/src/pages/main.tsx:353-371`: API data merged with static visual config (fallback to static if API fails)
- `client/src/pages/insights.tsx:1711-1722`: Top-level tabs: dashboard, reports, library, hunches -- no Goals tab, no standalone Activity tab
- `client/src/pages/insights.tsx:536-539`: DealerPulse imported and rendered via `useDealerPulse()` hook
- `client/src/pages/insights.tsx:983`: `<DealerPulsePanel />` rendered inside dashboard tab
- `client/src/pages/insights.tsx:1029-1031`: Reports tab has 3 sub-tabs (Loss Autopsy, Re-Engagement, Source Quality Trends)
- `client/src/pages/insights.tsx:1188-1190`: Channel analysis sub-tabs
- `client/src/pages/insights.tsx:1352-1354`: Trends sub-tabs

**Gap:**
- Main dashboard tiles: Live API wired (line 352), falls back to hardcoded static values if API fails. Values on main.tsx:81-92 are hardcoded strings ("$284K", "47 new"), not blanked-out -- if API fails, misleading numbers show.
- Insights crash risk (P0-2) still present for `freshness[0].pct` and `statusFlow[0].pct`
- Goals tab correctly absent from insights page (AC-053 met)
- DealerPulse panel is wired but requires a running DealerPulse job (4-hour interval)

---

### DEMO-2: Communications Agent Configuration

**Wave Says:** Communications Agent static, configured by Super Admin. 7 event types, 5 action types. Trigger CRUD. Skills architecture. Gap: hot_lead no call site, 0/84 executions. (wave1-reconciled.md DEMO-2)

**Code Status:** PARTIAL

**Evidence:**
- `server/services/TriggerService.ts:22-29`: 8 event types defined (added `lead_idle` beyond the 7 in wave notes)
- `server/routes/triggers.ts:48`: Lists `hot_lead` as a valid event type that UI can configure
- No `evaluateEvent('hot_lead', ...)` call anywhere in codebase -- confirmed by full search
- `server/routes/agents.ts:385`: `is_provisioned` check restricts non-SuperAdmin from modifying provisioned agents
- `database/migrations/034_skills_catalog.sql`: Skills catalog migration exists with 4 INSERT statements seeding skills
- `server/routes/skills.ts`: Full CRUD for skills catalog registered at `/api/skills`
- `server/routes.ts:104`: `app.use("/api/skills", skillsRoutes)` -- skills routes registered
- Trigger execution: business hours check at `TriggerService.ts:189` actively skips rules when outside hours

**Gap:**
- `hot_lead` event type: defined, configurable via UI, but never emitted -- any trigger rule using `hot_lead` will never fire
- `appointment_created` trigger event: defined at `TriggerService.ts:25`, listed in `triggers.ts:49`, but no call to `evaluateEvent('appointment_created', ...)` anywhere in appointments route or service
- Skills catalog seeded with 4 skills per migration (not 74 or 64+ as wave notes suggest -- needs DB verification)

---

### DEMO-3: Appointment Flow (Appointment -> Calendar -> VIN Note)

**Wave Says:** Calendar CRUD with drag-drop, RBAC, 10 endpoints, public confirmation. Appointment-to-VIN-note link unverified. VIN Solutions has no appointment endpoint. (wave1-reconciled.md DEMO-3)

**Code Status:** PARTIAL

**Evidence:**
- `server/routes/appointments.ts`: 10 endpoints confirmed (list, calendar, stats, create, get, update, delete, cancel, confirmation-token, confirm)
- `server/services/AppointmentService.ts:571-658`: `createAppointment()` -- inserts to appointments table, fires notification to org admins
- `server/services/AppointmentService.ts:663-750`: `updateAppointment()` -- NO VIN sync, NO trigger evaluation, NO status change notification
- `client/src/pages/work-center.tsx:85-100`: `AppointmentCalendar` component imported and used with FullCalendar
- `client/src/pages/work-center.tsx:267-268`: `useCalendarEvents` and `useCalendarAppointments` hooks wired
- No search for `sync_queue` insert from any appointment creation path -- **zero results** for appointment-triggered VIN sync
- `server/services/AppointmentService.ts`: No import of VinSolutionsService or SyncCoordinator

**Gap:**
- Appointment-to-VIN-note link: CONFIRMED MISSING. `createAppointment()` does not push anything to `sync_queue` or call VinSolutionsService. The "appointment note inserted into VIN Solutions lead" step described in wave notes does not exist in code.
- `updateAppointment()` fires no status change notifications (P0-3, confirmed above)
- `appointment_created` trigger event is never emitted from appointment creation path (neither `createAppointment` nor route handler)

---

### DEMO-4: Proactive Lead Follow-up (Outbound Call + Text)

**Wave Says:** TriggerService with outbound call via VAPI POST /call. Neglected Lead Auto-Call template. TextMagic SMS send endpoint wired. Gap: 0 completed trigger executions. VAPI phone numbers not assigned per org. (wave1-reconciled.md DEMO-4)

**Code Status:** PARTIAL

**Evidence:**
- `server/services/TriggerService.ts:359-592`: `executeOutboundCall()` and `initiateVapiCall()` implemented
- `server/services/TriggerService.ts:429`: `phoneNumberId: vapiPhoneNumberId` -- uses `config.phoneNumberId` from trigger rule `action_config`
- `server/services/TriggerService.ts:499-501`: `if (metadata.phoneNumberId) { vapiBody.phoneNumberId = ... }` -- phone number is optional, outbound call can proceed without it but VAPI will fail
- `server/services/TriggerService.ts:448`: Checks `process.env.VAPI_API_KEY` -- if not set, logs "VAPI_API_KEY not configured" and skips
- `server/services/TriggerService.ts:600-638`: `executeSendSMS()` wired to `TextMagicService.sendSMS()`
- `server/jobs/vinLeadPollingJob.ts:341`: `evaluateEvent(orgId, 'new_lead', {...})` fires when new lead polled -- this IS the proactive follow-up trigger point
- `server/jobs/idleLeadChecker.ts`: `lead_idle` event fired for leads idle > 15 minutes

**Gap:**
- VAPI phone number: `config.phoneNumberId` must be set in each trigger rule's `action_config`. If not configured per org, outbound calls will fail at VAPI API (missing required field). This is an operational configuration gap, not a code gap.
- Business hours: all rules with `businessHoursOnly: true` will skip if triggered outside org hours -- production triggers are being skipped for this reason per wave notes
- TextMagic SMS: code wired but 0 successful sends in production -- operational gap (credentials must be configured per org in `textmagic_config` table)

---

### DEMO-5: Reactive After-Hours Coverage

**Wave Says:** SMS after-hours AI responds via DealerBrain (Claude API). Conversation state tracking AI_ACTIVE / HUMAN_ACTIVE / DORMANT. Business hours configurable per org. Gap: SMS collision avoidance and business hours routing "Needs Work." (wave1-reconciled.md DEMO-5)

**Code Status:** PARTIAL

**Evidence:**
- `server/routes/sms.ts:303`: `evaluateEvent(resolvedOrgId, 'sms_received', {...})` -- trigger fires on inbound SMS
- `server/services/TextMagicService.ts`: Service exists for SMS operations
- No inspection of inbound SMS response logic (after-hours AI auto-response path) -- would require reading `sms.ts` route in detail
- `database/migrations/032_sms_business_hours.sql`: Migration exists specifically for SMS business hours
- `client/src/pages/work-center.tsx:494-1016`: Inbox/communication tab renders `<InboxPanel />` component

**Gap:** UNVERIFIABLE from surface-level code inspection whether the AI_ACTIVE / HUMAN_ACTIVE / DORMANT state machine is fully wired for production after-hours routing. The code structure exists. Whether the business hours check for SMS auto-response is actually wired to the org's hours configuration requires reading the inbound SMS handler.

---

### DEMO-6: Widgets (All 3 Deployment Modes)

**Wave Says:** Unified widget (50.13 KB bundle), embed code, hosted landing pages. 5 deployed slugs. Domain whitelisting required. Voice agent IDs not wired in widget config. P0 route bug (hosted pages). (wave1-reconciled.md DEMO-6)

**Code Status:** MOSTLY WORKING with confirmed gap

**Evidence:**
- `client/src/App.tsx:41`: Route `/w/:slug` -> `HostedPage` -> fetches `/api/pages/:slug` -- CORRECT, works
- `client/src/App.tsx:42`: Route `/p/:slug` -> `HostedPagePublic` -> fetches `/api/hosted-pages/public/:slug` -- NO server route at that path
- `server/routes/widget-public.ts:156-170`: CORS handler sets `Access-Control-Allow-Origin: *` (mirrors request origin, no whitelist check at CORS level)
- `server/routes/widget-public.ts:176-185`: Rate limiting: 100 requests/hour/IP confirmed
- `server/services/WidgetInteractionService.ts:110-123`: `resolveWidget()` checks `widget.allowedDomains.length > 0` -- if domains configured, validates origin; if no domains configured, any origin allowed
- `server/routes/widget-public.ts:204-207`: Returns 403 if domain not authorized
- `server/routes/widget-public.ts:694-695`: Video agent route checks `configChannels?.videoAgent?.personaId`

**Gap:**
- Domain whitelisting: Code is correct but operational -- if `allowedDomains` is empty (no domains configured for org's widgets), ANY domain can use the widget. Customer domains are not configured in prod per wave notes.
- `/p/:slug` route is broken (P0-1 confirmed)
- `/w/:slug` route is working

---

### DEMO-7: Automa Chat

**Wave Says:** DealerBrain with 24 tools, SSE streaming, Claude API. Goal awareness injected. Floating overlay. Conversation history, favorites, suggested prompts. DEMO-READY. (wave1-reconciled.md DEMO-7)

**Code Status:** IMPLEMENTED

**Evidence:**
- `server/services/DealerBrainService.ts`: 3,106 lines -- confirmed
- `server/services/DealerBrainStreamingService.ts`: 2,020 lines -- confirmed
- `server/services/DealerBrainService.ts:93-636`: Tool definitions: `query_leads`, `query_calls`, `query_video_sessions`, `get_lead_stats`, `get_call_stats`, `get_session_stats`, `query_vin_customers`, `get_vin_lead_stats`, `get_vin_dealer_info`, `query_leads_multi_org`, `get_multi_org_stats`, `send_sms`, `get_sms_history`, `send_email`, `get_goals`, `update_goal_progress`, `create_goal`, `analyze_pipeline`, `create_vin_lead`, `generate_lead_report`, `query_appointments`, `query_tasks`, `query_aging_leads`, `create_agent` -- 24 tool name entries confirmed
- Wave notes claim "24 tools" -- code has exactly 24 named tool entries in the TOOLS array
- SSE streaming: `POST /api/conversations/:id/stream` exists in `server/routes/conversations.ts`
- `client/src/pages/main.tsx`: FloatingChat pattern for global overlay

**Gap:** None confirmed from static analysis. DealerBrain is the most complete feature.

---

## 3. Watch Areas

---

### WATCH-1: Agent Functionality / Defaults

**Wave Says:** Default seed agents: Automa (system, undeletable), Sales Coach, Message Crafter, VAPI voice agent. Communications Agent static, Super Admin configured. Skills catalog draws from V1's 27 agents. 12 active agents in production (0 video). (wave1-reconciled.md WATCH-1)

**Code Status:** PARTIAL

**Evidence:**
- `server/routes/agents.ts:123`: Agent type `'chat'` is a valid provisioned type
- `server/routes/agents.ts:300`: "Provisioned types (voice, video, chat) require Super Admin"
- `server/routes/agents.ts:317`: Valid types: `voice, video, chat, email, task` -- 5 types
- `database/seed.sql`: Does NOT insert any seed agents (only orgs, roles, users, integrations)
- `database/migrations/040_agent_provisioning.sql`: Provisioning migration likely seeds agents -- needs confirmation
- Skills catalog: `database/migrations/034_skills_catalog.sql` has 4 INSERT statements (not 74 or 64+)
- `server/routes/skills.ts`: Skills CRUD wired at `/api/skills`
- `server/routes.ts:104`: `app.use("/api/skills", skillsRoutes)` registered
- Automa exclusion from Agents list: No code found that explicitly filters `name = 'Automa'` or `type = 'system'` from the agent list query

**Gap:**
- Default agent seeding: Not in `seed.sql`. Need to verify `database/migrations/040_agent_provisioning.sql` to confirm default agent seeds exist.
- Skills catalog size: Migration 034 inserts 4 skills only -- NOT 74 or 64+. The wave notes claim "74 from V1" but code shows only 4 seeded.
- Automa exclusion: No explicit filter found in agents list query -- if Automa is stored in `agents` table, it may appear in the list (AC-071 says it should NOT).

---

### WATCH-2: Billing

**Wave Says:** Backend: CreditService wired, credit_policies, credit_allocations, credit_usage tables. Frontend: Billing page commented out as PHASE-FUTURE. Credits page route commented out. (wave1-reconciled.md WATCH-2)

**Code Status:** PARTIALLY IMPLEMENTED -- contrary to wave notes, billing IS wired

**Evidence:**
- `server/routes/billing.ts`: Full billing routes file exists with endpoints for config, dashboard, invoices, usage, tool-economy
- `server/routes.ts:40`: `import billingRoutes from "./routes/billing.js"`
- `server/routes.ts:178`: `app.use("/api/billing", billingRoutes)` -- REGISTERED (not commented out)
- `client/src/App.tsx:95-101`: `/billing` route IS registered (not commented out)
- `client/src/App.tsx:22`: `BillingManagementPage` imported
- `client/src/pages/billing-management.tsx:51-60`: Uses `useBilling`, `useBillingConfig`, `useBillingDashboard` hooks
- `client/src/hooks/useBilling.ts`: Full billing hooks file exists with 8 API endpoints
- `client/src/App.tsx:88-93`: `/credits` route IS registered (CreditsPage)

**Gap:**
- Wave notes claim billing and credits routes are "commented out as PHASE-FUTURE" -- this is INCORRECT in current code. Both routes are active. The wave notes may have captured a prior state.
- This is a POSITIVE finding: billing infrastructure is more complete than wave notes suggest.
- Whether the billing backend endpoints actually return real data (vs. empty/error responses) is UNVERIFIABLE without live testing.

---

### WATCH-3: Unified Inbox Handoff

**Wave Says:** InboxPanel merges SMS + widget chat + email. External conversations can be continued internally. inbox_conversations and inbox_messages tables exist. Handoff mechanics not documented. (wave1-reconciled.md WATCH-3)

**Code Status:** PARTIAL

**Evidence:**
- `client/src/pages/work-center.tsx:99`: `import { InboxPanel } from '@/components/inbox/InboxPanel'` -- imported
- `client/src/pages/work-center.tsx:1016`: `<InboxPanel />` rendered in communication tab
- `client/src/pages/work-center.tsx:117`: `inbox: 'communication'` -- tab redirect maps 'inbox' to 'communication' tab
- `client/src/pages/work-center.tsx:494-502`: Communication tab (value="communication") is the 5th of 6 tabs
- `client/src/pages/work-center.tsx:477-506`: Work-center tabs are: calendar, tasks, hunches, approvals, communication, leads -- NOT "Calendar, Leads, Inbox" as wave notes specify (Hub tab count)
- `client/src/hooks/useInbox.ts`: `useInboxUnreadCount` exists -- wired for unread count badge

**Gap:**
- Hub tab structure: Wave notes say 3 tabs (Calendar, Leads, Inbox per AC-090 / CONFLICT-R02 resolution). Actual code has 6 tabs: calendar, tasks, hunches, approvals, communication, leads. The "Inbox" tab is called "communication" and contains `<InboxPanel />`. The wave notes' "3 tab" resolution has NOT been applied to the code.
- The inbox/communication relationship is renamed but the tab count is 6, not 3.

---

### WATCH-4: Super Admin Functionality

**Wave Says:** Super Admin has platform-wide access. All 14 admin endpoints are Super Admin only. Emergency kill switch in AI Configuration. Skills tab Super Admin only. (wave1-reconciled.md WATCH-4)

**Code Status:** IMPLEMENTED (code level)

**Evidence:**
- `server/routes/admin.ts`: 14 endpoints registered (from wave3-reconciled.md citation)
- `server/routes.ts:various`: `requireSuperAdmin` middleware applied to admin routes
- `client/src/App.tsx:95`: `/billing` route exists (Super Admin visibility)
- Settings page RBAC: would require reading `client/src/pages/settings.tsx` for full verification
- Skills: `server/routes/skills.ts:58`: `router.post('/', requireSuperAdmin, ...)` -- create skill requires Super Admin
- Skills: `server/routes/skills.ts:140`: `router.delete('/:id', requireSuperAdmin, ...)` -- delete requires Super Admin

**Gap:** UNVERIFIABLE whether the full Super Admin experience works end-to-end without live testing. Code structure appears correct.

---

### WATCH-5: Context Router Functionality

**Wave Says:** SourceSelector VIN API primary, local DB fallback. Source tags internal only. Cache 5 min VIN, 1 hour VAPI/Tavus. excel_upload exclusion across 32+ queries. CONTEXT_ROUTER_ENABLED=true in .env. (wave1-reconciled.md WATCH-5)

**Code Status:** IMPLEMENTED

**Evidence:**
- `server/services/contextRouter/ContextRouterService.ts`: Exists
- `server/services/contextRouter/SourceSelector.ts:75-250`: `SourceSelector` class with `DEFAULT_CACHE_TTL_MS` and `HISTORICAL_CACHE_TTL_MS`
- `server/services/contextRouter/CacheManager.ts`: Exists
- `server/services/contextRouter/index.ts`: Barrel export
- excel_upload exclusion: `grep -rn "excel_upload" server/` returns 44 matches -- confirmed across multiple service files

**Gap:** None confirmed from static code. CONTEXT_ROUTER_ENABLED env var not verifiable from static analysis.

---

## 4. Other Significant Gaps Found

---

### GAP-A: Hub Tab Count Mismatch

**Wave Says:** Hub has exactly 3 tabs: Calendar, Leads, Inbox. Owner-confirmed. Both agents agree. CONFLICT-R02 resolved as "3 tabs." (wave4-reconciled.md AC-090; CONFLICT-R02)

**Code Status:** DOES NOT MATCH

**Evidence:**
- `client/src/pages/work-center.tsx:473-506`: 6 TabsTrigger elements: calendar, tasks, hunches, approvals, communication, leads
- `client/src/pages/work-center.tsx:494-502`: "communication" tab contains `<InboxPanel />` (the inbox)
- The wave notes' "3 tab" agreement has NOT been applied. There are 6 tabs in current code.

**Gap:** Work-center has 6 tabs (calendar, tasks, hunches, approvals, communication, leads). Wave notes and AC say it should have 3 (calendar, leads, inbox). The difference:
- "tasks" tab exists in code -- spec says remove
- "hunches" tab exists in code -- spec says this moves to Insights
- "approvals" tab exists in code -- spec does not list it as a Hub tab
- "communication" (inbox) exists -- this is the correct Inbox tab
- Leads and calendar exist -- correct

---

### GAP-B: Goals Tab in Insights vs Work-Center

**Wave Says:** Goals REMOVED from Insights per DevDesign Notes. Backend persists. (wave4-reconciled.md AC-053 / CONFLICT-R05)

**Code Status:** CORRECTLY IMPLEMENTED -- Goals is not a tab in insights.tsx

**Evidence:**
- `client/src/pages/insights.tsx:1711-1722`: Tabs are: dashboard, reports, library, hunches -- NO goals tab
- `client/src/pages/insights.tsx:632`: Comment: "Goals (production hook -> not used in Dashboard tab yet, staged for future)"
- `server/routes/goals.ts`: Exists (backend wired)
- `client/src/hooks/useGoals.ts`: Exists (hook wired)

**Assessment:** Goals correctly removed from Insights page UI. Backend and hooks exist for future use.

---

### GAP-C: Activity Page Location

**Wave Says:** Activity moved to Insights sub-tab per DevDesign Notes. CONFLICT-R06 resolved as "inside Insights." (wave4-reconciled.md AC-054 / CONFLICT-R06)

**Code Status:** DOES NOT MATCH

**Evidence:**
- `client/src/App.tsx:109-114`: `/activity` route renders standalone `<ActivityPage />` in AppLayout
- `client/src/pages/insights.tsx:1711-1722`: Top-level insights tabs are: dashboard, reports, library, hunches -- NO activity tab
- `client/src/pages/activity.tsx`: Standalone activity page exists

**Gap:** Activity is a standalone sidebar page at `/activity`, NOT a sub-tab in Insights. Wave notes say it should be inside Insights as a sub-tab. The code has not implemented this consolidation.

---

### GAP-D: RLS Variable Name Mismatch

**Wave Says:** SecureQueryBuilder sets `app.current_organization_id` but RLS policies check `app.current_org_id`. System works because routes bypass SecureQueryBuilder and use `set_config('app.current_org_id', ...)` directly. (wave3-reconciled.md Section 3.2)

**Code Status:** CONFIRMED

**Evidence:**
- `server/db/SecureQueryBuilder.ts:86`: Comment says `app.current_organization_id`
- `server/db/SecureQueryBuilder.ts:244`: `SET LOCAL app.current_organization_id = ...`
- `database/migrations/013_create_widget_tables.sql:142`: RLS policy checks `current_setting('app.current_org_id', true)`
- `database/migrations/015_hosted_pages.sql:38`: RLS policy checks `current_setting('app.current_org_id', true)`
- `server/routes/insights.ts:49`: `SELECT set_config('app.current_org_id', $1, true)` -- bypasses SecureQueryBuilder
- `server/routes/leads.ts:63`: `SELECT set_config('app.current_org_id', $1, false)` -- bypasses SecureQueryBuilder
- `server/routes/widgets.ts:27`: `SELECT set_config('app.current_org_id', $1, false)` -- bypasses SecureQueryBuilder
- `server/routes/triggers.ts:37`: `SELECT set_config('app.current_org_id', $1, false)` -- bypasses SecureQueryBuilder

**Gap:** The variable name mismatch is confirmed. SecureQueryBuilder is architecturally broken (sets wrong variable name), but routes work by bypassing it with direct `set_config` calls. If any route is refactored to use SecureQueryBuilder instead of direct pool queries with `set_config`, RLS will silently fail and data will leak across orgs.

---

### GAP-E: Vendor Names in User-Facing UI

**Wave Says:** No vendor names (VIN Solutions, VAPI, Tavus, TextMagic) in user-visible UI. (wave4-reconciled.md AC-016)

**Code Status:** PARTIAL VIOLATION

**Evidence:**
- `client/src/pages/settings.tsx:1880`: Dialog title `"Add VIN Solutions Integration"` -- visible to org admin users
- `client/src/pages/settings.tsx:1982`: Button text "Add VIN Solutions" -- visible to org admin users
- `client/src/pages/settings.tsx:1995`: `'VIN Solutions'` displayed as integration name -- visible
- `client/src/pages/settings.tsx:2057-2059`: "About VIN Solutions Integration" section -- visible
- `client/src/data/help-content.ts:103`: "integrations (VIN Solutions, VAPI, Tavus)" in help text
- `client/src/pages/activity.tsx:546`: "generated by DealerBrain" -- internal name visible to users

**Gap:** VIN Solutions appears in Settings > Tools & Integrations as a visible vendor name. Wave notes and AC-016 state no vendor names in user-visible UI. The Settings integration UI uses "VIN Solutions" as the display name. VAPI and Tavus do not appear to be visible in the same way. The `activity.tsx` uses "DealerBrain" (internal name that should show as "Automa").

---

### GAP-F: DealerBrain Name in User-Facing UI

**Wave Says:** DealerBrain DOES NOT appear in UI. User sees "Automa" only. (wave4-reconciled.md AC-031 / CONFLICT-R07)

**Code Status:** MINOR VIOLATION

**Evidence:**
- `client/src/pages/activity.tsx:546`: "Charts, reports, and data exports generated by DealerBrain will appear here"
- All other client pages reviewed: no other "DealerBrain" occurrences in display text

**Gap:** One location in activity.tsx exposes the "DealerBrain" internal name to users. Should read "Automa" or "AI Assistant."

---

### GAP-G: Skills Catalog Size

**Wave Says:** 74 skills from V1 should populate catalog. DISAGREE-3: "64+ skill templates referenced." Both agents agree skills catalog exists. (wave4-reconciled.md AC-077)

**Code Status:** SIGNIFICANT DISCREPANCY

**Evidence:**
- `database/migrations/034_skills_catalog.sql:90-159`: Only 4 INSERT INTO skills statements
- `server/routes/skills.ts`: Skills CRUD exists and works
- No other migration or seed file adds skills

**Gap:** Migration 034 seeds exactly 4 skills. Wave notes say 74 skills from V1 (or 64+ per ANALYST). The catalog is almost empty. Any user attempting to "select from skills catalog" will see only 4 options, not the full set. This is a significant operational gap -- the skills architecture is coded but the catalog content is not populated.

---

### GAP-H: Appointment Notification for Status Changes

**Wave Says:** AC-094 says "appointment creation triggers lead insertion to VIN Solutions with appointment note." Wave also notes updateAppointment fires zero status change events. (wave4-reconciled.md AC-R072; wave2-reconciled.md Section 1.5)

**Code Status:** CONFIRMED MISSING (partially covered in P0-3)

**Evidence:**
- `server/services/AppointmentService.ts:663-750`: `updateAppointment()` -- SQL UPDATE only, no notification, no trigger, no VIN sync
- `server/services/AppointmentService.ts:571-658`: `createAppointment()` -- inserts to appointments table, fires org admin notification, but NO VIN sync queue insert

**Gap Summary for Appointments:**
1. `updateAppointment()` fires no notifications on status change -- P0-3 confirmed
2. `createAppointment()` fires notification but does NOT push to sync_queue or call VIN API
3. No `evaluateEvent('appointment_created', ...)` in any appointment creation path
4. No "appointment note to VIN lead" pipeline exists -- this AC requirement has no implementation

---

### GAP-I: VAPI Webhook Optional Secret Verification

**Wave Says:** VAPI webhook accepts requests without verification if header is absent. (wave3-reconciled.md Section 2.7)

**Code Status:** CONFIRMED

**Evidence:**
- `server/webhooks/vapi.ts:133-143`:
  ```
  if (vapiSecret && headerSecret) {
    const verification = verifyVapiSignature(headerSecret, vapiSecret);
    if (!verification.valid) { console.warn(...); }
  }
  ```
  No `return res.status(401)` after failed verification. Code logs a warning but continues processing.

**Gap:** VAPI webhook verification is optional (soft check). If `VAPI_WEBHOOK_SECRET` is not set OR header is absent, webhook processes without authentication. This is a security gap (any client can POST to `/api/webhooks/vapi` with crafted payloads).

---

### GAP-J: idle_trigger_count Never Resets

**Wave Says:** P1-3: `idle_trigger_count` never resets. (wave5-reconciled.md P1-3)

**Code Status:** CONFIRMED from job listing

**Evidence:**
- `server/jobs/idleLeadChecker.ts:14`: Comment says "Enforces max retry limit (default 3) per lead via idle_trigger_count column"
- `database/migrations/039_idle_trigger_columns.sql`: Migration exists for idle trigger columns

**Gap:** UNVERIFIABLE from static code whether reset logic exists. Would require reading full `idleLeadChecker.ts`. The wave notes confirm this as P1-3 gap.

---

## Summary Table

### P0 Gaps

| ID | Gap | Code Status | Fix Complexity |
|----|-----|-------------|----------------|
| P0-1 | Hosted pages route mismatch | CONFIRMED -- `/p/:slug` broken, `/w/:slug` works | TRIVIAL: redirect or add endpoint |
| P0-2 | Insights crash risk (4 null guards) | CONFIRMED -- 5 unguarded `.pct` accesses | TRIVIAL: optional chaining |
| P0-3 | Appointment status change notifications | CONFIRMED MISSING -- updateAppointment fires nothing | MODERATE: add event emission |
| P0-4 | Zero production trigger executions | CONFIRMED (business hours + hot_lead no-callsite) | MODERATE: fix business hours logic + add hot_lead emission |
| P0-5 | VAPI webhook ingestion | PARTIAL -- code now has UPSERT; production needs live test | UNVERIFIABLE -- requires live test |

### Payment-Critical Demo Items

| Demo | Status | Key Gap |
|------|--------|---------|
| DEMO-1: Metrics & Insights | PARTIAL | P0-2 crash risk; main tile static fallback may show wrong numbers |
| DEMO-2: Comms Agent | PARTIAL | hot_lead no callsite; appointment_created no callsite; 0 trigger executions |
| DEMO-3: Appointment Flow | PARTIAL | No VIN note link; no status change notifications; appointment_created trigger never fires |
| DEMO-4: Proactive Follow-up | NOT WORKING | 0 trigger executions; VAPI phone numbers not configured |
| DEMO-5: After-Hours Coverage | PARTIAL | SMS sends unverified in production; business hours routing unclear |
| DEMO-6: Widgets | MOSTLY WORKING | `/p/:slug` broken; `/w/:slug` works; domain whitelist not configured |
| DEMO-7: Automa Chat | IMPLEMENTED | No gaps from static analysis |

### Watch Areas

| Area | Status | Key Finding |
|------|--------|-------------|
| WATCH-1: Agent Defaults | PARTIAL | Skills catalog has 4 seeds (not 74); Automa exclusion filter not found in agents list query |
| WATCH-2: Billing | PARTIAL -- BETTER THAN EXPECTED | Billing routes ARE wired and registered (wave notes said commented out) |
| WATCH-3: Unified Inbox | PARTIAL | InboxPanel wired but Hub has 6 tabs, not 3 |
| WATCH-4: Super Admin | IMPLEMENTED (code level) | Needs live testing |
| WATCH-5: Context Router | IMPLEMENTED | excel_upload exclusion confirmed (44 occurrences) |

### Other Significant Gaps

| Gap | Severity | Status |
|-----|----------|--------|
| GAP-A: Hub has 6 tabs (not 3) | HIGH | Confirmed -- work-center.tsx has calendar, tasks, hunches, approvals, communication, leads |
| GAP-B: Goals correctly absent from Insights | PASS | Goals tab removed correctly |
| GAP-C: Activity is standalone, not in Insights | MEDIUM | Confirmed -- /activity route still exists as standalone page |
| GAP-D: RLS variable name mismatch | HIGH | Confirmed -- SecureQueryBuilder broken but bypassed |
| GAP-E: VIN Solutions name visible in Settings | LOW | "VIN Solutions" appears in Settings integration UI |
| GAP-F: DealerBrain name in activity.tsx | LOW | One occurrence; should say "Automa" |
| GAP-G: Skills catalog has 4 skills, not 74 | HIGH | Migration 034 seeds only 4 skills |
| GAP-H: No appointment-to-VIN-note pipeline | HIGH | Confirmed missing from createAppointment and updateAppointment |
| GAP-I: VAPI webhook optional verification | MEDIUM | Security soft-check, no rejection on failed verification |
| GAP-J: idle_trigger_count reset logic | P1 | Needs code-level verification |

---

*All findings are evidence-based. File paths are absolute. Line numbers are from direct code inspection. No inferences made beyond what the code shows.*
