# Wave 1 RECONCILED Output -- Business Context for PRD

**Agent:** ORCHESTRATOR (merging REVIEWER + ANALYST)
**Wave:** 1 (Business Context -> PRD)
**Date:** 2026-03-02
**Status:** PENDING OWNER REVIEW
**Method:** Independent extraction by two agents, merged with disagreements flagged

---

## Reconciliation Summary

| Metric | REVIEWER | ANALYST |
|--------|----------|---------|
| Files read | 50 of 53 (3 skipped) | 53 (all read) |
| Categories extracted | 10 | 10 |
| Demo items tagged | 7 | 7 |
| Watch areas documented | 5 | 5 |
| Conflicts detected | 6 | 10 |
| Missing information items | 8 | 12 |

**Agreement level: HIGH.** Both agents extracted substantially the same facts for all 10 categories. No contradictions between agents. Differences are in depth and scope, not in factual claims.

---

## DISAGREEMENTS REQUIRING OWNER RESOLUTION

### DISAGREE-1: File Read Coverage

- **REVIEWER** skipped 3 files: replit_reference.textClipping (binary), Chat-Checklist.pdf (blank), --Insights Layout copy.md (duplicate). Read 50 of 53.
- **ANALYST** claims to have read all 53 files.
- **Impact:** Minimal. The 3 skipped files are a binary artifact, a blank PDF, and a known duplicate. No information was lost.
- **Recommendation:** Accept. No owner action needed.

### DISAGREE-2: DealerBrain Tool List

- **REVIEWER** lists 24 specific tools by name (from REVERSE_SRS_old.md, lines 376-399): query_leads, query_vapi_calls, query_tavus_sessions, query_vin_data, create_goal, create_agent, get_lead_details, get_call_transcript, check_availability, create_appointment, create_task, send_sms, get_dashboard_metrics, get_dealer_pulse, query_credit_usage, get_org_settings.
- **ANALYST** states "24 tools referenced but complete list not in input files" and flags this as MISSING-9.
- **Resolution:** The REVIEWER found the list in REVERSE_SRS_old.md. The ANALYST missed it or read different lines. The tool list exists. Carry the REVIEWER's enumeration forward.
- **Owner action:** None needed. REVIEWER evidence is stronger here.

### DISAGREE-3: Skills Catalog Size

- **REVIEWER** references "skills catalog" without a size estimate.
- **ANALYST** states "64+ skill templates referenced" citing DESIGNER_UPDATE_SPEC.md Section 12 and Section 16.
- **Resolution:** The "64+" figure needs verification. If DESIGNER_UPDATE_SPEC.md Section 12 was only partially read (150 lines by REVIEWER), the ANALYST may have captured this from a different section or inferred it.
- **Owner action:** Confirm whether 64+ skill templates is a real specification or an aspirational number.

### DISAGREE-4: Conflict Count and Scope

- **REVIEWER** found 6 conflicts. **ANALYST** found 10 conflicts.
- The 6 REVIEWER conflicts are a subset of the ANALYST's 10. Both agents agree on the 6 shared conflicts. The ANALYST additionally found:
  - CONFLICT-7 (Goals feature location: removed from Insights per DevDesign Notes but still in implementation)
  - CONFLICT-8 (Work Center vs Hub naming)
  - CONFLICT-9 (Frontend framework: ARCHITECTURE_VISUAL_MAP.md says Next.js 14, actual is Vite + React 18)
  - CONFLICT-10 (Agent architecture vision vs reality: 7-layer aspirational map vs actual DealerBrain + basic Context Router)
- **Resolution:** All 4 additional ANALYST conflicts are valid and well-sourced. Carry all 10 forward.
- **Owner action:** Review CONFLICT-9 and CONFLICT-10. These indicate the ARCHITECTURE_VISUAL_MAP.md describes a design vision, not current implementation. Should the PRD reflect the vision, the reality, or both?

### DISAGREE-5: Missing Information Items

- **REVIEWER** found 8 missing items. **ANALYST** found 12 missing items.
- Items in BOTH: Subscription pricing (M-1/MISSING-2), Skills catalog (M-2/MISSING-8), Inbox handoff mechanics (M-3), Super Admin capabilities (M-4), Competitive analysis (implied in REVIEWER's Category 10 / MISSING-10).
- Items ONLY in REVIEWER: Partner credit pool mechanics (M-5), Orchestration agent decision (M-6), Inventory data strategy (M-7), Org creation wizard details (M-8).
- Items ONLY in ANALYST: Partner economics/compensation (MISSING-1), Customer success metrics/KPIs (MISSING-3), New vertical onboarding flow (MISSING-4), Disaster recovery (MISSING-5), API rate limits (MISSING-6), Video agent details (MISSING-7), DealerBrain tool list (MISSING-9 -- resolved above), Legal/compliance requirements (MISSING-11), Scalability plan (MISSING-12).
- **Resolution:** Merge all unique items. The ANALYST found more missing items because it cast a wider net for what a PRD "should" contain. Some ANALYST items (disaster recovery, scalability, legal compliance) are valid PRD concerns but may be out of scope for the current launch-critical focus.
- **Owner action:** Review the merged missing items list below and decide which are launch-critical vs deferred.

### DISAGREE-6: "NOT a lead generation tool" Source

- **REVIEWER** lists "NOT a lead generation tool" citing NEXXUS_V2_BOOTSTRAP_PROMPT.md, line 22.
- **ANALYST** does not include this specific negation.
- **Resolution:** The REVIEWER's citation is accurate. Carry forward. This is an important product boundary to include in the PRD.
- **Owner action:** None needed.

### DISAGREE-7: Backend Freeze Rule

- **REVIEWER** does not flag the backend freeze as a business rule.
- **ANALYST** includes it as a key business rule citing DO_NOT_TOUCH.md.
- **Resolution:** The backend freeze is real (345+ files frozen per DO_NOT_TOUCH.md), but it is a development constraint, not a business rule. It belongs in PLAN.md or CLAUDE.md, not PRD.md.
- **Owner action:** Confirm: should the backend freeze be mentioned in the PRD, or only in PLAN.md/CLAUDE.md?

### DISAGREE-8: MCP Proxy Documentation

- **REVIEWER** does not mention the Central-MCP proxy.
- **ANALYST** documents it in Section 6 (External Interaction Surfaces): located at ../central-mcp/ (port 4002), MCP proxy for Notion/Supabase/ClickUp/VAPI.
- **Resolution:** The Central-MCP is infrastructure context from session-knowledge.md. It is a development tool, not a product feature. It does not belong in the PRD.
- **Owner action:** Confirm: is Central-MCP user-facing functionality that should be in the PRD, or developer infrastructure?

---

## RECONCILED CATEGORIES (Merged Output)

The following merges both agents' findings. Where both agree, the stronger citation is used. Where one agent has additional detail, it is included with attribution.

### CATEGORY 1: Product Identity

**Both agents agree on all points. No disagreements.**

- **What Nexxus IS:**
  - "AI orchestration layer that bridges businesses, their data, third-party integrations, language models, and tools." (MASTER_SRS.md, Section 2.1)
  - "Partner-enabled platform." Domain experts recruit customers into segments and manage them through the platform. (app_identity.md, Section A3)
  - First vertical is automotive dealerships, but "the platform is industry-agnostic by design; automotive is the first vertical, not the only one." (app_identity.md, Section A2; MASTER_SRS.md, Section 2.2)
  - "Intelligent execution layer for automotive dealerships that solves response gaps and follow-up inconsistencies through AI-powered voice, video, and chat interactions." (NEXXUS_V2_BOOTSTRAP_PROMPT.md, line 20)
  - Core value proposition: "Dealerships don't lose because of lead volume -- they lose because of response gaps and execution failures. Nexxus fixes this." (CLAUDE.md line 9; NEXXUS_V2_BOOTSTRAP_PROMPT.md line 24)

- **What Nexxus IS NOT:**
  - NOT a CRM (app_identity.md, Section A6)
  - NOT a marketing automation tool (app_identity.md, Section A6)
  - NOT a content development platform (app_identity.md, Section A6)
  - NOT a lead generation tool (NEXXUS_V2_BOOTSTRAP_PROMPT.md, line 22) [REVIEWER only]

- **Platform Mental Model (Owner-Stated):**
  - External surfaces: VAPI voice, Tavus video, Widgets (chat/SMS/callback)
  - Internal surfaces: Automa Chat (DealerBrain), Agents page, Metrics/Insights, Hub (Calendar/Leads/Inbox)
  - Data flow layer: VIN Solutions CRM, internal PostgreSQL, user uploads, external service APIs
  - (session-knowledge.md, Section 0)

- **Operator:** Huminic (company), operated by Duane Wells. Live URL: https://nexxusv2.huminicdev.com

- **Naming Conventions:**
  - DealerBrain = the concept/system (AI intelligence layer)
  - Automa = the user-facing chat interface name
  - Skills = agent capabilities (user-selectable overlays with context + instructions)
  - No vendor names (Tavus, VAPI) in user-facing UI. Use "Voice Agent", "Video Agent", "AI Assistant" instead. (CONSTITUTION.md; MASTER_SRS.md, AC-002)

### CATEGORY 2: Target Customers

**Both agents agree. ANALYST adds onboarding requirements detail.**

- **Business Model:** Partner-enabled delivery. First partner: Duran Cage, automotive sales expert.

- **Current Customers:**

| Customer | Organizations | Status | Deployed |
|----------|--------------|--------|----------|
| Serra Automotive | Serra Honda (21043), Serra Nissan (21044), Tony Serra Ford (21047) | Live, paying | 2026-01-16 |
| Hyundai of Columbia | Hyundai of Columbia (6374), Ford of Columbia (3027) | Live, paying | 2026-01-16 |

- **Video Agents Deployed:** 5 named personas: Caroline, Magnolia, Georgia, Elizabeth, Savannah (REVERSE_SRS_old.md, line 116)

- **Target Verticals:** Automotive first, platform designed for any B2B vertical via partner model.

- **Onboarding Requirements per Customer** [ANALYST addition]: 11 items needed, 5 customer decisions required before go-live (CUSTOMER_ONBOARDING_KICKOFF.md, lines 30-80)

### CATEGORY 3: Business Model / Economics

**Both agents agree on all pricing and credit system details.**

| Service | Customer Rate | Platform Cost | Margin |
|---------|--------------|---------------|--------|
| Voice AI (VAPI) | $0.25/min | $0.15/min | 40% |
| Video AI (Tavus) | $0.32/min | $0.20/min | 37.5% |
| SMS (TextMagic) | $0.05/msg | $0.02/msg | 60% |

(MASTER_SRS.md, Section 12; CLAUDE.md, lines 317-319)

- **Credit System:** CreditService tracks usage per org. credit_policies, credit_allocations, credit_usage tables. Service quotas with 80% alert threshold. Wired to webhooks. (database-audit.md, tables 17-19)
- **Tool Provisioning:** Super Admin -> Partner Admin -> Org Admin. Tools "pushed down" to orgs. (ARCHITECTURE_GUIDE_RBAC_ADDITION.md)
- **Billing UI:** Commented out as PHASE-FUTURE in frontend. DESIGNER_UPDATE_SPEC.md specifies new Billing Page design. (client-audit.md, line 94)

### CATEGORY 4: User Roles & Permissions

**Both agents agree on the 4-tier RBAC model and access matrix.**

| Role | Level | Description | Typical User |
|------|-------|-------------|-------------|
| super_admin | 1 | Platform-wide access, provisions tools, manages partners | Huminic (Duane Wells) |
| partner_admin | 2 | Multi-org management, aggregate metrics, no PII | Duran Cage, partner operators |
| org_admin | 3 | Single org management, users, settings, full org data | Dealership Sales Manager, BDC Manager |
| org_staff | 4 | Daily operational use, personal leads/tasks only | Salesperson, BDC Agent |

(MASTER_SRS.md, Section 3.1-3.3; app_identity.md, Section D; CLAUDE.md, lines 303-307)

**Key Distinctions:**
- Staff CANNOT see Settings (===DevDesign Notes===.md)
- Partner Admin sees aggregate data, NO individual lead data (no PII) (MASTER_SRS.md, AC-010)
- Partner Admin has READ-ONLY view of AI Configuration (DESIGNER_UPDATE_SPEC.md)
- Org Admin sees all org data. Org Staff sees only own assignments (MASTER_SRS.md, Section 7.4)
- Activity page: Org Admin+ only (UI_DEVELOPER_HANDOFF.md)

**RBAC Settings Matrix** [ANALYST addition]:

| Tile | Super Admin | Partner Admin | Org Admin | Staff |
|------|:-----------:|:------------:|:---------:|:-----:|
| User Management | Yes | Yes | Yes | No |
| Organization | Yes | Yes | Yes | No |
| Tools & Integrations | Yes | Yes | Yes | No |
| Knowledge Base | Yes | Yes | Yes | No |
| AI Configuration | Yes | Read-Only | No | No |
| Security & Privacy | Yes | Yes | No | No |
| Notifications | Yes | Yes | Yes | No |
| Data Management | Yes | No | No | No |
| Appearance | Yes | Yes | Yes | No |

(DESIGNER_UPDATE_SPEC.md, lines 80-98)

### CATEGORY 5: Feature Inventory

**Both agents agree on all major features. Differences are in organization, not content.**

**Navigation (Left Sidebar):**
1. Main (Home/Chat) -- Automa chat interface
2. Insights -- Dashboard, Dealer Pulse, Goals, Hunches, Reports, Attribution
3. Agents -- Agent management, creation, chat interface
4. Hub (Work Center) -- Calendar, Leads, Inbox (3 tabs, owner-confirmed)
5. Drive -- File management, templates
6. Activity -- AI Governance (Org Admin+ only)
7. System (Settings) -- 9 tiles, role-gated
8. Profile -- Edit, preferences, integrations

**Automa Chat:**
- DealerBrain AI chat with SSE streaming via Claude API
- 24 tools for function calling (enumerated in REVERSE_SRS_old.md, lines 376-399)
- Conversation history, file upload, paste-data features
- FloatingChat global overlay (not inline on dashboard)
- Goal awareness injected into AI context

**Insights Section:**
- Dashboard: Command Center (3-zone Red/Yellow/Green alert), Pipeline Health, Performance Scorecard, DealerPulse health gauges, Lead Feed, Agent Actions, Team Leaderboard
- Goals: CRUD with status tracking, target values, periods
- Reports: 6 priority reports (Deal Death Autopsy, Lead Source Quality, Channel Performance, Pipeline Velocity, Active Lead Triage, Deal Status Snapshot) -- all "100% buildable" from available VIN data
- Hunches: AI detective agent generating cross-dimensional insights, 5-10 per run, confidence scoring
- Dealer Pulse: 5-phase health snapshots, 4-hour refresh cycle
- Attribution: Tracking pixel for UTM and page visit tracking

**Role-Based Dashboard Tiles:**

Partner Admin: # sub orgs, customer logins 24hrs, actions 24hrs, agent actions 24hrs

Org Admin (scored 0-100 each): Pipeline Health, Lead Source Performance, Lead Quality, Market Demand Insight

Staff (scored 0-100 each): Hot Opportunities, Buying Intelligence, Competitive Threat Alert, Pipeline Urgency

**Agents Page:**
- Three-column layout: agent list, chat interface, info/artifacts/stats panel
- Agent creation wizard: Basic Info, Channel Config (voice/video/chat/email/task), Skills, Triggers, Review
- Default seed agents: Automa (system, undeletable), Sales Coach, Message Crafter, VAPI voice agent
- Communications Agent: static, configured by Super Admin. 2 agents available out of box.
- Skills architecture: users CREATE agents and ADD skills. Same concept as V1's 27 agents but now user-selectable.
- 12 active agents in production: 5 voice, 2 chat, 4 task. 0 video (operational gap).

**Hub (Work Center):**
- 3 tabs (owner-confirmed per DESIGNER_UPDATE_SPEC.md): Calendar, Leads, Inbox
- Calendar: AppointmentCalendar + AppointmentModal, FullCalendar integration, drag-drop rescheduling
- Leads: Status management with mark-contacted
- Inbox: Universal inbox merging SMS + widget chat + email (InboxPanel)
- Quick action buttons, Dialer with keypad

**Drive:**
- File management with grid/list view toggle, folder navigation, breadcrumb trail
- Upload, create, delete, download. Storage usage display.

**Settings:**
- 9 tiles: Users, Organization, Tools & Integrations, Knowledge Base, AI Configuration, Security & Privacy, Notifications, Data Management, Appearance
- API & Webhooks removed as standalone tile, moved inside Tools & Integrations
- Org Creation Wizard (Super Admin only)
- Context Router should have 3 sections: Memory stores, Sync Data, Upload Data Store + Web/3rd party

**Widget System:**
- 6 channel options: Text Chat, Voice Inbound, Voice Outbound, Video Agent, Web Audio, Send a Text
- 3 deployment modes: unified floating widget, embed code, hosted landing pages
- Widgets are portals to agents (not standalone features)
- Domain whitelist enforcement, rate limiting (100 interactions/hour/visitor)
- Preact-based bundle: 50.13 KB minified

**Trigger System:**
- 7 event types: new_lead, lead_status_change, missed_call, appointment_scheduled, inbound_message, hot_lead, custom
- 5 action types: outbound_call, send_sms, send_email, create_task, webhook
- Rate limiting, business hours checking, prior-contact detection
- hot_lead event has NO firing call site in codebase
- 0/84 trigger executions completed in production

**Additional Features:**
- Product tour (driver.js) needs reactivation with RBAC
- Google Calendar OAuth per-user sync
- Email system: IMAP/SMTP + Resend for transactional
- Password reset flow
- Activity/AI Governance page with stats, feed, CSV export

### CATEGORY 6: External Interaction Surfaces

**Both agents agree. ANALYST adds TextMagic credential storage detail.**

**VAPI (Voice AI):**
- Master API key, assistants tagged with org metadata
- 15 of 16 endpoints accessible
- Webhook at `/api/webhooks/vapi`: processes call.started, call.ended, end-of-call-report, transcript, status-update
- Org resolution via metadata.organizationId or assistantId lookup
- 18 total assistants on VAPI account, 5 registered in V2 agents table
- Outbound call API: `POST https://api.vapi.ai/call` with assistantOverrides
- **CRITICAL:** Real-time webhook ingestion is broken. All 137 real records were BULK IMPORTED. call.started events not received. PM2 has restarted 3,247 times. (DATA_ACCURACY_REPORT.md)

**Tavus (Video AI):**
- Master API key, org-specific personas, HMAC-SHA256 webhook verification
- 10 of 11 endpoints accessible. `/landing-pages` returns 404
- Webhook at `/api/webhooks/tavus`: conversation.started, conversation.ended, replica.ready, video.ready
- No cost API available. Video cost tracking requires manual rate application ($0.20/min).

**TextMagic (SMS):**
- Per-org phone numbers, two-way via inbound webhook
- SMS outbound-only for now; bi-directional when each store gets own number
- AI SMS responses powered by DealerBrain (Claude API), NOT VAPI
- Conversation state tracking: AI_ACTIVE / HUMAN_ACTIVE / DORMANT
- Collision avoidance: human takeover stops AI responses
- Shared phone 18338096836 assigned to 3 orgs -- first DB match wins routing
- Credentials stored in DB per org (NOT env vars) -- uses textmagic_config table [ANALYST addition]
- TextMagic inbound webhook has no signature verification (TextMagic does not sign)

**Widgets:**
- Embeddable JavaScript widget serving as portal to VAPI, Tavus, and internal agents
- Hosted pages at `/w/:slug`: 5 deployed slugs
- 4 page types: chat, video, callback, multi

**Resend (Email)** [ANALYST addition]:
- Transactional email delivery for welcome emails, password resets, notification routing
- Email templates stored in database

**Google Calendar** [ANALYST addition]:
- OAuth integration for appointment sync
- Connect/disconnect/sync/toggle in profile preferences

### CATEGORY 7: Internal Interaction Surfaces

**Both agents agree on all points.**

**Automa Chat (DealerBrain):**
- Claude API integration with tool calling and SSE streaming
- DealerBrainService: 3,047 lines. DealerBrainStreamingService: 2,020 lines.
- 24 tools including: query_leads, query_vapi_calls, query_tavus_sessions, query_vin_data, create_goal, create_agent, get_lead_details, get_call_transcript, check_availability, create_appointment, create_task, send_sms, get_dashboard_metrics, get_dealer_pulse, query_credit_usage, get_org_settings
- Goal awareness injected into AI context
- System prompt should include explicit list of available vs blocked data (MASTER_SRS.md, AC-011)

**Agents Page:**
- IS the chat agents feature. `type` field = channel integration.
- Users CREATE agents and ADD skills (V2 architecture). Skills catalog draws from what V1's 27 agents used to do.

**Unified Inbox:**
- Merges SMS, widget chat, and email into single inbox
- External agent conversations can be continued internally by staff
- Continuity between external and internal surfaces

**Metrics / Insights:**
- 50+ derivable metrics across 5 categories
- Metrics fragmented across ~5 services, need consolidation into unified MetricsEngine
- 80+ computable metrics from VIN Solutions data documented

**Notification System** [ANALYST addition]:
- In-app notifications with bell icon badge
- Email notifications via Resend, SMS notifications via TextMagic
- Notification settings per user per channel per event type
- Idempotency via notification_sent flag on vapi_call_logs

### CATEGORY 8: Data Sources & Architecture

**Both agents agree on truth hierarchy and all data source details.**

**Truth Hierarchy:**

| Priority | Source | Notes |
|----------|--------|-------|
| 1 (highest) | VIN Solutions API | Authoritative CRM data |
| 2 | VAPI / Tavus webhooks | AI interaction records |
| 3 | Local database | Nexxus-internal data |
| 4 (lowest) | Derived / computed | Metrics, scores, aggregations |

**Context Router:**
- SourceSelector: VIN API primary, local DB fallback
- CONTEXT_ROUTER_ENABLED=true in .env
- Source tags (VIN, VAPI, TAVUS, LOCAL) internal only, NOT shown in UI
- Cache TTL: 5 min VIN, 1 hour VAPI/Tavus, no cache local
- excel_upload excluded from ALL lead queries (32+ queries, 11 files)
- Was initially inverted -- corrected

**VIN Solutions API:**
- OAuth 2.0 Client Credentials, tokens expire every 60 minutes
- 13 accessible endpoints, 17 blocked (403)
- Lead creation is 2-step: create contact -> create lead with href references
- Headers: lowercase v3 required (production rejects uppercase)
- Rate limits: 250ms minimum delay between calls
- CAN measure: AI performance, pipeline state, outcomes, vehicle demand, staff roster
- CANNOT measure: human execution quality, deal economics, appointment conversion, inventory metrics, CRM activity detail

**Data Refresh Strategy:**
- Hybrid: pull once a day + manual refresh button
- VIN polling every 4 hours, discreet refresh button

**Database:**
- 53 tables with 100% RLS coverage. ~100 RLS policies. 160+ indexes. 33 migrations.
- Supabase (PostgreSQL) with pgbouncer connection pooling
- CRITICAL: RLS variable name mismatch (app.current_organization_id vs app.current_org_id)

**VIN Data Reality** [ANALYST addition]:
- Nexxus sees beginning (lead creation) and end (SOLD/LOST status) but NOT the middle (deals, follow-ups, execution)
- Many VIN fields sparsely populated (sellingPrice, downPaymentRequested often null)
- >50% field fill rate required per Constitution for metric certification

**Integrations (7 Third-Party):**

| Integration | Auth | Purpose |
|-------------|------|---------|
| VIN Solutions | OAuth2 Client Credentials | CRM data |
| VAPI | Webhook + shared secret | Voice AI |
| Tavus | HMAC-SHA256 + API key | Video AI |
| Resend | API key | Email |
| TextMagic | Username + API key | SMS |
| Anthropic Claude | API key | AI chat/tools |
| Google Calendar | OAuth2 Authorization Code | Calendar sync |

**Scheduled Jobs (8):**

| Job | Interval | Purpose |
|-----|----------|---------|
| VIN Token Refresh | 30 min | OAuth token refresh |
| Sync Queue Worker | 1 min (out), 4 hrs (in) | VIN sync |
| Appointment Reminder | 5 min | 24h and 2h reminders |
| Email Sync | 5 min | IMAP sync |
| VIN Lead Polling | 60 min | Import new leads |
| Trigger Re-evaluation | 5 min | Age-based triggers |
| Dealer Pulse | 4 hrs | Health snapshots |
| Hunch Generation | 6 hrs | AI insights |

### CATEGORY 9: Key Business Rules

**Both agents agree. ANALYST adds non-destructive operations and certification-over-credit principles.**

- **Data accuracy is non-negotiable.** Metric certification requires: >50% fill rate, ground truth within 2%, accessible data source. (MASTER_SRS.md, Section 8.2; CONSTITUTION.md)
- Metrics depending on blocked endpoints excluded entirely -- not shown, not placeholdered
- No source labels visible to end users. No placeholder UI. No vendor names in UI.
- Most actionable activities go through an agent at the user level
- Communication agent cannot be modified by user except triggers and instruction supplement
- Scheduling is a hub action (both user and agent can do it)
- Lead assignment is NOT part of requirements
- Appointments go in OUR calendar (not VIN Solutions -- VIN has no appointment endpoint)
- Google Calendar is sync target, not source of truth
- RLS from day 1. JWT auth (NOT express-session). AES-256-GCM encryption for OAuth tokens.
- Multi-tenant isolation at database level via organization_id FK + RLS
- DealerBrain must not fabricate information. When asked about blocked data, explain unavailability.
- **Non-destructive operations:** Soft deletes preferred, audit logging for sensitive operations, no cascading deletes without approval. (CONSTITUTION.md) [ANALYST addition]
- **Certification over credit:** Features must be verifiable, not just claimed. 3-proof validation. (CONSTITUTION.md) [ANALYST addition]
- **Excel upload exclusion:** Records imported via excel upload excluded from ALL lead queries. 32+ queries across 11 files. (DEVELOPMENT_TEAM_BRIEFING.md) [ANALYST addition]

### CATEGORY 10: Competitive Positioning

**Both agents agree: no explicit competitors named in any file.**

- AI-first platform (not retrofitted AI onto existing tool)
- Partner-enabled model scales via domain experts
- Bridges multiple AI modalities (voice, video, chat, SMS) in one platform
- Widgets are portals to agents with staff follow-up continuity
- Orchestration layer that works WITH existing CRM, not replacing it
- Traditional BDC (Business Development Center) is human-staffed; Nexxus automates this [ANALYST addition]
- White-label capability (org branding limited to logo + 2 colors) [ANALYST addition]

---

## RECONCILED PAYMENT-CRITICAL DEMO ITEMS

### DEMO-1: Metrics & Insights Display Correctly

**Both agents agree. Status: DEMO-READY with caveats.**

- Dashboard with DealerPulse health gauges, lead feed, team leaderboard implemented
- All queries use real DB sources, excel_upload excluded, source labels masked
- 4 org admin tiles + 4 staff tiles defined with score formulas
- 6 buildable reports
- 3-zone alert system (Red/Yellow/Green)
- **Risk (both agents):** Metrics fragmentation across 5 services needs consolidation. VAPI webhook ingestion broken may mean incomplete call metrics.
- **Status per CUSTOMER_ONBOARDING_KICKOFF.md:** Ready to demo

### DEMO-2: Communications Agent Configuration

**Both agents agree. Status: PARTIALLY READY -- trigger execution gap.**

- Communications Agent is static, configured by Super Admin
- 7 event types, 5 action types in trigger system
- Conditional triggers configurable per agent
- Skills-based agent creation (V2 architecture)
- **Gap (both agents):** hot_lead event has no firing call site. 0/84 trigger executions completed.
- **ANALYST addition:** 64+ skill templates referenced but catalog content not documented

### DEMO-3: Appointment Flow

**Both agents agree. Status: PARTIALLY READY -- VIN note gap.**

- Calendar CRUD with drag-drop, RBAC, 10 endpoints, public confirmation with signed JWT
- Appointment reminders via SMS/email
- **Gap (both agents):** No explicit evidence of "appointment note inserted into VIN Solutions lead" step. Lead creation pipeline exists but appointment-to-VIN-note link unverified.
- VIN Solutions has NO appointment endpoint (403)
- **ANALYST addition:** 0 video agents in production (migration 033 may not be applied)

### DEMO-4: Proactive Lead Follow-up

**Both agents agree. Status: NOT READY -- 0/84 executions, no phone numbers.**

- TriggerService with outbound call via VAPI POST /call
- "Neglected Lead Auto-Call" template ready
- TextMagic SMS send endpoint wired
- #1 PRIORITY stated by owner
- **Gap (both agents):** 0 completed trigger executions. VAPI phone numbers not assigned per org.

### DEMO-5: Reactive After-Hours Coverage

**Both agents agree. Status: PARTIALLY READY -- shared phone, business hours routing "Needs Work".**

- SMS after-hours AI responds via DealerBrain (Claude API)
- Conversation state tracking: AI_ACTIVE / HUMAN_ACTIVE / DORMANT
- Business hours configurable per org
- **Gap (both agents):** SMS collision avoidance and business hours routing listed as "Needs Work." Shared phone number across 3 orgs.

### DEMO-6: Widgets (All 3 Modes)

**Both agents agree. Status: PARTIALLY READY -- P0 route bug, domain whitelisting needed.**

- Unified widget: 50.13 KB bundle, 19 configs, 6 channels
- Embed code implemented
- Hosted pages: 5 deployed slugs, all HTTP 200
- **Known P0 (both agents):** Hosted pages route mismatch (client fetches /api/hosted-pages/public/:slug, server serves /api/pages/:slug). One-line fix.
- **Gap (both agents):** Customer domains not whitelisted. Voice agent IDs not wired in widget config. Serra Honda video disabled.

### DEMO-7: Automa Chat

**Both agents agree. Status: DEMO-READY.**

- DealerBrain with 24 tools, SSE streaming, Claude API
- Goal awareness injected into AI context
- Floating overlay on all pages
- Conversation history, favorites, suggested prompts
- **Status per CUSTOMER_ONBOARDING_KICKOFF.md:** Ready to demo for Serra orgs

---

## RECONCILED WATCH AREAS

### WATCH-1: Agent Functionality / Defaults

**Both agents agree. ANALYST adds V1-to-V2 transition risk.**

- Default seed agents: Automa (system, undeletable), Sales Coach, Message Crafter, VAPI voice agent
- Communications Agent: static, Super Admin configured. 2 agents out of box.
- Skills architecture: users create agents and add skills from catalog
- Agent page IS the chat agents feature. type = channel integration.
- 12 active agents in production: 5 voice, 2 chat, 4 task. 0 video (operational gap).
- **Risk (ANALYST):** V1-to-V2 transition is the "single biggest knowledge gap" -- any agent working on this without understanding the transition will make the same mistakes as Run 2.
- **Missing:** Complete skills catalog definition. What skills exist and what they do.

### WATCH-2: Billing

**Both agents agree.**

- Backend: CreditService wired, credit_policies, credit_allocations, credit_usage tables exist, service_quotas with 80% alert
- Frontend: Billing page commented out as PHASE-FUTURE. Credits page route commented out.
- DESIGNER_UPDATE_SPEC specifies new Billing Page design (credit balance, usage charts, invoice history)
- **Status:** Backend wiring complete, frontend deferred. No customer-facing billing UI exists.
- **Missing:** Subscription pricing model (how much per month/seat). Only per-usage rates documented.

### WATCH-3: Unified Inbox Handoff

**Both agents agree. Neither found detailed handoff mechanics.**

- InboxPanel merges SMS + widget chat + email in Hub -> Inbox tab
- External agent conversations can be continued internally by staff
- inbox_conversations and inbox_messages tables exist
- Compose functionality via ComposeEmailModal with Tiptap rich-text editor [ANALYST addition]
- **Missing (both):** End-to-end handoff workflow not documented. How does an external widget conversation transition to an internal inbox thread? What triggers the handoff? Automatic or manual?

### WATCH-4: Super Admin Functionality

**Both agents agree. ANALYST adds AI Configuration details.**

- Super Admin has platform-wide access. All 14 admin endpoints are Super Admin only.
- Super Admin visible features: Users, Organizations, Partner Links, Tools, Hunches, Automa (in Settings)
- Data Management tile: Super Admin ONLY
- AI Configuration: full access including emergency kill switch and skills tab. Partner Admin gets read-only on System Prompt and Agent Behavior tabs. [ANALYST addition]
- Total metrics visible: 5 system-wide health, cost, usage metrics minimum
- **Gap:** "Super Admin functionality is undertested."
- **Missing (both):** No document comprehensively lists all Super Admin capabilities.

### WATCH-5: Context Router Functionality

**Both agents agree. REVIEWER has more technical detail.**

- SourceSelector: VIN API primary, local DB fallback
- Source tags internal only, not UI. Cache: 5 min VIN, 1 hour VAPI/Tavus.
- excel_upload exclusion across 32+ queries, 11 files
- Was inverted (local primary, VIN fallback) -- corrected
- Service files: ContextRouterService.ts, SourceSelector.ts, CacheManager.ts
- Owner wants 3 sections in UI: Memory stores, Sync Data, Upload Data Store + Web/3rd party
- **Missing:** How Context Router decides between sources for non-lead data (e.g., VAPI call logs, Tavus sessions).

---

## RECONCILED CONFLICTS (All 10)

| # | Conflict | Sources | Resolution |
|---|----------|---------|------------|
| C-1 | Hub tab count (3 vs 5) | DESIGNER_UPDATE_SPEC vs ARCHITECTURE_GUIDE, UI_DEVELOPER_HANDOFF | 3 tabs per owner decision. Older docs are wrong. |
| C-2 | Table count (36 vs 53) | CLAUDE.md vs database-audit.md, REVERSE_SRS_old.md | 53 is correct. CLAUDE.md is stale. |
| C-3 | E2E test count (376 vs 747 vs 1,699) | CLAUDE.md vs health-audit.md vs MASTER_SRS.md | 747 test blocks. CLAUDE.md stale. 1,699 may include assertions. |
| C-4 | API endpoint count (119 vs 185 vs 237) | CLAUDE.md vs server-audit.md vs health-audit.md | 237 total. ~185 from route files. CLAUDE.md stale. |
| C-5 | SRS chain vs Master SRS | SRS v3.0, v3.1, v3.2 vs MASTER_SRS.md | MASTER_SRS.md is authoritative. Chain files are historical. |
| C-6 | Webhook status (working vs broken) | CLARIFICATION_ANSWERS vs DATA_ACCURACY_REPORT | Webhooks registered but ingestion broken. |
| C-7 | Goals feature location | UI_DEVELOPER_HANDOFF vs ===DevDesign Notes=== | Owner intent: removed from Insights. Code still has it there. |
| C-8 | Work Center vs Hub naming | Various docs vs owner preference | Owner prefers "Hub." Route may remain /work-center. |
| C-9 | Frontend framework (Next.js vs Vite) | ARCHITECTURE_VISUAL_MAP vs actual stack | Visual map is aspirational. Actual: Vite + React 18 + Wouter. |
| C-10 | Agent architecture (7-layer vs actual) | ARCHITECTURE_VISUAL_MAP vs implementation | Visual map is design vision. Actual: DealerBrain + basic CR. |

**OWNER DECISION NEEDED on C-9 and C-10:** Should the PRD reflect the aspirational architecture from ARCHITECTURE_VISUAL_MAP.md, the current reality, or both (with clear labeling)?

---

## MERGED MISSING INFORMATION (18 items)

### Launch-Relevant Missing Items

| # | Item | Source | PRD Impact |
|---|------|--------|------------|
| M-1 | Subscription pricing model | Both agents | Business model section incomplete |
| M-2 | Skills catalog content (what skills exist and do) | Both agents | Agent architecture section needs skill inventory |
| M-3 | Unified inbox handoff mechanics (end-to-end) | Both agents | Internal surfaces section incomplete |
| M-4 | Super Admin comprehensive capability list | Both agents | RBAC section incomplete |
| M-5 | Partner credit pool mechanics | REVIEWER only | Business model section |
| M-6 | Orchestration agent decision (needed or not) | REVIEWER only | Architecture decision |
| M-7 | Inventory data strategy (VIN 403) | REVIEWER only | Data sources section |
| M-8 | Org creation wizard details | REVIEWER only | Feature inventory |
| M-9 | Video agent details (Tavus persona config) | ANALYST only | Feature inventory |

### Potentially Deferred Missing Items

| # | Item | Source | PRD Impact |
|---|------|--------|------------|
| M-10 | Partner economics/compensation model | ANALYST only | Business model section |
| M-11 | Customer success metrics/KPIs | ANALYST only | Competitive positioning |
| M-12 | New vertical onboarding flow | ANALYST only | Platform identity vs automotive-only reality |
| M-13 | Disaster recovery / data backup | ANALYST only | Non-functional requirements |
| M-14 | API rate limits for all integrations | ANALYST only | External surfaces section |
| M-15 | Competitive analysis (named competitors) | ANALYST only | Competitive positioning |
| M-16 | Legal/compliance (TCPA, call recording consent, data retention) | ANALYST only | Compliance section |
| M-17 | Scalability plan | ANALYST only | Growth strategy |
| M-18 | DealerBrain complete tool list | ANALYST (resolved -- REVIEWER found it) | Resolved |

**OWNER ACTION:** Review both sections. For the "Launch-Relevant" items: which ones should the PRD address now vs defer? For the "Potentially Deferred" items: confirm these can wait, or flag any that are actually launch-relevant.

---

## CROSS-WAVE NOTES (Forwarded to Waves 2-4)

### For Wave 2 (SRS -- System Behavior)

- MASTER_SRS.md Section 7.3 (webhook-to-lead data flow) is technically detailed -- carry forward verbatim
- Context Router architecture needs expansion for non-lead data types
- RLS variable name mismatch is a critical below-the-line detail
- SET LOCAL without transaction issue is a security architecture concern
- SMS conversation state machine (AI_ACTIVE / HUMAN_ACTIVE / DORMANT) needs full state transition documentation
- Trigger deduplication: "two mechanisms exist in code" but not documented in any specification file
- VAPI webhook ingestion broken -- data flow section must document actual vs intended behavior

### For Wave 3 (SPEC -- Architecture)

- 53 database tables fully inventoried in database-audit.md
- 237 API endpoints catalogued in server-audit.md
- 40+ services listed in REVERSE_SRS_old.md
- 8 scheduled jobs with intervals
- Frontend: 174 TS/TSX files, 21 pages, 26 hooks, 4 context providers
- ARCHITECTURE_VISUAL_MAP.md is aspirational vision, not current architecture

### For Wave 4 (PLAN -- Current State and Priorities)

- DATA_ACCURACY_REPORT.md documents broken webhook ingestion -- P0 fix
- 3 confirmed real P0 bugs: hosted pages route mismatch, insights crash (4 null guards), appointment notifications
- Trigger system: 0/84 executions completed -- needs live verification
- VAPI phone numbers not assigned per org -- operational prerequisite
- Customer domains not whitelisted -- prerequisite for widget demo
- Owner timeline: ~1 week

---

## OWNER ACTION ITEMS SUMMARY

| # | Item | Type | Priority |
|---|------|------|----------|
| OA-1 | DISAGREE-3: Confirm whether "64+ skill templates" is a real specification or aspirational | Fact check | Medium |
| OA-2 | DISAGREE-4: Should PRD reflect aspirational architecture (ARCHITECTURE_VISUAL_MAP) or current reality? | Decision | High |
| OA-3 | DISAGREE-5: Review merged missing items list; classify as launch-relevant vs deferred | Decision | High |
| OA-4 | DISAGREE-7: Should backend freeze rule be in PRD or only PLAN.md/CLAUDE.md? | Decision | Low |
| OA-5 | DISAGREE-8: Is Central-MCP user-facing functionality (PRD) or developer infrastructure? | Decision | Low |
| OA-6 | C-9/C-10: PRD treatment of vision vs reality for architecture and frontend framework | Decision | High |
| OA-7 | C-3: E2E test count (747 vs 1,699) -- which is accurate? | Fact check | Low |

---

*This reconciled output merges two independent Wave 1 extractions. All factual claims are sourced. Disagreements are flagged for owner resolution. No inferences have been added beyond what the source files state.*

*Status: PENDING OWNER REVIEW. Wave 1 is not locked until all Owner Action Items are resolved.*
