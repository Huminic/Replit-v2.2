# Wave 6 — Agent Rules for CLAUDE.md (REVIEWER)

**Date:** 2026-03-03
**Scope:** Extract all agent operating rules from 53 input files for the new CLAUDE.md
**Method:** Systematic file-by-file scan, 15 extraction categories, every rule cited to source

---

## 1. Truth Hierarchy

### 1a. Data Truth Hierarchy (When data conflicts between sources)

| Priority | Source | Authoritative For |
|----------|--------|-------------------|
| 1 (highest) | VIN Solutions API | Leads, statuses, sources, types, CRM users |
| 2 | VAPI / Tavus APIs | AI call and video session data |
| 3 | Local Database | Nexxus-only data: tasks, goals, agents, preferences, activity |
| 4 (lowest) | Derived Metrics | Computed from above sources; never cached as truth |

**Rule:** If VIN API returns data that differs from the local database, VIN wins. Update local to match. Derived metrics are recomputed on demand, not stored as authoritative values.
**Source:** CONSTITUTION.md Section 2.1; MASTER_SRS.md Section 7.1

### 1b. Document Truth Hierarchy (When documents conflict)

| Priority | Source |
|----------|--------|
| 1 (highest) | RUI (Replit Reference Design) — Tier 1, immutable spec |
| 2 | Owner's designs / Acceptance Criteria |
| 3 | CLAUDE.md / UNIFIED_HANDOFF_PROMPT |
| 4 | CONSTITUTION.md |
| 5 | Audit files (forensic as-built) |
| 6 | MASTER_SRS / SRS.md |
| 7 (lowest) | IMPLEMENTATION_PLAN / PLAN.md |

**Rule:** New UI Design > ACCEPTANCE_CRITERIA > UNIFIED_HANDOFF_PROMPT > Constitution > Audit Files > SRS > Implementation Plan
**Source:** UNIFIED_HANDOFF_PROMPT.md Section 2 "Conflict Resolution Rule"; session-knowledge.md Section 0 ("Tier 1 in truth hierarchy — immutable spec — can be added to, never modified")

### 1c. Owner's Governance File Hierarchy (Structural standard)

| File | Purpose | Read Frequency |
|------|---------|----------------|
| CLAUDE.md | Agent rules, truth hierarchy, conventions | Every session |
| PRD.md | Plain language: what and why (strategy) | Reference |
| SRS.md | Technical narrative: how it works above + below the line (precision) | Reference |
| SPEC.md | Architecture: where things live, how they connect (build logic) | When needed |
| PLAN.md | Marching orders: current phase, next steps, status (execution momentum) | Every session |
| ACCEPTANCE_CRITERIA.md | Testable statements (mirrors test battery) | When testing |

**Source:** Standards.md; session-knowledge.md Section 2

---

## 2. Document Reading Order

### Before Writing Any Code

**Tier 1: Forensic Audit Files (What Actually Exists)**
1. server-audit.md — actual API contract (~237 endpoints)
2. database-audit.md — 53 tables, RLS policies, migration history
3. client-audit.md — 26 hooks, 4 contexts, 59 custom components
4. health-audit.md — build system, dependencies, 117K LOC
5. DATA_ACCURACY_REPORT.md — VAPI/Tavus/VIN data integrity findings

**Tier 2: Carry-Forward and Freeze Lists**
6. CARRY_FORWARD_MANIFEST.md — 32 PRESERVE files, 8 REFERENCE, 11 REPLACEABLE
7. DO_NOT_TOUCH.md — 345+ backend files that are frozen

**Tier 3: Lessons and Operational Knowledge**
8. DEVELOPMENT_TEAM_BRIEFING.md — hard-won lessons, gotchas, guidance
9. DEALERBRAIN_STREAMING_SPEC.md — SSE streaming protocol

**Tier 4: Design Specifications**
10. ACCEPTANCE_CRITERIA.md — pixel-level UI behavior spec
11. Designer handoff documents

**Tier 5: Governance Documents**
12. CLAUDE.md
13. CONSTITUTION.md
14. SRS.md
15. IMPLEMENTATION_PLAN.md

**Tier 6: Reference Material**
16. Agent Instructions.md — agent team protocol
17. Hunch Instructions.md — AI prompt for Hunch Engine
18. Metrics formula files

**Source:** UNIFIED_HANDOFF_PROMPT.md Section 2

### Before Every Session

1. Read session-state.md for session context
2. Read CLAUDE.md and PLAN.md (read every session)
3. Check git status and recent commits
4. Create feature branch before work

**Source:** CLAUDE.md (preflight-input) "How to Continue Work"

---

## 3. Naming Conventions

### User-Facing Names (NEVER expose internal/vendor names)

| Internal/Vendor Name | User-Facing Name |
|----------------------|-----------------|
| VAPI | Voice Agent |
| Tavus | Video Agent |
| DealerBrain | (not shown — underlying concept) |
| Automa | Automa |
| Tools (agent capabilities) | Skills |
| Hub | Work Center |
| TextMagic | (not shown — SMS is the user concept) |

**Rule:** Never expose vendor names (VAPI, Tavus, TextMagic) in any customer-facing UI text. Use role-appropriate labels.
**Source:** CONSTITUTION.md Section 3.1, Section 4; MASTER_SRS.md Section 2.4

### No Source Labels in UI

**Rule:** No "Local + VIN", "VIN API", or other internal data source attribution visible to end users. Source tagging is internal only for traceability.
**Source:** CONSTITUTION.md Section 3.1; MASTER_SRS.md Section 5.2 locked decision

### Platform Identity

- Nexxus is NOT a CRM replacement, NOT a marketing automation tool, NOT a content development platform
- Nexxus is an AI orchestration layer
- Not automotive-only — automotive is the first vertical, architecture must not be permanently locked to it
- Agent capabilities are called "Skills" in the UI (not "Tools")
- DealerBrain is not a sidebar link. Automa is always at the top of the agents list.

**Source:** CONSTITUTION.md Section 1; MASTER_SRS.md Section 2; app_identity.md Sections A1, A6

---

## 4. Backend Freeze Rules

### The Backend is Frozen

**Rule:** If a file is not explicitly listed in DO_NOT_TOUCH.md Section 20 ("SAFE TO MODIFY"), it must not be modified. When in doubt, do not touch it.

**Frozen categories (345+ files):**
- Server entry points and core (5 files)
- Server routes / API layer (34 files)
- Server services / business logic (40+ files)
- Server database layer (4 files)
- Server middleware (3 files)
- Server authentication (2 files)
- Server webhooks (4 files — LIVE production)
- Server WebSocket (2 files)
- Server jobs and schedulers (8 files)
- Server utilities (2 files)
- Database migrations (33 migration files + 5 support files)
- Shared schema (`shared/schema.ts`)
- Widget (17 files)
- Build system (2 files)
- Root configuration files (15 files)
- Test suite (65 files)
- Scripts (19 files)
- Documentation (100+ files)

**Source:** DO_NOT_TOUCH.md; UNIFIED_HANDOFF_PROMPT.md Section 0, Section 1

### Safe to Modify

- `client/` directory (the frontend) — ~130 files
- Exception: `client/src/lib/api.ts` request format must remain compatible
- Exception: `shared/schema.ts` is frozen (client imports types from it)

**Source:** DO_NOT_TOUCH.md Section 20

### Specific Frozen File Rules

| Rule | Source |
|------|--------|
| API contracts are immutable — do not change request/response shapes | DO_NOT_TOUCH.md Section 20 Rule 1 |
| `shared/schema.ts` is frozen — frontend conforms to these types | DO_NOT_TOUCH.md Section 20 Rule 3 |
| VAPI webhook handlers — do not modify without explicit approval | CONSTITUTION.md Section 6 item 8 |
| Existing dependencies — do NOT remove, upgrade, or downgrade | DO_NOT_TOUCH.md Section 15 note |
| `build.outDir` must remain `dist/public` | DO_NOT_TOUCH.md Section 20 Rule 8 |
| Database migrations — must be additive only, never destructive | UNIFIED_HANDOFF_PROMPT.md Section 1 Rule 4 |

---

## 5. Commit & Code Conventions

### Branch Strategy

- **NEVER** deploy from a feature branch
- **ALWAYS** work on feature branches for development
- **ONLY** deploy after merging to master
- Branch naming: `feature/phase-{N}-{name}` or `feature/{name}`

**Source:** CLAUDE.md (preflight-input); CONSTITUTION.md Section 2.5, 3.4

### Deployment

- Deploy only via `./deploy.sh`
- The script enforces: master branch only, warns on uncommitted changes, runs `npm run build`, restarts PM2
- Working Directory -> TypeScript (.ts) -> `npm run build` -> `dist/` -> PM2 serves compiled code
- Editing `.ts` files does NOT affect the webserver until you rebuild

**Source:** CLAUDE.md (preflight-input) "Deployment Workflow"; DO_NOT_TOUCH.md Section 14

### Feature Branch Workflow

```
1. git checkout -b feature/{name}
2. Do work, commit changes
3. git checkout master && git merge feature/{name}
4. ./deploy.sh
5. git branch -d feature/{name}
```

**Source:** CLAUDE.md (preflight-input) "Feature Branch Workflow"

### Code Quality

- TypeScript strict mode
- 3-Proof Validation required per feature (see Section 7)
- No commits without passing quality gates
- No `any` type annotations in new code (380 existing ones are tech debt)
- Follow the implementation plan sequentially — NEVER ad-lib, skip ahead, or add unplanned features

**Source:** CLAUDE.md (preflight-input) Section 4; CONSTITUTION.md Section 2.6; DEVELOPMENT_TEAM_BRIEFING.md

---

## 6. Safety Gates (Pre-Change Checks)

### Before Any Change

1. **Check if the file is in DO_NOT_TOUCH.md** — if listed, do not modify
2. **Check audit files first** — verify what already exists before building (many things are already implemented)
3. **Check VIN API access** — 17 of 30 endpoints return 403. Do not build UI for data that does not exist
4. **Check CARRY_FORWARD_MANIFEST.md** — 32 PRESERVE files must not be rewritten
5. **If uncertain, STOP and ask** — present options with tradeoffs, wait for guidance

**Source:** DO_NOT_TOUCH.md; UNIFIED_HANDOFF_PROMPT.md Section 14 Rule 7; Agent Instructions.md Phase 2

### Before Any VIN API Work

1. Consult `filestore/VinDocs/Leadmanagement.md` and `filestore/VinDocs/user_guide.md`
2. Check which endpoints are accessible vs blocked (17 blocked)
3. Use correct version headers: v1 for reference data, v3 for leads, gateway for user data
4. VIN documentation says uppercase `V3` — production rejects it. Use lowercase `v3`

**Source:** CLAUDE.md (preflight-input) "VIN Solutions API Reference"; DEVELOPMENT_TEAM_BRIEFING.md Lesson 3; MASTER_SRS.md Section 6.1

### Before New Endpoints

- If a UI feature needs a new endpoint, STOP and ask the owner
- Check `server-audit.md` — most endpoints already exist (~237 total)
- Do NOT add new API routes from the frontend — that requires server changes

**Source:** UNIFIED_HANDOFF_PROMPT.md Section 14 Rule 2; DO_NOT_TOUCH.md Section 20

---

## 7. Quality Gates (Pre-Commit Requirements)

### 3-Proof Validation (Per Feature)

Every feature requires THREE pieces of evidence:
1. **Configuration Test** — verify configs, env vars, settings work
2. **Functional Test** — verify feature works (unit or integration test)
3. **Visual/E2E Test** — verify UI/API produces expected results

**Rule:** A feature is CERTIFIED only after all three proofs pass. Until then, it is IN PROGRESS regardless of how much code has been written. "Code exists" does not mean "feature works."

**Source:** CONSTITUTION.md Section 2.6; CLAUDE.md (preflight-input) "3-Proof Validation"

### Quality Gate Commands

Run all three before every deploy:
1. `npm run check` — TypeScript compilation
2. `npm run build` — production build
3. `npx playwright test` — E2E suite

All three must pass with zero errors.

**Source:** CONSTITUTION.md Section 3.4; IMPLEMENTATION_PLAN.md Phase 7

### Evidence Requirements

- Prove functionality with tests/screenshots/logs
- No "it passed" — capture artifacts (log files, screenshots, test output)
- Evidence-first: support all claims with proof
- Metrics require automated verification, not manual checks

**Source:** CLAUDE.md (preflight-input) "Evidence-Based Development"; Agent Instructions.md Section 4

### Status Declaration Standard

Any "COMPLETED" label requires:
- Link to artifact
- Timestamp
- Verifiable reference

**Source:** opinions_facts.md.md Suggestion 4

---

## 8. Agent Team Structure

### Roles

| Role | Type | Responsibility | Tool Access |
|------|------|---------------|-------------|
| Architect | Plan (read-only) | Decomposes specs into tasks, defines interfaces, resolves ambiguity | Read-only |
| Implementer(s) | General-purpose | Writes code within assigned scope | Full |
| Validator | General-purpose | Writes and runs tests, verifies metrics | Full |
| Auditor | Explore (read-only) | Reviews for gaps, inconsistencies, security | Read-only |
| Lead | Orchestrator | Assigns work, enforces gates, makes decisions | Full |

**Source:** Agent Instructions.md Section 2.1

### Scaling Rule

- 1 Architect always
- min(N, 3) Implementers (max 3 parallel)
- 1 Validator per 2 Implementers
- 1 Auditor (runs after each phase gate)

**Source:** Agent Instructions.md Section 2.3

### Development Phases

- Phase 0: Decomposition (Architect only — produces Task Dependency Graph)
- Phase 1: Interface-First Implementation (types, signatures, schemas — no logic)
- Phase 2: Implementation (parallel, in isolated worktrees)
- Phase 3: Validation (Validator tests merged code, not individual branches)
- Phase 4: Audit (Auditor is read-only, reports findings, does not fix)

**Source:** Agent Instructions.md Section 3

### Communication Protocol

- Implementer discovers interface needs to change -> STOP. Message Lead. Do not modify unilaterally.
- Implementer blocked by another task -> Message Lead for reassignment.
- Spec ambiguity -> Message Lead with 2-3 options. Do not guess.
- Status updates: DM to Lead only (not broadcast)

**Source:** Agent Instructions.md Section 5

### Task Lifecycle

```
CREATED -> ASSIGNED -> IN_PROGRESS -> REVIEW -> VALIDATED -> DONE
                    |                           ^
                  BLOCKED -----------------------|
```

A task is not DONE until it passes through Validator AND Auditor.

**Source:** Agent Instructions.md Section 7

---

## 9. Enforcer Rules

### What the Enforcer Is

- The enforcer is the owner's personal representative, a Claude-native agent
- Separate from the agent team
- Lives at `.claude/agents/enforcer.md` (only agent definition file that exists)
- Operating workspace: `.agent_docs/`

**Source:** session-knowledge.md Section 4, Section 8

### What the Enforcer Checks

- Commit compliance: governance, safety gates, quality gates before commit
- It does NOT gate comprehension or read-only testing passes
- It does NOT self-certify (the gatekeeper did — that was a failure mode)
- It catches and flags conflicts but cannot force resolution (that requires the owner)

**Source:** known_issues.md.md (enforcer explanation); session-knowledge.md Section 4

### What the Enforcer Cannot Do

- Prevent architectural misunderstanding if knowledge is not in files
- Force resolution of flagged conflicts
- Gate read-only testing passes
- Compensate for placeholder files used as authoritative truth

**Source:** known_issues.md.md items 1-6

### Enforcer vs Gatekeeper (Important Distinction)

- **Gatekeeper** (archived): sprint lifecycle quality — scope criteria, verify builder output, loop until ALL pass, handoff. Was the OLD system. Self-certified during incident (31 unauthorized commits). ARCHIVED.
- **Enforcer** (active): commit compliance — check governance, safety gates, quality gates before commit. Does NOT self-certify.
- **Gap:** Nobody currently loops builder output against AC + RUI until criteria pass. The gatekeeper's quality verification function has not been replaced.

**Source:** session-knowledge.md Section 4; failure-analysis.md Category H

---

## 10. RBAC Rules

### 4-Tier Role Hierarchy

| Role | System Value | Level | Dashboard Focus | Data Access |
|------|-------------|-------|-----------------|-------------|
| Super Admin | `super_admin` | 1 | System-wide health | All orgs, all data |
| Partner Admin | `partner_admin` | 2 | Org engagement and adoption | Assigned orgs, aggregate metrics (no PII) |
| Org Admin | `org_admin` | 3 | Pipeline health, team performance | Own org, all leads, all staff data |
| Staff | `org_staff` | 4 | My leads, my tasks, my performance | Own assignments only |

**Source:** CONSTITUTION.md Section 5; MASTER_SRS.md Section 3.1

### Key RBAC Rules

- Data access follows RBAC at the database level via RLS policies — no cross-org data leakage
- `org_staff` does NOT get direct VIN Solutions query access — functionality delivered through Work Hub
- Agents are created by `org_admin`, `partner_admin`, or `super_admin` and shared down to staff
- Activity feed (oversight) only accessible to `org_admin` and above
- Lead assignment must be configurable via Settings, never hardcoded
- Communication agent cannot be modified by user except triggers and instruction supplement

**Source:** CONSTITUTION.md Section 5; MASTER_SRS.md Section 3.2, 3.3; session-knowledge.md Section 0

### Route-Level RBAC

- RBAC enforcement should be at the route level, not component level (current code has it scattered across components — this is a known problem)

**Source:** DEVELOPMENT_TEAM_BRIEFING.md "What Doesn't Work" item 3

---

## 11. Data Accuracy Rules

### Metric Certification Requirements

A metric is only certified if:
1. It has a defined name, data source(s), computation formula, field dependencies, and fill rate requirement
2. The underlying data fields are actually populated (>50% fill rate from a 50+ record sample)
3. The computed result matches ground truth (direct API query) within 2%
4. The data source is accessible (not a blocked 403 endpoint)

**Source:** MASTER_SRS.md Section 8.2; CONSTITUTION.md Section 2.4

### Data Accuracy Mandate

- "We cannot have data that is wrong. We cannot have metrics that are wrong." (owner's words)
- A metric showing correct data is worth more than ten metrics showing guesses
- No metric is displayed without ground truth verification
- Metrics that depend on blocked/inaccessible endpoints are excluded entirely — not shown, not placeholdered
- Every phase must include data reconciliation verification
- Quality gates must test data outcomes and accuracy

**Source:** CLARIFICATION_ANSWERS.md "Overarching Mandate"; CONSTITUTION.md Section 2.4

### Data Exclusion Rules

- `excel_upload` records excluded from ALL lead queries (32+ queries across 11 files already fixed)
- Test calls (`test-e2e-*` IDs) filtered before real notifications and metrics

**Source:** DEVELOPMENT_TEAM_BRIEFING.md Lesson 7; MASTER_SRS.md Section 7.2; CONSTITUTION.md Section 3.2

### Source Tagging

- All data responses include source tag (`VIN`, `VAPI`, `TAVUS`, `LOCAL`) — internal only
- Not displayed to users
- Source tagging is for traceability, not customer display

**Source:** CONSTITUTION.md Section 3.2; MASTER_SRS.md Section 7.2

### Cache TTL

| Data Source | Cache TTL |
|-------------|-----------|
| VIN leads | 5 minutes |
| VAPI/Tavus | 1 hour |
| Local-only data | No cache |

**Source:** CONSTITUTION.md Section 3.2; MASTER_SRS.md Section 7.2

---

## 12. UI Immutability Rules

### RUI (Replit Reference Design) is Tier 1

- The live RUI mockup at https://nexxusv2sample.replit.app/ is the immutable visual spec
- It is Tier 1 in the truth hierarchy — can be ADDED TO, never MODIFIED
- Use for Playwright visual comparison
- Note: SPA, will not render with simple fetch/curl — needs Playwright or real browser
- Static RUI files also at: filestore/nexus-v2-1-current/

**Source:** session-knowledge.md Section 0 (MEMORY.md reference); UNIFIED_HANDOFF_PROMPT.md Section 2 Conflict Resolution Rule

### UI Rules

- No placeholder UI for blocked features — if a metric/feature cannot be delivered, do not show it at all
- No "coming soon" indicators, no speculative numbers
- No placeholder data
- No vendor names in any customer-facing UI
- No source labels in UI
- Owner's designs are source of truth, not the existing frontend, not agent assumptions

**Source:** CONSTITUTION.md Section 3.1; UNIFIED_HANDOFF_PROMPT.md Section 14

### Cross-Contamination Prevention

- Do NOT copy patterns from the existing frontend visual components — build fresh from designs
- Do NOT inherit assumptions from the old frontend
- The existing codebase is a "parts bin" — take what works (data hooks), leave what doesn't (visual patterns)

**Source:** DEVELOPMENT_TEAM_BRIEFING.md summary item 5; UNIFIED_HANDOFF_PROMPT.md Section 14 Rule 5

---

## 13. Key Technical Facts

### Codebase Metrics

| Metric | Value | Source |
|--------|-------|--------|
| Total TypeScript LOC | ~117-118K | health-audit.md |
| Total files | 402 TypeScript files | health-audit.md |
| API endpoints | ~237 | server-audit.md |
| Route files | 34 | server-audit.md |
| Services | 40+ | server-audit.md |
| Database tables | 53 | database-audit.md |
| RLS policies | ~100 across 28 tables | database-audit.md |
| Database migrations | 33 | database-audit.md |
| Indexes | 160+ | database-audit.md |
| E2E tests | 747 across 46 files | health-audit.md |
| Unit tests | 0 | health-audit.md |
| `any` type annotations | 380 (325 in server/) | DEVELOPMENT_TEAM_BRIEFING.md |
| TanStack Query hooks | 26 hooks, ~38 queries, ~34 mutations | CARRY_FORWARD_MANIFEST.md |
| Third-party integrations | 7 (VIN, VAPI, Tavus, Resend, TextMagic, Claude, Google Cal) | UNIFIED_HANDOFF_PROMPT.md |
| Scheduled jobs | 8 | DO_NOT_TOUCH.md |

### Authentication Architecture

- JWT-based (NOT express-session — if any doc says express-session, ignore it)
- Access + refresh tokens stored in localStorage
- Keys: `nexxus_access_token`, `nexxus_refresh_token`, `nexxus_token_expiry`, `nexxus_accessible_orgs`
- Auto-refresh: checks every 60 seconds, refreshes when < 5 minutes to expiry
- On refresh failure: automatic logout

**Source:** UNIFIED_HANDOFF_PROMPT.md Section 3.3; CARRY_FORWARD_MANIFEST.md Section 5

### Server Architecture

- Express server, PM2-managed, compiled from TypeScript to `dist/index.cjs`
- Supabase (PostgreSQL) database
- SecureQueryBuilder enforces RLS via `SET LOCAL app.current_org_id`
- Webhooks registered BEFORE body parsers (order matters in `server/routes.ts`)
- No active WebSocket in production — real-time uses SSE (DealerBrain) + polling

**Source:** DO_NOT_TOUCH.md Sections 1-9; UNIFIED_HANDOFF_PROMPT.md Section 3.5

### Economics

| Service | Customer Price | Cost | Margin |
|---------|---------------|------|--------|
| Voice AI | $0.25/min | $0.15/min | 40% |
| Video AI | $0.32/min | $0.20/min | 37.5% |
| SMS | $0.05/msg | $0.02/msg | 60% |

**Source:** CLAUDE.md (preflight-input) "Economics"

### Production Customers

- Serra Automotive (Serra Honda) — live, using voice agents
- Hyundai of Columbia — live
- Live URL: https://nexxusv2.huminicdev.com
- Two customers are live — do not break webhook processing, VIN sync, or notification delivery

**Source:** DEVELOPMENT_TEAM_BRIEFING.md "Production Customers"; app_identity.md Section A2

### Skills Architecture (Critical — Previously Undocumented)

- V1: 27 separate agents + a super chat. Each agent was an overlay with prepopulated context and instructions.
- V2: Instead of 27 hardcoded agents, users CREATE their own agents and ADD skills to them.
- Skills are pre-prompting, context, instructions that tell the agent what it is good at — user-selectable, not fixed.
- Widgets are portals to agents (not standalone features).
- Externally-initiated conversations (via widget) can be continued internally in the Unified Inbox.
- This is NOT a blocker — it was reported as one because the V1-to-V2 transition was not understood.

**Source:** session-knowledge.md Section 0, Section 0b

---

## 14. Known Gotchas

### VIN Solutions API

| Issue | Detail | Source |
|-------|--------|--------|
| Header casing | OAS docs say uppercase `V3`. Production rejects uppercase. Use lowercase `v3`. | DEVELOPMENT_TEAM_BRIEFING.md Lesson 3 |
| 17 blocked endpoints | 403 Forbidden on deals, desking, appointments, inventory, tasks, calls, emails, contacts search, activity, notes | MASTER_SRS.md Section 6.1 |
| Lead creation is 2-step | Create contact via gateway POST -> get ContactId -> create lead with href references. `leadSource`, `leadType`, `contact` are ALL href references, NOT strings. | DEVELOPMENT_TEAM_BRIEFING.md Lesson 2 |
| `dealerId` placement | Goes in query parameter, NOT in request body for POST /leads | MASTER_SRS.md Section 6.1 |
| Version headers per endpoint | v1 for reference data (`/leadSources`, `/leadTypes`, `/vehicles/*`), v3 for `/leads`, `application/json` for gateway | MASTER_SRS.md Section 6.1 |
| Token expiry | OAuth bearer tokens expire every 60 minutes — caching in VinOAuthService | CLAUDE.md (preflight-input) |
| No 48-hour retention limit | VIN API has NO data retention limit (verified). Prior claims of 48-hour limit were false. | IMPLEMENTATION_PLAN.md Phase 1.3 |

### RLS Variable Name Mismatch (CRITICAL BUG)

- `SecureQueryBuilder` sets: `app.current_organization_id`
- Every RLS policy checks: `app.current_org_id`
- These are DIFFERENT variable names
- System works because most routes call `set_config('app.current_org_id', ...)` directly, bypassing SecureQueryBuilder
- SecureQueryBuilder also uses `SET LOCAL` without a transaction — variable can persist on pooled connection
- Risk: potential cross-tenant data leak (not confirmed in production but architecturally unsound)
- Do NOT add new routes that depend on SecureQueryBuilder for org isolation

**Source:** DEVELOPMENT_TEAM_BRIEFING.md Lessons 4, 5

### Excel Upload Pollution

- Records imported via excel upload appeared in lead counts, metrics, and dashboards
- Filter `source != 'excel_upload'` required on ALL lead queries
- Already fixed in 32+ queries across 11 files
- If you add any new lead queries, ALWAYS exclude `source = 'excel_upload'`

**Source:** DEVELOPMENT_TEAM_BRIEFING.md Lesson 7; CONSTITUTION.md Section 3.2

### Context Router Was Inverted

- Originally configured backwards: local DB primary, VIN API fallback
- Corrected to: VIN API primary, local DB fallback
- `CONTEXT_ROUTER_ENABLED=true` in env

**Source:** DEVELOPMENT_TEAM_BRIEFING.md Lesson 6

### Three Governance Layers (Resolved — but awareness needed)

Three authority systems were stacked:
1. `.project/` — from /init (Feb 22) — has its own AC, plan, progress tracker
2. `.agent_docs/` — from enforcer bootstrap (Mar 1) — safety/quality gates, placeholder AC
3. `filestore/` — original project files — release plan, authoritative AC, test kit

**Resolution:** `.project/` gets gutted (reserved for /plan mode scratch). `.agent_docs/` stays (enforcer workspace). New consolidated governance files at root replace the 3-layer system.

**Source:** Current_State.md.md; session-knowledge.md Section 1

### CLAUDE.md Is chmod 444

- CLAUDE.md in nexxus-v2 is read-only (chmod 444)
- Only the owner can edit it
- This was done because agents kept modifying it without consent

**Source:** session-knowledge.md Section 8; opinions_facts.md.md

### Webhook Route Order Matters

- VAPI webhook registered BEFORE body parsers in `server/routes.ts`
- Tavus webhook needs raw body capture for HMAC verification
- DO NOT move webhook registrations or change their order

**Source:** DO_NOT_TOUCH.md Section 7; UNIFIED_HANDOFF_PROMPT.md Section 3.2

---

## 15. Prohibited Actions

### NEVER Do

| # | Rule | Source |
|---|------|--------|
| 1 | NEVER modify production v1 (`/home/ubuntu/Claude-store/nexxus/`) | CONSTITUTION.md Section 6; CLAUDE.md |
| 2 | NEVER share credentials between v1 and v2 | CONSTITUTION.md Section 6 |
| 3 | NEVER deploy from a feature branch | CONSTITUTION.md Section 6; CLAUDE.md |
| 4 | NEVER expose vendor names in customer-facing UI | CONSTITUTION.md Section 6 |
| 5 | NEVER fabricate data or show unverified metrics | CONSTITUTION.md Section 6 |
| 6 | NEVER hardcode integration-specific values (lead assignment, phone numbers, API keys) | CONSTITUTION.md Section 6 |
| 7 | NEVER bypass RLS or multi-tenant isolation | CONSTITUTION.md Section 6 |
| 8 | NEVER modify VAPI webhook handlers without explicit approval | CONSTITUTION.md Section 6 |
| 9 | NEVER ad-lib features or "do something else" — follow the plan | CLAUDE.md Section 4 |
| 10 | NEVER skip ahead or work on later phases | CLAUDE.md Section 4 |
| 11 | NEVER add features not in the current step | CLAUDE.md Section 4 |
| 12 | NEVER modify backend/server code unless explicitly required by new UI | UNIFIED_HANDOFF_PROMPT.md Section 1 |
| 13 | NEVER drop, truncate, or destructively migrate existing data | UNIFIED_HANDOFF_PROMPT.md Section 1 |
| 14 | NEVER modify the WebSocket protocol from the frontend | DO_NOT_TOUCH.md Section 20 |
| 15 | NEVER change the JWT token format or storage location | DO_NOT_TOUCH.md Section 20 |
| 16 | NEVER change how organization context (`x-organization-id` header) is sent | DO_NOT_TOUCH.md Section 20 |
| 17 | NEVER show placeholder UI for blocked features | CONSTITUTION.md Section 3.1 |
| 18 | NEVER use stale/cached data as truth — cache with TTL | CONSTITUTION.md Section 3.2 |
| 19 | NEVER build features that imply VIN data access without checking which endpoints are accessible | DEVELOPMENT_TEAM_BRIEFING.md |
| 20 | NEVER modify CLAUDE.md without owner consent (chmod 444) | opinions_facts.md.md |
| 21 | NEVER self-certify work as complete — separate validator required | Agent Instructions.md Section 7 |
| 22 | NEVER rewrite PRESERVE files from CARRY_FORWARD_MANIFEST.md | CARRY_FORWARD_MANIFEST.md |
| 23 | NEVER copy visual patterns from existing frontend — build fresh from designs | DEVELOPMENT_TEAM_BRIEFING.md |
| 24 | NEVER guess on spec ambiguity — present 2-3 options and wait for decision | Agent Instructions.md Phase 2 |

---

## Conflicts Found

### CONFLICT C6-1: Acceptance Criteria Count

- CLAUDE.md (preflight-input) lists **5 acceptance criteria** (AC-1 through AC-5): outbound calls, VIN data analysis, lead insertion, dashboard metrics, widget deployment
- MASTER_SRS.md lists **19 acceptance criteria** (AC-001 through AC-019)
- session-knowledge.md Section 0c lists **7 demo items** as "payment-critical functionality"
- `— Acceptance Criteria.md` lists **13 demo items**

**Impact:** The new CLAUDE.md must reference a single authoritative AC document. The owner's 13-item demo AC (from `— Acceptance Criteria.md`) and the 7-item payment-critical list (from session-knowledge.md) may be the owner's actual priority set, while MASTER_SRS AC-001 through AC-019 is the comprehensive formal set.
**Recommendation:** Use session-knowledge.md Section 0c (7 payment-critical items) as the launch-critical subset, with MASTER_SRS AC-001-019 as the full set.

### CONFLICT C6-2: Document Location

- CLAUDE.md (preflight-input) references governance docs at `docs/CONSTITUTION.md`, `docs/MASTER_SRS.md`, etc.
- session-knowledge.md Section 2 says new governance files go at project root: `CLAUDE.md`, `PRD.md`, `SRS.md`, `SPEC.md`, `PLAN.md`, `ACCEPTANCE_CRITERIA.md`
- Standards.md defines the same root-level structure

**Impact:** The new governance files are being placed at root (per the surgery plan), not in `docs/`. References in CLAUDE.md must use root paths.
**Recommendation:** Use root-level paths in the new CLAUDE.md.

### CONFLICT C6-3: Implementation Plan Sequencing

- CLAUDE.md (preflight-input) Section 4 says "ALWAYS follow the implementation plan step-by-step, sequentially"
- IMPLEMENTATION_PLAN.md explicitly states Phases 1, 2, and 5 can run in parallel
- Agent Instructions.md describes parallel implementation in worktrees

**Impact:** The "strictly sequential" rule contradicts the parallelism described in the implementation plan.
**Recommendation:** The rule should be "follow the plan" (which itself defines where parallelism is allowed), not "strictly sequential."

### CONFLICT C6-4: RLS Variable Name

- CONSTITUTION.md Section 5 states "RLS enforced at database level via SecureQueryBuilder"
- DEVELOPMENT_TEAM_BRIEFING.md Lesson 4 documents that SecureQueryBuilder uses the WRONG variable name
- Both present SecureQueryBuilder as functional, but it is architecturally unsound

**Impact:** CLAUDE.md should note this as a known bug and warn against using SecureQueryBuilder for new routes.

### CONFLICT C6-5: Widget Channel Count

- CLARIFICATION_ANSWERS.md Q7 lists 6 widget options (Text Chat, Voice Inbound, Voice Outbound, Video Agent, Web Audio, Send a Text)
- DO_NOT_TOUCH.md Section 13 lists 6 channel components matching this
- MASTER_SRS.md Section 5.9 describes 4 choices (text chat, voice inbound, voice outbound, video agent)

**Impact:** Minor. The code has 6 channels; MASTER_SRS describes fewer.

### CONFLICT C6-6: "MVP" Terminology

- session-knowledge.md Section 0c explicitly says "DO NOT call this MVP. This is the launch-critical demo set for customer payment."
- CLAUDE.md (preflight-input) uses "MVP" terminology extensively

**Impact:** The new CLAUDE.md should use "launch-critical" or "payment-critical" instead of "MVP."

---

## Missing Information

### MISSING M6-1: Payment-Critical Demo Flow

The 7-item payment-critical demo list (session-knowledge.md Section 0c) is the actual launch filter but does not exist in any formal governance document yet. Must be in CLAUDE.md or PLAN.md.

### MISSING M6-2: Skills Architecture Documentation

The V1-to-V2 architecture transition (27 hardcoded agents -> user-created agents with selectable skills) was explained 3+ times by the owner but never written to any file agents read. session-knowledge.md Section 0b captures it. Must be in SRS.md and referenced in CLAUDE.md.

### MISSING M6-3: Widget-as-Portal Pattern

Widgets are portals to agents, not standalone features. Externally-initiated conversations continue internally in Unified Inbox. This critical architecture concept exists only in session-knowledge.md. Must be in SRS.md.

### MISSING M6-4: Owner's 5 Watch Areas

From session-knowledge.md Section 0d, these require extra attention during every wave:
1. Agent functionality/defaults
2. Billing
3. Unified inbox handoff
4. Super Admin functionality
5. Context Router functionality

These are not in any governance file.

### MISSING M6-5: Gatekeeper Function Replacement

The gatekeeper was archived. The enforcer does not perform the gatekeeper's quality verification function (loop builder output against AC + RUI until criteria pass). This structural gap needs an owner decision documented in CLAUDE.md.

### MISSING M6-6: Change Consent Boundary

opinions_facts.md.md Suggestion 5 requests: "Write down which files agents may modify without approval and which require explicit consent." This does not exist as a formal list. DO_NOT_TOUCH.md covers backend freeze but does not define consent boundaries for governance files.

### MISSING M6-7: Testing Protocol Details

- Voice testing: use "Elliot" test-only VAPI agent
- SMS testing: loopback to self via TextMagic API — never to real customers
- Email testing: use `neoweaver@gmail.com`
- Video testing: test sessions only — never production Tavus sessions
- Playwright viewport: fixed to 1280x720

These are scattered across documents. Must be consolidated in CLAUDE.md.
**Source:** UNIFIED_HANDOFF_PROMPT.md Section 10; MEMORY.md

---

## Source File Log

| File | Relevance to Wave 6 | Rules Extracted |
|------|---------------------|-----------------|
| CLAUDE.md (preflight-input) | HIGH — prior version of agent rules | Truth hierarchy, constraints, deployment, plan discipline, 3-proof validation, economics, tech stack |
| CONSTITUTION.md | HIGH — platform principles and rules | Data truth hierarchy, naming conventions, UI rules, development rules, testing rules, RBAC mapping, non-negotiable constraints |
| DO_NOT_TOUCH.md | HIGH — backend freeze manifest | 345+ frozen files, safe-to-modify scope, specific modification rules |
| UNIFIED_HANDOFF_PROMPT.md | HIGH — most recent governance doc | Document reading order, conflict resolution rule, production rules, existing infrastructure catalog, operational lessons |
| MASTER_SRS.md | HIGH — formal specification | RBAC permissions matrix, naming conventions, navigation, data architecture, metric certification, acceptance criteria (19), integration specs |
| DEVELOPMENT_TEAM_BRIEFING.md | HIGH — operational lessons | 7 hard-won lessons (VIN API, headers, RLS bug, SET LOCAL, Context Router, excel pollution), what works, what doesn't, tech debt |
| Agent Instructions.md | HIGH — agent team protocol | Team topology, development phases, communication protocol, task lifecycle, worktree strategy, anti-patterns, metrics framework |
| opinions_facts.md.md | HIGH — owner's governance rules | Evidence-first rule, single source of truth freeze, truth hierarchy verification, status declaration standard, change consent boundary, gap tracker consolidation |
| Standards.md | HIGH — owner's file structure standard | Document architecture (PRD/SRS/SPEC/PLAN/AC), what each file does and does not do, structural insight |
| Current_State.md.md | MEDIUM-HIGH — governance layer analysis | Three authority systems stacked, /init impact, resolution decisions |
| CARRY_FORWARD_MANIFEST.md | MEDIUM-HIGH — frontend preserve list | 32 PRESERVE files, 8 REFERENCE, 11 REPLACEABLE, API endpoint catalog, provider tree order |
| IMPLEMENTATION_PLAN.md | MEDIUM — execution plan | Phase dependencies, parallel execution rules, completion criteria patterns, risk register |
| app_identity.md | MEDIUM — owner's platform identity | Platform identity, customer goals, RBAC descriptions, integration descriptions, known issues |
| CLARIFICATION_ANSWERS.md | MEDIUM — owner decisions | VIN write-back, webhooks, Context Router, data warehouse, widget options, SMS, outbound communication, data accuracy mandate |
| Forensics.md.md | MEDIUM — evidence audit framework | Verified vs derived vs unverified classification system |
| known_issues.md.md | MEDIUM — failure analysis context | Enforcer scope limitations, causal chain of failures, 3 confirmed P0s |
| session-knowledge.md | HIGH — owner's mental model | Platform mental model, skills architecture, payment-critical items, watch areas, file structure standard, gatekeeper vs enforcer, file sprawl causes |
| ARCHITECTURE_GUIDE.md | LOW for agent rules | Layout architecture (3-pane grid, responsive breakpoints, sidebar states) |
| — Acceptance Criteria.md | MEDIUM — owner's 13-item demo AC | Demo acceptance items, RUI-level UI behavior specs |
| CUSTOMER_ONBOARDING_KICKOFF.md | LOW | Per-customer readiness checklists |
| VIN_SOLUTIONS_INTEGRATION.md | LOW — superseded by MASTER_SRS | Sprint 2 VIN OAuth2 details |
| DATA_SOURCE_INVENTORY.md | LOW | API endpoint field schemas |
| ACCEPTANCE_VERIFICATION_REPORT.md | LOW — partially refuted | Prior 13/13 verification claims |
| INIT_PROJECT_ANSWERS.txt | LOW | Pre-filled /init interview answers |
| Hunch Instructions.md | LOW | AI prompt template for Hunch Engine |
| NEXXUS_V2_BOOTSTRAP_PROMPT.md | LOW — superseded | Session bootstrap prompt |
| DESIGN_FLAGS.md | LOW — empty template | Decision flag template |
| REVERSE_SRS_old.md | LOW — forensic reference | As-built audit |
| Audit files (database, server, client, health, docs) | MEDIUM — referenced by reading order | Codebase metrics, endpoint counts |
| Layout specs (Insights, Metrics, Reports, Tiles, Hunches) | LOW for agent rules | UI layout specifications |
| SRS chain (v3.0, v3.1, v3.2) | LOW — superseded by MASTER_SRS | Historical reference |
| THEME_CONTRACT.md | LOW | Design tokens |
| UI_DEVELOPER_HANDOFF.md | LOW | UI patterns |
| UI_INTERACTIVE_ELEMENTS_MAP.md | LOW | Interactive element inventory |
| ARCHITECTURE_VISUAL_MAP.md | LOW | ASCII architecture map |
| ARCHITECTURE_GUIDE_RBAC_ADDITION.md | LOW | Partner entity RBAC addendum |
| DESIGNER_UPDATE_SPEC.md | LOW | UI elements needing addition |
| DATA_ACCURACY_REPORT.md | LOW for rules | Data integrity findings |
| Chat-Checklist.pdf | NONE — blank template | N/A |
| replit_reference.textClipping | NONE — macOS artifact | N/A |
| —Insights Layout copy.md | NONE — duplicate | N/A |
| INSIGHT_CARDS_SPECIFICATION.md | NONE — superseded | N/A |
| SYSTEM_REQUIREMENTS_SPECIFICATION_v3.0.md | NONE — superseded | N/A |

---

*End of Wave 6 Reviewer extraction. 15 categories, 24 prohibited actions, 6 conflicts, 7 missing items, 53 files scanned.*
