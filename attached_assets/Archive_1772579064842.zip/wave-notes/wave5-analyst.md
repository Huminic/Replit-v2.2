# Wave 5 Analyst: Current State Extraction (PLAN)

**Date:** 2026-03-03
**Analyst:** Wave 5 ANALYST (independent extraction)
**Input files scanned:** 53 preflight-input files + 5 other_notes + 4 workbench root files
**Priority filter:** 7 payment-critical demo items from session-knowledge.md Section 0c

---

## 1. Project Completion Status

### Overall Assessment

The platform is deployed and serving 2 live customers (Serra Automotive, Hyundai of Columbia) across 5 dealership organizations. The codebase is 117,693 lines of TypeScript across 402 source files with 237 API endpoints, 53 database tables, and 747 E2E tests.

**Completion estimate by area:**

| Area | Status | Evidence |
|------|--------|----------|
| Backend/API | ~90% complete | 237 endpoints, 40+ services, all routes implemented (DO_NOT_TOUCH.md, full inventory) |
| Database | ~95% complete | 53 tables, 33 migrations, ~100 RLS policies (REVERSE_SRS_old.md lines 149-199) |
| Frontend (visual) | ~70% complete, REBUILD PLANNED | 172 source files, 21 pages, but V2.1 visual rebuild was planned (UNIFIED_HANDOFF_PROMPT.md lines 1-7) |
| Integrations | ~75% complete | 7 integrations wired but VAPI webhook ingestion broken, Tavus webhook not receiving (DATA_ACCURACY_REPORT.md) |
| Metrics/Insights | ~60% complete | 5 fragmented services, metrics not consolidated, insights crash risk (verified-findings.md F3) |
| Trigger system | ~50% complete | Code exists but zero production triggers have fired (DATA_ACCURACY_REPORT.md lines 622-624) |
| SMS (TextMagic) | ~40% complete | Service exists, architecture confirmed, but 0 successful sends in production (DATA_ACCURACY_REPORT.md line 656) |
| Testing | ~45% complete | 747 E2E tests but 0 unit tests, no CI/CD (health-audit.md lines 44, 163-168) |
| Governance/Docs | ~20% correct | 3 conflicting governance layers, AC placeholder, CLAUDE.md mismatch (verified-findings.md F4, F5) |

### Key Evidence of Completion

**CLAIMED:** ACCEPTANCE_VERIFICATION_REPORT.md declares "13/13 PASS" across all acceptance criteria.
**Source:** ACCEPTANCE_VERIFICATION_REPORT.md line 10.

**REALITY:** This is partially correct. The verification was done against a different AC set than the payment-critical 7 items. Several items marked PASS have operational caveats:
- AC-5 (triggers): "0/84 executions completed" (ACCEPTANCE_VERIFICATION_REPORT.md line 63)
- AC-7 (hosted pages): Route mismatch confirmed real (verified-findings.md F2)
- AC-9 (agents): "0 video agents" operational gap (ACCEPTANCE_VERIFICATION_REPORT.md line 87)
- AC-1 (chat overlay): Fixed in f12b025, appears functional

**CLAIMED:** release_criteria.md shows "All 12 P0 Gaps FIXED, 0 P0 Blockers."
**Source:** verified-findings.md F0, line 19.

**REALITY:** At least 1 P0 fix is incomplete (hosted pages route mismatch still in code). 3 additional confirmed P0s were found in Run 2 verification (verified-findings.md F1).

---

## 2. Known Gaps & Bugs (with severity, demo-blocking flag)

### Payment-Critical Demo Items (from session-knowledge.md Section 0c)

The 7 items the owner must demonstrate to secure payment:

| # | Demo Item | Current State | Blocks Payment? | Key Gaps |
|---|-----------|---------------|-----------------|----------|
| 1 | Metrics & Insights display correctly | PARTIAL | YES | insights.tsx crash risk (4 null guards needed), metrics fragmented across 5 services |
| 2 | Communications Agent Configuration | PARTIAL | YES | Trigger system never fired in production, VAPI phoneNumberId may be missing |
| 3 | Appointment Flow | PARTIAL | YES | Appointment status changes fire zero notifications (verified-findings.md F1 item 12) |
| 4 | Proactive Lead Follow-up | NOT WORKING | YES | Zero production triggers fired (DATA_ACCURACY_REPORT.md line 623), VAPI phone numbers not assigned |
| 5 | Reactive After-Hours Coverage | PARTIAL | YES | SMS service 0 successful sends, business hours routing not tested live |
| 6 | Widgets (all 3 modes) | PARTIAL | YES | Hosted pages 404 from route mismatch (verified-findings.md F2), embed/unified modes likely work |
| 7 | Automa Chat | FUNCTIONAL | Likely OK | DealerBrain chat working, tool calling functional |

### Full Gap Registry

#### P0 Gaps (Must Fix for Demo)

| ID | Gap | Source File | Line | Status | Demo Blocks |
|----|-----|------------|------|--------|-------------|
| P0-1 | **Hosted pages route mismatch** -- Client fetches `/api/hosted-pages/public/${slug}`, server serves `/api/pages/:slug` | verified-findings.md | F2, line 98-108 | CONFIRMED | #6 Widgets |
| P0-2 | **Insights crash risk** -- 4 unsafe `.pct` accesses without null guards: lines 854, 1293, 2142, 2143 of insights.tsx | verified-findings.md | F3, lines 114-122 | CONFIRMED | #1 Metrics |
| P0-3 | **Appointment status notifications missing** -- updateAppointment() fires zero events, no appointment_status_change event type | verified-findings.md | F1 item 12, line 63 | CONFIRMED | #3 Appointment Flow |
| P0-4 | **Zero production trigger executions** -- All 84 executions are E2E test artifacts. `lead_age_minutes >= 5` evaluated at import time when lead is 0 min old | DATA_ACCURACY_REPORT.md | lines 622-627 | CONFIRMED | #4 Proactive Follow-up |
| P0-5 | **VAPI webhook ingestion broken** -- 66 post-V2 calls lost. `call.started` never received for real calls; `end-of-call-report` UPDATE finds no row | DATA_ACCURACY_REPORT.md | lines 98-130 | CONFIRMED | #4 Proactive Follow-up |
| P0-6 | **Tavus: 0 real sessions captured** -- Zero V2 callback URLs configured, no video agents in DB with persona IDs | DATA_ACCURACY_REPORT.md | lines 323-337 | CONFIRMED | Not directly demo-blocking (video not in 7 items) |
| P0-7 | **PM2 crash-looping** -- 3,247+ restarts, minutes of uptime. IMAP auth failure, missing dist/public/index.html | DATA_ACCURACY_REPORT.md | lines 170-175 | STATUS UNKNOWN (may be resolved since Feb 21 audit; health-audit.md line 416 shows 2D uptime) | ALL |

#### P1 Gaps (Important, Not Immediately Demo-Blocking)

| ID | Gap | Source File | Line | Status | Notes |
|----|-----|------------|------|--------|-------|
| P1-1 | **Agent status toggle bypasses provisioning** | verified-findings.md | F10, line 243 | OPEN | GAP-B1-STATUS-BYPASS-001 from release_criteria.md |
| P1-2 | **LeadMapper missing 6/8 source mappings** | verified-findings.md | F10, line 244 | OPEN | GAP-B1-SOURCE-MAP-001 |
| P1-3 | **idle_trigger_count never resets** | verified-findings.md | F10, line 245 | OPEN | GAP-B4-IDLE-RESET-001 |
| P1-4 | **0/22 successful VIN syncs at runtime** | verified-findings.md | F10, line 246 | OPEN | GAP-B3-VIN-SYNC-001 -- may block #3 Appointment Flow |
| P1-5 | **Persona data never reaches frontend** | verified-findings.md | F10, line 247 | OPEN | GAP-B2-PERSONA-RESPONSE-001 |
| P1-6 | **Legacy agent names block seed** | verified-findings.md | F10, line 248 | OPEN | GAP-B6-AGENT-NAME-001 |
| P1-7 | **Super Admin can't view other orgs' data** | verified-findings.md | F10, line 249 | OPEN | GAP-B6-SA-DATA-001 |
| P1-8 | **start_time returns null in appointment API** | verified-findings.md | F10, line 250 | OPEN | GAP-B5-APPT-STARTTIME-001 |
| P1-9 | **Ford/Hyundai triggers with no VIN integration** | DATA_ACCURACY_REPORT.md | line 636-638 | OPEN | Missing VIN config for 2 orgs |
| P1-10 | **SMS: 0 successful sends** | DATA_ACCURACY_REPORT.md | line 656 | OPEN | Configured but untested |
| P1-11 | **19-28% gap in 7-day VIN lead capture** | DATA_ACCURACY_REPORT.md | lines 450-454 | OPEN | Polling timing/pagination |
| P1-12 | **Unregistered VAPI assistants** (38 calls) | DATA_ACCURACY_REPORT.md | lines 86-91 | OPEN | Elliott, Andor, Gabrielle not in agents table |
| P1-13 | **No credits/notifications on VAPI records** | DATA_ACCURACY_REPORT.md | lines 147-152 | OPEN | Bulk-imported before logic existed |
| P1-14 | **RLS variable name mismatch** -- SecureQueryBuilder uses `app.current_organization_id`, RLS checks `app.current_org_id` | REVERSE_SRS_old.md | lines 203-216 | OPEN | Security architecture broken but system works via direct bypasses |
| P1-15 | **hot_lead event has no firing call site** | ACCEPTANCE_VERIFICATION_REPORT.md | line 100 | OPEN | Trigger event defined but never emitted |
| P1-16 | **updatePerformanceMetrics() defined but never called** | IMPLEMENTATION_PLAN.md | lines 243-258 | OPEN | Agent metrics never updated from webhooks |
| P1-17 | **Mark Contacted only updates local DB, not VIN CRM** | IMPLEMENTATION_PLAN.md | lines 262-283 | OPEN | Wiring gap |

#### P2 Gaps (Nice to Have)

| ID | Gap | Source | Notes |
|----|-----|--------|-------|
| P2-1 | 85% of leads stuck in `new` status | DATA_ACCURACY_REPORT.md line 666 | VIN import doesn't update status on re-import |
| P2-2 | 102 archived E2E test trigger rules | DATA_ACCURACY_REPORT.md line 667 | Cleanup needed |
| P2-3 | No activity feed CSV export | IMPLEMENTATION_PLAN.md line 585 | Phase 7 item |
| P2-4 | 380 explicit `any` type annotations | health-audit.md line 502 | Technical debt |
| P2-5 | 242 console.log in server, no structured logging | health-audit.md lines 517-521 | Technical debt |
| P2-6 | No ESLint/Prettier/pre-commit hooks | health-audit.md lines 510-514 | Technical debt |
| P2-7 | 18 stale feature branches | health-audit.md line 259 | Git hygiene |
| P2-8 | No PM2 ecosystem config file | health-audit.md line 425 | Deployment risk |
| P2-9 | xlsx vulnerability (2 high CVEs, no fix) | health-audit.md lines 630-633 | Security |
| P2-10 | Deploy script has no rollback, no pre-deploy tests, no health check | health-audit.md lines 436-439 | Deployment risk |
| P2-11 | No CI/CD pipeline | health-audit.md line 651 | Process gap |

### Needs Verification (Status Unknown)

| ID | Gap | Source | What's Needed |
|----|-----|--------|---------------|
| NV-1 | Widget header shows "Nexxus" not persona name | verified-findings.md F1 item 14 | Re-test with 1280x720 viewport |
| NV-2 | No availability validation for AI bookings | verified-findings.md F1 item 15 | Owner decision: is this required? |
| NV-3 | Hyundai: no VIN integration config in DB | verified-findings.md F1 item 16 | DB check: intentional? |
| NV-4 | Ford of Columbia: no VIN integration config | verified-findings.md F1 item 17 | Same DB check needed |

---

## 3. Implemented Features (Confirmed Working)

Evidence from multiple sources (ACCEPTANCE_VERIFICATION_REPORT.md, verified-findings.md F10, DATA_ACCURACY_REPORT.md):

| Feature | Evidence | Source |
|---------|----------|--------|
| **VAPI voice webhooks** | Processing live calls daily (end-of-call-report received) | DATA_ACCURACY_REPORT.md lines 101-102 |
| **VIN Solutions OAuth + API** | Active for 3/5 orgs (Serra Honda, Serra Nissan, Tony Serra Ford) | DATA_ACCURACY_REPORT.md lines 377-381 |
| **VIN lead polling job** | Running every 60 min, 48-hour lookback, 771/771 leads have names | DATA_ACCURACY_REPORT.md lines 496-507 |
| **Lead extraction pipeline** | VAPI -> internal DB -> VIN sync queue (3 orgs) | ACCEPTANCE_VERIFICATION_REPORT.md lines 54-57 |
| **Calendar UI** | FullCalendar renders, CRUD works, RBAC enforced | DO_NOT_TOUCH.md line 103 (AppointmentService listed) |
| **Main dashboard** | AI Key Metrics render, excel_upload excluded, source labels masked | ACCEPTANCE_VERIFICATION_REPORT.md lines 90-93 |
| **Chat AI / Automa / DealerBrain** | Claude API + 24 tools + SSE streaming functional | REVERSE_SRS_old.md lines 371-401, ACCEPTANCE_VERIFICATION_REPORT.md line 110 |
| **Trigger system (code)** | 7 event types, 5 action types, rate limiting, business hours | ACCEPTANCE_VERIFICATION_REPORT.md lines 96-99 |
| **Trigger deduplication** | 2 mechanisms: TriggerService:856-871 + idleLeadChecker:406-439 | verified-findings.md F1 item 7 |
| **TextMagic per-org credentials** | Architecture confirmed: getConfig from DB, decryptApiKey | verified-findings.md F1 item 8 |
| **Widget tools** | 7 tools at system/widget level (chatEnabledTools array) | verified-findings.md F1 item 4, WidgetConfigService.ts line 241 |
| **Unified widget** | 50.13KB bundle, 19 configs, 6 channels, domain whitelist | ACCEPTANCE_VERIFICATION_REPORT.md lines 66-70 |
| **Email via Resend** | API valid, domain verified | verified-findings.md F10 line 264 |
| **Security** | JWT, RLS (53 policies), RBAC (4-tier), AES-256 encryption, Helmet, rate limiting | REVERSE_SRS_old.md lines 440-457 |
| **RBAC** | 4-tier role hierarchy, sidebar filtering, server middleware | ACCEPTANCE_VERIFICATION_REPORT.md lines 79-82 |
| **Two-way SMS (code)** | Phone format fixed, conversation state machine exists | ACCEPTANCE_VERIFICATION_REPORT.md lines 40-45 |
| **Email system** | Settings tab + Work Center, IMAP/SMTP, 7 API endpoints | ACCEPTANCE_VERIFICATION_REPORT.md lines 48-51 |
| **Widget channels** | 6 channels implemented: textChat, videoAgent, callUs, callYou, webAudio, sendText | ACCEPTANCE_VERIFICATION_REPORT.md line 69 |
| **Hosted pages (code)** | 5 deployed slugs, 4 page types | ACCEPTANCE_VERIFICATION_REPORT.md lines 73-76 |
| **Frontend integration plumbing** | 32 PRESERVE files, 25 TanStack Query hooks, SSE streaming | CARRY_FORWARD_MANIFEST.md summary line 287-288 |
| **Context Router** | Enabled, SourceSelector + CacheManager functional | REVERSE_SRS_old.md lines 321-323 |
| **DealerPulse** | 5-phase health snapshots, 4-hour cache cycle | ACCEPTANCE_VERIFICATION_REPORT.md line 93 |
| **Goals** | CRUD + progress tracking | DO_NOT_TOUCH.md, goals route listed |
| **Drive** | File/folder CRUD | DO_NOT_TOUCH.md, drive route listed |
| **Hunches & Approvals** | AI-generated insights + approval workflow | DO_NOT_TOUCH.md, both routes listed |
| **Tracking Pixel** | Event ingestion, attribution, funnel | DO_NOT_TOUCH.md, tracking route listed |
| **Google Calendar** | OAuth flow, sync, push appointment | DO_NOT_TOUCH.md, google-calendar route listed |

---

## 4. Broken Features (Built But Not Working)

| Feature | What's Broken | Evidence | Fix Complexity |
|---------|---------------|----------|----------------|
| **VAPI webhook ingestion** | `call.started` never received for real calls; `end-of-call-report` UPDATE finds no row. All 137 real records are from bulk imports. | DATA_ACCURACY_REPORT.md lines 98-130 | MODERATE: Change to UPSERT in handleEndOfCallReport; investigate VAPI dashboard org-level server URL |
| **Hosted pages public access** | Client fetches wrong path; 404 on all hosted pages | verified-findings.md F2 | TRIVIAL: 1-line fix in hosted-page-public.tsx:163 |
| **Insights page** | 4 crash-risk locations with unguarded array/property access | verified-findings.md F3 | TRIVIAL: 4 null guards |
| **Production triggers** | All 84 executions are test artifacts. Zero real triggers have fired. lead_age_minutes condition never met at import time. | DATA_ACCURACY_REPORT.md lines 622-627 | MODERATE: Trigger re-evaluation job exists (5-min interval) but condition logic needs fixing |
| **Tavus video integration** | 0 real sessions captured. No V2 callback URLs configured on any persona. No video agents registered in DB. | DATA_ACCURACY_REPORT.md lines 316-337 | MODERATE: Register video agents, configure callback URLs in Tavus dashboard |
| **Appointment notifications** | updateAppointment() fires zero events. No appointment_status_change event type in trigger system. | verified-findings.md F1 item 12 | MODERATE: Add event emission to AppointmentService |
| **VIN sync at runtime** | 0/22 successful VIN syncs noted in gap tracker | verified-findings.md F10 line 246 | NEEDS INVESTIGATION |
| **Credit recording** | 0/137 VAPI records have credit_recorded=true | DATA_ACCURACY_REPORT.md line 150 | MODERATE: Depends on fixing webhook ingestion first |
| **Notification sending** | 0/137 VAPI records have notification_sent=true | DATA_ACCURACY_REPORT.md line 149 | MODERATE: Same dependency on webhook fix |

---

## 5. Missing Features (Specified But Not Built)

| Feature | Specified In | Current State | Priority |
|---------|-------------|---------------|----------|
| **MetricsEngine consolidation** | IMPLEMENTATION_PLAN.md Phase 4, lines 320-395 | MetricsEngine.ts exists as service file but metrics still fragmented across 5 services | P1 |
| **Combined cross-platform metrics** | IMPLEMENTATION_PLAN.md Phase 6, lines 504-569 | Not implemented (depends on MetricsEngine) | P1 |
| **SMS after-hours AI routing** | IMPLEMENTATION_PLAN.md Phase 5, lines 398-500 | Business hours config exists in migration 032 but routing logic not wired | P0 for demo item #5 |
| **SMS collision avoidance state machine** | IMPLEMENTATION_PLAN.md Phase 5, lines 447-477 | sms_conversation_state table exists in code (AC-2 verification) but state transitions not tested live | P1 |
| **Mark Contacted -> VIN CRM writeback** | IMPLEMENTATION_PLAN.md Phase 3, lines 262-283 | Button updates local DB only; VIN API write confirmed possible (PUT /leads probe succeeded) | P1 |
| **VAPI Analytics API integration** | IMPLEMENTATION_PLAN.md Phase 3, lines 285-304 | Not implemented; local computation is the only path | P2 |
| **Activity feed CSV export** | IMPLEMENTATION_PLAN.md Phase 7, lines 585-596 | Not implemented | P2 |
| **Role-based dashboard filtering** | IMPLEMENTATION_PLAN.md Phase 6, lines 539-557 | Infrastructure exists (RBAC, role fields) but metrics not role-filtered | P1 |
| **Unit tests** | health-audit.md line 44 | Zero exist | P2 |
| **CI/CD pipeline** | health-audit.md line 651 | Not configured | P2 |
| **Web scraping as a skill** | session-knowledge.md line 29 | Owner mentioned as future; not implemented | FUTURE |
| **AI Governance Stage 2-3** | IMPLEMENTATION_PLAN.md line 765-766 | Deferred (Stage 1 monitoring-only is active) | FUTURE |
| **MCP proxy integration** | app_identity.md line 239 | Exists at central-mcp but not properly integrated | FUTURE |

---

## 6. Tainted Claims (Wrong Gaps That Must Not Re-Enter)

**CRITICAL: The following 8 items from Phase 9 Run 2 are WRONG. They must NOT appear in any future gap list or plan.**

| # | Original Claim | Why It's Wrong | Evidence |
|---|---------------|----------------|----------|
| 1 | "Serra Nissan: no chat agent" (GAP-B1-AGENT-001) | Automa IS the chat agent on homepage/popout | Owner confirmation + verified-findings.md F1 |
| 2 | "Tony Serra Ford: no chat agent" (GAP-B1-AGENT-002) | Same architecture misunderstanding | Owner confirmation + verified-findings.md F1 |
| 3 | "Ford of Columbia: no chat agent" (GAP-B1-AGENT-003) | Same | Owner confirmation + verified-findings.md F1 |
| 4 | "No tools on any agent (tools=[])" (GAP-B1-SKILLS-001) | Tools are at widget/system level, not per-agent. 7 tools in chatEnabledTools array at WidgetConfigService.ts:241 | verified-findings.md F1 item 4 |
| 5 | "Lead Follow-Up lacks CRM instructions" (GAP-B1-INSTR-001) | Measured raw DB field; skills are prompt overlays on Automa in V2 architecture | Owner confirmation + session-knowledge.md Section 0b |
| 6 | "15-min idle trigger not in instructions" (GAP-B1-INSTR-002) | Same skills overlay misunderstanding | Owner confirmation |
| 7 | "No trigger dedup for active conversations" (GAP-B1-TRIGGER-001) | TWO dedup mechanisms exist in code: TriggerService.ts:856-871 + idleLeadChecker.ts:406-439 | verified-findings.md F1 item 7 |
| 8 | "TextMagic API returns 401" (GAP-B3-SMS-001) | Tested .env creds; service uses per-org DB creds (TextMagicService.ts:223-232, line 330 decryptApiKey) | verified-findings.md F1 item 8 |

**Root cause of tainted findings:** Agent performing Run 2 did not understand the V1-to-V2 architecture transition. The skills model, Automa-as-chat-agent pattern, widget-level tools, and per-org credential handling were never documented in any file the testing agent could read (failure-analysis.md Category A).

**Additionally resolved by owner:**

| # | Claim | Owner Decision |
|---|-------|----------------|
| 9 | "VIN appointment sync never executes" (GAP-B5-VIN-SYNC-001) | VIN has no calendar API. Platform calendar is standalone. |
| 10 | "Bidirectional calendar/VIN impossible" (GAP-B5-BIDIR-001) | Same -- marked N/A in release_criteria.md line 69 |

---

## 7. Dependencies & Prerequisites

### For Payment-Critical Demo

| Dependency | Required For | Status | Who |
|------------|-------------|--------|-----|
| **VAPI phone numbers assigned per org** | #4 Proactive Follow-up, #5 After-Hours | NOT DONE | Huminic must purchase in VAPI dashboard (CUSTOMER_ONBOARDING_KICKOFF.md line 27) |
| **Trigger rules activated** | #4 Proactive Follow-up | NOT DONE | Customer must approve (CUSTOMER_ONBOARDING_KICKOFF.md line 28) |
| **VAPI webhook ingestion fixed** | #4 Proactive Follow-up (real-time) | BROKEN | Code fix (UPSERT) + VAPI dashboard config |
| **Hosted pages route fix** | #6 Widgets (hosted mode) | 1-line fix needed | Developer |
| **Insights null guards** | #1 Metrics & Insights | 4-line fix needed | Developer |
| **Appointment event emission** | #3 Appointment Flow | Code addition needed | Developer |
| **Production website domains** | #6 Widgets (embed mode) | NOT PROVIDED | Customer must provide (CUSTOMER_ONBOARDING_KICKOFF.md line 26) |
| **Columbia VIN credentials** | VIN integration for 2 orgs | NOT PROVIDED | Customer must confirm CRM usage (CUSTOMER_ONBOARDING_KICKOFF.md lines 37-39) |

### Technical Dependencies

| Prerequisite | Depends On | Status |
|-------------|------------|--------|
| MetricsEngine consolidation | Phase 2 field population audit | NOT STARTED |
| Combined metrics | MetricsEngine | NOT STARTED |
| Mark Contacted VIN writeback | VIN API header verification (Phase 2) | Headers likely OK (probe succeeded) |
| SMS after-hours routing | Business hours config (migration 032 exists) | Config exists, logic not wired |
| VAPI Analytics API | VAPI API access | Available but not integrated |

---

## 8. Sprint/Phase History

### Project Timeline (from health-audit.md lines 173-193)

| Period | Commits | Activity |
|--------|---------|----------|
| 2026-01-21 to 2026-01-24 | 9 | Ramp-up |
| 2026-01-24 to 2026-01-31 | 8 | Early development |
| 2026-01-31 to 2026-02-07 | 63 | Peak sprint (MVP push) |
| 2026-02-07 to 2026-02-14 | 66 | Peak sprint (stabilization) |
| 2026-02-14 to 2026-02-21 | 35 | Post-stabilization |
| 2026-02-22+ | Unknown | Frontend rebuild planned, pre-flight surgery initiated |

**Total:** 181 commits over 31 days. 100% authored by Claude Code (health-audit.md line 266).

### Sprint Sequence (from CLAUDE.md in preflight-input)

| Phase | Feature | Priority | Status |
|-------|---------|----------|--------|
| 6 | Credit Wiring | P0 | COMPLETE |
| 7 | Notifications System | P1 | COMPLETE |
| 8 | TextMagic SMS | P1 | COMPLETE |
| 9 | Bug Fixes & Tech Debt | P0 | COMPLETE |
| 10 | Master Widget | P0 | COMPLETE |
| 11 | Hosted Widget Pages | P1 | COMPLETE |
| 12 | Staff Messaging Inbox | P0 | COMPLETE |
| 13 | Tracking Pixel | P1 | COMPLETE |
| 14 | Agent Triggers | P1 | COMPLETE |
| 15 | AI Governance Stage 1 | P1 | COMPLETE |
| 16 | Goals Integration | P1 | COMPLETE |
| 17 | Google Calendar OAuth | P1 | COMPLETE |
| 18 | Drive & Artifacts | P2 | COMPLETE |
| 19 | Hunches & Approvals | P2 | COMPLETE |
| 20 | Leads & Demo Readiness | P2 | COMPLETE |

**Source:** CLAUDE.md in preflight-input, lines ~170-200.

**CONFLICT:** Phases 6-20 all show "COMPLETE" but DATA_ACCURACY_REPORT.md shows critical gaps in many of these (e.g., SMS shows 0 successful sends despite Phase 8 marked COMPLETE, triggers show 0 production executions despite Phase 14 marked COMPLETE).

### Post-Sprint Activity

| Date | Event | Source |
|------|-------|--------|
| 2026-02-16 | "Second wave fresh start" alignment exercise -- 40+ files archived | CLAUDE.md line ~335 |
| 2026-02-18 | IMPLEMENTATION_PLAN.md v2.0 written (8 phases from gap analysis) | IMPLEMENTATION_PLAN.md line 2 |
| 2026-02-19 | ACCEPTANCE_VERIFICATION_REPORT (13/13 PASS), DATA_ACCURACY_REPORT | Report dates |
| 2026-02-21 | REVERSE_SRS forensic audit, health-audit | Report dates |
| 2026-02-22 | /init Tier 3 run (created .project/ governance layer), DO_NOT_TOUCH.md, UNIFIED_HANDOFF_PROMPT.md | Current_State.md.md lines 17-18; file dates |
| 2026-03-01 | Enforcer bootstrap (created .agent_docs/ layer), method enforcement overhaul | MEMORY.md |
| 2026-03-01 | Phase 9 Run 2 testing (~40% tainted) | MEMORY.md |
| 2026-03-02 | Fact-finding session, failure analysis, preflight surgery plan | MEMORY.md |

### What the IMPLEMENTATION_PLAN.md v2.0 Proposed (Feb 18)

8 phases with dependency chain:
1. Critical Fixes (vendor names, DealerBrain prompts) -- ~80 lines across ~12 files
2. Data Integrity (VIN headers, field population audit)
3. Wiring Gaps (webhook metrics, Mark Contacted to VIN, VAPI Analytics)
4. Metrics Consolidation (unified MetricsEngine)
5. SMS Enhancement (after-hours routing, collision avoidance)
6. Combined Metrics & Role Dashboards
7. Certification & Testing
8. Deployment

**Status:** It is unclear how much of this plan was executed. The plan was written on 2026-02-18. The /init run on 2026-02-22 created a competing plan structure. No evidence that Phases 1-8 of this plan were systematically executed.

---

## 9. Environment Status

### Deployment State

| Component | Status | Evidence |
|-----------|--------|----------|
| PM2 process (nexxus-v2) | Online (PID 1616575, 148.9 MB) | health-audit.md line 412-419 |
| Uptime | 2 days at audit time (Feb 21) | health-audit.md line 416 |
| Total restarts | 3,327 | health-audit.md line 418 (CONCERN but may be from deployments) |
| Live URL | https://nexxusv2.huminicdev.com | health-audit.md line 7 |
| Node.js | v20.19.5 | health-audit.md line 447 |
| Platform | Linux 5.15.0-1081-oracle (Oracle Cloud) | health-audit.md line 449 |
| Reverse proxy | Caddy (managed by sysadmin) | health-audit.md line 464 |
| Build | `npm run build` produces 4 outputs (client, widget, pixel, server) | health-audit.md lines 349-357 |

### Database State

| Component | Status | Evidence |
|-----------|--------|----------|
| Provider | Supabase (PostgreSQL) on AWS us-west-2 | REVERSE_SRS_old.md line 144 |
| Tables | 53 | REVERSE_SRS_old.md line 149 |
| Migrations | 33 (001-033, 011 missing, two 004s) | REVERSE_SRS_old.md lines 175-182 |
| RLS policies | ~100 | REVERSE_SRS_old.md line 186 |
| RLS variable mismatch | SecureQueryBuilder uses wrong var name | REVERSE_SRS_old.md lines 203-216 |
| Live data | 775 leads (excl excel_upload), 137 VAPI records (all bulk-imported), 1 Tavus seed record | DATA_ACCURACY_REPORT.md |

### External Service Connectivity

| Service | Status | Evidence |
|---------|--------|----------|
| VIN Solutions OAuth | ACTIVE for 3 orgs (Serra) | DATA_ACCURACY_REPORT.md lines 377-381 |
| VIN Solutions OAuth | NOT CONFIGURED for 2 orgs (Columbia) | CUSTOMER_ONBOARDING_KICKOFF.md lines 37-39 |
| VAPI webhooks | RECEIVING end-of-call-report (NOT call.started) | DATA_ACCURACY_REPORT.md lines 101-102 |
| VAPI phone numbers | 7 numbers on account | DATA_ACCURACY_REPORT.md line 92 |
| Tavus webhooks | NOT RECEIVING (0 V2 callback URLs) | DATA_ACCURACY_REPORT.md lines 282 |
| TextMagic SMS | Configured but 0 successful sends | DATA_ACCURACY_REPORT.md line 656 |
| Resend email | Working (domain verified) | verified-findings.md F10 |
| Google Calendar | OAuth flow implemented | DO_NOT_TOUCH.md |
| Central-MCP | Port 4002, has Notion/Supabase/ClickUp/VAPI connectors. No TextMagic connector. Not properly integrated. | MEMORY.md, app_identity.md line 239 |

---

## 10. Owner Decisions Needed

| # | Decision | Context | Options | Source |
|---|----------|---------|---------|--------|
| 1 | **Which AC file is authoritative?** | 3 AC files exist. CLAUDE.md points to the placeholder. | A) Complete reconciliation into .agent_docs/ac.md, B) Write new consolidated AC at root, C) Use docs/ACCEPTANCE_CRITERIA.md as-is | verified-findings.md F4 |
| 2 | **Update CLAUDE.md on disk** | On-disk version is pre-enforcer (chmod 444). System prompt has updated version. New sessions reading from disk get wrong rules. | Owner must manually edit the file | verified-findings.md F5 |
| 3 | **Is availability validation required for launch?** | No availability checking for AI bookings | Launch with current behavior or add check | verified-findings.md F1 item 15 |
| 4 | **Are Columbia orgs using VIN Solutions?** | No VIN integration config exists for Ford/Hyundai of Columbia | If yes: need dealer IDs + credentials. If no: those orgs use local data only. | CUSTOMER_ONBOARDING_KICKOFF.md lines 37-39 |
| 5 | **VAPI phone number purchases** | Required for outbound call triggers | Which area codes/numbers to buy per org | CUSTOMER_ONBOARDING_KICKOFF.md line 27 |
| 6 | **How to restore gatekeeper function** | Gatekeeper archived, enforcer doesn't do quality verification loops | A) Write gatekeeper-like logic into enforcer, B) Create new quality verifier agent, C) Manual owner verification | failure-analysis.md Category H |
| 7 | **Billing plan for frontend** | Backend billing wired but frontend deferred (Credits page hidden in App.tsx:106-114) | When to expose billing UI | IMPLEMENTATION_PLAN.md line 764 |
| 8 | **What to do with .project/ directory** | /init created parallel governance layer | A) Gut it (reserved for /plan scratch), B) Delete entirely, C) Reconcile with other layers | session-knowledge.md Section 1 |
| 9 | **Archive folder path for deprecated files** | Owner has archive folder outside nexxus-v2 root | Need the path | session-knowledge.md Section 8 |
| 10 | **Frontend rebuild scope** | V2.1 rebuild was planned per UNIFIED_HANDOFF_PROMPT.md | Is this still the plan? Or fix existing frontend? | UNIFIED_HANDOFF_PROMPT.md |

---

## Watch Area Findings

### Watch Area 1: Agent Functionality/Defaults

**Current state:**
- 12 active agents exist in production: 5 voice (VAPI), 2 chat, 4 task, 0 video (ACCEPTANCE_VERIFICATION_REPORT.md line 85)
- Automa is the master chat agent, present in every account (app_identity.md lines 83-86, session-knowledge.md Section 0)
- Skills architecture: V2 allows users to CREATE agents and ADD skills (overlays with pre-prompting/context). This replaced V1's 27 hardcoded agents. (session-knowledge.md Section 0b)
- Default agents are seeded via migration 004_serra_seed_data.sql (REVERSE_SRS_old.md lines 459-475)
- Agent CRUD API exists with org isolation (ACCEPTANCE_VERIFICATION_REPORT.md line 86)
- Skills are configured within agent creation/editing dialogue (app_identity.md line 141)

**Known gaps:**
- GAP-B6-AGENT-NAME-001: Legacy agent names block seed (verified-findings.md F10)
- 0 video agents registered (no tavus_persona_id in any agent config) (DATA_ACCURACY_REPORT.md line 316)
- Agent status toggle bypasses provisioning (P1-1)
- hot_lead event has no firing call site (P1-15)

**What's needed:** Video agents must be registered with Tavus persona IDs. Agent seeding must work without name conflicts. Skills catalog documentation needs to exist in a file agents can read.

### Watch Area 2: Billing

**Current state:**
- CreditService exists with balance tracking, usage deduction, policy enforcement (DO_NOT_TOUCH.md line 107)
- Credits route: 5 endpoints (balance, usage, policies, recent, summary) (UNIFIED_HANDOFF_PROMPT.md line 143)
- Credits page is intentionally deferred/hidden: App.tsx lines 106-114 (IMPLEMENTATION_PLAN.md line 764)
- Credit recording on VAPI records: 0/137 have credit_recorded=true (DATA_ACCURACY_REPORT.md line 150)
- Revenue model defined: Voice $0.25/min, Video $0.32/min, SMS $0.05/msg (REVERSE_SRS_old.md lines 99-105)
- Service quotas table exists (migration 031) (DO_NOT_TOUCH.md line 275)
- Credit idempotency guard exists (migration 024) (DO_NOT_TOUCH.md line 268)

**Known gaps:**
- Credits not being recorded because webhook ingestion is broken (P0-5 dependency)
- Frontend billing UI intentionally hidden -- owner must decide when to expose
- No evidence of actual billing/invoicing to customers

**What's needed:** Fix webhook ingestion first, then credit recording will work. Owner decision on when to show billing UI.

### Watch Area 3: Unified Inbox

**Current state:**
- InboxService exists (DO_NOT_TOUCH.md line 118)
- 8 API endpoints for unified inbox (UNIFIED_HANDOFF_PROMPT.md line 133)
- Merges SMS + widget chat + email conversations (ACCEPTANCE_VERIFICATION_REPORT.md line 49)
- Staff messaging inbox implemented in Phase 12 (marked COMPLETE in CLAUDE.md)
- 21 inbox conversations in last 7 days (DATA_ACCURACY_REPORT.md line 587)
- Widget conversations flow into inbox (app_identity.md: "Externally-initiated conversations via widget can be continued internally in the Unified Inbox" -- session-knowledge.md line 19)

**Known gaps:**
- Handoff flow from widget-initiated external conversation to internal staff follow-up is architecturally designed but needs live verification
- No evidence of SMS conversations flowing into inbox (0 successful SMS sends)
- Email sync job runs every 5 min but IMAP auth failure was causing PM2 crash-loops (DATA_ACCURACY_REPORT.md line 174)

**What's needed:** Live verification that widget -> inbox handoff works. Fix IMAP auth to stabilize email in inbox. Test SMS -> inbox flow once TextMagic sends are working.

### Watch Area 4: Super Admin

**Current state:**
- 14 admin API endpoints (user/org CRUD, partner links, roles, locations) (UNIFIED_HANDOFF_PROMPT.md line 123)
- RBAC role level 1 = Super Admin, system-wide access (REVERSE_SRS_old.md lines 452-455)
- Super Admin can: create partners, create orgs, manage billing, maintain system (app_identity.md lines 169-170)
- DealerBrain config management: Super Admin only (3 endpoints) (UNIFIED_HANDOFF_PROMPT.md line 128)

**Known gaps:**
- GAP-B6-SA-DATA-001: Super Admin can't view other orgs' data (verified-findings.md F10 line 249)
- Super Admin functionality is "undertested, owner has focused on customer-facing features" (session-knowledge.md line 98)
- No evidence of Super Admin-specific E2E tests beyond RBAC suite

**What's needed:** Dedicated Super Admin testing pass. Fix cross-org data visibility. Document what Super Admin can see/do vs. Partner Admin vs. Org Admin.

### Watch Area 5: Context Router

**Current state:**
- 3 files: ContextRouterService.ts, SourceSelector.ts, CacheManager.ts (DO_NOT_TOUCH.md lines 141-144)
- Routes data requests to VIN API (primary) or local DB (fallback) (REVERSE_SRS_old.md line 321)
- AC-006 (Context Router Refactor) marked "ALREADY CERTIFIED (build-verified)" (IMPLEMENTATION_PLAN.md line 786)
- CacheManager has stale doc comments referencing "48-hour API retention limit" (which doesn't exist) (IMPLEMENTATION_PLAN.md lines 123-128)
- SourceSelector has stale @see reference to old SRS v3.0 (IMPLEMENTATION_PLAN.md line 126)

**Known gaps:**
- Stale code comments reference non-existent 48-hour VIN API limit (Phase 1 item 1.6 in IMPLEMENTATION_PLAN.md)
- Session-knowledge.md mentions "Context Router inversion" -- unclear if this was fixed
- REVERSE_SRS_old.md line 214-215 notes `app.current_organization_id` variable mismatch -- Context Router queries may be affected

**What's needed:** Verify Context Router is routing correctly under current RLS configuration. Fix stale doc comments. Confirm "inversion" issue status.

---

## Conflicts Found

| # | Topic | File A Says | File B Says |
|---|-------|-------------|-------------|
| CONFLICT-1 | **Completion status** | CLAUDE.md (preflight-input): All phases 6-20 "COMPLETE" (line ~170) | DATA_ACCURACY_REPORT.md: SMS 0 sends (line 656), triggers 0 production fires (line 623), VAPI ingestion broken (line 98) |
| CONFLICT-2 | **P0 count** | release_criteria.md: "All 12 P0 FIXED, 0 blockers" (verified-findings.md F0 line 19) | verified-findings.md F1: 3 confirmed real P0s still open (lines 60-66) |
| CONFLICT-3 | **P0 count (different direction)** | FINAL_REPORT.md (Run 2): "22 P0 blockers, 22/100 readiness" (verified-findings.md F9) | verified-findings.md F1: Only 3-7 actual P0s (8 tainted, 2 resolved) |
| CONFLICT-4 | **AC reconciliation** | .agent_docs/work_tree.md: "COMPLETED" (failure-analysis.md E1) | .agent_docs/acceptance_criteria.md: File says "PLACEHOLDER" (verified-findings.md F4) |
| CONFLICT-5 | **CLAUDE.md on disk vs system prompt** | On-disk at commit 95c0290: pre-enforcer version | System prompt cache: includes enforcer sections, truth hierarchy, incident record (verified-findings.md F5) |
| CONFLICT-6 | **Table count** | CLAUDE.md: "36 tables" | REVERSE_SRS_old.md line 149: "53 tables" in migrations. health-audit.md line 608: "36 tables per CLAUDE.md" -- audit noticed discrepancy |
| CONFLICT-7 | **AC numbering** | CLAUDE.md lists 5 ACs (AC-1 through AC-5) | IMPLEMENTATION_PLAN.md maps 19 ACs (AC-001 through AC-019) (lines 774-794) | Owner's 7 payment-critical items (session-knowledge.md Section 0c) are yet another AC set |
| CONFLICT-8 | **"13/13 PASS" claim** | ACCEPTANCE_VERIFICATION_REPORT.md line 10 | Multiple operational caveats noted within the same report: 0/84 trigger executions (line 63), 0 video agents (line 87), shared SMS number (line 45) |
| CONFLICT-9 | **Frontend rebuild vs fix** | UNIFIED_HANDOFF_PROMPT.md: full V2.1 frontend rebuild planned | Current pre-flight surgery: focuses on governance + gap fixes, not full rebuild |
| CONFLICT-10 | **RLS policy count** | REVERSE_SRS_old.md line 186: "~100 RLS policies" | CLAUDE.md: "53 RLS policies" | health-audit.md line 609: "53 policies per CLAUDE.md" |

---

## Information Not Found

The following information was searched for across all input files but not found:

| # | What Was Sought | Why It Matters | Searched In |
|---|----------------|----------------|-------------|
| 1 | **Actual Playwright test pass rate** | 747 tests exist but no recent pass/fail numbers | All audit reports, health-audit.md |
| 2 | **Current PM2 stability** | Feb 21 showed 3,327 restarts; current state unknown | No file dated after Feb 22 has PM2 data |
| 3 | **TextMagic send/receive test results** | 0 sends reported in Feb 19 audit; may have been fixed since | No post-Feb-19 TextMagic data |
| 4 | **Whether IMPLEMENTATION_PLAN.md v2.0 phases were executed** | Plan written Feb 18; unclear what was done after | No execution log or progress tracking for this plan |
| 5 | **V2.1 frontend rebuild status** | UNIFIED_HANDOFF_PROMPT written Feb 22; unclear if any work started | No frontend rebuild artifacts found |
| 6 | **VAPI dashboard configuration** (org-level server URL, event subscriptions) | Required to fix call.started non-delivery | No VAPI dashboard screenshots or config dumps |
| 7 | **Owner's archive folder path** outside nexxus-v2 | Needed for file organization | Owner mentioned but didn't provide path (session-knowledge.md line 236) |
| 8 | **Whether SMS business hours routing was tested live** | Migration 032 exists but no test evidence | No SMS test results |
| 9 | **Current state of .project/ directory contents** | /init created it Feb 22; unclear what's in it now | No listing of current .project/ contents |
| 10 | **Actual trigger re-evaluation job behavior** | Job exists (5-min interval) but unclear if it's running and whether it fixes the lead_age_minutes problem | No runtime logs of trigger re-eval |

---

## Cross-Wave Notes

### For PRD (Wave 1)
- Owner's platform mental model is in session-knowledge.md Section 0 -- must be the opening of PRD.md
- app_identity.md is the owner's formalized platform identity -- primary input for PRD
- "Nexxus is NOT automotive-only" (app_identity.md line 50) -- architecture shouldn't be locked to automotive

### For SRS (Wave 2)
- Skills architecture (V1 -> V2 transition) MUST be documented -- this caused 8 tainted P0s (session-knowledge.md Section 0b)
- TextMagic per-org DB credentials (not .env) must be specified
- Trigger deduplication (2 mechanisms) must be specified
- Widget tools at system level (7 tools) must be specified
- "Widgets are portals to agents" concept (session-knowledge.md line 17) -- key SRS content

### For SPEC (Wave 3)
- 237 endpoints fully documented in UNIFIED_HANDOFF_PROMPT.md lines 112-148 and REVERSE_SRS_old.md
- 53 tables with schema in database-audit.md
- 40+ services inventoried in DO_NOT_TOUCH.md Section 3
- RLS variable name mismatch is a SPEC-level finding (REVERSE_SRS_old.md lines 203-216)

### For AC (Wave 4)
- Owner's 7 payment-critical items (session-knowledge.md Section 0c) are the PRIMARY AC source
- Owner views AC as "inverse of testing batteries" (Standards.md lines 4-7)
- AC should be "above-the-line focused" -- what users see and experience (session-knowledge.md Section 2)

### For PLAN (This Wave)
- Critical path to payment demo: Fix P0-1 through P0-5, then live-test all 7 demo items
- IMPLEMENTATION_PLAN.md v2.0 is useful as a reference but may need reprioritization against owner's 7 payment-critical items
- The 8-phase plan in IMPLEMENTATION_PLAN.md targets different ACs than the owner's 7 demo items

---

## Source File Log

| File | Location | Relevance | Key Extractions |
|------|----------|-----------|-----------------|
| session-knowledge.md | workbench root | HIGH | Owner's mental model, 7 payment-critical items, watch areas, architecture clarifications |
| file-inventory.md | workbench root | MEDIUM | 53 files categorized, flags (duplicates, security, superseded) |
| verified-findings.md | workbench root | HIGH | 11 code-verified findings, 3 confirmed P0s, 8 tainted, 4 need verification |
| failure-analysis.md | workbench root | HIGH | 31 failure items across 8 categories, gatekeeper gap |
| IMPLEMENTATION_PLAN.md | preflight-input | HIGH | 8-phase plan with file:line references, dependency graph, risk register |
| ACCEPTANCE_VERIFICATION_REPORT.md | preflight-input | HIGH | 13/13 PASS claim with operational caveats |
| DATA_ACCURACY_REPORT.md | preflight-input | HIGH | VAPI ingestion broken, 0 trigger executions, Tavus 0 sessions, VIN lead coverage |
| health-audit.md | preflight-input | HIGH | 402 files, 117K LOC, 747 tests, 0 unit tests, PM2 restarts, no CI/CD |
| DO_NOT_TOUCH.md | preflight-input | HIGH | 345+ frozen files, backend freeze manifest, safe-to-modify list |
| CARRY_FORWARD_MANIFEST.md | preflight-input | MEDIUM | 32 PRESERVE, 8 REFERENCE, 11 REPLACEABLE frontend files |
| REVERSE_SRS_old.md | preflight-input | HIGH | As-built audit, RLS mismatch, endpoint inventory, seed data |
| UNIFIED_HANDOFF_PROMPT.md | preflight-input | MEDIUM | V2.1 rebuild prompt, 6-tier doc hierarchy, endpoint catalog |
| CLAUDE.md (preflight) | preflight-input | MEDIUM | Pre-enforcer project config, sprint history, stale metrics |
| app_identity.md | preflight-input | HIGH | Owner's formalized platform identity, business model, all sections |
| CUSTOMER_ONBOARDING_KICKOFF.md | preflight-input | MEDIUM | Per-customer dependencies, decisions needed, readiness per AC |
| CONSTITUTION.md | preflight-input | LOW (not read in detail) | Platform principles |
| MASTER_SRS.md | preflight-input | LOW (not read in detail) | 257 requirements, supersedes prior SRS versions |
| known_issues.md.md | other_notes | MEDIUM | Phase 9 Run 2 results, owner reaction, causal chain |
| Current_State.md.md | other_notes | MEDIUM | 3 governance layers analysis, /init impact |
| Standards.md | other_notes | MEDIUM | Owner's document architecture vision (PRD/SRS/SPEC/PLAN/AC) |
| opinions_facts.md.md | other_notes | MEDIUM | Owner's evidence rules, 7 governance suggestions |
| Forensics.md.md | other_notes | LOW | Evidence audit framework (verified/derived/unverified) |
