# Wave 5 RECONCILED Output -- Current State for PLAN

**Date:** 2026-03-03
**Reconciliation by:** ORCHESTRATOR
**Inputs:** wave5-analyst.md (ANALYST) + wave5-reviewer.md (REVIEWER)
**Disagreements found:** 3

---

## Reconciliation Summary

Both extractions covered the same 10 categories and arrived at broadly consistent conclusions. The primary differences are:

1. **Completion percentage framing** (DISAGREE-1): Different measurements, not conflicting claims. Reconciled below.
2. **Sprint numbering discovery** (REVIEWER-only): REVIEWER explicitly identified that IMPLEMENTATION_PLAN.md phases 1-8 and CLAUDE.md phases 6-20 are TWO DIFFERENT NUMBERING SYSTEMS. ANALYST noted the conflict but did not name it as a separate numbering system.
3. **P0 scope**: Both agree on 3 confirmed code-level P0s (hosted pages, insights crash, appointment notifications). Both list VAPI webhook ingestion (P0-5) and zero trigger executions (P0-4) as P0. ANALYST also lists Tavus 0-sessions and PM2 crash-looping as P0; REVIEWER lists Tavus as P0 and PM2 as P1. See DISAGREE-2.
4. **Tainted claims**: Both list the same 8 tainted items + 2 owner-resolved items. No discrepancy.
5. **Missing info**: Largely overlapping. REVIEWER adds 3 items ANALYST did not (M6: PM2 ecosystem config, M7: .env.example, M9: billing operational docs). Merged below.

---

## DISAGREEMENTS REQUIRING OWNER RESOLUTION

### DISAGREE-1: Completion Percentage

| Source | Claim | What It Measures |
|--------|-------|-----------------|
| ANALYST | ~90% backend, ~70% frontend, ~95% database | Per-subsystem code existence. "Does the code exist and is the schema in place?" |
| REVIEWER | ~65-70% feature-complete, ~40-50% demo-ready | Functional readiness. "Of the features that exist, how many actually work end-to-end?" |

**Reconciliation:** These are not contradictory -- they measure different things. Both are accurate within their frame:

- **Code coverage** (ANALYST's frame): Most backend routes, services, and database tables exist. 237 endpoints, 53 tables, 40+ services. The code is largely written.
- **Functional readiness** (REVIEWER's frame): Of those features, many have never been tested in production. 0 trigger executions, 0 SMS sends, 72% VAPI calls missing, 0 Tavus sessions captured.
- **Demo readiness** (REVIEWER's frame): Of the 7 payment-critical items, 0 are fully demo-ready (REVIEWER) / 1 is functional (ANALYST: Automa Chat).

**RECONCILED STATEMENT:** The codebase is ~85-90% written (code exists for most features) but only ~40-50% operationally verified. Of the 7 payment-critical demo items, 1 works (Automa Chat), 5 are partially functional with blocking bugs, and 1 (Proactive Lead Follow-up) has fundamental operational failures.

**Owner action:** None required -- this is an informational reconciliation. PLAN.md should use the operational/demo-ready framing since that drives prioritization.

---

### DISAGREE-2: Tavus and PM2 Severity

| Item | ANALYST | REVIEWER |
|------|---------|----------|
| Tavus: 0 real sessions captured | P0-6 (CONFIRMED) but "Not directly demo-blocking (video not in 7 items)" | P0 (Critical Data Integrity Gap) |
| PM2 crash-looping (3,247+ restarts) | P0-7 (STATUS UNKNOWN, may be resolved) | P1 (Critical Data Integrity Gap) |

**Reconciliation:**

- **Tavus:** ANALYST correctly identifies video is not in the 7 payment-critical demo items. REVIEWER correctly identifies it as a data integrity P0. Both are right from their frame. For PLAN.md prioritization: Tavus is P1 (important but not demo-blocking). It should not be fixed before the 7 demo-critical items.
- **PM2:** ANALYST notes health-audit.md line 416 shows 2-day uptime (as of Feb 21), suggesting it may have stabilized. REVIEWER cites the 3,247 restart count. Neither has current data. Both agree it needs verification.

**RECONCILED SEVERITY:**
- Tavus: **P1** (not in 7 demo items, but must be fixed before video agents go live)
- PM2: **P0-VERIFY** (if still crash-looping, it blocks everything; if stabilized, downgrade to P2)

**Owner action:** Verify current PM2 status (`pm2 status` on production server). If stable, PM2 drops to P2. If crash-looping, it is the top-priority fix.

---

### DISAGREE-3: VIN Solutions API Access Scope

| Source | Claim | Evidence |
|--------|-------|----------|
| ANALYST | (not mentioned) | -- |
| REVIEWER | "17/30 VIN endpoints blocked with 403" | UNIFIED_HANDOFF_PROMPT.md Lesson 1 |

**Reconciliation:** REVIEWER found an additional detail: VIN Solutions API access is partial (17 of 30 endpoints return 403). ANALYST did not flag this. This affects the Context Router and Mark Contacted -> VIN writeback features.

**RECONCILED:** Include as a known constraint. The VIN API probe (PUT /leads) succeeded, so write-back is possible, but other endpoints may fail.

**Owner action:** None immediate. Document in SPEC.md which VIN endpoints are accessible.

---

## RECONCILED CATEGORIES

### Category 1: Project Completion Status

**RECONCILED ASSESSMENT:**

| Area | Completion (Code Exists) | Operational (Works in Prod) | Evidence |
|------|--------------------------|----------------------------|----------|
| Backend/API | ~90% | ~70% | 237 endpoints, 40+ services. Most routes work. VAPI ingestion, trigger execution, SMS sending broken. |
| Database | ~95% | ~90% | 53 tables, 33 migrations, ~100 RLS policies. Schema is solid. RLS variable name mismatch is the main issue. |
| Frontend (visual) | ~70% | ~60% | 172 source files, 21 pages. Insights crash risk, hosted pages 404. V2.1 rebuild was planned. |
| Integrations | ~75% | ~40% | 7 integrations wired. VIN works for 3/5 orgs. VAPI ingestion broken. Tavus 0 sessions. SMS 0 sends. |
| Metrics/Insights | ~60% | ~40% | Fragmented across 5 services. DashboardService works for basic cards. Insights page has crash risk. |
| Trigger System | ~50% | ~0% | Code exists, cron runs every 5 min, 8 active rules. Zero production executions completed. |
| SMS (TextMagic) | ~40% | ~0% | Service exists, per-org creds confirmed. 0 successful sends. |
| Testing | ~45% | Unknown | 747 E2E tests exist. 0 unit tests. No recent pass/fail data post-rollback. |
| Governance/Docs | ~20% correct | ~20% | 3 conflicting governance layers, AC placeholder, CLAUDE.md mismatch. |

**Key claims verified by both:**
- "13/13 PASS" in ACCEPTANCE_VERIFICATION_REPORT.md is partially misleading -- several items marked PASS have operational caveats (0/84 trigger executions, 0 video agents, shared SMS number). Source: ACCEPTANCE_VERIFICATION_REPORT.md line 10 vs lines 45, 63, 87.
- "All 12 P0 FIXED" in release_criteria.md is incorrect -- at least 3 confirmed P0s remain open (hosted pages, insights crash, appointment notifications). Source: verified-findings.md F0, F1.
- Run 2 "22 P0 blockers, 22/100 readiness" is significantly overstated -- actual P0 count is 3-7 after removing 8 tainted + 2 resolved. Source: verified-findings.md F9.

---

### Category 2: Known Gaps & Bugs (UNIFIED GAP LIST)

#### Payment-Critical Demo Mapping

| # | Demo Item | Status | Blocking Gaps | Fix Complexity |
|---|-----------|--------|---------------|----------------|
| 1 | Metrics & Insights display | PARTIAL | P0-2 (insights crash) + metrics fragmented | TRIVIAL (4 null guards) + MODERATE (MetricsEngine consolidation) |
| 2 | Communications Agent Config | PARTIAL | P0-4 (0 trigger executions) + P0-5 (VAPI ingestion broken) | MODERATE (trigger logic fix + UPSERT) |
| 3 | Appointment Flow | PARTIAL | P0-3 (0 appointment notifications) + P1-4 (0 VIN syncs) + P1-8 (start_time null) | MODERATE (add event emission) |
| 4 | Proactive Lead Follow-up | NOT WORKING | P0-4 (0 trigger executions) + P0-5 (VAPI ingestion) + VAPI phone numbers not assigned | MODERATE-HARD (trigger logic + VAPI config + phone purchase) |
| 5 | Reactive After-Hours | PARTIAL | P1-10 (SMS 0 sends) + business hours routing not wired | MODERATE (wire routing logic, test TextMagic) |
| 6 | Widgets (all 3 modes) | MOSTLY WORKING | P0-1 (hosted pages 404) | TRIVIAL (1-line fix) |
| 7 | Automa Chat | WORKING | None | -- |

**Summary:** 1 of 7 works. 1 is mostly working (1-line fix). 5 have P0 blocking issues. Demo item #4 (Proactive Lead Follow-up) is the hardest -- requires trigger logic fix, VAPI webhook fix, and phone number purchases.

#### P0 Gaps (Must Fix for Demo)

| ID | Gap | Source | Status | Demo Blocks | Fix Complexity |
|----|-----|--------|--------|-------------|----------------|
| P0-1 | **Hosted pages route mismatch** -- Client fetches `/api/hosted-pages/public/${slug}`, server serves `/api/pages/:slug` | verified-findings.md F2 (lines 98-108), hosted-page-public.tsx:163 vs routes.ts:175 | CONFIRMED (both agents) | #6 Widgets | TRIVIAL: 1-line fix |
| P0-2 | **Insights crash risk** -- 4 unsafe `.pct` accesses without null guards at insights.tsx lines 854, 1293, 2142, 2143 | verified-findings.md F3 (lines 114-122) | CONFIRMED (both agents) | #1 Metrics | TRIVIAL: 4 null guards |
| P0-3 | **Appointment status notifications missing** -- updateAppointment() fires zero events, no appointment_status_change event type | verified-findings.md F1 item 12 (line 63), release_criteria.md line 70 | CONFIRMED (both agents) | #3 Appointment Flow | MODERATE: Add event emission to AppointmentService |
| P0-4 | **Zero production trigger executions** -- All 84 executions are E2E test artifacts. `lead_age_minutes >= 5` evaluated at import time when lead is 0 min old | DATA_ACCURACY_REPORT.md lines 622-627 | CONFIRMED (both agents) | #2, #4 Proactive Follow-up | MODERATE: Trigger re-evaluation job exists (5-min interval) but condition logic needs fixing |
| P0-5 | **VAPI webhook ingestion broken** -- 66 post-V2 calls lost. `call.started` never received; `handleEndOfCallReport` UPDATE-only, finds no row to update | DATA_ACCURACY_REPORT.md lines 98-130 | CONFIRMED (both agents) | #2, #4 Proactive Follow-up | MODERATE: Change to UPSERT + investigate VAPI dashboard org-level server URL config |

#### P0-VERIFY (Need Live Check Before Severity Confirmed)

| ID | Gap | Source | Status | Demo Blocks | Action Needed |
|----|-----|--------|--------|-------------|---------------|
| P0-V1 | **PM2 crash-looping** -- 3,247-3,327 restarts at audit time (Feb 21). health-audit.md line 416 shows 2D uptime, suggesting possible stabilization | DATA_ACCURACY_REPORT.md lines 170-175, health-audit.md lines 412-419 | NEEDS LIVE VERIFICATION | ALL (if still looping) | Run `pm2 status` on production. If stable -> P2. If looping -> top priority fix. |

#### P1 Gaps (Important, Not Immediately Demo-Blocking)

| ID | Gap | Source | Status | Notes |
|----|-----|--------|--------|-------|
| P1-1 | Agent status toggle bypasses provisioning | release_criteria.md, verified-findings.md F10 line 243 | OPEN | GAP-B1-STATUS-BYPASS-001 |
| P1-2 | LeadMapper missing 6/8 source mappings | release_criteria.md, verified-findings.md F10 line 244 | OPEN | GAP-B1-SOURCE-MAP-001 |
| P1-3 | idle_trigger_count never resets | release_criteria.md, verified-findings.md F10 line 245 | OPEN | GAP-B4-IDLE-RESET-001 |
| P1-4 | 0/22 successful VIN syncs at runtime | release_criteria.md, verified-findings.md F10 line 246 | OPEN | GAP-B3-VIN-SYNC-001 -- may block #3 Appointment Flow |
| P1-5 | Persona data never reaches frontend | release_criteria.md, verified-findings.md F10 line 247 | OPEN | GAP-B2-PERSONA-RESPONSE-001 |
| P1-6 | Legacy agent names block seed | release_criteria.md, verified-findings.md F10 line 248 | OPEN | GAP-B6-AGENT-NAME-001 |
| P1-7 | Super Admin can't view other orgs' data | release_criteria.md, verified-findings.md F10 line 249 | OPEN | GAP-B6-SA-DATA-001 |
| P1-8 | start_time returns null in appointment API | release_criteria.md, verified-findings.md F10 line 250 | OPEN | GAP-B5-APPT-STARTTIME-001 |
| P1-9 | Ford/Hyundai triggers with no VIN integration | DATA_ACCURACY_REPORT.md lines 636-638 | OPEN | Missing VIN config for 2 orgs |
| P1-10 | SMS: 0 successful sends | DATA_ACCURACY_REPORT.md line 656 | OPEN | Configured but untested. Blocks demo item #5. |
| P1-11 | 19-28% gap in 7-day VIN lead capture | DATA_ACCURACY_REPORT.md lines 450-454 | OPEN | Polling timing/pagination |
| P1-12 | Unregistered VAPI assistants (38 calls) | DATA_ACCURACY_REPORT.md lines 86-91 | OPEN | Elliott, Andor, Gabrielle not in agents table |
| P1-13 | No credits/notifications on VAPI records | DATA_ACCURACY_REPORT.md lines 147-152 | OPEN | Bulk-imported before logic existed. Depends on P0-5 fix. |
| P1-14 | RLS variable name mismatch -- SecureQueryBuilder uses `app.current_organization_id`, RLS checks `app.current_org_id` | REVERSE_SRS_old.md lines 203-216, UNIFIED_HANDOFF_PROMPT.md Lesson 4 | OPEN | Security architecture broken but system works via direct bypasses |
| P1-15 | hot_lead event has no firing call site | ACCEPTANCE_VERIFICATION_REPORT.md line 100 | OPEN | Trigger event defined but never emitted |
| P1-16 | updatePerformanceMetrics() defined but never called | IMPLEMENTATION_PLAN.md lines 243-258 | OPEN | Agent metrics never updated from webhooks |
| P1-17 | Mark Contacted only updates local DB, not VIN CRM | IMPLEMENTATION_PLAN.md lines 262-283 | OPEN | Wiring gap. VIN PUT /leads probe succeeded. |
| P1-18 | **Tavus: 0 real sessions captured** -- Zero V2 callback URLs configured, no video agents registered with persona IDs | DATA_ACCURACY_REPORT.md lines 316-337 | CONFIRMED (both agents) | Not in 7 demo items. Must fix before video agents go live. |

#### P2 Gaps (Nice to Have / Technical Debt)

Both agents agree on these. Merged list:

| ID | Gap | Source | Notes |
|----|-----|--------|-------|
| P2-1 | 85% of leads stuck in `new` status | DATA_ACCURACY_REPORT.md line 666 | VIN import doesn't update status on re-import |
| P2-2 | 102 archived E2E test trigger rules | DATA_ACCURACY_REPORT.md line 667 | Cleanup needed |
| P2-3 | No activity feed CSV export | IMPLEMENTATION_PLAN.md line 585 | Phase 7 item |
| P2-4 | 380 explicit `any` type annotations | health-audit.md line 502 | Technical debt |
| P2-5 | 242 console.log in server, no structured logging | health-audit.md lines 517-521 | Technical debt |
| P2-6 | No ESLint/Prettier/pre-commit hooks | health-audit.md lines 510-514 | Technical debt |
| P2-7 | 18 stale feature branches | health-audit.md line 259 | Git hygiene |
| P2-8 | No PM2 ecosystem config file | health-audit.md line 425 | Deployment risk (REVIEWER: M6) |
| P2-9 | xlsx vulnerability (2 high CVEs, no fix) | health-audit.md lines 630-633 | Security |
| P2-10 | Deploy script has no rollback, no pre-deploy tests, no health check | health-audit.md lines 436-439 | Deployment risk |
| P2-11 | No CI/CD pipeline | health-audit.md line 651 | Process gap |

#### Needs Verification (Status Unknown)

| ID | Gap | Source | What's Needed |
|----|-----|--------|---------------|
| NV-1 | Widget header shows "Nexxus" not persona name | verified-findings.md F1 item 14 | Re-test with 1280x720 viewport |
| NV-2 | No availability validation for AI bookings | verified-findings.md F1 item 15 | Owner decision: is this required for launch? |
| NV-3 | Hyundai: no VIN integration config in DB | verified-findings.md F1 item 16, CUSTOMER_ONBOARDING_KICKOFF.md lines 37-39 | Owner decision: does this org use VIN? |
| NV-4 | Ford of Columbia: no VIN integration config | verified-findings.md F1 item 17, CUSTOMER_ONBOARDING_KICKOFF.md lines 37-39 | Same as NV-3 |

---

### Category 3: Implemented Features (Confirmed Working)

Both agents produced substantially identical lists. Merged with strongest evidence citation for each:

| Feature | Evidence | Status |
|---------|----------|--------|
| VAPI voice webhooks (receiving end-of-call-report) | DATA_ACCURACY_REPORT.md lines 101-102; PM2 logs show receipt of events | WORKING (but INSERT path broken -- see P0-5) |
| VIN Solutions OAuth + API (3/5 orgs) | DATA_ACCURACY_REPORT.md lines 377-381; tokens refreshing, last sync Feb 19 | WORKING |
| VIN lead polling job | DATA_ACCURACY_REPORT.md lines 496-507; every 60 min, 48-hour lookback, 771/771 leads have names | WORKING |
| Lead extraction pipeline | ACCEPTANCE_VERIFICATION_REPORT.md lines 54-57; webhook -> processCallEnd() -> sync_queue -> VIN API | WORKING (pipeline exists; runtime success rate low) |
| Calendar UI (FullCalendar) | ACCEPTANCE_VERIFICATION_REPORT.md AC-1: "Fixed in f12b025" | WORKING |
| Main dashboard | DATA_ACCURACY_REPORT.md "Dashboard Card Metrics": Overdue 263, New 223, Active 4, Recent 301 | WORKING |
| DealerBrain / Automa / Chat AI | ACCEPTANCE_VERIFICATION_REPORT.md AC-1; Claude API + 24 tools + SSE streaming | WORKING |
| Trigger system (code + cron) | DATA_ACCURACY_REPORT.md: 8 active rules, triggerReevalJob runs every 5 min | WORKING (code runs; 0 completions -- see P0-4) |
| Trigger deduplication (2 mechanisms) | verified-findings.md F1: TriggerService.ts:856-871 + idleLeadChecker.ts:406-439 | VERIFIED in code |
| TextMagic per-org credentials | verified-findings.md F1: TextMagicService.ts:223-232, line 330 decryptApiKey | VERIFIED in code |
| Widget tools (7 at system level) | verified-findings.md F1: WidgetConfigService.ts line 241 | VERIFIED in code |
| Unified widget (Preact bundle) | ACCEPTANCE_VERIFICATION_REPORT.md AC-6: 50.13KB, 19 configs, 6 channels, domain whitelist | WORKING |
| Security primitives (JWT, RLS, RBAC, encryption) | health-audit.md Section 11; REVERSE_SRS_old.md lines 440-457 | WORKING |
| 4-tier RBAC | ACCEPTANCE_VERIFICATION_REPORT.md AC-8: ROLE_VISIBILITY matrix, sidebar filtering | WORKING |
| Email via Resend | ACCEPTANCE_VERIFICATION_REPORT.md AC-3; domain verified | WORKING |
| Two-way SMS (code) | ACCEPTANCE_VERIFICATION_REPORT.md AC-2; phone format fixed, conversation state machine | CODE EXISTS (0 sends in production) |
| Email system (IMAP/SMTP) | ACCEPTANCE_VERIFICATION_REPORT.md lines 48-51; 7 API endpoints | WORKING (IMAP auth failure caused PM2 crashes previously) |
| Widget channels (6 implemented) | ACCEPTANCE_VERIFICATION_REPORT.md line 69 | WORKING |
| Hosted pages (code) | ACCEPTANCE_VERIFICATION_REPORT.md lines 73-76; 5 deployed slugs | CODE EXISTS (404 due to route mismatch -- see P0-1) |
| Context Router | IMPLEMENTATION_PLAN.md AC-006: "ALREADY CERTIFIED"; DO_NOT_TOUCH.md lines 141-144 | CLAIMED WORKING |
| DealerPulse | ACCEPTANCE_VERIFICATION_REPORT.md line 93; 5-phase health snapshots | WORKING |
| Agent CRUD + org isolation | ACCEPTANCE_VERIFICATION_REPORT.md AC-9: 12 active agents | WORKING |
| Credit system (code) | DO_NOT_TOUCH.md: CreditService; CARRY_FORWARD_MANIFEST.md: useCredits PRESERVE | CODE EXISTS (0 credits recorded -- depends on P0-5) |
| TypeScript strict mode | health-audit.md Section 7.1; npm run check PASSES | WORKING |
| E2E test suite (747 tests) | health-audit.md Section 2 | EXISTS (recent pass rate unknown) |
| Frontend integration plumbing | CARRY_FORWARD_MANIFEST.md: 32 PRESERVE files, 25 TanStack Query hooks | WORKING |
| Goals, Drive, Hunches/Approvals, Tracking Pixel, Google Calendar | DO_NOT_TOUCH.md (routes listed), CLAUDE.md preflight-input (phases marked COMPLETE) | CLAIMED COMPLETE (not independently verified post-rollback) |

**REVIEWER NOTE (retained):** Items marked "CLAIMED COMPLETE" from CLAUDE.md preflight-input were marked complete before the rollback to commit 95c0290. Current codebase state must be verified against the RUI and AC, not against these claims.

---

### Category 4: Broken Features (Built But Not Working)

Both agents agree on this list. Merged with strongest evidence:

| Feature | What's Broken | Evidence | Fix Complexity | Demo Blocks |
|---------|---------------|----------|----------------|-------------|
| VAPI webhook call ingestion | `call.started` never received for real calls; `handleEndOfCallReport` UPDATE-only, cannot INSERT. All 137 real DB records are bulk imports. | DATA_ACCURACY_REPORT.md lines 98-130 | MODERATE: UPSERT + VAPI dashboard config | #2, #4 |
| Hosted pages (public) | Route mismatch: client -> `/api/hosted-pages/public/${slug}`, server -> `/api/pages/:slug` | verified-findings.md F2, hosted-page-public.tsx:163 vs routes.ts:175 | TRIVIAL: 1-line fix | #6 |
| Insights page stability | 4 crash-risk locations with unguarded `.pct` access | verified-findings.md F3, insights.tsx lines 854, 1293, 2142, 2143 | TRIVIAL: 4 null guards | #1 |
| Production triggers | All 84 executions are test artifacts. lead_age_minutes condition never met at import time. | DATA_ACCURACY_REPORT.md lines 622-627 | MODERATE: Condition logic fix in re-evaluation job | #2, #4 |
| Appointment notifications | updateAppointment() fires zero events. No appointment_status_change event type. | verified-findings.md F1 item 12, release_criteria.md line 70 | MODERATE: Add event emission | #3 |
| Tavus video integration | 0 real sessions. No V2 callback URLs. No video agents with persona IDs. | DATA_ACCURACY_REPORT.md lines 316-337 | MODERATE: Register agents, configure callbacks | Not in 7 demo items |
| VIN sync at runtime | 0/22 successful VIN syncs noted in gap tracker | verified-findings.md F10 line 246 | NEEDS INVESTIGATION | May block #3 |
| Credit recording | 0/137 VAPI records have credit_recorded=true | DATA_ACCURACY_REPORT.md line 150 | MODERATE: Depends on VAPI webhook fix (P0-5) | Indirect |
| Notification sending | 0/137 VAPI records have notification_sent=true | DATA_ACCURACY_REPORT.md line 149 | MODERATE: Same P0-5 dependency | Indirect |
| Agent performance metrics | updatePerformanceMetrics() defined but never called | IMPLEMENTATION_PLAN.md Phase 3 | MODERATE | Not demo-blocking |

---

### Category 5: Missing Features (Specified But Not Built)

Both agents agree. Merged list with reconciled priority:

| Feature | Specified In | Current State | Priority | Demo Blocks |
|---------|-------------|---------------|----------|-------------|
| SMS after-hours AI routing | IMPLEMENTATION_PLAN.md Phase 5 | Migration 032 exists; routing logic not wired | P0 | #5 Reactive After-Hours |
| MetricsEngine consolidation | IMPLEMENTATION_PLAN.md Phase 4, lines 320-395 | MetricsEngine.ts file exists (may be stub). Metrics fragmented across 5 services. | P1 | Indirectly #1 |
| Combined cross-platform metrics | IMPLEMENTATION_PLAN.md Phase 6, lines 504-569 | Not implemented (depends on MetricsEngine) | P1 | Indirectly #1 |
| SMS collision avoidance state machine | IMPLEMENTATION_PLAN.md Phase 5 | sms_conversation_state table exists; full state machine may not be complete | P1 | -- |
| Mark Contacted -> VIN CRM writeback | IMPLEMENTATION_PLAN.md Phase 3 | Button updates local DB only; VIN PUT /leads probe succeeded | P1 | -- |
| Role-based dashboard filtering | IMPLEMENTATION_PLAN.md Phase 6 | RBAC infrastructure exists; metrics not role-filtered | P1 | -- |
| Availability validation for AI bookings | verified-findings.md GAP-B5-AVAIL-001 | Not built | OWNER DECISION | Possibly #3 |
| VAPI Analytics API integration | IMPLEMENTATION_PLAN.md Phase 3 | Not implemented; local computation only | P2 | -- |
| Activity feed CSV export | IMPLEMENTATION_PLAN.md Phase 7 | Not implemented | P2 | -- |
| Unit tests | health-audit.md line 44 | Zero exist | P2 | -- |
| CI/CD pipeline | health-audit.md line 651 | Not configured | P2 | -- |
| Web scraping skill | session-knowledge.md line 29 | Not implemented | FUTURE | -- |
| AI Governance Stage 2-3 | IMPLEMENTATION_PLAN.md lines 765-766 | Stage 1 monitoring-only active | FUTURE | -- |
| MCP proxy integration | app_identity.md line 239 | Exists at central-mcp but not properly integrated | FUTURE | -- |

---

### Category 6: Tainted Claims (Must NOT Re-Enter Gap List)

Both agents list identical 8 tainted + 2 owner-resolved items. No discrepancy.

| # | Gap ID | Run 2 Claim | Why Wrong | Verification |
|---|--------|-------------|-----------|-------------|
| 1 | GAP-B1-AGENT-001 | Serra Nissan: no chat agent | Automa IS the chat agent on homepage/popout | Owner + verified-findings.md F1 |
| 2 | GAP-B1-AGENT-002 | Tony Serra Ford: no chat agent | Same architecture misunderstanding | Owner + verified-findings.md F1 |
| 3 | GAP-B1-AGENT-003 | Ford of Columbia: no chat agent | Same | Owner + verified-findings.md F1 |
| 4 | GAP-B1-SKILLS-001 | No tools on any agent (tools=[]) | Tools at widget/system level (7 tools in chatEnabledTools at WidgetConfigService.ts:241) | verified-findings.md F1 item 4 |
| 5 | GAP-B1-INSTR-001 | Lead Follow-Up lacks CRM instructions | Skills are prompt overlays on Automa; raw DB field doesn't reflect runtime behavior | session-knowledge.md 0b |
| 6 | GAP-B1-INSTR-002 | 15-min idle trigger not in instructions | Same skills overlay misunderstanding | Owner confirmation |
| 7 | GAP-B1-TRIGGER-001 | No trigger dedup for active conversations | TWO dedup mechanisms exist: TriggerService.ts:856-871 + idleLeadChecker.ts:406-439 | verified-findings.md F1 item 7 |
| 8 | GAP-B3-SMS-001 | TextMagic API returns 401 | Tested .env creds; service uses per-org DB creds (TextMagicService.ts:223-232) | verified-findings.md F1 item 8 |

**Additionally resolved by owner (not tainted, just N/A):**

| # | Gap ID | Owner Decision |
|---|--------|----------------|
| 9 | GAP-B5-VIN-SYNC-001 | VIN has no calendar API. Platform calendar is standalone. Marked N/A in release_criteria.md line 69. |
| 10 | GAP-B5-BIDIR-001 | Same -- bidirectional calendar/VIN is impossible. |

**Root cause:** Agent performing Run 2 did not understand the V1-to-V2 architecture transition. Skills model, Automa-as-chat-agent, widget-level tools, and per-org credentials were never documented in any file the testing agent could read. Source: failure-analysis.md Category A.

**The Run 2 readiness score of 22/100 is SIGNIFICANTLY WRONG** (verified-findings.md F9). Both agents confirm.

---

### Category 7: Dependencies & Prerequisites

Both agents agree on all items. Merged with strongest citations:

#### For Payment-Critical Demo

| Dependency | Required For | Status | Who Owns | Source |
|------------|-------------|--------|----------|--------|
| Fix hosted pages route (1 line) | #6 Widgets | Code fix needed | Developer | verified-findings.md F2 |
| Fix insights.tsx null guards (4 lines) | #1 Metrics | Code fix needed | Developer | verified-findings.md F3 |
| Add appointment event emission | #3 Appointment Flow | Code addition needed | Developer | verified-findings.md F1 item 12 |
| Fix VAPI webhook UPSERT | #2, #4 Lead pipeline + triggers + credits | Code fix + VAPI dashboard config | Developer + Huminic (VAPI dashboard) | DATA_ACCURACY_REPORT.md lines 98-130 |
| Fix trigger delayed re-evaluation logic | #2, #4 Proactive Follow-up | Code fix (lead_age_minutes condition) | Developer | DATA_ACCURACY_REPORT.md lines 622-627 |
| VAPI phone numbers assigned per org | #4, #5 Outbound calls | NOT DONE | Huminic must purchase in VAPI dashboard | CUSTOMER_ONBOARDING_KICKOFF.md line 27 |
| Trigger rules activated by customer | #4 Proactive Follow-up | NOT DONE | Customer approval required | CUSTOMER_ONBOARDING_KICKOFF.md line 28 |
| Production website domains | #6 Widgets (embed mode) | NOT PROVIDED | Customer must provide | CUSTOMER_ONBOARDING_KICKOFF.md line 26 |
| Columbia VIN credentials | VIN integration for 2 orgs | NOT PROVIDED | Customer must confirm CRM usage | CUSTOMER_ONBOARDING_KICKOFF.md lines 37-39 |

#### For Governance Resolution

| Dependency | Blocks | Source |
|------------|--------|--------|
| Owner updates CLAUDE.md on disk (chmod 444) | All future agent sessions | failure-analysis.md B2, verified-findings.md F5 |
| Resolve 3 AC files into 1 authoritative | Agent trust in truth hierarchy | failure-analysis.md D1, verified-findings.md F4 |
| Write V1->V2 architecture knowledge to files | Prevent future tainted findings | failure-analysis.md A1-A4 |
| Decide on quality verification agent role | Sprint lifecycle quality assurance | failure-analysis.md H1-H4 |

#### Technical Dependencies (Build Sequencing)

| Prerequisite | Depends On | Status |
|-------------|------------|--------|
| MetricsEngine consolidation | Phase 2 field population audit | NOT STARTED |
| Combined metrics | MetricsEngine | NOT STARTED |
| Mark Contacted VIN writeback | VIN API header verification | Headers likely OK (probe succeeded) |
| SMS after-hours routing | Business hours config (migration 032) | Config exists, logic not wired |
| Credit recording | VAPI webhook fix (P0-5) | Blocked by P0-5 |
| Notification sending | VAPI webhook fix (P0-5) | Blocked by P0-5 |

---

### Category 8: Sprint/Phase History

#### CRITICAL DISCOVERY (REVIEWER): Two Different Numbering Systems

**IMPLEMENTATION_PLAN.md Phases 1-8** and **CLAUDE.md Phases 6-20** are NOT the same plan.

- **CLAUDE.md Phases 6-20:** Post-MVP roadmap items (Credit Wiring, Notifications, TextMagic, etc.) -- all marked COMPLETE. These were executed during the Jan-Feb build sprint.
- **IMPLEMENTATION_PLAN.md Phases 1-8:** A gap-closure plan written on 2026-02-18 AFTER the build sprint. These phases have NOT been started. The plan explicitly states: "Phase numbers start at 1. There are no inherited phase numbers from prior plans."

Source: IMPLEMENTATION_PLAN.md Section "Phasing Strategy" line 2 (REVIEWER), cross-confirmed by ANALYST noting CONFLICT between CLAUDE.md "COMPLETE" markers and DATA_ACCURACY_REPORT.md showing broken features.

#### Build Timeline (both agents agree)

| Period | Commits | Activity | Source |
|--------|---------|----------|--------|
| 2026-01-21 to 2026-01-24 | 9 | Ramp-up | health-audit.md lines 173-193 |
| 2026-01-24 to 2026-01-31 | 8 | Early development | health-audit.md |
| 2026-01-31 to 2026-02-07 | 63 | Peak sprint (MVP push) | health-audit.md |
| 2026-02-02 | -- | MVP deployed (REVIEWER-only detail) | CLAUDE.md preflight-input |
| 2026-02-07 to 2026-02-14 | 66 | Peak sprint (stabilization) | health-audit.md |
| 2026-02-14 to 2026-02-21 | 35 | Post-stabilization | health-audit.md |

**Total:** 181 commits over 31 days. 100% authored by Claude Code (health-audit.md line 266).

#### Post-Sprint Activity (both agents agree)

| Date | Event | Source |
|------|-------|--------|
| 2026-02-16 | "Second Wave Fresh Start" -- 40+ files archived | CLAUDE.md preflight-input line ~335 |
| 2026-02-18 | IMPLEMENTATION_PLAN.md v2.0 + CONSTITUTION + MASTER_SRS written | File dates |
| 2026-02-19 | ACCEPTANCE_VERIFICATION_REPORT + DATA_ACCURACY_REPORT | File dates |
| 2026-02-21 | REVERSE_SRS forensic audit, health-audit | File dates |
| 2026-02-22 | /init Tier 3 run (created .project/ governance layer) | session-knowledge.md Section 1 |
| 2026-02-22 | DO_NOT_TOUCH.md, UNIFIED_HANDOFF_PROMPT.md, CARRY_FORWARD_MANIFEST.md | File dates |
| 2026-03-01 | Enforcer bootstrap (.agent_docs/ layer), method enforcement overhaul | MEMORY.md |
| 2026-03-01 | Phase 9 Run 2 testing (~40% tainted) | MEMORY.md |
| 2026-03-02 | Fact-finding session, failure analysis, preflight surgery plan | MEMORY.md |

#### IMPLEMENTATION_PLAN.md v2.0 (Feb 18) -- Reference for PLAN.md

8 phases with dependency chain:
1. Critical Fixes (vendor names, DealerBrain prompts) -- ~80 lines across ~12 files
2. Data Integrity (VIN headers, field population audit)
3. Wiring Gaps (webhook metrics, Mark Contacted to VIN, VAPI Analytics)
4. Metrics Consolidation (unified MetricsEngine)
5. SMS Enhancement (after-hours routing, collision avoidance)
6. Combined Metrics & Role Dashboards
7. Certification & Testing
8. Deployment

**Status:** NONE of these 8 phases were executed. The /init run on 2026-02-22 created a competing plan structure. No evidence of systematic execution. Source: Both agents confirm.

---

### Category 9: Environment Status

Both agents agree on all environment details. Merged with strongest citations:

#### Deployment State

| Component | Status | Evidence |
|-----------|--------|----------|
| PM2 process (nexxus-v2) | Online (PID 1616575, 148.9 MB) at audit time | health-audit.md lines 412-419 |
| Uptime | 2 days at audit time (Feb 21) | health-audit.md line 416 |
| Total restarts | 3,247-3,327 | DATA_ACCURACY_REPORT.md line 170 / health-audit.md line 418 |
| Live URL | https://nexxusv2.huminicdev.com | health-audit.md line 7 |
| Node.js | v20.19.5 | health-audit.md line 447 |
| Platform | Linux 5.15.0-1081-oracle (Oracle Cloud) | health-audit.md line 449 |
| Reverse proxy | Caddy (managed by sysadmin) | health-audit.md line 464 |
| Build | `npm run build` produces 4 outputs (client, widget, pixel, server) | health-audit.md lines 349-357 |
| Docker | NOT USED | health-audit.md 6.5 |
| CI/CD | NOT CONFIGURED | health-audit.md 6.5 |
| Deploy script | deploy.sh (master-only, no rollback, no health check) | health-audit.md 6.2 |

#### Database State

| Component | Status | Evidence |
|-----------|--------|----------|
| Provider | Supabase (PostgreSQL) on AWS us-west-2 | REVERSE_SRS_old.md line 144 |
| Tables | 53 (corrects stale "36" in CLAUDE.md) | REVERSE_SRS_old.md line 149 |
| Migrations | 33 (001-033, 011 missing, two 004s) | REVERSE_SRS_old.md lines 175-182 |
| RLS policies | ~100 (corrects stale "53" in CLAUDE.md) | REVERSE_SRS_old.md line 186 |
| RLS variable mismatch | SecureQueryBuilder uses `app.current_organization_id`, RLS checks `app.current_org_id` | REVERSE_SRS_old.md lines 203-216, UNIFIED_HANDOFF_PROMPT.md Lesson 4 |
| Known vulnerability | xlsx package: 2 high-severity CVEs, no fix available | health-audit.md lines 630-633 |
| Live data | 775 leads (excl excel_upload), 137 VAPI records (all bulk-imported), 1 Tavus seed record | DATA_ACCURACY_REPORT.md |

#### External Service Connectivity

| Service | Status | Evidence |
|---------|--------|----------|
| VIN Solutions OAuth | ACTIVE for 3 orgs (Serra Honda, Serra Nissan, Tony Serra Ford) | DATA_ACCURACY_REPORT.md lines 377-381 |
| VIN Solutions OAuth | NOT CONFIGURED for 2 orgs (Ford/Hyundai of Columbia) | CUSTOMER_ONBOARDING_KICKOFF.md lines 37-39 |
| VIN Solutions API | PARTIAL: 17/30 endpoints blocked with 403 (REVIEWER-only detail) | UNIFIED_HANDOFF_PROMPT.md Lesson 1 |
| VAPI webhooks | RECEIVING end-of-call-report (NOT call.started) | DATA_ACCURACY_REPORT.md lines 101-102 |
| VAPI phone numbers | 7 numbers on account | DATA_ACCURACY_REPORT.md line 92 |
| VAPI API (calls) | WORKING: 832 total calls on account | DATA_ACCURACY_REPORT.md (REVIEWER-only detail) |
| Tavus webhooks | NOT RECEIVING (0 V2 callback URLs) | DATA_ACCURACY_REPORT.md line 282 |
| Tavus API | WORKING: 136 conversations queryable (REVIEWER-only detail) | DATA_ACCURACY_REPORT.md |
| TextMagic SMS | Configured but 0 successful sends | DATA_ACCURACY_REPORT.md line 656 |
| Resend email | WORKING (domain verified) | verified-findings.md F10, ACCEPTANCE_VERIFICATION_REPORT.md AC-3 |
| Claude API (DealerBrain) | WORKING | ACCEPTANCE_VERIFICATION_REPORT.md AC-1 |
| Google Calendar | OAuth flow implemented | DO_NOT_TOUCH.md, CLAUDE.md preflight-input |
| Central-MCP | Port 4002, Notion/Supabase/ClickUp/VAPI connectors. No TextMagic. Not properly integrated. | MEMORY.md, app_identity.md line 239 |

#### Build System

| Check | Status | Source |
|-------|--------|--------|
| `npm run check` (TypeScript) | PASSES | ACCEPTANCE_VERIFICATION_REPORT.md Quality Gates |
| `npm run build` (production) | PASSES | ACCEPTANCE_VERIFICATION_REPORT.md Quality Gates |
| E2E tests (747) | EXISTS (last full run unknown post-rollback) | health-audit.md Section 2 |
| Unit tests | ZERO | health-audit.md 2.5 |
| Linter | NOT CONFIGURED | health-audit.md 7.3 |

---

### Category 10: Owner Decisions Needed

Merged list. Both agents agree on items 1-5. REVIEWER adds items 7-10 that ANALYST did not cover (trigger activation, customer domains, VAPI phone selection, lead source tagging). ANALYST adds items 6-10 from a different angle (gatekeeper, billing UI, .project/, archive path, frontend rebuild).

| # | Decision | Context | Options | Urgency | Source |
|---|----------|---------|---------|---------|--------|
| 1 | **Update CLAUDE.md on disk** | File is chmod 444, pre-enforcer content. New sessions read wrong rules. | Owner must manually edit. | HIGH | failure-analysis.md B2, verified-findings.md F5 |
| 2 | **Which AC file is authoritative?** | 3 files: docs/AC (89KB), .agent_docs/AC (58KB, PLACEHOLDER), filestore/AC (49KB). | A) Complete reconciliation, B) Write new consolidated AC at root, C) Use docs/AC as-is. Surgery creates new consolidated AC. | HIGH | failure-analysis.md D1, verified-findings.md F4 |
| 3 | **How to restore quality verification loop?** | Gatekeeper archived. Enforcer does commit compliance, not sprint-level quality. | A) Restore gatekeeper function in new agent, B) Add quality loop to enforcer, C) Owner does manual QA. | HIGH | failure-analysis.md H1-H4 |
| 4 | **Trigger activation preferences per customer** | 8 active trigger rules exist but all deactivated for live firing. | Customer decisions needed per CUSTOMER_ONBOARDING_KICKOFF.md Items 3-4. | HIGH (for demo) | CUSTOMER_ONBOARDING_KICKOFF.md, DATA_ACCURACY_REPORT.md |
| 5 | **VAPI phone number selection per org** | Required for outbound call triggers. Must purchase/register in VAPI dashboard. | Huminic purchases, dealership approves area code. | HIGH (for demo) | CUSTOMER_ONBOARDING_KICKOFF.md Item 2 |
| 6 | **Is availability validation required for launch?** | No bounds checking on AI-booked appointments. | Accept risk for demo OR build validation. | MEDIUM | verified-findings.md GAP-B5-AVAIL-001 |
| 7 | **Are Ford/Hyundai Columbia VIN-integrated?** | No VIN config for these orgs. May be intentional. | A) These orgs don't use VIN, B) Need dealer IDs + credentials. | MEDIUM | CUSTOMER_ONBOARDING_KICKOFF.md lines 37-39 |
| 8 | **Customer website domains for widget deployment** | Widget embed only works on whitelisted domains, currently localhost. | Customers must provide domains. | MEDIUM | CUSTOMER_ONBOARDING_KICKOFF.md Item 1 |
| 9 | **Lead source tagging for VIN insertion** | How should AI-generated leads appear in VIN Solutions? | "Nexxus AI", "Phone - AI", "Internet - Chatbot", or match existing CRM sources. | MEDIUM | CUSTOMER_ONBOARDING_KICKOFF.md Decision 3 (REVIEWER-only) |
| 10 | **Frontend rebuild scope** | V2.1 rebuild was planned per UNIFIED_HANDOFF_PROMPT.md. Pre-flight surgery focuses on governance + gap fixes, not rebuild. | Is full rebuild still the plan? Or fix existing frontend? | MEDIUM | UNIFIED_HANDOFF_PROMPT.md |
| 11 | **Billing UI timing** | Backend billing wired but Credits page hidden (App.tsx:106-114). | When to expose billing UI? | LOW | IMPLEMENTATION_PLAN.md line 764 |
| 12 | **What to do with .project/ directory** | /init created parallel governance layer. | A) Gut it (reserved for /plan scratch), B) Delete entirely, C) Reconcile. | LOW | session-knowledge.md Section 1 |
| 13 | **Archive folder path** | Owner has archive folder outside nexxus-v2 root for deprecated files. Path not provided. | Owner provides path. | LOW | MEMORY.md |

---

## RECONCILED WATCH AREAS

### Watch Area 1: Agent Functionality/Defaults

**Current State (both agents agree):**
- 12 active agents: 5 voice (VAPI), 2 chat, 4 task, 0 video (ACCEPTANCE_VERIFICATION_REPORT.md AC-9)
- Automa is master chat agent, present in every account (app_identity.md B2, session-knowledge.md 0)
- V2 architecture: users CREATE agents and ADD skills (session-knowledge.md 0b)
- Default agents seeded via migration 004_serra_seed_data.sql (REVERSE_SRS_old.md lines 459-475)
- Agent CRUD API with org isolation works (ACCEPTANCE_VERIFICATION_REPORT.md AC-9)
- Only 1 of 5 defined agent .md files exists (enforcer.md) -- Orchestrator and 3 builders DO NOT EXIST (REVIEWER-only detail, verified-findings.md F6)

**Gaps:**
- 0 video agents registered with Tavus persona IDs (P1-18)
- Agent status toggle bypasses provisioning (P1-1)
- Legacy agent names block seed (P1-6)
- updatePerformanceMetrics() never called (P1-16)
- hot_lead event has no firing call site (P1-15)

**Needed:** Video agents registered with Tavus persona IDs. Agent seeding without name conflicts. Skills catalog documentation in agent-readable files.

### Watch Area 2: Billing

**Current State (both agents agree):**
- CreditService exists: balance tracking, usage deduction, policy enforcement (DO_NOT_TOUCH.md)
- Revenue model: Voice $0.25/min (40% margin), Video $0.32/min (37.5%), SMS $0.05/msg (60%) (REVERSE_SRS_old.md lines 99-105)
- Service quotas table exists (migration 031) (DO_NOT_TOUCH.md)
- Credit idempotency guard exists (migration 024) (DO_NOT_TOUCH.md)
- Credits page UI intentionally deferred/hidden (IMPLEMENTATION_PLAN.md line 764)
- Credit hooks (useCredits) marked PRESERVE (CARRY_FORWARD_MANIFEST.md)

**Gaps:**
- 0/137 VAPI records have credit_recorded=true (P1-13, depends on P0-5)
- 0/137 VAPI records have notification_sent=true (same root cause)
- Root cause per REVIEWER: bulk imports happened before credit/notification logic existed; idempotency guards on UPDATE path fail when row doesn't exist
- No evidence of actual billing/invoicing to customers

**Needed:** Fix VAPI webhook ingestion (P0-5) first, then credit recording will work. Owner decision on billing UI timing.

### Watch Area 3: Unified Inbox Handoff

**Current State (both agents agree):**
- InboxService exists with conversations, messages, assignment (DO_NOT_TOUCH.md)
- 8 API endpoints (UNIFIED_HANDOFF_PROMPT.md line 133)
- Staff messaging inbox implemented (CARRY_FORWARD_MANIFEST.md: useInbox hook with conversations, messages, assign, status, unread count)
- Widget -> inbox continuity is the intended architecture (session-knowledge.md 0)
- 21 inbox conversations in last 7 days (DATA_ACCURACY_REPORT.md)

**Gaps:**
- Widget -> inbox handoff needs live verification
- SMS conversations not visible in inbox (0 SMS sends)
- Email missing from Hub/inbox per CLARIFICATION_ANSWERS.md Q12 (REVIEWER-only detail)
- IMAP auth failure was causing PM2 crash-loops (may be resolved)

**Needed:** Live verification of widget -> inbox flow. Fix IMAP auth. Test SMS -> inbox once TextMagic sends are working.

### Watch Area 4: Super Admin

**Current State (both agents agree):**
- RBAC role level 1 = Super Admin (REVERSE_SRS_old.md)
- 14 admin API endpoints (UNIFIED_HANDOFF_PROMPT.md line 123)
- useAdmin hook marked PRESERVE (CARRY_FORWARD_MANIFEST.md)
- DealerBrain config management: Super Admin only (3 endpoints)

**Gaps:**
- GAP-B6-SA-DATA-001: Super Admin can't view other orgs' data (P1-7)
- Owner says "undertested" (session-knowledge.md 0d)
- No dedicated Super Admin test coverage beyond RBAC suite (41 tests in sprint-r4-rbac.spec.ts per health-audit.md 2.2, REVIEWER-only detail)

**Needed:** Dedicated Super Admin testing pass. Fix cross-org data visibility. Document functional scope.

### Watch Area 5: Context Router

**Current State (both agents agree):**
- 3 files: ContextRouterService.ts, SourceSelector.ts, CacheManager.ts (DO_NOT_TOUCH.md)
- Routes requests to VIN API (primary) or local DB (fallback) (REVERSE_SRS_old.md line 321)
- AC-006 marked "ALREADY CERTIFIED (build-verified)" (IMPLEMENTATION_PLAN.md)
- Owner defers technical implementation details; concerned about API rate limiting (CLARIFICATION_ANSWERS.md Q3, REVIEWER-only detail)

**Gaps:**
- CacheManager has false "48-hour API retention limit" comment (IMPLEMENTATION_PLAN.md Phase 1 Item 1.6)
- Stale @see reference to old SRS v3.0 (IMPLEMENTATION_PLAN.md)
- Daily refresh + manual button model decided but implementation status unknown (CLARIFICATION_ANSWERS.md Q4-Q5, REVIEWER-only detail)
- Context Router may be affected by RLS variable name mismatch (P1-14)

**Needed:** Verify routing under current RLS config. Fix stale comments. Document refresh model.

---

## RECONCILED CONFLICTS

Both agents identified overlapping conflicts. Merged into a single list with deduplicated numbering:

| # | Topic | Conflict | Resolution |
|---|-------|----------|------------|
| C1 | **Completion status** | CLAUDE.md: Phases 6-20 "COMPLETE" vs DATA_ACCURACY_REPORT.md: SMS 0 sends, triggers 0 fires, VAPI broken | Phases are claimed complete (code was written) but several features do not work operationally. PLAN.md must use operational state, not phase completion claims. |
| C2 | **P0 count (optimistic)** | release_criteria.md: "All 12 P0 FIXED, 0 blockers" vs verified-findings.md: 3 confirmed P0s still open | release_criteria.md is wrong. At least 5 P0s remain (P0-1 through P0-5). |
| C3 | **P0 count (pessimistic)** | FINAL_REPORT.md (Run 2): "22 P0 blockers, 22/100 readiness" vs verified-findings.md: only 3-7 actual P0s | Run 2 was ~40% tainted. Actual P0 count is 5 confirmed + 1 needs verification. |
| C4 | **AC reconciliation** | .agent_docs/work_tree.md: "COMPLETED" vs .agent_docs/acceptance_criteria.md: says "PLACEHOLDER" | work_tree.md is wrong. AC reconciliation was never completed. |
| C5 | **CLAUDE.md versions** | On-disk at commit 95c0290: pre-enforcer vs System prompt cache: has enforcer rules | On-disk is stale. Owner must manually update (chmod 444). |
| C6 | **Sprint numbering** | CLAUDE.md: Phases 6-20 (post-MVP roadmap, COMPLETE) vs IMPLEMENTATION_PLAN.md: Phases 1-8 (gap closure, NOT STARTED) | TWO DIFFERENT PLANS. IMPLEMENTATION_PLAN phases are a fresh gap-closure plan written after the build sprint. Neither numbering is "wrong" -- they track different things. PLAN.md should use its own numbering. |
| C7 | **Table count** | CLAUDE.md: "36 tables" vs REVERSE_SRS_old.md: "53 tables" | 53 is correct. 36 was stale CLAUDE.md info. health-audit.md parroted the stale number. |
| C8 | **RLS policy count** | CLAUDE.md: "53 RLS policies" vs REVERSE_SRS_old.md: "~100 RLS policies" | ~100 is correct. 53 was stale CLAUDE.md info. |
| C9 | **AC numbering** | CLAUDE.md: 5 ACs (AC-1 through AC-5) vs IMPLEMENTATION_PLAN.md: 19 ACs (AC-001 through AC-019) vs Owner's 7 payment-critical items | Three different AC sets. Owner's 7 payment-critical items (session-knowledge.md 0c) are the operative acceptance criteria for payment. |
| C10 | **13/13 PASS claim** | ACCEPTANCE_VERIFICATION_REPORT.md: all PASS vs Same report's own caveats: 0/84 trigger executions, 0 video agents | Report was point-in-time (Feb 19). "PASS" meant code exists, not operational verification. |
| C11 | **Frontend rebuild vs fix** | UNIFIED_HANDOFF_PROMPT.md: full V2.1 rebuild planned vs Current pre-flight surgery: governance + gap fixes | Owner decision needed (#10 above). |
| C12 | **Governance layers** | .project/ (8 BDD sprints) vs .agent_docs/ (phases 0-4 + plan_sequence) vs filestore/ (release_criteria gap tracker) | Surgery plan: gut .project/, keep .agent_docs/, create 6 root governance files. Owner decision needed (#12 above). |

---

## MERGED MISSING INFORMATION

Unified list from both agents. Items marked (A) = ANALYST-only, (R) = REVIEWER-only, (B) = both.

| # | What's Missing | Why It Matters | Source |
|---|---------------|----------------|--------|
| M1 | (B) Actual Playwright test pass rate post-rollback | 747 tests exist but no recent pass/fail | All audit reports |
| M2 | (B) Current PM2 stability | Feb 21 showed 3,327 restarts; may have stabilized | No file post-Feb 22 has PM2 data |
| M3 | (B) TextMagic send/receive test results | 0 sends in Feb 19 audit; status unknown | No post-Feb-19 TextMagic data |
| M4 | (B) Whether IMPLEMENTATION_PLAN.md phases were executed | Plan written Feb 18; no execution evidence | RECONCILED: Both confirm NOT executed |
| M5 | (B) V2.1 frontend rebuild status | UNIFIED_HANDOFF_PROMPT written Feb 22; no work artifacts found | No rebuild evidence |
| M6 | (B) VAPI dashboard configuration (org-level server URL, event subscriptions) | Required to fix call.started non-delivery | No VAPI dashboard screenshots |
| M7 | (B) Owner's archive folder path | Needed for file organization | Owner mentioned but didn't provide |
| M8 | (B) SMS business hours routing live test results | Migration 032 exists but no test evidence | No SMS test results |
| M9 | (A) Current .project/ directory contents | /init created it Feb 22; unclear what's in it | No listing |
| M10 | (A) Trigger re-evaluation job runtime behavior | Job exists (5-min interval) but unclear if it fixes lead_age_minutes | No runtime logs |
| M11 | (R) V1-to-V2 architecture narrative in agent-readable file | Prevents future tainted findings | session-knowledge.md 0, failure-analysis.md A1-A4 |
| M12 | (R) PM2 ecosystem config file | Process config is non-reproducible | health-audit.md 6.1 |
| M13 | (R) .env.example or .env.template | New sessions cannot verify env setup | health-audit.md 6.4 |
| M14 | (R) Context Router operational documentation | Agents don't understand routing logic | session-knowledge.md 0d |
| M15 | (R) Billing operational documentation | How credits flow, what's tracked, what's missing | session-knowledge.md 0d |
| M16 | (R) Super Admin functional scope documentation | Undertested, needs extraction | session-knowledge.md 0d |

---

## OWNER ACTION ITEMS SUMMARY

Prioritized by urgency and demo impact:

### IMMEDIATE (Blocks Demo Preparation)

| # | Action | Type | Owner |
|---|--------|------|-------|
| A1 | Verify PM2 status: `pm2 status` on production server | Live check | Huminic |
| A2 | Update CLAUDE.md on disk (chmod 444, must be manual) | Governance | Owner (Duane) |
| A3 | Decide: which AC file is authoritative? | Decision | Owner (Duane) |
| A4 | Purchase/assign VAPI phone numbers per org | External config | Huminic |
| A5 | Get customer approval for trigger rule activation | Customer decision | Owner (Duane) |

### BEFORE DEMO (Required for Payment)

| # | Action | Type | Owner |
|---|--------|------|-------|
| B1 | Fix P0-1: Hosted pages route (1 line) | Code fix | Developer |
| B2 | Fix P0-2: Insights null guards (4 lines) | Code fix | Developer |
| B3 | Fix P0-3: Appointment event emission | Code fix | Developer |
| B4 | Fix P0-4: Trigger condition logic | Code fix | Developer |
| B5 | Fix P0-5: VAPI webhook UPSERT + dashboard config | Code fix + Config | Developer + Huminic |
| B6 | Get customer website domains for widget embed | Customer input | Owner (Duane) |
| B7 | Confirm Columbia VIN Solutions usage | Customer input | Owner (Duane) |

### GOVERNANCE (Required for Sustainable Development)

| # | Action | Type | Owner |
|---|--------|------|-------|
| G1 | Decide on quality verification agent role (gatekeeper gap) | Decision | Owner (Duane) |
| G2 | Decide on frontend rebuild vs fix scope | Decision | Owner (Duane) |
| G3 | Decide on .project/ directory fate | Decision | Owner (Duane) |
| G4 | Provide archive folder path | Information | Owner (Duane) |
| G5 | Decide on availability validation for AI bookings | Decision | Owner (Duane) |
| G6 | Decide on lead source tagging for VIN insertion | Decision | Owner (Duane) |
| G7 | Decide on billing UI timing | Decision | Owner (Duane) |

---

## Cross-Wave Notes (Merged)

### For PRD (Wave 1)
- Owner's platform mental model (session-knowledge.md Section 0) must be the opening section
- app_identity.md is the formalized platform identity -- primary PRD input
- "Nexxus is NOT automotive-only" (app_identity.md line 50)

### For SRS (Wave 2)
- V1->V2 skills architecture MUST be documented (caused 8 tainted P0s)
- TextMagic per-org DB credentials (not .env) must be specified
- Trigger deduplication (2 mechanisms) must be specified
- Widget tools at system level (7 tools) must be specified
- "Widgets are portals to agents" concept
- "Below the line" system behaviors (credential handling, dedup, trigger mechanics) are NOT in any doc agents read (REVIEWER)

### For SPEC (Wave 3)
- 237 endpoints documented in UNIFIED_HANDOFF_PROMPT.md + REVERSE_SRS_old.md
- 53 tables with schema in database-audit.md
- 40+ services in DO_NOT_TOUCH.md Section 3
- RLS variable name mismatch is a SPEC-level finding
- No SPEC.md exists currently (REVIEWER: session-knowledge.md Section 2)
- CARRY_FORWARD_MANIFEST.md is the most practical build reference (REVIEWER)

### For AC (Wave 4)
- Owner's 7 payment-critical items (session-knowledge.md 0c) are PRIMARY
- Owner's 13-item demo AC (Acceptance Criteria.md) is secondary
- AC should be "inverse of testing batteries" (Standards.md lines 4-7)
- AC should be "above-the-line focused" (session-knowledge.md Section 2)

### For PLAN (This Wave)
- Critical path: Fix P0-1 through P0-5, then live-test all 7 demo items
- IMPLEMENTATION_PLAN.md v2.0 useful as reference but needs reprioritization against owner's 7 items
- PLAN.md should use its OWN numbering (not CLAUDE.md phases, not IMPLEMENTATION_PLAN.md phases)
- PLAN.md is permanent ("the roadmap, read every session") -- NOT a /plan scratch pad

---

*End of Wave 5 reconciled output. 3 disagreements flagged. All 10 categories covered. Ready for PLAN.md drafting.*
