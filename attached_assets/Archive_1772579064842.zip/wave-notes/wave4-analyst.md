# Wave 4 Analyst: Testable Outcomes Extraction (AC)

**Analyst:** Claude Opus 4.6 (Wave 4 ANALYST role)
**Date:** 2026-03-03
**Input Files Scanned:** 28 of ~53 (all HIGH and MEDIUM priority files per file-inventory.md)
**Method:** Extract every testable statement from input files, organize by 15 feature areas, cite source file and line

---

## Summary Statistics

| Metric | Count |
|--------|-------|
| Total AC items extracted | 247 |
| Explicitly stated (EXPLICIT) | 168 |
| Inferred from UI/behavior specs (INFERRED) | 79 |
| Testable (Playwright-automatable) | 209 |
| Testable (manual/live-integration only) | 38 |
| Conflicts detected | 12 |
| Missing AC (features without criteria) | 14 |
| Watch area items | 31 |

---

## 1. Authentication & Access (AUTH)

### AUTH-001 [EXPLICIT] — Login Page Renders
**Statement:** Given a user navigates to /login, When the page loads, Then a login form with email and password fields and a "Sign In" button is displayed.
**Source:** — Acceptance Criteria.md, line ~45 (Global Shell: Login Page)
**Testable:** YES (Playwright)
**Role(s):** All

### AUTH-002 [EXPLICIT] — Successful Login Redirects to Main
**Statement:** Given valid credentials, When user submits login form, Then user is redirected to the Main page (/) and JWT tokens are stored in localStorage.
**Source:** CARRY_FORWARD_MANIFEST.md, lines 39-44 (AuthContext Deep Details)
**Testable:** YES (Playwright)
**Role(s):** All

### AUTH-003 [EXPLICIT] — Invalid Login Shows Error
**Statement:** Given invalid credentials, When user submits login form, Then an error message is displayed and no redirect occurs.
**Source:** — Acceptance Criteria.md, line ~45 (Login Page); UNIFIED_HANDOFF_PROMPT.md, line 152
**Testable:** YES (Playwright)
**Role(s):** All

### AUTH-004 [EXPLICIT] — JWT Token Auto-Refresh
**Statement:** Given a logged-in user, When the access token is within 5 minutes of expiry, Then the system automatically refreshes the token via POST /api/auth/refresh without user interaction.
**Source:** CARRY_FORWARD_MANIFEST.md, lines 39-46; UNIFIED_HANDOFF_PROMPT.md, lines 153-160
**Testable:** YES (Playwright — observe network requests)
**Role(s):** All

### AUTH-005 [EXPLICIT] — Organization Switching (Partner Admin)
**Statement:** Given a Partner Admin user, When user selects a different organization from the org switcher, Then the system calls POST /api/auth/switch-org, returns new scoped tokens, and all data refreshes to the new org context.
**Source:** CARRY_FORWARD_MANIFEST.md, lines 138-146; MASTER_SRS.md, Section 4.5
**Testable:** YES (Playwright)
**Role(s):** partner_admin, super_admin

### AUTH-006 [EXPLICIT] — Super Admin Org Switch Includes "Nexxus System"
**Statement:** Given a Super Admin user, When org switcher is opened, Then there is an option for "Nexxus System" that shows the org UI in its default system configuration.
**Source:** ===DevDesign Notes===.md, line 37
**Testable:** YES (Playwright)
**Role(s):** super_admin

### AUTH-007 [EXPLICIT] — Logout Clears All Tokens
**Statement:** Given a logged-in user, When user clicks logout, Then all 4 localStorage keys (nexxus_access_token, nexxus_refresh_token, nexxus_token_expiry, nexxus_accessible_orgs) are cleared and user is redirected to /login.
**Source:** CARRY_FORWARD_MANIFEST.md, lines 125-129
**Testable:** YES (Playwright)
**Role(s):** All

### AUTH-008 [EXPLICIT] — Password Reset Flow
**Statement:** Given a user on the login page, When user clicks "Forgot Password" and enters email, Then a password reset email is sent and user can set a new password via the reset link.
**Source:** UNIFIED_HANDOFF_PROMPT.md, line 113 (POST /api/auth/forgot-password, POST /api/auth/reset-password)
**Testable:** YES (Playwright — up to form submission; email delivery is manual)
**Role(s):** All

### AUTH-009 [EXPLICIT] — 4-Tier RBAC Enforcement
**Statement:** Given the 4 RBAC roles (super_admin level 1, partner_admin level 2, org_admin level 3, org_staff level 4), When a user of any role accesses any page, Then only features/pages authorized for their role level are visible and accessible.
**Source:** MASTER_SRS.md, Section 3 (Permissions Matrix); CONSTITUTION.md, Role-Based Experience
**Testable:** YES (Playwright — test each role)
**Role(s):** All

### AUTH-010 [EXPLICIT] — Protected Route Guard
**Statement:** Given an unauthenticated user, When they attempt to access any protected route, Then they are redirected to /login.
**Source:** CARRY_FORWARD_MANIFEST.md, line 253 (ProtectedRoute.tsx)
**Testable:** YES (Playwright)
**Role(s):** All

---

## 2. Navigation & Layout (NAV)

### NAV-001 [EXPLICIT] — Sidebar Order
**Statement:** Given a logged-in user, When the sidebar is rendered, Then menu items appear in order: Main, Insights, Agents, Hub, Drive.
**Source:** ===DevDesign Notes===.md, line 129; — Acceptance Criteria.md, line ~35 (Navigation section)
**Testable:** YES (Playwright)
**Role(s):** All

### NAV-002 [EXPLICIT] — Sidebar Width 64px Collapsed
**Statement:** Given the sidebar in collapsed state, When measured, Then its width is 64px.
**Source:** ARCHITECTURE_GUIDE.md (3-pane layout); — Acceptance Criteria.md, line ~36
**Testable:** YES (Playwright)
**Role(s):** All

### NAV-003 [EXPLICIT] — 3-Pane Grid Layout
**Statement:** Given a desktop viewport (>1024px), When any page is loaded, Then the layout uses a 3-pane grid: sidebar (64px), left pane (240-400px), center pane (flexible), and optionally a right pane (320-500px).
**Source:** ARCHITECTURE_GUIDE.md (responsive breakpoints); — Acceptance Criteria.md, line ~38
**Testable:** YES (Playwright)
**Role(s):** All

### NAV-004 [EXPLICIT] — Settings Accessible as Submenu
**Statement:** Given a logged-in user with org_admin+ role, When Settings is clicked in the sidebar, Then it opens a settings page with tile-based navigation to 9 settings categories.
**Source:** DESIGNER_UPDATE_SPEC.md, Settings section; ===DevDesign Notes===.md, lines 207-220
**Testable:** YES (Playwright)
**Role(s):** org_admin, partner_admin, super_admin

### NAV-005 [EXPLICIT] — Staff Cannot See Settings
**Statement:** Given a user with org_staff role, When the sidebar renders, Then "Settings" is not visible.
**Source:** ===DevDesign Notes===.md, line 220
**Testable:** YES (Playwright)
**Role(s):** org_staff

### NAV-006 [EXPLICIT] — No Vendor Names in UI
**Statement:** Given any page in the application, When rendered, Then no third-party vendor names (VIN Solutions, VAPI, Tavus, TextMagic) appear in the user-visible interface.
**Source:** CONSTITUTION.md (Development Rules: UI Rules); MASTER_SRS.md, AC-002
**Testable:** YES (Playwright — text search)
**Role(s):** All

### NAV-007 [EXPLICIT] — No Source Labels in UI
**Statement:** Given any data display (leads, metrics, etc.), When rendered, Then no data source labels ("excel_upload", "vin_api", etc.) appear in the user-visible interface.
**Source:** CONSTITUTION.md (Development Rules: UI Rules); MASTER_SRS.md, AC-002
**Testable:** YES (Playwright — text search)
**Role(s):** All

### NAV-008 [EXPLICIT] — Logo Without Icon
**Statement:** Given the sidebar/header area, When the logo is rendered, Then the Nexxus logo appears WITHOUT the icon element.
**Source:** ===DevDesign Notes===.md, line 120
**Testable:** YES (Playwright)
**Role(s):** All

### NAV-009 [EXPLICIT] — Activity Feed in Header
**Statement:** Given the top navigation bar, When rendered, Then an activity feed icon/indicator shows lead activity for the current org.
**Source:** ===DevDesign Notes===.md, line 122
**Testable:** YES (Playwright)
**Role(s):** All

### NAV-010 [EXPLICIT] — Mobile Responsive (<768px)
**Statement:** Given a viewport width <768px, When the page loads, Then the sidebar collapses to a hamburger menu and the layout adapts to single-column.
**Source:** ARCHITECTURE_GUIDE.md (responsive breakpoints); — Acceptance Criteria.md, Section 10 (Mobile Responsive)
**Testable:** YES (Playwright — resize viewport)
**Role(s):** All

### NAV-011 [EXPLICIT] — Theme Toggle (Light/Dark)
**Statement:** Given the top navigation bar, When user clicks the theme toggle, Then the application switches between light and dark themes and persists the choice in localStorage.
**Source:** CARRY_FORWARD_MANIFEST.md (ThemeContext.tsx); — Acceptance Criteria.md, line ~42
**Testable:** YES (Playwright)
**Role(s):** All

### NAV-012 [EXPLICIT] — 5 Layout Types
**Statement:** Given the navigation structure, When different pages are loaded, Then they use the correct layout type: A (chat-only), B (info+chat), C (chat+info), D (settings), E (library).
**Source:** app_identity.md, Section B (navigation sections B1-B8)
**Testable:** YES (Playwright — check DOM structure per page)
**Role(s):** All

### NAV-013 [INFERRED] — Notifications Bell in Header
**Statement:** Given the top navigation bar, When rendered, Then a notifications bell icon displays unread count badge.
**Source:** UI_INTERACTIVE_ELEMENTS_MAP.md (TopBar: notifications); — Acceptance Criteria.md, Shell section
**Testable:** YES (Playwright)
**Role(s):** All

### NAV-014 [EXPLICIT] — Product Tour RBAC
**Statement:** Given a first-login user, When the product tour is triggered, Then it adapts its content based on the user's RBAC role.
**Source:** ===DevDesign Notes===.md, line 40 ("REACTIVATE THE TOUR AND SET IT UP WITH RBAC")
**Testable:** YES (Playwright — test per role)
**Role(s):** All

---

## 3. Automa Chat (CHAT)

### CHAT-001 [EXPLICIT] — Chat on Main Page
**Statement:** Given the Main page, When it loads, Then a chat interface (Automa) is present and ready to accept user input.
**Source:** ===DevDesign Notes===.md, lines 132-136; — Acceptance Criteria.md, Main Page section
**Testable:** YES (Playwright)
**Role(s):** All

### CHAT-002 [EXPLICIT] — Name is "Automa" (Not DealerBrain)
**Statement:** Given the chat interface anywhere in the UI, When rendered, Then the chat is labeled "Automa" and the name "DealerBrain" does NOT appear.
**Source:** ===DevDesign Notes===.md, line 127; CONSTITUTION.md (UI Rules: Skills not Tools)
**Testable:** YES (Playwright — text search)
**Role(s):** All

### CHAT-003 [EXPLICIT] — SSE Streaming with 6 Event Types
**Statement:** Given user sends a message in Automa chat, When the AI responds, Then the response streams via SSE with events: thinking, tool_start, tool_end, token, done, error.
**Source:** CARRY_FORWARD_MANIFEST.md, lines 106-117 (SSE Protocol); UNIFIED_HANDOFF_PROMPT.md, lines 175-176
**Testable:** YES (Playwright — observe streaming behavior)
**Role(s):** All

### CHAT-004 [EXPLICIT] — Thinking Animation is Wave Line
**Statement:** Given Automa is processing a request, When the "thinking" state is active, Then a flat line wave animation is shown (not dots or spinner).
**Source:** ===DevDesign Notes===.md, line 125
**Testable:** YES (Playwright — check animation element)
**Role(s):** All

### CHAT-005 [EXPLICIT] — Bot on Left, User on Right
**Statement:** Given a chat conversation, When messages render, Then bot messages appear on the left and user messages on the right, with no bot icon or initial icon needed.
**Source:** ===DevDesign Notes===.md, line 126
**Testable:** YES (Playwright — check alignment)
**Role(s):** All

### CHAT-006 [EXPLICIT] — Automa Replaces ChatGPT
**Statement:** Given a user asks a general question to Automa, When the question is about dealership operations, Then Automa provides answers using VIN Solutions data, VAPI metrics, and local data — functioning as a ChatGPT replacement for dealership context.
**Source:** — Acceptance Criteria.md, line 11 (Owner AC #9: "Automa functions as a ChatGPT replacement")
**Testable:** YES (manual — requires live Claude API)
**Role(s):** All

### CHAT-007 [EXPLICIT] — Per-Org System Context
**Statement:** Given Automa is responding, When the system prompt is constructed, Then it includes per-org contextual instructions configured in Settings.
**Source:** ===DevDesign Notes===.md, line 88; DESIGNER_UPDATE_SPEC.md, AI Configuration section
**Testable:** YES (manual — verify via API response behavior)
**Role(s):** org_admin, super_admin (config); All (experience)

### CHAT-008 [EXPLICIT] — Tool Calling Visibility
**Statement:** Given Automa calls a tool (e.g., VIN query), When the tool executes, Then the user sees a tool_start indicator, followed by tool_end with success/failure summary.
**Source:** CARRY_FORWARD_MANIFEST.md, lines 110-115 (event types)
**Testable:** YES (Playwright — check UI elements during streaming)
**Role(s):** All

### CHAT-009 [EXPLICIT] — Chart Rendering in Chat
**Statement:** Given Automa returns chart data via tool_end event, When chartData is present, Then an inline chart (bar/line/pie) renders within the chat conversation.
**Source:** CARRY_FORWARD_MANIFEST.md, line 115 (tool_end: chartData?); UNIFIED_HANDOFF_PROMPT.md, line 268 (ChatChart.tsx)
**Testable:** YES (Playwright — check chart rendering)
**Role(s):** All

### CHAT-010 [EXPLICIT] — VIN Query Limitations Disclosed
**Statement:** Given Automa is asked about data from VIN Solutions, When the query hits a VIN API limitation, Then Automa clearly discloses which queries are limited because of VIN Solutions access.
**Source:** ===DevDesign Notes===.md, line 36
**Testable:** YES (manual — requires live Claude API)
**Role(s):** All

### CHAT-011 [EXPLICIT] — Multi-Turn Conversations
**Statement:** Given a user has an active conversation with Automa, When user sends follow-up messages, Then Automa maintains context across the conversation and responds coherently.
**Source:** — Acceptance Criteria.md, line 10 (Owner AC #8: "Multi-turn conversations")
**Testable:** YES (manual — requires live Claude API)
**Role(s):** All

### CHAT-012 [INFERRED] — Send SMS/Email from Chat
**Statement:** Given a user is in Automa chat, When user requests to send an SMS or email, Then Automa can compose and send via TextMagic (SMS) or Resend (email) after user approval.
**Source:** ===DevDesign Notes===.md, lines 79-81; app_identity.md, Communication model
**Testable:** YES (manual — live integration)
**Role(s):** All

### CHAT-013 [INFERRED] — Attach Artifact from Drive
**Statement:** Given a user is in Automa chat, When user requests to attach a file, Then user can select from Drive or upload to include in the message.
**Source:** ===DevDesign Notes===.md, line 81
**Testable:** YES (Playwright — UI flow)
**Role(s):** All

---

## 4. Insights (INSIGHTS)

### INSIGHTS-001 [EXPLICIT] — 3-Zone Command Center
**Statement:** Given the Insights > Dashboard > Command Center page, When rendered, Then 3 alert zones display: Red (immediate action), Yellow (watch list), Green (performance tracking).
**Source:** —Insights Layout.md, lines 1-50; ===DevDesign Notes===.md, lines 52-64
**Testable:** YES (Playwright)
**Role(s):** org_admin, partner_admin, super_admin

### INSIGHTS-002 [EXPLICIT] — Dashboard Sub-Navigation
**Statement:** Given the Insights page, When the sub-navigation renders, Then it shows: Dashboard (Command Center, Pipeline Health, Performance Scorecard) and Reports (Loss & Quality Analysis, Channel Intelligence, Trend & Forecast Reports).
**Source:** ===DevDesign Notes===.md, lines 52-64, 163-176; —Insights Layout.md
**Testable:** YES (Playwright)
**Role(s):** org_admin, partner_admin, super_admin

### INSIGHTS-003 [EXPLICIT] — Hunches Sub-Tab
**Statement:** Given the Insights page, When sub-navigation renders, Then a "Hunches" sub-tab is available showing AI-generated insights.
**Source:** ===DevDesign Notes===.md, lines 65, 178
**Testable:** YES (Playwright)
**Role(s):** org_admin, partner_admin, super_admin

### INSIGHTS-004 [EXPLICIT] — Goals Removed
**Statement:** Given the Insights page, When sub-navigation renders, Then there is NO "Goals" sub-tab (it has been removed).
**Source:** ===DevDesign Notes===.md, lines 66, 179
**Testable:** YES (Playwright — verify absence)
**Role(s):** All

### INSIGHTS-005 [EXPLICIT] — Activity Moved to Insights Sub-Tab
**Statement:** Given the Insights page, When rendered, Then Activity feed appears as a sub-tab within Insights (not a standalone sidebar page).
**Source:** ===DevDesign Notes===.md, line 128
**Testable:** YES (Playwright)
**Role(s):** All

### INSIGHTS-006 [EXPLICIT] — 6 Priority Reports
**Statement:** Given the Reports section, When rendered, Then 6 reports are available: Deal Death Autopsy, Lead Source Quality, Channel Performance, Pipeline Velocity, Active Lead Triage, Deal Status Snapshot.
**Source:** —Reports.md, full document (6 reports)
**Testable:** YES (Playwright — verify report cards/tiles)
**Role(s):** org_admin, partner_admin, super_admin

### INSIGHTS-007 [EXPLICIT] — Grid/Tile View Toggle
**Statement:** Given any Insights section with data cards, When a view toggle exists, Then user can switch between grid and tile views.
**Source:** ===DevDesign Notes===.md, line 181
**Testable:** YES (Playwright)
**Role(s):** All

### INSIGHTS-008 [EXPLICIT] — VAPI Voice Metrics Display
**Statement:** Given the Insights voice section, When data loads, Then voice call metrics (total calls, avg duration, calls by status) display from /api/insights/voice-calls.
**Source:** — Acceptance Criteria.md, line 5 (Owner AC #3: "VAPI and Tavus data on insights"); MASTER_SRS.md, Section 8
**Testable:** YES (Playwright)
**Role(s):** org_admin, partner_admin, super_admin

### INSIGHTS-009 [EXPLICIT] — Tavus Video Metrics Display
**Statement:** Given the Insights video section, When data loads, Then video session metrics display from /api/insights/video-sessions.
**Source:** — Acceptance Criteria.md, line 5 (Owner AC #4); MASTER_SRS.md, Section 8
**Testable:** YES (Playwright)
**Role(s):** org_admin, partner_admin, super_admin

### INSIGHTS-010 [EXPLICIT] — Data Accuracy Mandate
**Statement:** Given any metric or data point displayed on Insights, When compared to the ground truth data source, Then the displayed value must be within 2% of the actual value.
**Source:** CLARIFICATION_ANSWERS.md ("We cannot have data that is wrong"); MASTER_SRS.md, AC-007 (Certified Metrics)
**Testable:** YES (manual — cross-reference with VIN API)
**Role(s):** All

### INSIGHTS-011 [EXPLICIT] — Excel Upload Records Excluded
**Statement:** Given any lead count or metric calculation, When data is aggregated, Then records with source='excel_upload' are excluded from all totals.
**Source:** UNIFIED_HANDOFF_PROMPT.md, Lesson 5 (Excel Upload Record Pollution); MASTER_SRS.md, Phase 1 fixes
**Testable:** YES (Playwright/API — compare with and without filter)
**Role(s):** All

### INSIGHTS-012 [EXPLICIT] — Null Guard Safety
**Statement:** Given Insights page components, When data contains null/undefined percentage values, Then the UI does not crash (null guards on .pct accesses).
**Source:** known_issues.md.md, line 8 (Confirmed P0 #2: "4 unsafe .pct accesses without null guards")
**Testable:** YES (Playwright — load with empty data)
**Role(s):** All

### INSIGHTS-013 [EXPLICIT] — Hunch Lifecycle Management
**Statement:** Given a Hunch item, When displayed, Then it shows status (New, Under Investigation, Test, Validated, Implemented, Monitoring) and actionable recommendations.
**Source:** —Hunches.md, full document (hunch lifecycle)
**Testable:** YES (Playwright)
**Role(s):** org_admin, partner_admin, super_admin

### INSIGHTS-014 [EXPLICIT] — Drill-Down from Metrics to Detail
**Statement:** Given a dashboard metric tile, When user clicks on it, Then a drill-down view with detailed data and the underlying records appears.
**Source:** — Acceptance Criteria.md, line 4 (Owner AC #2: "drill down to detailed data")
**Testable:** YES (Playwright)
**Role(s):** org_admin, partner_admin, super_admin

---

## 5. Agents (AGENTS)

### AGENTS-001 [EXPLICIT] — Agent List Page
**Statement:** Given a user navigates to the Agents page, When the page loads, Then a list of configured agents for the current org is displayed.
**Source:** — Acceptance Criteria.md, Agents section; UI_INTERACTIVE_ELEMENTS_MAP.md (Agents Page)
**Testable:** YES (Playwright)
**Role(s):** All

### AGENTS-002 [EXPLICIT] — Automa NOT on Agents Page
**Statement:** Given the Agents page, When rendered, Then Automa/DealerBrain does NOT appear as a listed agent (it is accessed via Main page chat only).
**Source:** ===DevDesign Notes===.md, line 187
**Testable:** YES (Playwright — verify absence)
**Role(s):** All

### AGENTS-003 [EXPLICIT] — New Agent Creation Wizard
**Statement:** Given user clicks "New Agent" button, When the creation flow opens, Then a center page shows dialogue input at center and tool tiles below, where clicking tiles opens a modal describing what each tool does.
**Source:** ===DevDesign Notes===.md, line 185
**Testable:** YES (Playwright)
**Role(s):** org_admin, super_admin

### AGENTS-004 [EXPLICIT] — Agent Right Pane Config
**Statement:** Given user clicks on an agent, When the right pane opens, Then it shows: agent configuration, activity log, triggers, prompt, and knowledge sections.
**Source:** ===DevDesign Notes===.md, lines 186-190
**Testable:** YES (Playwright)
**Role(s):** All

### AGENTS-005 [EXPLICIT] — Communications Agent Static Config
**Statement:** Given a Communications Agent (e.g., "Caroline"), When viewed, Then it is configured by Super Admin only and is available out of the box, not user-editable.
**Source:** ===DevDesign Notes===.md, lines 72-75
**Testable:** YES (Playwright — test with org_staff, verify read-only)
**Role(s):** super_admin (config), All (view)

### AGENTS-006 [EXPLICIT] — Agent Name Consistency
**Statement:** Given a named agent (e.g., "Caroline"), When that agent's name appears in Tavus video, VAPI voice, and internal UI, Then the same name is used consistently across all surfaces.
**Source:** — Acceptance Criteria.md, line 9 (Owner AC #7: "Agent names consistent"); ===DevDesign Notes===.md, lines 75-76
**Testable:** YES (Playwright — check UI labels match config)
**Role(s):** All

### AGENTS-007 [EXPLICIT] — Agent Instructions Editable in Settings
**Statement:** Given the Settings page for an agent or globally, When user navigates to agent instructions, Then they can modify the agent's prompt/instructions.
**Source:** — Acceptance Criteria.md, line 15 (Owner AC #13: "change agent instructions in settings")
**Testable:** YES (Playwright)
**Role(s):** org_admin, super_admin

### AGENTS-008 [EXPLICIT] — Right Pane Shows Agent Links
**Statement:** Given an agent's right pane, When opened, Then it shows: the customer-facing link (same URL customer would use), the phone number, and the text chat link.
**Source:** ===DevDesign Notes===.md, lines 83-86
**Testable:** YES (Playwright)
**Role(s):** All

### AGENTS-009 [EXPLICIT] — Skills Architecture (V2 Model)
**Statement:** Given agent creation, When skills are assigned, Then users select from a catalog of pre-built skills (74 from V1) that provide context/pre-prompting, not hardcoded agent types.
**Source:** session-knowledge.md, Section 2 (Skills Architecture); DESIGNER_UPDATE_SPEC.md, Skills Catalog
**Testable:** YES (Playwright — verify skills selection UI)
**Role(s):** org_admin, super_admin

### AGENTS-010 [EXPLICIT] — Skills Tab Super Admin Only with Kill Switch
**Statement:** Given the AI Configuration > Skills tab, When accessed, Then only Super Admin can see it, and it includes an emergency kill switch.
**Source:** DESIGNER_UPDATE_SPEC.md, AI Configuration section
**Testable:** YES (Playwright — verify RBAC)
**Role(s):** super_admin

### AGENTS-011 [INFERRED] — Agent CRUD Operations
**Statement:** Given the Agents page, When user performs CRUD operations, Then agents can be created, read, updated, deleted, duplicated, and status-toggled via /api/agents/*.
**Source:** CARRY_FORWARD_MANIFEST.md (useAgents hooks); DO_NOT_TOUCH.md, line 57-58
**Testable:** YES (Playwright)
**Role(s):** org_admin, super_admin (CUD), All (R)

---

## 6. Hub-Calendar (HUBCAL)

### HUBCAL-001 [EXPLICIT] — Hub Has Exactly 3 Tabs
**Statement:** Given the Hub page, When it loads, Then exactly 3 tabs are shown: Calendar, Leads, Inbox.
**Source:** session-knowledge.md, Section 4 (Watch Area correction: Hub = 3 tabs); ===DevDesign Notes===.md, lines 192-198
**Testable:** YES (Playwright)
**Role(s):** All

### HUBCAL-002 [EXPLICIT] — Calendar View
**Statement:** Given the Hub > Calendar tab, When loaded, Then a calendar view displays appointments and events for the current user (staff) or all users (org_admin).
**Source:** ===DevDesign Notes===.md, line 195; UI_INTERACTIVE_ELEMENTS_MAP.md (Calendar hooks)
**Testable:** YES (Playwright)
**Role(s):** All

### HUBCAL-003 [EXPLICIT] — Appointment CRUD
**Statement:** Given the Calendar tab, When user creates/edits/deletes an appointment, Then the appointment is persisted via /api/appointments/* endpoints.
**Source:** CARRY_FORWARD_MANIFEST.md (useAppointments hooks); DO_NOT_TOUCH.md, line 58-59
**Testable:** YES (Playwright)
**Role(s):** All

### HUBCAL-004 [EXPLICIT] — Appointment Confirmation SMS
**Statement:** Given an appointment is created, When the appointment is confirmed, Then an SMS is sent to the customer via TextMagic with appointment details.
**Source:** Nexxus_SRS_Addendum_v3.2_Widget_SMS_Notifications.md, REQ-SMS-002 (lines 404-412)
**Testable:** YES (manual — live SMS)
**Role(s):** All (triggered by system)

### HUBCAL-005 [EXPLICIT] — Appointment Status Notifications
**Statement:** Given an appointment is updated, When updateAppointment() is called, Then appropriate notification events fire.
**Source:** known_issues.md.md, line 11 (Confirmed P0 #3: "updateAppointment() fires zero events")
**Testable:** YES (Playwright/API — verify events emitted)
**Role(s):** All

### HUBCAL-006 [EXPLICIT] — Hub Activity Filtered by User
**Statement:** Given the Hub page, When staff views it, Then they see only their own activity. When org_admin views it, Then they see all users' activity with a color-coded key mapped to users.
**Source:** ===DevDesign Notes===.md, lines 92-93
**Testable:** YES (Playwright — test both roles)
**Role(s):** org_staff, org_admin

### HUBCAL-007 [EXPLICIT] — Org Admin Filter by User
**Statement:** Given an org_admin or partner_admin on Hub, When viewing activities, Then they can filter by a specific user or choose to see only their own data.
**Source:** ===DevDesign Notes===.md, lines 93-94
**Testable:** YES (Playwright)
**Role(s):** org_admin, partner_admin

### HUBCAL-008 [INFERRED] — Google Calendar Integration
**Statement:** Given a user connects Google Calendar in settings, When appointments are created in Nexxus, Then they can optionally push to Google Calendar.
**Source:** CARRY_FORWARD_MANIFEST.md (useGoogleCalendar hooks); DO_NOT_TOUCH.md, line 69
**Testable:** YES (manual — requires Google OAuth)
**Role(s):** All

---

## 7. Hub-Leads (HUBLEAD)

### HUBLEAD-001 [EXPLICIT] — Leads List View
**Statement:** Given the Hub > Leads tab, When loaded, Then a list of leads displays with text button, call button, and schedule button per lead.
**Source:** ===DevDesign Notes===.md, line 196
**Testable:** YES (Playwright)
**Role(s):** All

### HUBLEAD-002 [EXPLICIT] — Lead Follow-Up Trigger
**Statement:** Given a new lead enters the system, When trigger conditions are met (lead age > 2h, no contact), Then a proactive outbound call or SMS is triggered.
**Source:** — Acceptance Criteria.md, line 12 (Owner AC #10: "Lead follow-up trigger"); MASTER_SRS.md, AC-013
**Testable:** YES (manual — requires live triggers enabled)
**Role(s):** System-triggered

### HUBLEAD-003 [EXPLICIT] — Lead Insertion to VIN Solutions
**Statement:** Given a lead is captured from VAPI voice or Tavus video, When the webhook processes it, Then the lead is queued in sync_queue and synced to VIN Solutions CRM.
**Source:** — Acceptance Criteria.md, line 7 (Owner AC #3 in MASTER AC: "Lead Insertion to VIN"); MASTER_SRS.md, AC-004
**Testable:** YES (manual — live integration)
**Role(s):** System-triggered

### HUBLEAD-004 [EXPLICIT] — Mark Lead as Contacted
**Statement:** Given a lead in the leads list, When user clicks "Mark Contacted", Then the lead's contacted status updates via PATCH /api/leads/:id/mark-contacted.
**Source:** CARRY_FORWARD_MANIFEST.md (useMarkLeadContacted hook)
**Testable:** YES (Playwright)
**Role(s):** All

### HUBLEAD-005 [EXPLICIT] — Lead Status Update
**Statement:** Given a lead, When user changes its status, Then the status updates via PUT /api/leads/:id/status.
**Source:** CARRY_FORWARD_MANIFEST.md (useUpdateLeadStatus)
**Testable:** YES (Playwright)
**Role(s):** All

### HUBLEAD-006 [EXPLICIT] — VIN-Sourced Lead Data Accuracy
**Statement:** Given leads displayed from VIN Solutions, When data is shown, Then fields (name, phone, email, source, status) match the VIN Solutions API response exactly.
**Source:** MASTER_SRS.md, AC-005 (Data Field Population Audit); CLARIFICATION_ANSWERS.md (data accuracy mandate)
**Testable:** YES (manual — cross-reference VIN API)
**Role(s):** All

---

## 8. Hub-Inbox (HUBINBOX)

### HUBINBOX-001 [EXPLICIT] — Unified Messaging Inbox
**Statement:** Given the Hub > Inbox tab, When loaded, Then a unified inbox shows all communication threads: widget chats, SMS, and callbacks.
**Source:** Nexxus_SRS_Addendum_v3.2_Widget_SMS_Notifications.md, REQ-STAFF-MSG-001 (lines 511-536)
**Testable:** YES (Playwright)
**Role(s):** All

### HUBINBOX-002 [EXPLICIT] — Two-Way Text Messaging
**Statement:** Given a conversation thread with a customer, When staff types and sends a message, Then the message is delivered via TextMagic SMS and the customer's reply appears in the inbox.
**Source:** — Acceptance Criteria.md, line 8 (Owner AC #6: "Two-way text messaging functional")
**Testable:** YES (manual — live SMS)
**Role(s):** All

### HUBINBOX-003 [EXPLICIT] — New Message Modal (SMS/Email)
**Statement:** Given the Hub page, When user clicks "New Message" quick action, Then a modal opens with SMS and Email options.
**Source:** ===DevDesign Notes===.md, line 194
**Testable:** YES (Playwright)
**Role(s):** All

### HUBINBOX-004 [EXPLICIT] — Conversation Assignment
**Statement:** Given an inbox conversation, When an admin assigns it to a staff member, Then the conversation moves to that staff member's view.
**Source:** CARRY_FORWARD_MANIFEST.md (useAssignConversation hook); Nexxus_SRS_Addendum_v3.2, REQ-STAFF-MSG-001
**Testable:** YES (Playwright)
**Role(s):** org_admin (assign), org_staff (view)

### HUBINBOX-005 [EXPLICIT] — Conversation Status Tracking
**Statement:** Given an inbox conversation, When status is changed (open, in_progress, closed), Then the status persists and filters work correctly.
**Source:** CARRY_FORWARD_MANIFEST.md (useUpdateConversationStatus); Nexxus_SRS_Addendum_v3.2
**Testable:** YES (Playwright)
**Role(s):** All

### HUBINBOX-006 [EXPLICIT] — Unread Count Badge
**Statement:** Given unread inbox messages exist, When the Hub > Inbox tab is visible, Then an unread count badge displays the correct number.
**Source:** CARRY_FORWARD_MANIFEST.md (useInboxUnreadCount hook)
**Testable:** YES (Playwright)
**Role(s):** All

### HUBINBOX-007 [EXPLICIT] — Staff Can Send SMS from Inbox
**Statement:** Given a staff user in the inbox, When they compose and send a text message, Then it is delivered via TextMagic API.
**Source:** Nexxus_SRS_Addendum_v3.2_Widget_SMS_Notifications.md, REQ-STAFF-MSG-002 (line 573)
**Testable:** YES (manual — live SMS)
**Role(s):** All

### HUBINBOX-008 [INFERRED] — External Agent Conversations Continued by Staff
**Statement:** Given a customer conversation started with an AI agent (VAPI/Tavus/widget), When the conversation is handed to staff, Then the staff member can continue it in the inbox with full conversation history.
**Source:** session-knowledge.md, Section 4a (Watch Area: unified inbox definition)
**Testable:** YES (Playwright — verify conversation continuity)
**Role(s):** All

---

## 9. Widgets (WIDGET)

### WIDGET-001 [EXPLICIT] — Master Widget with 6 Options
**Statement:** Given a widget is embedded on a dealership website, When a customer clicks it, Then 6 communication options are available: Text Chat, Web Video Agent, Call Us, Call You, Web Audio, Send a Text.
**Source:** Nexxus_SRS_Addendum_v3.2_Widget_SMS_Notifications.md, REQ-WIDGET-001 (lines 173-183)
**Testable:** YES (Playwright — embed test)
**Role(s):** External (customer-facing)

### WIDGET-002 [EXPLICIT] — Widget Configuration UI in Settings
**Statement:** Given the Settings > Tools & Integrations > Widgets tab, When accessed, Then a widget configuration UI shows appearance, channels, targeting, and embed code sections.
**Source:** Nexxus_SRS_Addendum_v3.2_Widget_SMS_Notifications.md, REQ-WIDGET-CONFIG-UI-001 (lines 114-169)
**Testable:** YES (Playwright)
**Role(s):** org_admin, super_admin

### WIDGET-003 [EXPLICIT] — Hosted Widget Pages
**Statement:** Given a widget configuration, When hosted pages are enabled, Then standalone pages are accessible at URLs like /hosted/{orgSlug}/{widgetCode}/[chat|video|callback].
**Source:** Nexxus_SRS_Addendum_v3.2_Widget_SMS_Notifications.md, REQ-HOSTED-001 (lines 491-503)
**Testable:** YES (Playwright)
**Role(s):** External (public access)

### WIDGET-004 [EXPLICIT] — Hosted Pages Route Match
**Statement:** Given a hosted page URL, When accessed, Then the client route and server route match (/api/pages/:slug serves the correct content).
**Source:** known_issues.md.md, line 9 (Confirmed P0 #1: "client fetches /api/hosted-pages/public/:slug, server serves /api/pages/:slug")
**Testable:** YES (Playwright — HTTP request verification)
**Role(s):** External

### WIDGET-005 [EXPLICIT] — Widget Demo Shows Working Widget
**Statement:** Given a configured widget for a demo org, When the hosted page URL is loaded, Then the widget loads within 1.5 seconds and all enabled channels are functional.
**Source:** — Acceptance Criteria.md, line 7 (Owner AC #5: "Hosted page widget demo")
**Testable:** YES (Playwright)
**Role(s):** External

### WIDGET-006 [EXPLICIT] — Domain Restrictions
**Statement:** Given a widget configuration with allowed_domains set, When the widget is loaded from an unauthorized domain, Then it does not render.
**Source:** Nexxus_SRS_Addendum_v3.2_Widget_SMS_Notifications.md, Security section (lines 694-695)
**Testable:** YES (Playwright — test from different origins)
**Role(s):** External

### WIDGET-007 [EXPLICIT] — Widget Load Time <1.5s
**Statement:** Given a widget embed on a page, When the page loads, Then the widget is interactive within 1.5 seconds.
**Source:** MASTER_SRS.md, Section 11 (Non-functional: widget load <1.5s)
**Testable:** YES (Playwright — performance measurement)
**Role(s):** External

---

## 10. Triggers (TRIGGER)

### TRIGGER-001 [EXPLICIT] — Automatic Outbound Call Triggering
**Statement:** Given a trigger rule is configured and enabled, When trigger conditions are met (new lead, hot lead, missed call), Then the system initiates an outbound VAPI call automatically.
**Source:** — Acceptance Criteria.md, line 3 (Owner AC #1); MASTER_SRS.md, AC-001 (renamed: originally about VIN headers, but AC-013 covers triggers)
**Testable:** YES (manual — live VAPI integration)
**Role(s):** System-triggered

### TRIGGER-002 [EXPLICIT] — Trigger CRUD
**Statement:** Given the Triggers management UI, When user creates/edits/deletes trigger rules, Then they persist via /api/triggers/* endpoints.
**Source:** CARRY_FORWARD_MANIFEST.md (useTriggers hooks); DO_NOT_TOUCH.md, line 84
**Testable:** YES (Playwright)
**Role(s):** org_admin, super_admin

### TRIGGER-003 [EXPLICIT] — Trigger Deduplication
**Statement:** Given multiple trigger conditions fire for the same lead within a time window, When processing occurs, Then only one action executes (dedup via 2 mechanisms in code).
**Source:** session-knowledge.md (undocumented: trigger dedup confirmed by owner); known_issues.md.md, category A3
**Testable:** YES (manual — requires live trigger fire)
**Role(s):** System-triggered

### TRIGGER-004 [EXPLICIT] — Business Hours Enforcement
**Statement:** Given a trigger rule with business_hours_only=true, When conditions fire outside business hours, Then the action is deferred until next business hours window.
**Source:** Nexxus_SRS_Addendum_v3.2_Widget_SMS_Notifications.md, REQ-TRIGGER-001 (line 608: business_hours_only)
**Testable:** YES (manual — time-based)
**Role(s):** System-triggered

### TRIGGER-005 [EXPLICIT] — Global Enable/Disable (Super Admin)
**Statement:** Given the trigger system, When Super Admin toggles the global enable flag, Then all triggers across all orgs are enabled or disabled.
**Source:** Nexxus_SRS_Addendum_v3.2_Widget_SMS_Notifications.md, REQ-TRIGGER-001 (line 606: global_enabled)
**Testable:** YES (Playwright — test toggle via admin settings)
**Role(s):** super_admin

### TRIGGER-006 [EXPLICIT] — Trigger Notification <60s
**Statement:** Given a trigger fires successfully, When a notification is generated, Then it is delivered within 60 seconds of the trigger event.
**Source:** MASTER_SRS.md, Section 11 (Non-functional: trigger notification <60s)
**Testable:** YES (manual — timer measurement)
**Role(s):** System-triggered

### TRIGGER-007 [EXPLICIT] — All 15 Existing Triggers Currently Deactivated
**Statement:** Given the current production state, When triggers are audited, Then all 15 existing trigger rules are deactivated (status=inactive).
**Source:** REVERSE_SRS_old.md, line 37 ("all 15 trigger rules are currently deactivated")
**Testable:** YES (API — query /api/triggers and verify status)
**Role(s):** super_admin

---

## 11. Drive (DRIVE)

### DRIVE-001 [EXPLICIT] — File Management CRUD
**Statement:** Given the Drive page, When user creates folders, uploads files, renames items, or deletes items, Then operations persist via /api/drive/* endpoints.
**Source:** CARRY_FORWARD_MANIFEST.md (useDrive hooks); ===DevDesign Notes===.md, lines 95-99
**Testable:** YES (Playwright)
**Role(s):** All

### DRIVE-002 [EXPLICIT] — Share via Email or SMS
**Statement:** Given a file in Drive, When user clicks a share button, Then they can send the file via email or SMS.
**Source:** ===DevDesign Notes===.md, lines 98, 201-203
**Testable:** YES (Playwright — UI flow; manual for actual delivery)
**Role(s):** All

### DRIVE-003 [INFERRED] — Storage Usage Display
**Statement:** Given the Drive page, When loaded, Then current storage usage is displayed for the organization.
**Source:** CARRY_FORWARD_MANIFEST.md (DriveItem, StorageUsage types in useDrive)
**Testable:** YES (Playwright)
**Role(s):** org_admin, super_admin

---

## 12. Settings (SETTINGS)

### SETTINGS-001 [EXPLICIT] — 9 Settings Tiles
**Statement:** Given the Settings page, When loaded, Then 9 tile-based categories are displayed (API & Webhooks was moved inside Tools & Integrations, reducing from 10).
**Source:** DESIGNER_UPDATE_SPEC.md, Settings section; ===DevDesign Notes===.md, lines 207-219
**Testable:** YES (Playwright — count tiles)
**Role(s):** org_admin, partner_admin, super_admin

### SETTINGS-002 [EXPLICIT] — RBAC Visibility on Settings Tiles
**Statement:** Given the Settings tiles, When rendered per role, Then: Super Admin sees all 9; Partner Admin sees org-level subset; Org Admin sees Account, Users, Knowledge, Instructions, Billing; Staff sees none.
**Source:** DESIGNER_UPDATE_SPEC.md, RBAC visibility matrix; ===DevDesign Notes===.md, lines 215-220
**Testable:** YES (Playwright — test each role)
**Role(s):** All

### SETTINGS-003 [EXPLICIT] — Tools & Integrations: 5 Tabs
**Statement:** Given Settings > Tools & Integrations, When opened, Then 5 tabs display: MCP, API, Other, Widgets, Landing Pages. Super Admin sees 2 additional tabs: API Keys, Webhooks.
**Source:** DESIGNER_UPDATE_SPEC.md, Tools & Integrations section
**Testable:** YES (Playwright)
**Role(s):** org_admin, super_admin

### SETTINGS-004 [EXPLICIT] — AI Configuration: 4 Tabs
**Statement:** Given Settings > AI Configuration, When opened, Then 4 tabs display: System Prompt, Agent Behavior, Skills, Hunches.
**Source:** DESIGNER_UPDATE_SPEC.md, AI Configuration section
**Testable:** YES (Playwright)
**Role(s):** super_admin

### SETTINGS-005 [EXPLICIT] — Knowledge Base: 4 Tabs
**Statement:** Given Settings > Knowledge, When opened, Then 4 tabs display: Documents, Web Pages, Databases, Settings.
**Source:** DESIGNER_UPDATE_SPEC.md, Knowledge Base section
**Testable:** YES (Playwright)
**Role(s):** org_admin, super_admin

### SETTINGS-006 [EXPLICIT] — Billing Page (New)
**Statement:** Given Settings > Billing, When opened, Then subscription tiers, usage meters, and invoice information are displayed.
**Source:** DESIGNER_UPDATE_SPEC.md, Billing section
**Testable:** YES (Playwright)
**Role(s):** org_admin, super_admin

### SETTINGS-007 [EXPLICIT] — Users CRUD
**Statement:** Given Settings > Users, When an org_admin accesses it, Then full CRUD for adding/removing users within the current org is available.
**Source:** ===DevDesign Notes===.md, line 216; CARRY_FORWARD_MANIFEST.md (useAdmin hooks)
**Testable:** YES (Playwright)
**Role(s):** org_admin, partner_admin, super_admin

### SETTINGS-008 [EXPLICIT] — Org Creation Wizard (Super Admin)
**Statement:** Given Super Admin access, When user initiates org creation, Then a wizard guides through organization setup.
**Source:** DESIGNER_UPDATE_SPEC.md, Org Creation Wizard section
**Testable:** YES (Playwright)
**Role(s):** super_admin

### SETTINGS-009 [EXPLICIT] — Economy/Billing Rate on Tool Cards
**Statement:** Given Settings > Tools & Integrations, When tool cards are displayed, Then each card shows an "Economy" section for billing rate configuration.
**Source:** DESIGNER_UPDATE_SPEC.md, Economy section
**Testable:** YES (Playwright)
**Role(s):** super_admin

### SETTINGS-010 [EXPLICIT] — Data Management: 2 Tabs
**Statement:** Given Settings > Data Management, When opened, Then 2 tabs display: Database Uploads and Data Health.
**Source:** DESIGNER_UPDATE_SPEC.md, Data Management section
**Testable:** YES (Playwright)
**Role(s):** org_admin, super_admin

---

## 13. Metrics (METRICS)

### METRICS-001 [EXPLICIT] — Main Page: 4 Org Admin Tiles
**Statement:** Given an org_admin on the Main page, When the top metrics section renders, Then 4 tiles show: Pipeline Health (0-100), Lead Source Performance (0-100), Lead Quality (0-100), Market Demand Insight (0-100).
**Source:** —Org admin Metrics - Main - org admin.md, full document; ===DevDesign Notes===.md, lines 147-152
**Testable:** YES (Playwright)
**Role(s):** org_admin

### METRICS-002 [EXPLICIT] — Main Page: 4 Staff Tiles
**Statement:** Given a staff user on the Main page, When the top metrics section renders, Then 4 tiles show: Hot Opportunities, Buying Intelligence, Competitive Threats, Pipeline Urgency.
**Source:** —Staff Metrics.md, full document; ===DevDesign Notes===.md, lines 154-159
**Testable:** YES (Playwright)
**Role(s):** org_staff

### METRICS-003 [EXPLICIT] — Main Page: 4 Partner Admin Tiles
**Statement:** Given a partner_admin on the Main page, When the top metrics section renders, Then 4 system-based tiles show: # sub-orgs, # customer logins (24h), # actions taken (24h), # agent actions (24h).
**Source:** ===DevDesign Notes===.md, lines 138-144
**Testable:** YES (Playwright)
**Role(s):** partner_admin

### METRICS-004 [EXPLICIT] — Pipeline Health Score Formula
**Statement:** Given the Pipeline Health tile, When calculated, Then it uses: (0.3 * lead_volume_trend) + (0.25 * conversion_rate) + (0.25 * avg_response_time_score) + (0.2 * pipeline_stage_distribution_score), scaled 0-100.
**Source:** —Org admin Metrics - Main - org admin.md, Pipeline Health section
**Testable:** YES (manual — verify calculation against raw data)
**Role(s):** org_admin

### METRICS-005 [EXPLICIT] — Certified Metrics Registry
**Statement:** Given the /api/metrics/registry endpoint, When queried, Then it returns all certified metrics with role-based filtering and data source attribution.
**Source:** MASTER_SRS.md, AC-007 (Certified Metrics); CARRY_FORWARD_MANIFEST.md (useMetrics hook)
**Testable:** YES (API test)
**Role(s):** All

### METRICS-006 [EXPLICIT] — Metrics Accuracy Within 2%
**Statement:** Given any certified metric, When compared to ground truth, Then the displayed value is within 2% of the actual value.
**Source:** MASTER_SRS.md, AC-007; CLARIFICATION_ANSWERS.md (data accuracy mandate)
**Testable:** YES (manual — cross-reference)
**Role(s):** All

### METRICS-007 [EXPLICIT] — Field Fill Rate >50%
**Statement:** Given metrics certification, When field population is audited, Then >50% of data fields are populated for all certified metrics.
**Source:** MASTER_SRS.md, AC-005 (Data Field Population Audit)
**Testable:** YES (API — field population audit)
**Role(s):** All

### METRICS-008 [EXPLICIT] — Modal Drill-Down for Staff Tiles
**Statement:** Given a staff metric tile (Hot Opportunities, Buying Intelligence, etc.), When user clicks it, Then a modal opens with the detailed breakdown as specified in the metrics formulas.
**Source:** —Staff Metrics.md (each tile has "Modal When Clicked" specification)
**Testable:** YES (Playwright)
**Role(s):** org_staff

---

## 14. Notifications (NOTIF)

### NOTIF-001 [EXPLICIT] — In-App Notification List
**Statement:** Given a logged-in user, When they click the notification bell, Then a list of notifications displays with read/unread status.
**Source:** CARRY_FORWARD_MANIFEST.md (useNotifications hooks); UI_INTERACTIVE_ELEMENTS_MAP.md (TopBar)
**Testable:** YES (Playwright)
**Role(s):** All

### NOTIF-002 [EXPLICIT] — Notifications from Hunches
**Statement:** Given the notification system, When a new Hunch is generated, Then a notification is created and visible in the notification bell.
**Source:** ===DevDesign Notes===.md, line 123 ("Notifications should come from Hunches")
**Testable:** YES (Playwright — verify notification exists after hunch generation)
**Role(s):** org_admin, partner_admin, super_admin

### NOTIF-003 [EXPLICIT] — Notification Settings CRUD
**Statement:** Given the notification preferences UI, When user toggles notification types on/off, Then preferences persist via /api/notifications/settings endpoints.
**Source:** CARRY_FORWARD_MANIFEST.md (useNotificationSettings, useBulkUpdateNotificationSettings)
**Testable:** YES (Playwright)
**Role(s):** All

### NOTIF-004 [EXPLICIT] — Unread Count Polling
**Statement:** Given unread notifications exist, When the user is logged in, Then the unread count badge updates via polling (30s interval).
**Source:** CARRY_FORWARD_MANIFEST.md (useUnreadNotificationCount, polling: 30s); UNIFIED_HANDOFF_PROMPT.md, line 245
**Testable:** YES (Playwright — observe badge update)
**Role(s):** All

### NOTIF-005 [EXPLICIT] — Email Notification on Webhook Events
**Statement:** Given a VAPI call completes, When the webhook processes, Then an email notification is sent to configured recipients.
**Source:** CLAUDE.md, line 220 (Webhook flow: VAPI Call End -> Process); session-knowledge.md (webhook email is live production feature)
**Testable:** YES (manual — live webhook)
**Role(s):** System-triggered

### NOTIF-006 [EXPLICIT] — Mark All as Read
**Statement:** Given multiple unread notifications, When user clicks "Mark All as Read", Then all notifications are marked read via PUT /api/notifications/read-all.
**Source:** CARRY_FORWARD_MANIFEST.md (useMarkAllNotificationsRead)
**Testable:** YES (Playwright)
**Role(s):** All

---

## 15. Activity & Governance (GOVERN)

### GOVERN-001 [EXPLICIT] — AI Usage Event Logging
**Statement:** Given any AI interaction (DealerBrain chat, agent action, hunch generation), When the interaction completes, Then an AI usage event is logged with tokens used, tool calls, and cost.
**Source:** CARRY_FORWARD_MANIFEST.md (useActivityEvents, useActivityStats); DO_NOT_TOUCH.md, line 263 (ai_usage_events table)
**Testable:** YES (API — verify events exist after interaction)
**Role(s):** org_admin, super_admin

### GOVERN-002 [EXPLICIT] — Activity Feed Display
**Statement:** Given the Activity section (now inside Insights), When loaded, Then recent AI usage events display with action type, description, and timestamp.
**Source:** CARRY_FORWARD_MANIFEST.md (useRecentActivity); ===DevDesign Notes===.md, line 128
**Testable:** YES (Playwright)
**Role(s):** org_admin, partner_admin, super_admin

### GOVERN-003 [EXPLICIT] — Credit Balance Tracking
**Statement:** Given the credit system, When any AI-billable action occurs (voice call, video session, SMS), Then credits are deducted and the balance updates in real time.
**Source:** CARRY_FORWARD_MANIFEST.md (useCreditBalance, useCreditUsage); DO_NOT_TOUCH.md (CreditService)
**Testable:** YES (API — verify balance changes)
**Role(s):** org_admin, super_admin

### GOVERN-004 [EXPLICIT] — Approval Workflow
**Statement:** Given an approval request is created, When it reaches an approver, Then the approver can approve or reject with comments via /api/approvals/:id/resolve.
**Source:** CARRY_FORWARD_MANIFEST.md (useApprovals, useResolveApproval)
**Testable:** YES (Playwright)
**Role(s):** org_admin (approve), All (request)

### GOVERN-005 [EXPLICIT] — Artifacts by Conversation
**Statement:** Given DealerBrain generates artifacts (charts, summaries), When user views conversation history, Then artifacts are associated with their source conversation.
**Source:** CARRY_FORWARD_MANIFEST.md (useArtifactsByConversation)
**Testable:** YES (Playwright)
**Role(s):** All

---

## Watch Area Findings

### Watch Area 1: Agent Functionality

| # | Finding | Risk | Source |
|---|---------|------|--------|
| W1-1 | Skills architecture (V2 model) was never documented in any AC file the agent reads | HIGH | session-knowledge.md, Section 2; known_issues.md.md, Category A |
| W1-2 | V1 had 27 hardcoded agents; V2 replaces with user-created agents + skills catalog (74 pre-built) — transition logic needs explicit AC | HIGH | session-knowledge.md; DESIGNER_UPDATE_SPEC.md |
| W1-3 | Communications Agent (e.g., "Caroline") is static, configured by Super Admin only — different from user-created agents | MEDIUM | ===DevDesign Notes===.md, lines 72-75 |
| W1-4 | Agent tools exist at widget level (7 system tools), not per-agent — AC currently silent on this | MEDIUM | session-knowledge.md; known_issues.md.md, A4 |

### Watch Area 2: Billing

| # | Finding | Risk | Source |
|---|---------|------|--------|
| W2-1 | Billing page is a NEW feature in DESIGNER_UPDATE_SPEC but has no testable AC in any input file | HIGH | DESIGNER_UPDATE_SPEC.md, Billing section |
| W2-2 | Economy section on tool cards is specified in design but has no AC for rate calculations | MEDIUM | DESIGNER_UPDATE_SPEC.md |
| W2-3 | Credit service wired in backend (DO_NOT_TOUCH) but no AC for displaying credit balance to users | MEDIUM | DO_NOT_TOUCH.md; CARRY_FORWARD_MANIFEST.md |

### Watch Area 3: Unified Inbox

| # | Finding | Risk | Source |
|---|---------|------|--------|
| W3-1 | External agent conversations continued by staff is a core concept but has no formal AC | HIGH | session-knowledge.md, Section 4a |
| W3-2 | Email integration exists (IMAP/SMTP hooks) but email is "missing from interface" per owner | HIGH | CLARIFICATION_ANSWERS.md ("email missing from interface") |
| W3-3 | Canned responses mentioned in SRS Addendum v3.2 but not in AC | LOW | Nexxus_SRS_Addendum_v3.2, line 533 |

### Watch Area 4: Super Admin

| # | Finding | Risk | Source |
|---|---------|------|--------|
| W4-1 | Org Creation Wizard is a new feature with design spec but minimal AC | MEDIUM | DESIGNER_UPDATE_SPEC.md |
| W4-2 | Super Admin org switch to "Nexxus System" is mentioned once, no AC for what "system view" shows | MEDIUM | ===DevDesign Notes===.md, line 37 |
| W4-3 | Skills tab emergency kill switch mentioned in design but no AC for behavior when activated | HIGH | DESIGNER_UPDATE_SPEC.md |

### Watch Area 5: Context Router

| # | Finding | Risk | Source |
|---|---------|------|--------|
| W5-1 | Context Router is inverted-then-fixed; truth hierarchy is VIN > VAPI/Tavus > Local > Derived — but no AC tests this ordering | HIGH | session-knowledge.md; UNIFIED_HANDOFF_PROMPT.md, Lesson 6 |
| W5-2 | Context Router should have 3 clear sections (Memory Stores, Sync Data, Upload Data Store) per owner — no AC covers this UI | MEDIUM | ===DevDesign Notes===.md, line 41 |
| W5-3 | VIN API has hard limits (17 of 30 endpoints return 403) — no AC explicitly defines "graceful degradation when VIN returns 403" | HIGH | UNIFIED_HANDOFF_PROMPT.md, Lesson 1; DATA_SOURCE_INVENTORY.md |

---

## Conflicts Found

### CONFLICT-01: Hub Tab Count
**File A:** Older SRS docs reference Hub with 4 tabs (Calendar, Leads, Inbox, Tasks)
**File B:** session-knowledge.md and ===DevDesign Notes===.md specify exactly 3 tabs (Calendar, Leads, Inbox)
**Resolution:** Owner confirmed 3 tabs. Tasks is separate or removed. **Use 3 tabs.**

### CONFLICT-02: VIN Write-Back Scope
**File A:** MASTER_SRS.md, AC-004 implies lead insertion to VIN (write)
**File B:** Nexxus_SRS_Addendum_v3.1, REQ-VIN-CLARIFY-001 says "NO write-back capabilities to VIN Solutions CRM"
**File C:** CLARIFICATION_ANSWERS.md says "VIN write-back: leads only"
**Resolution:** Write-back is limited to LEAD CREATION only (2-step: create contact, then create lead). No other write operations.

### CONFLICT-03: Settings Tile Count
**File A:** Some docs reference 10 settings tiles
**File B:** DESIGNER_UPDATE_SPEC.md specifies 9 tiles (API & Webhooks moved inside Tools & Integrations)
**Resolution:** **Use 9 tiles** per latest design spec.

### CONFLICT-04: Goals Feature
**File A:** MASTER_SRS.md includes Goals integration features
**File B:** ===DevDesign Notes===.md, line 66 says "Goals - Remove"
**Resolution:** **Goals removed from Insights.** Backend endpoints may still exist but UI should not render Goals sub-tab in Insights.

### CONFLICT-05: Activity Feed Location
**File A:** Some docs show Activity as standalone sidebar item
**File B:** ===DevDesign Notes===.md, line 128 says "move activity into a sub-tab in insights"
**Resolution:** **Activity is inside Insights as a sub-tab**, not a standalone page.

### CONFLICT-06: DealerBrain vs Automa Naming
**File A:** Multiple backend files reference "DealerBrain"
**File B:** ===DevDesign Notes===.md, line 127 says "Automa aka dealer brain... The dealer brain will simply be omitted"
**Resolution:** **UI shows "Automa" only.** Backend can keep "DealerBrain" internally but no user-facing surface uses the name.

### CONFLICT-07: VIN Integration Model
**File A:** Nexxus_SRS_Addendum_v3.1 says "No bidirectional sync, no webhook subscriptions"
**File B:** IMPLEMENTATION_PLAN.md references "performanceMetrics from VIN" and "VAPI Analytics wiring"
**Resolution:** VIN integration is query-driven with caching. Lead creation (2-step) is the ONLY write operation. No bidirectional sync.

### CONFLICT-08: AC File Authority
**File A:** docs/ACCEPTANCE_CRITERIA.md (89KB, in git)
**File B:** .agent_docs/acceptance_criteria.md (PLACEHOLDER)
**File C:** — Acceptance Criteria.md (in preflight-input/, owner's 13-item + Replit spec)
**Resolution:** For this surgery: preflight-input/— Acceptance Criteria.md is the owner's latest intent. The other two are unreliable.

### CONFLICT-09: Hosted Pages URL Pattern
**File A:** Client code fetches /api/hosted-pages/public/:slug
**File B:** Server serves /api/pages/:slug
**Resolution:** Known P0 bug. One-line fix needed. **AC should test the CORRECTED route.**

### CONFLICT-10: TextMagic Credential Storage
**File A:** No AC document mentions where TextMagic credentials are stored
**File B:** Owner confirmed: per-org in database (textmagic_config table), NOT in .env
**Resolution:** AC should specify per-org TextMagic config stored in DB with encrypted API key.

### CONFLICT-11: Email in Hub
**File A:** ===DevDesign Notes===.md mentions "Email selection" in new message modal
**File B:** CLARIFICATION_ANSWERS.md says "email missing from interface"
**Resolution:** Email hooks exist in backend. Owner acknowledges gap. **Flag as partially implemented — needs owner decision on scope.**

### CONFLICT-12: Report Upload vs Data Uploads
**File A:** Nexxus_SRS_Addendum_v3.1 describes VIN report upload via Drive
**File B:** DESIGNER_UPDATE_SPEC.md puts Data Uploads under Settings > Data Management
**Resolution:** Both paths may coexist. AC should cover the Settings > Data Management path as primary.

---

## Missing AC (Features Without Criteria)

### MISSING-01: Billing Page Acceptance Criteria
**Feature:** Full billing page with subscription tiers, usage meters, invoice builder
**Source:** DESIGNER_UPDATE_SPEC.md (Billing section)
**Impact:** HIGH — payment-adjacent feature with no testable criteria

### MISSING-02: Profile Page Acceptance Criteria
**Feature:** User profile viewing and editing
**Source:** CARRY_FORWARD_MANIFEST.md (useUpdateProfile)
**Impact:** LOW — standard CRUD, but no AC defined

### MISSING-03: Password Reset E2E Flow
**Feature:** Complete forgot-password to reset-password flow
**Source:** UNIFIED_HANDOFF_PROMPT.md (auth endpoints)
**Impact:** MEDIUM — user-facing, needs AC for email link + reset form

### MISSING-04: Tracking Pixel Behavior
**Feature:** Attribution tracking pixel behavior and UTM capture
**Source:** Nexxus_SRS_Addendum_v3.2, REQ-TRACK-001 (lines 437-481)
**Impact:** MEDIUM — data accuracy for attribution relies on this

### MISSING-05: Knowledge Base Upload Flow
**Feature:** Document upload, parsing, indexing in Knowledge Base
**Source:** DESIGNER_UPDATE_SPEC.md (Knowledge Base section); DO_NOT_TOUCH.md (KnowledgeUploadService)
**Impact:** MEDIUM — affects DealerBrain's ability to answer org-specific questions

### MISSING-06: Email Integration Full Flow
**Feature:** IMAP/SMTP email compose, send, receive in Hub
**Source:** CARRY_FORWARD_MANIFEST.md (useEmail hooks); CLARIFICATION_ANSWERS.md ("email missing from interface")
**Impact:** HIGH — hooks exist, backend exists, but UI AC is absent

### MISSING-07: Drive Sharing Flow
**Feature:** Sharing Drive files via email or SMS
**Source:** ===DevDesign Notes===.md, lines 98, 201-203
**Impact:** MEDIUM — mentioned in design notes but no testable AC

### MISSING-08: Reporting PDF Export
**Feature:** Report generation and PDF download
**Source:** CARRY_FORWARD_MANIFEST.md (useGenerateReport); DO_NOT_TOUCH.md (PdfReportService)
**Impact:** MEDIUM — backend exists but no AC for user-facing flow

### MISSING-09: VIN API Graceful Degradation
**Feature:** Behavior when VIN API returns 403 on blocked endpoints
**Source:** DATA_SOURCE_INVENTORY.md (17 of 30 endpoints blocked); UNIFIED_HANDOFF_PROMPT.md, Lesson 1
**Impact:** HIGH — affects data accuracy and user experience

### MISSING-10: Context Router UI in Settings
**Feature:** 3-section Context Router configuration (Memory Stores, Sync Data, Upload Data Store)
**Source:** ===DevDesign Notes===.md, line 41
**Impact:** MEDIUM — owner-specified but no testable AC

### MISSING-11: SMS Opt-Out Compliance
**Feature:** STOP keyword detection, opt-out confirmation, opt-back-in
**Source:** Nexxus_SRS_Addendum_v3.2_Widget_SMS_Notifications.md, Security section (lines 699-706)
**Impact:** HIGH — compliance requirement with no testable AC

### MISSING-12: Data Health Dashboard
**Feature:** Data quality monitoring and health indicators
**Source:** DESIGNER_UPDATE_SPEC.md (Data Management > Data Health tab)
**Impact:** MEDIUM — new feature with no AC

### MISSING-13: Emergency Kill Switch Behavior
**Feature:** What happens when Super Admin activates the skills emergency kill switch
**Source:** DESIGNER_UPDATE_SPEC.md (AI Configuration > Skills tab)
**Impact:** HIGH — safety-critical feature with no behavior specification

### MISSING-14: Dealer Pulse Feature
**Feature:** 5-phase dealer health snapshot (pipeline, team, action items, neglected leads)
**Source:** CARRY_FORWARD_MANIFEST.md (useDealerPulse); DO_NOT_TOUCH.md (DealerPulseService)
**Impact:** LOW — backend exists, but no above-the-line AC for display

---

## Cross-Wave Notes

### For Wave 1 (File Inventory)
- Standards.md was listed at preflight-input/ root but actually lives in preflight-input/other_notes/Standards.md
- opinions_facts.md.md, Current_State.md.md, known_issues.md.md, Forensics.md.md all live in preflight-input/other_notes/ subdirectory

### For Wave 2 (Architecture Extraction)
- The 3-pane layout system (sidebar 64px, left/center/right panes) should appear in architecture map
- Provider tree order: QueryClientProvider > ThemeProvider > AuthProvider > AppProvider > ChatProvider
- SSE streaming protocol (6 event types) is architecture-critical for DealerBrain

### For Wave 3 (TBD — if exists)
- No wave3 file found in wave-notes/ — may be skipped or pending

### For Reviewer (Wave 4 cross-validation)
- 12 conflicts identified — reviewer should independently verify which resolution is correct
- 14 missing AC areas — reviewer should check if I missed source files that cover these
- Watch area findings should be compared for agreement/disagreement
- Hub tab count (3 not 4) is a critical reconciliation point
- Owner's 13 demo AC items (from — Acceptance Criteria.md lines 1-18) should be mapped to specific AC-XXX items by reviewer

### For Future Phases
- CONFLICT-09 (hosted pages route mismatch) is a known 1-line fix — should be resolved before testing
- CONFLICT-08 (AC file authority) is the root cause of many prior failures — the surgery's output must produce ONE authoritative AC file
- All 15 triggers being deactivated (TRIGGER-007) means AC-1 (Automatic Outbound Call Triggering) cannot be verified without manual activation

---

## Source File Log

| # | File | Location | Priority | Lines Read | AC Extracted |
|---|------|----------|----------|------------|--------------|
| 1 | session-knowledge.md | workbench root | CRITICAL | ~200 | 12 |
| 2 | file-inventory.md | workbench root | CRITICAL | ~100 | 0 (index only) |
| 3 | — Acceptance Criteria.md | preflight-input/ | HIGH | ~489 | 42 |
| 4 | MASTER_SRS.md | preflight-input/ | HIGH | ~990 | 35 |
| 5 | UI_INTERACTIVE_ELEMENTS_MAP.md | preflight-input/ | HIGH | 207 | 18 |
| 6 | IMPLEMENTATION_PLAN.md | preflight-input/ | HIGH | 814 | 15 |
| 7 | ACCEPTANCE_VERIFICATION_REPORT.md | preflight-input/ | HIGH | 137 | 8 |
| 8 | DESIGNER_UPDATE_SPEC.md | preflight-input/ | HIGH | ~800+ | 22 |
| 9 | CONSTITUTION.md | preflight-input/ | HIGH | 166 | 6 |
| 10 | app_identity.md | preflight-input/ | HIGH | 359 | 10 |
| 11 | CLARIFICATION_ANSWERS.md | preflight-input/ | HIGH | 150 | 8 |
| 12 | —Org admin Metrics - Main - org admin.md | preflight-input/ | HIGH | 77 | 4 |
| 13 | —Staff Metrics.md | preflight-input/ | HIGH | 109 | 4 |
| 14 | —Reports.md | preflight-input/ | HIGH | 361 | 6 |
| 15 | —Hunches.md | preflight-input/ | HIGH | 431 | 4 |
| 16 | —Insights Layout.md | preflight-input/ | HIGH | 749 | 8 |
| 17 | ARCHITECTURE_GUIDE.md | preflight-input/ | HIGH | ~500 | 5 |
| 18 | CLAUDE.md | preflight-input/ | HIGH | 359 | 3 |
| 19 | Nexxus_SRS_Addendum_v3.1_MVP_Critical.md | preflight-input/ | MEDIUM | ~600 | 12 |
| 20 | Nexxus_SRS_Addendum_v3.2_Widget_SMS_Notifications.md | preflight-input/ | MEDIUM | 732 | 18 |
| 21 | ===DevDesign Notes===.md | preflight-input/ | HIGH | 228 | 28 |
| 22 | DO_NOT_TOUCH.md | preflight-input/ | MEDIUM | 662 | 5 |
| 23 | CARRY_FORWARD_MANIFEST.md | preflight-input/ | MEDIUM | 502 | 20 |
| 24 | UNIFIED_HANDOFF_PROMPT.md | preflight-input/ | MEDIUM | 528 | 10 |
| 25 | REVERSE_SRS_old.md | preflight-input/ | MEDIUM | 200 | 5 |
| 26 | DATA_SOURCE_INVENTORY.md | preflight-input/ | MEDIUM | 150 | 3 |
| 27 | Standards.md | preflight-input/other_notes/ | LOW | 261 | 0 (meta only) |
| 28 | known_issues.md.md | preflight-input/other_notes/ | MEDIUM | 229 | 5 |

### Files NOT Read (Low Priority or Inaccessible)
- database-audit.md, server-audit.md, client-audit.md — forensic audits, backend-focused
- Forensics.md.md — in other_notes/, likely redundant with known_issues
- opinions_facts.md.md — file not found at expected path
- CUSTOMER_ONBOARDING_KICKOFF.md — onboarding checklist, operational
- VIN Solutions API docs (filestore/VinDocs/) — backend reference only

---

## Methodology Notes

1. **Extraction priority:** Owner's 13 demo AC items were extracted first as payment-critical anchors, then formal MASTER_SRS AC-001 through AC-019, then Replit mockup AC, then all remaining sources.
2. **EXPLICIT vs INFERRED:** Items marked EXPLICIT have a direct testable statement in a source file. Items marked INFERRED were derived from behavior descriptions, UI element maps, or design specifications that imply a testable outcome but don't state it as a formal AC.
3. **Line numbers:** Where exact line numbers are cited, they refer to the line count as reported by the Read tool. Some large files were read in chunks; line numbers are approximate for files exceeding 2000 lines.
4. **Role mapping:** super_admin=level 1, partner_admin=level 2, org_admin=level 3, org_staff=level 4. "All" means all 4 roles.
5. **Testable YES (Playwright)** means the AC can be verified by automated browser testing. **Testable YES (manual)** means it requires live integration (VAPI calls, SMS delivery, Claude API) that cannot be fully automated.
